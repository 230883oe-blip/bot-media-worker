# -*- coding: utf-8 -*-
"""
"קרן שמש בהפתעה" - תסריט ובימוי, 50 שניות בדיוק. (05/10)

שני שחקנים חדשים, בניגוד **שפת צורות** ולא בניגוד מין:
  זיגי  - עגולה, קופצנית, מאירת פנים. `dimorph="round"`.
  גרומפ - מרובע, כבד, זעפן.           `dimorph="block"`.
שניהם רשומים ב-`rig.pipeline.CAST`, והניגוד ביניהם נמדד מהרשת שנבנתה
ב-`rig.dimorph.audit_shape` (7 בדיקות, כולן עוברות).

**למה הקובץ הזה הוא נתונים ולא קוד רינדור.** הבקשה כאן היא תסריט
מוקפד באורך מדויק, והדבר היחיד שאפשר לאמת בלי להריץ מנוע שלם הוא
**החוזה**: שסכום השוטים הוא 50.000 שניות ולא 49.8, שכל שוט נושא את
סוג הצילום שהוזמן, ששתי הדמויות מופיעות, ושהדיאלוג יושב בתוך גבולות
השוט שלו. תסריט שמספריו לא נסגרים הוא תקלה שמתגלה אחרי שעת רינדור,
ולכן יש כאן `validate()` ובדיקה בחבילה.
"""
from __future__ import annotations

from dataclasses import dataclass, field

#: **60 ולא 50 מאז TASK 13 (06/10).** נוסף שוט חמישי של עשר שניות -
#: פיזור השלכת ותגובת גרומפ. 60 נבחר ולא 62: מחזור הרוח והעננים
#: (`park.LOOP_SEC = 10`) חייב להתחלק באורך הסרט בדיוק, ואורך שאינו
#: מתחלק מייצר קפיצה בתפר הלופ שנראית כמו פריים שאבד.
TOTAL_SECONDS = 60.0
CAST = ("zippy", "grump")
#: דמות המשנה. היא אינה ב-CAST כי אין לה ריג, אין לה קול ואין לה
#: דיאלוג - היא חיה, לא שחקנית. ראה `rig.ensemble`.
EXTRAS = ("nutsy",)

#: הלוקיישן. פארק פתוח ביום שמש מלא - וזה הניגוד לכל מה שנבנה כאן עד
#: היום, שהיה תאורת אולפן סגורה ("studio"). שלושת הדברים שהסביבה
#: אמורה להוכיח: תנועה משנית של עלים ברוח, צללים ארוכים מכיוון אחד,
#: והבזק עדשה כשקרן השמש פוגעת ישירות.
LOCATION = {
    "name": "פארק פתוח, אחר צהריים",
    "light": "sun_hard_left",     # שמש קופחת משמאל = צללים ארוכים ימינה
    "sun_azimuth_deg": -62.0,
    "sun_elevation_deg": 24.0,
    "props": ("עצים מוריקים", "דשא", "ספסל עץ", "שביל",
              # TASK 13: אביזרים ש**נוגעים** בדמויות, ולא רקע.
              "ערימת עלי שלכת", "פנס פארק מקולקל", "סל פיקניק על הספסל"),
    "wind": {"speed": 0.35, "gust": 0.12},   # מניע עלים וענפים
    "effects": ("צללים ארוכים", "אור מנוקד בין העלים", "הבזק עדשה בסיום",
                "אור מהבהב מהפנס", "עומק שדה בקשת המצלמה"),
    #: אורך הסרט עובר לשכבת הסביבה: הלופ של הרוח חייב להתחלק בו.
    "total_seconds": TOTAL_SECONDS,
}


@dataclass
class Line:
    who: str
    at: float               # שנייה מוחלטת בתוך הסרט
    secs: float
    text: str
    voice: str = ""         # איך זה נאמר - לא מה נאמר


@dataclass
class Shot:
    key: str
    start: float
    secs: float
    camera: str             # wide / medium / close_up
    angle: str
    visual: str
    action: str
    lines: list[Line] = field(default_factory=list)
    beats: tuple = ()       # רגעי משחק שחייבים להיראות

    @property
    def end(self) -> float:
        return round(self.start + self.secs, 3)


SHOTS: list[Shot] = [
    Shot(
        key="s1_park_wide", start=0.0, secs=10.0,
        camera="wide", angle="גובה עיניים, מצלמה נייחת עם סחיפה קלה ימינה",
        visual="הפארק כולו. עצים נעים ברוח (תנועה משנית בעלים ובענפים), "
               "שמש קופחת משמאל ויוצרת צללים ארוכים על הדשא.",
        action="זיגי נכנסת לפריים בקפיצות אדירות עם מתיחה וכיווץ מוגזמים; "
               "גרומפ גורר רגליים מאחור, איטי וכבד, הצל שלו נגרר איתו.",
        lines=[Line("zippy", 1.75, 7.94,
                    "תראה איזה יום מושלם! השמש זורחת, הציפורים עפות באוויר, "
                    "בוא נרוץ עד העץ הגדול!",
                    voice="מתלהב, גבוה, מהיר")],
        beats=("squash_stretch_על_כל_נחיתה", "משקל_כבד_בכל_צעד_של_גרומפ",
               "עלים_זזים_ברוח", "צללים_ארוכים_מכיוון_אחד"),
    ),
    Shot(
        key="s2_confrontation", start=10.0, secs=15.0,
        camera="medium", angle="שלושה-רבעים, שתי הדמויות בפריים",
        visual="המצלמה עוברת לזווית 3/4. ההבדל בין הצורות קורא מיד: "
               "זיגי עגולה וגמישה מול גרומפ המרובע והנוקשה.",
        action="גרומפ נעצר בעצירה פתאומית ומשלב ידיים בכעס; השיער שלו "
               "מגיב באיחור (follow-through). זיגי נבלמת מולו בחריקה, "
               "עיניים פעורות בתדהמה.",
        lines=[Line("grump", 12.4, 11.76,
                    "שמש? עצים? זה עושה קמטים בפנים ומזיע בטירוף. "
                    "אני הולך לשבת בצל של הספסל הזה ולא לזוז לעולם.",
                    voice="נהימה עמוקה, קצרה, אדישה")],
        beats=("עצירה_פתאומית_עם_השהיה", "follow_through_בשיער",
               "ניגוד_צורות_נקרא_בצללית", "ידיים_משולבות_מכוונות"),
    ),
    Shot(
        key="s3_faces", start=25.0, secs=15.0,
        camera="close_up", angle="תקריב קיצוני, חיתוך מהיר בין הפנים",
        visual="תקריב על פני זיגי, ואז חיתוך לתקריב על פני גרומפ. "
               "אור שמש צדדי שמדגיש תווי פנים ומרקם עור.",
        action="זיגי עוברת מחיוך ענק לשפתיים רוטטות של עצב בתוך שתי "
               "שניות - הבעה מורכבת שמשתנה, לא מתחלפת. גרומפ מגלגל "
               "עיניים בהגזמה ומפהק פיהוק ענק.",
        lines=[Line("zippy", 26.2, 4.66,
                    "אבל... אבל הבטחת שנשחק תופסת אור!",
                    voice="מתקתק ורוטט, נשבר בסוף"),
               Line("grump", 32.6, 5.69,
                    "אני לא הבטחתי שום דבר לאף אחד. תעזבי אותי בשקט.",
                    voice="אדיש לחלוטין, שטוח")],
        beats=("מעבר_רגש_מורכב_בשתי_שניות", "גלגול_עיניים_מוגזם",
               "פיהוק_עם_מתיחת_לסת_מלאה", "אור_צדדי_מדגיש_מרקם"),
    ),
    Shot(
        key="s4_pull_out", start=40.0, secs=10.0,
        camera="wide", angle="המצלמה נסוגה לאחור ומעלה",
        visual="קרן שמש גדולה פוגעת בעצים ויוצרת הבזק עדשה.",
        action="זיגי מתאוששת בשנייה, מחייכת חיוך ממזרי ומושכת את גרומפ "
               "קדימה בכוח. גרומפ מחליק על הדשא בתנועת מחאה מוגזמת.",
        lines=[Line("zippy", 41.6, 6.89,
                    "אין דבר כזה לשבת בצד! קדימה, גרומפ, השמש מחכה רק לנו!",
                    voice="שובב, מתגרה")],
        beats=("התאוששות_רגשית_מיידית", "משיכה_עם_העברת_משקל_אמיתית",
               "החלקה_על_דשא_עם_חיכוך", "הבזק_עדשה_בקרן_השמש"),
    ),
    # --- TASK 13 (06/10): הלהקה. הוראה: "choreograph a physical
    # interaction where Zippy accidentally scatters the leaves,
    # forcing Grump to react with heavy, exaggerated annoyance",
    # ולצידה דמות משנה שחוצה את הפריים, אביזרים אינטראקטיביים
    # וקשת מצלמה עם עומק שדה.
    #
    # **השוט הזה הוא שוט פיזי ולא שוט דיאלוג**, וזה מכוון: הבדיחה
    # היא הסיבה והתוצאה (רגל -> עלים -> פרצוף), ושתי שורות קצרות
    # מספיקות כדי למסגר אותה. דיאלוג ארוך כאן היה מכסה את התזמון
    # הקומי, שהוא כל מה שהשוט מוכיח.
    Shot(
        key="s5_leaves", start=50.0, secs=10.0,
        camera="arc",
        angle="קשת סוחפת סביב האקשן, יורדת אל גובה הקרקע באמצע",
        visual="השביל: ערימת שלכת, פנס פארק שמהבהב וסל פיקניק על "
               "הספסל. סנאי חוצה את הפריים בזינוקים, נעצר ליד הסל "
               "וחוטף אגוז. עומק השדה מטשטש את קו העצים.",
        action="זיגי מתכוננת, קופצת בהגזמה ונוחתת בתוך הערימה - "
               "העלים מתפזרים לכל עבר והקרקע מזדעזעת. גרומפ מגיב "
               "בהשהיה: גבות מרטטות, אנחה שמרוקנת את החזה, ואז "
               "חמישה צעדים כבדים אל הספסל.",
        lines=[Line("zippy", 52.95, 3.192, "אוי! לא בכוונה!",
                    voice="נבוך, גבוה, מתנצל"),
               Line("grump", 56.40, 3.432, "עלים. בכל הנעל.",
                    voice="שטוח לגמרי, בלי שום הפתעה")],
        beats=("נחיתה_מפזרת_עלים_בסיבתיות", "השהיית_תגובה_של_גרומפ",
               "מתיחה_וכיווץ_מוגזמים_בקפיצה", "זעזוע_קרקע_שדועך",
               "סנאי_חוצה_את_הפריים_ועוצר", "פנס_מהבהב_עם_אור_דינמי",
               "קשת_מצלמה_עם_עומק_שדה"),
    ),
]


def validate() -> dict:
    """
    חוזה התסריט. מחזיר {שם: {"pass": bool, "detail": str}}.

    כל כלל כאן הוא תקלה שראינו או שהייתה מתגלה רק אחרי רינדור.
    """
    out: dict[str, dict] = {}

    def chk(name: str, ok: bool, detail) -> None:
        out[name] = {"pass": bool(ok), "detail": str(detail)}

    total = round(sum(s.secs for s in SHOTS), 3)
    chk(f"אורך כולל {TOTAL_SECONDS:.0f} שניות בדיוק",
        total == TOTAL_SECONDS, total)

    # רצף בלי חורים ובלי חפיפה. חור של 0.2 שנייה הוא פריים שחור.
    ok, gap = True, ""
    cursor = 0.0
    for s in SHOTS:
        if round(s.start, 3) != round(cursor, 3):
            ok, gap = False, f"{s.key}: מתחיל ב-{s.start} ולא ב-{cursor}"
            break
        cursor = s.end
    chk("השוטים רצופים בלי חור ובלי חפיפה", ok, gap or "רצף תקין")

    # סוגי הצילום שהוזמנו, בסדר הזה.
    want_cams = ["wide", "medium", "close_up", "wide", "arc"]
    got_cams = [s.camera for s in SHOTS]
    chk("סוגי הצילום לפי הבימוי", got_cams == want_cams, got_cams)

    # TASK 13: השוט הפיזי חייב לשאת את כל ארבעת האביזרים והדמויות
    # החדשות, אחרת הוא שוט דיאלוג נוסף בתחפושת.
    ens = [s for s in SHOTS if s.camera == "arc"]
    chk("יש שוט אחד של קשת מצלמה", len(ens) == 1, [s.key for s in ens])
    if ens:
        txt = ens[0].visual + ens[0].action
        need = ("שלכת", "פנס", "סל", "סנאי")
        miss = [w for w in need if w not in txt]
        chk("ובו כל האביזרים החדשים ודמות המשנה", not miss, miss or "כולם")
        chk("ולפחות שבעה רגעי משחק (שוט פיזי צפוף)",
            len(ens[0].beats) >= 7, len(ens[0].beats))

    # האביזרים האינטראקטיביים הוכרזו בלוקיישן. אביזר שמופיע
    # באנימציה ולא בתסריט הוא אביזר שאיש לא ביים.
    for w in ("ערימת עלי שלכת", "פנס פארק מקולקל", "סל פיקניק על הספסל"):
        chk(f"האביזר '{w}' מוכרז בלוקיישן", w in LOCATION["props"], w)

    # כל שורת דיאלוג יושבת בתוך השוט שלה. שורה שגולשת נחתכת באמצע מילה.
    spill = [f"{ln.who}@{ln.at}" for s in SHOTS for ln in s.lines
             if ln.at < s.start or round(ln.at + ln.secs, 3) > s.end + 1e-6]
    chk("כל שורה יושבת בתוך השוט שלה", not spill, spill or "הכול בפנים")

    # שתי הדמויות מדברות, ואין דמות שהומצאה בטעות.
    who = {ln.who for s in SHOTS for ln in s.lines}
    chk("שתי הדמויות מדברות", who == set(CAST), sorted(who))

    # שתי שורות לא נאמרות בו-זמנית: בתקריב החיתוך הוא מה שמפריד.
    lines = sorted((ln for s in SHOTS for ln in s.lines), key=lambda x: x.at)
    clash = [f"{a.who}->{b.who}" for a, b in zip(lines, lines[1:])
             if b.at < a.at + a.secs - 1e-6]
    chk("אין חפיפת דיבור", not clash, clash or "אין")

    # לכל שוט יש רגעי משחק מוגדרים. שוט בלי beats הוא תיאור, לא בימוי.
    thin = [s.key for s in SHOTS if len(s.beats) < 3]
    chk("לכל שוט לפחות שלושה רגעי משחק", not thin, thin or "תקין")

    # הסביבה החיצונית: בלי שמש וצללים זה אולפן עם רקע ירוק.
    chk("הלוקיישן חיצוני עם שמש וצללים",
        LOCATION["light"].startswith("sun") and "צללים ארוכים" in LOCATION["effects"],
        LOCATION["light"])
    chk("יש רוח שמניעה את העלים", LOCATION["wind"]["speed"] > 0,
        LOCATION["wind"])

    # **הבדיקה שתפסה תקלה אמיתית ב-05/10.** האורכים בתסריט נכתבו
    # בהערכה, וההקלטה בפועל יצאה אחרת: השורה הראשונה ארכה 7.94
    # שניות במקום 6.4 שהוצהרו, כלומר היא **גלשה 0.54 שניות מעבר
    # לסוף השוט** - הקול היה נחתך באמצע מילה בדיוק בחיתוך. אורך
    # מוצהר שאינו אורך ההקלטה הוא תקלה שמתגלה רק בצפייה, ולכן
    # היא נמדדת כאן מול קובץ הקול עצמו.
    #
    # אין הקלטה -> הבדיקה מדווחת "לא נמדד" ואינה נכשלת: התסריט
    # חייב להיות תקף גם לפני שהוקלט.
    try:
        import sys as _sys
        from pathlib import Path as _P
        _studio = _P(__file__).resolve().parents[2]
        if str(_studio) not in _sys.path:
            _sys.path.insert(0, str(_studio))
        from rig import voice as _V
        _voices = {"zippy": "hila", "grump": "avri"}
        worst, miss = 0.0, []
        for s in SHOTS:
            for ln in s.lines:
                tr = _V.load(ln.text, _voices.get(ln.who, "avri"))
                if tr is None:
                    miss.append(f"{ln.who}@{ln.at}")
                    continue
                worst = max(worst, abs(float(tr.seconds) - ln.secs))
        if miss and len(miss) == sum(len(s.lines) for s in SHOTS):
            chk("אורך כל שורה הוא אורך ההקלטה בפועל", True, "אין עדיין הקלטות")
        else:
            chk("אורך כל שורה הוא אורך ההקלטה בפועל",
                not miss and worst <= 0.05,
                f"סטייה מרבית {worst:.3f}ש" + (f", חסרות: {miss}" if miss else ""))
    except Exception as _e:                              # noqa: BLE001
        chk("אורך כל שורה הוא אורך ההקלטה בפועל", True,
            f"לא נמדד ({type(_e).__name__})")
    return out


def passed() -> bool:
    return all(v["pass"] for v in validate().values())


def main() -> int:
    import sys
    sys.stdout.reconfigure(encoding="utf-8")
    rep = validate()
    for k, v in rep.items():
        print(("✅" if v["pass"] else "❌"), k, "-", v["detail"])
    print(f"\n{len(SHOTS)} שוטים · {sum(s.secs for s in SHOTS):.1f} שניות · "
          f"{sum(len(s.lines) for s in SHOTS)} שורות דיאלוג")
    return 0 if passed() else 1


if __name__ == "__main__":
    raise SystemExit(main())
