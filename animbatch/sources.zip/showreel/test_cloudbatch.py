# -*- coding: utf-8 -*-
"""שערי האצווה בענן. בלי רשת, בלי גיטהאב, בשניות.

שלושה דברים נמדדים כאן, ואין ביניהם קשר:

1. **שהמסלול אינו חוסם.** זו כל הסיבה שהקובץ נכתב: זמן התור של רנר
   אפל נמדד 12-13 דקות, והמתנה סינכרונית אליו הייתה מאיטה כל עבודה
   כאן. לכן יש כאן שער מבני שאוסר ``sleep`` בקובץ, ושער שמוודא
   ש-``ensure`` שאינו מוכן **אינו קורא לעובד המקומי** - כלומר לא
   "מתקן" את ההמתנה בכך שהוא עובד פעמיים.
2. **שאין שתי אמיתות לאותה אצווה.** כרטיס שעבר לנפילה מקומית אינו
   חוזר לענן, גם אם הענן יענה אחר כך. שתי תוצאות לאותה ידית הן באג
   שאי אפשר לאבחן אחר כך.
3. **שמה שחסר נאמר.** עבודה שלא חזרה מהרנר אינה נמחקת בשקט ואינה
   הופכת ל"ציון 0" או ל"עברה" - שני המצבים הם דיווח שקרי.

``TICKETS`` מופנה כאן לתיקייה זמנית ומוחזר ב-``finally``. בלי זה
חבילת הבדיקות הייתה מערימה כרטיסים בתיקיית ההפקה האמיתית, והמעבר
הבא היה מגיש לענן אצווה שהיא שורת בדיקה.
"""
from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
STUDIO = HERE.parent
if str(STUDIO) not in sys.path:
    sys.path.insert(0, str(STUDIO))

from showreel import batch_worker as BW                    # noqa: E402
from showreel import cloudbatch as CB                      # noqa: E402
from showreel import deliver as DL                         # noqa: E402

JOBS = [{"task": "measure", "script": "duo10", "tuning": {"smooth_win": v}}
        for v in (0.08, 0.12, 0.16)]


# ------------------------------------------------------------- כפילים

class FakeAPI:
    """גיטהאב מדומה. סופר קריאות, ולכן אפשר למדוד *אי*-פנייה."""

    REPO = "fake/repo"

    def __init__(self, *, runs=None, run=None, arts=None,
                 dispatch_error=None, put_error=None):
        self.calls: list[str] = []
        self.puts: list[str] = []
        self.dispatched: list[tuple] = []
        self._runs = runs if runs is not None else {"workflow_runs": []}
        self._run = run or {"status": "queued"}
        self._arts = arts or {"results": {}}
        self.dispatch_error = dispatch_error
        self.put_error = put_error

    # --- ממשק שהקוד באמת משתמש בו
    @staticmethod
    def utc(s: str) -> float:
        return float(s)

    def req(self, path, method="GET", body=None, full=None):
        self.calls.append(path)
        if "/runs?" in path:
            return self._runs
        if "/actions/runs/" in path and path.endswith(tuple("0123456789")):
            return self._run
        return {}

    def put_file(self, repo_path, local):
        if self.put_error:
            raise RuntimeError(self.put_error)
        self.puts.append(repo_path)
        return Path(local).stat().st_size

    def dispatch(self, wf, inputs=None, tries=1):
        if self.dispatch_error:
            raise RuntimeError(self.dispatch_error)
        self.dispatched.append((wf, inputs))
        return 0.0

    def job_timing(self, run_id):
        return [{"name": "batch (1)", "conclusion": "success",
                 "queue_seconds": 742.0, "steps": {}}]

    def fetch_artifacts(self, run_id):
        self.calls.append("artifacts")
        return self._arts


def _arts_for(keys, *, worst=70.0):
    """artifact בצורה שהעובד באמת מייצר: ``{"results": {מפתח: {...}}}``."""
    rows = {k: {"key": k, "worst": worst + i, "mean": worst + i,
                "tuning": {"smooth_win": 0.1 + i / 100},
                "worst_key": "d1:a"} for i, k in enumerate(keys)}
    return {"results": {"animbatch-1": {"shard": 1, "results": rows}}}


class LocalWorker:
    def __init__(self, fail_on=""):
        self.seen: list[str] = []
        self.fail_on = fail_on

    def __call__(self, job):
        k = CB.job_key(job)
        self.seen.append(k)
        if self.fail_on and self.fail_on in k:
            raise RuntimeError("נפל בכוונה")
        return {"key": k, "worst": 55.0, "mean": 55.0,
                "tuning": job.get("tuning") or {}}


# -------------------------------------------------------------- שערים

def audit() -> dict:
    g: dict[str, dict] = {}

    def gate(name, ok, detail=""):
        g[name] = {"pass": bool(ok), "detail": str(detail)[:150]}

    tmp = Path(tempfile.mkdtemp(prefix="cloudbatch_"))
    old_tickets = CB.TICKETS
    CB.TICKETS = tmp / "tickets"
    try:
        _gates(gate, tmp)
    finally:
        CB.TICKETS = old_tickets
    return g


def _gates(gate, tmp: Path) -> None:
    # ---------------------------------------------- 1 · אריזת המקורות
    paths = CB.source_paths()
    gate("נארזים רק קובצי הפייתון של הפרויקט",
         paths and all(p.suffix == ".py" for p in paths), len(paths))
    gate("ו-__pycache__ אינו נארז",
         not any("__pycache__" in p.parts for p in paths))
    gate("ושלוש החבילות שהרנר צריך בפנים",
         all(any(f"{d}" in p.parts for p in paths)
             for d in ("rig", "studio", "showreel")))
    a = CB.pack_sources(tmp / "a.zip").read_bytes()
    b = CB.pack_sources(tmp / "b.zip").read_bytes()
    gate("האריזה דטרמיניסטית (אחרת כל הגשה דוחפת 600KB)",
         a == b, f"{len(a)} בייט")

    # --------------------------------------------------- 2 · הפיצול
    sh = CB.plan_shards(JOBS, 6)
    flat = [CB.job_key(j) for s in sh for j in s]
    gate("מספר הרנרים הוא מינימום(עבודות, תקרה)",
         len(sh) == 3, len(sh))
    gate("וכל עבודה מופיעה בדיוק פעם אחת",
         sorted(flat) == sorted(CB.job_key(j) for j in JOBS), len(flat))
    gate("אין רנר ריק", all(s for s in sh))
    many = CB.plan_shards([{"key": f"k{i}"} for i in range(14)], 6)
    gate("14 עבודות ל-6 רנרים מתפזרות בסבב ולא בחתיכות",
         len(many) == 6 and [len(s) for s in many] == [3, 3, 2, 2, 2, 2]
         and many[0][0]["key"] == "k0" and many[0][1]["key"] == "k6",
         [len(s) for s in many])
    gate("אצווה ריקה מחזירה אפס רנרים", CB.plan_shards([]) == [])

    # -------------------------------------------------- 3 · החתימה
    s1 = CB.signature(JOBS)
    s2 = CB.signature(list(reversed(JOBS)))
    gate("החתימה אינה תלויה בסדר", s1 == s2, s1)
    gate("ואצווה אחרת מקבלת חתימה אחרת",
         CB.signature(JOBS[:2]) != s1)

    # --------------------------------------------------- 4 · ההגשה
    api = FakeAPI()
    k = CB.submit(JOBS, api=api, now=1000.0)
    gate("ההגשה דוחפת מקורות ומטען ומפעילה",
         api.puts == ["animbatch/sources.zip", "animbatch/payload.json"]
         and len(api.dispatched) == 1, api.dispatched[:1])
    gate("ההגשה אינה מחכה לריצה (אפס קריאות מעקב)",
         api.calls == [], api.calls)
    gate("הכרטיס נשמר לדיסק (מצב בזיכרון נמחק בכל עלייה)",
         k.path.is_file() and k.state == "queued", k.state)
    gate("והרנר הוא macos-15 בלבד", k.runner == "macos-15", k.runner)

    api2 = FakeAPI()
    k2 = CB.submit(JOBS, api=api2, now=1060.0)
    gate("הגשה שנייה של אותה אצווה אינה מדליקה שש מכונות",
         k2.id == k.id and api2.dispatched == [], k2.id)
    api3 = FakeAPI()
    k3 = CB.submit(JOBS, api=api3, now=1000.0 + CB.REUSE_WINDOW + 10)
    gate("אבל אחרי חלון השימוש כן מוגשת מחדש",
         k3.id != k.id and len(api3.dispatched) == 1, k3.id)

    api4 = FakeAPI(dispatch_error="404 not indexed")
    k4 = CB.submit([{"key": "solo"}], api=api4, now=2000.0)
    gate("404 בהפעלה אינו קריסה אלא כרטיס עם הערה",
         k4.state == "queued" and "נתפסה" in k4.note, k4.note)

    # --------------------------------------------------- 5 · המעקב
    api = FakeAPI()
    k = CB.submit(JOBS, api=api, now=3000.0, reuse=False)
    p = CB.poll(k, api=api, now=3030.0)
    gate("ריצה שעוד לא נראתה נשארת בתור ולא חוסמת",
         p.state == "queued" and p.run_id == 0, p.state)

    api._runs = {"workflow_runs": [{"id": 77, "created_at": "3005"}]}
    api._run = {"status": "in_progress"}
    p = CB.poll(p, api=api, now=3060.0)
    gate("ריצה שהתחילה מסומנת רצה",
         p.state == "running" and p.run_id == 77, p.state)

    api._run = {"status": "completed", "conclusion": "success"}
    api._arts = _arts_for([CB.job_key(j) for j in JOBS])
    p = CB.poll(p, api=api, now=3200.0)
    gate("ריצה שהצליחה מחזירה תוצאות מהענן",
         p.state == "done" and p.source == "cloud"
         and len(p.results) == 3 and not p.missing, p.state)
    gate("וזמן ההמתנה בתור נרשם (זה המספר שמצדיק את כל המנגנון)",
         p.queue_seconds == 742.0, p.queue_seconds)
    before = len(api.calls)
    p2 = CB.poll(p, api=api, now=3300.0)
    gate("כרטיס סגור אינו נבדק שוב",
         len(api.calls) == before and p2.state == "done")

    api = FakeAPI(runs={"workflow_runs": [{"id": 9, "created_at": "4005"}]},
                  run={"status": "completed", "conclusion": "failure"})
    k = CB.submit(JOBS, api=api, now=4000.0, reuse=False)
    p = CB.poll(k, api=api, now=4100.0)
    gate("ריצה שנפלה מסומנת כשל ולא כ'אין תוצאות'",
         p.state == "failed" and "failure" in p.note, p.note)

    api = FakeAPI(runs={"workflow_runs": [{"id": 11, "created_at": "5005"}]},
                  run={"status": "completed", "conclusion": "success"},
                  arts={"results": {}})
    k = CB.submit(JOBS, api=api, now=5000.0, reuse=False)
    p = CB.poll(k, api=api, now=5100.0)
    gate("ריצה שעברה בלי שום תוצאה היא כשל, לא הצלחה ריקה",
         p.state == "failed" and not p.results, p.note)

    # ------------------------------------------ 6 · התור הארוך
    api = FakeAPI()
    k = CB.submit(JOBS, api=api, now=6000.0, reuse=False)
    p = CB.poll(k, api=api, now=6000.0 + CB.QUEUE_GRACE + 1)
    gate("תור ארוך מחלון החסד עובר לעבודה מקומית",
         p.state == "fallback" and p.source == "local", p.note[:60])
    api._runs = {"workflow_runs": [{"id": 5, "created_at": "6005"}]}
    api._run = {"status": "completed", "conclusion": "success"}
    api._arts = _arts_for([CB.job_key(j) for j in JOBS])
    before = len(api.calls)
    p2 = CB.poll(p, api=api, now=6000.0 + CB.QUEUE_GRACE + 600)
    gate("ואחרי שעבר למקומי הענן לא נקרא יותר (אין שתי אמיתות)",
         p2.state == "fallback" and not p2.results
         and len(api.calls) == before, p2.state)

    api = FakeAPI()
    k = CB.submit(JOBS, api=api, now=7000.0, reuse=False)
    k.state = "running"
    p = CB.poll(k, api=api, now=7000.0 + CB.RUN_LIMIT + 1)
    gate("ריצה שלא נסגרה בתקרת הזמן פגה", p.state == "timeout", p.state)

    # ------------------------------------------ 7 · איחוד וחסרים
    keys = [CB.job_key(j) for j in JOBS]
    got, miss = CB.merge_results(_arts_for(keys[:2])["results"], keys)
    gate("עבודה שלא חזרה מהרנר נרשמת כחסרה ולא נמחקת",
         len(got) == 2 and miss == [keys[2]], miss)
    got, miss = CB.merge_results(
        {"a": {"key": "x", "worst": 10.0}}, ["x", "y"])
    gate("גם artifact של עבודה בודדת מתאחד נכון",
         got.get("x", {}).get("worst") == 10.0 and miss == ["y"], miss)

    # ------------------------------------- 8 · כרטיס על הדיסק
    k = CB.Ticket(id="t1", signature="s", jobs=["a"], results={"a": {"x": 1}})
    k.save()
    back = CB.load_ticket(k.path)
    gate("כרטיס חוזר מהדיסק שלם",
         back is not None and back.results == {"a": {"x": 1}}, back and back.id)
    bad = CB.TICKETS / "broken.json"
    bad.write_text('{"id": "x", "resu', encoding="utf-8")
    gate("כרטיס פגום מוסג ואינו נקרא כ'אין כרטיס'",
         CB.load_ticket(bad) is None and not bad.is_file()
         and any(p.name.startswith("broken.corrupt-")
                 for p in CB.TICKETS.iterdir()))
    gate("וקובץ שאינו קיים מחזיר None בשקט",
         CB.load_ticket(CB.TICKETS / "nope.json") is None)

    # ------------------------------------------- 9 · התזמור
    api = FakeAPI(runs={"workflow_runs": [{"id": 3, "created_at": "8005"}]},
                  run={"status": "completed", "conclusion": "success"},
                  arts=_arts_for([CB.job_key(j) for j in JOBS]))
    w = LocalWorker()
    r = CB.ensure(JOBS, worker=w, api=api, now=8000.0)
    gate("תוצאות ענן מוכנות מוחזרות, והעובד המקומי לא נקרא",
         r["ready"] and r["source"] == "cloud" and w.seen == [], w.seen)

    # אצווה **אחרת** בכוונה: לאותה אצווה יש כבר כרטיס גמור שורה
    # למעלה, ושימוש חוזר בו הוא התנהגות נכונה ולא מה שנמדד כאן.
    fresh = [dict(j, script="fresh10") for j in JOBS]
    api = FakeAPI()
    w = LocalWorker()
    r = CB.ensure(fresh, worker=w, api=api, now=9000.0)
    gate("אצווה שרק הוגשה מחזירה ready=False ולא עובדת פעמיים",
         not r["ready"] and w.seen == [] and r["ticket"] is not None,
         f"{r['ready']} {w.seen}")
    r2 = CB.ensure(fresh, worker=w, api=api,
                   now=9000.0 + CB.QUEUE_GRACE + 1)
    gate("ואחרי חלון התור אותה קריאה כן מריצה מקומית",
         r2["ready"] and r2["source"] == "local"
         and len(w.seen) == 3, w.seen)

    w = LocalWorker()
    r = CB.ensure([{"key": "z1"}], worker=w,
                  api=FakeAPI(put_error="אין רשת"), now=9500.0)
    gate("ענן לא זמין בכלל → מקומי מיד, בלי כרטיס",
         r["ready"] and r["source"] == "local" and w.seen == ["z1"], w.seen)

    r = CB.ensure([{"key": "z2"}], worker=None,
                  api=FakeAPI(put_error="אין רשת"), now=9600.0)
    gate("ובלי עובד מקומי - לא מומצאות תוצאות",
         not r["ready"] and r["results"] == {}, r["results"])

    w = LocalWorker(fail_on="bad")
    out = CB.run_local([{"key": "ok1"}, {"key": "bad"}, {"key": "ok2"}], w)
    gate("עבודה שנפלה אינה מפילה את האצווה כולה",
         len(out) == 3 and "error" in out["bad"]
         and out["ok2"]["worst"] == 55.0, out["bad"]["error"])

    # ----------------------------------- 10 · הבחירה והתיאור
    res = {"a": {"worst": 60.0, "mean": 90.0, "tuning": {"smooth_win": 0.08}},
           "b": {"worst": 71.0, "mean": 71.0, "tuning": {"smooth_win": 0.2}},
           "c": {"error": "נפל"}}
    b = DL.best_of(res)
    gate("הבחירה היא לפי החלש ביותר ולא לפי הממוצע",
         b["tuning"] == {"smooth_win": 0.2} and b["n"] == 2, b)
    gate("ובלי תוצאות תקינות אין 'הטוב ביותר' מומצא",
         DL.best_of({"c": {"error": "x"}}) == {})
    txt = DL.cloud_text({"ready": False, "ticket": None})
    gate("הדיווח אומר במפורש שהעבודה כאן אינה ממתינה",
         "לא ממתינה" in txt, txt[:60])

    # ------------------------------- 11 · העובד שרץ על הרנר
    pay = CB.payload_of(JOBS, CB.plan_shards(JOBS, 6))
    gate("המטען מחזיק את העבודות ואת חלוקתן",
         len(pay["jobs"]) == 3 and len(pay["shards"]) == 3)
    rep = BW.run_shard({"jobs": [{"key": "u", "task": "nope"}],
                        "shards": [["u"]]}, 1, 6)
    gate("משימה לא מוכרת מוחזרת כשגיאה מפורשת",
         "error" in rep["results"]["u"], rep["results"]["u"].get("error"))
    rep = BW.run_shard(pay, 6, 6)
    gate("רנר שאין לו עבודות יוצא עם אפס ולא בשגיאה",
         rep["n"] == 0 and rep["results"] == {}, rep["n"])
    gate("והחומרה נרשמת בכל תוצאה ('ענה' אינו 'האיץ')",
         "mps" in rep["hw"] and "platform" in rep["hw"],
         rep["hw"].get("mps"))

    # ------------------------------ 12 · שערים מבניים
    src = (HERE / "cloudbatch.py").read_text(encoding="utf-8")
    gate("אין sleep בכל מסלול האצווה (זה כל החוזה)",
         "time.sleep" not in src and "await asyncio.sleep" not in src)
    gate("ו-gh.dispatch נקרא עם tries=1 (לא ניסיון חוזר עם המתנה)",
         "tries=1" in src)
    yml = (STUDIO / "gpucloud" / "animbatch.yml").read_text(encoding="utf-8")
    gate("קובץ התהליך מצהיר macos-15 ולא macos-14",
         "macos-15" in yml and "macos-14" not in yml.split("#")[0])
    gate("ומריץ את העובד עם מספר הרנר",
         "batch_worker.py" in yml and "--shard" in yml)
    gate("ו-fail-fast כבוי (רנר שנופל לא גורר את החמישה)",
         "fail-fast: false" in yml)
    gate("ותקרת הזיכרון של MPS מוגדרת (בלעדיה אפל מסרב להקצות)",
         "PYTORCH_MPS_HIGH_WATERMARK_RATIO" in yml)

    api = FakeAPI()
    r = DL.cloud_sweep("duo10", values=(0.1, 0.2), api=api,
                       allow_local=False)
    gate("סריקת הידיות בונה עבודה לכל ערך ואינה חוסמת",
         not r["ready"] and len(api.dispatched) == 1
         and r["knob"] == "smooth_win", r.get("source"))
    k = r["ticket"]
    gate("והכרטיס שלה מחזיק שתי עבודות",
         k is not None and len(k.jobs) == 2, k and k.jobs)


def passed() -> bool:
    return all(v["pass"] for v in audit().values())


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8")
    g = audit()
    bad = 0
    for k, v in g.items():
        print(("  ✓ " if v["pass"] else "  ✗ ") + k + " — " + v["detail"])
        bad += 0 if v["pass"] else 1
    print(f"\n{len(g) - bad}/{len(g)} שערים עברו")
    return 0 if bad == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
