# -*- coding: utf-8 -*-
"""שרשרת האספקה האוטונומית: תסריט → MP4 מאושר, בלי אדם באמצע.

**מה היה חסר, ולמה דווקא זה.** בפרויקט הזה כבר היה כל מה שצריך,
ובדיוק אף לא חוליה אחת שמחברת:

* ``showreel/bridge.py`` יודע לקחת תסריט כלשהו ולהפיק ממנו MP4 —
  ו**אינו מודד את מה שהוא הפיק**. אין בו שורה אחת שנוגעת ב-``qa``,
  ב-``panel`` או ב-``critics``.
* ``studio/panel.py`` + ``critics.py`` יודעים לשפוט חמישה ממדים —
  ועל ``Evidence`` שמישהו אחר צריך לבנות.
* ``studio/qa.py`` יודע לבדוק סרטון מרונדר — ואף אחד לא קורא לו
  בדרך אל האספקה.
* ``studio/mission.py`` יודע לאבחן ולתקן — ברמת ה**מערכת**, על
  סצנת המבחן של ``master``, ולא על התסריט שמוסרים בפועל.

כלומר: אפשר היה להפיק סרטון פגום ולמסור אותו, ואפשר היה לשרוף
26 דקות רינדור על תסריט שהמדידה הייתה פוסלת בשניות. הקובץ הזה הוא
החוליה הזו, ושלושת העקרונות שלו נגזרים כולם מכשלים שתועדו כאן:

1. **הזול קודם, ולפי סדר עולה של מחיר.** חוזה התסריט (אפס זמן) →
   שיפוט ממסלול הפוזות (שניות, בלי דפדפן בכלל) → טיוטה ברזולוציה
   נמוכה (דקות) → רינדור סופי (26 דקות). שלב שנפל **עוצר את
   השרשרת**, ולכן תסריט שבור לא מגיע לרינדור ולו פעם אחת.
   נמדד כאן: ``park_disney90_voiced`` = 1594.8 שניות רינדור, מול
   8.5 שניות ל-6 פריימי בדיקה. ההפרש הוא פי 190.
2. **ההחלקה היא על התנועה ולא על המדידה.** הידית שמנוע התיקון מזיז
   (``studio.tuning``) נכנסה ל-``bridge.build_shots`` עצמו, כלומר
   לאותה פונקציה שמזינה את הרינדור. פילטר שיושב במודד היה מוריד את
   ``anim.jitter`` בדיוק באותה מידה ו**לא משנה פריים אחד בסרטון** —
   כלומר ציון שעולה ואיכות שלא.
3. **"לא תוקן" נאמר במילים ולא מתורגם לתיקון מומצא.** כשלכשל אין
   ידית מחוברת, השרשרת עוצרת עם סיבה בשם מלא ו"דרוש אדם" — היא
   אינה מדשדשת עוד שלושה סבבים כדי להציג "ניסיתי".

    python -m showreel.deliver <תסריט>              # השרשרת כולה
    python -m showreel.deliver <תסריט> --review      # רק המדידה הזולה
    python -m showreel.deliver <תסריט> --no-draft    # בלי שלב הטיוטה
    python -m showreel.deliver --list                # אילו תסריטים יש
"""
from __future__ import annotations

import asyncio
import json
import sys
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Callable, Optional, Sequence

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from showreel import bridge as BR                         # noqa: E402
from studio import critics as C                           # noqa: E402
from studio import evidence as EV                         # noqa: E402
from studio import mission as MI                          # noqa: E402
from studio import panel as P                             # noqa: E402
from studio import qa as QA                               # noqa: E402

#: לאן נשמר דוח האספקה. בתוך הפרויקט, כדי שייכנס למאגר הגרסאות
#: ושיהיה אפשר לראות ב-``git diff`` מה נמסר ומה נדחה ומתי.
REPORTS = ROOT / "production" / "deliveries"

#: מי שופט **לפני** הרינדור. רק מבקר שכל מקורותיו זמינים בלי
#: פריימים נכנס לכאן: ``SOURCES["animation"] == ("shot_id",
#: "seconds", "track")``. מבקר שחסרה לו עדות מחזיר 0 לפי החלטה
#: מפורשת ב-``critics`` ("חוסר עדות = 0, לא פטור"), ולכן צירוף
#: ``visual`` לשלב שאין בו פיקסלים היה מפיל כל תסריט בעולם על
#: כשל של התשתית ולא של התסריט.
PRE_CRITICS: tuple[str, ...] = ("animation",)

#: קצב דגימת מסלול הפוזות. 12 ולא 30: המדדים של ``animation`` הם
#: נגזרות מנורמלות ב-``dt``, והדגימה הדלילה מוזילה את המדידה פי
#: 2.5 בלי לשנות את הסדר בין שוטים.
SAMPLE_FPS = 12

#: שיפור מינימלי שמצדיק סבב נוסף. מתחת לזה הלולאה **עוצרת**
#: ואומרת "קיפאון": סבב שלא הזיז את המדידה יחזור על עצמו עד תקרת
#: הסבבים וידווח "ניסיתי שלוש פעמים" על מערכת שלא השתנתה.
MIN_GAIN = 0.5

MAX_ROUNDS = 4


# ======================================================== מפרט מעבר

@dataclass(frozen=True)
class PassSpec:
    """מפרט רינדור אחד. ``fps=0`` = להיגזר מהתסריט."""

    label: str
    width: int
    height: int
    ss: int
    fps: int = 0
    strict_edges: bool = True

    def resolved(self, sc) -> "PassSpec":
        if self.fps:
            return self
        return PassSpec(self.label, self.width, self.height, self.ss,
                        draft_fps(sc) if self.label == DRAFT.label
                        else int(sc.fps), self.strict_edges)


#: **הטיוטה קטנה בכוונה, ובכל שלושת הצירים.** רזולוציה, על-דגימה
#: וקצב פריימים. היא נמדדת ב-``qa`` על בדיקות שאינן תלויות
#: ברזולוציה (ריק, ניגוד, קיפאון, תנועה, לופ, משך), ולכן
#: ``strict_edges=False``: בדיקת שולי הקאדר על 480 פיקסל רוחב
#: מודדת את הפיקסליזציה ולא את הבימוי.
DRAFT = PassSpec("טיוטה", 480, 270, 1, 0, strict_edges=False)
FINAL = PassSpec("סופי", 1920, 1080, 2, 0, strict_edges=True)


def env_loops() -> dict[str, float]:
    """מחזורי הסביבה הצרובה, בשניות.

    נשלפים מהמודולים עצמם ולא מועתקים: מספר שמועתק נבדל בשקט
    ברגע שמישהו משנה את המקור, ואז הבדיקה הזולה מאשרת תסריט
    שהרינדור ידחה — כלומר הגרוע מכל העולמות.
    """
    from rig import park as PK                             # noqa: PLC0415
    from stage import park_disney as _PD                   # noqa: PLC0415
    return {"מחזור הרוח": float(PK.LOOP_SEC),
            "מחזור המזרקה": float(_PD.FOUNTAIN_LOOP)}


def loop_misfits(total: float) -> list[str]:
    """אילו מחזורי סביבה אינם מתחלקים באורך הסרט.

    **זה נתפס ברינדור ולא בחוזה, וזו הייתה טעות.** ``produce``
    זורק ``RuntimeError`` עם שמות השערים אחרי שהסביבה נצרבה,
    ואילו כאן זה אפס זמן ולפני כל שלב אחר. תפר שאינו נסגר נראה
    לצופה **בדיוק** כמו פריים שאבד.
    """
    out: list[str] = []
    for name, v in env_loops().items():
        if v > 0 and abs(total / v - round(total / v)) > 1e-9:
            out.append(f"{name} ({total:g}/{v:g})")
    return out


def draft_fps(sc, cap: int = 10) -> int:
    """קצב הטיוטה: המחלק הגדול ביותר של ``sc.fps`` שאינו עובר ``cap``.

    **חייב להיות מחלק.** חוזה הגשר דורש שכל שוט יהיה כפולה שלמה
    של פריים, והוא נבדק מול ``sc.fps``; רינדור בקצב שאינו מחלק
    היה שובר את ההנחה הזו בשקט דווקא בשוטים בעלי אורך שאינו שלם.
    """
    f = max(1, int(sc.fps))
    for d in range(min(int(cap), f), 0, -1):
        if f % d == 0:
            return d
    return f


# =========================================================== מדידה

def verdict_for(shot_id: str, seconds: float, actor: Callable, *,
                sample_fps: int = SAMPLE_FPS,
                names: Sequence[str] = PRE_CRITICS) -> P.PanelVerdict:
    """שיפוט שחקן אחד בשוט אחד, **בלי רינדור**.

    פאנל חדש לכל שיפוט בכוונה: ל-``Panel`` יש זיכרון (בחירת
    החוליה החלשה "דביקה" כשהתיקון עובד), והוא נכון בין *סבבים*
    על אותו שוט — אבל פאנל אחד שרץ על שמונה דמויות בזה אחר זה
    היה מכריע את הדמות השמינית לפי מה שנמדד אצל הראשונה.
    """
    ev = C.Evidence(shot_id=shot_id, seconds=float(seconds))
    ev.track = EV.track_from_fn(actor, float(seconds), int(sample_fps))
    return P.Panel(names=tuple(names)).review(ev)


def review(sc, *, sample_fps: int = SAMPLE_FPS,
           names: Sequence[str] = PRE_CRITICS,
           shots: Optional[list] = None) -> dict[str, P.PanelVerdict]:
    """שיפוט כל (שוט × דמות) של התסריט, מאותן פונקציות שמרנדרות."""
    shots = BR.build_shots(sc) if shots is None else shots
    out: dict[str, P.PanelVerdict] = {}
    for sh in shots:
        for slot, fn in sh.actors.items():
            key = f"{sh.key}:{slot}"
            out[key] = verdict_for(key, sh.secs, fn,
                                   sample_fps=sample_fps, names=names)
    return out


def worst_of(verdicts: dict[str, P.PanelVerdict]) -> tuple[str, P.PanelVerdict]:
    """הזוג (מפתח, פסק) בעל הציון המינימלי.

    מינימום ולא ממוצע: ממוצע על 48 שיפוטים מסתיר דמות אחת
    קטסטרופלית, וזו בדיוק ההחלטה שכבר נרשמה ב-``panel._gate``.
    המפתח נכנס למפתח המיון כדי שתיקו יוכרע דטרמיניסטית.
    """
    key = min(verdicts, key=lambda k: (verdicts[k].worst, k))
    return key, verdicts[key]


def as_diagnosis(pv: P.PanelVerdict) -> MI.Diagnosis:
    """פסק פאנל → ``mission.Diagnosis``, בשביל מנוע התיקון הקיים.

    המנוע קורא ``dim`` ו-``failed_checks``; שאר השדות ממולאים
    מהפסק עצמו כדי שהדוח יהיה קריא ולא כדי לרצות חתימה.
    """
    dim = pv.weakest
    return MI.Diagnosis(
        dim=dim, label=C.HE.get(dim, dim), value=pv.weakest_score,
        threshold=P.PASS_FLOOR,
        gap=round(P.PASS_FLOOR - pv.weakest_score, 1),
        priority="critical" if pv.weakest_score < P.HARD_FLOOR else "high",
        critical=pv.weakest_score < P.HARD_FLOOR,
        subsystems=list(MI.OWNER.get(dim, ())),
        failed_checks=[d["code"] for d in pv.diagnosis],
        repairs=list(pv.repairs), why=pv.gate)


# ====================================================== לולאת התיקון

@dataclass
class Round:
    """סבב אחד של מדוד → אבחן → תקן."""

    n: int
    worst_key: str = ""
    worst: float = 0.0
    mean: float = 0.0
    weakest: str = ""
    gate: str = ""
    n_fail: int = 0
    n_judged: int = 0
    failed: list[str] = field(default_factory=list)
    repairs: list[str] = field(default_factory=list)
    manual: list[str] = field(default_factory=list)
    note: str = ""
    passed: bool = False
    stop: str = ""
    secs: float = 0.0

    def text(self) -> str:
        head = (f"  סבב {self.n}: מינימום {self.worst:.1f} "
                f"({self.worst_key or '—'}) · {self.n_fail}/{self.n_judged} "
                f"נפלו · {self.secs:.1f}ש")
        L = [head]
        if not self.passed:
            L.append(f"      שער: {self.gate}")
        if self.failed:
            L.append(f"      נפל: {', '.join(self.failed[:4])}")
        if self.repairs:
            L.append(f"      תוקן: {', '.join(self.repairs)}")
        if self.manual:
            L.append(f"      דרוש אדם: {'; '.join(self.manual[:3])}")
        if self.stop:
            L.append(f"      עצירה: {self.stop}")
        return "\n".join(L)


def autocorrect(sc, *, rounds: int = MAX_ROUNDS, engine=None,
                sample_fps: int = SAMPLE_FPS,
                names: Sequence[str] = PRE_CRITICS,
                measure: Optional[Callable] = None,
                tune=None, restore_best: bool = True,
                log: Optional[Callable] = None) -> list[Round]:
    """מודד, מאבחן, מתקן, ומודד שוב — עד שהשער נסגר או שאין מה לעשות.

    שלוש יציאות, וכל אחת מהן מדווחת בשם מלא: השער נסגר, אין תיקון
    מחובר לכשל, או קיפאון. תקרת הסבבים היא רשת ביטחון רביעית ולא
    התנהגות רגילה — לולאה שמגיעה אליה היא לולאה שלא זיהתה קיפאון.

    ``measure(n) -> {מפתח: PanelVerdict}`` מוזרק בבדיקות. בלי
    ההזרקה, בדיקה של *לוגיקת הלולאה* (קיפאון, יציאה בלי ידית,
    תקרה) הייתה תלויה בציון אמיתי של תסריט אמיתי — כלומר הייתה
    משתנה בכל פעם שמישהו נוגע בריג, ונמחקת.
    """
    engine = MI.RepairEngine() if engine is None else engine
    if tune is None:
        from studio import tuning as _T                   # noqa: PLC0415
        tune = _T
    if measure is None:
        def measure(n):                                   # noqa: ARG001
            return review(sc, sample_fps=sample_fps, names=names)
    hist: list[Round] = []
    prev: Optional[float] = None
    #: הכוונון שבתוקף **בזמן המדידה** של כל סבב. זה מה שמאפשר
    #: לחזור אל המצב הטוב ביותר ולא אל המצב האחרון: הצעד השלישי
    #: של ידית יכול להחמיר, ולולאה שנשארת על "הכי רחוק שהגעתי"
    #: מוסרת מערכת פחות טובה מזו שהיא עצמה מדדה.
    snaps: dict[int, dict] = {}

    def close(r: Round, t0: float) -> Round:
        r.secs = round(time.time() - t0, 1)
        hist.append(r)
        if log:
            log(r)
        return r

    for n in range(1, int(rounds) + 1):
        t0 = time.time()
        snaps[n] = dict(tune.all_values())
        vs = measure(n)
        key, pv = worst_of(vs)
        bad = [k for k, v in vs.items() if not v.passed]
        r = Round(n=n, worst_key=key, worst=pv.worst, mean=pv.mean,
                  weakest=pv.weakest, gate=pv.gate, n_fail=len(bad),
                  n_judged=len(vs), passed=not bad,
                  failed=[d["code"] for d in pv.diagnosis])
        if not bad:
            r.stop = "השער נסגר"
            close(r, t0)
            break
        if prev is not None and (pv.worst - prev) < MIN_GAIN:
            r.stop = (f"קיפאון — התיקון הקודם הזיז את המדידה ב-"
                      f"{pv.worst - prev:+.2f} בלבד")
            close(r, t0)
            break
        plan = engine.plan(pv.weakest, [pv.weakest],
                           {"diagnosis": [as_diagnosis(pv)]})
        r.repairs = list(plan.get("repairs") or [])
        r.manual = list(plan.get("manual") or [])
        r.note = str(plan.get("note") or "")
        if not r.repairs:
            r.stop = "אין ידית מחוברת לכשל הזה — דרוש אדם"
            close(r, t0)
            break
        if n >= int(rounds):
            r.stop = "תקרת הסבבים"
        prev = pv.worst
        close(r, t0)

    # **המערכת נשארת במצב הטוב ביותר שנמדד, לא במצב האחרון.**
    # ``nudge`` זז צעד לכיוון אחד, ולכן הידית מגיעה לקצה התחום
    # גם כשהצעד האחרון החמיר. בלי החזרה הזו הלולאה "מתקנת" את
    # המערכת אל מצב שהיא עצמה מדדה כגרוע יותר — וזה כשל גרוע
    # מהיעדר תיקון, כי הוא מוצג כשיפור.
    if restore_best and len(hist) > 1:
        best = max(hist, key=lambda r: r.worst)
        if best.n != hist[-1].n:
            want = snaps.get(best.n) or {}
            now = dict(tune.all_values())
            diff = {k: v for k, v in want.items()
                    if abs(float(now.get(k, v)) - float(v)) > 1e-9}
            if diff:
                tune.apply(diff, why="חזרה למצב הטוב ביותר שנמדד")
                hist[-1].note = (
                    (hist[-1].note + " · " if hist[-1].note else "")
                    + f"הוחזר לכוונון של סבב {best.n} "
                      f"(מינימום {best.worst:.1f} מול {hist[-1].worst:.1f}): "
                    + ", ".join(f"{k}={v}" for k, v in sorted(diff.items())))
    return hist


# =========================================================== רינדור

def _render(sc, out: Path, spec: PassSpec,
            on_progress: Optional[Callable] = None) -> dict:
    """ברירת המחדל של שלב הרינדור. מוחלף בבדיקות."""
    return asyncio.run(BR.produce(sc, Path(out), fps=(spec.fps or None),
                                  width=spec.width, height=spec.height,
                                  ss=spec.ss, on_progress=on_progress))


def _inspect(path: Path, expect_sec: Optional[float],
             strict_edges: bool = True):
    """ברירת המחדל של שלב הבדיקה הטכנית. מוחלף בבדיקות."""
    return QA.inspect(Path(path), expect_sec=expect_sec,
                      strict_edges=strict_edges)


# ========================================================== האספקה

@dataclass
class Delivery:
    """תוצאת השרשרת. ``delivered`` הוא המצב היחיד שנחשב הצלחה."""

    script: str = ""
    delivered: bool = False
    reason: str = ""
    stage: str = ""                  #: באיזה שלב נעצר
    #: האם שער האיכות שלפני הרינדור נסגר. **אינו** זהה ל-
    #: ``delivered``: קובץ יכול לעבור את הבדיקה הטכנית (אינו ריק,
    #: אינו קפוא, באורך הנכון) ובכל זאת לא לעמוד בתקן ההפקה.
    quality_gate: bool = False
    gate_bypassed: bool = False      #: נמסר בדילוג מוצהר על השער
    gates: dict = field(default_factory=dict)
    rounds: list = field(default_factory=list)
    draft: dict = field(default_factory=dict)
    final: dict = field(default_factory=dict)
    mp4: str = ""
    seconds: float = 0.0
    total_secs: float = 0.0
    report: str = ""

    def to_dict(self) -> dict:
        return asdict(self)

    def text(self) -> str:
        mark = "✓ נמסר" if self.delivered else "✗ לא נמסר"
        if self.delivered and self.gate_bypassed:
            mark = "⚠ נמסר בדילוג מוצהר על שער האיכות"
        head = (f"{mark}  {self.script}  ·  שלב {self.stage}  ·  "
                f"תקן הפקה {'✓' if self.quality_gate else '✗'}  ·  "
                f"{self.total_secs:.1f}ש")
        L = [head]
        for r in self.rounds:
            L.append(Round(**r).text() if isinstance(r, dict) else r.text())
        for tag, d in (("טיוטה", self.draft), ("סופי", self.final)):
            if not d:
                continue
            q = d.get("qa") or {}
            L.append(f"  {tag}: {d.get('spec', '')} · "
                     f"רינדור {d.get('render_sec', 0)}ש · "
                     f"{d.get('size_mb', 0)}MB · בדיקה טכנית "
                     f"{'✓' if q.get('passed') else '✗'} "
                     f"{q.get('score', 0)}/100")
            for c in (q.get("checks") or []):
                if not c.get("passed"):
                    L.append(f"      ✗ {c.get('name')}: {c.get('detail')}")
        if self.reason:
            L.append(f"  סיבה: {self.reason}")
        if self.mp4:
            L.append(f"  {self.mp4}")
        return "\n".join(L)


def _pass_entry(spec: PassSpec, rep: dict, q) -> dict:
    return {
        "spec": f"{spec.width}x{spec.height} {spec.fps}fps ss={spec.ss}",
        "mp4": rep.get("mp4") or "",
        "render_sec": rep.get("render_sec") or 0,
        "size_mb": rep.get("size_mb") or 0,
        "frames": rep.get("frames") or 0,
        "qa": (q.to_dict() if q is not None and hasattr(q, "to_dict")
               else (q or {})),
    }


def _qa_reason(tag: str, q) -> str:
    names = ", ".join(c["name"] for c in q.failures) or "—"
    who = ", ".join(q.blames) or "—"
    return f"{tag} נפל בבדיקה הטכנית: {names} → אחראי: {who}"


def deliver(script, *, rounds: int = MAX_ROUNDS, engine=None,
            draft_spec: PassSpec = DRAFT, final_spec: PassSpec = FINAL,
            render: Optional[Callable] = None,
            inspect: Optional[Callable] = None,
            out: Optional[Path] = None, sample_fps: int = SAMPLE_FPS,
            names: Sequence[str] = PRE_CRITICS, skip_draft: bool = False,
            review_only: bool = False, save: bool = True,
            pre_gate: bool = True,
            measure: Optional[Callable] = None,
            log: Optional[Callable] = None) -> Delivery:
    """השרשרת כולה: תסריט → MP4 מאושר, או סירוב עם סיבה בשם מלא.

    ``render``/``inspect`` מוזרקים כדי שהשרשרת עצמה תהיה ניתנת
    לבדיקה בשניות. בלי ההזרקה הזו כל בדיקה של *סדר השלבים* הייתה
    דורשת 26 דקות דפדפן, כלומר לא הייתה נכתבת.
    """
    t0 = time.time()
    render = _render if render is None else render
    inspect = _inspect if inspect is None else inspect
    say = log or (lambda *_a, **_k: None)

    # **הפרת חוזה בטעינה היא סירוב, לא קריסה.** ``bridge.load``
    # זורק ``ValueError`` על שוט שאינו כפולה שלמה של פריים, על
    # דמות שאינה בהרכב ועוד — וזה נכון, הוא נתפס בטעינה ולא
    # בפריים 2000. אבל שרשרת אוטונומית שמתה עם traceback אינה
    # שרשרת: היא צריכה לומר *מה* נפל, ובעברית.
    try:
        sc = script if hasattr(script, "shots") else BR.load(script)
    except Exception as exc:                              # noqa: BLE001
        d = Delivery(script=str(script), stage="טעינה")
        d.total_secs = round(time.time() - t0, 1)
        d.reason = f"התסריט לא נטען: {exc}"
        return d

    d = Delivery(script=getattr(sc, "name", str(script)),
                 seconds=float(getattr(sc, "total", 0.0)), stage="חוזה")

    def finish(reason: str = "") -> Delivery:
        d.reason = reason or d.reason
        d.total_secs = round(time.time() - t0, 1)
        if save:
            REPORTS.mkdir(parents=True, exist_ok=True)
            p = REPORTS / f"{d.script}.json"
            p.write_text(json.dumps(d.to_dict(), ensure_ascii=False,
                                    indent=1, default=str),
                         encoding="utf-8")
            d.report = str(p)
        return d

    # 1 · חוזה התסריט — אפס זמן, ולכן ראשון.
    g = BR.audit(sc)
    d.gates = {k: bool(v["pass"]) for k, v in g.items()}
    bad = [k for k, v in g.items() if not v["pass"]]
    if bad:
        return finish("חוזה התסריט לא נסגר: " + ", ".join(bad))
    off = loop_misfits(float(sc.total))
    if off:
        return finish("אורך התסריט אינו מתחלק במחזורי הסביבה הצרובה: "
                      + ", ".join(off)
                      + " — התפר לא ייסגר וזה ייראה כפריים שאבד")
    say(f"חוזה התסריט נסגר ({len(g)} שערים + מחזורי הסביבה)")

    # 2 · שער האיכות ממסלול הפוזות — שניות, בלי דפדפן.
    d.stage = "מדידה ותיקון"
    hist = autocorrect(sc, rounds=rounds, engine=engine,
                       sample_fps=sample_fps, names=names,
                       measure=measure, log=log)
    d.rounds = [asdict(r) for r in hist]
    if not hist:
        return finish("לא בוצעה אף מדידה")
    d.quality_gate = bool(hist[-1].passed)
    if not hist[-1].passed:
        why = ("שער האיכות לפני הרינדור לא נסגר: " + hist[-1].gate
               + (f" · {hist[-1].stop}" if hist[-1].stop else ""))
        if pre_gate:
            return finish(why)
        # **דילוג מוצהר, ולא שער שהורד.** הורדת סף היא ההתחזות
        # שהפרויקט אוסר במפורש; דילוג מתועד הוא החלטת מפעיל,
        # והוא נרשם בדוח, בטקסט ובשם הקובץ. ``delivered`` כאן
        # אומר "עבר את הבדיקה הטכנית", ו-``quality_gate=False``
        # אומר שזה **אינו** תקן ההפקה.
        d.gate_bypassed = True
        d.reason = why
        say("דילוג מוצהר על שער האיכות — " + hist[-1].gate)
    if review_only:
        d.stage = "מדידה בלבד"
        d.delivered = False
        return finish("מדידה בלבד — לא התבקש רינדור")

    # 3 · טיוטה זולה. שלב שנפל כאן חוסך את הרינדור הסופי.
    if not skip_draft:
        d.stage = "טיוטה"
        spec = draft_spec.resolved(sc)
        dp = BR.OUT_DIR / f"{d.script}_draft.mp4"
        BR.OUT_DIR.mkdir(parents=True, exist_ok=True)
        say(f"טיוטה {spec.width}x{spec.height} {spec.fps}fps")
        rep = render(sc, dp, spec) or {}
        if not rep.get("mp4"):
            d.draft = _pass_entry(spec, rep, None)
            return finish("הטיוטה לא הופקה כלל — אין קובץ")
        q = inspect(Path(rep["mp4"]), sc.total, spec.strict_edges)
        d.draft = _pass_entry(spec, rep, q)
        if not q.passed:
            return finish(_qa_reason("הטיוטה", q))
        say(f"הטיוטה עברה ({q.score:.0f}/100)")

    # 4 · רינדור סופי, ובדיקה שלו. רק שניהם יחד הם אספקה.
    d.stage = "סופי"
    spec = final_spec.resolved(sc)
    fp = Path(out) if out else (BR.OUT_DIR / f"{d.script}.mp4")
    BR.OUT_DIR.mkdir(parents=True, exist_ok=True)
    say(f"רינדור סופי {spec.width}x{spec.height} {spec.fps}fps")
    rep = render(sc, fp, spec) or {}
    if not rep.get("mp4"):
        d.final = _pass_entry(spec, rep, None)
        return finish("הרינדור הסופי לא הפיק קובץ")
    q = inspect(Path(rep["mp4"]), sc.total, spec.strict_edges)
    d.final = _pass_entry(spec, rep, q)
    if not q.passed:
        return finish(_qa_reason("הסרטון הסופי", q))
    d.delivered = True
    d.mp4 = str(rep["mp4"])
    return finish("")


# ======================================= אצווה כבדה ברקע בענן

#: הידית שנסרקת כברירת מחדל, והערכים. ``smooth_win`` ולא אחרת:
#: היא **הידית היחידה שמחוברת למנוע התנועה עצמו** (נכנסה ל-
#: ``bridge.build_shots``), ולכן סריקה שלה משנה פריימים בפועל.
#: סריקה של ידית שאינה מחוברת הייתה מחזירה שש פעמים את אותו ציון.
CLOUD_KNOB = "smooth_win"
CLOUD_VALUES: tuple[float, ...] = (0.08, 0.12, 0.16, 0.20, 0.24, 0.28)


def _local_measure(job: dict) -> dict:
    """אותה עבודה בדיוק, כאן. החתימה והפלט זהים לעובד שבענן.

    ``batch_worker.measure_job`` הוא המקור היחיד, ולכן נפילה
    לעבודה מקומית אינה גרסה שנייה של אותה מדידה - מצב שבו הענן
    והבית מחזירים ציונים שונים לאותה ידית הוא באג שאי אפשר לאבחן.
    """
    from showreel import batch_worker as BW                # noqa: PLC0415
    return BW.measure_job(job)


def cloud_sweep(script_name: str, *, knob: str = CLOUD_KNOB,
                values: Sequence[float] = CLOUD_VALUES, api=None,
                allow_local: bool = True, submit_new: bool = True,
                log: Optional[Callable] = None) -> dict:
    """סורקת ידית אחת על רנרי אפל במקביל — ו**חוזרת מיד**.

    זה המקום שבו ענן באמת מרוויח כאן: שש מדידות שלוקחות כאן
    6 × ~70 שניות בזה אחר זה, רצות שם בבת אחת. אבל התור שלהן
    נמדד 12-13 דקות, ולכן זו עבודת **רקע** בלבד: הקריאה מגישה,
    מדווחת, וממשיכה. ``ready=False`` הוא תשובה תקינה ולא כשל —
    קוראים שוב אחר כך (``--cloud-poll``), והכרטיס יושב על הדיסק.

    חלף חלון התור ואין ענן → אותה עבודה נעשית כאן, מאותו קוד.
    """
    from showreel import cloudbatch as CB                  # noqa: PLC0415
    jobs = [{"task": "measure", "script": script_name,
             "tuning": {knob: float(v)}} for v in values]
    res = CB.ensure(jobs, worker=(_local_measure if allow_local else None),
                    api=api, submit_new=submit_new, log=log)
    res["best"] = best_of(res.get("results") or {})
    res["knob"] = knob
    return res


def best_of(results: dict) -> dict:
    """הערך הטוב ביותר בסריקה. המדד הוא ``worst`` ולא ``mean``.

    זו אותה הכרעה של ``worst_of``: ממוצע על 48 שיפוטים מסתיר דמות
    אחת קטסטרופלית, וסריקה שבוחרת לפי ממוצע תבחר בדיוק את הידית
    שמחליקה את הממוצע ומשאירה את הכשל.
    """
    good = {k: v for k, v in (results or {}).items()
            if isinstance(v, dict) and "error" not in v
            and v.get("worst") is not None}
    if not good:
        return {}
    k = max(good, key=lambda x: (good[x]["worst"], x))
    v = good[k]
    return {"key": k, "tuning": v.get("tuning") or {},
            "worst": v.get("worst"), "mean": v.get("mean"),
            "worst_key": v.get("worst_key"), "n": len(good)}


def cloud_text(res: dict) -> str:
    k = res.get("ticket")
    L = []
    if k is not None:
        L.append(k.text())
    if not res.get("ready"):
        L.append("  האצווה בענן ברקע. העבודה כאן לא ממתינה לה.")
        return "\n".join(L)
    L.append(f"  מוכן · מקור: {res.get('source') or '—'} · "
             f"{len(res.get('results') or {})} תוצאות")
    b = res.get("best") or {}
    if b:
        L.append(f"  הטוב ביותר: {b.get('tuning')} → "
                 f"החלש ביותר {b.get('worst')} "
                 f"({b.get('worst_key')}) · ממוצע {b.get('mean')}")
    for kk, v in sorted((res.get("results") or {}).items()):
        if isinstance(v, dict) and v.get("error"):
            L.append(f"    ✗ {kk}: {v['error'][:90]}")
    return "\n".join(L)


# ============================================================== CLI

def main(argv=None) -> int:
    import argparse                                       # noqa: PLC0415
    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(
        description="שרשרת האספקה האוטונומית: תסריט -> MP4 מאושר")
    ap.add_argument("script", nargs="?", default=None)
    ap.add_argument("--list", action="store_true",
                    help="אילו תסריטים נטענים")
    ap.add_argument("--review", action="store_true",
                    help="רק המדידה הזולה, בלי רינדור")
    ap.add_argument("--no-draft", action="store_true",
                    help="לדלג על שלב הטיוטה")
    ap.add_argument("--no-gate", action="store_true",
                    help="לרנדר גם אם שער האיכות לא נסגר (מתועד בדוח)")
    ap.add_argument("--rounds", type=int, default=MAX_ROUNDS)
    ap.add_argument("--sample-fps", type=int, default=SAMPLE_FPS)
    ap.add_argument("--out", default="")
    ap.add_argument("--cloud-sweep", action="store_true",
                    help="סריקת ידית על רנרי אפל ברקע (לא חוסם)")
    ap.add_argument("--cloud-poll", action="store_true",
                    help="מעבר אחד על כרטיסי האצווה הפתוחים")
    ap.add_argument("--cloud-knob", default=CLOUD_KNOB)
    ap.add_argument("--cloud-values",
                    default=",".join(str(v) for v in CLOUD_VALUES))
    ap.add_argument("--cloud-local", action="store_true",
                    help="מותר ליפול למדידה מקומית אם התור ארוך")
    a = ap.parse_args(argv)

    if a.cloud_poll:
        from showreel import cloudbatch as CB              # noqa: PLC0415
        open_ = [k for k in CB.tickets() if k.open]
        if not open_:
            print("אין כרטיס אצווה פתוח")
            return 0
        for k in open_:
            print(CB.poll(k, log=lambda x: print(x, flush=True)).text())
        return 0

    if a.cloud_sweep:
        if not a.script:
            print("צריך שם תסריט לסריקה")
            return 2
        vals = [float(x) for x in a.cloud_values.split(",") if x.strip()]
        res = cloud_sweep(a.script, knob=a.cloud_knob, values=vals,
                          allow_local=a.cloud_local,
                          log=lambda x: print(x, flush=True))
        print(cloud_text(res))
        return 0

    if a.list or not a.script:
        for line in BR.discover():
            print("  " + line)
        return 0

    def log(x):
        print(x.text() if isinstance(x, Round) else f"  · {x}", flush=True)

    d = deliver(a.script, rounds=a.rounds, sample_fps=a.sample_fps,
                skip_draft=a.no_draft, review_only=a.review,
                pre_gate=not a.no_gate,
                out=(Path(a.out) if a.out else None), log=log)
    print()
    print(d.text())
    if d.report:
        print(f"  דוח: {d.report}")
    return 0 if (d.delivered or a.review) else 1


if __name__ == "__main__":
    raise SystemExit(main())
