# -*- coding: utf-8 -*-
"""TASK 24 (07/10) - הגשר הדינמי: תסריט כלשהו -> וידאו, בלי קוד חדש.

================================================================
מה היה חסר, ולמה דווקא כאן
================================================================

עד כאן כל תסריט חדש דרש **גשר ידני** משלו. `disney_story` הוא
מפיק שמקובע ל-4 דמויות ו-60 שניות, ו-`park90_render` נכתב
(TASK 23) כחוליה שלישית שמחברת את חוזה `park90` - 8 דמויות,
90 שניות - אל אותה במה. שני הגשרים האלה עושים את **אותם** שבעה
דברים: ממפים מקומות לדמויות, בונים שוטים, מחשבים מצלמה שמכסה
את הפרישה, מתקנים את ה-HTML, מגישים את הקבצים, מריצים את לולאת
הפריימים ומקודדים.

המשמעות המעשית: תסריט של 10 דמויות ו-120 שניות היה "רק מפרט"
עד שמישהו היה כותב לו גשר שלישי. זה הקובץ שמבטל את הצורך.

================================================================
ההכרעה: חוזה קשיח, גלוי אוטומטית
================================================================

שלוש דעות חיצוניות שנשאלו בנפרד (07/10 - GPT-4, Qwen 3.8,
Command A) החזירו את אותה אזהרה: **גילוי לפי ניחוש שמות נשבר**.
הן המליצו לדרוש `SPEC` מילוני אחד עם סכימה.

מה שאומץ מזה, ומה שלא: הנרמול כאן הוא **קשיח** בדיוק כפי
שהמליצו - כל תסריט מתורגם לאובייקט `Script` אחד, והפרת חוזה
(סכום שוטים שאינו שווה לאורך, תוכנית הליכה שאינה מכסה את השוט,
דמות שאינה קיימת ב-`rig.pipeline.CAST`) היא `ValueError` **בטעינה**
ולא תקלה בפריים 2000. אבל הדרישה ל-`SPEC` נדחתה: שני התסריטים
הקיימים אינם מכילים כזה, ודרישה כזו הייתה הופכת את שניהם
לבלתי-טעינים - כלומר "גנרי" שעובד על אפס תסריטים. לכן מקור
הנתונים הוא **או** `SPEC` מפורש **או** גילוי של תכונות המודול,
והנרמול שאחריו זהה לשניהם. `Script.source` מתעד מאיפה הגיע כל
שדה, כך שגילוי שגוי נראה בדוח ולא מתגלה במסך.

================================================================
מה נגזר לבד, וזה העיקר
================================================================

תסריט חייב להצהיר שני דברים בלבד: **רשימת דמויות** (`CAST`, או
כל שם מהצורה `CAST8`) ו-**`SHOTS`**. כל השאר נגזר:

* `SLOTS` - אותיות לפי מספר הדמויות (A..Z ואז A1..).
* `TOTAL_SECONDS` - סכום השוטים, אם לא הוצהר.
* `LANE_X` / `LANE_YAW` - פרישה סימטרית במרווח קבוע.
* `SEEDS` / `PHASE` - **רצף יחס הזהב** (ראה `spread_unit`). זו
  ההמלצה היחידה משלוש הדעות שאומצה כפי שהיא, והיא הנכונה: n
  דמויות עם אותו זרע הן n בבואות של אותה אנימציה, והמידה שקובעת
  אם הן נראות שונות היא **המרווח המינימלי** בין הזרעים - לא
  המרווח הממוצע. רצף יחס הזהב הוא זה שממקסם אותו לכל n, ולכן
  10 דמויות נפרדות היטב בלי שאף אחד יכתוב להן טבלה.
* `crane_at` - עליית קרן על חלון השוט האחרון, אם התסריט לא הגדיר.
* מצב הדמות בשוט - נגזר משם הפעימה (`beat`), אם אין פונקציה.

================================================================
שלוש מלכודות שכל אחת הייתה באג
================================================================

1. **`_sit` של תסריט אחד אינו `_sit` של השני.** ב-`park90_render`
   החתימה היא `(slot, beat, shot_len)` וב-`disney_story` היא
   `(slot, line, shot_len, key)`. גילוי לפי שם בלבד היה קורא
   לפונקציה עם מספר ארגומנטים שגוי, או גרוע מזה - עם `beat`
   במקום `line`. לכן הפונקציה נבדקת ב-`inspect.signature`
   ונדחית אם היא אינה בת שלושה ארגומנטים.

2. **הנתיב משתנה בזמן, והבמה הכירה נתיב קבוע.** `LANE_PATCH`
   עבר לכאן מ-`park90_render` **כמקור אחד**: שתי החלפות של אותה
   שורה ב-`stage.html` היו שתי במות שונות שמתפצלות בשקט.

3. **אין "ברירת מחדל" לדמות שלא נבנתה.** שם שאינו ב-
   `rig.pipeline.CAST` נתפס בטעינה, כי `cast_skeleton` היה
   מפיל `KeyError` רק אחרי שהסביבה כבר נאפתה - 40 שניות עבודה
   על שגיאה שנראית בשורה הראשונה.
"""
from __future__ import annotations

import asyncio
import importlib
import inspect
import json
import math
import re
import shutil
import sys
import tempfile
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
STUDIO = HERE.parent
if str(STUDIO) not in sys.path:
    sys.path.insert(0, str(STUDIO))

from rig import cast_disney as CD                        # noqa: E402
from rig import controls, secondary                      # noqa: E402
from rig import locomotion as LM                         # noqa: E402
from rig import pipeline as PL                           # noqa: E402
from rig import showreel as SR                           # noqa: E402
from rig import voice as V                               # noqa: E402
from showreel import disney_story as DS                  # noqa: E402
from stage import park_disney as PD                      # noqa: E402
from studio import tuning as TU                          # noqa: E402

#: ברירות מחדל שאינן תלויות בתסריט.
DEF_FPS = 30
DEF_SPACING = 0.46          #: מרווח נתיבים כשהתסריט לא הצהיר
DEF_PAN = 0.030             #: סקאלת הפאן של הרקע
ENV_ROOT = Path(r"D:\claude-bot\out\char3d\env")
OUT_DIR = Path(r"D:\claude-bot\out\char3d\showreel")

#: חלון גלגול האופניים כשאין בעלילה אופניים נמלטות: **מחוץ
#: לרצף**, כך שהן נשארות הציור הצרוב של האופניים החונות.
BIKE_PARKED = (1.0e6, 1.0e6 + 1.0)

#: חלון האופניים שחוזה **הסביבה** נבדק מולו. זה אינו חלון
#: העלילה: `park_disney.validate` מודד את התמונה הצרובה, והיא
#: אותה תמונה לכל התסריטים שמתרחשים בפארק הזה.
_ENV_BIKE = DS.BIKE_ROLL

#: יחס הזהב. ראה `spread_unit`.
PHI = 0.6180339887498949


# ============================================= כלים גנריים קטנים

def letters(n: int) -> tuple[str, ...]:
    """שמות המקומות: A..Z, ואז A1..Z1 - כך שגם 30 דמויות עובדות."""
    out = []
    for i in range(n):
        c = chr(ord("A") + i % 26)
        out.append(c if i < 26 else f"{c}{i // 26}")
    return tuple(out)


def _coprime(n: int, target: int, avoid: tuple = ()) -> int:
    """הצעד הזר ל-n הקרוב ביותר ל-`target`."""
    for d in range(0, max(2, n)):
        for k in (target + d, target - d):
            if 1 <= k < max(2, n) and math.gcd(k, n) == 1 \
                    and k not in avoid:
                return k
    return 1


def spread_unit(n: int, start: float = 0.0, conj: int = 1) -> list[float]:
    """n ערכים ב-[0,1) **במרווח מינימלי מרבי**, ובסדר לא-מחזורי.

    שתי דרישות מתנגשות כאן, וזו הסיבה שזו פונקציה ולא שורה:

    * **מרווח.** המידה שקובעת אם n דמויות נראות שונות זו מזו היא
      המרווח ה**מינימלי** בין הזרעים, לא הממוצע. הקבוצה שממקסמת
      אותו היא הסריג השווה `j/n` בדיוק - כל דבר אחר (יחס הזהב,
      `random`) נותן מרווח מינימלי קטן יותר. נמדד כאן: רצף יחס
      הזהב הגיע ל-0.47 בלבד מהמרווח האידאלי ב-22 דמויות, ובסריג
      זה 1.00 לכל n.
    * **סדר.** אבל *הקצאה* של הסריג לפי סדר המקומות (A=0, B=1/n,
      C=2/n...) מייצרת "גל מקסיקני": הפאזות של שכנים על השביל
      עולות בהדרגה, וזה נראה מכוון. לכן הסריג מוקצה בצעד `k`
      שהוא **זר ל-n וקרוב ל-n·φ** - כלומר שני נתיבים שכנים
      מקבלים ערכים רחוקים זה מזה (0.3-0.4 במרחק מעגלי), והקבוצה
      כולה עדיין מכסה את הסריג כולו בדיוק פעם אחת.

    `conj` בוחר ערוץ: 1 לזרעים ו-2 לפאזות. שני ערוצים באותו צעד
    היו תלויים לגמרי זה בזה (פאזה = זרע + קבוע), וכל דמות הייתה
    מקבלת את אותו **זוג** - כלומר שני ערוצים בעלות אחד.
    """
    k1 = _coprime(n, round(n * PHI))
    k = k1 if conj == 1 else _coprime(n, round(n * PHI * PHI), (k1,))
    return [round((start + ((i * k) % n) / n) % 1.0, 4) for i in range(n)]


def min_gap(vals) -> float:
    """המרווח המינימלי ברצף מעגלי - המידה שקובעת אם n דמויות
    נראות שונות זו מזו."""
    s = sorted(float(v) for v in vals)
    if len(s) < 2:
        return 1.0
    gaps = [b - a for a, b in zip(s, s[1:])] + [1.0 - s[-1] + s[0]]
    return min(gaps)


def _is_pair_seq(v) -> bool:
    return (isinstance(v, (list, tuple)) and len(v) == 2
            and all(isinstance(x, (int, float)) for x in v))


# =========================================== ההחלפה של הנתיב בבמה

#: ההחלפה שמוסיפה ל-`stage.html` **נתיב מוחלט שמשתנה בזמן**.
#:
#: ב-`stage.html` המקום הבסיסי נקבע פעם אחת ב-`place()`, וה-`mv`
#: מוסיף לו היסט **בצירי הדמות**. אבל נתיב שמשתנה בזמן (התפצלות
#: לתת-קבוצות, התכנסות אל המרכז) הוא ציר **העולם**, ודחיפתו לתוך
#: `ox` הייתה מסובבת אותו ב-yaw של הדמות - כלומר קבוצה שנסוגה
#: "שמאלה" הייתה נסוגה גם לאחור. זה היה באג מלא ב-TASK 23.
LANE_PATCH = (
    "      const wx = g.x + (m.ox || 0) * c + (m.oz || 0) * s;",
    "      /* TASK 23: `lx` הוא הנתיב **המוחלט** בזמן הפריים\n"
    "         (`park90.lane_at`), והוא מחליף את המקום הבסיסי ולא\n"
    "         מתווסף אליו. דחיפתו לתוך `ox` הייתה מסובבת אותו\n"
    "         ב-yaw של הדמות, כלומר נסיגה הצידה הייתה גם נסיגה\n"
    "         לאחור. */\n"
    "      const bx = (m.lx === undefined ? g.x : m.lx);\n"
    "      const wx = bx + (m.ox || 0) * c + (m.oz || 0) * s;")

#: TASK 25: הזווית בזמן. `g.yaw` נקבע פעם אחת ב-`place()` מתוך
#: שאילתת הכתובת, ולכן דמות שנעה הצידה המשיכה להביט קדימה -
#: בדיוק הפגם ש-`park90_render.pet_frame` תיקן לחיה הרובוטית
#: ולא לדמויות. `m.ry` (מעלות, מוחלט) מחליף אותו **וגם מסובב
#: את הקבוצה בפועל**: עדכון c/s לבדו היה מזיז את ההיסט בלי
#: לסובב את הגוף, כלומר דמות שצועדת הצידה ופניה קדימה.
YAW_PATCH = (
    "      const c = Math.cos(g.yaw), s = Math.sin(g.yaw);",
    "      const yw = (m.ry === undefined ? g.yaw\n"
    "                  : m.ry * Math.PI / 180);\n"
    "      if (m.ry !== undefined) g.group.rotation.y = yw;\n"
    "      const c = Math.cos(yw), s = Math.sin(yw);")


# ======================================================= החוזה המנורמל

class Script:
    """תסריט מנורמל: כל מה שהמפיק צריך, בשמות אחידים.

    זה **לא** עותק של מודול התסריט - זה התרגום שלו. כל שדה כאן
    מגיע או מהצהרה מפורשת או מגזירה, ו-`source` אומר ממה. שדה
    שנגזר ונראה שגוי נתפס בדוח של `audit`, לא במסך.
    """

    def __init__(self, name: str, mod, companion=None, spec: dict | None = None):
        self.name = name
        self.mod = mod
        self.companion = companion
        self.spec = dict(spec or {})
        self.source: dict[str, str] = {}
        self._norm()

    # ------------------------------------------------ גילוי ונרמול

    def _find(self, key: str, *attrs: str, default=None, src: str = "נגזר"):
        """מחפש שדה: `SPEC` -> מודול התסריט -> מודול הגשר הצמוד."""
        if key in self.spec:
            self.source[key] = f"SPEC[{key!r}]"
            return self.spec[key]
        for a in attrs:
            for m, tag in ((self.mod, "התסריט"),
                           (self.companion, "הגשר הצמוד")):
                if m is not None and hasattr(m, a):
                    v = getattr(m, a)
                    if v is not None:
                        self.source[key] = f"{tag}.{a}"
                        return v
        self.source[key] = src
        return default

    def _norm(self) -> None:
        # --- הדמויות. זה השדה היחיד שאין לו ברירת מחדל סבירה.
        cast = self._find("cast", "CAST")
        if not cast:
            for a in sorted((a for a in dir(self.mod)
                             if re.fullmatch(r"CAST\d+", a)),
                            key=lambda s: -int(s[4:])):
                v = getattr(self.mod, a)
                if isinstance(v, (list, tuple)) and v:
                    cast, _ = v, self.source.update({"cast": f"התסריט.{a}"})
                    break
        if not cast or not all(isinstance(x, str) for x in cast):
            raise ValueError(
                f"התסריט {self.name!r} אינו מצהיר רשימת דמויות "
                "(CAST, או כל שם מהצורה CAST8).")
        self.cast = tuple(cast)
        missing = [n for n in self.cast if n not in PL.CAST]
        if missing:
            # מלכודת 3: בלי זה השגיאה הייתה מגיעה אחרי אפיית
            # הסביבה, כלומר 40 שניות אחרי שהיא נראית.
            raise ValueError(
                f"התסריט {self.name!r} מליהק דמויות שאינן ב-"
                f"rig.pipeline.CAST: {missing}")

        # --- המקומות
        slots = self._find("slots", "SLOTS")
        if not slots or len(slots) != len(self.cast):
            slots = letters(len(self.cast))
            self.source["slots"] = "נגזר מאותיות"
        self.slots = tuple(slots)

        self.fps = int(self._find("fps", "FPS", default=DEF_FPS))
        self.leads = tuple(self._find(
            "leads", "LEADS",
            default=(getattr(self.mod, "LEAD_M", self.slots[0]),
                     getattr(self.mod, "LEAD_F",
                             self.slots[min(1, len(self.slots) - 1)]))))

        # --- הנתיבים
        lx = self._find("lane_x", "LANE_X")
        if not (isinstance(lx, dict) and all(k in lx for k in self.slots)):
            n = len(self.slots)
            w = (n - 1) * DEF_SPACING
            lx = {k: round(-w / 2 + i * DEF_SPACING, 4)
                  for i, k in enumerate(self.slots)}
            self.source["lane_x"] = "נגזר (פרישה סימטרית)"
        self.lane_x = {k: float(lx[k]) for k in self.slots}
        yw = self._find("lane_yaw", "LANE_YAW")
        if not (isinstance(yw, dict) and all(k in yw for k in self.slots)):
            # סיבוב מתחלף ולא קבוע: n דמויות שכולן פונות לאותו
            # כיוון הן שורה, לא קבוצה.
            yw = {k: round((8.0 + 9.0 * ((i * PHI) % 1.0))
                           * (1 if i % 2 == 0 else -1), 1)
                  for i, k in enumerate(self.slots)}
            self.source["lane_yaw"] = "נגזר (מתחלף)"
        self.lane_yaw = {k: float(yw[k]) for k in self.slots}

        # --- השוטים
        raw = self._find("shots", "SHOTS")
        if not raw:
            raise ValueError(f"התסריט {self.name!r} אינו מצהיר SHOTS.")
        self.shots = [self._shot(i, dict(s)) for i, s in enumerate(raw)]
        tot = sum(s["secs"] for s in self.shots)
        declared = self._find("total_seconds", "TOTAL_SECONDS")
        if declared is None:
            self.total = round(tot, 6)
            self.source["total_seconds"] = "נגזר מסכום השוטים"
        else:
            self.total = float(declared)
            if abs(self.total - tot) > 1e-6:
                raise ValueError(
                    f"{self.name}: סכום השוטים {tot:.3f} אינו אורך "
                    f"הרצף שהוצהר {self.total:.3f}.")

        # --- זרעים ופאזות
        self.seeds = self._unit("seeds", "SEEDS", 0.17, conj=1)
        self.phase = self._unit("phase", "PHASE", 0.0, conj=2)

        # --- סביבה ועיטורים
        self.env_dir = Path(self._find("env_dir", "ENV_DIR",
                                       default=ENV_ROOT / self.name))
        self.location = self._find("location", "LOCATION")
        self.pan_scale = float(self._find("pan_scale", "PAN_SCALE",
                                          default=DEF_PAN))
        self.tree_pass = float(self._find("tree_pass", "TREE_PASS",
                                          default=round(self.total * 0.19, 3)))
        bk = self._find("bike_roll", "BIKE_ROLL", "BIKE_PARKED")
        self.bike_roll = tuple(bk) if _is_pair_seq(bk) else BIKE_PARKED

        # --- מצלמת הקרן
        self._crane = self._find("crane_at", "crane_at")
        cw = self._find("crane_window", "CRANE_WINDOW")
        if not _is_pair_seq(cw):
            cw = next((self.window(s["key"]) for s in reversed(self.shots)
                       if s["camera"] == "crane"), None)
            self.source["crane_window"] = "נגזר מהשוט האחרון"
        self.crane_window = tuple(cw) if cw else (max(0.0, self.total - 16.0),
                                                  self.total)

        # --- מוקד הסיום: הפרישה שהשוט המסיים אמור למסגר
        fs = self._find("focus_span", "FOCUS_SPAN")
        if fs is None:
            d = abs(self.lane_at(self.leads[0], self.total)
                    - self.lane_at(self.leads[1], self.total))
            fs = max(d * 4.2, 2.20)
            self.source["focus_span"] = "נגזר ממרחק הראשיים בסוף"
        self.focus_span = float(fs)

        # --- פונקציית המצב, אם התסריט סיפק אחת תקינה (מלכודת 1)
        hook = self._find("situation", "situation", "_sit")
        self._sit = hook if self._sit_ok(hook) else None
        if hook is not None and self._sit is None:
            self.source["situation"] = "נדחה (חתימה לא מתאימה) · נגזר"

        # --- האובייקטים התלת-ממדיים של התסריט
        self.extra_key = str(self._find("extra_key", "EXTRA_KEY",
                                        default="xtr"))
        self.stage_js = self._find("stage_js", "STAGE_JS")
        self.extra_ready = self._find("extra_ready", "EXTRA_READY_JS")
        self._extra = self._find("frame_extra", "frame_extra")
        self.audit_fn = self._find("story_audit", "audit")

        # --- TASK 25: שלושה הוקים אופציונליים, כולם גנריים
        #
        # `lane_yaw_at` - זווית הדמות **בזמן**. עד כה היא נקבעה
        # פעם אחת בשאילתת הכתובת, ולכן דמות שנעה הצידה המשיכה
        # להביט קדימה - וזה נראה כנגררת. תסריט שאינו מצהיר
        # עליה מקבל את הזווית הקבועה בדיוק כמו קודם.
        #
        # `body_over` - בקרות שגוברות על התנועה. **זה המקום
        # היחיד שבו אפשר**: `locomotion.Move.actor` מעדכן את
        # ערוצי התנועה אחרי ה-`extra` ומנצח אותו (מכוון שם),
        # ולכן תנוחה שמוזרקת כ-`extra` נמחקת בשקט.
        #
        # `voice_of` - פרופיל קול לדמות. ברירת המחדל נשארת
        # `cast_disney.VOICES`, כי ל-60 השניות יש כבר קבצים
        # ממוטמנים עליה.
        self._yaw_at = self._find("lane_yaw_at", "lane_yaw_at")
        self._over = self._find("body_over", "body_over")
        self._voice_of = self._find("voice_of", "voice_of")

    @staticmethod
    def _sit_ok(fn) -> bool:
        """פונקציית מצב מתקבלת רק אם היא `(slot, beat, shot_len)`.

        ראה מלכודת 1: `disney_story._sit` הוא בת ארבעה ארגומנטים
        עם `line` במקום `beat`, וקריאה אליה כאן הייתה מעבירה את
        שם הפעימה כטקסט שהדמות אומרת.
        """
        if not callable(fn):
            return False
        try:
            p = [q for q in inspect.signature(fn).parameters.values()
                 if q.kind in (q.POSITIONAL_ONLY, q.POSITIONAL_OR_KEYWORD)]
        except (TypeError, ValueError):
            return False
        need = [q for q in p if q.default is inspect.Parameter.empty]
        return len(need) <= 3 <= len(p)

    def _shot(self, i: int, s: dict) -> dict:
        key = str(s.get("key") or f"s{i + 1}")
        if "secs" not in s:
            raise ValueError(f"{self.name}/{key}: אין אורך לשוט (secs).")
        secs = float(s["secs"])
        if abs(secs * self.fps - round(secs * self.fps)) > 1e-9:
            raise ValueError(
                f"{self.name}/{key}: {secs} שניות אינן כפולה שלמה של "
                f"פריים ב-{self.fps} fps - החיתוך יפיק פריים שבור.")
        vis = tuple(s.get("vis") or self.slots)
        bad = [k for k in vis if k not in self.slots]
        if bad:
            raise ValueError(f"{self.name}/{key}: מקומות שאינם בהרכב {bad}")
        plan = dict(s.get("plan") or {})
        for k in vis:
            if k not in plan:
                plan[k] = [("walk", secs)]
            got = sum(float(d) for _m, d in plan[k])
            if abs(got - secs) > 1e-6:
                raise ValueError(
                    f"{self.name}/{key}/{k}: תוכנית ההליכה מכסה "
                    f"{got:.3f} שניות מתוך {secs:.3f} - הפער היה "
                    "הופך את הדמות להחליק על הדשא.")
        return {"key": key, "secs": secs, "camera": str(s.get("camera")
                                                        or "wide"),
                "cap": s.get("cap", ""), "vis": vis, "plan": plan,
                "beat": str(s.get("beat") or key),
                "lines": tuple(s.get("lines") or ())}

    def _unit(self, key: str, attr: str, start: float,
              conj: int = 1) -> dict:
        v = self._find(key, attr)
        if (isinstance(v, dict) and all(k in v for k in self.slots)
                and len(set(float(v[k]) for k in self.slots)) == len(self.slots)):
            return {k: float(v[k]) for k in self.slots}
        self.source[key] = "נגזר (סריג בצעד זר)"
        vals = spread_unit(len(self.slots), start, conj)
        return dict(zip(self.slots, vals))

    # ---------------------------------------------------- שאילתות

    def name_of(self, slot: str) -> str:
        return self.cast[self.slots.index(slot)]

    def window(self, key: str) -> tuple[float, float]:
        t = 0.0
        for s in self.shots:
            if s["key"] == key:
                return t, t + s["secs"]
            t += s["secs"]
        raise KeyError(key)

    def lane_at(self, slot: str, t: float) -> float:
        """ה-x של דמות בזמן. תסריט בלי `lane_at` = נתיב קבוע."""
        fn = getattr(self.mod, "lane_at", None)
        if callable(fn):
            return float(fn(slot, t))
        return self.lane_x[slot]

    def yaw_at(self, slot: str, t: float) -> float:
        """זווית הדמות בזמן. תסריט בלי הוק = הזווית הקבועה."""
        if callable(self._yaw_at):
            return float(self._yaw_at(slot, t))
        return self.lane_yaw[slot]

    def body_over(self, slot: str, t: float) -> dict:
        """בקרות שגוברות על התנועה ועל המשחק. {} אם אין."""
        if callable(self._over):
            return dict(self._over(slot, t) or {})
        return {}

    def voice_of(self, slot: str) -> str:
        """פרופיל הקול של דמות. ברירת המחדל: `cast_disney.VOICES`."""
        name = self.name_of(slot)
        if callable(self._voice_of):
            v = self._voice_of(slot)
            if v:
                return str(v)
        return CD.VOICES.get(name, "")

    def span_at(self, t: float) -> float:
        xs = [self.lane_at(k, t) for k in self.slots]
        return max(max(xs) - min(xs), 0.8)

    def crane_at(self, t: float) -> dict:
        """מסלול מצלמת הקרן. ברירת המחדל היא עלייה על חלון השוט
        האחרון - אותם מספרים שנמדדו ב-TASK 22, כי הם מה שמייצר
        עליית קרן שגבוהה מהדמות הגבוהה בכל הרכב שקיים כאן."""
        if callable(self._crane):
            return dict(self._crane(t))
        c0, c1 = self.crane_window
        u = SR.smooth(max(0.0, min(1.0, (t - c0) / max(1e-6, c1 - c0))))
        return {"y": 1.55 + (7.40 - 1.55) * u, "dist": 4.6 + 3.1 * u,
                "pitch": -7.0 - 26.0 * u, "u": u}

    def situation(self, slot: str, beat: str, shot_len: float, line=None):
        """מצב הדמות בשוט. פונקציה של התסריט גוברת; אחרת נגזר
        מ**שם הפעימה**.

        הגזירה היא לפי מילות מפתח ולא לפי טבלה סגורה, כי שם
        פעימה הוא טקסט חופשי שהתסריטאי כותב (`cart_loose`,
        `split_dodge`, `embrace`). פעימה שלא זוהתה מקבלת מצב
        ניטרלי-חיובי - וזה הדבר הנכון: דמות בלי מצב מוגדר
        משחקת "נוכחת", לא "מבוהלת".
        """
        if self._sit is not None:
            return self._sit(slot, beat, shot_len)
        from rig import emotion as E                      # noqa: PLC0415
        lead = slot in self.leads
        b = (beat or "").lower()
        base = dict(shot_len=shot_len, line=(line[3] if line else ""),
                    hides="")

        def hit(*w):
            return any(x in b for x in w)

        if hit("run", "chase", "dodge", "flee", "escape", "danger"):
            return E.Situation(
                knows="משהו מתקרב ואין זמן", wants="להתחמק ולא להתנגש",
                feels="fear", looks_at="object",
                change="הקבוצה נעה", knows_more=lead,
                want_strength=1.0, intensity=1.0 if not lead else 0.92,
                **base)
        if hit("loose", "break", "crash", "alarm", "surprise", "reveal"):
            return E.Situation(
                knows="זה קרה עכשיו" if lead else "משהו קורה",
                wants="להזהיר את כולם" if lead else "להבין מה קרה",
                feels="surprise", looks_at="object",
                change="המצב משתנה", knows_more=lead,
                want_strength=1.0, intensity=0.95 if lead else 0.86, **base)
        if hit("embrace", "hug", "reunion", "final", "end", "kiss"):
            return E.Situation(
                knows="הוא/היא בסדר" if lead else "השניים מתקרבים",
                wants="להגיע אליו" if lead else "לתת להם רגע",
                feels="joy", looks_at="partner",
                change="הם נפגשים", knows_more=lead,
                want_strength=1.0 if lead else 0.40,
                intensity=0.80 if lead else 0.38, **base)
        if hit("settle", "regroup", "calm", "rest", "breathe"):
            return E.Situation(
                knows="זה נגמר בשלום", wants="לנשום ולמצוא את השאר",
                feels="surprise", looks_at="partner",
                change="כולם שלמים", knows_more=False,
                want_strength=0.70, intensity=0.62, **base)
        if hit("chat", "talk", "speak", "line"):
            return E.Situation(
                knows="יש מה לספר", wants="לשתף את מי שלידו",
                feels="joy", looks_at="partner",
                change="כולם מאטים לדבר", knows_more=False,
                want_strength=0.60, intensity=0.55 if lead else 0.46,
                **base)
        return E.Situation(
            knows="הרגע נעים", wants="להיות שם",
            feels="joy", looks_at="partner" if lead else "object",
            change="החברים סביב", knows_more=False,
            want_strength=0.55 if lead else 0.45,
            intensity=0.50 if lead else 0.40, **base)

    def frame_extra(self, t_film: float):
        """המטען של שכבת האובייקטים התלת-ממדיים בפריים, אם יש."""
        if callable(self._extra):
            return self._extra(t_film)
        return None

    def report(self) -> dict:
        return {"name": self.name, "cast": list(self.cast),
                "slots": list(self.slots), "fps": self.fps,
                "total_seconds": self.total,
                "shots": [s["key"] for s in self.shots],
                "leads": list(self.leads),
                "has_lane_at": callable(getattr(self.mod, "lane_at", None)),
                "has_extras": bool(self.stage_js),
                "extra_key": self.extra_key,
                "source": dict(self.source)}


# ============================================================ טעינה

#: מודול שמוגש כתסריט חייב להיות בן-טעינה; מודול שאין בו SHOTS
#: אינו תסריט, וזה מה ש-`discover` מסנן.
_CANDIDATES = ("showreel.{n}", "{n}", "production.script.{n}")


def _import(name: str):
    if name.endswith(".py") or "/" in name or "\\" in name:
        p = Path(name).resolve()
        if not p.exists():
            raise ValueError(f"אין קובץ תסריט {p}")
        if str(p.parent) not in sys.path:
            sys.path.insert(0, str(p.parent))
        return importlib.import_module(p.stem), p.stem
    last = None
    for pat in _CANDIDATES:
        try:
            return importlib.import_module(pat.format(n=name)), name
        except ModuleNotFoundError as e:                  # noqa: PERF203
            last = e
    raise ValueError(f"לא נמצא מודול תסריט בשם {name!r} ({last})")


def load(name: str) -> Script:
    """טוען תסריט לפי שם מודול, שם קצר או נתיב קובץ.

    **הגשר הצמוד נטען מיוזמתו של הגשר ולא של התסריט**: מודול
    `<שם>_render`, אם קיים, הוא המקום שבו יושבים האובייקטים
    התלת-ממדיים ופונקציית המצב של אותו תסריט. כך `park90` -
    שמצהיר על עצמו "אינו מרנדר דבר" - נשאר חוזה טהור, והעיטורים
    שלו נמצאים בלי שהוא יודע על הגשר הזה בכלל.
    """
    mod, short = _import(name)
    comp = None
    for suf in ("_render", "_bridge"):
        try:
            comp = importlib.import_module(f"{mod.__name__}{suf}")
            break
        except ModuleNotFoundError:
            continue
    spec = getattr(mod, "SPEC", None)
    return Script(short, mod, comp, spec if isinstance(spec, dict) else None)


def discover() -> list[str]:
    """כל התסריטים שאפשר לטעון מתיקיית `showreel`."""
    out = []
    for p in sorted(HERE.glob("*.py")):
        if p.stem.startswith(("_", "test_")) or p.stem in (
                "bridge", "chase"):
            continue
        try:
            sc = load(p.stem)
        except Exception:                                  # noqa: BLE001
            continue
        out.append(f"{sc.name}: {len(sc.cast)} דמויות · "
                   f"{sc.total:g} שניות · {len(sc.shots)} שוטים")
    return out


# ============================================================ בימוי

def _actor(sc: Script, slot: str, shot: dict):
    """שחקן אחד בשוט אחד.

    שורת דיבור נלקחת מ-`lines` של השוט, ואם אין - `speech=()`
    ו-`voice=""`. העברת חלון דיבור ריק עם קול כן הייתה פותחת
    תנועת פה בלי שמע; קול בלי חלון הייתה שמע בלי פה.
    """
    line = next((l for l in shot["lines"] if l[0] == slot), None)
    win = () if line is None else ((round(float(line[1]), 4),
                                    round(float(line[1]) + float(line[2]),
                                          4)),)
    voice = "" if line is None else sc.voice_of(slot)
    fn, _eye = SR._emotion_actor(
        sc.situation(slot, shot["beat"], shot["secs"], line),
        seed=sc.seeds[slot], phase=sc.phase[slot],
        speech=win, voice=voice, body=True)
    return fn


def build_shots(sc: Script, heights: dict | None = None,
                fps: int | None = None,
                smooth: float | None = None) -> list[DS.Shot4]:
    """שוטי התסריט, כאובייקטי שוט של המפיק.

    `DS.Shot4` הוא מחזיק נתונים בלי שום קביעות של ארבע דמויות
    (מילון שחקנים לפי מקום), ולכן הוא משמש כאן כמות שהוא לכל n.

    `smooth` הוא חלון ההחלקה בשניות, ו-`None` (ברירת המחדל) =
    **לקרוא את הכוונון שבתוקף** (`studio.tuning`). הפרמטר קיים
    כדי שיהיה אפשר לקבע אותו מפורשות: הכוונון הוא מצב גלובלי
    שיורד לדיסק, ובדיקת "אפס נסיגה מול הגשר הידני" חייבת למדוד
    את הגשר ולא את הכוונון שהצטבר בו בינתיים. `0.0` מחזיר את
    השחקנים כמות שהם, בלי שום עטיפה.
    """
    fps = int(fps or sc.fps)
    out: list[DS.Shot4] = []
    t_abs = 0.0
    for s in sc.shots:
        moves, actors = {}, {}
        for slot in sc.slots:
            if slot not in s["vis"]:
                continue
            sk = SR.pipeline.cast_skeleton(sc.name_of(slot))
            # `lane=0`: הנתיב נקבע ב-HTML ובשדה `lx`, והבמה
            # **מוסיפה** אליו את צעדי ההליכה.
            moves[slot] = LM.Move(sk, s["plan"][slot], fps=fps,
                                  treadmill=True, lane=0.0,
                                  phase0=sc.phase[slot] + 0.55)
            # **ההחלקה נכנסת לפני התנועה, לא אחריה.** זו הידית
            # שמנוע התיקון האוטונומי מזיז (`studio.tuning`), והיא
            # חייבת לשבת על אותה פונקציה שמזינה את הרינדור -
            # אחרת הציון עולה והסרטון לא משתנה. לפני `_wrap`
            # ולא אחריו, כי `Move` הוא ההילוך: החלקה של נקודת
            # הדריכה מחזירה בדיוק את ההחלקה על הדשא שהשערים של
            # `locomotion` מודדים. בכוונון 0 (ברירת המחדל)
            # `smoothed` מחזיר את הפונקציה כמות שהיא, ולכן אין
            # שום שינוי לאף תסריט קיים.
            fn = TU.smoothed(_actor(sc, slot, s), s["secs"], fps,
                             win=smooth)
            actors[slot] = DS._wrap(fn, moves[slot])
        out.append(DS.Shot4(s["key"], s["secs"], s["cap"], s["camera"],
                            actors, moves, s["vis"], s["lines"], t_abs))
        t_abs += s["secs"]
    return out


def mv_frame(sc: Script, shot: DS.Shot4, slot: str, t: float,
             t_film: float) -> dict:
    """היסט התנועה של דמות בפריים, **כולל הנתיב המוחלט**.

    זו החוליה שמחברת בין צעדי ההליכה (`Move.offset`, בצירי
    הדמות) לבין הנתיב שמשתנה בזמן (`lane_at`, בציר העולם).
    """
    mv = shot.moves[slot].offset(t)
    mv["lx"] = round(sc.lane_at(slot, t_film), 4)
    # **`ry` נשלח רק כשהתסריט מצהיר על זווית בזמן.** שליחה
    # קבועה הייתה מחליפה את הזווית שהבמה קיבלה בכתובת גם
    # בתסריטים שאינם מבקשים זאת, כלומר שינוי שקט בכל השאר.
    if callable(sc._yaw_at):
        mv["ry"] = round(sc.yaw_at(slot, t_film), 3)
    return mv


# =========================================================== מצלמה

def camera(sc: Script, kind: str, u: float, heights: dict,
           t_film: float) -> dict:
    """מצלמה ל-n דמויות, וארבעה סוגי שוט.

    **המרחק נגזר מהרוחב שצריך לכסות ולא מהגובה.** זה ההבדל
    העקרוני מ-`disney_story._cam`, ששם הפרישה היא 2.30 מ' קבועה:
    כאן היא נמדדת מ-`lane_at` **בזמן הפריים**, ולכן השוט הרחב
    נפתח לבד כשהקבוצה מתפצלת ונסגר כשהיא מתאחדת - בלי שאף אחד
    יכתוב לו עקומה.
    """
    tall = max(heights.values())
    mid = sum(heights.values()) / len(heights)
    span = sc.span_at(t_film)

    def fit(fov_deg: float, margin: float = 1.08,
            width: float | None = None) -> float:
        half = math.radians(fov_deg) * 0.5
        w = span if width is None else width
        return (w * 0.5 * margin) / max(1e-6, math.tan(half))

    if kind == "wide":
        fov = 36.0
        # `ty` בגובה החזה ולא המותניים: נקודת המבט היא מה שמופיע
        # במרכז הפריים, ומותניים במרכז פירושם שליש פריים ריק.
        return {"yaw": SR.lerp(-11, 8, u), "pitch": 4.0,
                "dist": max(tall * 2.6, fit(fov)), "tx": 0.0,
                "ty": mid * 0.80, "fov": fov}
    if kind == "medium":
        fov = 33.0
        return {"yaw": SR.lerp(18, 29, u), "pitch": 2.6,
                "dist": max(tall * 2.2, fit(fov, 1.02)), "tx": 0.0,
                "ty": mid * 0.78, "fov": fov}
    if kind == "zoomout":
        # שוט הסיום של תסריט בלי קרן: נסיגה רכה שפותחת את המקום.
        fov = SR.lerp(31.0, 44.0, SR.smooth(u))
        base = max(tall * 2.4, fit(31.0))
        return {"yaw": SR.lerp(6, -14, SR.smooth(u)), "pitch": 5.4,
                "dist": base * SR.lerp(1.0, 1.52, SR.smooth(u)),
                "tx": 0.0, "ty": mid * 0.62, "fov": fov}

    # ---------------------------------------------------- crane
    # **ה-`pitch` נגזר ולא מועתק, וזה היה באג מלא ב-TASK 23.**
    # `crane_at` מחזיר שיפוע בקונבנציה הקולנועית (שלילי = מביט
    # למטה), ואילו `stage.html` מציב את המצלמה ב-
    # `ty + sin(pitch)*dist` - שם שלילי פירושו מצלמה **מתחת**
    # למטרה, כלומר צילום מהרצפה. הנגזרת:
    # `sin(pitch) = (גובה הקרן - גובה המבט) / המרחק`, ולכן גובה
    # המצלמה בפועל הוא **בדיוק** `crane_at(t)["y"]`.
    c = sc.crane_at(t_film)
    fov = SR.lerp(34.0, 41.0, c["u"])
    ty = mid * 0.70
    # **הפרישה ההתחלתית נמדדת פעם אחת, בתחילת החלון, ולא בכל
    # פריים.** בשוט הזה הלהקה נסוגה החוצה כדי לפתוח את המרכז,
    # כלומר `span` של הפריים *גדל* בדיוק כשהמצלמה אמורה
    # להתקרב - והמרחק יצא 9.4 -> 11.5 -> 7.2, כלומר נסיגה ואז
    # זינוק. מצלמה שנושמת פנימה והחוצה אינה תנועת קרן.
    span0 = sc.span_at(sc.crane_window[0])
    want = SR.lerp(span0, sc.focus_span, SR.smooth(c["u"]))
    dist = max(c["dist"], fit(fov, 1.08, want))
    pitch = math.degrees(math.asin(
        max(0.0, min(0.97, (c["y"] - ty) / max(1e-6, dist)))))
    return {"yaw": SR.lerp(6.0, -3.0, c["u"]), "pitch": round(pitch, 3),
            "dist": round(dist, 4), "tx": 0.0, "ty": round(ty, 4),
            "fov": fov}


# ============================================================= הבמה

def stage_html(sc: Script) -> str:
    """במת n המקומות, **נגזרת מ-`disney_story.stage_html`**.

    שם שש ההחלפות שמכלילות את `rig/stage.html` ל-n מקומות, וכאן
    נוספות שתיים: הנתיב שמשתנה בזמן, ושכבת האובייקטים של
    התסריט. כל החלפה נבדקת שמצאה את המקור - החלפה שהחמיצה היא
    במה שנשארה בלי העלילה המרכזית בלי שאף אחד צועק.
    """
    src = DS.stage_html()
    # **סדר ההחלפות: הזווית לפני הנתיב.** תיקון הנתיב מחליף את
    # השורה שמיד *אחרי* שורת c/s, ושתי ההחלפות אינן חופפות -
    # אבל הן נוגעות באותן שתי שורות, ולכן מי שיחליף סדר יקבל
    # "המקור לא נמצא" במקום באג שקט. ההחלפה בודקת מופע יחיד.
    for what, (old, new) in (("הזווית", YAW_PATCH), ("הנתיב", LANE_PATCH)):
        if old not in src:
            raise RuntimeError(
                f"ההחלפה של {what} לא מצאה את המקור; ההתפצלות "
                f"וההתכנסות לא יקרו. חסר: {old.strip()[:60]!r}")
        if src.count(old) != 1:
            raise RuntimeError(
                f"מקור {what} מופיע {src.count(old)} פעמים; החלפה "
                "מרובה כאן היא שתי במות שונות.")
        src = src.replace(old, new, 1)

    if not sc.stage_js:
        return src
    anchor = "window.__frame = (json) => {"
    if anchor not in src:
        raise RuntimeError("לא נמצאה נקודת העגינה של __frame")
    src = src.replace(anchor, sc.stage_js + "\n" + anchor, 1)
    hook = "  if (f.dn) dnFrame(f.dn);"
    if hook not in src:
        raise RuntimeError(
            "לא נמצאה נקודת הקריאה לשכבת האובייקטים; אובייקטי "
            "התסריט לא ייוצרו בשום פריים.")
    k = sc.extra_key
    return src.replace(hook, hook + f"\n  if (f.{k}) {k}Frame(f.{k});", 1)


def serve_dir(sc: Script, rig_dir: Path, env_dir: Path | None) -> Path:
    d = Path(tempfile.mkdtemp(prefix=f"{sc.name}_"))
    shutil.copytree(STUDIO / "lib", d / "lib")
    shutil.copytree(STUDIO / "utils", d / "utils")
    (d / "stage.html").write_text(stage_html(sc), encoding="utf-8")
    for slot in sc.slots:
        shutil.copy2(rig_dir / f"{sc.name_of(slot)}.glb", d / f"{slot}.glb")
    if env_dir and Path(env_dir).exists():
        shutil.copytree(Path(env_dir), d / "env")
    return d


# ====================================================== שערי הגשר

def audit(sc: Script, heights: dict | None = None) -> dict:
    """שערי המיפוי. **בלי דפדפן, בלי רינדור, בלי GLB.**

    כל שער כאן מודד את מה שהגשר **גזר**, ולא את מה שהתסריט
    הצהיר: תסריט שגוי נתפס בטעינה (`ValueError`), והמיפוי
    נתפס כאן.
    """
    g: dict = {}
    heights = heights or {k: 1.52 + 0.047 * i
                          for i, k in enumerate(sc.slots)}

    def gate(key, ok, detail):
        g[key] = {"pass": bool(ok), "detail": str(detail)}

    tot = sum(s["secs"] for s in sc.shots)
    gate("אורך הרצף הוא סכום השוטים",
         abs(tot - sc.total) < 1e-9,
         f"{tot:.3f} שניות ב-{len(sc.shots)} שוטים")
    gate("וכל שוט הוא כפולה שלמה של פריים",
         all(abs(s["secs"] * sc.fps - round(s["secs"] * sc.fps)) < 1e-9
             for s in sc.shots), f"{sc.fps} fps")
    gate("מספר המקומות שווה למספר הדמויות",
         len(sc.slots) == len(sc.cast) == len(set(sc.cast)),
         f"{len(sc.slots)} מקומות · {len(set(sc.cast))} דמויות נבדלות")
    gate("וכל דמות קיימת בהרכב שנבנה",
         all(n in PL.CAST for n in sc.cast),
         ", ".join(sc.cast))
    gate("וכל דמות מופיעה לפחות בשוט אחד",
         set().union(*[set(s["vis"]) for s in sc.shots]) == set(sc.slots),
         f"{len(set().union(*[set(s['vis']) for s in sc.shots]))}/"
         f"{len(sc.slots)}")

    # **הספים כאן מכוילים למה שנמדד בסרט שכבר אושר, ולא למה
    # שנוח לגנרטור.** הסריג שהגשר גוזר נותן מרווח 1/n בדיוק,
    # ולכן סף של 0.9/n היה "עובר תמיד" עליו - ו**נופל על הטבלה
    # שנכתבה ביד ל-`park90`**, שמרווח הזרעים שלה 0.11 (מול
    # 0.1125 שסף כזה דורש) ומרווח הפאזות שלה 0.06 בלבד. אותה
    # טבלה היא של 90 השניות שכבר הופקו ואושרו, ולכן סף שפוסל
    # אותה מודד את עצמו ולא את התוצאה.
    #
    # לכן: הזרע נמדד מול 0.7/n - זה בדיוק הסף 0.09 שהמחבר של
    # `park90` כתב ל-8 דמויות - והפאזה, שמעולם לא נדרשה שם,
    # נמדדת רק על הפרדה ממשית (0.4/n) ועל היותה נבדלת.
    mg = min_gap(sc.seeds.values())
    need = 0.7 / len(sc.slots)
    gate("לכל דמות זרע נבדל (n בבואות אינן הרכב)",
         len(set(sc.seeds.values())) == len(sc.slots) and mg >= need,
         f"מרווח מינימלי {mg:.3f} מול {need:.3f} נדרש")
    pg = min_gap(sc.phase.values())
    gate("ולכל דמות קיזוז פאזה נבדל",
         len(set(sc.phase.values())) == len(sc.slots)
         and pg >= 0.4 / len(sc.slots),
         f"מרווח מינימלי {pg:.3f} מול {0.4 / len(sc.slots):.3f} נדרש")

    lanes = sorted(sc.lane_x.values())
    lgap = min((b - a) for a, b in zip(lanes, lanes[1:])) if len(lanes) > 1 \
        else 1.0
    gate("הנתיבים מופרדים דיים שדמות לא תיעלם מאחורי שכנתה",
         lgap >= 0.30, f"מרווח נתיבים מינימלי {lgap:.2f} מ'")

    # --- המצלמה: מכסה את הפרישה הרחבה ביותר לאורך הרצף
    ts = [sc.total * i / 60.0 for i in range(61)]
    worst_t = max(ts, key=sc.span_at)
    wide = camera(sc, "wide", 0.5, heights, worst_t)
    need_d = (sc.span_at(worst_t) * 0.5 * 1.08) / math.tan(
        math.radians(36.0 * 0.5))
    gate("המצלמה הרחבה מכסה את הפרישה הרחבה ביותר",
         wide["dist"] >= need_d - 1e-6,
         f"פרישה {sc.span_at(worst_t):.2f} מ' · נדרש {need_d:.2f} מ' · "
         f"בפועל {wide['dist']:.2f} מ'")

    # --- מצלמת הקרן, אם יש שוט כזה
    if any(s["camera"] == "crane" for s in sc.shots):
        c0, c1 = sc.crane_window
        sm = []
        for i in range(241):
            t = c0 + (c1 - c0) * i / 240.0
            c = camera(sc, "crane", i / 240.0, heights, min(t, c1 - 1e-3))
            sm.append(c["ty"] + math.sin(math.radians(c["pitch"]))
                      * c["dist"])
        gate("גובה מצלמת הקרן עולה מונוטונית",
             all(b >= a - 1e-6 for a, b in zip(sm, sm[1:])),
             f"{sm[0]:.2f} -> {sm[-1]:.2f} מ'")
        gate("ועלייתה גבוהה מהדמות הגבוהה",
             sm[-1] - sm[0] > max(heights.values()),
             f"עלייה {sm[-1] - sm[0]:.2f} מ' מול "
             f"{max(heights.values()):.2f} מ'")

    # --- הבמה
    html = stage_html(sc)
    gate("הבמה נבנית ל-n מקומות ועם נתיב שמשתנה בזמן",
         "const SLOTS = " in html and "m.lx" in html
         and "const bx = " in html,
         f"{len(html)} תווים")
    if sc.stage_js:
        k = sc.extra_key
        gate("ושכבת האובייקטים של התסריט מוזרקת ונקראת בכל פריים",
             f"if (f.{k}) {k}Frame(f.{k});" in html
             and f"window.{k}Frame" in html,
             f"מפתח {k!r}")
        gate("ומטען האובייקטים מוחזר בפועל",
             isinstance(sc.frame_extra(sc.total * 0.5), dict),
             f"{type(sc.frame_extra(sc.total * 0.5)).__name__}")
    return g


def passed(sc: Script) -> bool:
    return all(v["pass"] for v in audit(sc).values())


# ============================================================== הפקה

async def produce(sc: Script, out_mp4: Path, rig_dir: Path = SR.RIG_DIR,
                  fps: int | None = None, width: int = 1920,
                  height: int = 1080, ss: int = 2, on_progress=None,
                  env_dir: Path | None = None, probe: bool = False,
                  probe_u: float = 0.5) -> dict:
    """מרנדר תסריט מנורמל לווידאו. **אותה לולאה לכל תסריט.**"""
    import engine                                        # noqa: PLC0415

    fps = int(fps or sc.fps)
    env_dir = Path(env_dir) if env_dir else sc.env_dir

    # 1 · הסביבה. חוזה הסביבה נסגר **לפני** הדפדפן: סצנת חוץ בלי
    #     רקע היא אולפן שחור, וגילוי שלה אחרי אלפי פריימים הוא
    #     40 דקות שנשרפו.
    loc = sc.location
    if loc is None:
        from production.script import sunbeam50 as SB    # noqa: PLC0415
        loc = SB.LOCATION
    loc = dict(loc)
    loc["total_seconds"] = sc.total
    man = PD.bake(env_dir, loc, width=width, height=height)
    bad = [k for k, v in PD.validate(man, env_dir, *_ENV_BIKE).items()
           if not v["pass"]]
    if bad:
        raise RuntimeError(f"חוזה הסביבה לא נסגר: {bad}")

    # 2 · שערי העלילה של התסריט (אם יש לו), ואחריהם שערי המיפוי.
    #     הרינדור קורא **מאותן פונקציות** שהם מודדים.
    story = {}
    if callable(sc.audit_fn):
        story = sc.audit_fn()
        bad = [k for k, v in story.items() if not v.get("pass")]
        if bad:
            raise RuntimeError(f"חוזה העלילה לא נסגר: {bad}")

    # 3 · הדמויות
    rigs, skels, libs = {}, {}, {}
    for slot in sc.slots:
        rigs[slot], skels[slot], libs[slot] = SR.load_char(
            sc.name_of(slot), rig_dir)
    heights = {k: float(rigs[k]["height_m"]) for k in sc.slots}
    shots = build_shots(sc, heights, fps)

    bridge_gates = audit(sc, heights)
    bad = [k for k, v in bridge_gates.items() if not v["pass"]]
    if bad:
        raise RuntimeError(f"שערי הגשר לא נסגרו: {bad}")

    # 4 · הבמה
    root = serve_dir(sc, rig_dir, env_dir)
    srv, port = SR._serve(root)
    br = engine.Browser(width, height)
    t0 = time.time()
    enc = None
    frames_done = 0
    info: dict = {}
    probes: list[Path] = []
    try:
        await br.start()
        q = "&".join([f"w={width}", f"h={height}", f"ss={ss}",
                      "slots=" + ",".join(sc.slots)]
                     + [f"g{k}={k}.glb" for k in sc.slots]
                     + [f"x{k}={sc.lane_x[k]}" for k in sc.slots]
                     + [f"r{k}={sc.lane_yaw[k]}" for k in sc.slots])
        await br.cmd("Page.navigate",
                     {"url": f"http://127.0.0.1:{port}/stage.html?{q}"})
        for _ in range(900):
            if await br.js("!!window.__ready"):
                break
            await asyncio.sleep(0.1)
        err = await br.js("window.__err ? window.__err() : 'הבמה לא נטענה'")
        if err:
            raise RuntimeError(f"הבמה החזירה שגיאה: {err}")
        info = json.loads(await br.js("JSON.stringify(window.__info||null)")
                          or "null") or {}
        for k in sc.slots:
            if not info.get(k) or info[k].get("bones", 0) < 1:
                raise RuntimeError(f"מקום {k} נטען בלי עצמות: {info.get(k)}")
            if len(info[k].get("shapes") or []) < len(SR.face.NAMES):
                raise RuntimeError(
                    f"מקום {k}: {len(info[k].get('shapes') or [])} צורות "
                    f"פנים מתוך {len(SR.face.NAMES)}")
        # **n מקומות ולא פחות.** במה שנטענה חלקית מרנדרת סצנה
        # עם פחות דמויות ואינה צועקת - וזה הכשל שאי אפשר לראות
        # בפריים בודד.
        if len(info) < len(sc.slots):
            raise RuntimeError(
                f"נטענו {len(info)} מקומות מתוך {len(sc.slots)}")

        spec = json.dumps(json.dumps(dict(man, base="env/")))
        env_on = await br.js(
            f"window.__env ? window.__env(JSON.parse({spec})) : -1")
        if not isinstance(env_on, (int, float)) or env_on < 1:
            raise RuntimeError(f"שכבות הסביבה לא נטענו (הוחזר {env_on!r}).")
        if sc.stage_js:
            ready = sc.extra_ready or (
                f"typeof window.{sc.extra_key}Frame === 'function' ? 1 : 0")
            if not await br.js(ready):
                raise RuntimeError(
                    "שכבת האובייקטים של התסריט לא נבנתה על הבמה.")

        if not probe:
            enc = engine.Encoder(out_mp4, width, height, fps, crf=19)
        total = sum(int(round(s.secs * fps)) for s in shots)
        for shot in shots:
            n = int(round(shot.secs * fps))
            # SoftRig אחת לכל דמות **ולכל שוט**: מצב קפיץ שנשאר
            # בין חיתוכי מצלמה הוא קפיצה בפריים הראשון של הבא.
            soft = {k: secondary.SoftRig(skels[k], 1.05) for k in shot.vis}
            idx = ([min(n - 1, max(0, int(round(probe_u * (n - 1)))))]
                   if probe else list(range(n)))
            for i in idx:
                t = i / fps
                u = i / max(1, n - 1)
                t_film = shot.t_abs + t

                f: dict = {"light": "sun_hard_left",
                           "cam": camera(sc, shot.camera, u, heights, t_film),
                           "cap": shot.caption_at(t),
                           "tag": "",
                           "fade": SR._fade_at(t, shot.secs),
                           "cap_o": SR._cap_opacity(t, shot.secs),
                           "vis": {k: (k in shot.vis) for k in sc.slots},
                           "mv": {}}
                for k in sc.slots:
                    if k not in shot.vis:
                        f[k] = {}
                        continue
                    # חוזה השחקן: נקרא **(u, t)** בסדר הזה.
                    r = shot.actors[k](u, t)
                    morphs = (r[2] or {}) if len(r) > 2 else {}
                    ctl = r[0]
                    # **הדריסה חייבת להיות כאן ולא ב-`extra`.**
                    # `Move.actor` מעדכן את ערוצי התנועה אחרי
                    # ה-extra ומנצח אותו (מכוון שם), ולכן תנוחת
                    # החיבוק שמוזרקת שם נמחקת בשקט - הזרועות
                    # ממשיכות להתנדנד בתוך החיבוק.
                    ov = sc.body_over(k, t_film)
                    if ov:
                        ctl = dict(ctl)
                        ctl.update(ov)
                    pose_q = controls.evaluate(skels[k], ctl, r[1])
                    pose_q = soft[k].solve(dict(pose_q), 1.0 / fps)
                    f[k] = SR._jsonable(pose_q)
                    f["M" + k] = {kk: round(float(vv), 4)
                                  for kk, vv in morphs.items()}
                    f["mv"][k] = mv_frame(sc, shot, k, t, t_film)

                gust = PD.gust_at(t_film, sc.tree_pass)
                f["env"] = {"pan": round(
                    shot.moves[next(iter(shot.moves))].pan_of(
                        t, sc.pan_scale), 4),
                    "dap": 0.16 if shot.camera == "medium" else 0.10,
                    "t": t_film, "gust": round(gust, 4)}
                bk = PD.bike_at(t_film, *sc.bike_roll)
                bk["r"] = PD.LAYOUT["bike"]["wheel_r"]
                f["dn"] = {"jets": PD.jets_at(t_film), "bike": bk}
                xtr = sc.frame_extra(t_film)
                if xtr is not None:
                    f[sc.extra_key] = xtr

                res = await br.js(
                    "window.__frame(" + json.dumps(json.dumps(f)) + ")")
                if res == "err":
                    raise RuntimeError(
                        await br.js("window.__err()") or "פריים נכשל")
                blob = await br.shot()
                if probe:
                    p = out_mp4.with_name(f"{out_mp4.stem}_{shot.key}.jpg")
                    p.write_bytes(blob)
                    probes.append(p)
                else:
                    enc.add_jpeg(blob)
                frames_done += 1
                if on_progress and frames_done % 30 == 0:
                    on_progress(frames_done, total)
    finally:
        await br.close()
        srv.shutdown()
        if enc:
            enc.close()
        shutil.rmtree(root, ignore_errors=True)

    # ================================ פס הקול (TASK 25)
    #
    # עד כה הגשר הדינמי ידע **רק** לפתוח תנועת פה: הוא העביר
    # `voice=` ל-`_emotion_actor` ולא הרכיב שום wav. כלומר כל
    # תסריט שעבר דרכו יצא **אילם**, ו-`park_disney90.mp4` של
    # TASK 23 אכן יצא בלי ערוץ שמע בכלל (נמדד: 0 ערוצי אודיו).
    # המסלול עצמו היה קיים ב-`disney_story._mux`, והוא נקרא
    # מכאן כמות שהוא - שני מסלולי מיקס היו מתפצלים בשקט.
    audio = None
    if not probe and out_mp4.exists():
        cues, missing = [], []
        for s, shot in zip(sc.shots, shots):
            for ln in s["lines"]:
                who, at, txt = ln[0], float(ln[1]), ln[3]
                tr = V.load(txt, sc.voice_of(who))
                if tr is None:
                    missing.append(f"{s['key']}/{who}")
                    continue
                cues.append((shot.t_abs + at, tr))
        if cues:
            audio = DS._mux(out_mp4, cues, sc.total)
            audio["missing"] = missing
        elif missing:
            audio = {"muxed": False, "lines": 0,
                     "why": "אין קובצי קול לשורות",
                     "missing": missing}

    return {"mp4": str(out_mp4) if not probe else None,
            "seconds": sc.total if not probe else None,
            "frames": frames_done,
            "render_sec": round(time.time() - t0, 1),
            "size_mb": (round(out_mp4.stat().st_size / 1e6, 2)
                        if out_mp4.exists() and not probe else None),
            "info": info,
            "audio": audio,
            "probes": [str(p) for p in probes] if probe else [],
            "script": sc.report(),
            "gates": bridge_gates,
            "story": {"total_seconds": sc.total,
                      "cast": {k: sc.name_of(k) for k in sc.slots},
                      "roles": {k: CD.ROLE.get(sc.name_of(k), "")
                                for k in sc.slots},
                      "heights": {k: round(v, 3)
                                  for k, v in heights.items()},
                      "shots": [s["key"] for s in sc.shots],
                      "audit": story or bridge_gates}}


def render(name: str, out_mp4: Path | str | None = None, **kw) -> dict:
    """נקודת הכניסה בשורה אחת: שם תסריט -> וידאו.

    זה מה שהופך "זה רק מפרט" ל"יש קובץ": אין כאן שום שלב שדורש
    קוד חדש לתסריט חדש.
    """
    sc = load(name)
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    out = Path(out_mp4) if out_mp4 else OUT_DIR / f"{sc.name}.mp4"
    return asyncio.run(produce(sc, out, **kw))


def main(argv=None) -> int:
    import argparse                                      # noqa: PLC0415
    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(
        description="הגשר הדינמי: תסריט כלשהו -> וידאו (TASK 24)")
    ap.add_argument("script", nargs="?", default=None,
                    help="שם מודול תסריט, שם קצר או נתיב קובץ")
    ap.add_argument("--list", action="store_true",
                    help="אילו תסריטים נטענים")
    ap.add_argument("--plan", action="store_true",
                    help="רק להראות את המיפוי ואת השערים")
    ap.add_argument("--out", default="")
    ap.add_argument("--fps", type=int, default=0)
    ap.add_argument("--width", type=int, default=1920)
    ap.add_argument("--height", type=int, default=1080)
    ap.add_argument("--ss", type=int, default=2)
    ap.add_argument("--probe", action="store_true")
    ap.add_argument("--probe-u", type=float, default=0.5)
    a = ap.parse_args(argv)

    if a.list or not a.script:
        for line in discover():
            print("  " + line)
        return 0

    sc = load(a.script)
    print(f"תסריט {sc.name}: {len(sc.cast)} דמויות · {sc.total:g} שניות · "
          f"{len(sc.shots)} שוטים · {sc.fps} fps")
    for k, v in sc.source.items():
        print(f"    {k} ← {v}")
    g = audit(sc)
    for k, v in g.items():
        print(("  ✓ " if v["pass"] else "  ✗ ") + k + " — " + v["detail"])
    bad = [k for k, v in g.items() if not v["pass"]]
    print(f"\n{len(g) - len(bad)}/{len(g)} שערי גשר עברו")
    if a.plan:
        return 1 if bad else 0
    if bad:
        print("השערים לא נסגרו - אין רינדור.")
        return 1

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    out = Path(a.out) if a.out else OUT_DIR / f"{sc.name}.mp4"

    def prog(i, t):
        print(f"  פריים {i}/{t}", flush=True)

    rep = asyncio.run(produce(sc, out, fps=(a.fps or None), width=a.width,
                              height=a.height, ss=a.ss, on_progress=prog,
                              probe=a.probe, probe_u=a.probe_u))
    out.with_suffix(".json").write_text(
        json.dumps(rep, ensure_ascii=False, indent=1, default=str),
        encoding="utf-8")
    if rep.get("mp4"):
        print(f"\n{rep['seconds']}ש · {rep['size_mb']}MB · "
              f"רנדור {rep['render_sec']}ש\n{rep['mp4']}")
    for p in rep.get("probes") or []:
        print("  תמונת בדיקה:", p)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
