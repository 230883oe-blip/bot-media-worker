# -*- coding: utf-8 -*-
"""בקרת איכות חזותית אוטומטית לשוטים מרונדרים — שלב 18 בתוכנית האולפן.

**למה זה המודול החשוב ביותר בצינור הזה.**
כל תקלת רינדור שנתפסה כאן עד היום נתפסה *בעין*, בלי שום שגיאה ובלי
שום סימן בקוד: ארבעה מונים שנשארו על אפס לאורך סצנה שלמה, כתובית
שנחתכה ע"י חלון שמעליה, קו שלא הגיע לנקודת הסיום, וקובץ MP4 פגום
שנראה בדיוק כמו הרצה שנקטעה. המשותף לכולן: התהליך סיים בקוד 0.

**ההחלטה הארכיטקטונית (מועצה 05/10 — Command A, Qwen 3.8).**
התוכנית המקורית אמרה "use a vision model". אין כאן GPU ואין מכסה
למודל ראייה, אבל גם לולא זה — המועצה פסלה במפורש את הבדיקות
הסמנטיות, ובצדק:

| נפסל | למה |
|---|---|
| אנטומיה / ידיים / פנים | בלי מודל זו בדיקת צורה חסרת משמעות. תנועת יד טבעית נתפסת כפגם. |
| תקינות תאורה | גרדיאנט רקע מתוכנן וסטייה לא מכוונת נראים זהים במדד. |
| נכונות ה-viseme | דורש השוואה סמנטית מול השמע. כאן נמדדת **קורלציה** בלבד. |
| חיתוך (clipping) כללי | אין סף אוניברסלי; תלוי תוכן. כאן רק אזור בטוח מוגדר. |

מה שכן נבנה: **מדידה של אזור עניין לאורך זמן**. כל בדיקה מחזירה
מספר אחד, סף אחד, ושם תת-המערכת האחראית — כדי שהתיקון יחזור לשלב
הנכון ולא "לאנימציה" באופן כללי.

**זיכרון.** המכונה חנוקה בזיכרון ולכן אין טעינה של כל הפריימים.
הפריימים נדגמים בצעדים, מומרים מיד לאפור מוקטן (ברירת מחדל 160
פיקסלים רוחב), ורק המערך המוקטן נשמר. סרטון של דקה ב-1080p נכנס
לפחות מ-3MB במקום 3.7GB.
"""
from __future__ import annotations

import json
import math
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Iterable, Optional

import numpy as np

# איזו תת-מערכת אחראית על איזה פגם. זה מה שמאפשר תיקון אוטומטי:
# שוט שנכשל חוזר לשלב הזה ולא "למישהו".
BLAME = {
    "container": "encode",       # קידוד / איחוד
    "duration": "timeline",      # ציר הזמן של הסצנה
    "frozen": "timeline",
    "loop": "timeline",
    "blank": "render",           # הרינדור עצמו
    "contrast": "lighting",
    "edge_safe": "layout",       # פריסה / קאדר
    "static_roi": "databind",    # חיבור הנתונים לציור
    "motion": "animation",
    "lipsync": "lipsync",
}

DOWNSCALE_W = 160               # רוחב הדגימה האפורה. 160 מספיק לכל מדד כאן.


# --------------------------------------------------------------- דגימה

@dataclass
class Sample:
    """דגימה דלילה של סרטון: אפור מוקטן + מדדים גלובליים לכל פריים."""

    gray: np.ndarray            # (n, h, w) float32 בטווח 0..1
    times: np.ndarray           # (n,) שניות
    fps: float
    width: int
    height: int
    frames_decoded: int
    duration_declared: float
    decode_error: str = ""
    edge_ink: np.ndarray = field(default_factory=lambda: np.zeros((0, 4), "float32"))

    @property
    def n(self) -> int:
        return int(self.gray.shape[0])


def _to_gray(img, w: int) -> np.ndarray:
    from PIL import Image
    if not isinstance(img, Image.Image):
        img = img.to_image()
    h = max(1, int(round(img.height * w / img.width)))
    g = img.convert("L").resize((w, h), Image.BILINEAR)
    return np.asarray(g, dtype=np.float32) / 255.0


def sample_video(path: Path, stride: int = 3, down_w: int = DOWNSCALE_W,
                 max_frames: int = 900) -> Sample:
    """מפענח בצעדים ומחזיר דגימה אפורה מוקטנת.

    `stride=3` ב-30fps נותן 10 דגימות לשנייה — די והותר לכל מדד כאן,
    ושליש מזמן הפענוח. הפענוח עצמו הוא סדרתי ולא seek: seek על קובץ
    פגום מחזיר שקרים, ואחת המטרות כאן היא *לתפוס* קובץ פגום.
    """
    import av

    path = Path(path)
    grays: list[np.ndarray] = []
    times: list[float] = []
    edges: list[tuple[float, float, float, float]] = []
    err = ""
    fps = 0.0
    w = h = 0
    declared = 0.0
    decoded = 0

    container = None
    try:
        container = av.open(str(path))
        vs = container.streams.video[0]
        fps = float(vs.average_rate or 0) or 0.0
        w, h = int(vs.codec_context.width), int(vs.codec_context.height)
        if vs.duration and vs.time_base:
            declared = float(vs.duration * vs.time_base)
        elif container.duration:
            declared = float(container.duration) / av.time_base
        tb = float(vs.time_base or 0) or (1.0 / (fps or 30.0))
        for i, frame in enumerate(container.decode(vs)):
            decoded += 1
            if i % stride:
                continue
            if len(grays) >= max_frames:
                continue
            g = _to_gray(frame, down_w)
            grays.append(g)
            pts = frame.pts
            times.append(float(pts) * tb if pts is not None else i / (fps or 30.0))
            edges.append((
                float(g[0, :].mean()), float(g[-1, :].mean()),
                float(g[:, 0].mean()), float(g[:, -1].mean()),
            ))
    except Exception as exc:              # noqa: BLE001 — זו *תוצאת מדידה*
        err = f"{type(exc).__name__}: {exc}"
    finally:
        if container is not None:
            try:
                container.close()
            except Exception:
                pass

    arr = (np.stack(grays) if grays
           else np.zeros((0, 1, 1), dtype=np.float32))
    return Sample(
        gray=arr, times=np.asarray(times, dtype=np.float64),
        fps=fps, width=w, height=h, frames_decoded=decoded,
        duration_declared=declared, decode_error=err,
        edge_ink=np.asarray(edges, dtype=np.float32) if edges
        else np.zeros((0, 4), dtype=np.float32),
    )


# --------------------------------------------------------------- בדיקות

@dataclass
class Check:
    name: str
    passed: bool
    metric: float
    threshold: float
    blame: str
    detail: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


def _roi_slice(sample: Sample, roi: tuple[float, float, float, float]):
    """ROI ביחידות יחסיות (x,y,w,h ב-0..1) -> חיתוך על הדגימה המוקטנת."""
    _, gh, gw = sample.gray.shape
    x, y, rw, rh = roi
    x0 = max(0, min(gw - 1, int(round(x * gw))))
    y0 = max(0, min(gh - 1, int(round(y * gh))))
    x1 = max(x0 + 1, min(gw, int(round((x + rw) * gw))))
    y1 = max(y0 + 1, min(gh, int(round((y + rh) * gh))))
    return sample.gray[:, y0:y1, x0:x1]


def check_container(sample: Sample, expect_frames: Optional[int] = None) -> Check:
    """תקינות הקובץ: האם הפענוח הגיע לסוף.

    זה הפגם שהסתיר את עצמו הכי טוב: איחוד שנפל בשקט השאיר שני קבצים
    בהפרש של 26 בייט בלבד, ושניהם "נראו" כמו הרצה שנקטעה בגלל שינה
    של המחשב. הבדיקה כאן היא ישירה — אם הפענוח זרק חריגה, זה FAIL,
    ושם החריגה נשמר כדי שלא נחזור לנחש.
    """
    if sample.decode_error:
        return Check("container", False, 0.0, 1.0, BLAME["container"],
                     f"הפענוח נכשל: {sample.decode_error}")
    if sample.frames_decoded == 0:
        return Check("container", False, 0.0, 1.0, BLAME["container"],
                     "אין פריימים בזרם הווידאו")
    if expect_frames:
        ratio = sample.frames_decoded / float(expect_frames)
        ok = ratio >= 0.98
        return Check("container", ok, round(ratio, 4), 0.98, BLAME["container"],
                     f"{sample.frames_decoded} פריימים פוענחו מתוך {expect_frames}")
    return Check("container", True, 1.0, 1.0, BLAME["container"],
                 f"{sample.frames_decoded} פריימים פוענחו במלואם")


def check_duration(sample: Sample, expect_sec: Optional[float],
                   tol: float = 0.12) -> Check:
    """משך בפועל מול משך מצופה.

    תפס כאן סצנה של 7 שניות שיצאה 132: אנימציית רקע בלופ על הציר
    הראשי האריכה את משך הציר פי עשרים. אין שגיאה, רק קובץ ארוך.
    """
    actual = (sample.frames_decoded / sample.fps) if sample.fps else 0.0
    if not expect_sec:
        return Check("duration", True, round(actual, 2), 0.0, BLAME["duration"],
                     f"{actual:.2f}ש (לא הוצהר משך מצופה)")
    dev = abs(actual - expect_sec) / max(0.001, expect_sec)
    return Check("duration", dev <= tol, round(dev, 4), tol, BLAME["duration"],
                 f"{actual:.2f}ש בפועל מול {expect_sec:.2f}ש מצופה")


def check_frozen(sample: Sample, max_share: float = 0.35) -> Check:
    """אחוז הפריימים שזהים לקודמם לחלוטין.

    הסף גבוה (35%) בכוונה: בסרטון לגיטימי יש החזקות (holds) ויש
    פתיחות שקטות. מה שהבדיקה תופסת הוא סצנה שבה *רוב* הזמן שום
    פיקסל לא זז — כלומר האנימציה לא רצה בכלל.
    """
    if sample.n < 3:
        return Check("frozen", True, 0.0, max_share, BLAME["frozen"],
                     "פחות משלוש דגימות")
    d = np.abs(np.diff(sample.gray, axis=0)).reshape(sample.n - 1, -1).max(axis=1)
    share = float((d < 1.5 / 255.0).mean())
    return Check("frozen", share <= max_share, round(share, 4), max_share,
                 BLAME["frozen"],
                 f"{share * 100:.1f}% מהדגימות זהות לקודמת")


def check_motion(sample: Sample, min_rms: float = 0.0015) -> Check:
    """האם בכלל יש תנועה בסרטון. מדד גלובלי, סף נמוך מאוד."""
    if sample.n < 2:
        return Check("motion", False, 0.0, min_rms, BLAME["motion"],
                     "אין מספיק דגימות למדידת תנועה")
    d = np.diff(sample.gray, axis=0)
    rms = float(np.sqrt((d ** 2).mean()))
    return Check("motion", rms >= min_rms, round(rms, 6), min_rms,
                 BLAME["motion"], f"תנועה ממוצעת {rms:.5f}")


def check_loop(sample: Sample, min_sec: float = 8.0,
               sim: float = 0.0025) -> Check:
    """חזרה מחזורית: האם חצי הסרטון השני כמעט זהה לחצי הראשון.

    המועצה (Qwen 3.8) הצביעה על זה כסימן המובהק של לופ. הסף נמוך
    מאוד (RMSE של 0.0025 על אפור 0..1) כדי שסרטון שחוזר לאותו קאדר
    פתיחה בסוף — דבר לגיטימי לגמרי — לא ייתפס.
    """
    dur = (sample.frames_decoded / sample.fps) if sample.fps else 0.0
    if sample.n < 20 or dur < min_sec:
        return Check("loop", True, 1.0, sim, BLAME["loop"],
                     "קצר מכדי לבדוק מחזוריות")
    half = sample.n // 2
    a = sample.gray[:half]
    b = sample.gray[half:half * 2]
    rmse = float(np.sqrt(((a - b) ** 2).mean()))
    return Check("loop", rmse > sim, round(rmse, 6), sim, BLAME["loop"],
                 f"מחצית שנייה מול ראשונה: שגיאה {rmse:.5f}")


def check_blank(sample: Sample, max_share: float = 0.10) -> Check:
    """פריימים שחורים או לבנים לגמרי."""
    if sample.n == 0:
        return Check("blank", False, 1.0, max_share, BLAME["blank"],
                     "אין דגימות")
    flat = sample.gray.reshape(sample.n, -1)
    rng = flat.max(axis=1) - flat.min(axis=1)
    share = float((rng < 0.02).mean())
    return Check("blank", share <= max_share, round(share, 4), max_share,
                 BLAME["blank"], f"{share * 100:.1f}% מהדגימות ריקות")


def check_contrast(sample: Sample, min_std: float = 0.045) -> Check:
    """טווח דינמי. תופס סצנה שיצאה אפורה אחידה בגלל תאורה שלא נדלקה."""
    if sample.n == 0:
        return Check("contrast", False, 0.0, min_std, BLAME["contrast"],
                     "אין דגימות")
    std = float(sample.gray.std())
    return Check("contrast", std >= min_std, round(std, 5), min_std,
                 BLAME["contrast"], f"סטיית בהירות {std:.4f}")


def check_edge_safe(sample: Sample, step: float = 0.06,
                    max_cross: float = 6.0) -> Check:
    """אזור בטוח: טקסט או קו שנחתך בשפת הקאדר.

    **הגרסה הראשונה של הבדיקה הזו נכשלה, והכישלון מלמד את העיקר.**
    היא השוותה את *הניגודיות* בפס הקצה לזו שבפנים הקאדר. זה לא
    עובד: פנים הקאדר מכיל ממילא את האובייקט הבוהק של הסצנה, ולכן
    המכנה גדול והיחס נשאר קטן גם כשיש חיתוך אמיתי. נמדד: 0.82 מול
    סף 1.22 — כלומר כתובית חתוכה שעברה בשלום.

    המדד שעובד הוא **ספירת מעברים לאורך קו הקצה עצמו**, ולא עוצמה.
    זה בדיוק מה שמפריד בין שני המצבים שנראים אותו דבר בעוצמה:

    | מה על הקצה | מעברים חדים לאורך הקו |
    |---|---|
    | רקע חלק או גרדיאנט | 0 — גם גרדיאנט אלכסוני משתנה הדרגתית בין שכנים |
    | גוש שמולא בכוונה עד הקצה (full bleed) | 2, קצה אחד מכל צד |
    | טקסט / קו / מספר שנחתך | עשרות — אות אחר אות |

    לכן הסף הוא 6 מעברים: גבוה מעל מילוי מכוון, ונמוך בהרבה
    ממחרוזת טקסט. זה גם מה שהופך את הבדיקה לחסינה בפני התראות שקר
    בלי שום ידע על התוכן.
    """
    if sample.n < 1:
        return Check("edge_safe", True, 0.0, max_cross, BLAME["edge_safe"],
                     "אין דגימות")
    lines = {
        "עליון": sample.gray[:, 0, :], "תחתון": sample.gray[:, -1, :],
        "שמאלי": sample.gray[:, :, 0], "ימני": sample.gray[:, :, -1],
    }
    worst, where = 0.0, ""
    for name, line in lines.items():
        if line.shape[-1] < 4:
            continue
        # מעברים חדים בין פיקסלים שכנים *לאורך* קו הקצה, לכל פריים
        cross = (np.abs(np.diff(line, axis=1)) > step).sum(axis=1)
        v = float(np.percentile(cross, 90))   # לא המקסימום: פריים בודד חריג אינו פסק דין
        if v > worst:
            worst, where = v, name
    return Check("edge_safe", worst <= max_cross, round(worst, 2), max_cross,
                 BLAME["edge_safe"],
                 f"קו {where or '—'}: {worst:.0f} מעברים חדים לאורך שפת הקאדר")


def check_static_roi(sample: Sample, roi: tuple[float, float, float, float],
                     label: str = "", min_ratio: float = 0.15,
                     window: tuple[float, float] | None = None) -> Check:
    """אזור שהוכרז דינמי אך לא התעדכן — בדיקת המונים שנשארו על אפס.

    **המדד: שונות בזמן חלקי שונות במרחב, בתוך אותו ROI.**
    המונה "מתעדכן" פירושו שהגליפים עצמם מתחלפים, כלומר השינוי
    לאורך הזמן הוא בסדר הגודל של הניגודיות של המספר עצמו. זוהר,
    התעמעמות או הזזה עדינה משנים את כל הפיקסלים בכמות קטנה ביחס
    לניגודיות הזו.

    **ולמה לא שונות מוחלטת, שהייתה הגרסה הראשונה.** היא נמדדה כאן
    על הסצנה האמיתית מול אותה סצנה שבה המונים מנותקים מציר הזמן,
    וכשלה: 3 מתוך 4 מונים *תקועים* עברו את הסף. המדד המוחלט אינו
    יודע להבדיל בין "המספר התחלף" לבין "הכרטיס האיר". המדד היחסי
    הפריד את כל הארבעה, ובפער גדול:

    | מונה | סצנה תקינה | אותה סצנה, מונים מנותקים |
    |---|---|---|
    | c1 | 0.297 | 0.045 |
    | c2 | 0.306 | 0.020 |
    | c3 | 0.386 | 0.094 |
    | c4 | 0.298 | 0.057 |

    סף 0.15 יושב באמצע הפער הזה, ומעבר לכך המדד **חסר יחידות** —
    הוא אינו תלוי בבהירות או בניגודיות של הסצנה, ולכן אינו צריך
    כיול מחדש לכל שוט.

    שתי מלכודות נוספות שנמדדו, ושתיהן הכרחיות:

    1. **ROI רחב מודד את הסצנה ולא את הרכיב.** ROI מוקלד ביד על כל
       רצועת הכרטיסים נתן 0.0173 — פי ארבעה מהסף הישן — בזמן
       שארבעת המונים היו תקועים. מה שזז היה הכרטיסים סביבם. לכן
       `probe.rois_from_page` גוזר את ה-ROI מהדף ולא מנחש אותו.
    2. **חלון זמן.** גם ROI הדוק קולט את אנימציית הכניסה של הכרטיס.
       `window=(t0,t1)` מצמצם את המדידה לטווח שבו הרכיב אמור
       להתעדכן, אחרי שהפריסה נחה.
    """
    name = f"static_roi:{label}" if label else "static_roi"
    patch = _roi_slice(sample, roi)
    if window and sample.times.size == sample.n and sample.n:
        t0, t1 = window
        mask = (sample.times >= t0) & (sample.times <= t1)
        if mask.sum() >= 3:
            patch = patch[mask]
    if patch.size == 0:
        return Check(name, False, 0.0, min_ratio, BLAME["static_roi"],
                     "ה-ROI ריק")
    if patch.shape[0] < 3:
        return Check(name, True, 0.0, min_ratio, BLAME["static_roi"],
                     "פחות משלוש דגימות בחלון הנבדק")
    temporal = float(patch.std(axis=0).mean())        # שינוי לאורך הזמן
    spatial = float(patch.std(axis=(1, 2)).mean())    # ניגודיות הרכיב עצמו
    if spatial < 1e-5:
        # אזור חלק לגמרי: אין בו תוכן. זה עצמו פגם — הרכיב לא צויר.
        return Check(name, False, 0.0, min_ratio, BLAME["static_roi"],
                     f"{label or 'ROI'} חלק לחלוטין — הרכיב כנראה לא צויר")
    ratio = temporal / spatial
    span = f" בחלון {window[0]:.1f}–{window[1]:.1f}ש" if window else ""
    return Check(name, ratio >= min_ratio, round(ratio, 4), min_ratio,
                 BLAME["static_roi"],
                 f"{label or 'ROI'}{span}: עדכון {ratio:.3f} "
                 f"(זמני {temporal:.4f} / מרחבי {spatial:.4f})")


def check_lipsync(sample: Sample, mouth_roi: tuple[float, float, float, float],
                  envelope: Iterable[float], min_corr: float = 0.10) -> Check:
    """קורלציה בלבד בין תנועת אזור הפה למעטפת השמע.

    **זו לא בדיקה סמנטית, במכוון.** המועצה פסלה במפורש בדיקת
    "האם ה-viseme נכון" בלי מודל. מה שנמדד כאן הוא הדבר היחיד
    שאפשר למדוד בלי מודל ושיש בו תוכן: האם הפה בכלל *מגיב* לשמע.
    הסף נמוך (0.10) כי זו בדיקת חיבור-צינור, לא בדיקת איכות: היא
    תופסת פה שקפא או שמע שלא חובר, ולא "שפתיים לא מדויקות".

    **המדד הוא שונות מרחבית בתוך ה-ROI, ולא הבהירות הממוצעת שלו.**
    בהירות ממוצעת זזה עם כל דבר שעובר באזור — רקע נע, תאורה, מצלמה —
    ואז מתקבלת קורלציה שמקורה בסצנה ולא בפה. נמדד כאן בדיוק: ROI
    רחב עם רקע נע נתן 0.52 לפה **קפוא לחלוטין**. שונות מרחבית עולה
    כשהפה נפתח (נוצר ניגוד בין השפתיים לחלל הפה) ואינה מגיבה להזזת
    גוש אחיד דרך האזור.

    **ולכן: ה-ROI חייב להיות הדוק סביב הפה.** ROI שמכיל חצי פנים
    ורקע מודד את הסצנה, לא את הדיבור.

    **קורלציה לבדה אינה מספיקה, וזו המלכודת השלישית שנמדדה כאן.**
    פה קפוא לחלוטין נתן קורלציה 0.22 מול סף 0.10 — ועבר. המקור
    אינו תנועה אלא **רעש המקודד**: libx264 מקצה ביטים אחרת לכל
    פריים, והרעש הזעיר שנוצר מתואם מקרית עם מעטפת חלקה כשיש רק
    כמה עשרות דגימות. קורלציה היא חסרת יחידות ולכן היא *לא יודעת*
    שהאות שלה בגודל אפס.

    התיקון: המדד משוקלל במשרעת. `corr × min(1, טווח/0.02)` — פה
    שנע פחות מ-2% רמות אפור מדולל לאפס גם אם הקורלציה מושלמת.
    נמדד אחרי התיקון: קפוא 0.06, מסונכרן 0.69.
    """
    env = np.asarray(list(envelope), dtype=np.float64)
    if sample.n < 8 or env.size < 8:
        return Check("lipsync", True, 0.0, min_corr, BLAME["lipsync"],
                     "קצר מכדי למדוד קורלציה")
    patch = _roi_slice(sample, mouth_roi)
    mouth = patch.reshape(sample.n, -1).std(axis=1)   # "פתיחת הפה"
    # דגימת המעטפת לאותם זמנים שבהם נדגמו הפריימים
    idx = np.clip((np.linspace(0, 1, mouth.size) * (env.size - 1)).round()
                  .astype(int), 0, env.size - 1)
    e = env[idx]
    if mouth.std() < 1e-9 or e.std() < 1e-9:
        return Check("lipsync", False, 0.0, min_corr, BLAME["lipsync"],
                     "אין שונות בפה או בשמע — הצינור כנראה לא חובר")
    corr = float(np.corrcoef(mouth, e)[0, 1])
    if math.isnan(corr):
        corr = 0.0
    rng = float(mouth.max() - mouth.min())
    amp = min(1.0, rng / 0.02)          # שקלול משרעת: רעש מקודד -> אפס
    score = max(0.0, corr) * amp
    return Check("lipsync", score >= min_corr, round(score, 4), min_corr,
                 BLAME["lipsync"],
                 f"קורלציה {corr:.2f} × משרעת {amp:.2f} = {score:.3f}"
                 f" (טווח פה {rng:.4f})")


# --------------------------------------------------------------- דוח

@dataclass
class Report:
    path: str
    passed: bool
    score: float
    checks: list[dict]
    width: int = 0
    height: int = 0
    fps: float = 0.0
    frames: int = 0
    seconds: float = 0.0

    @property
    def failures(self) -> list[dict]:
        return [c for c in self.checks if not c["passed"]]

    @property
    def blames(self) -> list[str]:
        out: list[str] = []
        for c in self.failures:
            if c["blame"] not in out:
                out.append(c["blame"])
        return out

    def to_dict(self) -> dict:
        d = asdict(self)
        d["blames"] = self.blames
        return d

    def text(self) -> str:
        lines = [f"{'✓ עבר' if self.passed else '✗ נכשל'}  {Path(self.path).name}"
                 f"  ·  {self.width}x{self.height} {self.fps:.0f}fps"
                 f"  ·  {self.seconds:.2f}ש  ·  ציון {self.score:.0f}/100"]
        for c in self.checks:
            mark = "  ✓" if c["passed"] else "  ✗"
            lines.append(f"{mark} {c['name']:<22} {c['detail']}")
        if self.failures:
            lines.append(f"  → אחראי לתיקון: {', '.join(self.blames)}")
        return "\n".join(lines)


def inspect(path: Path, expect_sec: float | None = None,
            expect_frames: int | None = None,
            dynamic_rois: dict[str, tuple[float, float, float, float]] | None = None,
            mouth_roi: tuple[float, float, float, float] | None = None,
            envelope: Iterable[float] | None = None,
            stride: int = 3, strict_edges: bool = True) -> Report:
    """מריץ את מערך הבדיקות על סרטון אחד ומחזיר דוח עם ציון ואשמה."""
    s = sample_video(Path(path), stride=stride)
    checks: list[Check] = [check_container(s, expect_frames)]

    if not s.decode_error and s.n:
        checks += [
            check_duration(s, expect_sec),
            check_blank(s),
            check_contrast(s),
            check_frozen(s),
            check_motion(s),
            check_loop(s),
        ]
        if strict_edges:
            checks.append(check_edge_safe(s))
        for label, spec in (dynamic_rois or {}).items():
            # spec הוא או ROI בלבד, או (ROI, חלון זמן)
            if (len(spec) == 2 and isinstance(spec[0], (tuple, list))):
                checks.append(check_static_roi(s, tuple(spec[0]), label,
                                               window=tuple(spec[1])))
            else:
                checks.append(check_static_roi(s, tuple(spec), label))
        if mouth_roi and envelope is not None:
            checks.append(check_lipsync(s, mouth_roi, envelope))

    score = 100.0 * sum(1 for c in checks if c.passed) / max(1, len(checks))
    return Report(
        path=str(path), passed=all(c.passed for c in checks),
        score=round(score, 1), checks=[c.to_dict() for c in checks],
        width=s.width, height=s.height, fps=s.fps,
        frames=s.frames_decoded,
        seconds=round(s.frames_decoded / s.fps, 2) if s.fps else 0.0,
    )


def main(argv: list[str]) -> int:
    import sys
    sys.stdout.reconfigure(encoding="utf-8")
    if not argv:
        print("שימוש: python -m studio.qa <סרטון> [משך_מצופה]")
        return 2
    expect = float(argv[1]) if len(argv) > 1 else None
    rep = inspect(Path(argv[0]), expect_sec=expect)
    print(rep.text())
    print(json.dumps(rep.to_dict(), ensure_ascii=False)[:0] or "", end="")
    return 0 if rep.passed else 1


if __name__ == "__main__":
    import sys
    raise SystemExit(main(sys.argv[1:]))
