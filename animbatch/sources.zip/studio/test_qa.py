# -*- coding: utf-8 -*-
"""בדיקות למודול בקרת האיכות — כל אחת מייצרת פגם *אמיתי* ודורשת שייתפס.

בדיקה שרק מוודאת שסרטון תקין עובר היא חצי בדיקה: היא עוברת גם
כשהמודול לא עושה כלום. לכן כל בדיקה כאן בונה קובץ MP4 עם פגם
מכוון, ואחריה בדיקת בקרה על קובץ נקי באותן מידות — כדי שאפשר
יהיה להפריד בין "הבדיקה תופסת" לבין "הבדיקה תמיד נדלקת".

הפגמים אינם המצאה: חמישה מהם קרו כאן בפועל ונתפסו רק בעין אנושית
(מונים תקועים על אפס, כתובית נחתכת, קובץ שהאיחוד הפיל בשקט,
סצנה שהתארכה פי עשרים, קו שלא הגיע לסופו).
"""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from studio import qa  # noqa: E402

W, H, FPS = 320, 180, 24


# ------------------------------------------------------------ בניית קבצים

def _write(path: Path, frames) -> Path:
    import av
    c = av.open(str(path), mode="w")
    st = c.add_stream("libx264", rate=FPS)
    st.width, st.height, st.pix_fmt = W, H, "yuv420p"
    st.options = {"crf": "20", "preset": "ultrafast"}
    for arr in frames:
        f = av.VideoFrame.from_ndarray(np.ascontiguousarray(arr), format="rgb24")
        for p in st.encode(f):
            c.mux(p)
    for p in st.encode():
        c.mux(p)
    c.close()
    return path


def _bg(i: int) -> np.ndarray:
    """רקע בסיס: גרדיאנט + ריבוע נע. סרטון לגיטימי לכל דבר."""
    y, x = np.mgrid[0:H, 0:W]
    a = np.zeros((H, W, 3), dtype=np.uint8)
    a[..., 0] = (20 + y * 0.5).astype(np.uint8)
    a[..., 1] = (30 + x * 0.25).astype(np.uint8)
    a[..., 2] = (60 + (x + y) * 0.2).astype(np.uint8)
    cx = int(30 + (W - 90) * (0.5 + 0.5 * np.sin(i / 11.0)))
    a[H // 2 - 18:H // 2 + 18, cx:cx + 44] = 235
    return a


def _counter_box(a: np.ndarray, value: int) -> np.ndarray:
    """תיבת "מונה": רצועת פיקסלים שאורכה נגזר מהערך.

    זה המקבילה המינימלית למונה מספרי על המסך — מונה שמתעדכן משנה
    פיקסלים, ומונה תקוע לא משנה אף אחד. בדיוק המדד שה-ROI בודק.
    """
    a = a.copy()
    a[12:30, 12:12 + max(1, min(60, value))] = 250
    return a


def clean(n: int = 72) -> list[np.ndarray]:
    return [_counter_box(_bg(i), 2 + i % 55) for i in range(n)]


# ------------------------------------------------------------ הבדיקות

def t_clean_passes(tmp: Path) -> tuple[bool, str]:
    p = _write(tmp / "clean.mp4", clean())
    r = qa.inspect(p, expect_sec=72 / FPS, stride=2)
    bad = [c["name"] for c in r.checks if not c["passed"]]
    return r.passed, f"ציון {r.score}; נכשלו: {bad or 'אין'}"


def t_truncated_caught(tmp: Path) -> tuple[bool, str]:
    """קובץ שנחתך באמצע — הפגם שהאיחוד השקט השאיר אחריו."""
    src = _write(tmp / "trunc_src.mp4", clean(120))
    dst = tmp / "trunc.mp4"
    dst.write_bytes(src.read_bytes()[: int(src.stat().st_size * 0.45)])
    r = qa.inspect(dst, stride=2)
    c = [x for x in r.checks if x["name"] == "container"][0]
    return (not r.passed) and not c["passed"], c["detail"][:70]


def t_frozen_caught(tmp: Path) -> tuple[bool, str]:
    frames = [_counter_box(_bg(0), 10)] * 72
    p = _write(tmp / "frozen.mp4", frames)
    r = qa.inspect(p, stride=2)
    names = {c["name"] for c in r.checks if not c["passed"]}
    return ("frozen" in names or "motion" in names), f"נכשלו: {sorted(names)}"


def t_blank_caught(tmp: Path) -> tuple[bool, str]:
    p = _write(tmp / "blank.mp4", [np.zeros((H, W, 3), np.uint8)] * 60)
    r = qa.inspect(p, stride=2)
    names = {c["name"] for c in r.checks if not c["passed"]}
    return "blank" in names, f"נכשלו: {sorted(names)}"


def t_loop_caught(tmp: Path) -> tuple[bool, str]:
    """חצי שני זהה לחצי ראשון — הסצנה שהתארכה פי עשרים."""
    half = clean(120)
    p = _write(tmp / "loop.mp4", half + half)
    r = qa.inspect(p, stride=2)
    c = [x for x in r.checks if x["name"] == "loop"][0]
    return not c["passed"], c["detail"]


def t_loop_not_false_positive(tmp: Path) -> tuple[bool, str]:
    """בקרה: סרטון ארוך שאינו מחזורי חייב *לעבור* את בדיקת הלופ."""
    p = _write(tmp / "noloop.mp4", clean(260))
    r = qa.inspect(p, stride=2)
    c = [x for x in r.checks if x["name"] == "loop"][0]
    return c["passed"], c["detail"]


def t_duration_caught(tmp: Path) -> tuple[bool, str]:
    p = _write(tmp / "long.mp4", clean(240))
    r = qa.inspect(p, expect_sec=72 / FPS, stride=3)
    c = [x for x in r.checks if x["name"] == "duration"][0]
    return not c["passed"], c["detail"]


def t_stuck_counter_caught(tmp: Path) -> tuple[bool, str]:
    """המונה שנשאר על אפס — התקלה שנתפסה כאן רק בהסתכלות על תמונות."""
    roi = {"מונה": (0.02, 0.05, 0.22, 0.14)}
    stuck = _write(tmp / "stuck.mp4", [_counter_box(_bg(i), 7) for i in range(72)])
    live = _write(tmp / "live.mp4", clean())
    rs = qa.inspect(stuck, dynamic_rois=roi, stride=2)
    rl = qa.inspect(live, dynamic_rois=roi, stride=2)
    cs = [x for x in rs.checks if x["name"].startswith("static_roi")][0]
    cl = [x for x in rl.checks if x["name"].startswith("static_roi")][0]
    ok = (not cs["passed"]) and cl["passed"]
    return ok, f"תקוע={cs['metric']} (נפל={not cs['passed']}) · חי={cl['metric']}"


def t_edge_crop_caught(tmp: Path) -> tuple[bool, str]:
    """טקסט שנחתך בקצה הקאדר — הכותרת שהשורה השנייה שלה נעלמה."""
    frames = []
    for i in range(72):
        a = _bg(i)
        a[0:6, 20:300:7] = 255          # "טקסט" חתוך בקצה העליון
        a[1:5, 24:296:9] = 10
        frames.append(a)
    p = _write(tmp / "crop.mp4", frames)
    r = qa.inspect(p, stride=2)
    c = [x for x in r.checks if x["name"] == "edge_safe"][0]
    return not c["passed"], c["detail"]


def t_lipsync_disconnected(tmp: Path) -> tuple[bool, str]:
    """פה שקפא בזמן שיש שמע — צינור שלא חובר, לא "שפתיים לא מדויקות".

    **הגרסה הראשונה של הבדיקה הזו הייתה שגויה בעצמה, ושווה לזכור
    למה.** היא הזיזה את הפה לפי `sin(i/4)` ובדקה קורלציה מול מעטפת
    שהיא `sin(linspace(0,9))` — שני אותות בתדרים שונים לגמרי. פה
    "מסונכרן" יצא 0.08 ונפל, בעוד פה קפוא יצא 0.52 ועבר, כי ה-ROI
    הרחב קלט את הרקע הנע. כלומר הבדיקה בדקה דבר אחר ממה שהצהירה.

    לכן כאן: הפה נגזר **מהמעטפת עצמה** באותו אינדקס, וה-ROI הדוק
    סביבו על רקע מקומי שאינו זז. זה מה שהבדיקה אמורה למדוד.
    """
    N = 96
    mouth = (0.44, 0.60, 0.09, 0.14)
    env = np.abs(np.sin(np.linspace(0, 9, N)))
    frozen, synced = [], []
    y0, x0 = int(H * 0.60), int(W * 0.44)
    for i in range(N):
        a = _bg(i)
        a[y0 - 2:y0 + 26, x0 - 2:x0 + 30] = 90    # לחי: רקע מקומי סטטי
        b = a.copy()
        open_px = max(1, int(round(22 * float(env[i]))))
        b[y0:y0 + open_px, x0:x0 + 26] = 250      # פה שנפתח לפי המעטפת
        a[y0:y0 + 3, x0:x0 + 26] = 250            # פה קפוא
        frozen.append(a)
        synced.append(b)
    pf = _write(tmp / "lip_frozen.mp4", frozen)
    ps = _write(tmp / "lip_sync.mp4", synced)
    rf = qa.inspect(pf, mouth_roi=mouth, envelope=env, stride=1)
    rs = qa.inspect(ps, mouth_roi=mouth, envelope=env, stride=1)
    cf = [x for x in rf.checks if x["name"] == "lipsync"][0]
    cs = [x for x in rs.checks if x["name"] == "lipsync"][0]
    return (not cf["passed"]) and cs["passed"], \
        f"קפוא={cf['metric']} (נפל={not cf['passed']}) · מסונכרן={cs['metric']}"


def t_blame_routing(tmp: Path) -> tuple[bool, str]:
    """כל בדיקה חייבת להצביע על תת-מערכת קיימת — אחרת אין לאן לתקן."""
    p = _write(tmp / "b.mp4", clean())
    r = qa.inspect(p, dynamic_rois={"x": (0.1, 0.1, 0.2, 0.2)}, stride=4)
    known = set(qa.BLAME.values())
    bad = [c["name"] for c in r.checks if c["blame"] not in known]
    return not bad, f"{len(r.checks)} בדיקות, כולן ממופות" if not bad else str(bad)


def t_memory_bounded(tmp: Path) -> tuple[bool, str]:
    """הדגימה חייבת להישאר קטנה — המכונה חנוקה בזיכרון."""
    p = _write(tmp / "mem.mp4", clean(240))
    s = qa.sample_video(p, stride=3)
    mb = s.gray.nbytes / 1048576
    return mb < 8.0 and s.n > 20, f"{s.n} דגימות, {mb:.2f}MB בזיכרון"


TESTS = [
    ("סרטון נקי עובר את כל הבדיקות", t_clean_passes),
    ("קובץ חתוך נתפס", t_truncated_caught),
    ("סצנה קפואה נתפסת", t_frozen_caught),
    ("פריים ריק נתפס", t_blank_caught),
    ("לופ מחזורי נתפס", t_loop_caught),
    ("סרטון לא-מחזורי אינו נתפס בטעות", t_loop_not_false_positive),
    ("משך שגוי נתפס", t_duration_caught),
    ("מונה תקוע על אותו ערך נתפס", t_stuck_counter_caught),
    ("טקסט חתוך בקצה הקאדר נתפס", t_edge_crop_caught),
    ("פה קפוא מול שמע נתפס, ומסונכרן אינו", t_lipsync_disconnected),
    ("כל בדיקה ממופה לתת-מערכת", t_blame_routing),
    ("הדגימה חסומה בזיכרון", t_memory_bounded),
]


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8")
    tmp = Path(tempfile.mkdtemp(prefix="qatest_"))
    ok = 0
    for name, fn in TESTS:
        try:
            passed, detail = fn(tmp)
        except Exception as exc:                      # noqa: BLE001
            passed, detail = False, f"{type(exc).__name__}: {exc}"
        print(f"{'✓' if passed else '✗'} {name:<42} {detail}")
        ok += bool(passed)
    print(f"\n{ok}/{len(TESTS)} עברו")
    return 0 if ok == len(TESTS) else 1


if __name__ == "__main__":
    raise SystemExit(main())
