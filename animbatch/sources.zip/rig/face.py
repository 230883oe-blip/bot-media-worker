# -*- coding: utf-8 -*-
"""Blendshapes של הפנים - מה שסיבוב עצם **לא** יכול לעשות.

למה בכלל. עד TASK 01 כל ריג הפנים היה סיבובי עצמות, וזה נכון ללסת,
ללשון, למבט, לעפעפיים ולגבות - כולם באמת מסתובבים סביב ציר. אבל
שלושה דברים שהמשתמש ביקש ב-TASK 02 אינם סיבוב בשום פירוש:

* **אף** - התרחבות נחיר היא תנועה לרוחב של כנף האף. עצם שמסתובבת
  תזיז את כל האזור המשוקלל אליה (חצי פנים), לא את הנחיר.
* **שפתיים** - כיווץ (pucker), חצוצרה (funnel), דחיסה (press) ומתיחה
  הם שינוי **צורה** של טבעת השפתיים. אין ציר.
* **אישון** - התרחבות היא סקייל. סקייל לא-אחיד על עצם מעור אינו יציב
  ב-three.js, והיועצים (Qwen, Command A) הזהירו מזה במפורש.

לכן: היברידי. עצמות לְמה שהוא סיבוב, blendshapes לְמה שאינו. הדלתות
נגזרות **אנליטית** מהגאומטריה שבנתה את הפנים (אותן יחידות של
`basemesh._head`: rel_y = (y-hc)/R, xn = |x-hc|/R), ולא מפוסלות ביד -
ולכן הן נכונות לכל דמות בלי כיול מחדש.

מלכודת שנמדדה: דלתא מוחלת ב-three.js **לפני** ה-skinning, כלומר בחלל
פוזת הכריכה. זה בדיוק מה שרוצים - דלתא על השפה התחתונה נסחבת אחר כך
עם הלסת, כמו בשר אמיתי. אבל זה גם אומר שאסור לחשב דלתא מתוך הפוזה
הנוכחית: הפוזה אינה קיימת בזמן הבנייה.
"""
from __future__ import annotations

import math

import numpy as np

# ------------------------------------------------------------ עזרי וקטור


def _ss(e0: float, e1: float, x):
    """smoothstep וקטורי. e0 יכול להיות גדול מ-e1 (יורד)."""
    x = np.asarray(x, dtype=np.float64)
    if abs(e1 - e0) < 1e-12:
        return (x >= e1).astype(np.float64)
    t = np.clip((x - e0) / (e1 - e0), 0.0, 1.0)
    return t * t * (3.0 - 2.0 * t)


def _band(center: float, half: float, x):
    """1 במרכז, 0 מעבר ל-half. פס רך דו-צדדי."""
    return _ss(half, 0.0, np.abs(np.asarray(x, float) - center))


# ------------------------------------------------------------ ההקשר


class FaceSpace:
    """כל מה שצריך כדי למקם דלתא על הפנים, פעם אחת ולכל הצורות.

    מרכז כל החישובים: אותן יחידות של `basemesh._head`. חישוב ביחידות
    מטרים היה נשבר בכל דמות עם ראש בגודל אחר - וזה בדיוק הבאג
    שהתגלה ב-05/10 (יחידת המידה של הפנים הייתה הגוף במקום הראש).
    """

    def __init__(self, mb, H):
        self.H = H
        self.V = np.asarray(mb.v, dtype=np.float64)
        self.n = self.V.shape[0]
        self.g = {name: (v0, v1) for name, v0, v1 in mb.groups}
        hc, R = H.hc, H.R
        self.R = float(R)
        self.hc = np.asarray(hc, float)
        self.rel_y = (self.V[:, 1] - hc[1]) / R
        self.xn = np.abs(self.V[:, 0] - hc[0]) / R
        self.xs = (self.V[:, 0] - hc[0]) / R          # עם סימן
        self.zn = (self.V[:, 2] - hc[2]) / R
        # frontness: רק מה שפונה קדימה. כל תווי הפנים מסתיימים כאן,
        # ובלי זה "התרחבות נחיר" מזיזה גם את העורף.
        self.front = _ss(0.0, 0.45, self.zn)
        self.y_rel = (self.V[:, 1] - (hc[1] - R)) / (2 * R)
        # TASK 11: משרעת החיוך היא **תכונת עיצוב** ולא הגדרה גלובלית.
        # זיגי מקבלת חיוך מוגזם שנמתח לרוחב, גרומפ חיוך מצומק. 1.0
        # הוא הערך שהיה, ולכן כל דמות אחרת אינה משתנה.
        self.smile = float(getattr(H, "fs", None).smile
                           if getattr(H, "fs", None) else 1.0)

    # --- מסכות לפי קבוצת קודקודים
    def mask_of(self, *names) -> np.ndarray:
        m = np.zeros(self.n, dtype=np.float64)
        for nm in names:
            if nm in self.g:
                v0, v1 = self.g[nm]
                m[v0:v1] = 1.0
        return m

    def side(self, tag: str) -> np.ndarray:
        """1 בצד המבוקש, 0 בצד השני, רך סביב מרכז הפנים."""
        s = self.xs if tag == "L" else -self.xs
        return _ss(-0.015, 0.045, s)

    # --- מרכז העין בפועל (אותה נקודה אחת שכל בוני העין משתמשים בה)
    def eye_c(self, tag: str) -> np.ndarray:
        return np.asarray(self.H.eye_center(tag), float)


# ------------------------------------------------------------ הצורות
# כל פונקציה מחזירה (N,3) דלתא במטרים, עבור משקולת 1.0.
# הכלל: הדלתא חייבת להיות 0 מחוץ לאזור שלה. צורה שמזיזה קודקוד אחד
# מחוץ לתחומה שוברת את ההפרדה בין האזורים - וזו בדיוק הדרישה
# המרכזית של TASK 02 ("independently control").

_SHAPES = {}


def shape(name: str, region: str):
    def deco(fn):
        _SHAPES[name] = (region, fn)
        return fn
    return deco


# ---- אף


def _nostril_mask(F, tag=None):
    """כנף האף. אותם מספרים שבנו את הנחיר ב-basemesh._head."""
    m = _band(0.075, 0.055, F.xn) * _band(-0.112, 0.062, F.rel_y) * F.front
    m = m * F.mask_of("head")
    if tag:
        m = m * F.side(tag)
    return m


@shape("nose_flare", "nose")
def _nose_flare(F):
    """הנחיריים מתרחבים. תנועה לרוחב - הסיבה שזה blendshape ולא עצם."""
    d = np.zeros_like(F.V)
    m = _nostril_mask(F)
    sgn = np.sign(F.xs)
    sgn[sgn == 0] = 1.0
    d[:, 0] = sgn * m * F.R * 0.052
    d[:, 1] = m * F.R * 0.016
    d[:, 2] = -m * F.R * 0.010
    return d


@shape("nose_wrinkle", "nose")
def _nose_wrinkle(F):
    """קמט על גשר האף (האף "מצטמק"). גשר האף: rel_y≈0.010."""
    d = np.zeros_like(F.V)
    m = _band(0.010, 0.145, F.rel_y) * _ss(0.085, 0.0, F.xn) * F.front
    m = m * F.mask_of("head")
    d[:, 1] = m * F.R * 0.030
    d[:, 2] = m * F.R * 0.020
    return d


def _sneer(F, tag):
    """כנף אף + שפה עליונה באותו צד עולות. אסימטרי מעצם הגדרתו -
    וזו הדוגמה הנקייה לכך שאסימטריה אינה "preset" אלא בקרה."""
    d = np.zeros_like(F.V)
    sd = F.side(tag)
    m = _nostril_mask(F, tag)
    d[:, 1] += m * F.R * 0.048
    d[:, 2] += m * F.R * 0.016
    lip = F.mask_of("lip_up") * sd
    d[:, 1] += lip * F.R * 0.038
    d[:, 2] += lip * F.R * 0.008
    return d


@shape("nose_sneer_L", "nose")
def _sneer_l(F):
    return _sneer(F, "L")


@shape("nose_sneer_R", "nose")
def _sneer_r(F):
    return _sneer(F, "R")


# ---- שפתיים
# השפתיים הן שתי קבוצות קודקודים משלהן (lip_up / lip_lo), ולכן
# הדלתות עליהן נקיות לחלוטין ואינן נוגעות בעור הפנים.


def _lip_t(F):
    """מיקום לרוחב השפה, -1 ימין .. +1 שמאל (ביחידות חצי רוחב הפה)."""
    return np.clip(F.xs / 0.255, -1.4, 1.4)


@shape("lip_pucker", "lips")
def _lip_pucker(F):
    """נשיקה: השפתיים קדימה ולמרכז. שינוי צורה טהור."""
    d = np.zeros_like(F.V)
    up, lo = F.mask_of("lip_up"), F.mask_of("lip_lo")
    m = up + lo
    t = _lip_t(F)
    d[:, 0] = -m * t * F.R * 0.105
    d[:, 2] = m * F.R * 0.072 * (1.0 - 0.45 * np.abs(t))
    d[:, 1] = (up - lo) * np.abs(t) * F.R * 0.012
    # הפילטרום והעור סביב הפה נסחבים מעט, אחרת השפה "נתלשת" מהפנים
    skin = _band(-0.26, 0.17, F.rel_y) * _ss(0.30, 0.10, F.xn) * \
        F.front * F.mask_of("head")
    d[:, 2] += skin * F.R * 0.016
    d[:, 0] += -skin * np.clip(F.xs / 0.26, -1, 1) * F.R * 0.020
    return d


@shape("lip_funnel", "lips")
def _lip_funnel(F):
    """חצוצרה ("או"): קדימה, אבל **פתוח** - עליונה מעלה, תחתונה מטה."""
    d = np.zeros_like(F.V)
    up, lo = F.mask_of("lip_up"), F.mask_of("lip_lo")
    t = _lip_t(F)
    taper = 1.0 - 0.50 * np.abs(t)
    d[:, 2] = (up + lo) * F.R * 0.060 * taper
    d[:, 1] += up * F.R * 0.030 * taper
    d[:, 1] -= lo * F.R * 0.034 * taper
    d[:, 0] = -(up + lo) * t * F.R * 0.072
    return d


@shape("lip_press", "lips")
def _lip_press(F):
    """דחיסה: השפתיים נלחצות זו לזו ונעשות דקות. סימן מובהק של
    התאפקות, ואחד משלושת המרכיבים שהמשתמש דרש בעצב."""
    d = np.zeros_like(F.V)
    up, lo = F.mask_of("lip_up"), F.mask_of("lip_lo")
    t = _lip_t(F)
    d[:, 1] -= up * F.R * 0.026
    d[:, 1] += lo * F.R * 0.030
    d[:, 2] -= (up + lo) * F.R * 0.016
    d[:, 0] += (up + lo) * t * F.R * 0.028       # נפרסות מעט לצדדים
    return d


def _lip_raise(F, tag):
    d = np.zeros_like(F.V)
    sd = F.side(tag)
    up = F.mask_of("lip_up") * sd
    d[:, 1] += up * F.R * 0.052
    d[:, 2] += up * F.R * 0.010
    return d


@shape("lip_up_raise_L", "lips")
def _lur_l(F):
    return _lip_raise(F, "L")


@shape("lip_up_raise_R", "lips")
def _lur_r(F):
    return _lip_raise(F, "R")


@shape("lip_lo_depress", "lips")
def _lip_lo_depress(F):
    """השפה התחתונה יורדת וחושפת את הפה - זה **לא** פתיחת לסת."""
    d = np.zeros_like(F.V)
    lo = F.mask_of("lip_lo")
    d[:, 1] -= lo * F.R * 0.058
    d[:, 2] -= lo * F.R * 0.006
    return d


def _corner(F, tag, sgn):
    """זווית הפה. sgn=+1 מעלה, -1 מטה. העור סביב הזווית נסחב איתה,
    אחרת מתקבלת שפה שנעה בתוך פנים קפואים."""
    d = np.zeros_like(F.V)
    t = _lip_t(F)
    w = _ss(0.35, 1.05, np.abs(t)) * (F.mask_of("lip_up") + F.mask_of("lip_lo"))
    w = w * F.side(tag)
    # TASK 11: המשרעת היא של הדמות (`facestyle.smile`). חיוך "נמתח
    # לרוחב" הוא בעיקר הרכיב ב-X, ולכן הוא מקבל את המכפיל במלואו.
    a = F.smile
    d[:, 1] += sgn * w * F.R * 0.072 * a
    d[:, 0] += w * np.sign(t) * F.R * 0.030 * a * (0.6 if sgn > 0 else -0.2)
    d[:, 2] += sgn * w * F.R * 0.010 * a
    skin = _band(-0.295, 0.13, F.rel_y) * _band(0.255, 0.14, F.xn) * \
        F.front * F.mask_of("head") * F.side(tag)
    d[:, 1] += sgn * skin * F.R * 0.040 * a
    return d


@shape("mouth_corner_up_L", "mouth")
def _cu_l(F):
    return _corner(F, "L", +1.0)


@shape("mouth_corner_up_R", "mouth")
def _cu_r(F):
    return _corner(F, "R", +1.0)


@shape("mouth_corner_down_L", "mouth")
def _cd_l(F):
    return _corner(F, "L", -1.0)


@shape("mouth_corner_down_R", "mouth")
def _cd_r(F):
    return _corner(F, "R", -1.0)


@shape("mouth_stretch", "mouth")
def _mouth_stretch(F):
    """הפה נמתח לרוחב ונעשה שטוח. פחד, מאמץ, חיוך מאולץ."""
    d = np.zeros_like(F.V)
    up, lo = F.mask_of("lip_up"), F.mask_of("lip_lo")
    t = _lip_t(F)
    m = up + lo
    d[:, 0] = m * t * F.R * 0.088 * F.smile
    d[:, 2] = -m * F.R * 0.020
    d[:, 1] = (lo - up) * F.R * 0.008
    return d


@shape("jaw_thrust", "jaw")
def _jaw_thrust(F):
    """הלסת נדחפת קדימה.

    הבקרה `jaw_fwd` קיימת בטבלת הבקרות מאז TASK 01 אבל **לא הייתה
    מיושמת כלל** ב-`controls.evaluate` - והסיבה טובה: דחיפת לסת
    קדימה היא הזזה, לא סיבוב, ואין לה ציר. היא מיושמת כאן, והשכבה
    ב-`acting.DRIVEN` מחברת את הבקרה הישנה לצורה הזו.
    """
    d = np.zeros_like(F.V)
    chin = _ss(0.26, 0.02, F.y_rel) * F.front * F.mask_of("head")
    d[:, 2] += chin * F.R * 0.052
    lo = F.mask_of("lip_lo")
    d[:, 2] += lo * F.R * 0.060
    d[:, 1] += lo * F.R * 0.010
    return d


@shape("mouth_dimple", "mouth")
def _mouth_dimple(F):
    """גומות: זוויות הפה נמשכות אחורה בלי לעלות. זה מה שמבדיל
    חיוך מנומס מחיוך אמיתי."""
    d = np.zeros_like(F.V)
    t = _lip_t(F)
    w = _ss(0.45, 1.05, np.abs(t)) * (F.mask_of("lip_up") + F.mask_of("lip_lo"))
    d[:, 2] -= w * F.R * 0.034
    d[:, 0] += w * np.sign(t) * F.R * 0.016
    skin = _band(-0.285, 0.10, F.rel_y) * _band(0.285, 0.10, F.xn) * \
        F.front * F.mask_of("head")
    d[:, 2] -= skin * F.R * 0.022
    return d


# ---- עיניים: פקיחה ואישון


def _eye_ring(F, tag):
    """מרחק מנורמל ממרכז העין, במישור XY (ביחידות R)."""
    c = F.eye_c(tag)
    dx = (F.V[:, 0] - c[0]) / F.R
    dy = (F.V[:, 1] - c[1]) / F.R
    return np.sqrt(dx * dx + dy * dy), dx, dy


def _orbit_x(F, mask, center, deg: float):
    """מגלגל קודקודים **סביב מרכז גלגל העין** בציר X, ולא מזיז אותם.

    **זה התיקון המרכזי של העפעפיים.** הגרסה הראשונה הרימה את העפעף
    ב-y בלבד: נמדד שהמרחק הממוצע שלו ממרכז העין קפץ מ-13.79 מ"מ
    ל-16.93, כלומר הוא התרומם 3.1 מ"מ **מעל** גלגל העין (רדיוס
    12.49) במקום להיגלל סביבו. התוצאה ברנדור: חלל כהה פעור מתחת
    לעפעף, שנראה בתקריב כמו חור שחור במקום עין פקוחה.

    עפעף אמיתי הוא קליפה על כדור. הוא מחליק על המעטפת, והמרחק
    ממרכז הכדור נשמר עד כדי דיוק המכונה. deg שלילי = גלילה
    מעלה-ואחורה, וזה הכיוון של פקיחה (לעליון) ושל התהדקות (לתחתון).
    """
    a = math.radians(deg)
    ca, sa = math.cos(a), math.sin(a)
    v = F.V - np.asarray(center, float)
    y2 = v[:, 1] * ca - v[:, 2] * sa
    z2 = v[:, 1] * sa + v[:, 2] * ca
    d = np.zeros_like(F.V)
    d[:, 1] = (y2 - v[:, 1]) * mask
    d[:, 2] = (z2 - v[:, 2]) * mask
    return d


def _eye_wide(F, tag):
    """העפעף העליון **נסוג** ונחשף לבן מעל הקשתית.

    זה לא ההיפך ממצמוץ. מצמוץ הוא סיבוב העצם `eyelid_up`; פקיחה
    רחבה היא נסיגה של העפעף **ומשיכה של העור שמעליו**, וזה בדיוק
    המרכיב "widened eyes" שהמשתמש דרש בהפתעה. בלי זה הפתעה נראית
    כמו פה פתוח בלבד.
    """
    c = F.eye_c(tag)
    lid = F.mask_of(f"eyelid_up_{tag}")
    lash = F.mask_of(f"lash_{tag}")
    lid_lo = F.mask_of(f"eyelid_lo_{tag}")
    d = _orbit_x(F, lid, c, -20.0)
    d += _orbit_x(F, lash, c, -18.0)
    d += _orbit_x(F, lid_lo, c, 7.0)      # התחתון יורד מעט
    # עור הארובה שמעל העין נמשך מעלה - אחרת העפעף נכנס לתוך העור
    r, _dx, dy = _eye_ring(F, tag)
    orb = _ss(0.34, 0.10, r) * _ss(-0.02, 0.09, dy) * F.front * F.mask_of("head")
    d[:, 1] += orb * F.R * 0.026
    return d


@shape("eye_wide_L", "eyelids")
def _ew_l(F):
    return _eye_wide(F, "L")


@shape("eye_wide_R", "eyelids")
def _ew_r(F):
    return _eye_wide(F, "R")


def _lower_lid_raise(F, tag):
    """העפעף התחתון עולה בלי שהעליון יורד. זה ה"narrowed eyes" של
    חשד - שונה לגמרי מעצימה (שבה **שני** העפעפיים נפגשים)."""
    c = F.eye_c(tag)
    # גלילה על המעטפת, לא הרמה - מאותה סיבה בדיוק כמו בפקיחה.
    d = _orbit_x(F, F.mask_of(f"eyelid_lo_{tag}"), c, -17.0)
    r, _dx, dy = _eye_ring(F, tag)
    skin = _ss(0.30, 0.08, r) * _ss(0.01, -0.08, dy) * F.front * F.mask_of("head")
    d[:, 1] += skin * F.R * 0.022
    return d


@shape("lid_tighten_L", "eyelids")
def _lt_l(F):
    return _lower_lid_raise(F, "L")


@shape("lid_tighten_R", "eyelids")
def _lt_r(F):
    return _lower_lid_raise(F, "R")


def _pupil(F, tag):
    """התרחבות אישון.

    האישון אינו גוף נפרד - הוא **צבע שנצרב לקודקודי הקרנית** לפי
    הרדיוס (`detail._iris_tag`). לכן הזזה רדיאלית של קודקודי הקרנית
    חוצה גוררת את הצבע איתה, והאישון באמת גדל. זה גם בדיוק הטריק
    שמאפשר לעשות את זה בלי טקסטורה ובלי שיידר מיוחד.
    """
    d = np.zeros_like(F.V)
    c = F.eye_c(tag)
    m = F.mask_of(f"cornea_{tag}")
    v = F.V - c
    rr = np.linalg.norm(v[:, :2], axis=1)
    rr = np.where(rr < 1e-9, 1.0, rr)
    # הקודקודים הפנימיים נדחפים חוצה, השוליים כמעט לא - כך קוטר
    # האישון גדל והקשתית נדחסת, במקום שהקרנית כולה תתנפח.
    w = m * _ss(0.42, 0.0, rr / (0.012 * F.H.k))
    d[:, 0] = w * (v[:, 0] / rr) * 0.0042 * F.H.k
    d[:, 1] = w * (v[:, 1] / rr) * 0.0042 * F.H.k
    return d


@shape("pupil_dilate_L", "gaze")
def _pd_l(F):
    return _pupil(F, "L")


@shape("pupil_dilate_R", "gaze")
def _pd_r(F):
    return _pupil(F, "R")


# ---- לחיים


def _cheek_raise(F, tag):
    """הרמת הלחי סביב העין (orbicularis oculi).

    זה ה"סימן של דושן": חיוך שמרים רק את הפה הוא חיוך מנומס, חיוך
    שמרים גם את הלחי הוא חיוך אמיתי. העצם `cheek_L` מסתובבת ומזיזה
    את זווית הפה; מה שחסר הוא ההתנפחות **מתחת לעין**, והיא לא סיבוב.
    """
    d = np.zeros_like(F.V)
    r, _dx, dy = _eye_ring(F, tag)
    m = _ss(0.40, 0.10, r) * _ss(0.04, -0.10, dy) * F.front * F.mask_of("head")
    d[:, 1] += m * F.R * 0.040
    d[:, 2] += m * F.R * 0.020
    lid = F.mask_of(f"eyelid_lo_{tag}")
    d[:, 1] += lid * F.R * 0.026
    return d


@shape("cheek_raise_L", "cheeks")
def _cr_l(F):
    return _cheek_raise(F, "L")


@shape("cheek_raise_R", "cheeks")
def _cr_r(F):
    return _cheek_raise(F, "R")


def _cheek_hollow(F, tag):
    """שאיבת לחיים פנימה. ההיפך מניפוח, ואינו אותה בקרה.

    **שים לב ל-y_rel ולא rel_y.** אזור השקע מוגדר ב-`basemesh._head`
    (המשתנה `hollow`) ביחידות y_rel - 0 בסנטר, 1 בקודקוד - ולא
    ביחידות R סביב מרכז הראש. הגרסה הראשונה כאן קראה 0.40 ב-rel_y,
    כלומר **באזור העיניים**, וזה אותו באג יחידות שתוקן ב-05/10 באף.
    הסימן שתפס אותו: שמאל הזיז 881 קודקודים וימין 574 - אסימטריה
    שאין לה שום סיבה בצורה סימטרית.
    """
    d = np.zeros_like(F.V)
    # **עוגן עצם ולא פס גאומטרי.** מסכה שמוגדרת כ"טווח גובה כפול
    # טווח רוחב" תלויה בצפיפות הסריג, והסריג של הראש אינו סימטרי:
    # נמדד שאותה מסכה בדיוק תופסת 1059 קודקודים משמאל ו-680 מימין,
    # ומרכז המסה של התזוזה יצא שונה ב-7.8 מ"מ בעומק בין הצדדים.
    # מרחק מעצם הלחי הוא מדד סימטרי מעצם הגדרתו - וזו בדיוק הסיבה
    # ש-`cheek_raise`, שנמדד ממרכז העין, יצא סימטרי מההתחלה.
    cp = np.asarray(F.H.P[f"cheek_{tag}"], float)
    dc = np.linalg.norm(F.V - cp, axis=1) / F.R
    m = _ss(0.52, 0.14, dc) * F.front * F.mask_of("head")
    sgn = 1.0 if tag == "L" else -1.0
    d[:, 2] -= m * F.R * 0.044
    d[:, 0] -= m * sgn * F.R * 0.022
    return d


@shape("cheek_hollow_L", "cheeks")
def _ch_l(F):
    return _cheek_hollow(F, "L")


@shape("cheek_hollow_R", "cheeks")
def _ch_r(F):
    return _cheek_hollow(F, "R")


# ------------------------------------------------------------ בנייה

#: סדר קבוע. האינדקס של כל צורה ב-GLB נגזר מכאן, ולכן **אסור** לשנות
#: את הסדר בלי לבנות מחדש את כל הדמויות - אחרת "התרחבות נחיר" תפעיל
#: "הורדת שפה תחתונה", בלי שום שגיאה.
NAMES: list[str] = list(_SHAPES)

REGION_OF: dict[str, str] = {k: v[0] for k, v in _SHAPES.items()}

REGIONS: dict[str, list[str]] = {}
for _n, (_r, _f) in _SHAPES.items():
    REGIONS.setdefault(_r, []).append(_n)


def build(mb, H, min_mm: float = 0.05) -> dict:
    """מחשב את כל הדלתות. מחזיר {"names": [...], "deltas": (S,N,3) float32,
    "report": {...}}.

    min_mm: צורה שהתזוזה המקסימלית שלה קטנה מזה היא **באג**, לא צורה -
    בדרך כלל מסכה שלא פגעה באף קודקוד (למשל שינוי שם קבוצה). היא
    נרשמת בדוח כ-dead כדי שהבדיקה תיפול, ולא נעלמת בשקט.
    """
    F = FaceSpace(mb, H)
    S = len(NAMES)
    out = np.zeros((S, F.n, 3), dtype=np.float32)
    report = {}
    for i, nm in enumerate(NAMES):
        region, fn = _SHAPES[nm]
        d = np.asarray(fn(F), dtype=np.float64)
        if d.shape != (F.n, 3):
            raise ValueError(f"צורה {nm} החזירה {d.shape} ולא {(F.n, 3)}")
        if not np.all(np.isfinite(d)):
            raise ValueError(f"צורה {nm} החזירה nan/inf")
        mag = np.linalg.norm(d, axis=1)
        moved = int(np.count_nonzero(mag > 1e-6))
        report[nm] = {
            "region": region,
            "verts_moved": moved,
            "max_mm": round(float(mag.max()) * 1000.0, 3),
            "mean_mm": round(float(mag[mag > 1e-6].mean() * 1000.0)
                             if moved else 0.0, 3),
            "dead": bool(float(mag.max()) * 1000.0 < min_mm),
        }
        out[i] = d.astype(np.float32)
    return {"names": list(NAMES), "deltas": out, "report": report,
            "regions": {k: list(v) for k, v in REGIONS.items()}}


def weights_vector(morph: dict | None, names: list[str] | None = None):
    """ממפה {"שם": משקולת} לווקטור לפי הסדר הקבוע. שם לא מוכר זורק -
    שגיאת כתיב במשקולת היא בדיוק סוג הבאג שנעלם בשקט."""
    names = names or NAMES
    idx = {n: i for i, n in enumerate(names)}
    v = np.zeros(len(names), dtype=np.float64)
    for k, val in (morph or {}).items():
        if k not in idx:
            raise KeyError(f"אין צורת פנים בשם {k!r}")
        v[idx[k]] = float(np.clip(val, -1.0, 1.0))
    return v


def apply_morphs(position: np.ndarray, deltas: np.ndarray,
                 morph: dict | None, names: list[str] | None = None):
    """מחיל את הצורות על העמדות (לפני skinning) - הגרסה הפייתונית של
    מה ש-three.js עושה. קיים כדי שהבדיקות ימדדו את אותה תוצאה."""
    w = weights_vector(morph, names)
    nz = np.nonzero(w)[0]
    p = np.asarray(position, dtype=np.float64).copy()
    for i in nz:
        p += deltas[i] * w[i]
    return p
