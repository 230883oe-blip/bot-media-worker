# -*- coding: utf-8 -*-
r"""אימות סגירת פערי ARKit-52 - **רץ בענן, לא כאן**.

ההנחיה שהולידה את הקובץ (08/10/2026, המשתמש):
"עקוף לחלוטין את בדיקת הזיכרון המקומי, אל תחכה שיתפנה מקום במחשב, ונתב
את כל משימת סגירת הפערים הזו באופן ישיר לענן באמצעות heavycloud.submit
ותשתית ה-GitHub Actions."

למה זה באמת מצדיק ענן, ולא רק כי ביקשו: הבנייה המלאה של שמונה דמויות
(`cast_disney.audit(quality="full")`) מחזיקה בבת אחת רשת מלאה **ומטריצת
דלתות של (S,N,3) float32 לכל דמות**. עם שלושים צורות זה פי 30 מהרשת,
ועל מכונה של 7.5GB עם 1.6 פנויים זה בדיוק התרחיש שבגללו `heavycloud`
נכתב. רנר של גיטהאב מקבל 16GB נקיים, ולכן המדידה שם גם אפשרית וגם
ניתנת לשחזור - מה שהיא לא כאן.

מה נמדד, בארבעה חלקים שכל אחד עומד בפני עצמו:
  A. חבילת הבדיקות המלאה של הריג (תהליך נפרד, כדי ש-`SystemExit` או
     קריסה בבדיקה אחת לא ייקחו איתם את כל האימות).
  B. שער המיפוי `arkit.audit()` - האם מישהו המציא יעד שאינו קיים.
  C. שבע הצורות החדשות, על **שמונה גבהי דמות שונים**. הטענה שהצורות
     "נכונות לכל דמות בלי כיול" נבדקת כאן ולא מוכרזת.
  D. ביקורת הצוות המלאה - החלק הכבד.

הפלט הוא JSON אחד ל-`arkitgap/result.json`, והוא נאסף כ-artifact.
"""
from __future__ import annotations

import json
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

#: שבע הצורות שנבנו 08/10 כדי לסגור את שבע המשבצות הנעדרות, ולצידן
#: משבצת התקן שכל אחת מהן מניעה. הזוג מופיע כאן במפורש כדי שהמדידה
#: תיפול אם מישהו יחבר צורה למשבצת אחרת.
NEW_SHAPES = {
    "mouth_close":   "mouthClose",
    "mouth_shift_L": "mouthLeft",
    "mouth_shift_R": "mouthRight",
    "lip_roll_up":   "mouthRollUpper",
    "lip_roll_lo":   "mouthRollLower",
    "lip_shrug_up":  "mouthShrugUpper",
    "lip_shrug_lo":  "mouthShrugLower",
}

#: שמונה גבהים, בטווח של הצוות (ילדה קטנה עד גבר גבוה). הצורות
#: מחושבות ביחידות רדיוס הראש, ולכן גובה הוא בדיוק הפרמטר שאמור
#: *לא* לשנות את התוצאה היחסית - וזה מה שנמדד כאן.
HEIGHTS = (1.12, 1.26, 1.41, 1.55, 1.63, 1.70, 1.82, 1.95)


def part_a_tests() -> dict:
    """חבילת הבדיקות המלאה, בתהליך נפרד."""
    t0 = time.perf_counter()
    try:
        p = subprocess.run([sys.executable, "-m", "rig.test_rig"],
                           cwd=str(ROOT), capture_output=True, timeout=2700)
    except subprocess.TimeoutExpired:
        return {"ok": False, "why": "חבילת הבדיקות עברה 45 דקות"}
    out = (p.stdout or b"").decode("utf-8", "replace")
    err = (p.stderr or b"").decode("utf-8", "replace")
    # שורת הסיכום היא "<עברו>/<סה"כ> עברו". קוראים אותה ולא סופרים
    # ✓ ידנית: ספירה ידנית הייתה מפספסת בדיקה שקרסה לפני ההדפסה.
    passed = total = -1
    for ln in reversed(out.splitlines()):
        ln = ln.strip()
        if "/" in ln and ln.endswith("עברו"):
            try:
                a, b = ln.split(" ")[0].split("/")
                passed, total = int(a), int(b)
            except ValueError:
                continue
            break
    fails = [ln.strip() for ln in out.splitlines() if ln.strip().startswith("✗")]
    # **הבחנה שעלתה תקלה 08/10:** ריצה שקרסה באמצע (`Traceback` ב-
    # stderr ובלי שורת סיכום) אינה "נכשלו 5 בדיקות" - כל הבדיקות
    # שאחרי נקודת הקריסה לא רצו בכלל, ודוח שמונה חמישה כשלים על
    # ריצה כזו מטעה לחלוטין. הראיה: בסבב הראשון כאן הקריסה הייתה
    # בבדיקה 12 מתוך 48, כלומר `t_arkit` - זו שבגללה הכול נעשה -
    # לא רצה, והדוח נראה כאילו היא עברה.
    crashed = passed < 0 and "Traceback" in err
    return {"ok": p.returncode == 0 and passed >= 0 and passed == total,
            "crashed_midway": crashed,
            "returncode": p.returncode, "passed": passed, "total": total,
            "failures": fails[:40], "seconds": round(time.perf_counter() - t0, 1),
            "stderr_tail": err[-1500:]}


def part_b_gate() -> dict:
    from rig import arkit
    a = arkit.audit()
    cov = a["coverage"]
    return {"ok": bool(a["ok"]) and not a["absent"] and cov["driven"] == 52,
            "problems": a["problems"], "absent": a["absent"],
            "driven": cov["driven"], "exact": cov["exact"],
            "shared": cov["shared"], "morph_targets": a["morph_targets"],
            "describe": arkit.describe()}


def part_c_shapes() -> dict:
    """שבע הצורות, על שמונה גבהים. זה הלב של האימות."""
    import numpy as np
    from rig import arkit, basemesh, detail, face
    from rig.skeleton import Skeleton

    per_height: list[dict] = []
    problems: list[str] = []

    for h in HEIGHTS:
        sk = Skeleton(h)
        mb, _meta = basemesh.build(sk)
        P = {b.name: np.asarray(b.rest, float) for b in sk.bones}
        H = detail.Head(P, 1.0)
        M = face.build(mb, H)
        pos = np.asarray(mb.v, float)
        rep = M["report"]
        row: dict = {"height": h, "verts": int(pos.shape[0]), "shapes": {}}

        for shp, slot in NEW_SHAPES.items():
            if shp not in rep:
                problems.append(f"{h}: הצורה {shp} אינה בדוח הבנייה")
                continue
            r = rep[shp]
            # ההנעה עוברת דרך שם **התקן**, ולא דרך שם הצורה הפרטי.
            # זו כל הנקודה של השכבה: כלי לכידה חיצוני לא מכיר את
            # השמות שלנו.
            ctl, mph = arkit.drive({slot: 1.0})
            p = face.apply_morphs(pos, M["deltas"], mph, M["names"])
            d = p - pos
            mag = np.linalg.norm(d, axis=1)
            moved = int(np.count_nonzero(mag > 1e-9))
            mm = float(mag.max()) * 1000.0
            dx = float(d[:, 0].sum() / max(moved, 1))
            # ביחידות רדיוס הראש - הגודל שאמור להיות קבוע בין דמויות.
            rel = mm / 1000.0 / float(H.R)
            row["shapes"][shp] = {
                "slot": slot, "mph": mph, "verts_moved": moved,
                "max_mm": round(mm, 3), "rel_of_head_R": round(rel, 5),
                "dx_mean": round(dx, 7), "dead": bool(r["dead"]),
            }
            if r["dead"] or mm < 0.05:
                problems.append(f"{h}: {shp} אינה מזיזה דבר ({mm:.3f} מ\"מ)")
            if moved == 0:
                problems.append(f"{h}: {shp} לא נגעה באף קודקוד")
            if mph.get(shp) != 1.0:
                problems.append(
                    f"{h}: {slot} אינו מניע את {shp} במלוא המשקל ({mph})")

        # זוג הכיוונים: הזזת הפה שמאלה וימינה חייבות להיות הפוכות
        # בציר הרוחב ושוות בגודלן. כאן נתפסת גם טעות סימן וגם מסכה
        # א-סימטרית שהתגנבה מהסריג.
        sl = row["shapes"].get("mouth_shift_L", {})
        sr = row["shapes"].get("mouth_shift_R", {})
        if sl and sr:
            dl, dr = sl["dx_mean"], sr["dx_mean"]
            row["shift_opposed"] = bool(dl * dr < 0)
            row["shift_balance"] = round(
                abs(abs(dl) - abs(dr)) / max(abs(dl), abs(dr), 1e-12), 4)
            if dl * dr >= 0:
                problems.append(f"{h}: תזוזת הפה לרוחב אינה הפוכה "
                                f"({dl:+.6f} / {dr:+.6f})")
            if row["shift_balance"] > 0.12:
                problems.append(f"{h}: תזוזת הפה לרוחב א-סימטרית "
                                f"({row['shift_balance']})")

        row["total_shapes"] = len(M["names"])
        row["dead_any"] = sorted(k for k, v in rep.items() if v["dead"])
        if row["dead_any"]:
            problems.append(f"{h}: צורות מתות בריג: {row['dead_any']}")
        per_height.append(row)

    # קביעות בין דמויות: המשרעת ביחידות רדיוס הראש חייבת להיות זהה
    # בכל הגבהים. פיזור גדול כאן פירושו שנכתבה צורה ביחידות מטרים -
    # בדיוק באג היחידות שתועד ב-`face.py` ב-05/10.
    spread: dict[str, float] = {}
    for shp in NEW_SHAPES:
        vals = [r["shapes"][shp]["rel_of_head_R"] for r in per_height
                if shp in r["shapes"]]
        if len(vals) < 2:
            continue
        lo, hi = min(vals), max(vals)
        spread[shp] = round((hi - lo) / max(hi, 1e-12), 5)
        if spread[shp] > 0.02:
            problems.append(f"{shp}: המשרעת היחסית משתנה בין דמויות "
                            f"({spread[shp]}) - חשד ליחידות מטרים")

    return {"ok": not problems, "problems": problems,
            "scale_spread": spread, "per_height": per_height}


def part_d_cast() -> dict:
    """ביקורת הצוות המלאה - החלק שחונק את המכונה המקומית."""
    t0 = time.perf_counter()
    try:
        from rig import cast_disney as CD
        rep = CD.audit(quality="full")
    except MemoryError as exc:
        return {"ok": False, "why": f"זיכרון: {exc}"}
    except Exception as exc:                                   # noqa: BLE001
        return {"ok": False, "why": f"{type(exc).__name__}: {exc}"}
    # הדוח של `audit` משתנה בין גרסאות; נשמר כמו שהוא ונחלץ ממנו רק
    # מה שבטוח קיים, כדי שהאימות לא ייפול על שינוי מבנה.
    small = {k: v for k, v in rep.items()
             if isinstance(v, (int, float, bool, str))}
    return {"ok": bool(rep.get("ok", rep.get("passed", True))),
            "summary": small, "seconds": round(time.perf_counter() - t0, 1)}


#: אילו חלקים רצים בכל עבודה. הפיצול הוא כדי שמדידת הצורות (שנייה
#: אחת) לא תחכה לחבילת הבדיקות (עשר דקות) - ובעיקר כדי שכשל באחת
#: ייראה בנפרד מכשל בשנייה. `all` הוא ברירת המחדל כשמריצים ביד.
PARTS = {
    "shapes": (("b_gate", "part_b_gate"), ("c_shapes", "part_c_shapes"),
               ("d_cast", "part_d_cast")),
    "tests":  (("a_tests", "part_a_tests"),),
    "all":    (("b_gate", "part_b_gate"), ("c_shapes", "part_c_shapes"),
               ("a_tests", "part_a_tests"), ("d_cast", "part_d_cast")),
}

#: מי חוסם. `d_cast` מודד איכות ומבנה הדוח שלו משתנה בין גרסאות, ולכן
#: הוא **אינו** עילה לכשל של סגירת הפערים. השלושה האחרים כן.
BLOCKING = ("b_gate", "c_shapes", "a_tests")


def main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    only = "all"
    if "--only" in argv:
        i = argv.index("--only")
        if i + 1 < len(argv):
            only = argv[i + 1]
    if only not in PARTS:
        print(f"--only חייב להיות אחד מ-{sorted(PARTS)}")
        return 2

    out: dict = {"started": time.strftime("%Y-%m-%d %H:%M:%S"),
                 "python": sys.version.split()[0],
                 "where": "github-actions", "part": only}
    for name, fname in PARTS[only]:
        fn = globals()[fname]
        try:
            out[name] = fn()
        except Exception as exc:                               # noqa: BLE001
            out[name] = {"ok": False,
                         "why": f"{type(exc).__name__}: {exc}"}
        print(f"[{name}] ok={out[name].get('ok')}", flush=True)

    ran = [k for k in BLOCKING if k in out]
    out["ok"] = bool(ran) and all(out[k].get("ok") for k in ran)
    dest = HERE / "result.json"
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(json.dumps(out, ensure_ascii=False, indent=1),
                    encoding="utf-8")
    print(f"\nנכתב {dest} · ok={out['ok']}")
    return 0 if out["ok"] else 1


if __name__ == "__main__":
    sys.exit(main())
