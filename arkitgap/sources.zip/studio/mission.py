# -*- coding: utf-8 -*-
"""שכבת הניהול של המשימה — שער איכות, גרסאות, ולולאה אוטונומית.

מה כבר היה כאן לפני הקובץ הזה, ולכן **אינו** נכתב בו מחדש:

* ``studio/baseline.py`` — שתים-עשרה קטגוריות נמדדות, בסיס מוגן
  (``BASELINE_V0``), השוואה וזיהוי נסיגה.
* ``studio/critics.py`` + ``studio/panel.py`` — חמישה מבקרים עצמאיים,
  ווטו, בחירת החוליה החלשה, ולולאת ``RefineLoop`` ברמת שוט בודד.
* ``studio/master.py`` — שלושת מבחני תקן הזהב וציון קולנועי מלא.
* ``studio/qa.py`` — בקרת איכות טכנית על הסרטון עצמו.
* ``studio/director.py`` — גרסאות וסנסיגה ברמת **שוט**.

שלוש חוליות היו חסרות, וכולן ברמת ה**מערכת** ולא ברמת השוט:

1. **שער איכות עם ספים מוחלטים.** ``baseline.gate`` בדק רק "לא נסוגנו
   מול הבסיס", כלומר מערכת שעמדה על 60 והמשיכה לעמוד על 60 עברה אותו.
   כאן נאכפים שלושה-עשר הספים (סיפור 90 ... רציפות 95, טכני 95), אפס
   כשלים קריטיים, ואי-נסיגה — שלושתם יחד.
2. **שרשרת גרסאות עם אב ונסיגה.** ``director`` יודע לחזור בשוט; לא הייתה
   דרך לחזור בגרסה של המערכת כולה.
3. **לולאת המשימה.** בחירת השלב הבא לפי תלות וקדימות חישוב, ואיסור
   מוחלט להתקדם כששלב נוכחי נושא כשל קריטי.

החלטות שנשמרות כאן בכוונה, כל אחת מהן נגזרת מכשל שנמדד בפרויקט הזה:

* **אין ממוצע בשער.** ממוצע מסתיר כשל קטסטרופלי של ממד אחד. האיחוד הוא
  מינימום בין המקורות של אותו ממד, וההכרעה היא "כולם מעל הסף".
* **"אין מערכת" אינו "לא נמדד".** הראשון הוא כשל קריטי; השני הוא תקלת
  סביבה ואינו נסיגה באיכות. ``baseline`` כבר מבדיל ביניהם, והשער מכבד
  את ההבחנה במקום לשטח אותה.
* **נסיגה מרוככת ברעש מדידה** (``baseline.NOISE``).
* **נסיגה אחורה היא ``git checkout <commit> -- <file>`` קובץ-קובץ**,
  לעולם לא ``reset --hard``: בתיקייה הזו יש קובצי מצב ותוצרים שאינם
  של הגרסה, ושחזור גורף מוחק עבודה.
"""

from __future__ import annotations

import argparse
import json
import math
import subprocess
import sys
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Callable, Optional, Sequence

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from studio import baseline as B                              # noqa: E402

#: איפה יושבת שרשרת הגרסאות. בתוך הפרויקט, כדי שתיכנס למאגר הגרסאות.
STORE = ROOT / "production" / "versions"

#: שם הגרסה הראשונה, שאינה נהרסת לעולם.
V0 = "BASELINE_V0"

#: ציון מתחת לזה הוא כשל קריטי בכל ממד, ללא תלות בסף שלו. הסף נלקח
#: מ-``panel.HARD_FLOOR`` ולא הומצא כאן — אותו רף, אותה משמעות.
HARD_FLOOR = 40.0


# ====================================================== ממדי האיכות

@dataclass(frozen=True)
class Dim:
    """ממד איכות אחד: סף, קדימות חישוב, ומאיפה הציון נגזר.

    ``sources`` הם מפתחות בצורת ``"<מקור>:<מפתח>"``, והמקורות הם
    ``baseline`` (שתים-עשרה הקטגוריות), ``critic`` (חמשת המבקרים),
    ``master`` (מבחני תקן הזהב) ו-``qa`` (בקרה טכנית). ממד עם שני
    מקורות מקבל את ה**מינימום** שלהם: שני מודדים שחולקים על אותו
    ממד הם שתי עדויות, והחמורה מביניהן היא זו שקובעת אם לשחרר.
    """

    key: str
    label: str
    threshold: float
    priority: str
    sources: tuple[str, ...]


#: שלושה-עשר הממדים ושלושה-עשר הספים, כפי שהוגדרו במשימה.
#: ``emotion`` של ``baseline`` נכנס תחת ``acting`` ולא כממד נפרד —
#: במשימה אין לו סף משלו, והיא קובעת במפורש שסינכרון שפתיים לבדו
#: אינו משחק, כלומר הרגש הוא מקור המשחק ולא שכן שלו.
DIMS: tuple[Dim, ...] = (
    Dim("story",      "סיפור",     90.0, "P0", ("critic:story",)),
    Dim("character",  "זהות",      90.0, "P0", ("baseline:identity",)),
    Dim("acting",     "משחק",      90.0, "P1", ("critic:acting",
                                                "baseline:emotion")),
    Dim("face",       "פנים",      90.0, "P1", ("baseline:face",)),
    Dim("eyes",       "עיניים",    90.0, "P1", ("baseline:eyes",)),
    Dim("body",       "גוף",       88.0, "P1", ("baseline:body",
                                                "baseline:hands")),
    Dim("animation",  "אנימציה",   88.0, "P2", ("baseline:animation",
                                                "critic:animation")),
    Dim("camera",     "מצלמה",     88.0, "P2", ("baseline:camera",
                                                "critic:cinematography")),
    Dim("lighting",   "תאורה",     85.0, "P3", ("baseline:lighting",)),
    Dim("visual",     "מראה",      85.0, "P3", ("baseline:rendering",
                                                "critic:visual")),
    Dim("sound",      "קול",       88.0, "P1", ("baseline:lipsync",
                                                "master:audio")),
    Dim("continuity", "רציפות",    95.0, "P0", ("baseline:continuity",)),
    Dim("technical",  "טכני",      95.0, "P0", ("qa:technical",)),
)

DIM_BY_KEY: dict[str, Dim] = {d.key: d for d in DIMS}

#: סדר הקדימות של עבודת החישוב. ככל שהמספר קטן — כך קודם.
PRIORITY_ORDER = ("P0", "P1", "P2", "P3", "P4", "P5")

#: כמה דרגות מתחת לכשל הדחוף ביותר מוקפאות. המשימה אומרת את זה
#: במפורש: כשהמשחק (P1) נכשל, אין להשקיע חישוב בליטוש הרינדור (P5).
#:
#: הגרסה הראשונה כאן קבעה **רשימה** של דרגות מוקפאות (``P4``, ``P5``),
#: והבדיקה תפסה שזה באג ולא דקדוק: אין בפרויקט הזה אף ממד ב-P4 או
#: ב-P5, ולכן ההקפאה לא נדלקה **אף פעם** — היא נראתה נכונה בקוד
#: והייתה מכובה בשקט. פער יחסי נדלק לבד בכל הרכב ממדים.
DEFER_GAP = 2

#: כשל בקדימות הזו ומעלה הוא זה שמקפיא. מתחתיו אין הקפאה בכלל.
BLOCKING_PRIORITIES = ("P0", "P1")


def _pri_rank(p: str) -> int:
    try:
        return PRIORITY_ORDER.index(p)
    except ValueError:
        return len(PRIORITY_ORDER)


# ====================================================== איסוף הציונים

def _is_num(x) -> bool:
    return isinstance(x, (int, float)) and not isinstance(x, bool) \
        and not (isinstance(x, float) and (math.isnan(x) or math.isinf(x)))


def _finding_code(item) -> str:
    """קוד הכשל מתוך רשומת אבחון של מבקר, בצורת ``"<code> ✗"``.

    ``panel`` מחזיר ``list[dict]`` עם ``code``/``label``/``value``/
    ``limit``/``repair``. מה שנשמר כאן הוא ה**קוד** ועוד הסימן,
    כדי ששתי משפחות הראיות — הבוליאנית של ``from_checks`` והרציפה
    של ``from_metrics`` — יגיעו לאבחון באותה צורה בדיוק. פורמט
    אחד פירושו קורא אחד, ולכן גם באג אחד ולא שלושה.
    """
    if isinstance(item, dict):
        code = str(item.get("code") or "").strip()
    else:
        code = str(item or "").strip().rstrip(" ✗")
    return f"{code} ✗" if code else ""


@dataclass
class DimScore:
    """ציון של ממד אחד אחרי איחוד המקורות."""

    key: str
    label: str
    value: Optional[float]
    threshold: float
    priority: str
    state: str                    # measured / unmeasured / missing
    parts: dict = field(default_factory=dict)
    note: str = ""
    #: הראיות שנכשלו בפועל, כפי שהמודד עצמו רשם אותן. זה מה שהופך
    #: את האבחון לשורשי ולא לניחוש: השורש הוא המדידה שנפלה, לא
    #: ההשערה שלנו על מה שגרם לה.
    failed_checks: list[str] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        """"לא נמדד" אינו עובר שער — אבל גם אינו כשל קריטי."""
        return self.value is not None and self.value >= self.threshold

    @property
    def critical(self) -> bool:
        """כשל קריטי: אין מערכת, או ציון מתחת לרצפה, או כשל ב-P0.

        ``unmeasured`` אינו קריטי בכוונה: תקלת סביבה אינה כשל איכות,
        והכרזה עליה כקריטית הייתה עוצרת את כל המשימה בכל פעם שגלאי
        אחד נופל על קובץ חסר.
        """
        if self.state == "missing":
            return True
        if self.value is None:
            return False
        if self.value < HARD_FLOOR:
            return True
        return self.priority == "P0" and not self.passed

    @property
    def gap(self) -> float:
        if self.value is None:
            return self.threshold
        return round(max(0.0, self.threshold - self.value), 1)

    def to_dict(self) -> dict:
        d = asdict(self)
        d.update(passed=self.passed, critical=self.critical, gap=self.gap)
        return d


def collect(baseline_rep: "B.Report | None" = None,
            critic_scores: dict[str, float] | None = None,
            master: dict[str, float] | None = None,
            qa_scores: dict[str, float] | None = None,
            critic_findings: dict[str, list] | None = None) -> list[DimScore]:
    """מאחד את כל מקורות המדידה לשלושה-עשר ממדי המשימה.

    כל מקור אופציונלי: מי שלא נמסר מסמן את הממדים שתלויים בו
    ``unmeasured`` ולא מפיל את השער. זו אותה החלטה של
    ``baseline.measure`` — מדידה שנופלת בגלל מקור אחד היא מדידה
    שלא תרוץ בלילה שבו היא באמת נחוצה.
    """
    pools: dict[str, dict[str, object]] = {
        "baseline": {}, "critic": dict(critic_scores or {}),
        "master": dict(master or {}), "qa": dict(qa_scores or {}),
    }
    #: ראיות שנפלו, ממופתחות ב-``"<מקור>:<מפתח>"`` המלא ולא במפתח
    #: לבדו. עד 07/10 המפתח היה הקטגוריה בלבד, ולכן ראיות של מבקר
    #: לא היה לה בכלל מקום להיכנס אליו — ``critic:animation`` ו-
    #: ``baseline:animation`` היו מתנגשים על אותה משבצת.
    ev_pool: dict[str, list[str]] = {}
    if baseline_rep is not None:
        for sc in baseline_rep.scores:
            # הערך נשמר עם המצב שלו, כדי שאפשר יהיה להבדיל בין
            # "המערכת אינה קיימת" (אפס אמיתי) ל"לא הצלחנו למדוד".
            pools["baseline"][sc.key] = (sc.value, sc.state)
            ev_pool[f"baseline:{sc.key}"] = [
                e for e in (sc.evidence or [])
                if str(e).rstrip().endswith("✗")]
    for name, items in (critic_findings or {}).items():
        ev_pool[f"critic:{name}"] = [_finding_code(x) for x in items
                                     if _finding_code(x)]

    out: list[DimScore] = []
    for dim in DIMS:
        parts: dict[str, object] = {}
        vals: list[float] = []
        missing = False
        checks: list[str] = []
        for src in dim.sources:
            checks += ev_pool.get(src, [])
            kind, _, key = src.partition(":")
            raw = pools.get(kind, {}).get(key, None)
            if isinstance(raw, tuple):
                val, state = raw
                if state == "missing":
                    missing = True
                    parts[src] = "אין מערכת"
                    vals.append(0.0)
                    continue
                if state == "unmeasured" or not _is_num(val):
                    parts[src] = "לא נמדד"
                    continue
                parts[src] = round(float(val), 1)
                vals.append(float(val))
            elif _is_num(raw):
                parts[src] = round(float(raw), 1)
                vals.append(float(raw))
            else:
                parts[src] = "לא נמדד"

        if missing:
            out.append(DimScore(dim.key, dim.label, 0.0, dim.threshold,
                                dim.priority, "missing", parts,
                                "אין מערכת שמממשת את הממד",
                                failed_checks=checks))
        elif vals:
            # מינימום ולא ממוצע: שני מודדים על אותו ממד הם שתי
            # עדויות, והחמורה היא זו שמכריעה אם לשחרר.
            out.append(DimScore(dim.key, dim.label, round(min(vals), 1),
                                dim.threshold, dim.priority, "measured",
                                parts, failed_checks=checks))
        else:
            out.append(DimScore(dim.key, dim.label, None, dim.threshold,
                                dim.priority, "unmeasured", parts,
                                "אין אף מקור מדידה זמין",
                                failed_checks=checks))
    return out


# ====================================================== שער האיכות

@dataclass
class GateResult:
    """פסק השער: שלושה תנאים, וכולם חייבים."""

    scores: list[DimScore]
    regressed: list[str] = field(default_factory=list)
    lost_measurement: list[str] = field(default_factory=list)
    base_tag: str = ""
    at: str = ""

    @property
    def failed(self) -> list[DimScore]:
        return [s for s in self.scores if not s.passed]

    @property
    def criticals(self) -> list[DimScore]:
        return [s for s in self.scores if s.critical]

    @property
    def unmeasured(self) -> list[DimScore]:
        return [s for s in self.scores if s.state == "unmeasured"]

    @property
    def no_regression(self) -> bool:
        return not self.regressed

    @property
    def passed(self) -> bool:
        """``PASS = כל הספים AND אפס קריטיים AND אין נסיגה``."""
        return (not self.failed and not self.criticals
                and self.no_regression)

    @property
    def quality_score(self) -> float:
        """ציון איכות אחד למשימה, לטובת רישום הגרסה.

        **זה אינו המדד שמכריע** — ההכרעה היא ``passed``. הוא ממוצע
        של שיעורי העמידה בסף, חסום ב-100, ונועד למעקב בין גרסאות.
        """
        ms = [s for s in self.scores if s.value is not None]
        if not ms:
            return 0.0
        ratios = [min(1.0, s.value / s.threshold) for s in ms]
        return round(100.0 * sum(ratios) / len(ratios), 1)

    def by_key(self) -> dict[str, DimScore]:
        return {s.key: s for s in self.scores}

    def known_failures(self) -> list[str]:
        out = [f"{s.label} {s.value if s.value is not None else '--'}"
               f"/{s.threshold:.0f}" + (" ⚠קריטי" if s.critical else "")
               for s in self.failed]
        out += [f"נסיגה ב-{k}" for k in self.regressed]
        return out

    def to_dict(self) -> dict:
        return {"passed": self.passed, "quality_score": self.quality_score,
                "critical_failures": len(self.criticals),
                "failed": [s.key for s in self.failed],
                "criticals": [s.key for s in self.criticals],
                "unmeasured": [s.key for s in self.unmeasured],
                "regressed": list(self.regressed),
                "lost_measurement": list(self.lost_measurement),
                "no_regression": self.no_regression,
                "base_tag": self.base_tag, "at": self.at,
                "scores": [s.to_dict() for s in self.scores]}

    # -------------------------------------------- קדימות חישוב

    def focus(self) -> list[str]:
        """על מה לעבוד עכשיו, לפי קדימות החישוב של המשימה.

        כשל קריטי ראשון, אחריו כשל רגיל, והמיון בתוך כל קבוצה לפי
        קדימות ואז לפי גודל הפער. פער גדול באותה קדימות הוא גם
        הכשל שנראה לעין וגם זה שיש בו מה להרוויח.
        """
        bad = [s for s in self.scores if not s.passed]
        bad.sort(key=lambda s: (not s.critical, _pri_rank(s.priority),
                                -s.gap, s.key))
        return [s.key for s in bad if s.key not in self.deferred()]

    def deferred(self) -> list[str]:
        """מה מוקפא כי ממד בקדימות גבוהה נכשל.

        ההקפאה היא **יחסית** לכשל הדחוף ביותר ולא לרשימת דרגות
        קבועה: כשל ב-P1 מקפיא P3 ומטה, כשל ב-P0 מקפיא P2 ומטה.
        ממד שעובר אינו מוקפא — אין מה להקפיא במי שגמור.
        """
        bad = [s for s in self.scores if not s.passed]
        # ממד ש**לא נמדד** אינו מקפיא כלום. נתפס בהרצה אמיתית ולא
        # בקריאת קוד: הממד הטכני לא נמדד (אין סרטון), הוא P0, ולכן
        # הוא הקפיא את P2 ומטה — כלומר תקלת סביבה כיוונה את העבודה.
        # זו אותה הבחנה שכבר נאכפת ב-``critical``: "לא נמדד" הוא
        # היעדר מידע, לא כשל איכות.
        blocking = [s for s in bad if s.priority in BLOCKING_PRIORITIES
                    and s.state != "unmeasured"]
        if not blocking:
            return []
        top = min(_pri_rank(s.priority) for s in blocking)
        return [s.key for s in bad
                if _pri_rank(s.priority) >= top + DEFER_GAP
                and s.state != "unmeasured"]

    def text(self) -> str:
        L = [f"=== שער איכות · {self.at or '—'} ==="]
        for s in sorted(self.scores, key=lambda x: (_pri_rank(x.priority),
                                                    x.key)):
            if s.state == "unmeasured":
                mark, val = "?", "  --"
            elif s.passed:
                mark, val = "✓", f"{s.value:5.1f}"
            else:
                mark, val = ("⛔" if s.critical else "✗"), f"{s.value:5.1f}"
            L.append(f" {mark} {s.priority} {s.label:9s} {val} "
                     f"/ {s.threshold:.0f}"
                     + (f"   פער {s.gap}" if not s.passed and s.value
                        is not None else "")
                     + (f"   {s.note}" if s.note else ""))
        L.append(f"  ציון איכות {self.quality_score} · "
                 f"כשלים קריטיים {len(self.criticals)} · "
                 f"נסיגה: {'אין' if self.no_regression else ', '.join(self.regressed)}")
        if self.deferred():
            L.append("  מוקפא עד שהמשחק עובר: "
                     + ", ".join(DIM_BY_KEY[k].label
                                 for k in self.deferred()))
        L.append(f"  פסק: {'PASS' if self.passed else 'FAIL'}")
        if not self.passed and self.focus():
            L.append("  לעבוד על: "
                     + " → ".join(DIM_BY_KEY[k].label
                                  for k in self.focus()[:4]))
        return "\n".join(L)


def quality_gate(baseline_rep: "B.Report | None" = None,
                 critic_scores: dict[str, float] | None = None,
                 master: dict[str, float] | None = None,
                 qa_scores: dict[str, float] | None = None,
                 base_tag: str = B.V0,
                 check_regression: bool = True,
                 critic_findings: dict[str, list] | None = None) -> GateResult:
    """השער המלא: ספים מוחלטים + אפס קריטיים + אי-נסיגה."""
    scores = collect(baseline_rep, critic_scores, master, qa_scores,
                     critic_findings)
    regressed: list[str] = []
    lost: list[str] = []
    used_base = ""
    if check_regression and baseline_rep is not None:
        cmp = B.gate(baseline_rep, base_tag)
        if "why" not in cmp:
            used_base = base_tag
            regressed = list(cmp.get("regressed", []))
            lost = list(cmp.get("lost_measurement", []))
    return GateResult(scores=scores, regressed=regressed,
                      lost_measurement=lost, base_tag=used_base,
                      at=datetime.now().isoformat(timespec="seconds"))


# ====================================================== אבחון שורש

#: מי אחראי לכל ממד. זה **הקובץ שצריך להיפתח**, לא תיאור מופשט —
#: אבחון שמסתיים ב"בעיה במשחק" אינו אבחון, הוא חזרה על הכשל במילים
#: אחרות. ``SELECT_RESPONSIBLE_SUBSYSTEM`` של המשימה הוא זה בדיוק.
OWNER: dict[str, tuple[str, ...]] = {
    "story":      ("showreel/disney_story.py", "rig/acting.py"),
    "character":  ("rig/identity.py", "rig/basemesh.py", "rig/dimorph.py"),
    "acting":     ("rig/emotion.py", "rig/acting.py", "rig/face.py"),
    "face":       ("rig/face.py", "rig/facestyle.py", "rig/detail.py"),
    "eyes":       ("rig/eyes.py", "rig/look.py"),
    "body":       ("rig/body.py", "rig/skeleton.py", "rig/controls.py"),
    "animation":  ("rig/principles.py", "rig/secondary.py",
                   "rig/locomotion.py"),
    "camera":     ("rig/camera.py", "rig/cinema.py", "rig/closeup.py"),
    "lighting":   ("rig/organic.py", "rig/appeal.py"),
    "visual":     ("engine.py", "rig/detail.py"),
    "sound":      ("rig/speech.py", "rig/voice.py", "rig/tts_tool.py"),
    "continuity": ("rig/pipeline.py", "studio/director.py"),
    "technical":  ("engine.py", "remux.py", "build.py"),
}


def _repair_book() -> dict[str, str]:
    """ספר התיקונים הקיים: קוד מדידה -> שם תיקון.

    הוא יושב ב-``critics`` ואינו נכתב כאן מחדש. ייבוא עצל, כי
    ``critics`` מביא איתו numpy ואת כל מנוע המדידה.
    """
    try:
        from studio import critics as C
        # השם האמיתי הוא ``REPAIR_FOR``. ניחוש שמות היה מחזיר מילון
        # ריק בשקט, כלומר כל אבחון היה יוצא בלי המלצת תיקון ואיש
        # לא היה רואה שגיאה — הבדיקה היא מה שתפסה את זה.
        for name in ("REPAIR_FOR", "REPAIR", "REPAIRS"):
            book = getattr(C, name, None)
            if isinstance(book, dict) and book:
                return dict(book)
    except Exception:                                   # noqa: BLE001
        pass
    return {}


@dataclass
class Diagnosis:
    """אבחון שורש של ממד אחד כושל."""

    dim: str
    label: str
    value: Optional[float]
    threshold: float
    gap: float
    priority: str
    critical: bool
    subsystems: list[str]
    failed_checks: list[str]
    repairs: list[str]
    why: str

    def to_dict(self) -> dict:
        return asdict(self)

    def text(self) -> str:
        v = "--" if self.value is None else f"{self.value:.1f}"
        L = [f"  {'⛔' if self.critical else '✗'} {self.label} "
             f"{v}/{self.threshold:.0f} (פער {self.gap}) · {self.priority}",
             f"      שורש: {self.why}",
             f"      תת-מערכת: {', '.join(self.subsystems) or '—'}"]
        if self.failed_checks:
            L.append(f"      בדיקות שנפלו: "
                     f"{', '.join(self.failed_checks[:6])}")
        if self.repairs:
            L.append(f"      תיקון מוצע: {', '.join(self.repairs[:6])}")
        return "\n".join(L)


def diagnose(gate: GateResult, stage: str = "",
             top: int = 4) -> list[Diagnosis]:
    """אבחון שורש לכשלים — לפי קדימות, ולפי ראיות ולא לפי השערה.

    שלושה מצבים ולא אחד, וההבחנה ביניהם היא כל התועלת:

    * **אין מערכת** — אין מה לתקן, צריך לבנות. תיקון אינו הפעולה.
    * **לא נמדד** — אין ידיעה. הפעולה היא להריץ את המודד, לא לגעת
      בקוד: שינוי על סמך אי-ידיעה מקלקל תיקון תקין.
    * **נמדד ונכשל** — כאן יש ראיות, וההמלצה נגזרת מהן.
    """
    book = _repair_book()
    keys = gate.focus() if not stage else \
        [k for k in gate.focus() if k in stage_dims(stage)]
    if stage and not keys:
        sv = stage_verdict(gate, stage)
        keys = sv["criticals"] + [k for k in sv["failed"]
                                  if k not in sv["criticals"]]
    by = gate.by_key()
    out: list[Diagnosis] = []
    for k in keys[:top]:
        s = by.get(k)
        if s is None:
            continue
        if s.state == "missing":
            why = "המערכת שאחראית לממד אינה קיימת — צריך לבנות, לא לתקן"
            reps: list[str] = []
        elif s.state == "unmeasured":
            why = ("הממד לא נמדד, ולכן אין ידיעה. להריץ את המודד "
                   "לפני שנוגעים בקוד")
            reps = []
        else:
            low = [f"{src}={val}" for src, val in s.parts.items()
                   if _is_num(val) and float(val) < s.threshold]
            why = ("המקור החלש הוא " + ", ".join(low)
                   if low else f"הציון {s.value} מתחת לסף {s.threshold:.0f}")
            if s.failed_checks:
                why += f" · {len(s.failed_checks)} בדיקות נפלו"
            reps = []
            for code in s.failed_checks:
                clean = str(code).rstrip(" ✗")
                if clean in book and book[clean] not in reps:
                    reps.append(book[clean])
        out.append(Diagnosis(
            dim=k, label=s.label, value=s.value, threshold=s.threshold,
            gap=s.gap, priority=s.priority, critical=s.critical,
            subsystems=list(OWNER.get(k, ())), failed_checks=
            [str(c).rstrip(" ✗") for c in s.failed_checks[:12]],
            repairs=reps, why=why))
    return out


# =================================================== מנוע התיקון

#: ספר התיקונים של ראיות ה-``baseline``, שכולן בעברית. ספר התיקונים
#: של המבקרים (``critics.REPAIR_FOR``) ממופתח בקודים לטיניים ולכן
#: אינו מכסה אותן — נמדד 07/10: אבחון של פנים ושל דיבור חזר עם
#: ראיות מדויקות ועם רשימת תיקונים **ריקה**, כי אין שום מפתח
#: משותף בין "צורות פנים בריג" ל-``face.shapes``.
#:
#: המפתח הוא **תחילית** של הראיה ולא התאמה מדויקת: הראיה נושאת את
#: הערך בתוכה (``"צורות פנים בריג=0.265"``), ולכן התאמה מדויקת לא
#: הייתה תופסת אף אחת מהן אף פעם.
BASELINE_REPAIR: dict[str, str] = {
    # פנים
    "צורות פנים בריג":        "expand_face_shapes",
    "אזורי פנים עצמאיים":     "split_face_regions",
    "יחידות תנועה מוגדרות":   "define_action_units",
    # דיבור
    "פונמות ממופות":          "map_phonemes",
    "ויזמות":                 "add_visemes",
    "קולות רגש":              "add_emotion_voices",
    "אינו מכני":              "break_mechanical_drive",
    "ריחוק מהנעה מכנית":      "break_mechanical_drive",
    # עיניים
    "בעיה":                   "fix_eye_feature",
    # גוף וידיים
    "אצבעות נשלטות":          "add_finger_controls",
    "העברת משקל":             "add_weight_shift",
    # אנימציה
    "חסר":                    "implement_principle",
}


def repair_for(check: str) -> str:
    """שם התיקון לראיה אחת, משני הספרים.

    קודם ספר המבקרים (התאמה מדויקת לקוד), ואחריו ספר ה-``baseline``
    (התאמה לפי תחילית). הסדר אינו שרירותי: קוד של מבקר הוא מזהה
    מדויק, וראיה בעברית היא טקסט — ומזהה מדויק מכריע לפני התאמת
    טקסט, תמיד.
    """
    clean = str(check).rstrip(" ✗").strip()
    book = _repair_book()
    if clean in book:
        return book[clean]
    head = clean.split("=", 1)[0].strip()
    if head in book:
        return book[head]
    for pref, name in BASELINE_REPAIR.items():
        if head.startswith(pref) or head == pref:
            return name
    return ""


#: תיקון -> הפרמטר שמבצע אותו. **רק מה שמחובר בפועל יושב כאן.**
#: תיקון שאין לו שורה כאן מדווח כ"דרוש אדם" ולא מתחזה לבוצע —
#: וזו ההבחנה שמונעת את הכשל הגרוע ביותר של לולאה אוטונומית:
#: לדווח "תיקנתי", למדוד בדיוק אותו דבר, ולהסיק "קיפאון באיכות"
#: במקום "לא עשיתי כלום".
REPAIR_KNOB: dict[str, str] = {
    "smooth_curves":      "smooth_win",
    "fix_discontinuity":  "smooth_win",
    "add_anticipation":   "anticipate",
}


class RepairEngine:
    """מנוע התיקון האוטונומי: אבחון -> ספר תיקונים -> פעולה.

    הוא **אינו** כותב קוד. הוא מזיז פרמטרים מרשימה סגורה
    (``studio.tuning``), שומר אותם לדיסק, ומדווח בדיוק מה בוצע
    ומה דורש אדם. זו החלטה ולא מגבלה: מנוע שמורשה לכתוב קוד
    במערכת שהוא גם מודד בעצמה הוא מנוע בלי בלם.

    שלושה בלמים, וכל אחד מהם נגזר מכשל שתועד בפרויקט הזה:

    * **אותו תיקון לא נוסה פעמיים על אותו שלב** אם הוא לא הזיז
      כלום — אחרת הלולאה מודדת מחדש בדיוק את אותו מצב עד שייגמרו
      הסבבים.
    * **פרמטר בקצה התחום אינו תיקון.** הוא מדווח כמוצה, והלולאה
      יוצאת עם סיבה אמיתית במקום לדשדש.
    * **פרמטר שאינו מחובר נדחה במפורש** (``Knob.wired``).
    """

    def __init__(self, tuning=None):
        if tuning is None:
            from studio import tuning as _T
            tuning = _T
        self.T = tuning
        self.tried: set[tuple[str, str]] = set()
        self.log: list[dict] = []

    def plan(self, stage: str, focus: Sequence[str],
             verdict: dict) -> dict:
        """החוזה של ``Mission.repair``."""
        gate = verdict.get("gate")
        items = verdict.get("diagnosis")
        if items is None and gate is not None:
            items = diagnose(gate, stage)
        items = items or []

        done: list[str] = []
        files: list[str] = []
        manual: list[str] = []
        notes: list[str] = []

        for d in items:
            dim = d.dim if isinstance(d, Diagnosis) else d.get("dim", "")
            checks = (d.failed_checks if isinstance(d, Diagnosis)
                      else d.get("failed_checks") or [])
            if focus and dim not in focus:
                continue
            owners = list(OWNER.get(dim, ()))
            if not checks:
                # ממד שנכשל בלי אף ראיה שנפלה הוא ממד שאין בו מה
                # לתקן נקודתית — הציון נמוך מהסף אך כל בדיקה עברה.
                # זה מצב אמיתי (סף גבוה מסך הראיות), והוא נאמר
                # במילים ולא מתורגם לתיקון מומצא.
                notes.append(f"{DIM_BY_KEY[dim].label}: אין ראיה בודדת "
                             f"שנפלה — הפער הוא בסף ולא בבדיקה")
                continue
            for chk in checks:
                name = repair_for(chk)
                if not name:
                    manual.append(f"{chk} (אין תיקון בספר)")
                    continue
                knob = REPAIR_KNOB.get(name)
                if knob is None:
                    if name not in manual:
                        manual.append(f"{name} ← {', '.join(owners[:2])}")
                    continue
                key = (stage, knob)
                if key in self.tried:
                    continue
                res = self.T.nudge(knob)
                self.log.append(dict(res, stage=stage, dim=dim,
                                     check=str(chk), repair=name))
                if res.get("ok"):
                    done.append(f"{name}({knob} {res['before']}"
                                f"→{res['after']})")
                    files += [f for f in owners if f not in files]
                    if res.get("at_limit"):
                        self.tried.add(key)
                else:
                    # כשל אינו "לא ננסה שוב לנצח": פרמטר בקצה
                    # התחום או לא מחובר לא ישתנה גם בסבב הבא,
                    # ולכן הוא נרשם — אבל *רק* הוא.
                    self.tried.add(key)
                    manual.append(f"{name}: {res.get('why', '')}")

        note = " · ".join(notes + ([f"דרוש אדם: {'; '.join(manual[:4])}"]
                                   if manual else []))
        return {"repairs": done, "files": files, "manual": manual,
                "note": note}

    def __call__(self, stage: str, focus: Sequence[str],
                 verdict: dict) -> dict:
        return self.plan(stage, focus, verdict)


def diagnosis_text(items: Sequence[Diagnosis]) -> str:
    if not items:
        return "אין כשל לאבחן."
    return "\n".join(["=== אבחון שורש ==="] + [d.text() for d in items])


# ====================================================== שרשרת גרסאות

#: שדות רשומת הגרסה, בדיוק כפי שהוגדרו במשימה.
VERSION_FIELDS = (
    "version_id", "parent_version", "models", "prompts", "parameters",
    "assets", "character_rig", "animation_config", "camera_config",
    "lighting_config", "render_config", "audio_config", "critic_results",
    "quality_score", "known_failures", "repairs", "timestamp",
)

#: סיומות שמותר להחזיר בנסיגה. קובץ מצב או תוצר אינו קוד, והחזרה
#: שלו אינה ביטול שינוי אלא דריסת עובדות.
ROLLBACK_EXT = (".py", ".js", ".html", ".css", ".md")


def _git(args: Sequence[str], cwd: Path = ROOT) -> tuple[int, str]:
    try:
        r = subprocess.run(["git", *args], cwd=str(cwd), capture_output=True,
                           text=True, encoding="utf-8", errors="replace",
                           timeout=60)
        return r.returncode, (r.stdout or "") + (r.stderr or "")
    except (OSError, subprocess.SubprocessError) as exc:
        return 1, f"{type(exc).__name__}: {exc}"


def git_point(cwd: Path = ROOT) -> str:
    """ה-commit הנוכחי, או "" אם אין מאגר. נשמר בכל גרסה."""
    code, out = _git(["rev-parse", "HEAD"], cwd)
    return out.strip() if code == 0 else ""


class VersionStore:
    """שרשרת גרסאות עם אב, פסק איכות, ונסיגה אפשרית תמיד.

    לא נבנה כאן מנגנון גיבוי קוד משלנו: התיקייה היא מאגר ``git``,
    וה-commit הוא הנקודה. הגרסה שומרת את ה-commit ואת רשימת
    הקבצים שהיא נגעה בהם, ולכן הנסיגה היא
    ``git checkout <commit> -- <file>`` לקבצים שהוצהרו **בלבד**.
    """

    def __init__(self, root: Path = STORE, repo: Path = ROOT):
        self.root = Path(root)
        self.repo = Path(repo)

    # ------------------------------------------------------ קריאה

    @property
    def index_path(self) -> Path:
        return self.root / "index.json"

    def path_of(self, version_id: str) -> Path:
        return self.root / f"{version_id}.json"

    def load(self, version_id: str) -> dict | None:
        p = self.path_of(version_id)
        if not p.exists():
            return None
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except (ValueError, OSError):
            return None

    def index(self) -> list[dict]:
        try:
            d = json.loads(self.index_path.read_text(encoding="utf-8"))
            return list(d.get("versions", []))
        except (ValueError, OSError):
            return []

    def latest(self) -> dict | None:
        idx = self.index()
        return self.load(idx[-1]["version_id"]) if idx else None

    def chain(self, version_id: str) -> list[str]:
        """שרשרת האבות, מהגרסה הנתונה אל השורש.

        שומר מפני מעגל: רשומה פגומה שמצביעה על עצמה הייתה תולה
        את כל הקורא, ואי אפשר למנוע אותה בכתיבה בלבד — רשומה
        נערכת גם ביד.
        """
        out, seen = [], set()
        cur = version_id
        while cur and cur not in seen:
            seen.add(cur)
            out.append(cur)
            rec = self.load(cur)
            cur = (rec or {}).get("parent_version") or ""
        return out

    # ------------------------------------------------------ כתיבה

    def _next_id(self) -> str:
        n = 1
        taken = {r["version_id"] for r in self.index()}
        while f"V{n}" in taken:
            n += 1
        return f"V{n}"

    def baseline_v0(self, gate: GateResult | None = None,
                    files: Sequence[str] = ()) -> dict:
        """מקבע את ``BASELINE_V0`` — שורש השרשרת, ואינו נהרס לעולם.

        המשימה דורשת שהמערכת הקיימת תהיה נקודת הפתיחה ושהנסיגה
        אליה תהיה אפשרית תמיד. לכן הבסיס הוא גרסה ככל גרסה אחרת
        בשרשרת (יש לה commit ויש לה קבצים), אבל היא מסורבת לדריסה
        ואין לה אב. בסיס שקיים מוחזר כמות שהוא ולא נכתב מחדש: זה
        מה שמונע ממי שמריץ פעמיים למחוק את נקודת החזרה.
        """
        exist = self.load(V0)
        if exist is not None:
            return exist
        return self.create(gate=gate, version_id=V0, parent="",
                           files=files, stage="baseline_v0")

    def create(self, gate: GateResult | None = None,
               version_id: str | None = None,
               parent: str | None = None,
               files: Sequence[str] = (),
               repairs: Sequence[str] = (),
               stage: str = "",
               **configs) -> dict:
        """רושם גרסה חדשה. אינו דורס גרסה קיימת.

        ``parent`` שלא נמסר נלקח מהגרסה האחרונה בשרשרת — כך שכל
        גרסה שנרשמת בלולאה קושרת את עצמה מאליה, ואין שרשרת
        שנקרעת כי מי שקרא שכח להעביר אב.
        """
        self.root.mkdir(parents=True, exist_ok=True)
        vid = version_id or self._next_id()
        if self.path_of(vid).exists():
            raise ValueError(f"גרסה {vid} קיימת — גרסה אינה נדרסת")
        idx = self.index()
        if parent is None:
            parent = idx[-1]["version_id"] if idx else ""

        rec: dict = {f: configs.pop(f, None) for f in VERSION_FIELDS}
        rec["version_id"] = vid
        rec["parent_version"] = parent
        rec["timestamp"] = datetime.now().isoformat(timespec="seconds")
        rec["repairs"] = list(repairs)
        for key in ("models", "prompts", "assets"):
            rec[key] = list(rec[key] or [])
        for key in ("parameters", "critic_results"):
            rec[key] = dict(rec[key] or {})
        if gate is not None:
            rec["quality_score"] = gate.quality_score
            rec["known_failures"] = gate.known_failures()
            rec["critic_results"] = rec["critic_results"] or {
                s.key: s.value for s in gate.scores}
            rec["gate"] = gate.to_dict()
        else:
            rec["known_failures"] = list(rec["known_failures"] or [])
            rec["quality_score"] = rec["quality_score"] or 0.0
        rec["stage"] = stage
        rec["commit"] = git_point(self.repo)
        rec["files"] = [f for f in files
                        if Path(f).suffix.lower() in ROLLBACK_EXT]
        rec["extra"] = configs or {}

        self.path_of(vid).write_text(
            json.dumps(rec, ensure_ascii=False, indent=1), encoding="utf-8")
        idx.append({"version_id": vid, "parent_version": parent,
                    "at": rec["timestamp"], "stage": stage,
                    "quality_score": rec["quality_score"],
                    "passed": bool(gate.passed) if gate else None})
        self.index_path.write_text(
            json.dumps({"versions": idx}, ensure_ascii=False, indent=1),
            encoding="utf-8")
        return rec

    # ------------------------------------------------------ נסיגה

    def rollback(self, version_id: str, apply: bool = False) -> dict:
        """מחזיר את הקוד לגרסה נתונה — קובץ-קובץ, ולא גורף.

        ``apply=False`` (ברירת המחדל) מחזיר את התוכנית בלי לגעת
        בדיסק. זה מכוון: נסיגה היא הפעולה המסוכנת ביותר כאן,
        ומי שמריץ אותה בטעות לא יכול לבטל.

        ``git reset --hard`` ו-``git checkout -- .`` אסורים: בתיקייה
        הזו יושבים גם תוצרי רינדור וגם קובצי מצב, וגם סשן אחר
        עשוי לערוך קוד באותו רגע.
        """
        rec = self.load(version_id)
        if rec is None:
            return {"ok": False, "why": f"אין גרסה בשם {version_id}"}
        commit = rec.get("commit") or ""
        files = [f for f in (rec.get("files") or [])
                 if Path(f).suffix.lower() in ROLLBACK_EXT]
        plan = {"ok": True, "version_id": version_id, "commit": commit,
                "files": files, "applied": [], "skipped": [],
                "dry_run": not apply}
        if not commit:
            plan.update(ok=False, why="לגרסה אין נקודת git — אין לאן לחזור")
            return plan
        if not files:
            plan.update(ok=False, why="הגרסה לא הצהירה על קובצי קוד")
            return plan
        if not apply:
            return plan
        for f in files:
            code, out = _git(["checkout", commit, "--", f], self.repo)
            if code == 0:
                plan["applied"].append(f)
            else:
                plan["skipped"].append({"file": f, "why": out.strip()[:160]})
        plan["ok"] = bool(plan["applied"]) and not plan["skipped"]
        return plan


# ====================================================== גרף הביצוע

@dataclass(frozen=True)
class Stage:
    """שלב בגרף הביצוע: מה הוא דורש לפניו, ואיזה ממדים הוא אחראי להם."""

    key: str
    label: str
    needs: tuple[str, ...]
    dims: tuple[str, ...]


#: גרף הביצוע של המשימה. כל חץ דורש מעבר, ולכן ``needs`` הוא התלות.
#: השלבים שאינם נושאים ממד (אבחון, תיקון, אישור) קיימים בגרף כי הם
#: קובעים את **הסדר**, גם כשאין להם סף משלהם.
GRAPH: tuple[Stage, ...] = (
    Stage("audit",       "ביקורת פתיחה",  (), ()),
    Stage("baseline_v0", "קיבוע הבסיס",   ("audit",), ()),
    Stage("character",   "צינור הדמות",   ("baseline_v0",),
          ("character",)),
    Stage("face",        "מנוע הפנים",    ("character",), ("face",)),
    Stage("eyes",        "מנוע העיניים",  ("face",), ("eyes",)),
    Stage("emotion",     "מנוע הרגש",     ("eyes",), ("acting",)),
    Stage("body",        "משחק גוף",      ("emotion",), ("body",)),
    Stage("principles",  "עקרונות אנימציה", ("body",), ("animation",)),
    Stage("secondary",   "תנועה משנית",   ("principles",), ()),
    Stage("camera",      "בימוי מצלמה",   ("secondary",), ("camera",)),
    Stage("lighting",    "תאורה ומראה",   ("camera",), ("lighting", "visual")),
    Stage("sound",       "קול ודיבור",    ("lighting",), ("sound",)),
    Stage("council",     "מועצת איכות",   ("sound",), ("story",)),
    Stage("gold",        "מבחן תקן הזהב", ("council",),
          ("continuity", "technical")),
    Stage("approval",    "אישור סופי",    ("gold",), ()),
)

STAGE_BY_KEY: dict[str, Stage] = {s.key: s for s in GRAPH}


def stage_dims(stage_key: str) -> tuple[str, ...]:
    return STAGE_BY_KEY[stage_key].dims if stage_key in STAGE_BY_KEY else ()


def stage_verdict(gate: GateResult, stage_key: str) -> dict:
    """פסק של שלב בודד: רק הממדים שהשלב אחראי להם.

    שלב בלי ממדים עובר כשאין בו מה למדוד — אחרת גרף הביצוע נתקע
    לנצח על שלב שאין לו שער, וזה היה חוסם את כל השרשרת אחריו.
    """
    dims = stage_dims(stage_key)
    by = gate.by_key()
    mine = [by[d] for d in dims if d in by]
    crit = [s.key for s in mine if s.critical]
    bad = [s.key for s in mine if not s.passed]
    return {"stage": stage_key, "dims": list(dims),
            "passed": not bad and not crit,
            "failed": bad, "criticals": crit,
            "scores": {s.key: s.value for s in mine}}


def select_next_stage(gate: GateResult, done: Sequence[str]) -> str | None:
    """השלב הבא: הראשון שתלויותיו הושלמו ושהוא עצמו טרם עבר.

    ``NO_CRITICAL_FAILURE_MAY_ADVANCE`` נאכף כאן ולא בהמשך: שלב
    שלא עבר אינו נכנס ל-``done``, ולכן כל מי שתלוי בו לא ייבחר
    לעולם לפניו. זו האכיפה, לא ההצהרה.
    """
    done_set = set(done)
    for st in GRAPH:
        if st.key in done_set:
            continue
        if not set(st.needs).issubset(done_set):
            return None if st.needs else st.key
        return st.key
    return None


# ====================================================== לולאת המשימה

#: תקרות הלולאה. כל אחת מהן נגזרת מכשל של מודל חינמי שנמדד כאן:
#: לולאה בלי תקרת סבבים לשלב נתקעת על ממד אחד עד סוף התקציב, ולולאה
#: בלי זיהוי קיפאון מרנדרת מחדש בדיוק אותו דבר.
MAX_ROUNDS_PER_STAGE = 3
PLATEAU_DELTA = 1.0


@dataclass
class Round:
    n: int
    stage: str
    before: dict
    after: dict
    repairs: list[str] = field(default_factory=list)
    files: list[str] = field(default_factory=list)
    gained: float = 0.0
    regressed: list[str] = field(default_factory=list)
    outcome: str = ""
    version_id: str = ""
    note: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class MissionResult:
    outcome: str
    done: list[str]
    blocked: str = ""
    rounds: list[dict] = field(default_factory=list)
    versions: list[str] = field(default_factory=list)
    final: dict | None = None
    why: str = ""

    @property
    def complete(self) -> bool:
        return self.outcome == "COMPLETE"

    def to_dict(self) -> dict:
        return asdict(self)

    def text(self) -> str:
        mark = {"COMPLETE": "✓", "BLOCKED": "⛔",
                "EXHAUSTED": "✗", "STALLED": "⏸"}.get(self.outcome, "·")
        L = [f"{mark} משימה · {self.outcome} · {self.why}"]
        for r in self.rounds:
            st = STAGE_BY_KEY.get(r["stage"])
            L.append(f"  {r['n']:>2}. {(st.label if st else r['stage']):<16}"
                     f" {r['outcome']:<10} {r['gained']:+6.1f}"
                     + (f" · תיקון: {', '.join(r['repairs'])}"
                        if r["repairs"] else "")
                     + (f" · ⚠ נסיגה ב-{', '.join(r['regressed'])}"
                        if r["regressed"] else "")
                     + (f" · {r['version_id']}" if r["version_id"] else "")
                     + (f" · {r['note']}" if r["note"] else ""))
        L.append(f"  הושלמו {len(self.done)}/{len(GRAPH)} שלבים"
                 + (f" · נחסם ב-{self.blocked}" if self.blocked else ""))
        return "\n".join(L)


class Mission:
    """הלולאה האוטונומית: בחירת שלב → מדידה → שער → אבחון → תיקון →
    מדידה חוזרת → אישור → גרסה → המשך.

    שני קולבקים הם כל הממשק אל העולם, וזו אותה תבנית של
    ``panel.RefineLoop`` — היא מה שמאפשר לבדוק את הלולאה בשניות
    בלי מנוע רינדור, ולכן גם מה שמאפשר לבדוק אותה בכלל:

    * ``measure(stage_key, round_n) -> GateResult``
    * ``repair(stage_key, focus, verdict) -> dict``
      מחזיר ``{"repairs": [...], "files": [...], "note": ""}``.
      החזרת רשימת תיקונים ריקה פירושה "אין מה לנסות" — והלולאה
      עוצרת במקום למדוד מחדש בדיוק את אותו מצב.
    """

    def __init__(self, measure: Callable[[str, int], GateResult],
                 repair: Callable[[str, list, dict], dict] | None = None,
                 store: VersionStore | None = None,
                 max_rounds: int = MAX_ROUNDS_PER_STAGE,
                 on_round: Callable[[Round], None] | None = None,
                 version_each: bool = True):
        self.measure = measure
        self.repair = repair
        self.store = store
        self.max_rounds = max_rounds
        self.on_round = on_round
        self.version_each = version_each
        self.rounds: list[Round] = []
        self.versions: list[str] = []

    # ------------------------------------------------------- עזר

    def _version(self, gate: GateResult, stage: str,
                 repairs: Sequence[str], files: Sequence[str]) -> str:
        if not (self.store and self.version_each):
            return ""
        try:
            rec = self.store.create(gate=gate, stage=stage,
                                    repairs=list(repairs), files=list(files))
        except (ValueError, OSError):
            return ""
        self.versions.append(rec["version_id"])
        return rec["version_id"]

    @staticmethod
    def _regressed_dims(before: GateResult, after: GateResult,
                        target: Sequence[str]) -> list[str]:
        """מי *אחר* ירד. תיקון שפוגע במי שלא התלונן חשוד.

        הסף הוא ``baseline.NOISE`` ולא אפס: הציונים כאן הם שיעורי
        מעבר על טבלאות בדיקה, וחצי נקודה אינה שינוי אמיתי.
        """
        a, b = before.by_key(), after.by_key()
        out = []
        for k, new in b.items():
            if k in target or new.value is None:
                continue
            old = a.get(k)
            if old is None or old.value is None:
                continue
            if old.value - new.value > B.NOISE:
                out.append(k)
        return out

    # ------------------------------------------------------ הרצה

    def run(self, max_steps: int = 60) -> MissionResult:
        done: list[str] = []
        per_stage: dict[str, int] = {}
        last: GateResult | None = None
        step = 0

        while step < max_steps:
            step += 1
            stage = select_next_stage(last or self._empty(), done)
            if stage is None:
                break
            gate = self.measure(stage, per_stage.get(stage, 0))
            last = gate
            sv = stage_verdict(gate, stage)

            if sv["passed"]:
                vid = self._version(gate, stage, [], [])
                self._note(Round(step, stage, sv, sv, [], [], 0.0, [],
                                 "APPROVED", vid,
                                 "" if sv["dims"] else "שלב בלי שער"))
                done.append(stage)
                continue

            tries = per_stage.get(stage, 0)
            if tries >= self.max_rounds:
                return self._stop("EXHAUSTED", done, stage,
                                  f"{STAGE_BY_KEY[stage].label}: "
                                  f"נגמרו {self.max_rounds} הסבבים")
            per_stage[stage] = tries + 1

            if self.repair is None:
                return self._stop("BLOCKED", done, stage,
                                  "אין מנוע תיקון — השלב נכשל ואין מי שיתקן")

            focus = [k for k in gate.focus() if k in sv["dims"]] \
                or sv["failed"] or sv["criticals"]
            # ה-``gate`` מצורף לפסק השלב כדי שהמנוע יוכל לאבחן
            # בעצמו. dict חדש ולא עדכון במקום: ``sv`` נרשם ב-
            # ``Round`` ונשמר בגרסה, ומדידה שלמה בתוך רשומת גרסה
            # הייתה מנפחת אותה ללא צורך.
            plan = self.repair(stage, focus, dict(sv, gate=gate)) or {}
            repairs = list(plan.get("repairs") or [])
            files = list(plan.get("files") or [])
            if not repairs:
                # **העצירה נושאת את ההסבר.** "ספר התיקונים נגמר"
                # לבדו הוא אותו כשל שקט שהמנוע נבנה למנוע: הוא
                # נכון ואינו אומר כלום. ה-``note`` הוא מה שאומר
                # *מה* דרוש ו*מי* אחראי.
                why = f"{STAGE_BY_KEY[stage].label}: ספר התיקונים נגמר"
                if plan.get("note"):
                    why += f" · {plan['note']}"
                return self._stop("EXHAUSTED", done, stage, why)

            after = self.measure(stage, per_stage[stage])
            last = after
            sv2 = stage_verdict(after, stage)
            regr = self._regressed_dims(gate, after, sv["dims"])
            gained = round(self._worst(sv2) - self._worst(sv), 1)

            if regr:
                outcome, note = "REGRESSED", "התיקון פגע במי שלא התלונן"
            elif sv2["passed"]:
                outcome, note = "APPROVED", ""
            elif gained <= PLATEAU_DELTA:
                outcome, note = "STALLED", f"שיפור {gained:+} אינו שיפור"
            else:
                outcome, note = "IMPROVED", ""

            vid = ""
            if outcome in ("APPROVED", "IMPROVED"):
                vid = self._version(after, stage, repairs, files)
            self._note(Round(step, stage, sv, sv2, repairs, files, gained,
                             regr, outcome, vid, note))

            if outcome == "APPROVED":
                done.append(stage)
            elif outcome == "REGRESSED":
                return self._stop("BLOCKED", done, stage,
                                  f"נסיגה ב-{', '.join(regr)} — "
                                  "אסור להתקדם")
            elif outcome == "STALLED" and per_stage[stage] >= self.max_rounds:
                return self._stop("STALLED", done, stage,
                                  f"{STAGE_BY_KEY[stage].label}: קיפאון")

        if len(done) == len(GRAPH):
            return self._stop("COMPLETE", done, "",
                              "כל השלבים עברו את השער")
        return self._stop("EXHAUSTED", done, "",
                          f"נגמרו {max_steps} הצעדים")

    # ------------------------------------------------------ פנימי

    @staticmethod
    def _worst(sv: dict) -> float:
        vals = [v for v in sv.get("scores", {}).values() if v is not None]
        return min(vals) if vals else 0.0

    @staticmethod
    def _empty() -> GateResult:
        return GateResult(scores=[])

    def _note(self, r: Round) -> None:
        self.rounds.append(r)
        if self.on_round:
            self.on_round(r)

    def _stop(self, outcome: str, done: list[str], blocked: str,
              why: str) -> MissionResult:
        return MissionResult(outcome=outcome, done=list(done),
                             blocked=blocked,
                             rounds=[r.to_dict() for r in self.rounds],
                             versions=list(self.versions), why=why)


# ====================================================== הרצה אמיתית

def critics_from_panel(detail: dict | None) -> dict[str, float]:
    """ציון מבקר אחד לכל המערכת, מתוך הציונים **לכל דמות**.

    זה היה באג שלי ולא דקדוק: ``panel_test`` שומר את הציונים תחת
    ``per_character``, ולכן קריאה ל-``detail["scores"]`` החזירה מילון
    ריק — כלומר חמשת המבקרים היו מסומנים "לא נמדד" בשקט, והשער היה
    עובר על ממדים שאין להם מודד.

    האיחוד הוא **מינימום על פני הדמויות**: מבקר שנותן 95 לדמות אחת
    ו-50 לשנייה לא מצא מערכת תקינה, הוא מצא בעיה בדמות אחת. ממוצע
    היה מסתיר בדיוק את זה.
    """
    per = (detail or {}).get("per_character") or {}
    out: dict[str, float] = {}
    for row in per.values():
        for name, val in (row.get("scores") or {}).items():
            if _is_num(val):
                out[name] = min(out.get(name, float(val)), float(val))
    return out


def findings_from_panel(detail: dict | None) -> dict[str, list[dict]]:
    """רשומות האבחון של המבקרים, מאוחדות על פני הדמויות.

    האיחוד הוא **איגוד ולא מינימום**, בניגוד לציונים: כשל שנמצא
    בדמות אחת הוא כשל שצריך לתקן, גם אם הדמות השנייה נקייה.
    מינימום על ציון עונה "מה מצב המערכת"; איגוד על כשלים עונה
    "מה צריך לפתוח", וזו שאלה אחרת.

    רשומה כפולה (אותו קוד בשתי הדמויות) נשמרת פעם אחת, לפי הערך
    ה**גרוע** מביניהן — שם הפער גדול יותר ושם כדאי להתחיל.
    """
    per = (detail or {}).get("per_character") or {}
    best: dict[str, dict[str, dict]] = {}
    for who, row in per.items():
        for d in (row.get("diagnosis") or []):
            if not isinstance(d, dict):
                continue
            critic = str(d.get("critic") or "").strip()
            code = str(d.get("code") or "").strip()
            if not code:
                continue
            # הקוד נושא את שם המבקר בקידומת (``anim.jitter``), ולכן
            # גם כשהרשומה לא מצהירה עליו במפורש הוא נגזר ממנה ולא
            # מנוחש. בלי הנפילה הזו רשומה בלי ``critic`` הייתה
            # נזרקת בשקט, כלומר אבחון שנמדד ולא הגיע לאיש.
            if not critic:
                critic = _CRITIC_OF_CODE.get(code.split(".", 1)[0], "")
            if not critic:
                continue
            rec = dict(d, code=code, critic=critic, character=who)
            prev = best.setdefault(critic, {}).get(code)
            if prev is None or _worse(rec, prev):
                best[critic][code] = rec
    return {k: list(v.values()) for k, v in best.items()}


#: קידומת הקוד -> שם המבקר. נגזר מ-``critics.REPAIR_FOR`` בפועל ולא
#: נכתב ביד, כדי שמבקר חדש לא יצטרך שורה כאן.
def _critic_prefixes() -> dict[str, str]:
    try:
        from studio import critics as C
        names = list(getattr(C, "NAMES", ()) or ())
    except Exception:                                       # noqa: BLE001
        names = []
    fixed = {"story": "story", "acting": "acting", "anim": "animation",
             "cine": "cinematography", "vq": "visual"}
    return {p: n for p, n in fixed.items() if not names or n in names}


_CRITIC_OF_CODE: dict[str, str] = _critic_prefixes()


def _worse(a: dict, b: dict) -> bool:
    """האם ``a`` גרוע מ-``b``, לפי איכות מדורגת ואחריה ערך."""
    qa, qb = a.get("quality"), b.get("quality")
    if _is_num(qa) and _is_num(qb):
        return float(qa) < float(qb)
    return False


def measure_system(quality: str = "fast",
                   video: Path | None = None) -> GateResult:
    """מדידה אמיתית של המערכת, מכל המקורות הקיימים.

    מקור שנופל אינו מפיל את המדידה — הממדים שתלויים בו מסומנים
    "לא נמדד". מדידה שנופלת בגלל מקור אחד היא מדידה שלא תרוץ
    בלילה שבו היא באמת נחוצה.
    """
    rep = B.measure(quality=quality, tag="mission")
    critic: dict[str, float] = {}
    master: dict[str, float] = {}
    qa_scores: dict[str, float] = {}
    findings: dict[str, list[dict]] = {}

    try:
        from studio import master as MA
        m = MA.run("full", MA.FPS, video)
        master["audio"] = float(m.audio.score)
        master["mute"] = float(m.mute.score)
        master["panel"] = float(m.panel.score)
        master["full"] = float(m.full)
        critic.update(critics_from_panel(m.panel.detail))
        findings.update(findings_from_panel(m.panel.detail))
    except Exception as exc:                            # noqa: BLE001
        print(f"  (מבחן תקן הזהב לא רץ: {type(exc).__name__}: {exc})",
              file=sys.stderr)

    if video is not None:
        try:
            from studio import qa as QA
            # ``qa.Report.score`` הוא שיעור הבדיקות הטכניות שעברו,
            # והוא כבר מחושב שם. ``checks`` הוא ``list[dict]`` ולא
            # רשימת אובייקטים — קריאה ל-``c.name`` שם נופלת.
            qrep = QA.inspect(Path(video))
            qa_scores["technical"] = float(qrep.score)
        except Exception as exc:                        # noqa: BLE001
            print(f"  (בקרה טכנית לא רצה: {type(exc).__name__}: {exc})",
                  file=sys.stderr)

    return quality_gate(rep, critic_scores=critic, master=master,
                        qa_scores=qa_scores, critic_findings=findings)


def main(argv=None) -> int:
    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(description="שכבת הניהול של המשימה")
    ap.add_argument("--quality", default="fast", choices=("fast", "full"))
    ap.add_argument("--video", default="", help="סרטון לבדיקה טכנית")
    ap.add_argument("--version", action="store_true",
                    help="לרשום גרסה חדשה עם הפסק הזה")
    ap.add_argument("--stage", default="", help="פסק של שלב אחד")
    ap.add_argument("--versions", action="store_true",
                    help="להציג את שרשרת הגרסאות")
    ap.add_argument("--rollback", default="", help="גרסה לחזור אליה")
    ap.add_argument("--apply", action="store_true",
                    help="לבצע את הנסיגה בפועל ולא רק להציג")
    ap.add_argument("--freeze-v0", action="store_true",
                    help="לקבע את המצב הנוכחי כשורש שרשרת הגרסאות")
    ap.add_argument("--run", action="store_true",
                    help="להריץ את לולאת המשימה על הגרף כולו")
    ap.add_argument("--diagnose", action="store_true",
                    help="אבחון שורש לכשלים, עם תת-המערכת האחראית")
    ap.add_argument("--no-repair", action="store_true",
                    help="להריץ את הלולאה בלי מנוע תיקון (אבחון בלבד)")
    ap.add_argument("--tuning", action="store_true",
                    help="להציג את הכוונון שבתוקף")
    ap.add_argument("--reset-tuning", action="store_true",
                    help="להחזיר את הכוונון לברירת המחדל")
    a = ap.parse_args(argv)

    st = VersionStore()

    from studio import tuning as TU
    if a.reset_tuning:
        ok = TU.reset()
        print("הכוונון חזר לברירת המחדל." if ok
              else "הכוונון לא נשמר לדיסק.")
        print(TU.text())
        return 0 if ok else 1

    if a.tuning:
        print(TU.text())
        return 0

    if a.versions:
        idx = st.index()
        if not idx:
            print("אין עוד גרסאות.")
            return 0
        for row in idx:
            mark = {True: "✓", False: "✗"}.get(row.get("passed"), "·")
            print(f" {mark} {row['version_id']:<6} "
                  f"אב={row.get('parent_version') or '—':<6} "
                  f"ציון={row.get('quality_score')} "
                  f"שלב={row.get('stage') or '—'} {row.get('at')}")
        return 0

    if a.rollback:
        plan = st.rollback(a.rollback, apply=a.apply)
        print(json.dumps(plan, ensure_ascii=False, indent=1))
        return 0 if plan["ok"] else 1

    video = Path(a.video) if a.video else None

    if a.run:
        # מדידה אחת למצב אחד: המערכת אינה משתנה בין שלב לשלב בלי
        # שתיקון נגע בה, ומדידה מחדש לכל שלב הייתה שישים שניות
        # לכל שלב על בדיוק אותה תשובה. מטמון לפי מספר הסבב — כך
        # שברגע שיהיה מנוע תיקון, סבב חדש כן נמדד מחדש.
        cache: dict[int, GateResult] = {}

        def measure(stage: str, n: int) -> GateResult:
            if n not in cache:
                cache[n] = measure_system(a.quality, video)
            return cache[n]

        t0 = time.time()
        eng = None if a.no_repair else RepairEngine()
        mis = Mission(measure=measure, repair=eng, store=st)
        res = mis.run()
        print(cache[0].text() if cache else "(לא נמדד)")
        print()
        print(res.text())
        if cache and res.blocked:
            print()
            print(diagnosis_text(diagnose(cache[max(cache)], res.blocked)))
        print(f"  ({time.time() - t0:.1f} שניות)")
        return 0 if res.complete else 1

    t0 = time.time()
    g = measure_system(a.quality, video)
    print(g.text())
    print(f"  ({time.time() - t0:.1f} שניות)")

    if a.freeze_v0:
        rec = st.baseline_v0(gate=g)
        print(f"\n{V0}: ציון {rec['quality_score']} · "
              f"נקודה {(rec.get('commit') or '')[:8] or '—'}")

    if a.stage:
        print("\n" + json.dumps(stage_verdict(g, a.stage),
                                ensure_ascii=False, indent=1))

    if a.diagnose:
        print("\n" + diagnosis_text(diagnose(g, a.stage)))

    if a.version:
        rec = st.create(gate=g, stage=a.stage or "audit")
        print(f"\nנרשמה גרסה {rec['version_id']} "
              f"(אב {rec['parent_version'] or '—'}) · "
              f"ציון {rec['quality_score']}")

    return 0 if g.passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
