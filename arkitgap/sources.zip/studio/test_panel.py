# -*- coding: utf-8 -*-
"""בדיקות לחמשת המבקרים, לפאנל וללולאת השיפור.

**כל בדיקת מבקר היא דו-כיוונית, וזה התנאי שהופך אותה לבדיקה.**
מבקר שרק נכשל על שוט שבור הוא קל לכתוב וחסר ערך — אפשר להחזיר
תמיד 0. מבקר שרק עובר על שוט תקין חסר ערך בדיוק באותה מידה.
לכן כל שורה כאן מריצה **את אותו מבקר פעמיים**: על שוט תקין שחייב
לעבור, ועל אותו שוט שנשבר *רק בממד שלו* — וגם מאמתת שהשבירה
נתפסה בקוד המדידה הנכון ולא ב"משהו נכשל".

השוט הסינתטי נבנה כאן ולא מרונדר, ולכן כל החבילה רצה בשניות: אין
דפדפן, אין מקודד, אין GPU. זה מה שמאפשר להריץ אותה אחרי כל שינוי.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from studio import critics as C        # noqa: E402
from studio import panel as P         # noqa: E402

FPS = 30
SECS = 10.0
N = int(SECS * FPS)


# ======================================================== בניית שוט תקין

def _smooth(u: np.ndarray) -> np.ndarray:
    u = np.clip(u, 0.0, 1.0)
    return u * u * (3.0 - 2.0 * u)


def _ramp(t: np.ndarray, t0: float, dur: float, amp: float,
          anticip: float = 0.12) -> np.ndarray:
    """עקומה מאויישת עם תנועת-נגד קצרה לפניה (ציפייה).

    זו ה"תנועה המקצועית" שהמבקר אמור לאשר: תנועת-נגד קטנה, האצה,
    האטה, והחזקה בסוף. פרופיל המהירות של smoothstep הוא 6u(1-u) —
    שיא 1.5 מול ממוצע 1.0, כלומר בדיוק מה ש-`anim.easing` מחפש.
    """
    y = amp * _smooth((t - t0) / dur)
    pre = (t >= t0 - 0.25) & (t < t0)
    if pre.any():
        w = (t[pre] - (t0 - 0.25)) / 0.25
        y[pre] = -amp * anticip * np.sin(np.pi * w)
    y[t < t0 - 0.25] = 0.0
    return y


def good_track(seed: int = 7) -> dict:
    """מסלול פוזות של שוט מבויים היטב.

    כל התכונות שהמבקרים דורשים נבנות כאן במכוון: הסטה בזמן בין
    האזורים (חפיפה), ציפייה לפני כל תנועה, איוש, שיער ובגד
    שמפגרים אחרי הראשי, החזקה ברביע האחרון, ומיקרו-נשימה בזנב
    כדי שההחזקה לא תהיה מוות קליני.
    """
    rng = np.random.default_rng(seed)
    t = np.arange(N) / FPS
    chans: dict[str, np.ndarray] = {}

    # --- פנים: עולות בהדרגה לאורך השוט (מגמה חד-כיוונית = קריא בלי קול)
    chans["brow_l"] = _ramp(t, 3.2, 1.3, 0.42) + _ramp(t, 6.4, 1.1, 0.22)
    chans["brow_r"] = chans["brow_l"] * 0.80          # אסימטריה
    chans["lid_l"] = _ramp(t, 3.4, 1.0, 0.30)
    chans["lid_r"] = chans["lid_l"] * 0.86
    chans["mouth_open"] = _ramp(t, 6.6, 0.9, 0.26)
    chans["gaze_x"] = _ramp(t, 5.2, 0.7, 0.33) - _ramp(t, 6.0, 0.7, 0.33)

    # --- גוף: אזורים מוסטים בזמן
    chans["head_yaw"] = _ramp(t, 1.0, 1.2, 0.36) - _ramp(t, 5.3, 0.8, 0.18)
    chans["neck_pitch"] = _ramp(t, 1.15, 1.2, 0.17)
    chans["spine_roll"] = _ramp(t, 4.7, 1.4, 0.21)
    chans["shoulder_l"] = _ramp(t, 1.35, 1.1, 0.19)
    chans["shoulder_r"] = _ramp(t, 1.55, 1.1, 0.15)
    chans["hand_l"] = _ramp(t, 6.8, 1.0, 0.28)
    chans["hand_r"] = _ramp(t, 7.0, 1.0, 0.13)
    chans["hip_shift"] = _ramp(t, 4.4, 1.6, 0.24)

    # --- תנועה משנית: אותו אות, מושהה (פיגור של 4 פריימים)
    lag = 4
    for name, src in (("hair_sway", "head_yaw"), ("cloth_hem", "spine_roll"),
                      ("sleeve_soft", "shoulder_l")):
        s = chans[src]
        chans[name] = np.concatenate([np.full(lag, s[0]), s[:-lag]]) * 0.55

    # --- מיקרו-נשימה: קטנה מכדי להיחשב תנועה, גדולה מכדי להיות מוות
    breath = 0.004 * np.sin(2 * np.pi * 0.28 * t)
    for k in ("spine_roll", "chest_rise" if "chest_rise" in chans else "neck_pitch"):
        chans[k] = chans[k] + breath
    chans["chest_rise"] = 0.012 * np.sin(2 * np.pi * 0.26 * t) + \
        _ramp(t, 2.0, 2.0, 0.05)

    keys = list(chans)
    M = np.stack([chans[k] for k in keys], axis=1)
    M += rng.normal(0.0, 2e-5, M.shape)       # רעש מדידה זניח
    return {"times": t, "keys": keys, "M": M}


def good_plan() -> dict:
    return {
        "knows": "שהמשפט שלו נוגע בה אישית",
        "wants": "לא להראות שזה פגע בה",
        "feels": "אי-נוחות שהולכת וגוברת",
        "hides": "פגיעוּת",
        "looking_at": "לוקאס",
        "intention": "לשמור על פנים",
        "subtext": "אני לא מוכנה לדבר על זה",
        "arc": {"turn": 4.6, "dvalence": -0.42, "darousal": 0.31},
        "beats": 4,
        "seconds": SECS,
    }


def good_events() -> dict:
    return {b: {"found": True, "at": 1.0 + i * 0.9}
            for i, b in enumerate(C.REQUIRED_BEATS)}


def good_camera(jerky: bool = False) -> list[dict]:
    u = np.linspace(0, 1, N)
    e = _smooth(u)
    yaw = -14.0 + 20.0 * e
    if jerky:
        yaw = yaw + 6.0 * ((np.arange(N) % 3) - 1)
    return [{"yaw": float(yaw[i]), "pitch": float(1.5 - 2.5 * e[i]),
             "dist": 2.4, "tx": 0.0, "ty": 0.92, "fov": 30.0}
            for i in range(N)]


def good_subject(crop: bool = False) -> np.ndarray:
    u = np.linspace(0, 1, N)
    y0 = 0.125 + 0.004 * np.sin(2 * np.pi * u)
    y1 = 0.95 + 0.003 * np.cos(2 * np.pi * u)
    x0 = 0.285 + 0.01 * u
    x1 = 0.735 + 0.01 * u
    if crop:
        y0 = y0 * 0.0 + 0.001          # הראש חתוך בשפה העליונה
        x1 = x1 * 0.0 + 0.999
    return np.stack([x0, y0, x1, y1], axis=1)


class FakeSample:
    """``qa.Sample`` מצומצם — רק מה שהמבקרים קוראים.

    נבנה ידנית ולא מרונדר: המבקרים קוראים ``gray``, ``n``, ``times``,
    ובדיוק זה מה שיש כאן. כך אין דפדפן בחבילת הבדיקות.
    """

    def __init__(self, gray: np.ndarray, times: np.ndarray, fps: float = FPS):
        self.gray = gray
        self.times = times
        self.fps = fps
        self.width, self.height = 1280, 720
        self.frames_decoded = gray.shape[0]
        self.duration_declared = gray.shape[0] / fps
        self.decode_error = ""

    @property
    def n(self) -> int:
        return int(self.gray.shape[0])


def good_gray(nf: int = 100, h: int = 90, w: int = 160,
              flat: bool = False, clipped: bool = False,
              flicker: bool = False) -> np.ndarray:
    """פריימים אפורים: גרדיאנט רקע + דמות בהירה שזזה פיקסל לפריים."""
    yy = np.linspace(0.22, 0.58, h)[:, None] * np.ones((1, w))
    xx = 0.04 * np.linspace(-1, 1, w)[None, :]
    bg = yy + xx
    out = np.empty((nf, h, w), dtype=np.float64)
    for i in range(nf):
        f = bg.copy()
        if not flat:
            cx = int(w * 0.5 + 6 * np.sin(2 * np.pi * i / nf))
            f[int(h * 0.20):int(h * 0.86),
              max(0, cx - 22):min(w, cx + 22)] += 0.26
            f[int(h * 0.22):int(h * 0.40),
              max(0, cx - 11):min(w, cx + 11)] += 0.10   # ראש בהיר יותר
        if flicker and i % 4 == 0:
            f += 0.22
        if clipped:
            f = f * 2.6 - 0.5
        out[i] = np.clip(f, 0.0, 1.0)
    if flat:
        out = np.clip(out * 0.08 + 0.46, 0.0, 1.0)
    return out


def good_color(nf: int = 24, h: int = 24, w: int = 40) -> np.ndarray:
    """פלטה הרמונית: גוון בסיס אחד + משלים חלש."""
    c = np.zeros((nf, h, w, 3))
    c[..., 0] = 0.72
    c[..., 1] = 0.48
    c[..., 2] = 0.30
    c[:, :, : w // 5, 0] = 0.30
    c[:, :, : w // 5, 1] = 0.46
    c[:, :, : w // 5, 2] = 0.70
    return c


def good_evidence(**over) -> C.Evidence:
    gray = over.pop("gray", None)
    if gray is None:
        gray = good_gray()
    nf = gray.shape[0]
    ev = C.Evidence(
        shot_id="t_good", seconds=SECS,
        plan=good_plan(), track=good_track(), events=good_events(),
        camera=good_camera(), subject=good_subject(),
        sample=FakeSample(gray, np.linspace(0, SECS, nf)),
        color=good_color(),
    )
    for k, v in over.items():
        setattr(ev, k, v)
    return ev


def _codes(v: C.Verdict) -> list[str]:
    return [m["code"] for m in v.failures]


# ======================================================== מבקר-מבקר

def _two_way(name: str, broken: C.Evidence, expect: str) -> tuple[bool, str]:
    """תקין עובר, שבור נכשל, **ובקוד שמצופה**."""
    g = C.review_one(name, good_evidence())
    b = C.review_one(name, broken)
    bad = _codes(b)
    ok = (g.score >= P.PASS_FLOOR and b.score < P.PASS_FLOOR
          and expect in bad)
    return ok, (f"תקין {g.score:.1f} (כשלים {_codes(g) or '—'}) · "
                f"שבור {b.score:.1f} · נתפס: {', '.join(bad) or '—'}")


def t_story(_) -> tuple[bool, str]:
    """שוט בלי מהפך רגשי אינו ביט — גם אם האנימציה מושלמת."""
    ev = good_evidence()
    ev.plan = dict(good_plan(), arc={}, hides="", beats=1)
    return _two_way("story", ev, "story.turn")


def t_acting(_) -> tuple[bool, str]:
    """הפנים קפואות: הגוף זז, אבל אין רגש ואין אזורים חיים."""
    ev = good_evidence()
    tr = good_track()
    M = tr["M"].copy()
    for i, k in enumerate(tr["keys"]):
        if C.region_of(k) in ("גבה", "עפעף", "עין", "מבט", "אישון", "פה"):
            M[:, i] = 0.0
    ev.track = {**tr, "M": M}
    ev.events = {b: {"found": i < 3} for i, b in enumerate(C.REQUIRED_BEATS)}
    ev.perf = np.zeros(N)
    return _two_way("acting", ev, "acting.beats")


def t_animation(_) -> tuple[bool, str]:
    """אינטרפולציה ליניארית + רעידה: עובר כל בדיקה טכנית, ונפסל כאן."""
    ev = good_evidence()
    tr = good_track()
    t = tr["times"]
    rng = np.random.default_rng(3)
    M = np.zeros_like(tr["M"])
    for i in range(M.shape[1]):
        amp = float(tr["M"][:, i].max() - tr["M"][:, i].min()) or 0.2
        M[:, i] = amp * np.clip((t - 1.0) / 7.0, 0, 1)      # ליניארי לגמרי
    M += rng.normal(0.0, 0.004, M.shape)                     # רעידה
    ev.track = {**tr, "M": M}
    return _two_way("animation", ev, "anim.easing")


def t_cinematography(_) -> tuple[bool, str]:
    """הדמות נחתכת בשפת הקאדר והמצלמה מקרטעת."""
    ev = good_evidence()
    ev.subject = good_subject(crop=True)
    ev.camera = good_camera(jerky=True)
    return _two_way("cinematography", ev, "cine.crop")


def t_visual(_) -> tuple[bool, str]:
    """תמונה שטוחה: התאורה לא נדלקה. אין שגיאה, אין קפיאה, יש פגם."""
    ev = good_evidence(gray=good_gray(flat=True))
    return _two_way("visual", ev, "vq.contrast")


def t_visual_flicker(_) -> tuple[bool, str]:
    """ריצוד — הפגם שאי אפשר לראות בצילום מסך בודד."""
    ev = good_evidence(gray=good_gray(flicker=True))
    v = C.review_one("visual", ev)
    return "vq.flicker" in _codes(v), \
        f"ציון {v.score:.1f} · {', '.join(_codes(v)) or '—'}"


# ======================================================== בידוד והיעדר עדות

def t_isolation(_) -> tuple[bool, str]:
    """מבקר הסיפור *אינו יכול* לגשת לפיקסלים, וההפך."""
    ev = good_evidence()
    hits = []
    try:
        _ = ev.view("story").sample
        hits.append("סיפור קרא פיקסלים")
    except AttributeError:
        pass
    try:
        _ = ev.view("visual").plan
        hits.append("איכות חזותית קראה את התוכנית")
    except AttributeError:
        pass
    try:
        _ = ev.view("animation").events
        hits.append("אנימציה קראה את האירועים")
    except AttributeError:
        pass
    return not hits, "שלושת הגבולות נאכפו" if not hits else str(hits)


def t_no_evidence_fails(_) -> tuple[bool, str]:
    """חוסר עדות = 0, לא פטור. מבקר מורעב לא מאשר שוט."""
    ev = good_evidence()
    ev.plan = None
    v = C.review_one("story", ev)
    pv = P.Panel().review(ev)
    return (v.score == 0.0 and not v.available and not pv.passed
            and pv.weakest == "story"), \
        f"סיפור {v.score} (זמין={v.available}) · פאנל: {pv.gate}"


def t_critic_crash_is_failure(_) -> tuple[bool, str]:
    """מבקר שנפל אינו מבקר שאישר."""
    ev = good_evidence()
    ev.track = {"times": np.arange(40) / 30.0, "keys": ["a", "b"],
                "M": np.zeros((9, 2))}          # ממדים לא עקביים
    v = C.review_one("animation", ev)
    return v.score < P.PASS_FLOOR and not v.available, \
        f"ציון {v.score} · {', '.join(_codes(v))}"


# ======================================================== הפאנל

def t_panel_passes_good(_) -> tuple[bool, str]:
    pv = P.Panel().review(good_evidence())
    return pv.passed, pv.text().splitlines()[0]


def t_veto_beats_mean(_) -> tuple[bool, str]:
    """95/92/90/88/18 — ממוצע 76.6 ובכל זאת נפילה. זה כל העניין."""
    pn = P.Panel()
    sc = {"story": 95.0, "acting": 92.0, "animation": 90.0,
          "cinematography": 88.0, "visual": 18.0}
    ok, gate = pn._gate(sc)
    mean = sum(sc.values()) / 5
    return (not ok and "ווטו" in gate and mean > 70), \
        f"ממוצע {mean:.1f} · {gate}"


def t_mean_gate(_) -> tuple[bool, str]:
    """כולם בדיוק על הרצפה — ועדיין לא עוברים, כי הממוצע נמוך."""
    pn = P.Panel()
    sc = {n: 71.0 for n in C.NAMES}
    ok, gate = pn._gate(sc)
    sc2 = {n: 84.0 for n in C.NAMES}
    ok2, _ = pn._gate(sc2)
    return (not ok and "ממוצע" in gate and ok2), gate


def t_weakest_precedence(_) -> tuple[bool, str]:
    """תיקו בין צמודים נשבר בסדר התלות — לא ברעש.

    סיפור 60.5 מול אנימציה 62.0: המינימום הגולמי הוא הסיפור, אבל
    הפער קטן מאזור התיקו, ולכן מתוקנת **האנימציה** — היסוד שעליו
    מדידת הסיפור יושבת. הפוך מבחירת המינימום, ובמכוון.
    """
    pn = P.Panel()
    a = pn.weakest({"story": 60.5, "acting": 90.0, "animation": 62.0,
                    "cinematography": 90.0, "visual": 90.0})
    pn2 = P.Panel()
    b = pn2.weakest({"story": 55.0, "acting": 90.0, "animation": 90.0,
                     "cinematography": 90.0, "visual": 90.0})
    return a == "animation" and b == "story", \
        f"תיקו → {C.HE[a]} · מינימום בודד → {C.HE[b]}"


def t_weakest_sticky(_) -> tuple[bool, str]:
    """חוליה שתוקנה ושיפרה — ממשיכים עליה ולא מתחלפים."""
    pn = P.Panel()
    pn.weakest({"story": 50.0, "acting": 90.0, "animation": 90.0,
                "cinematography": 90.0, "visual": 90.0})      # story
    pick = pn.weakest({"story": 56.0, "acting": 90.0, "animation": 90.0,
                       "cinematography": 90.0, "visual": 58.0})
    return pick == "story", f"אחרי שיפור של 6 נקודות → {C.HE[pick]}"


def t_weakest_abandons_stuck(_) -> tuple[bool, str]:
    """חוליה שלא שיפרה — עוברים לבא בתור לפי סדר התלות."""
    pn = P.Panel()
    pn.weakest({"story": 50.0, "acting": 90.0, "animation": 90.0,
                "cinematography": 90.0, "visual": 90.0})
    pick = pn.weakest({"story": 50.2, "acting": 90.0, "animation": 90.0,
                       "cinematography": 90.0, "visual": 52.0})
    return pick == "visual", f"בלי שיפור → {C.HE[pick]}"


def t_diagnosis_names_repair(_) -> tuple[bool, str]:
    """אבחון מחזיר ידית תיקון קונקרטית, לא "לתקן אנימציה"."""
    ev = good_evidence(gray=good_gray(flat=True))
    pv = P.Panel().review(ev)
    return (pv.weakest == "visual" and pv.diagnosis
            and "relight" in pv.repairs), \
        f"חלש: {C.HE[pv.weakest]} · תיקונים {pv.repairs}"


# ======================================================== הלולאה

def _loop(defect_rounds: int, **kw):
    """לולאה מדומה: הפגם נעלם אחרי ``defect_rounds`` סבבים."""
    state = {"round": 0}

    def render(knobs, n):
        state["round"] = n
        return knobs

    def evidence(knobs, n):
        broken = n <= defect_rounds and not knobs.get("relight")
        return good_evidence(gray=good_gray(flat=broken))

    def apply(knobs, repairs, pv):
        k = dict(knobs)
        for r in repairs:
            k[r] = True
        return k

    return P.RefineLoop("t_loop", render, evidence, apply, **kw)


def t_loop_converges(_) -> tuple[bool, str]:
    """**הבדיקה המרכזית.** נכשל → אובחן → תוקן → רונדר שוב → עבר."""
    res = _loop(1).run()
    r1 = res.rounds[0]
    return (res.passed and len(res.rounds) == 2
            and r1["weakest"] == "visual"
            and "relight" in r1["applied"]), \
        (f"{res.outcome} ב-{len(res.rounds)} סבבים · "
         f"סבב 1: {C.HE[r1['weakest']]} {r1['worst']:.1f} → "
         f"{r1['applied']} · סבב 2 מינימום {res.rounds[-1]['worst']:.1f}")


def t_loop_stalls_not_passes(_) -> tuple[bool, str]:
    """קיפאון נקרא קיפאון. "התכנסו אז עבר" הוא שקר.

    שלושה ממדים שבורים, ולכן יש תמיד תיקון חדש להציע — ואף תיקון
    לא מזיז את הציון. זה המצב היחיד שבו אסור להכריז הצלחה, והוא
    שונה גם מ"נגמרו הסבבים" וגם מ"נגמר ספר התיקונים".
    """
    def render(knobs, n):
        return knobs

    def evidence(knobs, n):
        ev = good_evidence(gray=good_gray(flat=True),
                           subject=good_subject(crop=True),
                           camera=good_camera(jerky=True))
        ev.plan = dict(good_plan(), arc={}, hides="", beats=1,
                       knows="", wants="")
        return ev

    def apply(knobs, repairs, pv):
        return dict(knobs, **{f"{r}_{i}": True
                              for i, r in enumerate(repairs)})

    res = P.RefineLoop("t_stall", render, evidence, apply,
                       max_rounds=9).run()
    targets = [r["target"] for r in res.rounds if r["target"]]
    return (res.outcome == P.STALLED and not res.passed
            and len(res.rounds) == P.PLATEAU_ROUNDS + 1
            and len(set(targets)) >= 2), \
        (f"{res.outcome} אחרי {len(res.rounds)} סבבים · יעדי תיקון "
         f"{[C.HE[x] for x in targets]} · {res.why}")


def t_loop_detects_regression(_) -> tuple[bool, str]:
    """תיקון שמשפר את A ומפיל את B נתפס, נפסל, והלולאה עוצרת."""
    def render(knobs, n):
        return knobs

    def evidence(knobs, n):
        # התיקון "relight" מתקן את התמונה — ושובר את הקאדר
        if knobs.get("relight"):
            return good_evidence(subject=good_subject(crop=True),
                                 camera=good_camera(jerky=True))
        return good_evidence(gray=good_gray(flat=True))

    def apply(knobs, repairs, pv):
        return dict(knobs, **{r: True for r in repairs})

    res = P.RefineLoop("t_reg", render, evidence, apply, max_rounds=6).run()
    regs = [r for r in res.rounds if r["regression"]]
    return (bool(regs) and not res.passed), \
        f"{res.outcome} · רגרסיה ב-{regs[0]['regression'] if regs else '—'} · {res.why}"


def t_loop_noop_repair_stops(_) -> tuple[bool, str]:
    """תיקון שלא משנה שום ידית = לא מרנדרים שוב את אותו דבר."""
    def render(knobs, n):
        return knobs

    def evidence(knobs, n):
        return good_evidence(gray=good_gray(flat=True))

    res = P.RefineLoop("t_noop", render, evidence,
                       lambda k, r, pv: dict(k), max_rounds=6).run()
    return (res.outcome == P.EXHAUSTED and len(res.rounds) == 1
            and "ידית" in res.why), f"{res.outcome} · {res.why}"


def t_loop_keeps_best(_) -> tuple[bool, str]:
    """לולאה שנעצרת נסוגה לגרסה הטובה ביותר שנמדדה בפועל."""
    seq = {"n": 0}

    def render(knobs, n):
        seq["n"] = n
        return knobs

    def evidence(knobs, n):
        # סבב 2 הוא הטוב ביותר שנמדד — ובכל זאת אינו עובר, כי
        # הדמות עדיין נחתכת. שאר הסבבים גרועים ממנו בשני ממדים.
        return good_evidence(gray=good_gray(flat=(n != 2)),
                             subject=good_subject(crop=True),
                             camera=good_camera(jerky=(n != 2)))

    def apply(knobs, repairs, pv):
        return dict(knobs, **{f"{r}_{len(knobs)}": True for r in repairs})

    res = P.RefineLoop("t_best", render, evidence, apply, max_rounds=4).run()
    worsts = [r["worst"] for r in res.rounds]
    return (res.best_round == 2 and not res.passed), \
        f"{res.outcome} · מינימומים {[round(w,1) for w in worsts]} · " \
        f"נבחר סבב {res.best_round}"


def t_loop_reports_round_detail(_) -> tuple[bool, str]:
    """הדוח מכיל לכל סבב: ציונים, חוליה חלשה, ותיקון שהוחל."""
    res = _loop(1).run()
    r = res.rounds[0]
    keys = {"n", "scores", "worst", "mean", "weakest", "repairs",
            "applied", "render_sec"}
    return (keys <= set(r) and len(r["scores"]) == 5), \
        f"{len(r['scores'])} ציונים · שדות {sorted(set(r) & keys)}"


TESTS = [
    ("סיפור: שוט בלי מהפך רגשי נופל", t_story),
    ("משחק: פנים קפואות נופלות", t_acting),
    ("אנימציה: אינטרפולציה ליניארית נופלת", t_animation),
    ("צילום: דמות חתוכה ומצלמה מקרטעת נופלות", t_cinematography),
    ("איכות חזותית: תמונה שטוחה נופלת", t_visual),
    ("איכות חזותית: ריצוד בין פריימים נתפס", t_visual_flicker),
    ("בידוד המבקרים נאכף בקוד", t_isolation),
    ("מבקר בלי עדות מקבל 0 ולא פטור", t_no_evidence_fails),
    ("מבקר שנפל נחשב כשל ולא אישור", t_critic_crash_is_failure),
    ("שוט מבויים היטב עובר את כל החמישה", t_panel_passes_good),
    ("ווטו גובר על ממוצע גבוה", t_veto_beats_mean),
    ("רצפה לכולם אינה מספיקה בלי ממוצע", t_mean_gate),
    ("חוליה חלשה: תיקו נשבר בסדר התלות", t_weakest_precedence),
    ("חוליה חלשה: דביקות כשהתיקון עובד", t_weakest_sticky),
    ("חוליה חלשה: נטישה כשאין שיפור", t_weakest_abandons_stuck),
    ("אבחון מחזיר ידית תיקון קונקרטית", t_diagnosis_names_repair),
    ("לולאה: נכשל → אובחן → תוקן → עבר", t_loop_converges),
    ("לולאה: קיפאון אינו הצלחה", t_loop_stalls_not_passes),
    ("לולאה: רגרסיה נתפסת והתיקון נפסל", t_loop_detects_regression),
    ("לולאה: תיקון ריק עוצר מיד", t_loop_noop_repair_stops),
    ("לולאה: נסיגה לגרסה הטובה שנמדדה", t_loop_keeps_best),
    ("דוח הלולאה מפורט לכל סבב", t_loop_reports_round_detail),
]


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8")
    ok = 0
    for name, fn in TESTS:
        try:
            passed, detail = fn(None)
        except Exception as exc:                        # noqa: BLE001
            import traceback
            passed = False
            detail = (f"{type(exc).__name__}: {exc} | "
                      f"{traceback.format_exc().splitlines()[-3][:70]}")
        print(f"{'✓' if passed else '✗'} {name:<44} {detail}")
        ok += bool(passed)
    print(f"\n{ok}/{len(TESTS)} עברו")
    return 0 if ok == len(TESTS) else 1


if __name__ == "__main__":
    raise SystemExit(main())
