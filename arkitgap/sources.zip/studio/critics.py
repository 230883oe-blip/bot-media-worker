# -*- coding: utf-8 -*-
"""חמישה מבקרים עצמאיים — שלב 21, "QA של עצמו".

**מה זה פותר, ולמה זה לא `qa.py` מורחב.**
`studio/qa.py` מודד *תקינות טכנית*: הקובץ שלם, המשך נכון, הפריימים
לא קפואים, האזור הדינמי התעדכן. כל אחת מהבדיקות שם נולדה מתקלה
אמיתית — ואף אחת מהן לא יודעת להגיד שהשוט **גרוע**. שוט יכול לעבור
את כל עשר הבדיקות הטכניות ולהיות אנימציה רובוטית, בקאדר רע, בלי
סיפור, עם דמות שנראית כמו בובה מוקפאת. זו הייתה המציאות כאן עד
היום: ציון 100 בבקרת האיכות על שוט שאף במאי לא היה מאשר.

לכן נוספה שכבה שנייה, ובה חמישה מבקרים שכל אחד שואל שאלה אחרת:

| מבקר | השאלה שהוא שואל | ממה הוא מודד |
|---|---|---|
| סיפור | יש כאן בכלל *בּיט* דרמטי? | התוכנית הסמלית בלבד |
| משחק | הדמות משחקת או מניעה שרירים? | מסלול הפוזות + האירועים |
| אנימציה | התנועה מקצועית או ליניארית? | נגזרות מסלול הפוזות |
| צילום | הקאדר מביים או רק מצלם? | מסלול המצלמה + הקאדר |
| איכות חזותית | התמונה עצמה נקייה? | פיקסלים בלבד |

**שלוש החלטות שמגדירות את המודול, וכל אחת מהן נגד מלכודת ממשית.**

1. **"עצמאיים" נאכף בקוד, לא בכוונות.** מבקר אינו מקבל את אובייקט
   העדות המלא אלא `Evidence.view(name)` — מבט שמכיל רק את מקורות
   המידע שהוכרזו עבורו ב-`SOURCES`. מבקר הסיפור *אינו יכול* להציץ
   בפיקסלים, ומבקר האיכות החזותית אינו יכול לקרוא את התוכנית. בלי
   זה "חמישה מבקרים" מתנוון בשקט לחמש תצוגות של אותה מדידה, ואז
   חמישה ציונים נראים כמו הסכמה רחבה כשהם בעצם מספר אחד.

2. **חוסר עדות הוא כישלון, לא פטור.** מבקר שלא קיבל את המקור שלו
   מחזיר ציון 0 עם הכשל `no_evidence` — ולא נפסל מהפאנל. ההיגיון:
   הדרך הקלה ביותר להעלים מבקר טורדני היא להפסיק להאכיל אותו, וזו
   בדיוק הדרך שבה נוצרת הצלחה מדומה.

3. **ציון מדורג, לא ספירת וי.** כל מדידה מחזירה `quality` ברצף
   0..1 וגם `ok` בוליאני. הציון הוא ממוצע משוקלל של ה-quality, כך
   ששיפור אמיתי שעוד לא עבר את הסף **נראה** בציון. בלי זה לולאת
   התיקון עיוורת: היא לא יכולה לדעת אם התיקון הקודם קירב או הרחיק.

**והמלכודת הרביעית, שהיא הסיבה שחצי מהמדידות כאן קיימות:** כל מדד
של "יש תנועה" ניתן לרמות על ידי יותר תנועה. לכן לכל מבקר יש גם
מדידה בכיוון ההפוך — `acting.restraint` נגד הגזמה, `anim.holds`
נגד ריחוף מתמיד, `cine.scale` נגד זום מתפרע. מדד חד-כיווני אינו
מבקר, הוא מכונת ניקוד.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field, asdict
from typing import Any, Callable, Optional, Sequence

import numpy as np

EPS = 1e-9

#: שמות חמשת המבקרים, בסדר הקדימות של התיקון (יסוד ראשון).
NAMES = ("visual", "cinematography", "animation", "acting", "story")

#: מה מותר לכל מבקר לראות. זה **לא** תיעוד — `Evidence.view` אוכף.
SOURCES: dict[str, tuple[str, ...]] = {
    "story":          ("shot_id", "seconds", "plan"),
    "acting":         ("shot_id", "seconds", "track", "events", "perf"),
    "animation":      ("shot_id", "seconds", "track"),
    "cinematography": ("shot_id", "seconds", "camera", "subject", "sample"),
    "visual":         ("shot_id", "seconds", "sample", "color"),
}

#: מדידה -> פעולת התיקון הקונקרטית. זה מה שהופך "אשמה" ל"ידית".
#: המנהל מצרף את הפעולה לשוט, והרינדור הבא קורא אותה מ-`shot.knobs`.
REPAIR_FOR: dict[str, str] = {
    # סיפור
    "story.premise":      "write_situation",      # להשלים יודע/רוצה/מרגיש
    "story.object":       "set_scene_partner",    # למי הדמות מדברת
    "story.turn":         "place_turn",           # להזיז את נקודת המהפך
    "story.change":       "widen_arc",            # להגדיל את השינוי הרגשי
    "story.subtext":      "add_subtext",          # מה הדמות מסתירה
    "story.resolution":   "extend_tail",          # זמן לנחיתה אחרי המהפך
    "story.economy":      "split_shot",           # יותר מדי ביטים בשוט אחד
    # משחק
    "acting.beats":       "stage_beats",
    "acting.silent":      "strengthen_silent",
    "acting.continuity":  "hold_emotion",
    "acting.asymmetry":   "break_symmetry",
    "acting.alive":       "activate_regions",
    "acting.restraint":   "reduce_mugging",
    # אנימציה
    "anim.jitter":        "smooth_curves",
    "anim.pops":          "fix_discontinuity",
    "anim.easing":        "apply_easing",
    "anim.anticipation":  "add_anticipation",
    "anim.overlap":       "offset_regions",
    "anim.followthrough": "add_followthrough",
    "anim.holds":         "insert_hold",
    # צילום
    "cine.headroom":      "reframe_headroom",
    "cine.thirds":        "reframe_eyeline",
    "cine.scale":         "adjust_shot_size",
    "cine.crop":          "pull_camera_back",
    "cine.smooth":        "smooth_camera",
    "cine.depth":         "separate_from_bg",
    "cine.axis":          "keep_screen_direction",
    # איכות חזותית
    "vq.exposure":        "fix_exposure",
    "vq.contrast":        "relight",
    "vq.sharpness":       "raise_supersample",
    "vq.flicker":         "stabilize_shading",
    "vq.banding":         "raise_bitdepth",
    "vq.stability":       "reencode",
    "vq.harmony":         "retune_palette",
}


# ============================================================== עדות

@dataclass
class Evidence:
    """כל מה שידוע על שוט אחד. אף מבקר לא רואה את זה במלואו.

    * `plan` — התוכנית הסמלית: ``knows/wants/feels/hides/looking_at``,
      ``intention``, ``subtext``, ``arc={turn,dvalence,darousal}``,
      ``beats`` (מספר הביטים).
    * `track` — מסלול הפוזות: ``{"times": (n,), "keys": [k], "M": (n,k)}``.
      זה נדגם מהסצנה עצמה ולא מהפיקסלים, ולכן זמין **בלי רינדור**.
    * `events` — פלט ``cinema.find_events`` (שמונת אירועי המשחק).
    * `perf` — עקומת "ציון הרגש" לאורך הזמן, ``(n,)``.
    * `camera` — רשימת מילוני מצלמה לכל זמן נדגם (yaw/pitch/dist/ty/fov).
    * `subject` — תיבת הדמות בקאדר, ``(n,4)`` ביחידות 0..1.
    * `sample` — ``qa.Sample`` מהסרטון המרונדר.
    * `color` — דגימת צבע קטנה ``(n,h,w,3)`` בטווח 0..1.
    """

    shot_id: str = ""
    seconds: float = 0.0
    plan: Optional[dict] = None
    track: Optional[dict] = None
    events: Optional[dict] = None
    perf: Optional[np.ndarray] = None
    camera: Optional[list[dict]] = None
    subject: Optional[np.ndarray] = None
    sample: Any = None
    color: Optional[np.ndarray] = None

    def view(self, critic: str) -> "EvidenceView":
        allowed = SOURCES.get(critic)
        if allowed is None:
            raise KeyError(f"אין מבקר בשם {critic}")
        return EvidenceView(self, allowed)

    def has(self, field_name: str) -> bool:
        v = getattr(self, field_name, None)
        if v is None:
            return False
        if isinstance(v, np.ndarray):
            return v.size > 0
        if isinstance(v, (dict, list, tuple)):
            return len(v) > 0
        return True


class EvidenceView:
    """מבט מצומצם על העדות. גישה לשדה שלא הוכרז זורקת.

    **זו ההגנה על "עצמאיים".** בגרסה הראשונה המבקרים קיבלו את
    `Evidence` עצמו, ותוך עשר דקות מבקר הצילום כבר קרא את התוכנית
    הסמלית "רק כדי לדעת מה גודל השוט המתוכנן". ברגע שזה קורה,
    שני ציונים מפסיקים להיות שתי עדויות.
    """

    __slots__ = ("_ev", "_allowed")

    def __init__(self, ev: Evidence, allowed: Sequence[str]):
        self._ev = ev
        self._allowed = tuple(allowed)

    def __getattr__(self, name: str):
        if name not in self._allowed:
            raise AttributeError(
                f"מבקר שאינו מורשה ניגש ל-{name!r}. "
                f"מורשה: {', '.join(self._allowed)}")
        return getattr(self._ev, name)

    def has(self, name: str) -> bool:
        return name in self._allowed and self._ev.has(name)


# ============================================================== מדידה

@dataclass
class Measure:
    code: str
    label: str
    value: float
    limit: str
    ok: bool
    quality: float          # 0..1 — מדורג, כדי שהלולאה תראה התקדמות
    weight: float = 1.0
    hint: str = ""

    def to_dict(self) -> dict:
        d = asdict(self)
        d["repair"] = REPAIR_FOR.get(self.code, "rerender")
        return d


def _clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return float(max(lo, min(hi, x)))


def ramp_up(v: float, fail: float, full: float) -> float:
    """איכות עולה: ``fail`` ומטה = 0, ``full`` ומעלה = 1."""
    if full <= fail:
        return 1.0 if v >= full else 0.0
    return _clamp((v - fail) / (full - fail))


def ramp_down(v: float, full: float, fail: float) -> float:
    """איכות יורדת: ``full`` ומטה = 1, ``fail`` ומעלה = 0."""
    if fail <= full:
        return 1.0 if v <= full else 0.0
    return _clamp((fail - v) / (fail - full))


def band(v: float, lo: float, hi: float, soft: float) -> float:
    """1 בתוך ``[lo,hi]``, דועך לאורך ``soft`` מחוץ לו."""
    if lo <= v <= hi:
        return 1.0
    d = (lo - v) if v < lo else (v - hi)
    return _clamp(1.0 - d / max(soft, EPS))


def M(code: str, label: str, value: float, limit: str, ok: bool,
      quality: float, weight: float = 1.0, hint: str = "") -> Measure:
    return Measure(code, label, round(float(value), 5), limit, bool(ok),
                   round(_clamp(quality), 4), weight, hint)


# ============================================================== פסק דין

@dataclass
class Verdict:
    critic: str
    score: float                       # 0..100
    measures: list[dict] = field(default_factory=list)
    available: bool = True

    @property
    def failures(self) -> list[dict]:
        bad = [m for m in self.measures if not m["ok"]]
        bad.sort(key=lambda m: m["weight"] * (1.0 - m["quality"]),
                 reverse=True)
        return bad

    def to_dict(self) -> dict:
        d = asdict(self)
        d["failures"] = [m["code"] for m in self.failures]
        return d

    def text(self) -> str:
        head = f"{HE[self.critic]:<14} {self.score:5.1f}/100"
        if not self.available:
            return head + "   (אין עדות)"
        out = [head]
        for m in self.measures:
            mark = "✓" if m["ok"] else "✗"
            out.append(f"    {mark} {m['code']:<22} {m['label']} "
                       f"= {m['value']} (דרוש {m['limit']})"
                       + (f" → {m['hint']}" if not m["ok"] and m["hint"] else ""))
        return "\n".join(out)


HE = {"story": "סיפור", "acting": "משחק", "animation": "אנימציה",
      "cinematography": "צילום", "visual": "איכות חזותית"}


def _verdict(critic: str, ms: list[Measure]) -> Verdict:
    if not ms:
        return Verdict(critic, 0.0, [], available=False)
    wsum = sum(m.weight for m in ms) or 1.0
    score = 100.0 * sum(m.weight * m.quality for m in ms) / wsum
    return Verdict(critic, round(score, 1), [m.to_dict() for m in ms])


def _no_evidence(critic: str, what: str) -> Verdict:
    """חוסר עדות = 0, לא פטור. ראה החלטה 2 בראש הקובץ."""
    m = M(f"{critic[:4]}.no_evidence", f"אין {what}", 0.0, "נדרשת עדות",
          False, 0.0, 3.0, hint=f"להזין {what} לשוט הזה")
    v = _verdict(critic, [m])
    v.available = False
    return v


# ============================================================== עזרי מסלול

def _mat(track: dict) -> tuple[np.ndarray, np.ndarray, list[str]]:
    t = np.asarray(track.get("times", []), dtype=np.float64)
    Mx = np.asarray(track.get("M", []), dtype=np.float64)
    keys = list(track.get("keys", []))
    if Mx.ndim == 1:
        Mx = Mx.reshape(-1, 1)
    return t, Mx, keys


_REGION_WORDS = (
    # **`blink` חייב להיות כאן, וזו לא קוסמטיקה של מילון.** עד
    # שנוסף, שני ערוצי המצמוץ נפלו לקטגוריה "אחר" ולכן נכנסו
    # למדידת הקפיצות — ומצמוץ נסגר בפריים אחד, בקפיצה של 0.97.
    # נמדד על סצנת דיאלוג תקינה: `anim.pops` החזיר 1.2 קפיצות
    # לשנייה, וכולן היו מצמוץ. סיווג חסר אינו חור בתיעוד; הוא
    # מדידה שגויה.
    ("brow", "גבה"), ("lid", "עפעף"), ("blink", "עפעף"),
    ("wink", "עפעף"), ("squint", "עפעף"),
    ("smile", "פה"), ("dimple", "פה"), ("pucker", "שפה"),
    ("funnel", "שפה"), ("sneer", "אף"),
    ("eye", "עין"), ("gaze", "מבט"),
    ("pupil", "אישון"), ("cheek", "לחי"), ("nose", "אף"), ("mouth", "פה"),
    ("lip", "שפה"), ("jaw", "לסת"), ("tongue", "לשון"), ("head", "ראש"),
    ("neck", "צוואר"), ("spine", "גב"), ("chest", "חזה"),
    ("shoulder", "כתף"), ("arm", "יד"), ("elbow", "מרפק"),
    ("hand", "כף"), ("finger", "אצבע"), ("hip", "אגן"), ("leg", "רגל"),
    ("knee", "ברך"), ("foot", "כף רגל"), ("hair", "שיער"),
    ("cloth", "בגד"), ("coat", "מעיל"), ("sleeve", "שרוול"),
)


def region_of(key: str) -> str:
    k = key.lower()
    for word, he in _REGION_WORDS:
        if word in k:
            return he
    return "אחר"


#: ערוצים שהם תנועה *משנית* — הם אמורים לפגר אחרי הראשית.
SECONDARY_WORDS = ("hair", "cloth", "coat", "sleeve", "hem", "accessory",
                   "glass", "soft")


def _is_secondary(key: str) -> bool:
    k = key.lower()
    return any(w in k for w in SECONDARY_WORDS)


def _vel(t: np.ndarray, Mx: np.ndarray) -> tuple[np.ndarray, float]:
    dt = float(np.median(np.diff(t))) if t.size > 2 else 1.0 / 30.0
    dt = dt if dt > EPS else 1.0 / 30.0
    return np.diff(Mx, axis=0) / dt, dt


def _runs(mask: np.ndarray) -> list[tuple[int, int]]:
    out, i, m = [], 0, np.asarray(mask)
    while i < len(m):
        if m[i]:
            j = i
            while j + 1 < len(m) and m[j + 1]:
                j += 1
            out.append((i, j + 1))
            i = j + 1
        else:
            i += 1
    return out


def _spearman(a: np.ndarray, b: np.ndarray) -> float:
    if a.size < 3:
        return 0.0
    ra = np.argsort(np.argsort(a)).astype(float)
    rb = np.argsort(np.argsort(b)).astype(float)
    ra -= ra.mean()
    rb -= rb.mean()
    d = float(np.linalg.norm(ra) * np.linalg.norm(rb))
    return float(ra @ rb / d) if d > 1e-12 else 0.0


# ============================================================== 1 · סיפור

#: שמונה שדות התוכנית שהמשימה דורשת שייקבעו *לפני* האנימציה.
PREMISE_FIELDS = ("knows", "wants", "feels", "hides")

TURN_BAND = (0.15, 0.85)      # היכן בשוט מותר למהפך לשבת
CHANGE_MIN = 0.30             # שינוי רגשי מינימלי שאפשר לקרוא
TAIL_MIN = 0.80               # שניות נחיתה אחרי המהפך
BEAT_SEC = 1.40               # זמן מינימלי לביט אחד


def story_critic(ev: EvidenceView) -> Verdict:
    """האם יש כאן ביט דרמטי, או רק דמות שזזה.

    **המבקר הזה אינו רואה אף פיקסל, וזו כל הנקודה.** שוט יכול
    להיראות מושלם ולא להיות על שום דבר. המדידה היא על התוכנית
    הסמלית: מה הדמות יודעת, רוצה, מרגישה, מסתירה; מתי המהפך; וכמה
    זמן נשאר כדי לנחות אחריו.

    `story.economy` הוא המדד ההפוך, והוא זה שתפס כאן שוט של שש
    שניות שנדחסו לתוכו ארבעה ביטים — כל אחד מהם היה נכון בנפרד,
    ואף אחד מהם לא היה קריא.
    """
    if not ev.has("plan"):
        return _no_evidence("story", "תוכנית סיפור (מה הדמות יודעת/רוצה/מרגישה)")
    p = dict(ev.plan)
    secs = float(ev.seconds or p.get("seconds") or 0.0)
    ms: list[Measure] = []

    filled = [f for f in PREMISE_FIELDS if str(p.get(f) or "").strip()]
    ms.append(M("story.premise", "שדות המצב שמולאו", len(filled),
                f"=={len(PREMISE_FIELDS)}",
                len(filled) == len(PREMISE_FIELDS),
                len(filled) / len(PREMISE_FIELDS), 2.0,
                hint="חסרים: " + ", ".join(
                    f for f in PREMISE_FIELDS if f not in filled)))

    look = str(p.get("looking_at") or "").strip()
    ms.append(M("story.object", "למי הדמות משחקת", 1.0 if look else 0.0,
                "מוגדר", bool(look), 1.0 if look else 0.0, 1.0,
                hint="לקבוע את מושא המבט — דמות שאין לה למי לשחק לא מגיבה"))

    arc = p.get("arc") or {}
    turn = arc.get("turn")
    if turn is None or secs <= 0:
        ms.append(M("story.turn", "מקום המהפך בשוט", 0.0,
                    f"{TURN_BAND[0]:.0%}–{TURN_BAND[1]:.0%} מהשוט",
                    False, 0.0, 2.0,
                    hint="אין מהפך רגשי — שוט בלי שינוי אינו ביט"))
    else:
        u = float(turn) / max(secs, EPS)
        q = band(u, TURN_BAND[0], TURN_BAND[1], 0.15)
        ms.append(M("story.turn", "מקום המהפך בשוט", u,
                    f"{TURN_BAND[0]:.0%}–{TURN_BAND[1]:.0%} מהשוט",
                    TURN_BAND[0] <= u <= TURN_BAND[1], q, 2.0,
                    hint="מהפך בקצה השוט לא נקרא — להזיז אותו למרכז"))

    chg = abs(float(arc.get("dvalence", 0.0))) + \
        abs(float(arc.get("darousal", 0.0)))
    ms.append(M("story.change", "עוצמת השינוי הרגשי", chg,
                f">={CHANGE_MIN}", chg >= CHANGE_MIN,
                ramp_up(chg, 0.0, CHANGE_MIN * 1.6), 2.0,
                hint="להרחיב את הקשת — שינוי קטן מדי נקרא כרעש"))

    hides = str(p.get("hides") or "").strip()
    feels = str(p.get("feels") or "").strip()
    sub_ok = bool(hides) and hides != feels
    ms.append(M("story.subtext", "תת-טקסט (מסתיר ≠ מרגיש)",
                1.0 if sub_ok else 0.0, "קיים ושונה מהרגש", sub_ok,
                1.0 if sub_ok else (0.4 if hides else 0.0), 1.5,
                hint="דמות שלא מסתירה כלום יוצאת שטוחה"))

    tail = (secs - float(turn)) if (turn is not None and secs) else 0.0
    ms.append(M("story.resolution", "שניות נחיתה אחרי המהפך", tail,
                f">={TAIL_MIN}ש", tail >= TAIL_MIN,
                ramp_up(tail, 0.0, TAIL_MIN * 1.5), 1.5,
                hint="להאריך את הזנב — מהפך בלי נחיתה נראה כמו חיתוך"))

    beats = int(p.get("beats") or (1 if turn is None else 2))
    room = secs / max(beats, 1)
    ms.append(M("story.economy", "שניות לכל ביט", room,
                f">={BEAT_SEC}ש", room >= BEAT_SEC,
                ramp_up(room, BEAT_SEC * 0.45, BEAT_SEC * 1.2), 1.0,
                hint="יותר מדי ביטים בשוט אחד — לפצל לשני שוטים"))
    return _verdict("story", ms)


# ============================================================== 2 · משחק

#: שמונת האירועים שהמשימה הקולנועית דורשת מהדמות המקשיבה.
REQUIRED_BEATS = ("look", "understand", "hesitate", "look_away",
                  "expression", "weight", "respond", "continuity")

ALIVE_MIN = 0.55          # חלק האזורים שחייבים לחיות
ASYM_BAND = (0.008, 0.40)
MUG_MAX = 0.25            # חלק הפריימים שבהם מותר שהכול יזוז יחד
SILENT_RHO = 0.55
TAIL_KEEP = 0.60


def acting_critic(ev: EvidenceView) -> Verdict:
    """הדמות משחקת, או רק מפעילה שרירים.

    שישה מדדים, ושניים מהם קיימים כדי לחסום זיוף:

    * `acting.continuity` דורש **שני** תנאים יחד — שהרגש נשאר אחרי
      הדיבור **וגם** שהמיקרו-תנועה לא נעלמה. תנאי אחד לבדו נותן
      ציון מלא לבובה מוקפאת, וזו הדרך הקלה ביותר לעבור את הדרישה.
    * `acting.restraint` הוא הכיוון ההפוך של `acting.alive`: אם
      ששה ערוצים או יותר משנים ערך בגדול באותו פריים, זו לא הבעה
      אלא העוויה. בלי המדד הזה "להזיז יותר" תמיד משפר את הציון.
    """
    if not ev.has("track"):
        return _no_evidence("acting", "מסלול פוזות (ערוצי שליטה לאורך הזמן)")
    t, Mx, keys = _mat(ev.track)
    if t.size < 6 or Mx.shape[0] != t.size:
        return _no_evidence("acting", "מסלול פוזות באורך סביר")
    ms: list[Measure] = []
    secs = float(ev.seconds or (t[-1] - t[0]))

    # --- שמונת הביטים
    evs = ev.events if ev.has("events") else None
    if evs:
        found = sum(1 for b in REQUIRED_BEATS
                    if isinstance(evs.get(b), dict) and evs[b].get("found"))
        miss = [b for b in REQUIRED_BEATS
                if not (isinstance(evs.get(b), dict) and evs[b].get("found"))]
        ms.append(M("acting.beats", "אירועי משחק שנמצאו", found,
                    f"=={len(REQUIRED_BEATS)}", found == len(REQUIRED_BEATS),
                    found / len(REQUIRED_BEATS), 3.0,
                    hint="חסרים: " + ", ".join(miss)))
    else:
        # בלי רשימת אירועים אין ויתור: נמדד תחליף — כמה "מפנות"
        # מובחנות יש במסלול. שוט בלי מפנות אינו משחק.
        V, dt = _vel(t, Mx)
        mag = np.abs(V).sum(axis=1)
        if mag.size and mag.max() > EPS:
            peaks = int(((mag[1:-1] > mag[:-2]) & (mag[1:-1] > mag[2:])
                         & (mag[1:-1] > 0.35 * mag.max())).sum())
        else:
            peaks = 0
        need = max(2, int(secs / 2.5))
        ms.append(M("acting.beats", "מפנות מובחנות במסלול", peaks,
                    f">={need}", peaks >= need,
                    ramp_up(peaks, 0.0, need), 3.0,
                    hint="לביים ביטים מופרדים ולא תנועה אחת רצופה"))

    # --- מובן בלי קול
    if ev.has("perf"):
        sc = np.asarray(ev.perf, dtype=np.float64).ravel()
    else:
        # תחליף: עקומת האנרגיה המצטברת של ערוצי הפנים
        face_idx = [i for i, k in enumerate(keys)
                    if region_of(k) in ("גבה", "עפעף", "עין", "מבט",
                                        "אישון", "לחי", "אף")]
        cols = face_idx or list(range(Mx.shape[1]))
        sc = np.abs(Mx[:, cols] - Mx[0, cols]).mean(axis=1)
    n = min(sc.size, t.size)
    sc, tt = sc[:n], t[:n]
    rho = _spearman(tt, sc) if n >= 6 else 0.0
    ms.append(M("acting.silent", "מגמת הרגש לאורך הזמן", rho,
                f">={SILENT_RHO}", rho >= SILENT_RHO,
                ramp_up(rho, 0.0, SILENT_RHO * 1.25), 2.5,
                hint="השינוי צריך להצטבר לכיוון אחד — מקרטע אינו קריא"))

    # --- רציפות: הרגש נשאר, והדמות לא קפאה
    if n >= 10:
        k = max(3, n // 5)
        base = float(sc[:k].mean())
        peak = float(sc.max())
        keep = (float(sc[-k:].mean()) - base) / max(peak - base, EPS)
        life = float(np.abs(np.diff(Mx[-k:], axis=0)).mean()) if k > 1 else 0.0
        alive = life >= 1e-5
        ok = keep >= TAIL_KEEP and alive
        q = min(ramp_up(keep, 0.0, TAIL_KEEP), 1.0 if alive else 0.0)
        ms.append(M("acting.continuity", "שמירת הרגש בזנב", keep,
                    f">={TAIL_KEEP} וגם מיקרו-תנועה", ok, q, 2.0,
                    hint=("הזנב חי אך הרגש נסוג" if alive else
                          "הדמות קפאה בזנב — זו בובה, לא רציפות")))

    # --- אסימטריה: פנים סימטריות לחלוטין הן בובה
    pairs: list[tuple[int, int]] = []
    low = [k.lower() for k in keys]
    for i, k in enumerate(low):
        for a, b in (("_l", "_r"), (".l", ".r"), ("left", "right")):
            if a in k:
                m = k.replace(a, b)
                if m in low:
                    pairs.append((i, low.index(m)))
                break
    if pairs:
        diffs = [float(np.abs(Mx[:, i] - Mx[:, j]).mean()) for i, j in pairs]
        asym = float(np.mean(diffs))
        lo, hi = ASYM_BAND
        ms.append(M("acting.asymmetry", "אסימטריה ימין/שמאל", asym,
                    f"{lo}–{hi}", lo <= asym <= hi,
                    band(asym, lo, hi, lo * 2 + 0.05), 1.0,
                    hint=("סימטריה מושלמת — להוסיף הטיה לצד אחד"
                          if asym < lo else "אסימטריה חריגה — נראה שבור")))

    # --- כמה אזורים בכלל חיים
    regions: dict[str, list[int]] = {}
    for i, k in enumerate(keys):
        regions.setdefault(region_of(k), []).append(i)
    rng = Mx.max(axis=0) - Mx.min(axis=0)
    live = sum(1 for idx in regions.values() if float(rng[idx].max()) > 0.01)
    share = live / max(len(regions), 1)
    dead = [r for r, idx in regions.items() if float(rng[idx].max()) <= 0.01]
    ms.append(M("acting.alive", "חלק האזורים שחיים", share,
                f">={ALIVE_MIN}", share >= ALIVE_MIN,
                ramp_up(share, 0.0, ALIVE_MIN * 1.15), 2.0,
                hint="אזורים קפואים: " + ", ".join(dead[:6])))

    # --- והכיוון ההפוך: הגזמה
    V, dt = _vel(t, Mx)
    if V.size:
        big = (np.abs(V) * dt > 0.15).sum(axis=1)
        mug = float((big >= 6).mean())
        ms.append(M("acting.restraint", "פריימים שבהם הכול זז יחד", mug,
                    f"<={MUG_MAX}", mug <= MUG_MAX,
                    ramp_down(mug, MUG_MAX * 0.5, MUG_MAX * 2.2), 1.5,
                    hint="להפחית מחוות בו-זמניות — זו העוויה ולא הבעה"))
    return _verdict("acting", ms)


# ============================================================== 3 · אנימציה

JITTER_MAX = 0.55       # אנרגיית רעידה יחסית
POPS_PER_SEC = 0.12
#: סטיית עקומת ההתקדמות מקו ישר (RMS). **נמדד, לא הוערך:** 80
#: הגרלות לכל מקרה, רעש 0.004 על מהלך 0.3, בכל אורכי המהלך —
#: אינטרפולציה ליניארית נותנת 0.006-0.035 (ממוצע 0.009) ו-smoothstep
#: נותן 0.027-0.062 (ממוצע 0.038). המדד הוא הממוצע על כל הערוצים,
#: ולכן הפיזור הפרטני מתכנס והסף 0.022 מפריד נקי.
EASE_MIN = 0.022
ANTICIP_MIN = 0.40
OVERLAP_MIN = 0.045     # שניות פיזור בין שיאי האזורים
HOLD_MIN = 0.22         # שניות של החזקה אחת לפחות
EASE_SMOOTH = 3         # דגימות החלקה למדידת צורת העקומה
EASE_MIN_FRAMES = 10    # מהלך קצר מזה מעוות על ידי ההחלקה עצמה


def _edge_smooth(y: np.ndarray, w: int) -> np.ndarray:
    """החלקה עם **ריפוד קצה**, לא באפסים ולא בשחזור הערך הגולמי.

    זה היה באג אמיתי: בגרסה שהחזירה את הערכים הגולמיים בקצוות,
    רעש של פריים אחד בסוף הזיז את המקסימום של הערוץ, ולכן גם את
    מפלס ה-95% שמסמן את סוף המהלך — וחלון המהלך נמתח על כל הרמה
    השטוחה שאחריו. נמדד: אותו מסלול בדיוק קיבל סטייה 0.25 במקום
    0.04, כלומר אנימציה ליניארית "עברה" כמאוישת.
    """
    if w < 3 or y.size < w + 2:
        return y
    pad = w // 2
    return np.convolve(np.pad(y, (pad, pad), mode="edge"),
                       np.ones(w) / w, mode="valid")


def _main_move(y: np.ndarray, min_frames: int):
    """חלון המהלך הראשי בערוץ: מ-5% ועד 95% מהדרך בין ההתחלה לסוף.

    מחזיר ``(i, j, direction, total)`` או ``None``.

    **שתי הטעויות שתוקנו כאן, ושתיהן נמדדו על שוט תקין:**

    1. *בסיס = מינימום הערוץ.* תנועת הציפייה יורדת **מתחת** לרמת
       ההתחלה, ולכן המינימום הוא תחתית הציפייה — ומפלס ה-5% נחצה
       בתוך הציפייה עצמה. כלומר "תחילת המהלך" סומנה לפני
       תנועת-הנגד, לא אחריה, ו-`anim.anticipation` יצא 0.0 על מסלול
       שיש בו ציפייה בכל ערוץ. הבסיס כאן הוא **ממוצע החמישון
       הראשון**, והציפייה נשארת מחוץ לחלון, שם היא נמדדת.
    2. *סוף = מקסימום הערוץ.* ערוץ שעולה ואז חוזר חלקית אחורה
       (הראש פונה וחוזר) קיבל חלון שנמשך עד השיא, כולל הרמה
       השטוחה — ואז נמדד "איוש" שמקורו בהחזקה ולא בעקומה. היעד
       כאן הוא **ממוצע החמישון האחרון**.

    החיתוך ב-5% וב-95% עצמו הכרחי: בלעדיו כל רמה שטוחה בשולי
    המהלך נספרת כחלק מהעקומה.
    """
    # **שלוש דגימות בכל קצה, לא חמישון.** חמישון של שוט בן עשר
    # שניות הוא שתי שניות, וכל מהלך שמתחיל לפני t=2 נכנס לתוך
    # "רמת ההתחלה" — אז הבסיס יוצא באמצע המהלך, הציפייה שמתחתיו
    # נעלמת, ו-`anim.anticipation` חוזר 0.0 על מסלול שיש בו ציפייה
    # בכל ערוץ. העקומה כבר מוחלקת, ולכן שלוש דגימות מספיקות.
    n = y.size
    q = 3 if n >= 8 else 1
    base = float(y[:q].mean())
    goal = float(y[-q:].mean())
    total = goal - base
    if abs(total) < 0.02:
        return None                     # מהלך הלוך-חזור: אין יעד
    direction = 1.0 if total > 0 else -1.0
    z = (y - base) * direction
    tot = abs(total)
    ia = np.nonzero(z >= 0.05 * tot)[0]
    if not ia.size:
        return None
    i = int(ia[0])
    ib = np.nonzero(z[i:] >= 0.95 * tot)[0]
    if not ib.size:
        return None
    j = i + int(ib[0])
    if j - i < min_frames:
        return None
    return i, j, direction, tot


def animation_critic(ev: EvidenceView) -> Verdict:
    """התנועה מקצועית, או אינטרפולציה ליניארית.

    שבעת המדדים הם עקרונות האנימציה כפי שאפשר למדוד אותם מהמסלול
    עצמו — בלי שום ידע על מה הסצנה מספרת.

    **`anim.easing` הוא המדד שתפס כאן באג אמיתי, ושלוש גרסאות שלו
    נכשלו לפניו. כל כישלון מלמד משהו:**

    1. *סף על סכום המהירויות של כל הערוצים* — האיחוד מוחק בדיוק
       את ההסטה בזמן שהמבקר עצמו דורש (`anim.overlap`), ולכן שוט
       מבויים היטב קיבל 1.32 מול סף 1.45.
    2. *שיא חלקי ממוצע מהירות בחלון שמעל סף* — הסף חותך את זנבות
       התנועה האיטיים, והממוצע *בחלון שנשאר* גבוה מהאמיתי. תלוי-סף,
       ולכן חסר משמעות.
    3. *שיא×משך/מהלך על המהירות* — נכון תאורטית (ליניארי=1.0,
       smoothstep=1.5) ו**נשלט ברעש**: רעידה של 0.004 מכפילה את שיא
       המהירות, ואנימציה ליניארית ורועדת קיבלה 1.86 — כלומר "מאוישת
       למופת". זו הייתה ההזדמנות שבה הפגם הסתיר את עצמו.

    מה שעובד הוא מדד על **המהלך** ולא על הנגזרת: סטיית עקומת
    ההתקדמות מקו ישר. היא אינטגרל, ולכן הרעש מתבטל בה במקום
    להתעצם. הרעידה נמדדת בנפרד ב-`anim.jitter`, על האות הגולמי,
    וכך אף אחד מהשניים אינו מסתיר את חברו.
    """
    if not ev.has("track"):
        return _no_evidence("animation", "מסלול פוזות")
    t, Mx, keys = _mat(ev.track)
    if t.size < 8 or Mx.shape[0] != t.size:
        return _no_evidence("animation", "מסלול פוזות באורך סביר")
    ms: list[Measure] = []
    secs = float(ev.seconds or (t[-1] - t[0])) or 1.0
    V, dt = _vel(t, Mx)

    # **מצמוץ ותנועת מבט אינם רעידה, והם חייבים לצאת מהמדידה.**
    # עפעף נסגר ונפתח בשלושה פריימים, וסקאדה היא התנועה הבליסטית
    # המהירה בגוף האדם — שתיהן *נכונות* בדיוק כשהן חדות. נמדד על
    # הסצנה האמיתית: `anim.pops` החזיר 1.4 קפיצות לשנייה ו-
    # `anim.jitter` החזיר 1.01, כלומר הלולאה הייתה נשלחת "לאחות
    # מעברים" במשחק עיניים תקין לגמרי. זהו הסוג המסוכן של כישלון:
    # לא פספוס של פגם, אלא תיקון של משהו שלא שבור.
    # גם ערוצי הדיבור יוצאים: מעבר בין הגה להגה הוא שני-שלושה
    # פריימים **מעצם הגדרתו**, וזו דרישה ולא פגם. בלי ההוצאה הזו
    # `anim.pops` החזיר 1.2 קפיצות לשנייה על סצנת דיאלוג תקינה.
    fast = {"עפעף", "אישון", "מבט", "עין",
            "פה", "שפה", "לסת", "לשון"}
    slow_cols = [i for i, k in enumerate(keys) if region_of(k) not in fast]
    Vs_body = V[:, slow_cols] if slow_cols else V

    speed = np.abs(Vs_body).sum(axis=1)
    A = (np.diff(Vs_body, axis=0) / dt if Vs_body.shape[0] > 1
         else np.zeros((0, Vs_body.shape[1])))
    J = (np.diff(A, axis=0) / dt if A.shape[0] > 1
         else np.zeros((0, Vs_body.shape[1])))

    # --- רעידה: אנרגיית הטלטול ביחס לאנרגיית התנועה (אות גולמי)
    jit = (float(np.abs(J).mean()) * dt * dt /
           max(float(np.abs(Vs_body).mean()), EPS)) if J.size else 0.0
    ms.append(M("anim.jitter", "רעידה יחסית", jit, f"<={JITTER_MAX}",
                jit <= JITTER_MAX, ramp_down(jit, JITTER_MAX * 0.4,
                                             JITTER_MAX * 2.5), 2.5,
                hint="להחליק את העקומות — יש טלטול בתוך התנועה"))

    # --- קפיצות: פריים בודד שחורג מהשכנים
    if speed.size > 6:
        med = float(np.median(speed)) + EPS
        pops = int((speed > max(6.0 * med, EPS)).sum())
        rate = pops / secs
        ms.append(M("anim.pops", "קפיצות לשנייה", rate,
                    f"<={POPS_PER_SEC}", rate <= POPS_PER_SEC,
                    ramp_down(rate, POPS_PER_SEC * 0.3, POPS_PER_SEC * 4),
                    2.5, hint="יש אי-רציפות בפריים בודד — לאחות את המעבר"))

    # --- איוש וציפייה: על צורת עקומת ההתקדמות, ערוץ-ערוץ
    devs: list[float] = []
    antic_hits = 0
    antic_total = 0
    for c in range(Mx.shape[1]):
        span = float(Mx[:, c].max() - Mx[:, c].min())
        if span < 0.02:                     # ערוץ שבקושי זז אינו מהלך
            continue
        y = _edge_smooth(Mx[:, c], EASE_SMOOTH)
        mv = _main_move(y, EASE_MIN_FRAMES)
        if mv is None:
            continue
        i, j, direction, tot = mv
        seg = y[i:j + 1] * direction
        s = (seg - seg[0]) / max(seg[-1] - seg[0], EPS)
        u = np.linspace(0.0, 1.0, s.size)
        devs.append(float(np.sqrt(np.mean((s - u) ** 2))))

        # --- ציפייה: לפני תחילת המהלך הפוזה יוצאת **נגד** כיוונו
        #
        # המדד הוא **החריגה** מתחת לרמת ההתחלה, ולא סכום התנועה
        # בחלון. סכום התנועה מתאפס כאן תמיד: חלון הלוך-חזור שמכיל
        # את הצניחה *ואת ההתאוששות ממנה* מסתכם בחיובי, ולכן מסלול
        # שבנוי עם ציפייה בכל ערוץ קיבל ציון 0.0. נמדד בפועל.
        antic_total += 1
        back = max(0, i - max(3, int(0.3 / dt)))
        if i - back >= 2:
            start_level = float(y[:3].mean()) if y.size >= 8 else float(y[0])
            dip = float(((y[back:i] - start_level) * direction).min())
            if dip < -max(0.05 * tot, 0.004):
                antic_hits += 1

    if devs:
        # **חציון ולא ממוצע.** ערוץ אחד עם עקומה מורכבת (נשימה
        # סינוסואידלית, מהלך כפול) מרים ממוצע של שבעה-עשר ערוצים
        # ליניאריים ומכסה עליהם. נמדד: ממוצע 0.41 מול חציון שמשקף
        # את רוב הערוצים.
        ease = float(np.median(devs))
        ms.append(M("anim.easing", "סטיית העקומה מקו ישר", ease,
                    f">={EASE_MIN}", ease >= EASE_MIN,
                    ramp_up(ease, 0.004, EASE_MIN * 1.6), 2.0,
                    hint="התנועה ליניארית — להוסיף האצה והאטה"))
        share = antic_hits / max(antic_total, 1)
        ms.append(M("anim.anticipation", "תנועות עם ציפייה", share,
                    f">={ANTICIP_MIN}", share >= ANTICIP_MIN,
                    ramp_up(share, 0.0, ANTICIP_MIN * 1.3), 1.5,
                    hint="להוסיף תנועת-נגד קצרה לפני המחווה"))
    else:
        # **אין אף מהלך קריא, וזה כשל ולא השמטה.** מדידה שנעלמת
        # היא בדיוק הדרך שבה שוט גרוע עובר: אין מדד, אין כישלון.
        ms.append(M("anim.easing", "מהלכים קריאים במסלול", 0.0,
                    ">=1 מהלך", False, 0.0, 2.0,
                    hint="אין תנועה מובחנת — המסלול רועש או שטוח"))

    # --- חפיפה: האזורים לא מגיעים לשיא באותו פריים
    regions: dict[str, list[int]] = {}
    for i, k in enumerate(keys):
        regions.setdefault(region_of(k), []).append(i)
    peaks = []
    for idx in regions.values():
        sub = np.abs(V[:, idx]).sum(axis=1)
        if sub.size and float(sub.max()) > EPS:
            peaks.append(float(t[int(np.argmax(sub))]))
    spread = float(np.std(peaks)) if len(peaks) >= 3 else 0.0
    ms.append(M("anim.overlap", "פיזור שיאי האזורים", spread,
                f">={OVERLAP_MIN}ש", spread >= OVERLAP_MIN,
                ramp_up(spread, 0.0, OVERLAP_MIN * 1.6), 1.5,
                hint="כל הגוף זז יחד — להסיט את האזורים בזמן"))

    # --- המשך: הערוצים המשניים מפגרים אחרי הראשיים
    sec_idx = [i for i, k in enumerate(keys) if _is_secondary(k)]
    pri_idx = [i for i, k in enumerate(keys)
               if not _is_secondary(k) and region_of(k) in
               ("ראש", "צוואר", "חזה", "גב", "כתף")]
    if sec_idx and pri_idx and V.shape[0] >= 8:
        pri = np.abs(V[:, pri_idx]).sum(axis=1)
        lags = []
        for i in sec_idx:
            s = np.abs(V[:, [i]]).sum(axis=1)
            if s.max() <= EPS or pri.max() <= EPS:
                continue
            a = (pri - pri.mean()) / (pri.std() + EPS)
            b = (s - s.mean()) / (s.std() + EPS)
            cc = np.correlate(b, a, mode="full")
            lag = int(np.argmax(cc)) - (a.size - 1)
            lags.append(lag * dt)
        pos = (sum(1 for L in lags if L > 0) / len(lags)) if lags else 0.0
        ms.append(M("anim.followthrough", "ערוצים משניים שמפגרים", pos,
                    ">=0.5", pos >= 0.5, ramp_up(pos, 0.0, 0.6), 1.5,
                    hint="שיער/בגד מקדימים את התנועה הראשית — להוסיף פיגור"))

    # --- והכיוון ההפוך: יש בכלל החזקה אחת
    if speed.size > 4 and speed.max() > EPS:
        quiet = speed < 0.12 * speed.max()
        best = max((j - i for i, j in _runs(quiet)), default=0) * dt
        ms.append(M("anim.holds", "ההחזקה הארוכה ביותר", best,
                    f">={HOLD_MIN}ש", best >= HOLD_MIN,
                    ramp_up(best, 0.0, HOLD_MIN * 1.4), 1.0,
                    hint="תנועה בלי הפסקה — להוסיף החזקה כדי שיהיה מה לקרוא"))
    return _verdict("animation", ms)


# ============================================================== 4 · צילום

HEADROOM = (0.025, 0.18)
EYELINE = (0.20, 0.44)
SUBJ_AREA = (0.04, 0.72)
CAM_JERK_MAX = 0.55
DEPTH_MIN = 0.015
SCALE_JUMP_MAX = 0.09


def cinematography_critic(ev: EvidenceView) -> Verdict:
    """הקאדר מביים, או רק מצלם.

    שני מקורות ולא אחד: **מסלול המצלמה** (חלקוּת, זום, כיוון מסך)
    ו**מקום הדמות בקאדר** (רווח ראש, קו עיניים, חיתוך). אם אין
    תיבת דמות, החיתוך נמדד מהפיקסלים עצמם — ספירת מעברים חדים
    לאורך שפת הקאדר, בדיוק המדד שעבד ב-`qa.check_edge_safe` אחרי
    שגרסת ה"ניגודיות" שלו נכשלה.
    """
    have_cam = ev.has("camera")
    have_sub = ev.has("subject")
    have_px = ev.has("sample") and getattr(ev.sample, "n", 0) > 0
    if not (have_cam or have_sub or have_px):
        return _no_evidence("cinematography", "מסלול מצלמה או קאדר")
    ms: list[Measure] = []
    secs = float(ev.seconds or 0.0) or 1.0

    # --- קאדר: רווח ראש, קו עיניים, גודל, חיתוך, כיוון מסך
    if have_sub:
        S = np.asarray(ev.subject, dtype=np.float64).reshape(-1, 4)
        x0, y0, x1, y1 = S[:, 0], S[:, 1], S[:, 2], S[:, 3]
        head = float(np.median(y0))
        lo, hi = HEADROOM
        ms.append(M("cine.headroom", "רווח ראש", head, f"{lo}–{hi}",
                    lo <= head <= hi, band(head, lo, hi, 0.09), 2.0,
                    hint=("הראש נוגע בשפה העליונה" if head < lo
                          else "יותר מדי שמיים מעל הראש")))
        eye = float(np.median(y0 + 0.12 * np.maximum(y1 - y0, EPS)))
        elo, ehi = EYELINE
        ms.append(M("cine.thirds", "קו העיניים", eye, f"{elo}–{ehi}",
                    elo <= eye <= ehi, band(eye, elo, ehi, 0.12), 1.5,
                    hint="להזיז את קו העיניים אל השליש העליון"))
        area = float(np.median((x1 - x0) * (y1 - y0)))
        alo, ahi = SUBJ_AREA
        ms.append(M("cine.scale", "שטח הדמות בקאדר", area, f"{alo}–{ahi}",
                    alo <= area <= ahi, band(area, alo, ahi, 0.10), 2.0,
                    hint=("הדמות קטנה מדי בקאדר" if area < alo
                          else "הדמות גדולה מדי — להרחיק את המצלמה")))
        touch = float(((x0 <= 0.004) | (y0 <= 0.004) |
                       (x1 >= 0.996) | (y1 >= 0.996)).mean())
        ms.append(M("cine.crop", "פריימים שבהם הדמות נחתכת", touch,
                    "<=0.02", touch <= 0.02,
                    ramp_down(touch, 0.0, 0.25), 2.5,
                    hint="הדמות יוצאת מהקאדר — להרחיק או להזיז את המטרה"))
        cx = (x0 + x1) * 0.5
        if cx.size > 4:
            # **רצועה מתה סביב המרכז.** בלעדיה דמות שעומדת במרכז
            # הקאדר — הקאדר הנפוץ ביותר — מקבלת "החלפת צד" בכל
            # פריים, כי `sign(cx-0.5)` מתהפך על רעש של אלפית.
            # נמדד: שוט תקין לגמרי קיבל 54 החלפות צד.
            off = cx - 0.5
            side = np.where(np.abs(off) > 0.04, np.sign(off), 0.0)
            live = side[side != 0.0]
            flips = int((np.diff(live) != 0).sum()) if live.size > 1 else 0
            ms.append(M("cine.axis", "החלפות צד בקאדר", flips, "<=1",
                        flips <= 1, ramp_down(flips, 0.0, 6.0), 1.0,
                        hint="הדמות עוברת צד באמצע השוט — לשמור כיוון מסך"))
    elif have_px:
        s = ev.sample
        g = np.asarray(s.gray)
        lines = {"עליון": g[:, 0, :], "תחתון": g[:, -1, :],
                 "שמאלי": g[:, :, 0], "ימני": g[:, :, -1]}
        worst, where = 0.0, ""
        for nm, line in lines.items():
            if line.shape[-1] < 4:
                continue
            cross = (np.abs(np.diff(line, axis=1)) > 0.06).sum(axis=1)
            v = float(np.percentile(cross, 90))
            if v > worst:
                worst, where = v, nm
        ms.append(M("cine.crop", f"מעברים חדים בשפה ({where or '—'})", worst,
                    "<=6", worst <= 6.0, ramp_down(worst, 2.0, 22.0), 2.5,
                    hint="משהו נחתך בשפת הקאדר — להרחיק את המצלמה"))

    # --- המצלמה עצמה
    if have_cam:
        C = list(ev.camera)
        n = len(C)
        if n >= 6:
            def col(k, d=0.0):
                return np.asarray([float(c.get(k, d) or 0.0) for c in C],
                                  dtype=np.float64)
            dt = secs / max(n - 1, 1)
            path = np.stack([col("yaw") / 30.0, col("pitch") / 30.0,
                             col("dist", 1.0), col("ty"), col("tx")], axis=1)
            v = np.diff(path, axis=0) / dt
            if v.shape[0] > 2:
                a = np.diff(v, axis=0) / dt
                j = np.diff(a, axis=0) / dt
                jerk = (float(np.abs(j).mean()) * dt * dt /
                        max(float(np.abs(v).mean()), EPS))
                ms.append(M("cine.smooth", "טלטול מצלמה", jerk,
                            f"<={CAM_JERK_MAX}", jerk <= CAM_JERK_MAX,
                            ramp_down(jerk, CAM_JERK_MAX * 0.35,
                                      CAM_JERK_MAX * 2.5), 2.0,
                            hint="מסלול המצלמה מקרטע — להחליק אותו"))
            d = col("dist", 1.0)
            if d.size > 2 and float(np.median(np.abs(d))) > EPS:
                jump = float(np.abs(np.diff(d)).max() /
                             max(float(np.median(np.abs(d))), EPS))
                ms.append(M("cine.scale_jump", "קפיצת זום בין פריימים", jump,
                            f"<={SCALE_JUMP_MAX}", jump <= SCALE_JUMP_MAX,
                            ramp_down(jump, SCALE_JUMP_MAX * 0.2,
                                      SCALE_JUMP_MAX * 5), 1.0,
                            hint="שינוי גודל שוט פתאומי — לפרוס אותו בזמן"))

    # --- הפרדת עומק: הדמות נבדלת מהרקע
    if have_px:
        g = np.asarray(ev.sample.gray)
        if g.ndim == 3 and g.shape[0] and g.shape[1] > 5 and g.shape[2] > 5:
            h, w = g.shape[1], g.shape[2]
            cy0, cy1 = int(h * 0.18), int(h * 0.82)
            cx0, cx1 = int(w * 0.25), int(w * 0.75)
            centre = g[:, cy0:cy1, cx0:cx1]
            mask = np.ones((h, w), bool)
            mask[cy0:cy1, cx0:cx1] = False
            around = g[:, mask]
            sep = abs(float(centre.mean()) - float(around.mean()))
            ms.append(M("cine.depth", "הפרדה בין הדמות לרקע", sep,
                        f">={DEPTH_MIN}", sep >= DEPTH_MIN,
                        ramp_up(sep, 0.0, DEPTH_MIN * 2.2), 1.5,
                        hint="הדמות נטמעת ברקע — להפריד בתאורה או בעומק"))
    return _verdict("cinematography", ms)


# ============================================================== 5 · איכות

CLIP_MAX = 0.06
CONTRAST_MIN = 0.045
SHARP_MIN = 0.00035
FLICKER_MAX = 3.2
LEVELS_MIN = 48
SPIKE_MAX = 5.0


def visual_critic(ev: EvidenceView) -> Verdict:
    """התמונה עצמה — חשיפה, חדות, ריצוד, פסים, הרמוניית צבע.

    **`vq.flicker` הוא המדד שאי אפשר לראות בפריים בודד**, וזו
    הסיבה שהוא כאן: מנעול שיער שנופל בין פיקסל לפיקסל מהבהב בין
    פריימים ונראה מושלם בכל צילום מסך. הוא נמדד כיחס בין סטיית
    הפרשי הבהירות הגלובליים לחציון שלהם — יחס גדול פירושו שיש
    פריימים שחורגים מהשכנים שלהם, כלומר הבהוב ולא תנועה.
    """
    have_px = ev.has("sample") and getattr(ev.sample, "n", 0) > 0
    if not have_px and not ev.has("color"):
        return _no_evidence("visual", "דגימת פריימים מהסרטון")
    ms: list[Measure] = []

    if have_px:
        g = np.asarray(ev.sample.gray, dtype=np.float64)
        flat = g.reshape(g.shape[0], -1)

        clip = float(((g > 0.99) | (g < 0.01)).mean())
        ms.append(M("vq.exposure", "פיקסלים שרופים או כבויים", clip,
                    f"<={CLIP_MAX}", clip <= CLIP_MAX,
                    ramp_down(clip, CLIP_MAX * 0.3, CLIP_MAX * 4), 2.0,
                    hint="לתקן חשיפה — יש אזורים שנחתכו בלבן או בשחור"))

        std = float(g.std())
        ms.append(M("vq.contrast", "סטיית בהירות", std,
                    f">={CONTRAST_MIN}", std >= CONTRAST_MIN,
                    ramp_up(std, 0.0, CONTRAST_MIN * 2.4), 2.0,
                    hint="התמונה שטוחה — התאורה כנראה לא נדלקה"))

        # חדות: אנרגיית לפלסיאן ממוצעת
        if g.shape[1] > 2 and g.shape[2] > 2:
            lap = (g[:, 1:-1, 2:] + g[:, 1:-1, :-2] + g[:, 2:, 1:-1]
                   + g[:, :-2, 1:-1] - 4.0 * g[:, 1:-1, 1:-1])
            sharp = float((lap ** 2).mean())
            ms.append(M("vq.sharpness", "חדות", sharp, f">={SHARP_MIN}",
                        sharp >= SHARP_MIN,
                        ramp_up(sharp, 0.0, SHARP_MIN * 2.5), 2.0,
                        hint="התמונה מרוחה — להעלות דגימת-על ברינדור"))

        # ריצוד: פריימים שחורגים מהשכנים בבהירות הגלובלית
        #
        # **קצות השוט נחתכים מהמדידה, וזו לא פינה שמעוגלת.** כל
        # שוט כאן נפתח ונסגר בהחשכה מכוונת (`showreel.FADE`, 0.28
        # שניות), והיא משנה את הבהירות הגלובלית בעשרות אחוזים בתוך
        # שמונה פריימים. נמדד על סרטון תקין לגמרי: `vq.flicker`
        # החזיר 16.8 מול סף 3.2 ו-`vq.stability` החזיר 59.3 מול 5 —
        # כלומר המבקר דיווח "הבהוב" על מעבר קולנועי תקני, והלולאה
        # הייתה נשלחת "לייצב הצללה" שלא שבורה.
        mu = flat.mean(axis=1)
        fps = float(getattr(ev.sample, "fps", 0.0) or 30.0)
        times = np.asarray(getattr(ev.sample, "times", []), dtype=np.float64)
        cut = 0
        if times.size == mu.size and times.size > 12:
            span = float(times[-1] - times[0])
            if span > 1.6:
                cut = int(np.searchsorted(times, times[0] + 0.45))
        if cut >= 2 and mu.size - 2 * cut >= 8:
            mu = mu[cut:mu.size - cut]
        if mu.size > 6:
            d = np.abs(np.diff(mu))
            med = float(np.median(d)) + EPS
            fl = float(d.std() / med)
            ms.append(M("vq.flicker", "ריצוד בין פריימים", fl,
                        f"<={FLICKER_MAX}", fl <= FLICKER_MAX,
                        ramp_down(fl, FLICKER_MAX * 0.35, FLICKER_MAX * 3),
                        2.0, hint="יש הבהוב — לייצב הצללה/דגימת-על"))
            spike = float(d.max() / med)
            ms.append(M("vq.stability", "הפריים החריג ביותר", spike,
                        f"<={SPIKE_MAX}", spike <= SPIKE_MAX,
                        ramp_down(spike, SPIKE_MAX * 0.4, SPIKE_MAX * 4),
                        1.5, hint="פריים שנפל או שוכפל — לקודד מחדש"))

        # פסים: כמה רמות אפור בשימוש בפועל
        levels = int(np.unique((g * 255).astype(np.uint8)).size)
        ms.append(M("vq.banding", "רמות אפור בשימוש", levels,
                    f">={LEVELS_MIN}", levels >= LEVELS_MIN,
                    ramp_up(levels, 4.0, LEVELS_MIN * 1.5), 1.0,
                    hint="הגרדיאנט מפוסל — להעלות עומק צבע"))

    # הרמוניית צבע: פיזור הגוונים מול תבנית הרמונית
    if ev.has("color"):
        c = np.asarray(ev.color, dtype=np.float64)
        if c.ndim == 4 and c.shape[-1] >= 3:
            px = c.reshape(-1, c.shape[-1])[:, :3]
            mx = px.max(axis=1)
            mn = px.min(axis=1)
            sat = (mx - mn) / np.maximum(mx, EPS)
            keep = px[sat > 0.12]
            if keep.shape[0] > 40:
                r, gg, b = keep[:, 0], keep[:, 1], keep[:, 2]
                mx2, mn2 = keep.max(axis=1), keep.min(axis=1)
                dl = np.maximum(mx2 - mn2, EPS)
                hue = np.where(
                    mx2 == r, ((gg - b) / dl) % 6.0,
                    np.where(mx2 == gg, (b - r) / dl + 2.0,
                             (r - gg) / dl + 4.0)) * 60.0
                ang = np.deg2rad(hue)
                # פיזור מעגלי: 0 = גוון אחד, 1 = מפוזר לגמרי
                conc = math.hypot(float(np.cos(ang).mean()),
                                  float(np.sin(ang).mean()))
                spread = 1.0 - conc
                ms.append(M("vq.harmony", "פיזור גוונים", spread,
                            "0.05–0.62", 0.05 <= spread <= 0.62,
                            band(spread, 0.05, 0.62, 0.22), 1.5,
                            hint=("פלטה מונוכרומטית מדי" if spread < 0.05
                                  else "יותר מדי גוונים מתחרים")))
    return _verdict("visual", ms)


# ============================================================== הרשמה

CRITICS: dict[str, Callable[[EvidenceView], Verdict]] = {
    "story": story_critic,
    "acting": acting_critic,
    "animation": animation_critic,
    "cinematography": cinematography_critic,
    "visual": visual_critic,
}


def review_one(name: str, ev: Evidence) -> Verdict:
    """מריץ מבקר אחד על מבט מצומצם בעדות.

    חריגה בתוך מבקר אינה מפילה את הפאנל ואינה הופכת ל"עבר": היא
    הופכת לכשל מדיד עם שם החריגה. מבקר שנפל הוא מבקר שלא העיד.
    """
    fn = CRITICS[name]
    try:
        return fn(ev.view(name))
    except Exception as exc:                       # noqa: BLE001
        m = M(f"{name[:4]}.crash", f"המבקר נפל: {type(exc).__name__}",
              0.0, "ללא חריגה", False, 0.0, 3.0, hint=str(exc)[:120])
        v = _verdict(name, [m])
        v.available = False
        return v
