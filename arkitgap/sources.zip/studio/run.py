# -*- coding: utf-8 -*-
"""חיבור מנהל האולפן למנוע הרינדור — הפקה אמיתית מקצה לקצה.

זה הקובץ שהופך את `director` + `qa` ממודולים לכלי עבודה: הוא מגדיר
את תוכנית הצילום, מרנדר כל שוט דרך `engine`, מריץ עליו בקרת איכות,
מתקן מה שנכשל, ומרכיב את הסרטון הסופי — והכול במצב ששומר את עצמו
לדיסק, כך שהפקה שנקטעה ממשיכה מאותו מקום.

שימוש:
    python -m studio.run                 # כל תוכנית הצילום
    python -m studio.run s5_dashboard    # שוטים נבחרים
    python -m studio.run --status        # מה מצב ההפקה כרגע
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

import engine                              # noqa: E402
from studio import director as dr          # noqa: E402
from studio import probe                   # noqa: E402

SCENES = ROOT / "scenes"
PROD = ROOT / "production"

# תוכנית הצילום. `probe` הוא המקום שבו מוצהר אילו רכיבים *אמורים*
# להתעדכן על המסך — וההצהרה הזו היא מה שהופך את בדיקת "האזור לא
# התעדכן" לבדיקה בלי התראות שקר. האזורים עצמם **נגזרים מהדף** ולא
# מוקלדים: ROI מוקלד ביד על רצועת הכרטיסים של לוח הבקרה נתן "עבר"
# בזמן שארבעת המונים שבתוכו היו תקועים על אפס.
#
# `window` הוא הטווח שבו הרכיב אמור לרוץ, כי ROI הדוק עדיין קולט
# את אנימציית הכניסה של הכרטיס סביבו.
PLAN = [
    {"id": "s1_intro"},
    {"id": "s2_vector"},
    {"id": "s3_avatar"},
    {"id": "s4_terminal"},
    {"id": "s5_dashboard", "probe_at": 4.0, "window": (1.2, 3.6)},
    {"id": "s6_physical"},
    {"id": "s7_motion"},
]


def make_render(fps: int = 30):
    def render(shot: dr.Shot, out: Path) -> dict:
        html = SCENES / f"{shot.source}.html"
        if not html.exists():
            raise FileNotFoundError(f"אין סצנה {html.name}")
        return engine.render(html, out, fps=fps)
    return render


def build(only: list[str] | None = None, fps: int = 30,
          fresh: bool = False) -> int:
    sys.stdout.reconfigure(encoding="utf-8")
    if fresh:
        dr.reset(PROD)
    d = dr.Director(PROD, "סרטון התצוגה")
    wanted = [p for p in PLAN if not only or p["id"] in only]
    for p in wanted:
        rois = None
        if "probe_at" in p:
            html = SCENES / f"{p['id']}.html"
            if html.exists():
                rois = probe.rois_from_page(
                    html, at=p["probe_at"], default_window=p.get("window"))
                print(f"  {p['id']}: {len(rois)} רכיבים לבדיקה נגזרו מהדף",
                      flush=True)
        d.add_shot(p["id"], p["id"], dynamic_rois=rois)
    d.save()

    t0 = time.time()

    def on_event(state: str, shot: dr.Shot) -> None:
        bv = shot.best_version
        print(f"  {shot.id:<16} {state:<9} "
              f"ציון {bv['score'] if bv else '—'}"
              f"{'  אשמה: ' + ', '.join(shot.blame) if shot.blame and state != dr.DONE else ''}",
              flush=True)

    print(f"→ מפיק {len(wanted)} שוטים ...", flush=True)
    st = d.run(make_render(fps), {"stride": 3}, on_event=on_event)
    print()
    print(d.report())

    if st["complete"]:
        final = PROD / "final" / "showreel.mp4"
        info = d.assemble(final, fps=fps)
        print(f"\n✓ הורכב: {final}")
        print(f"  {info['seconds']}ש · {info['frames']} פריימים · "
              f"{info['size_mb']}MB")
        from studio import qa
        rep = qa.inspect(final, stride=6)
        print(f"  בקרת איכות על הסרטון המורכב: "
              f"{'עבר' if rep.passed else 'נכשל'} · ציון {rep.score}")
    print(f"\nסך הכול {time.time() - t0:.1f} שניות")
    return 0 if st["complete"] else 1


def main(argv: list[str]) -> int:
    sys.stdout.reconfigure(encoding="utf-8")
    if "--status" in argv:
        d = dr.Director(PROD)
        print(d.report())
        return 0
    only = [a for a in argv if not a.startswith("-")]
    return build(only or None, fresh="--fresh" in argv)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
