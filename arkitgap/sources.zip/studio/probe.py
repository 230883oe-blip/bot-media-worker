# -*- coding: utf-8 -*-
"""גזירת אזורי בדיקה מהדף עצמו, במקום לנחש אותם ביד.

**למה זה קיים.** בקרת האיכות בודקת "האזור שאמור להתעדכן אכן
מתעדכן". כל כוחה של הבדיקה הזו תלוי בשאלה *איזה אזור*. ROI שהוקלד
ביד על רצועת הכרטיסים בלוח הבקרה נתן שונות של 0.0173 — פי ארבעה
מהסף — בזמן שארבעת המונים שבתוכו היו תקועים על אפס לאורך כל
הסצנה. מה שזז היה הכרטיסים סביבם, לא המספרים.

ROI מוקלד ביד הוא גם שקר שמתיישן: מזיזים כרטיס ב-CSS, וה-ROI
ממשיך להצביע על המקום הישן ולדווח "עבר".

לכן האזורים נשאלים מהדפדפן. הדף ממילא נפתח לרינדור, וכל אלמנט
יודע בדיוק איפה הוא יושב. אלמנט מסומן לבדיקה בשתי דרכים:

    <span class="counter" id="c1">0</span>          <!-- לפי מחלקה -->
    <span data-qa="עומס" data-qa-window="1.2,3.4">   <!-- מפורש -->

התוצאה היא ROI יחסי (0..1) שמתאים לכל רזולוציה, ולכן גם לא נשבר
כשמחליפים בין אנכי לאופקי.
"""
from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

# ברירת מחדל: מה נחשב "רכיב שאמור להתעדכן" גם בלי סימון מפורש.
DEFAULT_SELECTORS = ".counter, [data-qa], [data-counter]"

JS = """
(() => {
  const out = [];
  const W = window.innerWidth, H = window.innerHeight;
  document.querySelectorAll(%s).forEach((el, i) => {
    const r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return;
    const label = el.dataset.qa || el.id || (el.className || "el") + "_" + i;
    const win = el.dataset.qaWindow || "";
    // הרחבה קטנה כדי לא לחתוך גליף, אבל לא יותר - ROI רחב מודד
    // את הסצנה ולא את הרכיב.
    const pad = 2;
    out.push({
      label: String(label),
      roi: [
        Math.max(0, (r.left - pad) / W), Math.max(0, (r.top - pad) / H),
        Math.min(1, (r.width + pad * 2) / W), Math.min(1, (r.height + pad * 2) / H),
      ],
      window: win,
    });
  });
  return JSON.stringify(out);
})()
"""


async def _probe(html: Path, selectors: str, width: int, height: int,
                 at: float) -> list[dict]:
    import engine
    br = engine.Browser(width, height, 1)
    try:
        await br.start()
        await br.open_file(html)
        # דגימת הציר לזמן שבו הפריסה כבר נחה, אחרת נמדד מקום
        # של אלמנט שעוד נע באנימציית כניסה.
        try:
            await br.js(f"window.__seek && window.__seek({at:.3f})")
        except Exception:
            pass
        raw = await br.js(JS % json.dumps(selectors))
        return json.loads(raw) if raw else []
    finally:
        await br.close()


def rois_from_page(html: Path, selectors: str = DEFAULT_SELECTORS,
                   width: int = 1920, height: int = 1080,
                   at: float = 0.0,
                   default_window: tuple[float, float] | None = None
                   ) -> dict[str, object]:
    """מחזיר `{label: (roi, window)}` מוכן להעברה ל-qa.inspect."""
    found = asyncio.run(_probe(Path(html), selectors, width, height, at))
    out: dict[str, object] = {}
    for item in found:
        roi = tuple(float(x) for x in item["roi"])
        win = item.get("window") or ""
        if win:
            try:
                a, b = (float(x) for x in str(win).split(","))
                out[item["label"]] = (roi, (a, b))
                continue
            except Exception:
                pass
        out[item["label"]] = (roi, default_window) if default_window else roi
    return out


def main(argv: list[str]) -> int:
    sys.stdout.reconfigure(encoding="utf-8")
    if not argv:
        print("שימוש: python -m studio.probe <דף.html> [שנייה]")
        return 2
    at = float(argv[1]) if len(argv) > 1 else 0.0
    rois = rois_from_page(Path(argv[0]), at=at)
    for label, spec in rois.items():
        print(f"{label:<16} {spec}")
    print(f"\n{len(rois)} רכיבים לבדיקה")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
