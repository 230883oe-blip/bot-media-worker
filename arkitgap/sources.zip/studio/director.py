# -*- coding: utf-8 -*-
"""מנהל האולפן — שלבים 0 ו-20 בתוכנית ההפקה.

**מה הוא פותר.** עד היום הפקת סרטון כאן הייתה סקריפט אחד שרץ מלמעלה
למטה: רנדר כל הסצנות, אחד מהן נשבר — מתחילים מהתחלה. אין מצב, אין
תלויות, אין ניסיון חוזר, ואין דרך לדעת *מי* אשם. התוכנית מגדירה את
זה כשלב 0 במפורש, לפני כל שאר עשרים השלבים, ובצדק: בלי מצב מתמשך
אין לאן להחזיר שוט שנכשל בבקרת האיכות.

**שלוש החלטות שמגדירות את המודול.**

1. **המצב יושב בדיסק, לא בזיכרון התהליך.** הפקה נקטעת כאן בפועל —
   המחשב נרדם, הבוט מופעל מחדש. לכן כל שינוי מצב נכתב מיד
   (`production.json`, כתיבה אטומית דרך קובץ זמני). הפקה שנקטעה
   ממשיכה מהשוט שבו עצרה ולא מרנדרת מחדש מה שכבר עבר.

2. **בקרת האיכות היא *חלק* ממכונת המצבים, לא שלב אחרי.** שוט אינו
   `DONE` כשהרינדור חזר בקוד 0 — הוא `DONE` רק כשהוא עבר את
   `qa.inspect`. זה בדיוק ההפרש שהפיל כאן ארבעה סרטונים שסיימו
   "בהצלחה" עם פגם גלוי.

3. **ניסיון חוזר מנותב לפי אשמה.** `qa` מחזיר את תת-המערכת האחראית
   (`timeline`, `layout`, `databind`, `encode`...). המנהל ממפה כל
   אשמה לפעולת תיקון, ומנסה *תיקון אחר* בכל סבב. ניסיון חוזר שמריץ
   שוב בדיוק את אותו דבר הוא בזבוז זמן מחשב, לא תיקון.

**גרסאות ותקציב (שלב 20).** כל רינדור מוצלח נשמר כגרסה ממוספרת
ב-`renders/<shot>/v<N>.mp4`, והגרסה הטובה ביותר (לפי ציון בקרת
האיכות) היא זו שנכנסת לעריכה. נסיגה לגרסה קודמת היא שינוי מצביע,
בלי רינדור מחדש. זמן הרינדור המצטבר נמדד לכל שוט ולכל ההפקה, כי
על המכונה הזאת זמן מעבד הוא המשאב היחיד שנגמר.
"""
from __future__ import annotations

import json
import shutil
import time
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Callable, Optional

from studio import qa

# תיקיות ההפקה. סדר קבוע — כל שלב בתוכנית יודע לאן הוא כותב.
LAYOUT = [
    "script", "characters", "environments", "storyboard",
    "shots", "renders", "qa", "audio", "final",
]

# מצבי שוט. המעברים היחידים המותרים מוגדרים ב-ALLOWED.
PLANNED, RENDERING, QA_WAIT, REPAIR, DONE, FAILED, BLOCKED = (
    "PLANNED", "RENDERING", "QA", "REPAIR", "DONE", "FAILED", "BLOCKED")

ALLOWED = {
    PLANNED: {RENDERING, BLOCKED},
    RENDERING: {QA_WAIT, FAILED},
    QA_WAIT: {DONE, REPAIR},
    REPAIR: {RENDERING, FAILED},
    BLOCKED: {PLANNED},
    DONE: set(),
    FAILED: {REPAIR},
}

# אשמה -> מה לשנות בניסיון הבא. זה מה שהופך ניסיון חוזר לתיקון.
REPAIR_ACTIONS = {
    "timeline": "rebuild_timeline",     # ציר נפרד לרקע, גזירת זמן מ-t
    "encode": "reencode",               # שרשור פאקטים במקום קידוד מחדש
    "layout": "reflow",                 # הקטנת גופן / הזזת הקאדר פנימה
    "databind": "rebind",               # חיבור מחדש של הנתונים לציור
    "render": "rerender",               # רינדור נקי
    "lighting": "relight",
    "animation": "reanimate",
    "lipsync": "resync",
}


# --------------------------------------------------------------- מודל

@dataclass
class Shot:
    """שוט בודד. `deps` הם מזהי שוטים שחייבים להיות DONE לפניו."""

    id: str
    source: str                       # דף HTML / מתכון לרינדור
    seconds: float = 0.0
    state: str = PLANNED
    deps: list[str] = field(default_factory=list)
    attempts: int = 0
    versions: list[dict] = field(default_factory=list)
    best: int = -1                    # אינדקס הגרסה הנבחרת
    blame: list[str] = field(default_factory=list)
    repairs: list[str] = field(default_factory=list)
    render_sec: float = 0.0
    note: str = ""
    dynamic_rois: dict = field(default_factory=dict)

    @property
    def best_version(self) -> Optional[dict]:
        if 0 <= self.best < len(self.versions):
            return self.versions[self.best]
        return None

    def to_dict(self) -> dict:
        return asdict(self)


class StateError(RuntimeError):
    """מעבר מצב אסור. נזרק בכוונה ולא נבלע."""


# --------------------------------------------------------------- המנהל

class Director:
    def __init__(self, root: Path, name: str = "הפקה"):
        self.root = Path(root)
        self.name = name
        self.shots: dict[str, Shot] = {}
        self.order: list[str] = []
        self.log: list[dict] = []
        self.budget_sec = 0.0
        self.max_attempts = 3
        self._ensure_layout()
        self.load()

    # ------------------------------------------------------- התמדה
    @property
    def state_file(self) -> Path:
        return self.root / "production.json"

    def _ensure_layout(self) -> None:
        for d in LAYOUT:
            (self.root / d).mkdir(parents=True, exist_ok=True)

    def save(self) -> None:
        """כתיבה אטומית. הפקה שנקטעת באמצע כתיבה לא משאירה JSON חצי."""
        data = {
            "name": self.name, "order": self.order,
            "budget_sec": round(self.budget_sec, 2),
            "max_attempts": self.max_attempts,
            "shots": {k: v.to_dict() for k, v in self.shots.items()},
            "log": self.log[-400:],
        }
        tmp = self.state_file.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=1),
                       encoding="utf-8")
        tmp.replace(self.state_file)

    def load(self) -> bool:
        if not self.state_file.exists():
            return False
        try:
            data = json.loads(self.state_file.read_text(encoding="utf-8"))
        except Exception:
            return False
        self.name = data.get("name", self.name)
        self.order = list(data.get("order", []))
        self.budget_sec = float(data.get("budget_sec", 0.0))
        self.max_attempts = int(data.get("max_attempts", 3))
        self.log = list(data.get("log", []))
        self.shots = {k: Shot(**v) for k, v in data.get("shots", {}).items()}
        return True

    # ------------------------------------------------------- בנייה
    def add_shot(self, shot_id: str, source: str, seconds: float = 0.0,
                 deps: list[str] | None = None,
                 dynamic_rois: dict | None = None) -> Shot:
        if shot_id in self.shots:
            return self.shots[shot_id]
        s = Shot(id=shot_id, source=str(source), seconds=seconds,
                 deps=list(deps or []), dynamic_rois=dict(dynamic_rois or {}))
        self.shots[shot_id] = s
        self.order.append(shot_id)
        self._note(shot_id, "נוסף לתוכנית הצילום")
        return s

    def _note(self, shot_id: str, msg: str, **extra) -> None:
        self.log.append({"t": round(time.time(), 1), "shot": shot_id,
                         "msg": msg, **extra})

    def _move(self, shot: Shot, to: str, why: str = "") -> None:
        if to not in ALLOWED.get(shot.state, set()):
            raise StateError(f"{shot.id}: {shot.state} -> {to} אסור")
        shot.state = to
        self._note(shot.id, f"מצב -> {to}" + (f" ({why})" if why else ""))

    # ------------------------------------------------------- תלויות
    def ready(self) -> list[Shot]:
        """שוטים שאפשר לרנדר עכשיו: PLANNED/REPAIR וכל התלויות DONE."""
        out = []
        for sid in self.order:
            s = self.shots[sid]
            if s.state not in (PLANNED, REPAIR):
                continue
            missing = [d for d in s.deps
                       if self.shots.get(d) is None
                       or self.shots[d].state != DONE]
            if missing:
                if s.state == PLANNED:
                    s.state = BLOCKED
                    self._note(s.id, f"חסום על {missing}")
                continue
            out.append(s)
        return out

    def unblock(self) -> None:
        for s in self.shots.values():
            if s.state == BLOCKED:
                if all(self.shots.get(d) and self.shots[d].state == DONE
                       for d in s.deps):
                    s.state = PLANNED
                    self._note(s.id, "התלויות הושלמו — חזר לתוכנית")

    # ------------------------------------------------------- גרסאות
    def _version_path(self, shot: Shot, n: int) -> Path:
        d = self.root / "renders" / shot.id
        d.mkdir(parents=True, exist_ok=True)
        return d / f"v{n}.mp4"

    def rollback(self, shot_id: str, version: int) -> bool:
        """נסיגה לגרסה קודמת. מצביע בלבד — בלי רינדור מחדש."""
        s = self.shots[shot_id]
        if not (0 <= version < len(s.versions)):
            return False
        s.best = version
        s.state = DONE
        self._note(shot_id, f"נסיגה לגרסה v{version}")
        self.save()
        return True

    # ------------------------------------------------------- הצינור
    def run_shot(self, shot: Shot,
                 render: Callable[[Shot, Path], dict],
                 qa_kw: dict | None = None) -> Shot:
        """מרנדר שוט, מריץ עליו בקרת איכות, ומחליט DONE / REPAIR.

        `render(shot, out_path) -> dict` הוא הפעולה החיצונית. היא
        מוחלפת בבדיקות ובהרצות שונות, וזה מה שמאפשר למנהל להיות
        אדיש לשאלה *איך* מרנדרים.
        """
        self._move(shot, RENDERING, f"ניסיון {shot.attempts + 1}")
        shot.attempts += 1
        n = len(shot.versions)
        out = self._version_path(shot, n)
        t0 = time.time()
        try:
            info = render(shot, out) or {}
        except Exception as exc:                       # noqa: BLE001
            dt = time.time() - t0
            shot.render_sec += dt
            self.budget_sec += dt
            shot.state = FAILED
            shot.note = f"{type(exc).__name__}: {exc}"
            self._note(shot.id, "הרינדור נפל", error=shot.note)
            self.save()
            return shot
        dt = time.time() - t0
        shot.render_sec += dt
        self.budget_sec += dt
        self._move(shot, QA_WAIT)

        rep = qa.inspect(out, expect_sec=shot.seconds or None,
                         dynamic_rois=shot.dynamic_rois or None,
                         **(qa_kw or {}))
        (self.root / "qa").mkdir(parents=True, exist_ok=True)
        (self.root / "qa" / f"{shot.id}_v{n}.json").write_text(
            json.dumps(rep.to_dict(), ensure_ascii=False, indent=1),
            encoding="utf-8")
        shot.versions.append({
            "v": n, "mp4": str(out), "score": rep.score,
            "passed": rep.passed, "render_sec": round(dt, 1),
            "blames": rep.blames, **{k: info[k] for k in
                                     ("frames", "seconds") if k in info},
        })
        # הגרסה הנבחרת היא בעלת הציון הגבוה ביותר, לא בהכרח האחרונה
        best = max(range(len(shot.versions)),
                   key=lambda i: shot.versions[i]["score"])
        shot.best = best
        shot.blame = rep.blames

        if rep.passed:
            self._move(shot, DONE, f"ציון {rep.score}")
        else:
            actions = [REPAIR_ACTIONS.get(b, "rerender") for b in rep.blames]
            if shot.attempts >= self.max_attempts:
                shot.state = FAILED
                shot.note = f"נכשל {shot.attempts} פעמים: {rep.blames}"
                self._note(shot.id, "מוותר", blames=rep.blames)
            else:
                self._move(shot, REPAIR, ", ".join(rep.blames))
                shot.repairs = actions
                # האשמה נרשמת ביומן ההפקה, לא רק בשוט: השוט נדרס
                # בניסיון הבא, והיומן הוא מה שנשאר כדי לדעת *למה*
                # היה צריך תיקון בכלל.
                self._note(shot.id, "תיקון מנותב", blames=rep.blames,
                           actions=actions, version=n, score=rep.score,
                           failed=[c["name"] for c in rep.failures])
        self.save()
        return shot

    def run(self, render: Callable[[Shot, Path], dict],
            qa_kw: dict | None = None,
            on_event: Callable[[str, Shot], None] | None = None,
            max_rounds: int = 12) -> dict:
        """מריץ את ההפקה עד שכל השוטים DONE או FAILED.

        `max_rounds` הוא תקרה קשה. לולאת תיקון שלא מתקדמת נעצרת
        לבד — על המכונה הזאת לולאה אינסופית של רינדור היא תקלה
        שמשתיקה את המחשב לשעות.
        """
        for _ in range(max_rounds):
            self.unblock()
            batch = self.ready()
            if not batch:
                break
            for shot in batch:
                self.run_shot(shot, render, qa_kw)
                if on_event:
                    on_event(shot.state, shot)
        return self.status()

    # ------------------------------------------------------- דיווח
    def status(self) -> dict:
        by: dict[str, int] = {}
        for s in self.shots.values():
            by[s.state] = by.get(s.state, 0) + 1
        done = [s for s in self.shots.values() if s.state == DONE]
        return {
            "name": self.name,
            "shots": len(self.shots),
            "by_state": by,
            "done": len(done),
            "failed": by.get(FAILED, 0),
            "avg_score": round(sum(s.best_version["score"] for s in done)
                               / len(done), 1) if done else 0.0,
            "budget_sec": round(self.budget_sec, 1),
            "complete": all(s.state == DONE for s in self.shots.values())
            if self.shots else False,
        }

    def assemble(self, out: Path, fps: int = 30) -> dict:
        """שלב 14 — עריכה: מחבר את הגרסאות הנבחרות לסרטון אחד.

        מסרב להרכיב הפקה שאינה שלמה. סרטון "כמעט שלם" הוא בדיוק
        מה שעבר כאן בעבר כתוצאה תקינה.
        """
        import sys
        sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
        import engine                                    # noqa: E402

        missing = [s.id for s in self.shots.values() if s.state != DONE]
        if missing:
            raise RuntimeError(f"אי אפשר להרכיב — שוטים שלא עברו: {missing}")
        parts = [Path(self.shots[sid].best_version["mp4"]) for sid in self.order]
        out = Path(out)
        out.parent.mkdir(parents=True, exist_ok=True)
        info = engine.concat(parts, out, fps=fps)
        self._note("FINAL", "הורכב", **{k: info[k] for k in ("frames", "seconds")})
        self.save()
        return info

    def report(self) -> str:
        st = self.status()
        lines = [f"{self.name} · {st['done']}/{st['shots']} עברו · "
                 f"ציון ממוצע {st['avg_score']} · "
                 f"{st['budget_sec']:.0f}ש זמן רינדור"]
        for sid in self.order:
            s = self.shots[sid]
            bv = s.best_version
            mark = {DONE: "✓", FAILED: "✗"}.get(s.state, "·")
            extra = f"ציון {bv['score']}" if bv else ""
            if s.blame and s.state != DONE:
                extra += f" · אשמה: {', '.join(s.blame)}"
            if s.repairs and s.state != DONE:
                extra += f" · תיקון: {', '.join(s.repairs)}"
            lines.append(f" {mark} {sid:<16} {s.state:<10} "
                         f"נסיונות {s.attempts} · {extra}")
        return "\n".join(lines)


def reset(root: Path) -> None:
    """מוחק מצב הפקה. קיים כדי שבדיקות יתחילו נקי."""
    f = Path(root) / "production.json"
    if f.exists():
        f.unlink()
    shutil.rmtree(Path(root) / "renders", ignore_errors=True)
    shutil.rmtree(Path(root) / "qa", ignore_errors=True)
