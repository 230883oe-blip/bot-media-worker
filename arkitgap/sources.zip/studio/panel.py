# -*- coding: utf-8 -*-
"""הפאנל ולולאת השיפור — אבחון → תיקון → רינדור מחדש → הערכה מחדש.

**מה שהמשימה דורשת, ומה שבאמת קשה בה.** חמישה מבקרים זה החלק הקל;
הם מודולים נפרדים ב-`critics.py`. מה שמכריע הוא מה עושים עם חמישה
ציונים, ואיך לולאת תיקון אוטונומית נעצרת בלי לשקר.

**החלטה 1 — אין ממוצע בשער הכניסה.** התרחיש שהרג את הגרסה הראשונה:
סיפור 95, משחק 92, אנימציה 90, צילום 88, איכות חזותית 18 → ממוצע
76, "נראה בסדר", והשוט שיצא היה בלתי צפוי. לכן שלושה תנאים
*במקביל*, וכל אחד יכול להפיל לבדו:

* ווטו — מבקר אחד מתחת ל-``HARD_FLOOR`` מפיל את השוט, נקודה.
* רצפה — **כל** מבקר חייב ``PASS_FLOOR``.
* ממוצע — וגם הממוצע חייב ``PASS_MEAN``, שהוא גבוה מהרצפה. בלי
  התנאי השלישי חמישה ציונים של 70 בדיוק עוברים, וזה שוט בינוני.

(מועצה 05/10 — GPT-4, Qwen 3.8, Command A — שלושתם אמרו "מינימום
ולא ממוצע" בנפרד. את ההמלצה הרביעית של Qwen, "אם הציונים מתכנסים
הכרז PASS גם מתחת לרף", **פסלתי**: זו בדיוק ההצלחה המדומה
שהמשימה אוסרת. התכנסות מתחת לרף נקראת כאן ``STALLED``.)

**החלטה 2 — "החוליה החלשה" חייבת להיות יציבה, לא רועשת.** אם שני
מבקרים צמודים, בחירת המינימום מתחלפת בכל סבב בגלל 0.3 נקודה, הלולאה
מתקנת את A, אחר כך את B, ושוב את A — וכל תיקון מבטל את קודמו. שלוש
הגנות יחד:

1. **אזור תיקו** ``TIE_EPS``: כל מי שבתוך 5 נקודות מהמינימום הוא
   מועמד שווה.
2. **סדר קדימות קבוע** בין המועמדים: איכות חזותית → צילום →
   אנימציה → משחק → סיפור. זה לא שרירותי — זה סדר התלות. אין טעם
   לכייל משחק על שוט שהתמונה שלו מרוחה, כי מדידת המשחק עצמה
   מושפעת מהתמונה.
3. **דביקות**: אם החוליה שתוקנה בסבב הקודם עוד מועמדת **והיא
   שיפרה** — נשארים עליה. תיקון שעובד לא מחליפים באמצע.

**החלטה 3 — ארבעה סיומים, ורק אחד מהם "עבר".** ``PASSED`` כשכל
שלושת תנאי השער התקיימו. ``STALLED`` כשהציון המינימלי לא זז
ב-``PLATEAU_DELTA`` לאורך ``PLATEAU_ROUNDS`` סבבים. ``REGRESSED``
כשתיקון הוריד מבקר אחר ביותר מ-``REGRESSION_DROP`` פעמיים —
כלומר התיקונים נלחמים זה בזה. ``EXHAUSTED`` כשנגמרו הסבבים או
ספר התיקונים. בשלושת האחרונים הלולאה **נסוגה לגרסה הטובה ביותר
שנמדדה** ומדווחת שהשוט לא עבר. לא "כמעט עבר".
"""
from __future__ import annotations

import json
import time
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Callable, Optional

from studio import critics as C

# --------------------------------------------------------------- ספים
HARD_FLOOR = 40.0        #: ווטו מיידי
PASS_FLOOR = 70.0        #: כל מבקר חייב
PASS_MEAN = 78.0         #: וגם הממוצע
TIE_EPS = 5.0            #: אזור תיקו בבחירת החוליה החלשה
REGRESSION_DROP = 4.0    #: ירידה אצל מבקר שלא תוקן = רגרסיה
MAX_REGRESSIONS = 2      #: שתי רגרסיות רצופות ועוצרים
PLATEAU_ROUNDS = 3       #: כמה סבבים בלי שיפור נחשבים קיפאון
PLATEAU_DELTA = 2.0      #: שיפור קטן מזה אינו שיפור
STICKY_GAIN = 1.0        #: שיפור מינימלי שמצדיק להישאר על אותה חוליה

#: סדר התלות. מי שקודם — מתוקן קודם בתיקו.
PRECEDENCE = ("visual", "cinematography", "animation", "acting", "story")

PASSED, STALLED, REGRESSED, EXHAUSTED = (
    "PASSED", "STALLED", "REGRESSED", "EXHAUSTED")


# --------------------------------------------------------------- פסק הפאנל

@dataclass
class PanelVerdict:
    shot_id: str
    scores: dict[str, float]
    passed: bool
    gate: str                       # איזה תנאי הפיל, בעברית
    weakest: str
    weakest_score: float
    diagnosis: list[dict] = field(default_factory=list)
    verdicts: dict[str, dict] = field(default_factory=dict)
    mean: float = 0.0
    worst: float = 0.0

    @property
    def repairs(self) -> list[str]:
        out: list[str] = []
        for d in self.diagnosis:
            if d["repair"] not in out:
                out.append(d["repair"])
        return out

    def to_dict(self) -> dict:
        d = asdict(self)
        d["repairs"] = self.repairs
        return d

    def text(self) -> str:
        head = (f"{'✓ עבר את הפאנל' if self.passed else '✗ נפל בפאנל'}"
                f"  {self.shot_id}  ·  מינימום {self.worst:.1f} · "
                f"ממוצע {self.mean:.1f}")
        lines = [head, f"  שער: {self.gate}"]
        for n in C.NAMES:
            if n not in self.scores:
                continue
            sc = self.scores[n]
            mark = "✓" if sc >= PASS_FLOOR else ("✗" if sc < HARD_FLOOR else "·")
            tag = "  ← החוליה החלשה" if n == self.weakest and not self.passed else ""
            lines.append(f"  {mark} {C.HE[n]:<14} {sc:5.1f}{tag}")
        for d in self.diagnosis:
            lines.append(f"      · {d['code']}: {d['label']} = {d['value']} "
                         f"(דרוש {d['limit']}) → תיקון {d['repair']}")
        return "\n".join(lines)


class Panel:
    """חמשת המבקרים כגוף אחד: מריץ, מאחד, ומאבחן.

    הפאנל **אינו** מתקן ואינו מרנדר. זה מכוון: שער האיכות חייב
    להיות ניתן להרצה לבד, בלי מנוע רינדור, אחרת אי אפשר לבדוק
    אותו — וזו הסיבה שחבילת הבדיקות כאן רצה בשניות ולא בשעות.
    """

    def __init__(self, floor: float = PASS_FLOOR, mean: float = PASS_MEAN,
                 hard: float = HARD_FLOOR, names: tuple[str, ...] = C.NAMES):
        self.floor, self.mean_req, self.hard = floor, mean, hard
        self.names = tuple(names)
        self._last_weakest: str = ""
        self._last_scores: dict[str, float] = {}

    # ---------------------------------------------------- הרצה
    def judge(self, ev: C.Evidence) -> dict[str, C.Verdict]:
        """חמש הערכות בלתי תלויות. אף מבקר לא רואה את ציון חברו."""
        return {n: C.review_one(n, ev) for n in self.names}

    # ---------------------------------------------------- איחוד
    def _gate(self, scores: dict[str, float]) -> tuple[bool, str]:
        worst_n = min(scores, key=lambda k: scores[k])
        worst = scores[worst_n]
        avg = sum(scores.values()) / len(scores)
        if worst < self.hard:
            return False, (f"ווטו — {C.HE[worst_n]} {worst:.1f} מתחת "
                           f"לרצפה הקשה {self.hard:.0f}")
        if worst < self.floor:
            return False, (f"{C.HE[worst_n]} {worst:.1f} מתחת לרצפה "
                           f"{self.floor:.0f}")
        if avg < self.mean_req:
            return False, (f"כולם מעל הרצפה אך הממוצע {avg:.1f} מתחת "
                           f"ל-{self.mean_req:.0f}")
        return True, (f"כל חמשת המבקרים מעל {self.floor:.0f} והממוצע "
                      f"{avg:.1f}")

    def weakest(self, scores: dict[str, float]) -> str:
        """החוליה החלשה — פער מהחציון, אזור תיקו, קדימות, ודביקות.

        הפער נמדד מהחציון ולא מהממוצע: ממוצע נגרר אחרי המבקר
        הקטסטרופלי עצמו, ואז *כל* המבקרים נראים "מעל הממוצע"
        והבחירה מאבדת רזולוציה.
        """
        order = sorted(scores, key=lambda k: scores[k])
        low = scores[order[0]]
        cands = [k for k in order if scores[k] <= low + TIE_EPS]
        if len(cands) == 1:
            pick = cands[0]
        else:
            prev = self._last_weakest
            gain = (scores.get(prev, 0.0) -
                    self._last_scores.get(prev, 0.0)) if prev else 0.0
            if prev in cands and gain >= STICKY_GAIN:
                pick = prev                       # התיקון עובד — נשארים
            else:
                pick = min(cands, key=lambda k: PRECEDENCE.index(k)
                           if k in PRECEDENCE else 99)
        self._last_weakest = pick
        self._last_scores = dict(scores)
        return pick

    # ---------------------------------------------------- אבחון
    @staticmethod
    def diagnose(v: C.Verdict, top: int = 3) -> list[dict]:
        """הכשלים החמורים של המבקר החלש, עם פעולת התיקון לכל אחד.

        מוגבל ל-3: רשימת תיקונים ארוכה בסבב אחד היא בדיוק מה
        שמייצר רגרסיה — שינוי של שש ידיות בבת אחת לא ניתן לשייך
        לתוצאה, ולכן גם לא ניתן לבטל נכון.
        """
        return v.failures[:top]

    def review(self, ev: C.Evidence) -> PanelVerdict:
        vs = self.judge(ev)
        scores = {n: v.score for n, v in vs.items()}
        ok, gate = self._gate(scores)
        weak = self.weakest(scores)
        diag = [] if ok else self.diagnose(vs[weak])
        return PanelVerdict(
            shot_id=ev.shot_id, scores={k: round(v, 1) for k, v in scores.items()},
            passed=ok, gate=gate, weakest=weak,
            weakest_score=round(scores[weak], 1),
            diagnosis=diag, verdicts={n: v.to_dict() for n, v in vs.items()},
            mean=round(sum(scores.values()) / len(scores), 1),
            worst=round(min(scores.values()), 1),
        )


# --------------------------------------------------------------- הלולאה

@dataclass
class Round:
    n: int
    scores: dict[str, float]
    worst: float
    mean: float
    weakest: str
    repairs: list[str]
    applied: list[str] = field(default_factory=list)
    #: למי התיקון כוון בפועל. **לא תמיד** ``weakest``: אם ספר
    #: התיקונים של החוליה החלשה נגמר, התיקון מכוון לכושלת הבאה —
    #: וזיהוי הרגרסיה חייב להשתמש ביעד האמיתי, אחרת הוא מאשים את
    #: המבקר הלא נכון ופוסל תיקון תקין.
    target: str = ""
    regression: list[str] = field(default_factory=list)
    note: str = ""
    render_sec: float = 0.0
    version: int = -1


@dataclass
class LoopResult:
    shot_id: str
    outcome: str
    rounds: list[dict]
    best_round: int
    best_scores: dict[str, float]
    final: Optional[dict] = None
    why: str = ""

    @property
    def passed(self) -> bool:
        return self.outcome == PASSED

    def to_dict(self) -> dict:
        return asdict(self)

    def text(self) -> str:
        mark = {PASSED: "✓", STALLED: "⏸", REGRESSED: "⟲",
                EXHAUSTED: "✗"}.get(self.outcome, "·")
        out = [f"{mark} {self.shot_id} · {self.outcome} · {self.why}"]
        for r in self.rounds:
            sc = " ".join(f"{C.HE[k][:4]}{r['scores'][k]:.0f}"
                          for k in C.NAMES if k in r["scores"])
            out.append(f"  סבב {r['n']}: מינ' {r['worst']:.1f} ממוצע "
                       f"{r['mean']:.1f} | {sc} | חלש: {C.HE[r['weakest']]}"
                       + (f" | תיקון: {', '.join(r['applied'])}"
                          if r["applied"] else "")
                       + (f" | ⚠ רגרסיה ב-{', '.join(r['regression'])}"
                          if r["regression"] else ""))
        out.append(f"  הטוב ביותר: סבב {self.best_round} · "
                   + " ".join(f"{C.HE[k][:4]}{v:.0f}"
                              for k, v in self.best_scores.items()))
        return "\n".join(out)


class RefineLoop:
    """אבחון → תיקון → רינדור מחדש → הערכה מחדש, עד שעוברים או עוצרים.

    שלושת הקולבקים הם כל הממשק אל העולם, וזה מה שמאפשר לבדוק את
    הלולאה בשניות בלי מנוע רינדור:

    * ``render(knobs, round_n) -> Any`` — מרנדר ומחזיר מה שיוצר.
    * ``evidence(artifact, round_n) -> Evidence`` — אוסף עדות.
    * ``apply(knobs, repairs, verdict) -> dict`` — מחזיר ידיות חדשות.
      אם הוא מחזיר את אותן ידיות בדיוק, הלולאה מזהה שאין מה לנסות
      ועוצרת ב-``EXHAUSTED`` במקום לרנדר שוב אותו דבר.
    """

    def __init__(self, shot_id: str, render: Callable, evidence: Callable,
                 apply: Callable, panel: Panel | None = None,
                 max_rounds: int = 6, knobs: dict | None = None,
                 on_round: Callable[[Round], None] | None = None):
        self.shot_id = shot_id
        self.render = render
        self.evidence = evidence
        self.apply = apply
        self.panel = panel or Panel()
        self.max_rounds = max_rounds
        self.knobs = dict(knobs or {})
        self.on_round = on_round
        self.rounds: list[Round] = []
        self.tried: dict[str, set[str]] = {}      # חוליה -> תיקונים שנוסו

    # ------------------------------------------------- זיהוי רגרסיה
    @staticmethod
    def _regressed(prev: dict[str, float], now: dict[str, float],
                   target: str) -> list[str]:
        """מי *אחר* ירד משמעותית. תיקון שפוגע במי שלא התלונן חשוד."""
        return [k for k, v in now.items()
                if k != target and prev.get(k, v) - v > REGRESSION_DROP]

    def _plateau(self) -> bool:
        if len(self.rounds) < PLATEAU_ROUNDS + 1:
            return False
        tail = [r.worst for r in self.rounds[-(PLATEAU_ROUNDS + 1):]]
        return (max(tail) - min(tail)) < PLATEAU_DELTA

    # ------------------------------------------------- הרצה
    def run(self) -> LoopResult:
        regressions = 0
        last_scores: dict[str, float] = {}
        for i in range(1, self.max_rounds + 1):
            t0 = time.time()
            artifact = self.render(dict(self.knobs), i)
            ev = self.evidence(artifact, i)
            ev.shot_id = ev.shot_id or self.shot_id
            pv = self.panel.review(ev)
            r = Round(n=i, scores=dict(pv.scores), worst=pv.worst,
                      mean=pv.mean, weakest=pv.weakest,
                      repairs=list(pv.repairs),
                      render_sec=round(time.time() - t0, 2))

            if last_scores:
                r.regression = self._regressed(
                    last_scores, pv.scores,
                    self.rounds[-1].target or self.rounds[-1].weakest)
            self.rounds.append(r)
            if self.on_round:
                self.on_round(r)

            if pv.passed:
                r.note = "עבר את הפאנל"
                return self._done(PASSED, pv, pv.gate)

            if r.regression:
                regressions += 1
                r.note = (f"התיקון {', '.join(self.rounds[-2].applied)} "
                          f"הוריד את {', '.join(C.HE[k] for k in r.regression)}")
                # התיקון שהזיק נפסל, ולא ינוסה שוב על אותה חוליה
                prev_r = self.rounds[-2]
                for a in prev_r.applied:
                    self.tried.setdefault(prev_r.target or prev_r.weakest,
                                          set()).add(a)
                if regressions >= MAX_REGRESSIONS:
                    return self._done(
                        REGRESSED, pv,
                        f"{regressions} תיקונים פגעו במבקרים אחרים — "
                        "התיקונים נלחמים זה בזה")
            else:
                regressions = 0

            if self._plateau():
                return self._done(
                    STALLED, pv,
                    f"הציון המינימלי לא זז ב-{PLATEAU_DELTA} נקודות "
                    f"לאורך {PLATEAU_ROUNDS} סבבים — אין מה להמשיך לנסות")

            if i == self.max_rounds:
                return self._done(EXHAUSTED, pv,
                                  f"נגמרו {self.max_rounds} הסבבים")

            # --- תיקון: רק מה שלא נוסה כבר על החוליה הזו
            #
            # **שתי נסיגות שנמדדו כאן, ושתיהן עצרו עבודה שאפשר היה
            # לעשות:**
            #
            # 1. *ספר התיקונים של החוליה החלשה נגמר → סוף הלולאה.*
            #    גם כששני מבקרים אחרים היו מתחת לרצפה עם תיקונים
            #    שלא נוסו. עכשיו עוברים לכושלת הבאה בסדר התלות.
            # 2. *`apply` החזיר את אותן ידיות → סוף הלולאה.* על
            #    המנוע האמיתי שלושה תיקוני אנימציה שונים
            #    (`apply_easing`, `add_anticipation`, `insert_hold`)
            #    מצביעים כולם על אותה ידית אחת. ברגע שהיא כבר
            #    במקומה, כל השלושה הם no-op — והלולאה נעצרה
            #    כשהתמונה והקאדר עוד היו מתחת לרצפה. עכשיו תיקון
            #    שלא הזיז ידית נפסל **לבדו**, והחיפוש ממשיך.
            target, fresh, new = "", [], None
            before = json.dumps(self.knobs, sort_keys=True, default=str)
            # **כל מבקר שיש לו כשל הוא יעד אפשרי, לא רק מי שמתחת
            # לרצפה.** השער דורש גם ממוצע ``PASS_MEAN`` שגבוה
            # מהרצפה, ולכן מבקר שיושב על 71.8 *מונע מעבר* ובכל זאת
            # אינו "מתחת לרצפה". נמדד: הלולאה סיימה EXHAUSTED עם
            # מצלמה מקרטעת וקאדר צמוד מדי, בזמן ששתי הידיות שמתקנות
            # אותם היו פנויות ולא נוסו.
            cands = [pv.weakest] + [
                n for n in PRECEDENCE
                if n != pv.weakest
                and any(not m["ok"]
                        for m in pv.verdicts.get(n, {}).get("measures", []))]
            dead: list[str] = []
            for cand in cands:
                done = self.tried.setdefault(cand, set())
                opts = self.panel.diagnose(
                    C.Verdict(cand, pv.scores.get(cand, 0.0),
                              pv.verdicts[cand]["measures"]))
                todo = [m["repair"] for m in opts if m["repair"] not in done]
                if not todo:
                    continue
                cand_new = self.apply(dict(self.knobs), todo, pv) or {}
                if json.dumps(cand_new, sort_keys=True,
                              default=str) == before:
                    # התיקון הזה אינו ניתן להחלה כאן. לפסול אותו
                    # ולהמשיך — לא לסיים את הלולאה.
                    done.update(todo)
                    dead.extend(todo)
                    continue
                target, fresh, new = cand, todo, cand_new
                break
            if not fresh or new is None:
                why = "התיקון לא שינה שום ידית — רינדור חוזר זהה הוא בזבוז" \
                    if dead else \
                    ("ספר התיקונים נגמר לכל הכושלים (נוסו: "
                     + str({C.HE[k]: sorted(v)
                            for k, v in self.tried.items()}) + ")")
                return self._done(EXHAUSTED, pv, why)
            done = self.tried.setdefault(target, set())
            self.knobs = new
            r.applied = fresh
            r.target = target
            done.update(fresh)
            last_scores = dict(pv.scores)
        return self._done(EXHAUSTED, None, "לא הגיע לשער")   # pragma: no cover

    # ------------------------------------------------- סיום
    def _done(self, outcome: str, pv: PanelVerdict | None,
              why: str) -> LoopResult:
        """נסיגה לסבב הטוב ביותר שנמדד. "כמעט עבר" אינו תוצאה."""
        best = max(range(len(self.rounds)),
                   key=lambda i: (self.rounds[i].worst, self.rounds[i].mean))
        return LoopResult(
            shot_id=self.shot_id, outcome=outcome,
            rounds=[asdict(r) for r in self.rounds],
            best_round=self.rounds[best].n,
            best_scores=dict(self.rounds[best].scores),
            final=pv.to_dict() if pv else None, why=why,
        )


# --------------------------------------------------------------- שמירה

def save(result: LoopResult, root: Path) -> Path:
    d = Path(root) / "qa"
    d.mkdir(parents=True, exist_ok=True)
    p = d / f"panel_{result.shot_id}.json"
    p.write_text(json.dumps(result.to_dict(), ensure_ascii=False, indent=1),
                 encoding="utf-8")
    return p
