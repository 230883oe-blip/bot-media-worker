"""מבחן האמן הסופי — STAGE 12 · FINAL MASTER TEST.

סצנת דיאלוג קולנועית של **12 שניות** עם שתי הדמויות המקוריות
(לוקאס ומאיה), ועליה שלושה מבחנים שכל אחד מודד ערוץ אחד **לבד**:

1. ``MUTE TEST`` — השמע מנותק בקוד. צופה חייב להבין שבע עובדות:
   מי מקשיב (בכל חצי), מי לא נוח, מי מופתע, מי חושב, מי משתנה
   רגשית, ומי שולט בשיחה.
2. ``AUDIO ONLY TEST`` — התמונה מנותקת. הדיבור, הפרוזודיה והחפיפה
   חייבים להעביר את אותו מבנה רגשי.
3. ``FULL CINEMATIC TEST`` — תמונה + אנימציה + מצלמה + קול יחד,
   בציון 0..100 דרך חמשת המבקרים של STAGE 11.

ושלושת העקרונות שהופכים את זה למבחן ולא להצהרה:

* **הקריאה אינה יודעת את התסריט.** ``mute_read`` מקבל שני מסלולי
  בקרות ללא שמות דמויות משמעותיים, ו**מוצא** את התשובות — כולל את
  חלון המחשבה, שהוא מחפש ולא מקבל. ההשוואה ל-``TRUTH`` נעשית אחר כך.
* **ההכרעות הן השוואתיות ולא ספי-קסם.** כל שאלה היא "מי מהשתיים",
  עם דרישת מרווח מינימלי — ולכן סצנה שטוחה מחזירה "לא ניתן להכרעה"
  ונכשלת, במקום להגריל תשובה ולעבור במחצית המקרים.
* **גרסאות ביקורת שחייבות ליפול.** ``swap`` (החלפת הזהויות),
  ``flat`` (בלי משחק פנים), ``frozen`` (בובה מוקפאת), ``monotone``
  (קריאה שטוחה) ו-``sequential`` (בלי חפיפה) — כל אחת שוברת דרישה
  אחת ונופלת בדיוק במבחן שמגן עליה. בלעדיהן המדדים מודדים את עצמם.

`python -m studio.master` מריץ הכול ומדפיס את שלושת הציונים.
"""

from __future__ import annotations

import json
import math
import sys
from contextlib import contextmanager
from dataclasses import dataclass, field
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from rig import cinema as CI
from rig import duet as D

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "production" / "master"

# ------------------------------------------------------------- הסצנה

#: 12 שניות — בתוך הטווח 10..15 שהמשימה דורשת. התשע הראשונות הן
#: הדואט (לוקאס מכחיש, מאיה חותכת אותו), והשלוש הנוספות הן הביט
#: השלישי: שניהם שותקים, ושם נקרא "מי חושב".
SCENE_LEN = 12.0
FPS = 30

#: הביט השלישי. הוא **אינו** מועבר למודד — המודד מחפש את חלון
#: השתיקה בעצמו. הוא מופיע כאן רק כדי לבנות את ההצגה.
#: 9.05–10.90 ולא 7.60–9.90: **החלון נקבע לפי מתי הגוף נרגע
#: בפועל**, לא לפי מתי הדיבור נגמר. `find_quiet` מצא את השקט
#: החזותי ב-9.03, כי העברת המשקל השנייה (`duet.RESHIFT`) רצה עד
#: שם — והרהור שיושב בתוך תנועת גוף אינו נקרא כהרהור.
THINK_WIN = (9.05, 10.90)
THINK_RISE = 0.55          #: שניות העלייה אל תוך המחשבה
LAND = 11.60               #: ומכאן נחיתה אל סוף הסצנה
#: ולאן נוחתים. **לא לאפס.** נחיתה אל אפס היא איפוס, לא נחיתה:
#: `acting.continuity` מדד 0.16 שמירת רגש בזנב, כלומר הדמות חזרה
#: לנקודת המוצא כאילו לא קרה דבר. אדם שהרהר אינו חוזר לאפס.
BEAT3_REST = 0.68

#: מי חושב ומי לא נוח בביט השלישי. מאיה אמרה את שלה והיא שוקלת;
#: לוקאס שומע את עצמו ולא נוח לו.
THINKER = "maya"
UNEASY = "lucas"

# ------------------------------------- תזמון הדיבור מהקול הנשמע

#: החפיפה הנשמעת שאנחנו דורשים ברגע החיתוך.
CUT_OVERLAP = 0.38
#: ומתחת לזה אין קול בכלל (על RMS מנורמל לשיא).
AUDIBLE_TH = 0.03

_AUD: dict[str, tuple[float, float]] = {}


def audible_span(who: str) -> tuple[float, float]:
    """(כמה שקט בראש ההקלטה, מתי הקול בה נגמר) — בשניות.

    **זה הבאג שהתיקון הזה סוגר.** ב-`duet` חלונות הדיבור נגזרים
    מ*אורך הקובץ* (``L_DUR``/``M_DUR``), ו-edge-tts מוסיף זנב שקט
    ארוך: בהקלטה של לוקאס, 2.64 שניות קובץ אך הקול נשמע רק
    0.22–1.72. לכן "מאיה חותכת את לוקאס" — הרגע של הסצנה — נפל
    כולו בתוך השקט שלו, ובפועל **לא נשמע כלל**. אוזן אינה שומעת
    חלון זמן; היא שומעת אנרגיה.
    """
    if who not in _AUD:
        from rig import voice as V                      # noqa: PLC0415
        tr = V.load(D.LINES[who], D.VOICES[who])
        if tr is None or not len(tr.rms):
            lo, hi = D.WINDOWS[who]
            _AUD[who] = (0.0, hi - lo)
        else:
            r = np.asarray(tr.rms, float)
            r = r / max(1e-9, float(r.max()))
            on = np.flatnonzero(r >= AUDIBLE_TH)
            hop = float(tr.hop)
            _AUD[who] = ((float(on[0]) * hop, float(on[-1]) * hop)
                         if len(on) else (0.0, len(r) * hop))
    return _AUD[who]


def speech_windows() -> dict[str, tuple[float, float]]:
    """חלונות הדיבור של סצנת המבחן, **נגזרים ולא נבחרים**.

    לוקאס פותח ב-0.90 ונגמר כשהקול שלו נגמר (ולא כשהקובץ נגמר —
    אחרת הפה נע בשקט). מאיה נכנסת בדיוק כך שתהיה חפיפה **נשמעת**
    של `CUT_OVERLAP`, בתוך דבריו.
    """
    l_lead, l_tail = audible_span("lucas")
    m_lead, m_tail = audible_span("maya")
    l0 = D.L_SPEECH[0]
    l1 = round(l0 + l_tail, 3)
    m0 = round(l1 - CUT_OVERLAP - m_lead, 3)
    return {"lucas": (l0, l1), "maya": (m0, round(m0 + m_tail, 3))}


@contextmanager
def scene_timing(enabled: bool = True):
    """מזריק את חלונות הדיבור של המבחן אל `duet`, **בעקביות**.

    `duet.actor`, `duet.reactive_breath` ו-`duet.envelope` כולם
    נגזרים מ-``WINDOWS``/``CUT_IN``. דריסה של אחד מהם בלבד הייתה
    יוצרת סצנה שבה הפה במקום אחד והנשימה במקום אחר — ולכן כאן
    נדרסים כולם יחד, שני המטמונים מתנקים, והמצב חוזר ב-`finally`
    גם אם נזרקה חריגה.
    """
    if not enabled:
        yield None
        return
    win = speech_windows()
    old_w = dict(D.WINDOWS)
    old_cut, old_ov = D.CUT_IN, D.OVERLAP
    old_env, old_solo = dict(D._ENV_CACHE), dict(D._SOLO_BREATH)
    # **גלאי האירועים של `cinema` מכויל לסצנה שלו.** `SETTLE_T`
    # שם הוא סוף דברי הדובר הראשון *בסצנה ההיא* (3.53), ובסצנה
    # הזו הוא 2.62 — ולכן הגלאי חיפש העברת משקל בחלון הלא נכון
    # והחזיר 4 אירועים מתוך 8. גלאי שמקבל תזמון של סצנה אחרת
    # מודד את הסצנה האחרת.
    old_ci = (CI.SCENE_LEN, CI.SETTLE_T, CI.A_SPEECH, CI.B_SPEECH)
    D.WINDOWS.update(win)
    D.CUT_IN = win["maya"][0]
    D.OVERLAP = round(win["lucas"][1] - win["maya"][0], 4)
    D._ENV_CACHE.clear()
    D._SOLO_BREATH.clear()
    CI.SCENE_LEN = SCENE_LEN
    CI.A_SPEECH = tuple(win["lucas"])
    CI.B_SPEECH = tuple(win["maya"])
    CI.SETTLE_T = win["lucas"][1]
    try:
        yield win
    finally:
        D.WINDOWS.clear()
        D.WINDOWS.update(old_w)
        D.CUT_IN, D.OVERLAP = old_cut, old_ov
        D._ENV_CACHE.clear()
        D._ENV_CACHE.update(old_env)
        D._SOLO_BREATH.clear()
        D._SOLO_BREATH.update(old_solo)
        (CI.SCENE_LEN, CI.SETTLE_T, CI.A_SPEECH,
         CI.B_SPEECH) = old_ci

#: עוצמות הביט השלישי. קטנות בכוונה — "מחשבה" שנראית היא העמדת
#: פנים. ההכרעה כאן השוואתית, ולכן קטן מספיק.
THINK_GAZE = 0.42          #: הסטת המבט הצידה
THINK_BROW = 0.20
THINK_LID = 0.24
UNEASY_BROW = 0.30
UNEASY_LID = 0.22
UNEASY_MOUTH = 0.18
HOLD_GAZE = 0.75           #: כמה המבט של הלא-נוח נמשך חזרה אל בן השיח


#: **האמת, מהתסריט.** שבע הכרעות, ובהן שלוש "מאיה" וארבע "לוקאס":
#: מודד שעונה תמיד את אותו שם נכשל, ויש לכך בדיקה מפורשת.
TRUTH: dict[str, str] = {
    "listening_first":  "maya",    # לוקאס מדבר 0.90-3.56, היא מאזינה
    "listening_second": "lucas",   # מאיה מדברת עד 7.06, הוא מאזין
    "uneasy":           "lucas",   # guilt/defend — הוא נתפס
    "surprised":        "lucas",   # החיתוך ב-3.10 נופל עליו
    "thinking":         "maya",    # amusement/test — היא שוקלת
    "changing":         "lucas",   # ניטרלי→מופתע→לא נוח→מהרהר
    "control":          "maya",    # היא חותכת, היא מסיימת
}

QUESTIONS: dict[str, str] = {
    "listening_first":  "מי מקשיב בחצי הראשון",
    "listening_second": "מי מקשיב בחצי השני",
    "uneasy":           "מי לא נוח",
    "surprised":        "מי מופתע",
    "thinking":         "מי חושב",
    "changing":         "מי משתנה רגשית",
    "control":          "מי שולט בשיחה",
}

#: גרסאות הביקורת של המבחן הזה, מעל אלה של `duet`.
VARIANTS: dict[str, str] = {
    "swap":       "הזהויות מוחלפות — כל התשובות צריכות להתהפך",
    "flat":       "בלי משחק פנים — ההבעה קפואה על פריים ההתחלה",
    "frozen":     "בובה מוקפאת — פנים, עיניים וראש בלי תנועה",
    "monotone":   "הקול נקרא בעוצמה שטוחה, בלי פרוזודיה",
    "sequential": "בלי חפיפה — כל אחד מחכה בנימוס לתורו",
}

#: גרסאות שמשנות את **הסצנה** (ולא את ההאזנה/הקריאה).
_SCENE_VARIANTS = frozenset({"flat", "frozen", "sequential", "static",
                             "mirror", "sync", "solo"})


def _ease(x: float) -> float:
    """0..1 -> 0..1, חלק בשני הקצוות."""
    x = max(0.0, min(1.0, float(x)))
    return x * x * (3.0 - 2.0 * x)


#: ההפתעה ברגע החיתוך: עולה חד, דועכת.
REACT_RISE = 0.18
REACT_FALL = 0.85
REACT_BROW = 0.46
REACT_WIDE = 0.34
#: ואי-הנוחות שנשארת אחריה, עולה עד שיא בסוף הביט השני.
UNEASY_BASE = 0.34
UNEASY_RAMP = 1.60         #: שניות עד השיא, מרגע החיתוך


def _react(t: float) -> float:
    """עוצמת תגובת ההפתעה בזמן t, סביב רגע החיתוך."""
    t0 = D.CUT_IN
    if t < t0 - REACT_RISE or t > t0 + REACT_FALL:
        return 0.0
    if t <= t0:
        return _ease((t - (t0 - REACT_RISE)) / REACT_RISE)
    return 1.0 - _ease((t - t0) / REACT_FALL)


def _uneasy_base(t: float) -> float:
    """אי-הנוחות שמצטברת אחרי שנתפס, ונשארת עד סוף הסצנה."""
    t0 = D.CUT_IN
    if t <= t0:
        return 0.0
    return _ease(min(1.0, (t - t0) / UNEASY_RAMP))


def _beat3(t: float) -> float:
    """עוצמת הביט השלישי בזמן t: עולה, מחזיקה, ונוחתת."""
    t0, t1 = THINK_WIN
    if t <= t0:
        return 0.0
    if t < t0 + THINK_RISE:
        return _ease((t - t0) / THINK_RISE)
    if t <= t1:
        return 1.0
    if t >= LAND:
        return BEAT3_REST
    return 1.0 - (1.0 - BEAT3_REST) * _ease((t - t1) / max(1e-6, LAND - t1))


def _add(d: dict, key: str, delta: float, lo: float = -1.0,
         hi: float = 1.0) -> None:
    """מוסיף לערוץ, **וגם אם הוא חסר מהפריים**.

    `_emotion_actor` משמיט ערוץ שערכו אפס, ולכן ``brow_furrow_L``
    קיים בפריים של שנייה 2 וחסר בפריים של שנייה 8. גרסה שבדקה
    ``if key in d`` פשוט לא כתבה לשם כלום — כלומר יחידת ה-FACS
    המרכזית של אי-נוחות (AU4) נשארה אפס לאורך כל הסצנה, בשקט.
    **היעדר ערוץ הוא אפס, לא "אין ערוץ כזה".**
    """
    d[key] = round(max(lo, min(hi, float(d.get(key, 0.0)) + delta)), 5)


def actor(who: str, variant: str = "full"):
    """`(u, t) -> (ctl, {}, mph)` לדמות אחת בסצנת המבחן הסופי.

    עובר דרך `duet.actor`, כלומר אותו מסלול בדיוק שמייצר את
    הסרטון, ומוסיף עליו את הביט השלישי. גרסת ביקורת שאינה של
    הסצנה (``swap``, ``monotone``) אינה נוגעת בשחקן בכלל.
    """
    if variant not in VARIANTS and variant not in D.VARIANTS \
            and variant != "full":
        raise ValueError(f"גרסה לא מוכרת: {variant}")

    inner = variant if variant in D.VARIANTS else "full"
    base = D.actor(who, inner)
    thinks = (who == THINKER)
    frozen_face = variant in ("flat", "frozen")
    frozen_head = (variant == "frozen")
    held: dict = {}
    held_mph: dict = {}

    def fn(u, t):
        ctl, _x, mph = base(u, float(t))
        ctl, mph = dict(ctl), dict(mph)

        if frozen_face:
            # ההבעה קפואה על פריים ההתחלה. הגוף ממשיך לנוע, ולכן
            # הנפילה היא **של המשחק** ולא של "הסרטון ריק".
            if not held:
                h0, _y, m0 = base(0.0, 0.0)
                held.update({k: v for k, v in h0.items()
                             if _is_face(k) or (frozen_head and _is_head(k))})
                held_mph.update(m0)
            ctl.update(held)
            mph.update(held_mph)
            return ctl, {}, mph

        tt = float(t)
        if not thinks:
            # ההפתעה ברגע החיתוך — **בעיניים ובגבות, לפני התשובה.**
            # ``reacts`` של `_emotion_actor` מניע את הציון הפנימי אך
            # לא מגיע ל-AU1/AU2/`eye_wide`, ולכן נמדדה כאן הפתעה של
            # 0.03 אצל מי שנחתך מול 0.22 אצל מי שחתך — הפוך לגמרי
            # ממה שהסצנה מספרת.
            s = _react(tt)
            if s > 0.0:
                _add(ctl, "brow_inner_up_L", REACT_BROW * s)
                _add(ctl, "brow_inner_up_R", REACT_BROW * s)
                _add(ctl, "brow_outer_up_L", REACT_BROW * 0.8 * s)
                _add(ctl, "brow_outer_up_R", REACT_BROW * 0.8 * s)
                _add(mph, "eye_wide_L", REACT_WIDE * s)
                _add(mph, "eye_wide_R", REACT_WIDE * s)
                _add(mph, "pupil_dilate_L", REACT_WIDE * 0.5 * s)
                _add(mph, "pupil_dilate_R", REACT_WIDE * 0.5 * s)
            # ואחרי שהוא נתפס, אי-הנוחות נשארת ומתעצמת. זה
            # ה-`guilt` של התסריט, ובלעדיו "מי לא נוח" יצא תיקו.
            u = _uneasy_base(tt)
            if u > 0.0:
                _add(ctl, "brow_furrow_L", UNEASY_BASE * u)
                _add(ctl, "brow_furrow_R", UNEASY_BASE * u)
                _add(mph, "lid_tighten_L", UNEASY_BASE * 0.7 * u)
                _add(mph, "lid_tighten_R", UNEASY_BASE * 0.7 * u)
                _add(mph, "cheek_hollow_L", UNEASY_BASE * 0.35 * u)
                _add(mph, "cheek_hollow_R", UNEASY_BASE * 0.35 * u)

        g = _beat3(float(t))
        if g > 0.0:
            if thinks:
                # מבט שעוזב, מצח מתכנס קלות — מחשבה, לא הבעה.
                _add(ctl, "eye_aim_x", THINK_GAZE * g)
                _add(ctl, "brow_furrow_L", THINK_BROW * g)
                _add(ctl, "brow_furrow_R", THINK_BROW * g)
                _add(mph, "lid_tighten_L", THINK_LID * g)
                _add(mph, "lid_tighten_R", THINK_LID * g)
            else:
                # מחזיק מבט עליה, ולא נוח לו.
                if "eye_aim_x" in ctl:
                    ctl["eye_aim_x"] = round(
                        float(ctl["eye_aim_x"]) * (1.0 - HOLD_GAZE * g), 5)
                _add(ctl, "brow_furrow_L", UNEASY_BROW * g)
                _add(ctl, "brow_furrow_R", UNEASY_BROW * g)
                _add(ctl, "squint_L", UNEASY_LID * g * 0.6)
                _add(ctl, "squint_R", UNEASY_LID * g * 0.6)
                _add(mph, "lid_tighten_L", UNEASY_LID * g)
                _add(mph, "lid_tighten_R", UNEASY_LID * g)
                _add(mph, "mouth_corner_down_L", UNEASY_MOUTH * g)
                _add(mph, "mouth_corner_down_R", UNEASY_MOUTH * g)
                _add(mph, "lip_press", UNEASY_MOUTH * g)
        return ctl, {}, mph

    fn.speech = getattr(base, "speech", None)
    fn.body = getattr(base, "body", None)
    fn.track = getattr(base, "track", None)
    fn.eye = getattr(base, "eye", None)
    fn.window = getattr(base, "window", None)
    return _smoothed(fn)


#: מינימום דגימות בחלון ההחלקה. המספר בפועל נגזר מרוחב החלון
#: ומקצב הפריימים — דגימה לכל פריים — ולא נקבע קבוע.
#:
#: **למה זה חייב להיות נגזר, ולא מספר.** עם שלוש דגימות קבועות,
#: חלון של 0.2 שנייה דוגם כל 0.1 שנייה, כלומר כל שלושה פריימים —
#: זו **תת-דגימה ולא החלקה**, והיא מכניסה קיפול תדר. נמדד כאן
#: בדיוק: רעידת הגוף ירדה 0.688 -> 0.359 בחלון 0.08, ואז **עלתה
#: חזרה** ל-0.608 ב-0.16 ול-0.653 ב-0.20. כלומר ככל שההחלקה
#: "חזקה" יותר כך היא הזיקה — התנהגות שאין לה שום פשר פיזיקלי,
#: והיא כולה תוצר של הדגימה הדלילה.
SMOOTH_MIN_TAPS = 3

#: תקרת דגימות, כדי שחלון רחב לא יכפיל את זמן המדידה בלי גבול.
SMOOTH_MAX_TAPS = 13


def _smoothed(fn):
    """עוטף שחקן בהחלקה זמנית, לפי הכוונון שבתוקף.

    **ההחלקה היא על התנועה ולא על המדידה.** זו ההבחנה היחידה
    שחשובה כאן: פילטר שיושב ב-``evidence.track_from_fn`` היה
    מוריד את ``anim.jitter`` בדיוק באותה מידה — ולא היה משנה
    פריים אחד בסרטון. כלומר הציון היה עולה והאיכות לא, וזו
    ההתחזות שהמשימה אוסרת במפורש. כאן העטיפה היא על ``fn``
    עצמה, אותה פונקציה שמזינה גם את הרינדור.

    חלון ``0`` מחזיר את הפונקציה **כמות שהיא**, בלי שום עטיפה —
    כך שמערכת בלי כוונון מתנהגת בדיוק כמו לפני הקובץ הזה, ואפס
    עלות. זה גם מה שהופך את הבדיקה ל"האם ההחלקה שינתה משהו".
    """
    # **מקום אחד להחלקה.** המימוש עבר ל-``tuning.smoothed`` ברגע
    # שגם הגשר הדינמי נזקק לו (``showreel/bridge.build_shots``):
    # שתי עטיפות החלקה בשני קבצים היו נבדלות בשקט ברגע שאחת מהן
    # מתוקנת — וזו בדיוק ההתחזות שכל הקובץ הזה בנוי למנוע.
    # ``keep_ik=False`` ו-``set_missing=True`` משמרים בדיוק את
    # ההתנהגות שהייתה כאן, ו-83 שערי ``test_master`` מאמתים זאת.
    try:
        from studio import tuning as T
        return T.smoothed(fn, SCENE_LEN, FPS, keep_ik=False,
                          attrs=("speech", "body", "track", "eye", "window"),
                          set_missing=True)
    except Exception:                                   # noqa: BLE001
        return fn


FACE_PREFIX = ("brow_", "lid_", "squint", "cheek_", "nose_", "eye_wide",
               "smile", "pupil_", "blink")
HEAD_PREFIX = ("head_", "neck_", "eye_aim", "eye_converge")

#: ערוצי הגוף הגדולים. מהם נגזרת ה"יזימה": מי שמדבר מנפנף, מי
#: שמקשיב נייח. **אין כאן אף ערוץ פנים** — אחרת "מקשיב" היה נמדד
#: מאותם ערוצים שמהם נמדד "לא נוח", ושני הציונים לא היו שתי עדויות.
BODY_PREFIX = ("arm_", "elbow_", "shoulder_", "spine_", "hips_",
               "weight_", "wrist_", "curl_", "spread_", "fist_")


def _is_face(k: str) -> bool:
    return any(k.startswith(p) for p in FACE_PREFIX)


def _is_head(k: str) -> bool:
    return any(k.startswith(p) for p in HEAD_PREFIX)


def _is_body(k: str) -> bool:
    return any(k.startswith(p) for p in BODY_PREFIX)


# --------------------------------------------------------- הדגימה

@dataclass
class Lane:
    """מסלול חזותי של דמות אחת, **אחרי** ניתוק השמע."""
    times: np.ndarray
    keys: list[str]
    M: np.ndarray
    audio_keys: int = 0

    def ch(self, *names: str) -> np.ndarray:
        """סכום הערוצים המבוקשים; מה שאינו קיים פשוט אינו נספר."""
        idx = [self.keys.index(n) for n in names if n in self.keys]
        if not idx:
            return np.zeros(len(self.times))
        return self.M[:, idx].sum(axis=1)

    def group(self, pred) -> np.ndarray:
        idx = [i for i, k in enumerate(self.keys) if pred(k)]
        if not idx:
            return np.zeros((len(self.times), 0))
        return self.M[:, idx]

    @property
    def dt(self) -> float:
        return float(self.times[1] - self.times[0])


def mute_lanes(variant: str = "full", fps: int = FPS,
               seconds: float = SCENE_LEN) -> dict[str, Lane]:
    """דוגם את שתי הדמויות ו**מסיר בקוד** כל ערוץ שהשמע מניע.

    ההסרה היא לפי `cinema.is_audio_driven`, כלומר לפי **תחילית**
    ולא לפי רשימה — ערוץ פה שייווסף מחר ייתפס גם הוא. אחרי זה
    ``audio_keys`` חייב להיות 0, ואם לא — המבחן נכשל ולא "עובר
    חלקית".
    """
    n = int(round(seconds * fps)) + 1
    ts = np.linspace(0.0, seconds, n)
    who_order = ("lucas", "maya")
    if variant == "swap":
        who_order = ("maya", "lucas")

    out: dict[str, Lane] = {}
    with scene_timing():
        for slot, who in zip(("A", "B"), who_order):
            fn = actor(who,
                       "full" if variant in ("swap", "monotone") else variant)
            frames = []
            for t in ts:
                ctl, _x, mph = fn(0.0, float(t))
                merged = dict(ctl)
                merged.update(mph)
                frames.append(CI.visual_only(merged))
            # **איחוד המפתחות של כל הפריימים, ולא של הראשון.**
            # ערוץ שערכו אפס מושמט מהפריים, ולכן `brow_furrow_L`
            # חסר בשנייה 0 וקיים בשנייה 2. גרסה שלקחה את מפתחות
            # הפריים הראשון השמיטה את הערוץ **לגמרי** — מדידה
            # חלקית שמחזירה מספר, בלי שום שגיאה.
            keys = sorted({k for f in frames for k in f})
            M = np.array([[float(f.get(k, 0.0)) for k in keys]
                          for f in frames])
            bad = sum(1 for k in keys if CI.is_audio_driven(k))
            out[slot] = Lane(ts, keys, M, audio_keys=bad)
    return out


def _smooth(x: np.ndarray, dt: float, secs: float = 0.25) -> np.ndarray:
    """החלקה — צופה אינו רואה 70 מילישניות כשינוי רגשי.

    **הריפוד הוא בערך הקצה ולא באפסים.** ``np.convolve(mode="same")``
    מרפד באפס, ולכן הוא מרעיב את שני קצות העקומה — וכל מדד שמסתכל
    על *הזנב* (שמירת הרגש אחרי הביט) נמדד נמוך משקרית. כאן זה נתן
    ``acting.continuity`` 0.118 במקום ~0.68, כלומר "הדמות התאפסה"
    על סצנה שבה הזנב נבנה במפורש.
    """
    w = max(1, int(round(secs / max(1e-9, dt))))
    if w <= 1 or len(x) < 3:
        return np.asarray(x, float)
    x = np.asarray(x, float)
    pad = w // 2 + 1
    xp = np.concatenate([np.full(pad, x[0]), x, np.full(pad, x[-1])])
    k = np.ones(w) / w
    return np.convolve(xp, k, mode="same")[pad:pad + len(x)]


def _energy(Mx: np.ndarray, dt: float) -> np.ndarray:
    """אנרגיית התנועה של קבוצת ערוצים, מנורמלת לשנייה."""
    if Mx.size == 0 or Mx.shape[1] == 0:
        return np.zeros(Mx.shape[0] if Mx.ndim == 2 else 0)
    v = np.abs(np.gradient(Mx, dt, axis=0)).mean(axis=1)
    return v


def _norm01(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, float)
    lo, hi = float(x.min()), float(x.max())
    if hi - lo < 1e-12:
        return np.zeros_like(x)
    return (x - lo) / (hi - lo)


# ------------------------------------------------- המדדים החזותיים

GAZE_FULL = 0.35           #: הסטה שמעליה המבט עזב לגמרי
MARGIN = 0.08              #: פער יחסי מינימלי להכרעה
#: ורצפות מוחלטות: מתחתן אין בכלל מה למדוד, ולכן אין הכרעה.
UNEASY_FLOOR = 0.020
SURPRISE_FLOOR = 0.040
CHANGE_FLOOR = 0.060
CONTROL_FLOOR = 0.004
QUIET_MIN = 1.00           #: שניות שתיקה חזותית מינימליות לחלון מחשבה
QUIET_Q = 0.45             #: אחוזון היזימה שמתחתיו "שקט"
SURPRISE_WIN = 0.33        #: שניות החלון שבו מודדים עלייה חדה


def attention(ln: Lane) -> np.ndarray:
    """כמה המבט מופנה אל בן השיח: 1 = ישר אליו, 0 = עזב."""
    off = np.hypot(ln.ch("eye_aim_x"), ln.ch("eye_aim_y"))
    a = 1.0 - np.clip(off / GAZE_FULL, 0.0, 1.0)
    return _smooth(a, ln.dt)


def initiative(ln: Lane) -> np.ndarray:
    """יזימה — אנרגיית הגוף הגדול. מי שמדבר מנפנף; מי שמקשיב נייח."""
    return _smooth(_energy(ln.group(_is_body), ln.dt), ln.dt, 0.40)


def unease(ln: Lane) -> np.ndarray:
    """אי-נוחות מיחידות FACS ששרדו את ניתוק השמע.

    AU4 (`brow_furrow`), AU7 (`lid_tighten`/`squint`) ו-AU14
    (`cheek_hollow`). ``mouth_corner_down`` ו-``lip_press`` **אינם
    כאן** — ההשתקה הסירה אותם, וזה בדיוק העניין: אי-הנוחות חייבת
    להיקרא גם בלי הפה.
    """
    u = (ln.ch("brow_furrow_L", "brow_furrow_R") * 0.5
         + ln.ch("lid_tighten_L", "lid_tighten_R") * 0.35
         + ln.ch("squint_L", "squint_R") * 0.25
         + ln.ch("cheek_hollow_L", "cheek_hollow_R") * 0.20)
    return _smooth(np.clip(u, 0.0, None), ln.dt)


def surprise(ln: Lane) -> np.ndarray:
    """AU1+AU2+`eye_wide` — ההרמה, לא ההחזקה."""
    s = (ln.ch("brow_inner_up_L", "brow_inner_up_R") * 0.5
         + ln.ch("brow_outer_up_L", "brow_outer_up_R") * 0.5
         + ln.ch("eye_wide_L", "eye_wide_R") * 0.6)
    return _smooth(np.clip(s, 0.0, None), ln.dt, 0.15)


def surprise_peak(ln: Lane) -> tuple[float, float]:
    """(גובה העלייה החדה, הזמן שבו). הפתעה היא **שינוי**, לא גובה."""
    s = surprise(ln)
    w = max(1, int(round(SURPRISE_WIN / ln.dt)))
    if len(s) <= w:
        return 0.0, 0.0
    rise = s[w:] - s[:-w]
    i = int(np.argmax(rise))
    return float(rise[i]), float(ln.times[i + w])


#: משקל רכיב התנועה בעקומת הרגש. קטן בכוונה: בגרסה הראשונה הוא
#: היה 2.0 ו**הכריע** את העקומה, ולכן "מי משתנה רגשית" מדד בפועל
#: *מי מזיז את הפנים יותר* — שני הדוברים מזיזים, והתשובה יצאה
#: תיקו (מרווח 0.01). רכיב קטן מספיק כדי שבובה מוקפאת תיפול, ולא
#: גדול דיו כדי להחליף את המצב הרגשי עצמו.
EXPR_W = 0.45


def state_curve(ln: Lane) -> np.ndarray:
    """עקומת המצב הרגשי **המצטבר**, בלי רכיב ההפתעה.

    זו העקומה שמבקר המשחק מקבל, והיא אינה `emotion_curve`: הפתעה
    היא שיא חולף בשנייה 2.0, ובתוך העקומה היא הופכת את המגמה —
    `acting.silent` ירד ל-0.005 ("הרגש אינו מתפתח") על סצנה שבה
    אי-הנוחות רק מצטברת. הפתעה היא **אירוע**, לא מצב.
    """
    expr = _energy(ln.group(_is_face), ln.dt)
    return _smooth(unease(ln) + EXPR_W * expr, ln.dt, 0.40)


def emotion_curve(ln: Lane) -> np.ndarray:
    """עקומת המצב הרגשי הקריא: אי-נוחות + הפתעה + מעט מאמץ הבעה."""
    expr = _energy(ln.group(_is_face), ln.dt)
    return _smooth(unease(ln) + 0.6 * surprise(ln) + EXPR_W * expr,
                   ln.dt, 0.40)


def _pick(a: float, b: float, names=("A", "B"),
          floor: float = 0.0) -> tuple[str, float]:
    """מכריע בין שתי הדמויות, ומחזיר גם את המרווח היחסי.

    שני שומרים, ושניהם נדרשים:

    * מרווח יחסי מתחת ל-`MARGIN` → ``""`` ("לא ניתן להכרעה"). זה
      מה שמפיל סצנה שטוחה במקום להגריל לה תשובה.
    * **רצפה מוחלטת.** מרווח יחסי על שני ערכים זעירים מתפוצץ:
      1e-9 מול 2e-9 נותן 0.5, כלומר "הכרעה בביטחון מלא" על רעש
      חישובי. בבובה המוקפאת זה בדיוק מה שקרה — שלושת המדדים היו
      אפס בשתי הדמויות, וההכרעה בכל זאת יצאה חדה. אם שני הצדדים
      מתחת ל-`floor`, אין שם מה למדוד.
    """
    if max(abs(a), abs(b)) < floor:
        return "", 0.0
    denom = max(abs(a), abs(b), 1e-9)
    m = abs(a - b) / denom
    if m < MARGIN:
        return "", m
    return (names[0] if a > b else names[1]), m


def find_quiet(lanes: dict[str, Lane]) -> tuple[float, float] | None:
    """**מוצא** את חלון השתיקה החזותית — אינו מקבל אותו.

    החלון הארוך ביותר שבו שתי הדמויות מתחת לאחוזון היזימה שלהן.
    בלי זה מודד "מי חושב" היה מקבל את התשובה במתנה מהתסריט.
    """
    a, b = lanes["A"], lanes["B"]
    ia, ib = initiative(a), initiative(b)
    qa = float(np.quantile(ia, QUIET_Q))
    qb = float(np.quantile(ib, QUIET_Q))
    mask = (ia <= qa) & (ib <= qb)
    best = None
    i = 0
    while i < len(mask):
        if not mask[i]:
            i += 1
            continue
        j = i
        while j + 1 < len(mask) and mask[j + 1]:
            j += 1
        dur = float(a.times[j] - a.times[i])
        if dur >= QUIET_MIN and (best is None or dur > best[2]):
            best = (float(a.times[i]), float(a.times[j]), dur)
        i = j + 1
    return (best[0], best[1]) if best else None


def _slice(ln: Lane, t0: float, t1: float) -> slice:
    i0 = int(np.searchsorted(ln.times, t0))
    i1 = int(np.searchsorted(ln.times, t1))
    return slice(i0, max(i0 + 1, i1))


@dataclass
class Read:
    """מה שנקרא מהתמונה בלבד."""
    answers: dict[str, str] = field(default_factory=dict)
    margins: dict[str, float] = field(default_factory=dict)
    quiet: tuple[float, float] | None = None
    audio_keys: int = 0


def mute_read(lanes: dict[str, Lane]) -> Read:
    """שבע ההכרעות, מתוך התמונה בלבד ובלי לדעת את התסריט.

    השמות כאן הם ``A``/``B`` ולא ``lucas``/``maya`` — המודד אינו
    יודע מי הדמות ולא מה היא אמרה.
    """
    a, b = lanes["A"], lanes["B"]
    r = Read(audio_keys=a.audio_keys + b.audio_keys)
    half = SCENE_LEN / 2.0

    # --- מי מקשיב, בכל חצי: מבט על בן השיח, בלי יזימה
    attn = {"A": attention(a), "B": attention(b)}
    init = {"A": initiative(a), "B": initiative(b)}
    imax = max(float(init["A"].max()), float(init["B"].max()), 1e-9)
    for tag, (t0, t1) in (("listening_first", (0.0, half)),
                          ("listening_second", (half, SCENE_LEN))):
        sc = {}
        for k, ln in (("A", a), ("B", b)):
            sl = _slice(ln, t0, t1)
            sc[k] = (float(attn[k][sl].mean())
                     - 0.9 * float(init[k][sl].mean()) / imax)
        who, m = _pick(sc["A"], sc["B"])
        r.answers[tag], r.margins[tag] = who, m

    # --- מי לא נוח: יחידות FACS לאורך הסצנה
    ua, ub = unease(a), unease(b)
    r.answers["uneasy"], r.margins["uneasy"] = _pick(
        float(ua.mean()), float(ub.mean()), floor=UNEASY_FLOOR)

    # --- מי מופתע: העלייה החדה ביותר
    pa, ta = surprise_peak(a)
    pb, tb = surprise_peak(b)
    r.answers["surprised"], r.margins["surprised"] = _pick(
        pa, pb, floor=SURPRISE_FLOOR)

    # --- מי חושב: בחלון השתיקה שנמצא, מי שהמבט שלו עזב
    r.quiet = find_quiet(lanes)
    if r.quiet is None:
        r.answers["thinking"], r.margins["thinking"] = "", 0.0
    else:
        t0, t1 = r.quiet
        away = {}
        for k, ln in (("A", a), ("B", b)):
            sl = _slice(ln, t0, t1)
            away[k] = 1.0 - float(attn[k][sl].mean())
        r.answers["thinking"], r.margins["thinking"] = _pick(
            away["A"], away["B"])

    # --- מי משתנה רגשית: טווח עקומת הרגש
    def span(ln: Lane) -> float:
        c = emotion_curve(ln)
        return float(np.quantile(c, 0.95) - np.quantile(c, 0.05))
    r.answers["changing"], r.margins["changing"] = _pick(
        span(a), span(b), floor=CHANGE_FLOOR)

    # --- מי שולט: מי **פתח** פעולה חדשה ברגע שבן שיחו הופתע.
    # לא "מי היה פעיל אז": בגרסה הראשונה זה הצביע דווקא על מי
    # שנחתך, כי הוא היה באמצע דיבור ולכן ברמת פעילות גבוהה. מה
    # שגורם להפתעה אינו רמה אלא **עלייה** — כניסה שלא הייתה שם
    # רגע קודם. לכן נמדדת הנגזרת, לא הערך.
    ctrl = {}
    for me, t_peak in (("A", tb), ("B", ta)):
        ln = lanes[me]
        sl = _slice(ln, max(0.0, t_peak - 0.60), t_peak + 0.15)
        seg = init[me][sl]
        rise = (float(np.max(np.gradient(seg, ln.dt))) if len(seg) > 2
                else 0.0)
        ctrl[me] = max(0.0, rise)
    r.answers["control"], r.margins["control"] = _pick(
        ctrl["A"], ctrl["B"], floor=CONTROL_FLOOR)
    return r


#: מיפוי מהחריץ אל הדמות. **קבוע, גם ב-`swap`.**
#:
#: בגרסה הראשונה הוא התהפך יחד עם המסלולים — ושני ההיפוכים ביטלו
#: זה את זה, כלומר גרסת הביקורת החשובה ביותר **עברה את המבחן**
#: ולא בדקה דבר. ``swap`` מחליף את המסלולים בין החריצים; הפירוש
#: נשאר כשהיה, ולכן כל תשובה יוצאת הפוכה — וזה בדיוק מה שצריך
#: לקרות למודד שאינו קורא את המסלול אלא מנחש.
def slot_map(variant: str) -> dict[str, str]:
    return {"A": "lucas", "B": "maya"}


@dataclass
class TestResult:
    name: str
    score: float
    passed: bool
    detail: dict = field(default_factory=dict)
    note: str = ""

    def to_dict(self) -> dict:
        return {"name": self.name, "score": round(self.score, 1),
                "passed": bool(self.passed), "note": self.note,
                "detail": self.detail}


MUTE_PASS = 100.0          #: שבע מתוך שבע. שאלה שלא נקראת היא כשל.


def mute_test(variant: str = "full", fps: int = FPS) -> TestResult:
    """מבחן ההשתקה. הציון הוא אחוז ההכרעות הנכונות."""
    lanes = mute_lanes(variant, fps)
    r = mute_read(lanes)
    smap = slot_map(variant)
    rows, hits = {}, 0
    for q, want in TRUTH.items():
        got_slot = r.answers.get(q, "")
        got = smap.get(got_slot, "")
        ok = (got == want)
        hits += int(ok)
        rows[q] = {"question": QUESTIONS[q], "expected": want,
                   "read": got or "לא ניתן להכרעה",
                   "margin": round(r.margins.get(q, 0.0), 4), "ok": ok}
    score = 100.0 * hits / len(TRUTH)
    clean = (r.audio_keys == 0)
    note = (f"{hits}/{len(TRUTH)} הכרעות"
            + ("" if clean else f" · ⚠ {r.audio_keys} ערוצי שמע לא הוסרו"))
    return TestResult("MUTE", score, score >= MUTE_PASS and clean,
                      {"answers": rows, "quiet": r.quiet,
                       "audio_keys": r.audio_keys}, note)


# ------------------------------------------------- מבחן השמע בלבד

PROSODY_MIN = 0.30         #: סטיית התקן היחסית של העוצמה בתוך הדיבור
OVERLAP_MIN = 0.25         #: שניות חפיפה מינימליות
#: מעל זה הדובר נשמע. **חייב להיות זהה ל-`AUDIBLE_TH`**: החפיפה
#: מתוכננת שם ונמדדת כאן, ושני ספים שונים היו הופכים את התכנון
#: לתכנון של משהו אחר — חפיפה שתוכננה ב-0.03 ונמדדת ב-0.12 פשוט
#: לא קיימת.
ACTIVE_TH = AUDIBLE_TH
AUDIO_PASS = 75.0


def _env_curve(who: str, ts: np.ndarray, monotone: bool = False
               ) -> np.ndarray:
    """מעטפת האנרגיה של הדיבור, מההקלטה עצמה.

    ``monotone`` מחליף אותה בקופסה בעוצמה אחת — גרסת הביקורת של
    "קריאה בלי פרוזודיה".
    """
    if monotone:
        lo, hi = D.WINDOWS[who]
        return np.array([0.85 if lo <= t <= hi else 0.0 for t in ts])
    env = D.envelope(who)
    return np.array([float(env(float(t))) for t in ts])


def _declared_cutter() -> str:
    """מי נכנס שני לדברי חברו — מהתזמון, לא מהתסריט."""
    w = speech_windows()
    return "maya" if w["maya"][0] > w["lucas"][0] else "lucas"


def _active_window(y: np.ndarray, ts: np.ndarray) -> tuple[float, float]:
    on = np.flatnonzero(y >= ACTIVE_TH)
    if not len(on):
        return 0.0, 0.0
    return float(ts[on[0]]), float(ts[on[-1]])


def audio_test(variant: str = "full", fps: int = FPS) -> TestResult:
    """מבחן השמע בלבד: שני דוברים, חפיפה, פרוזודיה, ומבנה משותף."""
    n = int(round(SCENE_LEN * fps)) + 1
    ts = np.linspace(0.0, SCENE_LEN, n)
    mono = (variant == "monotone")
    seq = (variant == "sequential")

    env: dict[str, np.ndarray] = {}
    win: dict[str, tuple[float, float]] = {}
    with scene_timing():
        for who in ("lucas", "maya"):
            y = _env_curve(who, ts, mono)
            if seq and who == "maya":
                # בלי חפיפה: היא מחכה בנימוס שהוא יסיים.
                shift = (D.WINDOWS["lucas"][1] + 0.25) - D.WINDOWS["maya"][0]
                y = np.interp(ts - shift, ts, y, left=0.0, right=0.0)
            env[who] = y
            win[who] = _active_window(y, ts)
        cutter = _declared_cutter() if not seq else "maya"

    checks: dict[str, dict] = {}

    def chk(code: str, label: str, value: float, limit: str, ok: bool,
            weight: float = 1.0) -> None:
        checks[code] = {"label": label, "value": round(float(value), 4),
                        "limit": limit, "ok": bool(ok), "weight": weight}

    # 1 · שני דוברים נבדלים
    gap = abs(win["lucas"][0] - win["maya"][0])
    chk("two_voices", "שני דוברים נפרדים נשמעים", gap, "≥0.5ש הפרש פתיחה",
         gap >= 0.5 and win["lucas"][1] > 0 and win["maya"][1] > 0, 1.0)

    # 2 · חפיפה — ממנה נקרא "מי חותך את מי"
    both = (env["lucas"] >= ACTIVE_TH) & (env["maya"] >= ACTIVE_TH)
    ov = float(both.sum()) * float(ts[1] - ts[0])
    chk("overlap", "חפיפה שממנה נקרא מי חתך את מי", ov,
        f"≥{OVERLAP_MIN}ש", ov >= OVERLAP_MIN, 1.5)
    chk("cutter", "והחותך הוא מי שהתסריט אומר", 1.0 if cutter == "maya" else 0.0,
        "maya", cutter == "maya" and ov >= OVERLAP_MIN, 1.0)

    # 3 · פרוזודיה — עוצמה שאינה שטוחה, לכל דובר בנפרד
    for who in ("lucas", "maya"):
        y = env[who]
        on = y[y >= ACTIVE_TH]
        rel = float(on.std() / max(1e-9, on.mean())) if len(on) else 0.0
        chk(f"prosody_{who}", f"פרוזודיה בקול של {who}", rel,
            f"≥{PROSODY_MIN}", rel >= PROSODY_MIN, 1.25)

    # 4 · מבנה רגשי משותף: רגע ההסלמה בשמע מול זה שבתמונה
    lanes = mute_lanes("full" if variant in ("monotone", "swap") else variant,
                       fps)
    # **ההסלמה החזותית היא רגע המהפך, כלומר שיא ההפתעה.** שיפוע
    # עקומת הרגש אינו מתאים: בסצנה הזו יש שתי עליות — החיתוך
    # והביט השלישי — והשיפוע הגדול יותר יושב דווקא בביט השלישי,
    # שאין לו שום מקבילה בשמע. המדד השווה בין שני הערוצים הוא
    # הרגע שבו **קרה משהו חדש**.
    peaks = [surprise_peak(lanes[k]) for k in ("A", "B")]
    t_vis = float(max(peaks, key=lambda pr: pr[0])[1])
    d = env["maya"] - env["lucas"]
    cross = np.flatnonzero((d[:-1] <= 0) & (d[1:] > 0))
    t_aud = float(ts[cross[0]]) if len(cross) else -1.0
    near = (t_aud >= 0.0 and abs(t_aud - t_vis) <= 1.5)
    chk("structure", "ההסלמה בשמע באותו מקום שבתמונה",
        abs(t_aud - t_vis) if t_aud >= 0 else 99.0, "≤1.5ש", near, 1.5)

    # 5 · ביצוע קולי אמיתי (הקלטה, לא קופסה)
    real = all(getattr(actor(w), "track", None) is not None
               for w in ("lucas", "maya"))
    chk("recorded", "הקול מוקלט ולא מסונתז מחלון זמן",
        1.0 if real else 0.0, "הקלטה", real and not mono, 1.0)

    wsum = sum(c["weight"] for c in checks.values())
    good = sum(c["weight"] for c in checks.values() if c["ok"])
    score = 100.0 * good / max(1e-9, wsum)
    bad = [c["label"] for c in checks.values() if not c["ok"]]
    return TestResult("AUDIO_ONLY", score, score >= AUDIO_PASS,
                      {"checks": checks, "cutter": cutter,
                       "t_audio": t_aud, "t_visual": t_vis},
                      "הכול עבר" if not bad else " · ".join(bad[:3]))


# --------------------------------------------- המבחן הקולנועי המלא

#: המשקולות. ``render`` **אינו** ביניהן בכוונה: "הרינדור הסתיים"
#: אינו איכות, וזו הדרישה המפורשת של השלב הזה.
WEIGHTS = {"mute": 0.35, "audio": 0.20, "panel": 0.45}
FULL_PASS = 78.0

#: שלושת המבקרים שאינם דורשים סרטון מרונדר. בלעדיו `visual` ו-
#: `cinematography` מקבלים 0 ב-`_no_evidence`, והווטו של הפאנל
#: היה הופך את הציון כולו לחסר משמעות — דיווח על איכות שלא נמדדה.
DRY_CRITICS = ("story", "acting", "animation")


def _camera(seconds: float = SCENE_LEN):
    """רחב → בינוני → תקריב. הנמקה: הכניסה אל הפנים נעשית בדיוק
    כשהרגש מתחיל להיקרא, ולא בזמן קבוע."""
    def cam(u: float) -> dict:
        x = max(0.0, min(1.0, float(u)))
        e = _ease(x)
        return {"yaw": -14.0 + 9.0 * e, "pitch": 2.0 - 3.0 * e,
                "dist": 4.30 - 2.55 * e, "ty": 1.44 + 0.12 * e,
                "fov": 38.0 - 6.0 * e, "roll": 0.0}
    return cam


#: מה כל דמות מסתירה. ב-`duet` שני השדות האלה ריקים, ולכן
#: `story.premise` נפל על 2 מתוך 4 שדות ו-`story.subtext` על אפס —
#: 45.5 אצל שתי הדמויות, שהוא בדיוק מה שנמדד כאן לפני התיקון.
#: תת-טקסט אינו קוסמטיקה: בלעדיו לדמות אין מה לשחק *מתחת* למילים.
HIDES = {
    "lucas": "שהוא זוכר בדיוק מה אמר, ושהוא מתבייש בזה",
    "maya": "שזה גם משעשע אותה, ולא רק מכעיס",
}
CHANGES = {
    "lucas": "מהכחשה אל הודאה פנימית בלי להודות בקול",
    "maya": "מניצחון קטן אל ספק אם היה שווה את זה",
}
ARCS = {
    "lucas": {"dvalence": -0.42, "darousal": 0.46},
    "maya": {"dvalence": 0.30, "darousal": 0.34},
}


def _track(who: str, variant: str, fps: int) -> CI.Track:
    """`cinema.Track` **מהמסלול של הסצנה הזו**.

    הגרסה הראשונה האכילה את מבקר המשחק ב-``cinema.take()`` — מסלול
    של **סצנה אחרת לגמרי** (לוקאס ומאיה בשיחה על רשימה, 10 שניות).
    הציון שחזר היה אמיתי ולא שייך: 90.6 לדמות אחת ו-50.0 לשנייה,
    בלי שום קשר למה שנמדד כאן. ראיה שאינה של השוט הנבדק גרועה
    מהיעדר ראיה, כי היא לא מסגירה את עצמה.
    """
    n = int(round(SCENE_LEN * fps)) + 1
    ts = np.linspace(0.0, SCENE_LEN, n)
    fn = actor(who, "full" if variant in ("swap", "monotone") else variant)
    frames = []
    for t in ts:
        ctl, _x, mph = fn(0.0, float(t))
        f = dict(ctl)
        f.update(mph)
        frames.append(f)
    return CI.Track(name=who, times=ts, frames=frames, variant=variant,
                    speech=tuple(D.WINDOWS[who]))


def _lane_of(tr: CI.Track) -> Lane:
    """`Lane` מתוך `cinema.Track`, אחרי ניתוק השמע."""
    frames = [CI.visual_only(f) for f in tr.frames]
    keys = sorted({k for f in frames for k in f})
    M = np.array([[float(f.get(k, 0.0)) for k in keys] for f in frames])
    return Lane(np.asarray(tr.times, float), keys, M)


def _evidence(who: str, variant: str, fps: int, video: Path | None):
    from studio import evidence as EV
    fn = actor(who, "full" if variant in ("swap", "monotone") else variant)
    sit = D.SITS[who]()
    sit.shot_len = SCENE_LEN
    sit.hides = HIDES[who]
    sit.change = CHANGES[who]
    # המהפך **בשניות** (המבקר מחלק ב-`seconds` בעצמו), ובמקום שבו
    # הוא נגמר ולא במקום שבו הוא מתחיל: מה שנקרא הוא ההתגבשות.
    # **`plan_from_situation` קורא את הקשת ב-`getattr`, לא ב-`get`.**
    # מילון עובר שם בשקט ומחזיר אפסים, ולכן `story.turn` ו-
    # `story.change` יצאו 0.0 על סצנה שיש בה גם מהפך וגם שינוי —
    # כשל שנולד בממשק ולא בסצנה.
    arc = SimpleNamespace(turn=round(D.CUT_IN + UNEASY_RAMP, 3),
                          **ARCS[who])
    tb = _track(who, variant, fps)
    ta = _track(D.partner_of(who), variant, fps)
    events, perf = None, None
    try:
        events = CI.find_events(tb, ta)
    except Exception:                                   # noqa: BLE001
        events = None
    try:
        # **לא `tb.score()`.** הוא `cinema.discomfort`, ובו יושבת
        # AU1 (`brow_inner_up`) — שהיא גם חלק מהפתעה. ההפתעה בשנייה
        # 2.0 יצרה בו שיא גדול, ומכאן והלאה העקומה *יורדת*:
        # `acting.silent` חזר **מינוס** 0.23, כלומר "הרגש דועך עם
        # הזמן", על סצנה שבה אי-הנוחות רק מצטברת. העקומה הנכונה היא
        # המצב הרגשי הנמדד מהמסלול החזותי.
        perf = state_curve(_lane_of(tb))
    except Exception:                                   # noqa: BLE001
        perf = None
    return EV.collect(f"master_{who}", SCENE_LEN, actor=fn,
                      cam=_camera(), situation=sit, arc=arc, beats=3,
                      events=events, perf=perf, video=video, fps=fps)


def panel_test(variant: str = "full", fps: int = FPS,
               video: Path | None = None) -> TestResult:
    """חמשת המבקרים (או שלושה, בלי סרטון) על שתי הדמויות."""
    from studio import panel as P
    names = tuple(P.C.NAMES) if video is not None else DRY_CRITICS
    pan = P.Panel(names=names)
    per: dict[str, dict] = {}
    with scene_timing():
        for who in ("lucas", "maya"):
            ev = _evidence(who, variant, fps, video)
            pv = pan.review(ev)
            per[who] = {
                "scores": {k: round(v, 1) for k, v in pv.scores.items()},
                "mean": round(pv.mean, 1), "ok": bool(pv.passed),
                "why": pv.gate,
                # **האבחון נשמר, ולא רק הציון.** עד 07/10 נשמרו כאן
                # הציונים בלבד, ולכן ``pv.diagnosis`` — שכולל את קוד
                # הכשל המדויק (``anim.jitter``), את הערך, את הדרישה
                # ואת שם התיקון מ-``critics.REPAIR_FOR`` — נמדד בכל
                # הרצה ונזרק מיד. כלומר ספר התיקונים של המבקרים היה
                # קיים ומנותק: האבחון השורשי ידע לומר "אנימציה 54.7"
                # ולא ידע לומר *מה* נפל ומה לעשות.
                "diagnosis": list(pv.diagnosis),
                "repairs": list(pv.repairs),
                "weakest": pv.weakest}
    score = sum(p["mean"] for p in per.values()) / len(per)
    worst = min(min(p["scores"].values()) for p in per.values())
    ok = score >= FULL_PASS and worst >= P.PASS_FLOOR
    return TestResult("PANEL", score, ok,
                      {"per_character": per, "critics": list(names),
                       "worst": round(worst, 1),
                       "with_video": video is not None},
                      f"ממוצע {score:.1f} · החלש {worst:.1f}")


@dataclass
class Master:
    variant: str
    mute: TestResult
    audio: TestResult
    panel: TestResult
    full: float = 0.0
    passed: bool = False

    def to_dict(self) -> dict:
        return {"variant": self.variant, "full": round(self.full, 1),
                "passed": bool(self.passed),
                "tests": [self.mute.to_dict(), self.audio.to_dict(),
                          self.panel.to_dict()]}

    def text(self) -> str:
        L = [f"מבחן האמן הסופי · גרסה {self.variant} · "
             f"{SCENE_LEN:.0f} שניות · שתי דמויות"]
        for t in (self.mute, self.audio, self.panel):
            mark = "✓" if t.passed else "✗"
            L.append(f"  {mark} {t.name:<12} {t.score:6.1f}   {t.note}")
        for q, row in self.mute.detail.get("answers", {}).items():
            m = "✓" if row["ok"] else "✗"
            L.append(f"      {m} {row['question']:<22}"
                     f" נקרא: {row['read']:<6} (צפוי {row['expected']},"
                     f" מרווח {row['margin']:.2f})")
        L.append(f"  {'✓' if self.passed else '✗'} FULL CINEMATIC "
                 f"{self.full:.1f}/100   סף {FULL_PASS:.0f}")
        return "\n".join(L)


def run(variant: str = "full", fps: int = FPS,
        video: Path | None = None) -> Master:
    """כל שלושת המבחנים על אותה סצנה, ואז הציון המשוקלל."""
    mu = mute_test(variant, fps)
    au = audio_test(variant, fps)
    pa = panel_test(variant, fps, video)
    full = (WEIGHTS["mute"] * mu.score + WEIGHTS["audio"] * au.score
            + WEIGHTS["panel"] * pa.score)
    m = Master(variant, mu, au, pa, full,
               bool(mu.passed and au.passed and pa.passed
                    and full >= FULL_PASS))
    return m


def save(m: Master, root: Path = OUT) -> Path:
    root.mkdir(parents=True, exist_ok=True)
    p = root / f"master_{m.variant}.json"

    def _clean(o):
        if isinstance(o, dict):
            return {k: _clean(v) for k, v in o.items()}
        if isinstance(o, (list, tuple)):
            return [_clean(v) for v in o]
        if isinstance(o, (np.floating, np.integer)):
            return float(o)
        if isinstance(o, float) and (math.isnan(o) or math.isinf(o)):
            return None
        return o
    p.write_text(json.dumps(_clean(m.to_dict()), ensure_ascii=False,
                            indent=2), encoding="utf-8")
    return p


# ----------------------------------------------------------- הרצה

def main(argv=None) -> int:
    sys.stdout.reconfigure(encoding="utf-8")
    argv = list(sys.argv[1:] if argv is None else argv)
    variant = "full"
    if "--variant" in argv:
        variant = argv[argv.index("--variant") + 1]
    video = None
    if "--video" in argv:
        video = Path(argv[argv.index("--video") + 1])
    m = run(variant, FPS, video)
    print(m.text(), flush=True)
    print(f"\nנשמר: {save(m)}")
    return 0 if m.passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
