# -*- coding: utf-8 -*-
"""בדיקות למנהל האולפן — מכונת המצבים, התלויות, ולופ התיקון האוטומטי.

הבדיקה המרכזית כאן היא `t_repair_loop`: שוט מרונדר **פגום בכוונה**
בניסיון הראשון, נתפס על ידי בקרת האיכות, מנותב לתיקון לפי האשמה,
ובניסיון השני מרונדר נכון ועובר. זו כל הנקודה של שלב 18 בתוכנית —
אם הלופ הזה לא עובד, אין אוטונומיה, יש רק דוח.
"""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from studio import director as dr    # noqa: E402
from studio import qa                # noqa: E402
from studio.test_qa import _write, clean, _bg, _counter_box, FPS, H, W  # noqa: E402

ROI = {"מונה": (0.02, 0.05, 0.22, 0.14)}


def _ok_render(shot, out):
    _write(out, clean(72))
    return {"frames": 72}


def _frozen_render(shot, out):
    _write(out, [_counter_box(_bg(0), 10)] * 72)
    return {"frames": 72}


def _stuck_counter_render(shot, out):
    """מרנדר "תקין" לכל דבר — חוץ מהמונה שתקוע. הפגם האמיתי מ-04/10."""
    _write(out, [_counter_box(_bg(i), 7) for i in range(72)])
    return {"frames": 72}


# ------------------------------------------------------------- הבדיקות

def t_layout(tmp: Path) -> tuple[bool, str]:
    d = dr.Director(tmp / "p1", "בדיקה")
    missing = [x for x in dr.LAYOUT if not (tmp / "p1" / x).is_dir()]
    return not missing, f"{len(dr.LAYOUT)} תיקיות" if not missing else str(missing)


def t_illegal_transition(tmp: Path) -> tuple[bool, str]:
    d = dr.Director(tmp / "p2")
    s = d.add_shot("a", "x.html")
    try:
        d._move(s, dr.DONE)
        return False, "מעבר PLANNED->DONE לא נחסם"
    except dr.StateError as exc:
        return True, str(exc)


def t_deps_block(tmp: Path) -> tuple[bool, str]:
    d = dr.Director(tmp / "p3")
    d.add_shot("a", "a.html", 3.0)
    d.add_shot("b", "b.html", 3.0, deps=["a"])
    ready = [s.id for s in d.ready()]
    blocked = d.shots["b"].state
    return ready == ["a"] and blocked == dr.BLOCKED, \
        f"מוכן={ready}, b={blocked}"


def t_clean_shot_done(tmp: Path) -> tuple[bool, str]:
    d = dr.Director(tmp / "p4")
    s = d.add_shot("s1", "x", 72 / FPS, dynamic_rois=ROI)
    d.run_shot(s, _ok_render, {"stride": 3})
    bv = s.best_version
    return s.state == dr.DONE and bv and bv["passed"], \
        f"{s.state} · ציון {bv['score'] if bv else '—'}"


def t_bad_shot_repair(tmp: Path) -> tuple[bool, str]:
    """שוט פגום חייב להגיע ל-REPAIR עם אשמה ופעולת תיקון."""
    d = dr.Director(tmp / "p5")
    s = d.add_shot("s1", "x", 72 / FPS)
    d.run_shot(s, _frozen_render, {"stride": 3})
    ok = (s.state == dr.REPAIR and s.blame and s.repairs)
    return ok, f"{s.state} · אשמה {s.blame} · תיקון {s.repairs}"


def t_repair_loop(tmp: Path) -> tuple[bool, str]:
    """**הבדיקה המרכזית.** פגום -> נתפס -> נותב -> תוקן -> עבר.

    הפגם הוא המונה התקוע, כלומר הפגם האמיתי שנתפס כאן ב-04/10 רק
    בהסתכלות אנושית על תמונות. האשמה המצופה היא `databind` ולא
    "render" — חיבור הנתונים לציור, בדיוק כמו שהיה.
    """
    d = dr.Director(tmp / "p6")
    s = d.add_shot("s1", "x", 72 / FPS, dynamic_rois=ROI)
    calls = {"n": 0}

    def render(shot, out):
        calls["n"] += 1
        if calls["n"] == 1:
            return _stuck_counter_render(shot, out)   # הפעם הראשונה פגומה
        return _ok_render(shot, out)                  # אחרי התיקון — תקין

    st = d.run(render, {"stride": 3})
    first_blame = [e for e in d.log if e.get("blames")]
    ok = (s.state == dr.DONE and s.attempts == 2
          and len(s.versions) == 2 and s.best == 1
          and st["complete"])
    blame = first_blame[0]["blames"] if first_blame else []
    return ok and "databind" in blame, \
        (f"{s.state} · {s.attempts} נסיונות · אשמה ראשונה {blame} · "
         f"גרסה נבחרת v{s.best} (ציונים "
         f"{[v['score'] for v in s.versions]})")


def t_attempt_cap(tmp: Path) -> tuple[bool, str]:
    """שוט שלא מצליח להיתקן נעצר, ולא מרנדר לנצח."""
    d = dr.Director(tmp / "p7")
    d.max_attempts = 3
    s = d.add_shot("s1", "x", 72 / FPS)
    d.run(_frozen_render, {"stride": 4})
    return s.state == dr.FAILED and s.attempts == 3, \
        f"{s.state} אחרי {s.attempts} נסיונות · {s.note[:50]}"


def t_persistence(tmp: Path) -> tuple[bool, str]:
    """הפקה שנקטעה ממשיכה מאותו מקום — המחשב כאן נרדם בפועל."""
    root = tmp / "p8"
    d1 = dr.Director(root, "הפקה א")
    s = d1.add_shot("s1", "x", 72 / FPS)
    d1.run_shot(s, _ok_render, {"stride": 4})
    d1.add_shot("s2", "y", 3.0, deps=["s1"])
    d1.save()

    d2 = dr.Director(root)                 # תהליך "חדש"
    ok = (d2.name == "הפקה א" and d2.shots["s1"].state == dr.DONE
          and d2.order == ["s1", "s2"]
          and [x.id for x in d2.ready()] == ["s2"]
          and d2.budget_sec > 0)
    return ok, (f"נטען: s1={d2.shots['s1'].state}, "
                f"מוכן={[x.id for x in d2.ready()]}, "
                f"תקציב {d2.budget_sec:.1f}ש")


def t_best_version_and_rollback(tmp: Path) -> tuple[bool, str]:
    """הגרסה הנבחרת היא בעלת הציון הגבוה, ונסיגה היא מצביע בלבד."""
    d = dr.Director(tmp / "p9")
    s = d.add_shot("s1", "x", 72 / FPS)
    d.run_shot(s, _frozen_render, {"stride": 4})      # v0 — ציון נמוך
    d.run_shot(s, _ok_render, {"stride": 4})          # v1 — ציון גבוה
    picked = s.best
    scores = [v["score"] for v in s.versions]
    rolled = d.rollback("s1", 0)
    return (picked == 1 and scores[1] > scores[0] and rolled
            and s.best == 0 and s.state == dr.DONE), \
        f"ציונים {scores} · נבחר v{picked} · נסיגה ל-v{s.best}"


def t_assemble_refuses_partial(tmp: Path) -> tuple[bool, str]:
    d = dr.Director(tmp / "pa")
    s1 = d.add_shot("s1", "x", 72 / FPS)
    d.add_shot("s2", "y", 3.0)
    d.run_shot(s1, _ok_render, {"stride": 4})
    try:
        d.assemble(tmp / "pa" / "final" / "f.mp4")
        return False, "הרכיב הפקה חסרה"
    except RuntimeError as exc:
        return "s2" in str(exc), str(exc)[:60]


def t_assemble_full(tmp: Path) -> tuple[bool, str]:
    """הרכבה מלאה, והתוצאה עצמה עוברת בקרת איכות."""
    d = dr.Director(tmp / "pb")
    for sid in ("s1", "s2"):
        s = d.add_shot(sid, "x", 72 / FPS)
        d.run_shot(s, _ok_render, {"stride": 4})
    out = tmp / "pb" / "final" / "film.mp4"
    info = d.assemble(out, fps=FPS)
    rep = qa.inspect(out, stride=3)
    return (out.exists() and info["frames"] == 144 and rep.passed), \
        f"{info['frames']} פריימים · {info['seconds']}ש · ציון סופי {rep.score}"


def t_budget(tmp: Path) -> tuple[bool, str]:
    d = dr.Director(tmp / "pc")
    s = d.add_shot("s1", "x", 72 / FPS)
    d.run_shot(s, _ok_render, {"stride": 4})
    st = d.status()
    return st["budget_sec"] > 0 and s.render_sec > 0, \
        f"תקציב {st['budget_sec']}ש · שוט {s.render_sec:.1f}ש"


def t_render_crash_is_failed(tmp: Path) -> tuple[bool, str]:
    """רינדור שזורק חריגה לא מפיל את ההפקה — השוט מסומן ונשמר."""
    d = dr.Director(tmp / "pd")
    s = d.add_shot("s1", "x", 1.0)

    def boom(shot, out):
        raise ValueError("הדפדפן לא נפתח")

    d.run_shot(s, boom)
    return s.state == dr.FAILED and "הדפדפן" in s.note, s.note[:60]


TESTS = [
    ("מבנה תיקיות ההפקה נוצר", t_layout),
    ("מעבר מצב אסור נדחה", t_illegal_transition),
    ("תלות חוסמת שוט", t_deps_block),
    ("שוט נקי מגיע ל-DONE", t_clean_shot_done),
    ("שוט פגום מנותב לתיקון עם אשמה", t_bad_shot_repair),
    ("לופ תיקון: פגום -> נתפס -> תוקן -> עבר", t_repair_loop),
    ("תקרת נסיונות עוצרת שוט שלא נתקן", t_attempt_cap),
    ("הפקה שנקטעה ממשיכה מאותו מקום", t_persistence),
    ("גרסה טובה ביותר ונסיגה אחורה", t_best_version_and_rollback),
    ("הרכבה מסרבת להפקה חסרה", t_assemble_refuses_partial),
    ("הרכבה מלאה עוברת בקרת איכות", t_assemble_full),
    ("זמן רינדור נמדד לשוט ולהפקה", t_budget),
    ("רינדור שנפל מסומן ולא מפיל הכול", t_render_crash_is_failed),
]


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8")
    tmp = Path(tempfile.mkdtemp(prefix="dirtest_"))
    ok = 0
    for name, fn in TESTS:
        try:
            passed, detail = fn(tmp)
        except Exception as exc:                       # noqa: BLE001
            import traceback
            passed = False
            detail = f"{type(exc).__name__}: {exc} | " \
                     f"{traceback.format_exc().splitlines()[-3][:60]}"
        print(f"{'✓' if passed else '✗'} {name:<42} {detail}")
        ok += bool(passed)
    print(f"\n{ok}/{len(TESTS)} עברו")
    return 0 if ok == len(TESTS) else 1


if __name__ == "__main__":
    raise SystemExit(main())
