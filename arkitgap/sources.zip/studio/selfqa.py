# -*- coding: utf-8 -*-
"""TASK 11 — הפאנל על הפקה אמיתית: אבחון → תיקון → רינדור → הערכה.

**מה המודול הזה מוכיח, ולמה הוא לא עוד בדיקה.** `test_panel.py`
מוכיח שחמשת המבקרים מודדים נכון, עם שוט סינתטי שנבנה בזיכרון.
כאן אותם מבקרים שופטים **שוט שעובר דרך מנוע הרינדור האמיתי**:
אותו דפדפן, אותו שלד, אותה במה, אותו מקודד. ההרצה מתחילה משוט
*מקולקל בכוונה* — תאורת שפה חלשה, בלי דגימת-על, מצלמה צמודה
ומקרטעת, ותנועה שהיא אינטרפולציה ליניארית בין שתי פוזות — והלולאה
מאבחנת, מתקנת, מרנדרת שוב ומודדת שוב, עד שהשוט עובר את הרף או
שהיא עוצרת ואומרת למה.

**הפגם אינו מומצא.** ארבעת הקלקולים הם בדיוק מה שהיה כאן בפועל
בשלבים קודמים: `rim` הוא מצב התאורה שהפיל את הניגודיות, `ss=1`
הוא מה שגרם למנעולי השיער להבהב בין פריימים, מצלמה צמודה היא מה
שחתך את הראש בשפת הקאדר, ו-lerp בין שתי פוזות הוא בדיוק מה
שהאנימציה כאן הייתה לפני TASK 07.

הרצה::

    python -m studio.selfqa            # הלולאה המלאה, עם רינדור
    python -m studio.selfqa --dry      # בלי רינדור: רק משחק/אנימציה/סיפור
"""
from __future__ import annotations

import asyncio
import json
import sys
import time
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from studio import critics as C        # noqa: E402
from studio import evidence as EV      # noqa: E402
from studio import panel as P          # noqa: E402

OUT = Path(r"D:\claude-bot\out")
SECS = 5.0
FPS = 30
W, H = 1280, 720

#: המצב ההתחלתי — ארבעה פגמים, כל אחד בממד של מבקר אחר.
START_KNOBS = {
    "light": "rim",        # תאורת שפה: ניגודיות נמוכה  → איכות חזותית
    "ss": 1,               # בלי דגימת-על: ריצוד וחדות  → איכות חזותית
    "dist": 0.74,          # מצלמה צמודה: הראש נחתך     → צילום
    "jerky": True,         # מסלול מצלמה מקרטע          → צילום
    "linear": True,        # lerp בין שתי פוזות         → אנימציה
    "antic": False,        # בלי תנועת ציפייה           → אנימציה
}

#: ידית התיקון → מה היא משנה. זו הטבלה שהופכת אבחון לפעולה.
KNOB_FOR = {
    "relight":            ("light", "studio"),
    "fix_exposure":       ("light", "studio"),
    "raise_supersample":  ("ss", 2),
    "raise_bitdepth":     ("ss", 2),
    "stabilize_shading":  ("ss", 2),
    "reencode":           ("ss", 2),
    "pull_camera_back":   ("dist", 1.00),
    "adjust_shot_size":   ("dist", 1.00),
    "reframe_headroom":   ("dist", 1.06),
    "reframe_eyeline":    ("dist", 1.06),
    "separate_from_bg":   ("light", "studio"),
    "smooth_camera":      ("jerky", False),
    "keep_screen_direction": ("jerky", False),
    "apply_easing":       ("linear", False),
    "insert_hold":        ("linear", False),
    "smooth_curves":      ("linear", False),
    "offset_regions":     ("linear", False),
    "add_followthrough":  ("linear", False),
    "fix_discontinuity":  ("linear", False),
    "add_anticipation":   ("antic", True),
}


# ------------------------------------------------------------ השוט

ANTIC_K = 0.45        # עומק תנועת-הנגד, כשבריר מהתנועה שאחריה
ANTIC_LEAD = 0.30     # שניות ההקדמה


def anticipate(fn, k: float = ANTIC_K, lead: float = ANTIC_LEAD):
    """עוטף שחקן ומוסיף **תנועת ציפייה** לפני כל תנועה.

    הנוסחה היא ``y'(t) = (1+k)·y(t) - k·y(t+lead)``. לפני עלייה
    ``y(t+lead) > y(t)``, ולכן ``y'`` *צונח* מתחת לקו ההתחלה —
    זו בדיוק תנועת-הנגד. בקצוות, שבהם העקומה שטוחה, שני האיברים
    שווים והערך נשמר, כך שהמשרעת הסופית אינה משתנה.

    **זו לא קוסמטיקה.** מבקר האנימציה מדד על הסצנה האמיתית
    `anim.anticipation` = 0.139, כלומר שבעה אחוזי ערוצים בלבד
    פתחו בתנועת-נגד. הידית הזו נולדה מהאבחון הזה, וזו כל הכוונה
    של שלב 21: המבקר מצא פער אמיתי במערכת, לא בקובץ.

    צורות הפנים נחתכות ל-``[0,1]`` — ערך שלילי בצורה הוא פנים
    שבורות ולא ציפייה. העצמות סובלות את הצניחה, ובהן היא נראית.
    """
    def wrapped(u, t):
        a = fn(u, t)
        b = fn(min(1.0, u + lead / SECS), t + lead)
        out = []
        for i in range(3):
            da = dict(a[i]) if i < len(a) and a[i] else {}
            db = dict(b[i]) if i < len(b) and b[i] else {}
            if i == 1:                     # יעדי IK נשארים כמו שהם
                out.append(da)
                continue
            res = {}
            for key in set(da) | set(db):
                v0 = float(da.get(key, 0.0))
                v1 = float(db.get(key, v0))
                v = (1.0 + k) * v0 - k * v1
                res[key] = max(0.0, min(1.0, v)) if i == 2 else v
            out.append(res)
        return out[0], out[1], out[2]
    return wrapped


def _actor(linear: bool, antic: bool = False):
    """שחקנית הסצנה. ``linear=True`` הוא הקלקול: lerp בין שתי פוזות.

    ה"תקין" הוא **אותה פונקציה בדיוק** שמייצרת את הסרטון בייצור
    (`cinema.actor`), ולא עותק. הקלקול עוטף אותה ולא מחליף אותה,
    ולכן ההשוואה היא בין אותה הצגה עם איוש ובלעדיו.
    """
    from rig import cinema as CI
    fn = CI.actor("full", "b")
    if not linear:
        return anticipate(fn) if antic else fn
    a = fn(0.0, 0.0)
    b = fn(1.0, SECS)

    # ב-lerp בין שתי פוזות אין מה להקדים: אין תנועה שהציפייה
    # תקדים. הידית מתחילה לעבוד רק אחרי שהאיוש הוחזר.
    def lerp_actor(u, t):
        out = []
        for i in range(3):
            da = a[i] if i < len(a) else {}
            db = b[i] if i < len(b) else {}
            keys = set(da) | set(db)
            out.append({k: float(da.get(k, 0.0)) * (1 - u) +
                        float(db.get(k, 0.0)) * u for k in keys})
        return out[0], out[1], out[2]
    return lerp_actor


def _camera(knobs: dict, h: float):
    dist = float(knobs.get("dist", 1.0))
    jerky = bool(knobs.get("jerky"))

    def cam(u):
        yaw = 12.0 - 18.0 * (u * u * (3 - 2 * u))
        pitch = 1.4 - 2.2 * u
        if jerky:
            k = int(round(u * (SECS * FPS)))
            yaw += 5.0 * ((k % 3) - 1)
            pitch += 1.6 * ((k % 2) - 0.5)
        return {"yaw": yaw, "pitch": pitch, "dist": 0.92 * dist,
                "tx": 0.53, "ty": h * 0.93, "tz": 0.03, "fov": 30}
    return cam


def _shot(knobs: dict, h: float, round_n: int):
    from rig import showreel as SR
    fb = _actor(bool(knobs.get("linear")), bool(knobs.get("antic")))
    fa = None
    cap = (f"סבב {round_n} · תאורה {knobs.get('light')} · "
           f"דגימת-על {knobs.get('ss')} · "
           f"{'תנועה ליניארית' if knobs.get('linear') else 'תנועה מאוישת'}")
    return SR.Shot("panel_shot", SECS, cap,
                   "חמישה מבקרים עצמאיים שופטים את השוט הזה",
                   "אבחון → תיקון → רינדור מחדש → הערכה מחדש",
                   _camera(knobs, h), a=fb, b=fb,
                   vis={"A": False, "B": True},
                   light=str(knobs.get("light", "studio")))


# ------------------------------------------------------------ העדות

def _situation_and_arc():
    from rig import cinema as CI
    from rig import emotion as E
    sit = CI.situation_b() if hasattr(CI, "situation_b") else None
    if sit is None:
        from rig import cinema as _CI
        sit = _CI.beats()[-1][2] if hasattr(_CI, "beats") else None
    arc = E.arc(sit) if sit is not None else None
    return sit, arc


def build_evidence(knobs: dict, video: Path | None, h: float = 1.70,
                   round_n: int = 1) -> C.Evidence:
    from rig import cinema as CI
    sit, arc = _situation_and_arc()
    actor = _actor(bool(knobs.get("linear")), bool(knobs.get("antic")))
    tr = CI.take("full", "b", FPS) if not knobs.get("linear") else None
    events = None
    perf = None
    if tr is not None:
        try:
            events = CI.find_events(tr, CI.take("full", "a", FPS))
            perf = tr.score()
        except Exception:                              # noqa: BLE001
            events, perf = None, None
    ev = EV.collect("panel_shot", SECS, actor=actor,
                    cam=_camera(knobs, h), situation=sit, arc=arc, beats=4,
                    events=events, perf=perf, video=video, fps=FPS)
    return ev


# ------------------------------------------------------------ הרצה

def _render(knobs: dict, round_n: int, h_box: dict) -> Path:
    from rig import showreel as SR
    out = OUT / f"task11_panel_v{round_n}.mp4"
    shot = _shot(knobs, h_box["h"], round_n)
    rep = asyncio.run(SR.produce(
        out, task=1, title="אולפן האנימציה · TASK 11 · QA של עצמו",
        fps=FPS, width=W, height=H, ss=int(knobs.get("ss", 2)),
        shots_override=[shot]))
    print(f"    רונדר: {rep.get('seconds')}ש · {rep.get('size_mb')}MB",
          flush=True)
    return out


def main(argv: list[str]) -> int:
    sys.stdout.reconfigure(encoding="utf-8")
    dry = "--dry" in argv
    OUT.mkdir(parents=True, exist_ok=True)
    h_box = {"h": 1.70}
    try:
        rig = json.loads((ROOT / "rig" / "maya.json").read_text("utf-8")) \
            if (ROOT / "rig" / "maya.json").exists() else {}
        h_box["h"] = float(rig.get("height_m") or 1.70)
    except Exception:                                  # noqa: BLE001
        pass

    t0 = time.time()
    if dry:
        print("→ בלי רינדור: סיפור, משחק ואנימציה בלבד\n", flush=True)
        for label, knobs in (("מקולקל", START_KNOBS),
                             ("מתוקן", {**START_KNOBS, "linear": False,
                                        "light": "studio", "ss": 2,
                                        "dist": 1.0, "jerky": False})):
            ev = build_evidence(knobs, None, h_box["h"])
            pv = P.Panel().review(ev)
            print(f"— {label} —")
            print(pv.text())
            print(flush=True)
        return 0

    def render(knobs, n):
        print(f"  סבב {n}: ידיות {knobs}", flush=True)
        return _render(knobs, n, h_box)

    def evidence(video, n):
        return build_evidence(LOOP.knobs, Path(video), h_box["h"], n)

    def apply(knobs, repairs, pv):
        k = dict(knobs)
        for r in repairs:
            if r in KNOB_FOR:
                name, val = KNOB_FOR[r]
                k[name] = val
        return k

    def on_round(r):
        sc = " · ".join(f"{C.HE[n]} {r.scores[n]:.0f}" for n in C.NAMES)
        print(f"    {sc}\n    חלש: {C.HE[r.weakest]} ({r.worst:.1f}) "
              f"→ {', '.join(r.repairs) or '—'}", flush=True)

    LOOP = P.RefineLoop("panel_shot", render, evidence, apply,
                        knobs=dict(START_KNOBS), max_rounds=4,
                        on_round=on_round)
    res = LOOP.run()
    print()
    print(res.text())
    p = P.save(res, ROOT / "production")
    print(f"\nהדוח המלא: {p}")
    best = OUT / f"task11_panel_v{res.best_round}.mp4"
    print(f"הגרסה הנבחרת: {best}")
    print(f"סך הכול {time.time() - t0:.0f} שניות")
    return 0 if res.passed else 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
