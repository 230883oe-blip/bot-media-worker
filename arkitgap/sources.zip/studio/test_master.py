"""בדיקות מבחן האמן הסופי (STAGE 12).

הכיוון החשוב כאן הוא **השני**: לא רק "הסצנה האמיתית עוברת", אלא
שכל גרסת ביקורת **נופלת בדיוק במבחן שמגן עליה**. בלי זה שבע
ההכרעות של מבחן ההשתקה מודדות את עצמן.

`python -m studio.test_master`
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

# הרצה ישירה (`python studio/test_master.py`) שמה ב-sys.path את
# `studio/` ולא את שורש הפרויקט, ולכן `rig` לא נמצא והחבילה כולה
# נפלה ב-ModuleNotFoundError לפני הבדיקה הראשונה. חבילה שלא רצה
# גרועה מחבילה שאין: היא מרגיעה. שאר החבילות כאן עושות את זה.
ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from rig import cinema as CI
from rig import duet as D
from studio import master as MA

_ok = 0
_bad: list[str] = []


def ok(cond, label: str, extra: str = "") -> None:
    global _ok
    if cond:
        _ok += 1
        print(f"  ✓ {label:<52} {extra}")
    else:
        _bad.append(label)
        print(f"  ✗ {label:<52} {extra}")


# ------------------------------------------------- מטמון למבחנים כבדים
_MUTE: dict[str, MA.TestResult] = {}
_AUDIO: dict[str, MA.TestResult] = {}


def mute(variant: str) -> MA.TestResult:
    if variant not in _MUTE:
        _MUTE[variant] = MA.mute_test(variant)
    return _MUTE[variant]


def audio(variant: str) -> MA.TestResult:
    if variant not in _AUDIO:
        _AUDIO[variant] = MA.audio_test(variant)
    return _AUDIO[variant]


# ---------------------------------------------------------- הסצנה

def t_scene() -> None:
    print("הסצנה:")
    ok(10.0 <= MA.SCENE_LEN <= 15.0, "אורך הסצנה בטווח שהמשימה דורשת",
       f"{MA.SCENE_LEN:.0f}ש")
    lanes = mute("full").detail  # רק כדי לוודא שהמבחן רץ
    ok(bool(lanes), "המבחן מחזיר פירוט")
    ln = MA.mute_lanes("full")
    ok(set(ln) == {"A", "B"}, "שתי דמויות על אותו ציר זמן", str(sorted(ln)))
    n = int(round(MA.SCENE_LEN * MA.FPS)) + 1
    ok(len(ln["A"].times) == n and len(ln["B"].times) == n,
       "שתיהן נדגמות באותו מספר פריימים", f"{n}")
    ok(MA.TRUTH["thinking"] != MA.TRUTH["uneasy"],
       "החושב והלא-נוח אינם אותה דמות")


def t_truth_balanced() -> None:
    print("האמת מאוזנת:")
    vals = list(MA.TRUTH.values())
    for who in ("lucas", "maya"):
        c = vals.count(who)
        ok(c >= 2, f"ל-{who} לפחות שתי הכרעות", f"{c}/{len(vals)}")
    # **מודד שעונה תמיד אותו שם חייב להיכשל.** בלי זה 'מי מופתע'
    # ו'מי לא נוח' היו נענים נכון בלי למדוד כלום.
    for who in ("lucas", "maya"):
        hits = sum(1 for v in vals if v == who)
        ok(hits < len(vals), f"ניחוש קבוע '{who}' אינו עובר",
           f"{hits}/{len(vals)}")


# ----------------------------------------------- ניתוק השמע בקוד

def t_audio_separation() -> None:
    print("ניתוק השמע:")
    ln = MA.mute_lanes("full")
    bad = ln["A"].audio_keys + ln["B"].audio_keys
    ok(bad == 0, "אפס ערוצי שמע נשארו במסלול החזותי", f"{bad}")
    # ההסרה לפי תחילית — ערוץ פה שייווסף מחר ייתפס גם הוא.
    ok(CI.is_audio_driven("mouth_brand_new"),
       "ערוץ פה חדש שאיש לא הכיר נתפס לפי תחילית")
    ok(not CI.is_audio_driven("brow_furrow_L"),
       "וערוץ מצח אינו נחשב שמע")
    keys = ln["A"].keys
    ok(not any(k.startswith(("jaw_", "mouth_", "lip_")) for k in keys),
       "אין במסלול שום ערוץ לסת/פה/שפה")


def t_union_keys() -> None:
    print("איחוד מפתחות המסלול:")
    ln = MA.mute_lanes("full")
    v = ln["A"].ch("brow_furrow_L", "brow_furrow_R")
    # הבאג: `keys` נלקחו מהפריים הראשון, ו-AU4 חסר שם כי ערכו אפס.
    # התוצאה הייתה ערוץ שדומם לאורך כל הסצנה, בלי שום שגיאה.
    ok(float(np.max(np.abs(v))) > 0.05,
       "AU4 (מצח) אינו דומם לאורך הסצנה", f"max={float(v.max()):.3f}")
    frames_keys = set(ln["A"].keys)
    ok("brow_furrow_L" in frames_keys, "והוא נמצא ברשימת הערוצים")


def t_add_missing() -> None:
    print("הוספה לערוץ חסר:")
    d: dict = {}
    MA._add(d, "brow_furrow_L", 0.3)
    ok(d.get("brow_furrow_L") == 0.3, "מפתח חסר נוצר עם הערך", str(d))
    MA._add(d, "brow_furrow_L", 0.9)
    ok(d["brow_furrow_L"] == 1.0, "והוא נחתך ב-1.0", str(d["brow_furrow_L"]))
    MA._add(d, "x", -5.0)
    ok(d["x"] == -1.0, "וב--1.0 מלמטה")


def t_smooth_edges() -> None:
    print("החלקה בקצוות:")
    x = np.ones(60) * 0.8
    y = MA._smooth(x, 1.0 / 30.0, 0.40)
    ok(abs(float(y[-1]) - 0.8) < 1e-6,
       "קצה העקומה אינו מורעב לאפס", f"{float(y[-1]):.4f}")
    ok(abs(float(y[0]) - 0.8) < 1e-6, "וגם הקצה הראשון")
    ok(len(y) == len(x), "ואורך העקומה נשמר")


# ------------------------------------------------- מבחן ההשתקה

def t_mute_full() -> None:
    print("מבחן ההשתקה — הסצנה האמיתית:")
    r = mute("full")
    for q, row in r.detail["answers"].items():
        ok(row["ok"], MA.QUESTIONS[q],
           f"נקרא {row['read']} (צפוי {row['expected']})")
    ok(r.passed, "המבחן כולו עבר", f"{r.score:.0f}")


def t_quiet_found() -> None:
    print("חלון המחשבה נמצא ולא התקבל:")
    lanes = MA.mute_lanes("full")
    q = MA.find_quiet(lanes)
    ok(q is not None, "נמצא חלון שתיקה חזותית", str(q))
    if q:
        t0, t1 = q
        ok(t1 - t0 >= MA.QUIET_MIN, "והוא ארוך מהמינימום",
           f"{t1 - t0:.2f}ש")
        # הדרישה המהותית היא **חפיפה** עם הביט השלישי: החלון
        # נמצא מתוך היזימה ולא מתוך התסריט, ולכן גבולותיו אינם
        # חייבים להיות גבולות הביט.
        a0, a1 = MA.THINK_WIN
        cover = max(0.0, min(t1, a1) - max(t0, a0))
        ok(cover >= 0.8 * (a1 - a0),
           "והוא מכסה את הביט השלישי",
           f"[{t0:.2f},{t1:.2f}] מכסה {cover:.2f} מתוך {a1 - a0:.2f}")


def t_mute_controls() -> None:
    print("גרסאות הביקורת של ההשתקה — כל אחת חייבת ליפול:")
    for variant, why in (("swap", "הזהויות הוחלפו"),
                         ("flat", "בלי משחק פנים"),
                         ("frozen", "בובה מוקפאת")):
        r = mute(variant)
        ok(not r.passed, f"{variant}: {why}", f"{r.score:.0f}/100")
    # ו-swap חייב להתהפך, לא רק ליפול: אם רק *אחת* מההכרעות
    # מתהפכת, המודד למעשה מתעלם מהמסלולים.
    r = mute("swap")
    flipped = sum(1 for row in r.detail["answers"].values()
                  if row["read"] in ("lucas", "maya")
                  and row["read"] != row["expected"])
    ok(flipped >= 6, "swap הפך לפחות שש מתוך שבע ההכרעות",
       f"{flipped}/7")
    # ובמוקפאת ההכרעות שגויות ולא "נכונות במקרה".
    fz = mute("frozen")
    wrong = sum(1 for row in fz.detail["answers"].values()
                if not row["ok"])
    ok(wrong >= 3, "ובמוקפאת לפחות שלוש הכרעות שגויות", f"{wrong}/7")


def t_pick_noise() -> None:
    """**הרצפה המוחלטת ב-`_pick`.**

    זה הבאג שגרסת הבובה המוקפאת חשפה: מרווח *יחסי* על שני ערכים
    זעירים מתפוצץ, ולכן 1e-9 מול 2e-9 הוחזר כהכרעה בביטחון 0.5 —
    "מי לא נוח" נענה חד-משמעית על רעש חישובי.
    """
    print("הכרעה על רעש:")
    who, m = MA._pick(1e-9, 2e-9, floor=0.02)
    ok(who == "" and m == 0.0, "שני ערכי רעש אינם מוכרעים",
       f"{who!r} {m}")
    who, m = MA._pick(0.0, 0.0, floor=0.02)
    ok(who == "", "ושני אפסים גם לא")
    # והכיוון השני — הכרעה אמיתית אינה נחסמת על ידי הרצפה.
    who, m = MA._pick(0.30, 0.10, floor=0.02)
    ok(who == "A" and m > MA.MARGIN, "והכרעה אמיתית עוברת",
       f"{who} {m:.2f}")
    who, _m = MA._pick(0.300, 0.299, floor=0.02)
    ok(who == "", "ופער זניח בין ערכים גדולים גם אינו מוכרע")


# --------------------------------------------------- מבחן השמע

def t_audio_full() -> None:
    print("מבחן השמע בלבד:")
    r = audio("full")
    for code, c in r.detail["checks"].items():
        ok(c["ok"], c["label"], f"{c['value']} ({c['limit']})")
    ok(r.passed, "מבחן השמע עבר", f"{r.score:.0f}")


def t_audible_overlap() -> None:
    print("החפיפה נשמעת ולא רק מוצהרת:")
    lo, hi = MA.audible_span("lucas")
    ok(hi > lo, "נמדד חלון הקול הנשמע בהקלטה", f"{lo:.2f}-{hi:.2f}")
    ok(hi < D.L_DUR - 0.2,
       "וההקלטה אכן מכילה זנב שקט ארוך — זה הבאג שנסגר",
       f"קול עד {hi:.2f} מתוך קובץ {D.L_DUR:.2f}")
    w = MA.speech_windows()
    ov_declared = w["lucas"][1] - w["maya"][0]
    ok(ov_declared >= MA.OVERLAP_MIN, "החפיפה המוצהרת מעל המינימום",
       f"{ov_declared:.2f}ש")
    r = audio("full")
    ov = r.detail["checks"]["overlap"]["value"]
    ok(ov >= MA.OVERLAP_MIN, "והחפיפה **הנשמעת** מעל המינימום",
       f"{ov:.2f}ש")
    ok(r.detail["cutter"] == "maya", "והחותכת היא מי שהתסריט אומר")


def t_audio_controls() -> None:
    print("גרסאות הביקורת של השמע:")
    r = audio("monotone")
    ok(not r.passed, "monotone: קריאה בלי פרוזודיה נופלת",
       f"{r.score:.0f}/100")
    bad = [c for c in r.detail["checks"].values()
           if not c["ok"] and "פרוזודיה" in c["label"]]
    ok(len(bad) >= 2, "והיא נופלת דווקא במדד הפרוזודיה",
       f"{len(bad)} דוברים")
    r = audio("sequential")
    ok(not r.passed, "sequential: בלי חפיפה נופלת", f"{r.score:.0f}/100")
    ok(not r.detail["checks"]["overlap"]["ok"],
       "והיא נופלת דווקא במדד החפיפה",
       f"{r.detail['checks']['overlap']['value']}ש")


def t_threshold_match() -> None:
    print("ספי השמיעה:")
    ok(MA.ACTIVE_TH == MA.AUDIBLE_TH,
       "סף התכנון וסף המדידה זהים", f"{MA.ACTIVE_TH}")


# ------------------------------------------- התזמון חוזר למקומו

def t_timing_restored() -> None:
    print("הזרקת התזמון ל-duet:")
    before = (dict(D.WINDOWS), D.CUT_IN, D.OVERLAP)
    with MA.scene_timing() as win:
        ok(D.WINDOWS["maya"][0] == win["maya"][0],
           "בתוך ההקשר duet עובד עם החלונות של המבחן",
           f"{D.CUT_IN:.2f}")
        ok(D.CUT_IN != before[1], "והחיתוך זז לרגע שבו הקול נשמע")
        ok(CI.SETTLE_T == win["lucas"][1],
           "וגלאי האירועים כוּיל לאותו תזמון", f"{CI.SETTLE_T:.2f}")
    ok(D.WINDOWS == before[0] and D.CUT_IN == before[1]
       and D.OVERLAP == before[2], "ואחרי ההקשר הכול חזר למקומו")
    # וגם כשנזרקה חריגה — אחרת סצנה אחת מרעילה את כל השאר.
    try:
        with MA.scene_timing():
            raise RuntimeError("בכוונה")
    except RuntimeError:
        pass
    ok(D.WINDOWS == before[0] and D.CUT_IN == before[1],
       "וגם אחרי חריגה בתוך ההקשר")


# ------------------------------------------- המבחן הקולנועי המלא

def t_full() -> None:
    print("המבחן הקולנועי המלא:")
    ok(abs(sum(MA.WEIGHTS.values()) - 1.0) < 1e-9,
       "המשקולות מסתכמות ל-1", str(MA.WEIGHTS))
    ok("render" not in MA.WEIGHTS and "seconds" not in MA.WEIGHTS,
       "ו'הרינדור הסתיים' אינו אחד מהן — זו דרישת השלב")
    m = MA.run("full")
    exp = (MA.WEIGHTS["mute"] * m.mute.score
           + MA.WEIGHTS["audio"] * m.audio.score
           + MA.WEIGHTS["panel"] * m.panel.score)
    ok(abs(m.full - exp) < 1e-6, "הציון הוא בדיוק השקלול",
       f"{m.full:.1f}")
    ok(m.full >= MA.FULL_PASS, "והוא מעל סף המעבר",
       f"{m.full:.1f} ≥ {MA.FULL_PASS:.0f}")
    ok(m.panel.detail["critics"] == list(MA.DRY_CRITICS),
       "בלי סרטון מורצים רק המבקרים שאינם דורשים סרטון",
       str(m.panel.detail["critics"]))
    # שקיפות: סצנה שלא עברה את הפאנל **אינה** מוכרזת כהצלחה.
    ok(m.passed == bool(m.mute.passed and m.audio.passed
                        and m.panel.passed and m.full >= MA.FULL_PASS),
       "הכרזת ההצלחה דורשת את שלושת המבחנים ולא רק את הציון",
       f"passed={m.passed}")
    for who, p in m.panel.detail["per_character"].items():
        ok(p["scores"].get("story", 0) >= 70.0,
           f"מבקר הסיפור עובר אצל {who}", str(p["scores"].get("story")))
    d = m.to_dict()
    ok(len(d["tests"]) == 3 and all("score" in t for t in d["tests"]),
       "הדוח מכיל את שלושת המבחנים")
    p = MA.save(m)
    ok(p.exists() and p.stat().st_size > 200, "והוא נשמר לקובץ", p.name)


def t_evidence_is_this_scene() -> None:
    print("הראיות הן של הסצנה הזו:")
    with MA.scene_timing():
        tr = MA._track("lucas", "full", MA.FPS)
        ok(abs(float(tr.times[-1]) - MA.SCENE_LEN) < 1e-6,
           "המסלול שנמסר למבקרים הוא באורך הסצנה",
           f"{float(tr.times[-1]):.1f}ש")
        ok(tr.name == "lucas", "ובשם הדמות הנכונה")
        ev = MA._evidence("lucas", "full", MA.FPS, None)
        ok(abs(float(ev.seconds) - MA.SCENE_LEN) < 1e-6,
           "וגם העדות")
        plan = ev.plan or {}
        for f in ("knows", "wants", "feels", "hides"):
            ok(bool(str(plan.get(f) or "").strip()),
               f"שדה המצב '{f}' מולא")
        arc = plan.get("arc") or {}
        ok(float(arc.get("turn") or 0.0) > 0.0,
           "והמהפך הגיע כמספר ולא כאפס", str(arc.get("turn")))
        ok(abs(float(arc.get("dvalence") or 0.0)) >= 0.30,
           "וגם עוצמת השינוי הרגשי", str(arc.get("dvalence")))


TESTS = (t_scene, t_truth_balanced, t_audio_separation, t_union_keys,
         t_pick_noise,
         t_add_missing, t_smooth_edges, t_mute_full, t_quiet_found,
         t_mute_controls, t_audio_full, t_audible_overlap,
         t_audio_controls, t_threshold_match, t_timing_restored,
         t_evidence_is_this_scene, t_full)


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8")
    for fn in TESTS:
        fn()
    total = _ok + len(_bad)
    print(f"\n{_ok}/{total} עברו")
    for b in _bad:
        print(f"  נכשל: {b}")
    return 0 if not _bad else 1


if __name__ == "__main__":
    raise SystemExit(main())
