# -*- coding: utf-8 -*-
"""איסוף העדות לשוט אמיתי — מהסצנה עצמה ומהפריימים המרונדרים.

**למה זה מודול נפרד.** המבקרים ב-`critics.py` מקבלים מערכי numpy
ולא יודעים דבר על הריג, על השוטים או על הדפדפן, וזה מה שמאפשר
להריץ את כל חבילת הבדיקות שלהם בשניות. המודול הזה הוא הגשר: הוא
יודע לשלוף מסלול פוזות מפונקציית סצנה, מסלול מצלמה ממנה, תוכנית
סיפור מאובייקט `emotion.Situation`, ותיבת דמות מתוך פריימים.

**שתי החלטות.**

1. **מסלול הפוזות נדגם מאותה פונקציה שמרנדרת את הסרטון**
   (``shot.a`` / ``shot.b``), ולא משכבה מקבילה. מבחן שבונה לעצמו
   נתונים בדרך אחרת בודק קוד שאיש אינו מריץ — זה בדיוק הלקח של
   `cinema.take` מאתמול. היתרון הנוסף: אפשר לשפוט משחק ואנימציה
   **בלי לרנדר בכלל**, כלומר בשנייה אחת במקום בדקות.

2. **תיבת הדמות נגזרת מהפריימים ולא מהגאומטריה.** הרקע של הבמה
   הוא גרדיאנט חלק, והדמות היא האובייקט היחיד עם *פרטים* — ולכן
   מסכת האנרגיה של הלפלסיאן מפרידה אותה נקי, בלי לדעת כלום על
   הדגם, על ה-fov או על יחס הצדדים. מדידה גאומטרית הייתה מחייבת
   לשחזר את מטריצת ההקרנה של הבמה, ושחזור כזה שונה בשקט מהאמת
   ברגע שמישהו נוגע ב-`stage.html`.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Callable, Optional

import numpy as np

from studio import critics as C

ROOT = Path(__file__).resolve().parent.parent


# ------------------------------------------------------------ מסלול פוזות

def track_from_fn(fn: Callable, secs: float, fps: int = 30) -> dict:
    """דוגם פונקציית סצנה ``(u, t) -> (ctl, ik[, mph])`` למטריצה.

    הבקרות וצורות הפנים מאוחדות לאותו מרחב ערוצים: חצי מטבלת
    ה-FACS יושבת בצורות ולא בעצמות, ומדידה שלוקחת רק ``ctl``
    מודדת שליש מהפנים ומחזירה ציון שנראה סביר. זו בדיוק המלכודת
    שנפלה כאן ב-`cinema.take`.
    """
    n = max(2, int(round(secs * fps)) + 1)
    ts = np.linspace(0.0, secs, n)
    frames: list[dict] = []
    for i, t in enumerate(ts):
        u = i / max(1, n - 1)
        r = fn(float(u), float(t))
        ctl = dict(r[0] or {})
        if len(r) > 2 and r[2]:
            ctl.update(r[2])
        frames.append(ctl)
    keys = sorted({k for f in frames for k in f})
    M = np.array([[float(f.get(k, 0.0)) for k in keys] for f in frames],
                 dtype=np.float64)
    return {"times": ts, "keys": keys, "M": M}


def camera_from_fn(cam: Callable[[float], dict], secs: float,
                   fps: int = 30) -> list[dict]:
    n = max(2, int(round(secs * fps)) + 1)
    return [dict(cam(i / (n - 1))) for i in range(n)]


# ------------------------------------------------------------ תוכנית סיפור

def _emotion_of(obj):
    """שולף את אובייקט הרגש מתוך ``Plan``, ``Emotion`` או שם רגש."""
    if obj is None:
        return None
    if hasattr(obj, "valence") and hasattr(obj, "arousal"):
        return obj
    inner = getattr(obj, "emotion", None)
    if inner is not None:
        if hasattr(inner, "valence"):
            return inner
        try:
            from rig import emotion as E
            return E.EMOTIONS.get(str(inner))
        except Exception:                              # noqa: BLE001
            return None
    return None


def plan_from_situation(sit: Any, secs: float, arc: Any = None,
                        beats: int = 0) -> dict:
    """``emotion.Situation`` → מילון התוכנית שמבקר הסיפור קורא."""
    def g(*names):
        for nm in names:
            v = getattr(sit, nm, None)
            if v:
                return v if isinstance(v, str) else str(v)
        return ""

    out = {
        "knows": g("knows", "knowledge"),
        "wants": g("wants", "want", "goal"),
        "feels": g("feels", "feel", "emotion"),
        "hides": g("hides", "hide", "hiding"),
        "looking_at": g("looking_at", "looks_at", "target", "partner"),
        "intention": g("intention", "intent"),
        "seconds": secs,
        "beats": beats or 2,
    }
    if arc is not None:
        out["arc"] = {
            "turn": float(getattr(arc, "turn", 0.0) or 0.0),
            "dvalence": float(getattr(arc, "dvalence", 0.0) or 0.0),
            "darousal": float(getattr(arc, "darousal", 0.0) or 0.0),
        }
        if not out["arc"]["dvalence"] and not out["arc"]["darousal"]:
            # **`emotion.Arc` לא מחזיק דלתות — הוא מחזיק שתי תוכניות.**
            # ערכי ה-valence/arousal יושבים שכבה פנימה, ב-`Plan.emotion`.
            # בלי החפירה הזו המדד `story.change` החזיר 0.0 על סצנה שיש
            # בה שינוי רגשי אמיתי, כלומר כשל שנולד במתאם ולא בסצנה.
            fr = _emotion_of(getattr(arc, "before", None))
            to = _emotion_of(getattr(arc, "after", None))
            if fr is not None and to is not None:
                for nm, key in (("valence", "dvalence"),
                                ("arousal", "darousal")):
                    out["arc"][key] = float(getattr(to, nm, 0.0) -
                                            getattr(fr, nm, 0.0))
            if not out["arc"]["turn"]:
                out["arc"]["turn"] = float(getattr(arc, "turn", 0.0) or 0.0)
    return out


# ------------------------------------------------------------ פיקסלים

def subject_bbox(gray: np.ndarray, pct: float = 2.0) -> np.ndarray:
    """תיבת הדמות לכל פריים, ביחידות 0..1, ממסכת פרטים.

    הרקע הוא גרדיאנט חלק ולכן הלפלסיאן שלו אפסי; הדמות היא
    האובייקט היחיד עם קצוות. האחוזון (ברירת מחדל 2%) מונע ממפרץ
    רעש בודד למתוח את התיבה על כל הקאדר.
    """
    nf, h, w = gray.shape
    lap = np.abs(gray[:, 1:-1, 2:] + gray[:, 1:-1, :-2] + gray[:, 2:, 1:-1]
                 + gray[:, :-2, 1:-1] - 4.0 * gray[:, 1:-1, 1:-1])
    out = np.zeros((nf, 4), dtype=np.float64)
    for i in range(nf):
        m = lap[i]
        thr = max(float(np.percentile(m, 97)) * 0.30, 0.012)
        rows = np.nonzero((m > thr).sum(axis=1) > 0)[0]
        cols = np.nonzero((m > thr).sum(axis=0) > 0)[0]
        if rows.size < 2 or cols.size < 2:
            out[i] = (0.0, 0.0, 1.0, 1.0)
            continue
        y0 = float(np.percentile(rows, pct)) + 1.0
        y1 = float(np.percentile(rows, 100 - pct)) + 1.0
        x0 = float(np.percentile(cols, pct)) + 1.0
        x1 = float(np.percentile(cols, 100 - pct)) + 1.0
        out[i] = (x0 / w, y0 / h, x1 / w, y1 / h)
    return out


def color_sample(path: Path, stride: int = 12, down_w: int = 48,
                 max_frames: int = 40) -> Optional[np.ndarray]:
    """דגימת RGB זעירה לבדיקת הרמוניית הצבע. נכשלת ברכות."""
    try:
        import av
        from PIL import Image
    except Exception:                                  # noqa: BLE001
        return None
    out: list[np.ndarray] = []
    try:
        with av.open(str(path)) as cont:
            vs = cont.streams.video[0]
            for i, fr in enumerate(cont.decode(vs)):
                if i % stride or len(out) >= max_frames:
                    continue
                img = fr.to_image()
                hh = max(1, int(round(img.height * down_w / img.width)))
                out.append(np.asarray(img.resize((down_w, hh), Image.BILINEAR),
                                      dtype=np.float32) / 255.0)
    except Exception:                                  # noqa: BLE001
        return None
    return np.stack(out) if out else None


# ------------------------------------------------------------ איסוף

def collect(shot_id: str, seconds: float, *, actor=None, cam=None,
            situation=None, arc=None, beats: int = 0, events=None,
            perf=None, video: Path | None = None, fps: int = 30,
            stride: int = 3) -> C.Evidence:
    """בונה `Evidence` מלא לשוט אחד.

    כל מקור שאפשר להשיג בלי רינדור מושג בלי רינדור. ``video``
    הוא היחיד שדורש קובץ, והוא זה שמאכיל את מבקר האיכות החזותית
    ואת הפרדת העומק של מבקר הצילום.
    """
    ev = C.Evidence(shot_id=shot_id, seconds=float(seconds))
    if actor is not None:
        ev.track = track_from_fn(actor, seconds, fps)
    if cam is not None:
        ev.camera = camera_from_fn(cam, seconds, fps)
    if situation is not None:
        ev.plan = plan_from_situation(situation, seconds, arc, beats)
    if events:
        ev.events = events
    if perf is not None:
        ev.perf = np.asarray(perf, dtype=np.float64)
    if video is not None and Path(video).exists():
        from studio import qa
        s = qa.sample_video(Path(video), stride=stride)
        if s.n:
            ev.sample = s
            ev.subject = subject_bbox(np.asarray(s.gray))
        ev.color = color_sample(Path(video))
    return ev
