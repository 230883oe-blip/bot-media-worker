# -*- coding: utf-8 -*-
"""כוונון מתמיד — הפרמטרים שמנוע התיקון האוטונומי מורשה לשנות.

**למה זה קובץ ולא משתנה בזיכרון.** תיקון אוטונומי שחי בזיכרון התהליך
נמחק ברגע שההרצה נגמרת, כלומר המדידה הבאה מודדת בדיוק את המצב שלפני
התיקון — והלולאה מדווחת "שיפרתי" על מערכת שלא השתנתה. זה אותו כשל
שתועד בפרויקט הזה על מתג ההגשה ועל סימון המכסה: **מצב שלא ירד לדיסק
אינו מצב.**

**למה רשימה סגורה ולא "שנה מה שצריך".** מנוע שמורשה לגעת בכל פרמטר
הוא מנוע בלי בלם, ובמערכת שבה הוא גם מודד את עצמו זו דרך בטוחה
לכיול הציון במקום לשיפור האיכות. כאן כל פרמטר מוצהר עם תחום, עם
צעד, ועם הממד שהוא אמור לשרת — ובקשה לפרמטר שאינו ברשימה **נדחית**,
לא מתעלמים ממנה בשקט.

**ומה אסור לכוונן, נקודה:** שום פרמטר של *מודד*. סף, רף, משקל ורצפה
אינם ברשימה הזו ולא ייכנסו אליה. מנוע שמוריד סף במקום להעלות איכות
"עובר" את השער בלי לשנות דבר, וזו בדיוק ההתחזות שהמשימה אוסרת.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Optional

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent

#: קובץ הכוונון. בתוך הפרויקט, כדי שייכנס למאגר הגרסאות ושיהיה
#: אפשר לראות ב-``git diff`` בדיוק מה המנוע שינה ומתי.
STATE = ROOT / "production" / "tuning.json"


@dataclass(frozen=True)
class Knob:
    """פרמטר אחד שמותר לכוונן."""

    key: str
    label: str
    default: float
    lo: float
    hi: float
    step: float
    dim: str                 #: איזה ממד איכות הוא אמור לשרת
    why: str
    #: האם הפרמטר **מחובר בפועל** למנוע שמייצר את התנועה.
    #:
    #: פרמטר מוצהר שאינו מחובר הוא המלכודת הגרועה ביותר שיכולה
    #: להיות כאן: המנוע "מתקן", הערך משתנה בקובץ, המדידה חוזרת
    #: בדיוק אותו דבר — והלולאה מסיקה "קיפאון באיכות" במקום
    #: "הפרמטר הזה לא מחובר לכלום". אבחון שגוי גרוע מהיעדר אבחון.
    #: לכן ``wired=False`` נדחה ב-``nudge`` עם הסבר מפורש.
    wired: bool = True

    def clamp(self, v: float) -> float:
        return float(max(self.lo, min(self.hi, v)))


#: רשימת הפרמטרים הסגורה.
KNOBS: tuple[Knob, ...] = (
    Knob("smooth_win", "חלון החלקה זמנית", 0.0, 0.0, 0.20, 0.04,
         "animation",
         "מחליק את עקומת התנועה עצמה. יורד ישירות על anim.jitter "
         "ועל anim.pops, שהן אי-רציפות בפריים בודד ורעידה בתוך "
         "התנועה. ההחלקה היא על **התנועה** ולא על המדידה שלה — "
         "פילטר על האות הנמדד היה מסתיר את הבעיה במקום לתקן.",
         wired=True),
    Knob("anticipate", "עומק תנועת-הנגד", 0.0, 0.0, 0.45, 0.12,
         "animation",
         "תנועת-נגד קצרה לפני כל מחווה. זה מה ש-anim.anticipation "
         "מודד. **אינו מחובר עדיין** למנוע התנועה של סצנת המבחן: "
         "ההכנה שם נולדת ב-rig/principles.py ברמת המחווה הבודדת, "
         "ואין לה נקודת שליטה אחת בפלט השחקן. דורש חיבור ידני "
         "לפני שמנוע התיקון יוכל להזיז אותו.",
         wired=False),
)

KNOB_BY_KEY: dict[str, Knob] = {k.key: k for k in KNOBS}


def _read() -> dict:
    """קורא את הכוונון. קובץ חסר אינו קובץ שבור.

    שני המצבים נבדלים בכוונה: היעדר קובץ הוא המצב התקין של הרצה
    ראשונה ומחזיר ברירות מחדל; קובץ שאינו נפרס הוא אבדן מצב, והוא
    מוסג הצידה כדי שהערך הבא לא ייכתב עליו. טיפול זהה בשניהם היה
    מוחק בשקט כל כוונון שהצטבר.
    """
    if not STATE.exists():
        return {}
    try:
        d = json.loads(STATE.read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        try:
            STATE.rename(STATE.with_suffix(
                f".corrupt-{datetime.now():%Y%m%d%H%M%S}"))
        except OSError:
            pass
        return {}


def _write(d: dict) -> bool:
    """כתיבה אטומית. כשלון מחזיר ``False`` ו**אינו** נופל לכתיבה
    ישירה: לאבד עדכון אחד הוא נזק של עדכון אחד, להשחית את הקובץ
    הוא אבדן כל ההיסטוריה."""
    try:
        STATE.parent.mkdir(parents=True, exist_ok=True)
        tmp = STATE.with_suffix(".tmp")
        blob = json.dumps(d, ensure_ascii=False, indent=1)
        json.loads(blob)                       # מאומת לפני שנוגעים ביעד
        tmp.write_text(blob, encoding="utf-8")
        tmp.replace(STATE)
        return True
    except (OSError, ValueError):
        return False


def get(key: str) -> float:
    """הערך בתוקף. פרמטר לא מוכר זורק — שגיאת כתיב בשם פרמטר היא
    בדיוק סוג הבאג שמחזיר ברירת מחדל ונעלם בשקט."""
    kn = KNOB_BY_KEY.get(key)
    if kn is None:
        raise KeyError(f"פרמטר כוונון לא מוכר: {key}")
    v = _read().get(key)
    try:
        return kn.clamp(float(v))
    except (TypeError, ValueError):
        return kn.default


def all_values() -> dict[str, float]:
    return {k.key: get(k.key) for k in KNOBS}


def nudge(key: str, steps: int = 1) -> dict:
    """מזיז פרמטר בצעד אחד (או כמה), ושומר.

    מחזיר ``{"ok", "key", "before", "after", "at_limit", "why"}``.
    ``at_limit=True`` פירושו שהפרמטר כבר בקצה התחום — וזו תשובה
    אמיתית וחשובה: הלולאה צריכה לדעת שאין מה להזיז יותר, אחרת
    היא תמדוד מחדש בדיוק את אותו מצב עד שייגמרו הסבבים.
    """
    kn = KNOB_BY_KEY.get(key)
    if kn is None:
        return {"ok": False, "key": key, "why": "פרמטר לא מוכר"}
    if not kn.wired:
        return {"ok": False, "key": key, "unwired": True,
                "before": get(key),
                "why": f"{kn.label} אינו מחובר למנוע התנועה — "
                       f"שינוי שלו לא ישנה את המדידה. {kn.why}"}
    before = get(key)
    after = kn.clamp(round(before + kn.step * int(steps), 6))
    if abs(after - before) < 1e-9:
        return {"ok": False, "key": key, "before": before, "after": after,
                "at_limit": True, "why": f"{kn.label} בקצה התחום "
                                         f"({kn.lo}..{kn.hi})"}
    d = _read()
    d[key] = after
    d.setdefault("_log", []).append(
        {"key": key, "from": before, "to": after,
         "at": datetime.now().isoformat(timespec="seconds")})
    d["_log"] = d["_log"][-200:]
    if not _write(d):
        return {"ok": False, "key": key, "before": before,
                "why": "הכוונון לא נשמר לדיסק"}
    return {"ok": True, "key": key, "before": before, "after": after,
            "at_limit": abs(after - kn.hi) < 1e-9, "why": kn.why}


def reset(key: Optional[str] = None) -> bool:
    """מחזיר פרמטר (או הכול) לברירת המחדל. זו הנסיגה של הכוונון."""
    d = _read()
    if key is None:
        d = {k: v for k, v in d.items() if k.startswith("_")}
    else:
        d.pop(key, None)
    return _write(d)


def apply(values: dict, why: str = "") -> bool:
    """קובע ערכים מהרשימה הסגורה בבת אחת, ומתעד את השינוי.

    **זה מה שמאפשר "להשאיר את המערכת במצב הטוב ביותר שנמדד".**
    ``nudge`` זז צעד אחד לכיוון אחד, ולכן לולאת תיקון שמצאה
    שהצעד השלישי החמיר לא הייתה יכולה לחזור אל השני — היא הייתה
    נשארת על המצב האחרון. נמדד כאן ב-``master``: הרעידה ירדה
    ל-0.359 בחלון 0.08 ו**עלתה** ל-0.653 ב-0.20, כלומר "הידית
    עד הסוף" היא לא רק בזבוז אלא נסיגה.

    מפתח שאינו ברשימה **נדחה** ואינו מושתק: בקשה לפרמטר שלא
    הוצהר היא באג אצל הקורא, ושתיקה עליה מייצרת "תיקנתי" על
    מערכת שלא השתנתה.
    """
    bad = [k for k in values if k not in KNOB_BY_KEY]
    if bad:
        raise KeyError(f"פרמטרים שאינם ברשימה הסגורה: {sorted(bad)}")
    d = _read()
    log = d.get("_log") or []
    changed = 0
    for k, v in values.items():
        kn = KNOB_BY_KEY[k]
        before = float(d.get(k, kn.default))
        after = kn.clamp(float(v))
        if abs(after - before) < 1e-9:
            continue
        d[k] = after
        changed += 1
        log.append({"key": k, "from": round(before, 6),
                    "to": round(after, 6),
                    "at": datetime.now().isoformat(timespec="seconds"),
                    "why": why or "apply"})
    if not changed:
        return True
    d["_log"] = log[-60:]
    return _write(d)


# =============================================== החלקה: הידית כפעולה

#: רצפת דגימות לחלון. חלון רחב עם שלוש דגימות הוא **תת-דגימה ולא
#: החלקה**, והיא מכניסה קיפול תדר: נמדד ב-``studio/master.py``
#: שהרעידה ירדה ל-0.359 בחלון 0.08 ואז **עלתה** ל-0.653 ב-0.20.
SMOOTH_MIN_TAPS = 3

#: תקרת דגימות, כדי שחלון רחב לא יכפיל את זמן המדידה בלי גבול.
SMOOTH_MAX_TAPS = 13

#: תכונות שחייבות לעבור את העטיפה. ``speech``/``voice`` הן הפסקול:
#: עטיפה שמאבדת אותן מפיקה סרטון שלם ו**אילם**, ואף בדיקת פריים לא
#: צועקת. ראה ``showreel/disney_story._wrap``.
SMOOTH_ATTRS = ("speech", "body", "track", "voice", "eye", "sit", "window")


def smoothed(fn, scene_len: float, fps: int = 30, *, keep_ik: bool = True,
             attrs: tuple[str, ...] = SMOOTH_ATTRS,
             set_missing: bool = False, win: float | None = None):
    """עוטף שחקן ``(u, t) -> (ctl, ik, mph)`` בהחלקה זמנית.

    **ההחלקה היא על התנועה ולא על המדידה.** זו ההבחנה היחידה
    שחשובה כאן: פילטר שיושב ב-``evidence.track_from_fn`` היה מוריד
    את ``anim.jitter`` בדיוק באותה מידה — ולא היה משנה פריים אחד
    בסרטון. כלומר הציון היה עולה והאיכות לא. כאן העטיפה היא על
    ``fn`` עצמה, אותה פונקציה שמזינה גם את הרינדור.

    חלון ``0`` מחזיר את הפונקציה **כמות שהיא**, בלי שום עטיפה, ולכן
    מערכת בלי כוונון מתנהגת בדיוק כמו לפני הקובץ הזה — ואפס עלות.

    ``keep_ik`` הוא ההבדל מהגרסה שהייתה כאן קודם לכן ב-``master``:
    יעדי ה-IK הם מילונים מקוננים (``{"foot_L": {...}}``) ואינם
    ערוצים סקלריים, וחשוב מזה — **רגל דורכת היא אילוץ ולא עקומה**.
    החלקה של נקודת הדריכה מחזירה בדיוק את ההחלקה על הדשא שהשערים
    של ``locomotion`` מודדים. לכן ה-IK עובר מהדגימה המרכזית כמו
    שהוא, וההחלקה נוגעת רק בערוצי הפוזה ובצורות הפנים.
    """
    w = float(get("smooth_win")) if win is None else float(win)
    if w <= 0.0:
        return fn

    half = w / 2.0
    # דגימה לכל פריים בתוך החלון, ולכל הפחות שלוש. אי-זוגי, כדי
    # שתהיה דגימה מרכזית אחת בדיוק — חלון זוגי מזיז את התוצאה
    # בחצי פריים, וחצי פריים על רגע החיתוך הוא בימוי ולא החלקה.
    taps = int(round(w * fps)) + 1
    taps = max(SMOOTH_MIN_TAPS, min(SMOOTH_MAX_TAPS, taps))
    if taps % 2 == 0:
        taps += 1
    offs = [(-half + w * i / (taps - 1)) for i in range(taps)]
    # **הנורמול הוא ל-``2*half`` ולא ל-``half``.** ``1 - |o|/half``
    # נותן אפס מדויק לשתי הדגימות הקיצוניות, כלומר חלון של שלוש
    # הצטמק למשקל ``[0, 1, 0]`` — ההחלקה "רצה", שילמה פי שלוש
    # בזמן, והחזירה את אותה מטריצה בדיוק.
    wts = [1.0 - abs(o) / (2.0 * half) if half > 0 else 1.0 for o in offs]
    tot = sum(wts) or 1.0
    mid = len(offs) // 2
    span = max(float(scene_len), 1e-6)

    def smooth(u, t):
        tt, uu = float(t), float(u)
        acc_ctl: dict = {}
        acc_mph: dict = {}
        ik_mid: dict = {}
        for i, (o, wt) in enumerate(zip(offs, wts)):
            # **שני הפרמטרים מוזזים, לא אחד.** חלק מהערוצים — ובפרט
            # ערוצי הגוף, שהם היחידים שנכנסים ל-``anim.jitter`` —
            # מונפשים לפי ``u`` ולא לפי ``t``, ולכן הזזת ``t`` לבד
            # החליקה חצי מנוע, והחצי שהוחלק לא נמדד בכלל.
            du = o / span
            r = fn(max(0.0, min(1.0, uu + du)), max(0.0, tt + o))
            c = r[0] if len(r) > 0 else {}
            m = r[2] if len(r) > 2 else {}
            if i == mid:
                ik_mid = (r[1] if len(r) > 1 else {}) or {}
            for src, acc in ((c, acc_ctl), (m, acc_mph)):
                for k, v in (src or {}).items():
                    try:
                        acc[k] = acc.get(k, 0.0) + float(v) * wt
                    except (TypeError, ValueError):
                        acc[k] = v
        out_ctl = {k: (round(v / tot, 5) if isinstance(v, float) else v)
                   for k, v in acc_ctl.items()}
        out_mph = {k: (round(v / tot, 5) if isinstance(v, float) else v)
                   for k, v in acc_mph.items()}
        return out_ctl, (ik_mid if keep_ik else {}), out_mph

    for attr in attrs:
        if set_missing or hasattr(fn, attr):
            setattr(smooth, attr, getattr(fn, attr, None))
    smooth.smoothed = w
    return smooth


def text() -> str:
    L = ["=== כוונון בתוקף ==="]
    for kn in KNOBS:
        v = get(kn.key)
        mark = "·" if abs(v - kn.default) < 1e-9 else "✎"
        L.append(f" {mark} {kn.label:<22} {v:<6} "
                 f"(ברירת מחדל {kn.default}, תחום {kn.lo}..{kn.hi}) "
                 f"→ {kn.dim}")
    return "\n".join(L)
