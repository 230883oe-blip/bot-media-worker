# -*- coding: utf-8 -*-
"""בדיקות שכבת הניהול — שער איכות, גרסאות, ולולאת המשימה.

כל בדיקה כאן **דו-כיוונית**: לא רק "המצב התקין עובר", אלא גם "המצב
השבור באמת נופל". שער שרק מאשר אינו שער, וזו בדיוק הטעות שהייתה
ב-``baseline.gate``: הוא בדק אי-נסיגה, ולכן מערכת שעמדה על 60 והמשיכה
לעמוד על 60 עברה אותו.

`python studio/test_mission.py`
"""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from studio import baseline as B                              # noqa: E402
from studio import mission as M                               # noqa: E402

_ok = 0
_bad: list[str] = []


def ok(cond, label: str, extra: str = "") -> None:
    global _ok
    if cond:
        _ok += 1
        print(f"  ✓ {label:<52} {extra}")
    else:
        _bad.append(label)
        print(f"  ✗ {label:<52} {extra}")


def _rep(vals: dict, states: dict | None = None,
         tag: str = "t") -> B.Report:
    """דוח baseline מזויף, עם מצב לכל קטגוריה."""
    states = states or {}
    scores = []
    for cat in B.CATEGORIES:
        if cat.key not in vals and cat.key not in states:
            continue
        st = states.get(cat.key, "measured")
        v = vals.get(cat.key)
        scores.append(B.Score(cat.key, cat.label,
                              None if st == "unmeasured" else float(v or 0.0),
                              st, evidence=["a", "b", "c"]))
    return B.Report(tag=tag, at="2026-10-07T00:00:00", scores=scores)


#: ציונים שמעבירים את כל שלושה-עשר הספים.
PERFECT_BASE = {k: 99.0 for k in
                ("identity", "face", "eyes", "lipsync", "body", "hands",
                 "emotion", "animation", "camera", "lighting", "rendering",
                 "continuity")}
PERFECT_CRIT = {n: 99.0 for n in
                ("story", "acting", "animation", "cinematography", "visual")}
PERFECT_MASTER = {"audio": 99.0, "mute": 100.0, "panel": 99.0, "full": 99.0}
PERFECT_QA = {"technical": 99.0}


#: לאיזה בריכה כל מקור שייך. ``over`` ב-``_perfect`` נמסר ב**מפתח
#: הממד** ("character"), והמקור שלו נקרא אחרת ("baseline:identity").
#: הגרסה הראשונה חיפשה את מפתח הממד בבריכות, לא מצאה אותו, והשתיקה
#: את ההשפלה בשקט — כלומר בדיקה שאמורה הייתה לבדוק כשל קריטי
#: בדקה מצב מושלם ועברה. זה מה שהפיל שלוש בדיקות כאן.
_POOL_OF = {"baseline": 0, "critic": 1, "master": 2, "qa": 3}


def _perfect(**over) -> M.GateResult:
    pools = [dict(PERFECT_BASE), dict(PERFECT_CRIT),
             dict(PERFECT_MASTER), dict(PERFECT_QA)]
    for k, v in over.items():
        dim = M.DIM_BY_KEY.get(k)
        if dim is None:
            raise KeyError(f"אין ממד בשם {k}")
        for src in dim.sources:
            kind, _, key = src.partition(":")
            pools[_POOL_OF[kind]][key] = float(v)
    base, crit, mas, qa = pools
    return M.quality_gate(_rep(base), crit, mas, qa, check_regression=False)


# ===================================================== 1 · ממדים וספים

def t_dims() -> None:
    print("\n1. שלושה-עשר הממדים והספים")
    want = {"story": 90, "character": 90, "acting": 90, "face": 90,
            "eyes": 90, "body": 88, "animation": 88, "camera": 88,
            "lighting": 85, "visual": 85, "sound": 88, "continuity": 95,
            "technical": 95}
    got = {d.key: int(d.threshold) for d in M.DIMS}
    ok(got == want, "כל שלושה-עשר הספים בדיוק כפי שהוגדרו",
       f"{len(got)} ממדים")
    ok(len({d.key for d in M.DIMS}) == len(M.DIMS),
       "אין ממד כפול")
    srcs = {s.partition(":")[0] for d in M.DIMS for s in d.sources}
    ok(srcs <= {"baseline", "critic", "master", "qa"},
       "כל מקור מדידה מוכר", str(sorted(srcs)))
    bkeys = {c.key for c in B.CATEGORIES}
    bad = [s for d in M.DIMS for s in d.sources
           if s.startswith("baseline:") and s.split(":")[1] not in bkeys]
    ok(not bad, "כל מקור baseline הוא קטגוריה שקיימת בפועל", str(bad))
    # כל שתים-עשרה הקטגוריות הקיימות משתתפות — ולא נשמטה אחת בדרך
    used = {s.split(":")[1] for d in M.DIMS for s in d.sources
            if s.startswith("baseline:")}
    ok(used == bkeys, "אף קטגוריה קיימת לא נשמטה מהמיפוי",
       f"חסרות: {sorted(bkeys - used)}")
    ok(all(d.priority in M.PRIORITY_ORDER for d in M.DIMS),
       "לכל ממד יש קדימות חישוב מוכרת")


# ===================================================== 2 · איחוד מקורות

def t_collect() -> None:
    print("\n2. איחוד המקורות — מינימום ולא ממוצע")
    # body נגזר מ-body ומ-hands. ממוצע היה 74, מינימום 50.
    g = M.quality_gate(_rep({**PERFECT_BASE, "body": 98.0, "hands": 50.0}),
                       PERFECT_CRIT, PERFECT_MASTER, PERFECT_QA,
                       check_regression=False)
    body = g.by_key()["body"]
    ok(body.value == 50.0, "שני מקורות לממד = המינימום, לא הממוצע",
       f"body={body.value} (98 ו-50)")
    ok(not body.passed, "ולכן הממד נכשל, ולא 'עובר בממוצע'")

    g2 = M.quality_gate(None, check_regression=False)
    ok(all(s.state == "unmeasured" for s in g2.scores),
       "בלי מקורות — הכול 'לא נמדד'")
    ok(not g2.criticals,
       "'לא נמדד' אינו כשל קריטי — תקלת סביבה אינה כשל איכות")
    ok(not g2.passed, "אבל גם אינו עובר שער")

    g3 = M.quality_gate(_rep({**PERFECT_BASE, "camera": 0.0},
                             {"camera": "missing"}),
                        PERFECT_CRIT, PERFECT_MASTER, PERFECT_QA,
                        check_regression=False)
    cam = g3.by_key()["camera"]
    ok(cam.state == "missing" and cam.critical,
       "'אין מערכת' כן כשל קריטי", f"state={cam.state}")

    # מקור יחיד שלא נמסר אינו הופך את הממד לאפס
    g4 = M.quality_gate(_rep(PERFECT_BASE), PERFECT_CRIT, {}, PERFECT_QA,
                        check_regression=False)
    snd = g4.by_key()["sound"]
    ok(snd.value == 99.0 and snd.passed,
       "מקור חסר מדולג, והמקור שכן נמדד קובע", f"sound={snd.value}")


def t_critics_from_panel() -> None:
    print("\n2ב. ציוני המבקרים נשלפים מהמבנה האמיתי")
    detail = {"per_character": {
        "lucas": {"scores": {"story": 95.0, "acting": 92.0}},
        "maya": {"scores": {"story": 60.0, "acting": 99.0}}}}
    got = M.critics_from_panel(detail)
    ok(got == {"story": 60.0, "acting": 92.0},
       "מינימום על פני הדמויות, לא ממוצע", str(got))
    ok(M.critics_from_panel({}) == {} and M.critics_from_panel(None) == {},
       "מבנה ריק מחזיר ריק ולא נופל")
    # הכיוון שתפס את הבאג: המבנה השגוי שהנחתי מחזיר ריק
    ok(M.critics_from_panel({"scores": {"story": 90}}) == {},
       "מבנה שאינו per_character אינו 'ממציא' ציונים")


# ===================================================== 3 · שער האיכות

def t_gate() -> None:
    print("\n3. שער האיכות — שלושה תנאים, וכולם חייבים")
    g = _perfect()
    ok(g.passed, "מצב תקין עובר", f"ציון {g.quality_score}")
    ok(not g.criticals and not g.failed and g.no_regression,
       "ושלושת התנאים מתקיימים")

    # כיוון שני א: סף. 94 ברציפות (סף 95) נופל.
    g = _perfect(continuity=94.0)
    ok(not g.passed, "ציון נקודה אחת מתחת לסף נופל",
       f"רציפות 94/95, פער {g.by_key()['continuity'].gap}")
    ok(g.by_key()["continuity"].critical,
       "ורציפות היא P0, ולכן זה גם כשל קריטי")

    # כיוון שני ב: רצפה קשה.
    g = _perfect(lighting=39.0)
    ok(g.by_key()["lighting"].critical,
       "ציון מתחת לרצפה הקשה הוא קריטי בכל קדימות",
       f"תאורה 39 < {M.HARD_FLOOR}")
    g = _perfect(lighting=60.0)
    lg = g.by_key()["lighting"]
    ok(not lg.passed and not lg.critical,
       "אך כשל ב-P3 מעל הרצפה אינו קריטי", f"תאורה 60")

    # כיוון שני ג: נסיגה לבדה מפילה, גם כשכל הספים עוברים.
    g = _perfect()
    g.regressed = ["face"]
    ok(not g.passed and not g.no_regression,
       "נסיגה לבדה מפילה שער שכל ספיו עוברים")

    # רעש מדידה אינו נסיגה — נבדק דרך baseline.compare עצמו
    base = _rep(PERFECT_BASE, tag="b")
    now = _rep({**PERFECT_BASE, "face": 99.0 - B.NOISE / 2})
    cmp = B.compare(now, base)
    ok(not cmp["regressed"],
       "ירידה קטנה מרעש המדידה אינה נסיגה",
       f"-{B.NOISE / 2} מול רעש {B.NOISE}")

    ok(0.0 <= g.quality_score <= 100.0,
       "ציון האיכות חסום ב-100 גם כשכל הציונים מעל הסף",
       f"{g.quality_score}")
    d = g.to_dict()
    ok(set(d) >= {"passed", "quality_score", "critical_failures",
                  "no_regression", "scores"},
       "הפסק מסודר למילון עם כל השדות")
    ok("PASS" in g.text() or "FAIL" in g.text(),
       "ויש לו טקסט קריא")


def t_focus() -> None:
    print("\n4. קדימות חישוב — על מה עובדים ומה מוקפא")
    g = _perfect(lighting=50.0, visual=50.0, acting=50.0)
    foc = g.focus()
    ok(foc and foc[0] == "acting",
       "כשל ב-P1 נבחר לפני כשל ב-P3", f"{foc}")
    ok(set(g.deferred()) == {"lighting", "visual"},
       "ותאורה ומראה מוקפאים כל עוד המשחק נכשל", str(g.deferred()))
    ok(not set(g.deferred()) & set(foc),
       "מה שמוקפא אינו מופיע ברשימת העבודה")

    g2 = _perfect(lighting=50.0)
    ok(g2.deferred() == [],
       "כשאין כשל ב-P0/P1 — שום דבר אינו מוקפא")
    ok(g2.focus() == ["lighting"], "והעבודה היא על הכשל היחיד")

    g3 = _perfect(continuity=50.0, acting=60.0)
    ok(g3.focus()[0] == "continuity",
       "כשל קריטי קודם לכשל רגיל", f"{g3.focus()[:2]}")

    # הכיוון שנתפס בהרצה אמיתית: ממד שלא נמדד הוא P0, ולכן הוא
    # הקפיא את כל מה שמתחתיו — תקלת סביבה שכיוונה את העבודה.
    g4 = M.quality_gate(_rep({**PERFECT_BASE, "animation": 54.0}),
                        PERFECT_CRIT, PERFECT_MASTER, {},
                        check_regression=False)
    ok(g4.by_key()["technical"].state == "unmeasured",
       "הממד הטכני בלי סרטון אינו נמדד")
    ok("animation" not in g4.deferred(),
       "וממד שלא נמדד אינו מקפיא עבודה על מה שכן נמדד",
       str(g4.deferred()))
    ok("animation" in g4.focus(),
       "ולכן הכשל האמיתי כן מגיע לרשימת העבודה", str(g4.focus()))
    ok("technical" in g4.focus(),
       "וגם המדידה החסרה עצמה, כבקשה למדוד")


# ===================================================== 4ב · אבחון שורש

def t_diagnose() -> None:
    print("\n4ב. אבחון שורש")
    ok(set(M.OWNER) == {d.key for d in M.DIMS},
       "לכל ממד מוצהרת תת-מערכת אחראית",
       f"חסרים: {sorted({d.key for d in M.DIMS} - set(M.OWNER))}")
    missing = [(k, f) for k, fs in M.OWNER.items() for f in fs
               if not (ROOT / f).exists()]
    ok(not missing,
       "וכל קובץ שמוצהר כאחראי קיים בפועל — לא מפנים לקובץ מדומה",
       str(missing[:3]))

    g = _perfect(face=50.0, lighting=50.0)
    ds = M.diagnose(g)
    ok(ds and ds[0].dim == "face",
       "האבחון מתחיל בכשל הדחוף ביותר", str([d.dim for d in ds]))
    ok("rig/face.py" in ds[0].subsystems,
       "ומצביע על הקובץ שצריך להיפתח", str(ds[0].subsystems[:2]))
    ok(ds[0].gap == 40.0 and ds[0].priority == "P1",
       "עם הפער והקדימות", f"פער {ds[0].gap}")
    ok("baseline:face=50.0" in ds[0].why,
       "והשורש מצביע על המקור החלש בשמו", ds[0].why)

    ok(M.diagnose(g, "face") and M.diagnose(g, "face")[0].dim == "face",
       "אבחון של שלב מוגבל לממדים שלו")
    ok(M.diagnose(_perfect(), "face") == [],
       "ושלב שעובר אינו מאובחן")

    # שלושת המצבים נבדלים זה מזה בהמלצה, וזה כל התועלת
    gm = M.quality_gate(_rep({**PERFECT_BASE, "camera": 0.0},
                             {"camera": "missing"}),
                        PERFECT_CRIT, PERFECT_MASTER, PERFECT_QA,
                        check_regression=False)
    dm = [d for d in M.diagnose(gm, "camera")]
    ok(dm and "לבנות" in dm[0].why,
       "'אין מערכת' -> לבנות, לא לתקן", dm[0].why if dm else "")
    gu = M.quality_gate(_rep(PERFECT_BASE), PERFECT_CRIT, PERFECT_MASTER,
                        {}, check_regression=False)
    du = M.diagnose(gu, "gold")
    ok(du and "אין ידיעה" in du[0].why,
       "'לא נמדד' -> להריץ את המודד, לא לגעת בקוד",
       du[0].why if du else "")
    ok(du and not du[0].repairs,
       "ואין המלצת תיקון על סמך אי-ידיעה")

    # ראיות שנפלו מתורגמות לתיקון דרך הספר הקיים
    book = M._repair_book()
    ok(book, "ספר התיקונים נטען מ-critics ולא נכתב מחדש",
       f"{len(book)} קודים")
    if not book:
        return
    code = next(iter(book))
    rep = _rep(PERFECT_BASE)
    for sc in rep.scores:
        if sc.key == "face":
            sc.value, sc.evidence = 50.0, [f"{code} ✗", "אחר"]
    g2 = M.quality_gate(rep, PERFECT_CRIT, PERFECT_MASTER, PERFECT_QA,
                        check_regression=False)
    d2 = M.diagnose(g2, "face")
    ok(d2 and book[code] in d2[0].repairs,
       "בדיקה שנפלה מתורגמת לתיקון מהספר",
       f"{code} -> {book[code]}")
    ok(d2 and code in d2[0].failed_checks,
       "והבדיקה עצמה נרשמת, בלי סימן הכשל")
    ok("אחר" not in (d2[0].failed_checks if d2 else []),
       "ראיה שעברה אינה נרשמת ככשל")
    ok("אבחון" in M.diagnosis_text(d2) and
       M.diagnosis_text([]) == "אין כשל לאבחן.",
       "ולאבחון יש טקסט קריא")


# ===================================================== 5 · גרסאות

def t_versions() -> None:
    print("\n5. שרשרת גרסאות")
    tmp = Path(tempfile.mkdtemp(prefix="mis_"))
    try:
        st = M.VersionStore(root=tmp / "v", repo=ROOT)
        g = _perfect()
        v1 = st.create(gate=g, stage="face", files=["rig/face.py", "a.mp4"])
        ok(v1["version_id"] == "V1" and v1["parent_version"] == "",
           "הגרסה הראשונה היא V1 ואין לה אב")
        ok(set(M.VERSION_FIELDS) <= set(v1),
           "כל שדות הרשומה שהוגדרו במשימה קיימים",
           f"{len(M.VERSION_FIELDS)} שדות")
        ok(v1["files"] == ["rig/face.py"],
           "קובץ שאינו קוד אינו נרשם לנסיגה", str(v1["files"]))
        ok(v1["quality_score"] == g.quality_score,
           "ציון האיכות נרשם מהשער ולא מהקורא")

        v2 = st.create(gate=_perfect(face=50.0), stage="eyes")
        ok(v2["parent_version"] == "V1",
           "האב נקבע מאליו מהגרסה האחרונה — שרשרת אינה נקרעת")
        ok(v2["known_failures"],
           "כשלים ידועים נרשמים בגרסה", str(v2["known_failures"][:1]))
        ok(st.chain("V2") == ["V2", "V1"],
           "שרשרת האבות נקראת עד השורש", str(st.chain("V2")))

        try:
            st.create(gate=g, version_id="V1")
            dup = False
        except ValueError:
            dup = True
        ok(dup, "גרסה קיימת אינה נדרסת")

        idx = st.index()
        ok(len(idx) == 2 and idx[-1]["version_id"] == "V2",
           "המפתח מעודכן ומסודר", f"{[r['version_id'] for r in idx]}")
        ok(st.latest()["version_id"] == "V2", "ו-latest מחזיר את האחרונה")

        # שורש השרשרת: בסיס מוגן, בלי אב, ואינו נהרס
        st0 = M.VersionStore(root=tmp / "z", repo=ROOT)
        b0 = st0.baseline_v0(gate=_perfect(), files=["rig/face.py"])
        ok(b0["version_id"] == M.V0 and b0["parent_version"] == "",
           "הבסיס המוגן הוא שורש השרשרת, בלי אב", b0["version_id"])
        b0b = st0.baseline_v0(gate=_perfect(face=10.0))
        ok(b0b["quality_score"] == b0["quality_score"],
           "הרצה שנייה מחזירה את הבסיס ואינה כותבת מחדש")
        ok(len(st0.index()) == 1, "ואין רשומה כפולה במפתח")
        nxt = st0.create(gate=_perfect(), stage="face")
        ok(nxt["version_id"] == "V1" and nxt["parent_version"] == M.V0,
           "והגרסה הבאה תולה את עצמה בבסיס", nxt["parent_version"])

        # מעגל ברשומה פגומה אינו תולה את הקורא
        bad = st.path_of("V2")
        rec = json.loads(bad.read_text(encoding="utf-8"))
        rec["parent_version"] = "V2"
        bad.write_text(json.dumps(rec, ensure_ascii=False), encoding="utf-8")
        ok(st.chain("V2") == ["V2"],
           "רשומה שמצביעה על עצמה אינה תולה את השרשרת")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def t_rollback() -> None:
    print("\n6. נסיגה — קובץ-קובץ, ולעולם לא גורפת")
    tmp = Path(tempfile.mkdtemp(prefix="mrb_"))
    try:
        repo = tmp / "repo"
        repo.mkdir()
        run = lambda *a: subprocess.run(["git", *a], cwd=str(repo),
                                        capture_output=True, text=True)
        run("init", "-q")
        run("config", "user.email", "t@t")
        run("config", "user.name", "t")
        code = repo / "mod.py"
        code.write_text("VALUE = 1\n", encoding="utf-8")
        state = repo / "state.json"
        state.write_text('{"n": 1}', encoding="utf-8")
        run("add", "-A")
        run("commit", "-q", "-m", "v1")

        st = M.VersionStore(root=tmp / "v", repo=repo)
        v1 = st.create(gate=_perfect(), stage="face",
                       files=["mod.py", "state.json"])
        ok(v1["commit"], "הגרסה שמרה נקודת git", v1["commit"][:8])
        ok(v1["files"] == ["mod.py"],
           "קובץ מצב לא נרשם לנסיגה — החזרתו אינה ביטול שינוי")

        # אדם ערך את שני הקבצים אחרי הגרסה
        code.write_text("VALUE = 999\n", encoding="utf-8")
        state.write_text('{"n": 42}', encoding="utf-8")

        plan = st.rollback("V1")
        ok(plan["ok"] and plan["dry_run"] and not plan["applied"],
           "ברירת המחדל היא תוכנית בלבד — הדיסק לא נגע")
        ok(code.read_text(encoding="utf-8") == "VALUE = 999\n",
           "ובפועל הקובץ לא שוחזר")

        plan = st.rollback("V1", apply=True)
        ok(plan["ok"] and plan["applied"] == ["mod.py"],
           "נסיגה בפועל מחזירה את קובץ הקוד", str(plan["applied"]))
        ok(code.read_text(encoding="utf-8") == "VALUE = 1\n",
           "והתוכן חזר לגרסה")
        ok(state.read_text(encoding="utf-8") == '{"n": 42}',
           "קובץ המצב **לא** נדרס — זו ההגנה על עובדות שאינן של הגרסה")

        bad = st.rollback("V99")
        ok(not bad["ok"] and "אין גרסה" in bad["why"],
           "נסיגה לגרסה שאינה קיימת נכשלת בהודעה ברורה")

        v2 = st.create(gate=_perfect(), stage="eyes", files=[])
        p2 = st.rollback("V2")
        ok(not p2["ok"] and "קובצי קוד" in p2["why"],
           "גרסה בלי קובצי קוד אינה 'מחזירה הכול'")

        # מחפשים את הפקודה כ**ארגומנט** ולא כטקסט: המחרוזת
        # "reset --hard" מופיעה בתיעוד הקובץ בדיוק כדי להסביר שהיא
        # אסורה, ובדיקה על טקסט חופשי הייתה נכשלת על ההסבר שלה.
        src = Path(M.__file__).read_text(encoding="utf-8")
        banned = [p for p in ('"reset"', "'reset'", '"--", "."',
                              '"checkout", "--"', '"clean"') if p in src]
        ok(not banned,
           "אין בקוד שחזור גורף — רק checkout לקובץ מוצהר", str(banned))
        ok('"checkout", commit, "--", f' in src.replace("\n", " "),
           "והנסיגה היא checkout לנקודה ולקובץ בודד")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


# ===================================================== 7 · גרף הביצוע

def t_graph() -> None:
    print("\n7. גרף הביצוע — תלות, וסדר שאינו עוקף כשל")
    keys = [s.key for s in M.GRAPH]
    ok(len(keys) == len(set(keys)), "אין שלב כפול")
    for s in M.GRAPH:
        bad = [n for n in s.needs if n not in M.STAGE_BY_KEY]
        ok(not bad, f"תלויות {s.key} קיימות", str(bad))
    # כל תלות מופיעה לפני השלב שתלוי בה
    order = {k: i for i, k in enumerate(keys)}
    bad = [(s.key, n) for s in M.GRAPH for n in s.needs
           if order[n] >= order[s.key]]
    ok(not bad, "כל תלות מופיעה לפני מי שתלוי בה", str(bad))
    covered = {d for s in M.GRAPH for d in s.dims}
    ok(covered == {d.key for d in M.DIMS},
       "כל ממד שייך לשלב אחד לפחות",
       f"חסרים: {sorted({d.key for d in M.DIMS} - covered)}")
    dup = [d for d in covered
           if sum(1 for s in M.GRAPH if d in s.dims) > 1]
    ok(not dup, "ואין ממד ששייך לשני שלבים", str(dup))

    ok(M.select_next_stage(_perfect(), []) == "audit",
       "בלי שלבים שהושלמו — מתחילים בראשון")
    ok(M.select_next_stage(_perfect(), ["audit"]) == "baseline_v0",
       "ואחרי שהראשון עבר — השני")
    ok(M.select_next_stage(_perfect(), [s.key for s in M.GRAPH]) is None,
       "כשהכול הושלם אין שלב הבא")
    # הכיוון שהוא כל האכיפה: שלב שלא עבר אינו ב-done, ולכן מי
    # שתלוי בו לא נבחר לפניו.
    ok(M.select_next_stage(_perfect(), ["audit", "baseline_v0"]) ==
       "character",
       "שלב נבחר רק כשכל תלויותיו הושלמו")


def t_stage_verdict() -> None:
    print("\n8. פסק של שלב בודד")
    g = _perfect(face=50.0)
    sv = M.stage_verdict(g, "face")
    ok(not sv["passed"] and sv["failed"] == ["face"],
       "שלב נכשל רק על הממדים שלו", str(sv))
    ok(M.stage_verdict(g, "eyes")["passed"],
       "ושלב אחר שלא נפגע עובר")
    ok(M.stage_verdict(g, "audit")["passed"],
       "שלב בלי ממדים עובר — אחרת הגרף נתקע לנצח")
    ok(M.stage_verdict(g, "אין_כזה")["passed"],
       "ושלב לא מוכר אינו מפיל")


# ===================================================== 9 · הלולאה

def _fake(scores: dict) -> M.GateResult:
    base = dict(PERFECT_BASE)
    crit = dict(PERFECT_CRIT)
    mas = dict(PERFECT_MASTER)
    qa = dict(PERFECT_QA)
    for k, v in scores.items():
        for pool in (base, crit, mas, qa):
            if k in pool:
                pool[k] = v
    return M.quality_gate(_rep(base), crit, mas, qa, check_regression=False)


def t_loop() -> None:
    print("\n9. לולאת המשימה")
    tmp = Path(tempfile.mkdtemp(prefix="mlp_"))
    try:
        # א. הכול תקין -> משימה שלמה, וגרסה לכל שלב
        st = M.VersionStore(root=tmp / "a", repo=ROOT)
        m = M.Mission(measure=lambda s, n: _perfect(), store=st)
        res = m.run()
        ok(res.complete and len(res.done) == len(M.GRAPH),
           "מצב תקין משלים את כל הגרף", f"{res.outcome} {len(res.done)}")
        ok(len(res.versions) == len(M.GRAPH),
           "ונרשמת גרסה לכל שלב שאושר", f"{len(res.versions)}")
        ch = st.chain(res.versions[-1])
        ok(len(ch) == len(res.versions),
           "והגרסאות קשורות בשרשרת אחת", f"{len(ch)}")

        # ב. כשל בלי מנוע תיקון -> נחסם, ולא מתקדם
        m = M.Mission(measure=lambda s, n: _perfect(face=50.0))
        res = m.run()
        ok(res.outcome == "BLOCKED" and res.blocked == "face",
           "כשל בלי מנוע תיקון חוסם בשלב עצמו", res.why)
        ok("eyes" not in res.done,
           "ושלב שתלוי בו אינו מתקדם — אסור להתקדם עם כשל")

        # ג. תיקון שעובד -> אושר והמשיך
        state = {"face": 50.0}

        def measure_c(stage, n):
            return _perfect(**state)

        def repair_c(stage, focus, sv):
            state["face"] = 99.0
            return {"repairs": ["refine_face"], "files": ["rig/face.py"]}

        st2 = M.VersionStore(root=tmp / "c", repo=ROOT)
        m = M.Mission(measure=measure_c, repair=repair_c, store=st2)
        res = m.run()
        ok(res.complete, "תיקון שעבד מאשר את השלב וממשיך", res.outcome)
        fixed = [r for r in res.rounds if r["repairs"]]
        ok(len(fixed) == 1 and fixed[0]["gained"] > 0,
           "והסבב נרשם עם השיפור שנמדד",
           f"+{fixed[0]['gained']}")

        # ד. ספר תיקונים ריק -> עוצר, ולא מודד שוב אותו דבר
        calls = {"n": 0}

        def measure_d(stage, n):
            calls["n"] += 1
            return _perfect(face=50.0)

        m = M.Mission(measure=measure_d, repair=lambda *a: {"repairs": []})
        res = m.run()
        ok(res.outcome == "EXHAUSTED" and "נגמר" in res.why,
           "ספר תיקונים ריק עוצר", res.why)
        before = calls["n"]
        ok(before <= 4,
           "ולא נמדד מחדש בדיוק אותו מצב", f"{before} מדידות")

        # ה. תיקון שפוגע במי שלא התלונן -> נסיגה, עצירה.
        # הספירה היא **לפי שלב** ולא מונה גלובלי: השלבים הראשונים
        # בגרף הם ללא ממדים ונצרכים מיד, ומונה גלובלי היה "מבזבז"
        # עליהם את המצב השבור — הבדיקה הייתה מגיעה לשלב הפנים
        # כשהוא כבר תקין, ועוברת מהסיבה הלא נכונה.
        def measure_e(stage, n):
            if stage != "face":
                return _perfect()
            if n == 0:
                return _perfect(face=50.0)
            return _perfect(face=99.0, continuity=80.0)

        m = M.Mission(measure=measure_e,
                      repair=lambda *a: {"repairs": ["hard_relight"]})
        res = m.run()
        ok(res.outcome == "BLOCKED" and "נסיגה" in res.why,
           "תיקון שפגע במי שלא התלונן עוצר את המשימה", res.why)
        ok(any(r["regressed"] for r in res.rounds),
           "והנסיגה נרשמה בסבב",
           str([r["regressed"] for r in res.rounds if r["regressed"]]))

        # ו. שיפור זניח -> קיפאון, ולא לולאה אין-סופית
        prog = {"v": 50.0}

        def measure_f(stage, n):
            return _perfect(face=prog["v"])

        def repair_f(stage, focus, sv):
            prog["v"] += 0.4          # קטן מ-PLATEAU_DELTA
            return {"repairs": ["nudge"]}

        m = M.Mission(measure=measure_f, repair=repair_f, max_rounds=2)
        res = m.run()
        ok(res.outcome in ("STALLED", "EXHAUSTED"),
           "שיפור שקטן מסף הקיפאון עוצר", f"{res.outcome} · {res.why}")
        ok(len(res.rounds) <= 8, "והלולאה אינה אין-סופית",
           f"{len(res.rounds)} סבבים")

        # ז. תקרת צעדים
        m = M.Mission(measure=lambda s, n: _perfect(face=50.0),
                      repair=lambda *a: {"repairs": ["x"]}, max_rounds=99)
        res = m.run(max_steps=3)
        ok(res.outcome in ("EXHAUSTED", "STALLED", "BLOCKED"),
           "תקרת הצעדים נאכפת", f"{res.outcome} · {len(res.rounds)} סבבים")
        ok("✓" in res.text() or "⛔" in res.text() or "✗" in res.text()
           or "⏸" in res.text(), "ולדוח יש טקסט קריא")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def t_no_advance() -> None:
    print("\n10. איסור התקדמות עם כשל קריטי")
    seen: list[str] = []

    def measure(stage, n):
        seen.append(stage)
        return _perfect(character=30.0)      # קריטי, שלב character

    m = M.Mission(measure=measure)
    res = m.run()
    after = [s for s in seen if s in ("face", "eyes", "emotion", "body")]
    ok(not after,
       "שום שלב שאחרי הכשל הקריטי לא נמדד בכלל", str(after))
    ok(res.blocked == "character" and not res.complete,
       "והמשימה נעצרת בשלב הכושל עצמו", f"{res.outcome} {res.blocked}")
    ok(set(res.done) == {"audit", "baseline_v0"},
       "רק מה שעבר לפניו נספר כהושלם", str(res.done))


# ===================================================== 11 · חיבור אמיתי

def t_real_wiring() -> None:
    print("\n11. חיבור למקורות האמיתיים")
    import inspect
    src = inspect.getsource(M.measure_system)
    ok("B.measure" in src, "המדידה עוברת דרך baseline הקיים")
    ok("critics_from_panel" in src,
       "וציוני המבקרים דרך הפונקציה שנבדקה")
    ok("qrep.score" in src,
       "והציון הטכני מ-qa.Report.score שכבר מחושב שם")
    ok("except Exception" in src,
       "מקור שנופל אינו מפיל את המדידה כולה")

    # הממדים שנגזרים מ-baseline לבדו באמת נמדדים בהרצה אמיתית קצרה
    rep = B.measure(quality="fast", only=["face", "eyes"], tag="t_wire")
    g = M.quality_gate(rep, check_regression=False)
    by = g.by_key()
    ok(by["face"].state == "measured" and by["face"].value is not None,
       "מדידה אמיתית של פנים מגיעה לשער",
       f"face={by['face'].value}")
    ok(by["eyes"].state == "measured",
       "וגם של עיניים", f"eyes={by['eyes'].value}")
    ok(by["story"].state == "unmeasured",
       "ומה שלא נמדד מסומן ככזה ולא מקבל ציון מומצא")


# ============================ 12 · הראיה שנפלה: פורמט אחד לכל המודדים

def t_evidence_format() -> None:
    print("\n12. ראיה שנפלה — פורמט אחד לכל המודדים")
    # עד 07/10 היו שני פורמטים, ו-``from_metrics`` לא סימן כלום.
    # כל הקוראים חיפשו ``✗``, ולכן חמישה מודדים רציפים החזירו
    # רשימת כשלים ריקה — באג שקט מושלם.
    _sc, ev = B.from_metrics([("טוב", 1.0), ("גבולי", 0.97),
                              ("רע", 0.265)])
    fails = [e for e in ev if str(e).rstrip().endswith("✗")]
    ok(len(fails) == 1 and "רע" in fails[0],
       "מדד מתחת לסף מסומן ✗", f"{fails}")
    ok(not any("טוב" in f for f in fails),
       "ומדד מלא אינו מסומן — אחרת הרשימה היא רעש")
    ok(not any("גבולי" in f for f in fails),
       "וגם לא מדד גבולי מעל EV_FAIL", f"EV_FAIL={B.EV_FAIL}")
    ok(B.ev_value("רע=0.265 ✗") == 0.265,
       "הערך נשלף מתוך הראיה", "0.265")
    ok(B.ev_value("מצלמה/headroom ✗") is None,
       "וראיה בוליאנית מחזירה None ולא אפס מומצא")
    ok(B.ev_value("בלי שום מספר") is None,
       "וכך גם ראיה בלי סימן שווה בכלל")

    # ראיות בוליאניות של ``from_checks`` נשארו בדיוק כמו שהיו
    _s2, ev2 = B.from_checks({"a": {"pass": True}, "b": {"pass": False}})
    ok([e for e in ev2 if e.endswith("✗")] == ["b ✗"],
       "והפורמט הבוליאני לא נשבר", f"{ev2}")


def t_findings_wiring() -> None:
    print("\n13. אבחון המבקרים מגיע לשער")
    ok(M._finding_code({"code": "anim.jitter"}) == "anim.jitter ✗",
       "רשומת אבחון של מבקר הופכת לראיה מסומנת")
    ok(M._finding_code("anim.pops") == "anim.pops ✗",
       "וגם מחרוזת, בלי כפל סימן")
    ok(M._finding_code({"code": ""}) == "",
       "ורשומה בלי קוד אינה ראיה", "ולא 'None ✗'")

    det = {"per_character": {
        "a": {"scores": {"animation": 59.0},
              "diagnosis": [{"code": "anim.jitter", "quality": 0.57},
                            {"code": "anim.pops", "quality": 0.0}]},
        "b": {"scores": {"animation": 54.9},
              "diagnosis": [{"code": "anim.jitter", "quality": 0.46}]}}}
    f = M.findings_from_panel(det)
    codes = sorted(d["code"] for d in f.get("animation", []))
    ok(codes == ["anim.jitter", "anim.pops"],
       "כשל בדמות אחת נכנס גם אם השנייה נקייה — איגוד ולא מינימום",
       f"{codes}")
    jit = [d for d in f["animation"] if d["code"] == "anim.jitter"][0]
    ok(abs(float(jit["quality"]) - 0.46) < 1e-9,
       "ומרשומה כפולה נשמרת הגרועה", f"quality={jit['quality']}")
    ok(jit.get("critic") == "animation",
       "ושם המבקר נגזר מהקוד ולא נדרש בשדה", jit.get("critic"))

    # והראיות באמת מגיעות ל-``failed_checks`` של הממד הנכון
    g = M.quality_gate(_rep({**PERFECT_BASE, "animation": 99.0}),
                       {"animation": 50.0, "story": 99.0, "acting": 99.0,
                        "cinematography": 99.0, "visual": 99.0},
                       check_regression=False, critic_findings=f)
    chk = g.by_key()["animation"].failed_checks
    ok("anim.jitter" in [c.rstrip(" ✗") for c in chk],
       "ראיה של מבקר מגיעה לממד שלו", f"{chk}")
    # ושל baseline לא מתנגשת בה — אותו מפתח, שני מקורות
    ok(len(chk) >= 2, "שתי המשפחות חיות באותה רשימה", f"{len(chk)}")


def t_repair_book() -> None:
    print("\n14. ספר התיקונים — שני ספרים, מפתח אחד")
    ok(M.repair_for("anim.jitter ✗") == "smooth_curves",
       "קוד של מבקר נפתר מספר המבקרים")
    ok(M.repair_for("צורות פנים בריג=0.265 ✗") == "expand_face_shapes",
       "וראיה בעברית נפתרת לפי תחילית — התאמה מדויקת לא הייתה "
       "תופסת אף אחת, כי הערך בתוכה")
    ok(M.repair_for("פונמות ממופות=0.714 ✗") == "map_phonemes",
       "וגם ראיה של דיבור")
    ok(M.repair_for("משהו שאיש לא כתב=0.1 ✗") == "",
       "ומה שאין לו תיקון מחזיר ריק ולא ניחוש")


def t_tuning() -> None:
    print("\n15. כוונון מתמיד")
    from studio import tuning as TU
    tmp = Path(tempfile.mkdtemp(prefix="tun_"))
    old = TU.STATE
    try:
        TU.STATE = tmp / "tuning.json"
        ok(TU.get("smooth_win") == 0.0,
           "קובץ חסר מחזיר ברירת מחדל — ואינו קובץ שבור")
        r = TU.nudge("smooth_win")
        ok(r["ok"] and r["after"] > r["before"],
           "הפרמטר זז בצעד מוצהר", f"{r['before']}→{r['after']}")
        ok(TU.STATE.exists(),
           "והשינוי ירד לדיסק — תיקון שלא נשמר אינו תיקון")
        ok(TU.get("smooth_win") == r["after"],
           "ונקרא חזרה אחרי 'הפעלה מחדש'")

        lim = TU.KNOB_BY_KEY["smooth_win"]
        for _ in range(40):
            TU.nudge("smooth_win")
        r2 = TU.nudge("smooth_win")
        ok(TU.get("smooth_win") == lim.hi,
           "ולא חורג מהתחום", f"{lim.hi}")
        ok(not r2["ok"] and r2.get("at_limit"),
           "וקצה התחום מדווח כמוצה ולא כהצלחה", r2.get("why", "")[:40])

        r3 = TU.nudge("anticipate")
        ok(not r3["ok"] and r3.get("unwired"),
           "פרמטר שאינו מחובר נדחה במפורש — אחרת 'תיקנתי' ואפס שינוי")
        r4 = TU.nudge("אין_כזה")
        ok(not r4["ok"], "ופרמטר לא מוכר נדחה ולא מתעלמים ממנו בשקט")

        ok(TU.reset("smooth_win") and TU.get("smooth_win") == 0.0,
           "נסיגה מחזירה לברירת המחדל")

        # קובץ פגום מוסג ואינו נדרס — אבדן מצב אינו "הרצה ראשונה"
        TU.nudge("smooth_win")
        TU.STATE.write_text("{ זה לא json", encoding="utf-8")
        ok(TU.get("smooth_win") == 0.0, "קובץ פגום מחזיר ברירת מחדל")
        ok(any(p.name.startswith("tuning.corrupt-")
               for p in tmp.iterdir()),
           "והמקור הפגום מוסג הצידה ולא נמחק",
           f"{[p.name for p in tmp.iterdir()]}")
    finally:
        TU.STATE = old
        shutil.rmtree(tmp, ignore_errors=True)


class _FakeTuning:
    """כוונון מדומה: אותו חוזה, בזיכרון, בלי דיסק."""

    def __init__(self, wired=("smooth_win",), hi=0.2, step=0.04):
        self.vals = {"smooth_win": 0.0, "anticipate": 0.0}
        self.wired = set(wired)
        self.hi, self.step = hi, step
        self.calls: list[str] = []

    def nudge(self, key, steps=1):
        self.calls.append(key)
        if key not in self.vals:
            return {"ok": False, "key": key, "why": "לא מוכר"}
        if key not in self.wired:
            return {"ok": False, "key": key, "unwired": True,
                    "why": "לא מחובר"}
        before = self.vals[key]
        after = min(self.hi, round(before + self.step, 6))
        if after == before:
            return {"ok": False, "key": key, "at_limit": True,
                    "before": before, "after": after, "why": "בקצה"}
        self.vals[key] = after
        return {"ok": True, "key": key, "before": before, "after": after,
                "at_limit": after >= self.hi, "why": ""}


def t_repair_engine() -> None:
    print("\n16. מנוע התיקון")
    f = {"animation": [{"code": "anim.jitter", "quality": 0.5},
                       {"code": "anim.anticipation", "quality": 0.3}]}
    g = M.quality_gate(_rep({**PERFECT_BASE, "animation": 99.0}),
                       {**PERFECT_CRIT, "animation": 50.0},
                       dict(PERFECT_MASTER), dict(PERFECT_QA),
                       check_regression=False, critic_findings=f)
    sv = M.stage_verdict(g, "principles")
    T = _FakeTuning()
    eng = M.RepairEngine(tuning=T)
    plan = eng.plan("principles", sv["failed"], dict(sv, gate=g))

    ok(any("smooth_curves" in r for r in plan["repairs"]),
       "ראיה שנפלה הופכת לתיקון שבוצע", f"{plan['repairs']}")
    ok(all("add_anticipation" not in r for r in plan["repairs"]),
       "ותיקון שאינו מחובר **אינו** נרשם כבוצע — זו כל הנקודה")
    ok(any("add_anticipation" in m for m in plan["manual"]),
       "אלא מדווח כדורש אדם", f"{plan['manual'][:1]}")
    ok("rig/principles.py" in plan["files"],
       "והקובץ האחראי מצורף", f"{plan['files']}")
    ok(plan["note"],
       "ולעצירה יש הסבר ולא רק 'נגמר'", plan["note"][:40])

    before = len(T.calls)
    eng.plan("principles", sv["failed"], dict(sv, gate=g))
    ok(T.calls.count("anticipate") == 1,
       "פרמטר שנדחה לא נוסה שוב על אותו שלב",
       f"{T.calls.count('anticipate')} מתוך {len(T.calls)}")
    ok(len(T.calls) > before,
       "אבל פרמטר שעובד כן ממשיך לזוז בסבב הבא")

    # ממד שנכשל בלי אף ראיה — נאמר במילים, לא מתורגם לתיקון מומצא
    g2 = M.quality_gate(_rep({**PERFECT_BASE}),
                        {"animation": 50.0, "story": 99.0, "acting": 99.0,
                         "cinematography": 99.0, "visual": 99.0},
                        check_regression=False)
    sv2 = M.stage_verdict(g2, "principles")
    p2 = M.RepairEngine(tuning=_FakeTuning()).plan(
        "principles", sv2["failed"], dict(sv2, gate=g2))
    ok(not p2["repairs"] and "סף" in p2["note"],
       "ממד בלי ראיה בודדת מדווח 'הפער בסף'", p2["note"][:40])


def t_loop_with_engine() -> None:
    print("\n17. הלולאה עם מנוע תיקון אמיתי")
    # המצב שנמדד לפני התיקון: הלולאה נעצרה ב"אין מנוע תיקון".
    state = {"animation": 50.0}
    T = _FakeTuning()

    def measure(stage, n):
        # כל המקורות נמסרים, גם ``master`` וגם ``qa``: בלעדיהם
        # הממד הטכני מסומן "לא נמדד", שלב תקן הזהב נכשל, והבדיקה
        # מודדת פיקסטורה חסרה במקום את הלולאה.
        return M.quality_gate(
            _rep({**PERFECT_BASE, "animation": 99.0}),
            {**PERFECT_CRIT,
             "animation": 50.0 + 400.0 * T.vals["smooth_win"]},
            dict(PERFECT_MASTER), dict(PERFECT_QA),
            check_regression=False,
            critic_findings={"animation": [{"code": "anim.jitter",
                                            "quality": 0.5}]})

    m = M.Mission(measure=measure, repair=M.RepairEngine(tuning=T))
    res = m.run()
    ok("אין מנוע תיקון" not in (res.why or ""),
       "הלולאה אינה נעצרת יותר ב'אין מנוע תיקון'", res.why[:40])
    ok(res.complete, "והיא משלימה את הגרף כשהתיקון עובד",
       f"{res.outcome} {len(res.done)}/{len(M.GRAPH)}")
    ok(T.vals["smooth_win"] > 0.0,
       "והפרמטר אכן זז בפועל", f"{T.vals['smooth_win']}")

    # וכשאין מה להזיז — עצירה עם סיבה אמיתית, לא קיפאון מעורפל
    T2 = _FakeTuning(wired=())
    m2 = M.Mission(measure=lambda s, n: M.quality_gate(
        _rep({**PERFECT_BASE, "animation": 99.0}),
        {**PERFECT_CRIT, "animation": 50.0},
        dict(PERFECT_MASTER), dict(PERFECT_QA),
        check_regression=False,
        critic_findings={"animation": [{"code": "anim.jitter",
                                        "quality": 0.5}]}),
        repair=M.RepairEngine(tuning=T2))
    res2 = m2.run()
    ok(res2.outcome == "EXHAUSTED" and "דרוש אדם" in res2.why,
       "ובלי פרמטר מחובר העצירה אומרת מה דרוש", res2.why[:50])


def t_smoothing() -> None:
    print("\n18. ההחלקה היא על התנועה, ולא על המדידה")
    from studio import master as MA
    from studio import tuning as TU
    tmp = Path(tempfile.mkdtemp(prefix="sm_"))
    old = TU.STATE
    try:
        TU.STATE = tmp / "t.json"

        def raw(u, t):
            # ערוץ מקפץ: פריים זוגי 0, אי-זוגי 1. ההחלקה חייבת
            # לשטח אותו, וחלון 0 חייב להשאיר אותו בדיוק כמו שהוא.
            i = int(round(float(t) * MA.FPS))
            return {"arm_x": float(i % 2)}, {}, {}

        same = MA._smoothed(raw)
        ok(same is raw,
           "חלון אפס מחזיר את הפונקציה כמות שהיא — אפס עלות, "
           "אפס שינוי התנהגות")

        d = {"smooth_win": 0.2}
        TU.STATE.write_text(json.dumps(d), encoding="utf-8")
        sm = MA._smoothed(raw)
        ok(sm is not raw and getattr(sm, "smoothed", 0) == 0.2,
           "וחלון חיובי עוטף", f"{getattr(sm, 'smoothed', None)}")

        vals = [sm(i / 60.0, i / MA.FPS)[0]["arm_x"] for i in range(10)]
        spread = max(vals) - min(vals)
        ok(spread < 0.9,
           "ערוץ מקפץ נשטח בפועל — זה הכשל שהחזיק: משקלי הקצה "
           "היו אפס, ולכן ההחלקה החזירה את אותה מטריצה בדיוק",
           f"פרישה {spread:.3f} מול 1.0 גולמי")

        rawvals = [raw(i / 60.0, i / MA.FPS)[0]["arm_x"] for i in range(10)]
        ok(max(rawvals) - min(rawvals) == 1.0,
           "ושהמקור באמת מקפץ (אחרת הבדיקה מודדת כלום)")

        # הדגימות הן לפי קצב הפריימים, לא שלוש קבועות
        ok(MA.SMOOTH_MIN_TAPS == 3 and MA.SMOOTH_MAX_TAPS >= 7,
           "ומספר הדגימות נגזר מהחלון ולא קבוע — שלוש קבועות על "
           "חלון רחב הן תת-דגימה ולא החלקה")
    finally:
        TU.STATE = old
        shutil.rmtree(tmp, ignore_errors=True)


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8")
    print("=== בדיקות שכבת הניהול ===")
    for fn in (t_dims, t_collect, t_critics_from_panel, t_gate, t_focus,
               t_diagnose, t_versions, t_rollback, t_graph, t_stage_verdict,
               t_loop, t_no_advance, t_real_wiring,
               t_evidence_format, t_findings_wiring, t_repair_book,
               t_tuning, t_repair_engine, t_loop_with_engine, t_smoothing):
        fn()
    total = _ok + len(_bad)
    print(f"\n{_ok}/{total} עברו")
    if _bad:
        for b in _bad:
            print(f"  נכשל: {b}")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
