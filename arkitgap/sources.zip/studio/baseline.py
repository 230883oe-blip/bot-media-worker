# -*- coding: utf-8 -*-
"""שלב 1 · מדידת בסיס והשוואת גרסאות (BASELINE_V0).

**מה הבעיה שהמודול הזה פותר.** בפרויקט הזה כבר יושבות תשע מערכות
שכל אחת מהן מודדת את עצמה היטב (`rig.acting.audit`, `rig.eyes.audit`,
`rig.principles.audit` וכן הלאה), וכולן עוברות. מה שלא היה אפשרי עד
עכשיו הוא לענות על השאלה הפשוטה: **האם הגרסה של היום טובה מזו של
אתמול, ובאיזה תחום בדיוק היא נסוגה?** בלי תשובה לזה, כל שיפור הוא
הצהרה, וכל רגרסיה נמצאת רק כשהיא מגיעה לסרטון.

---

## שלושת העקרונות שנאכפים כאן

**1 · ציון נגזר ממדידה קיימת, לא מדעה.** אין במודול הזה אפילו מספר
דקורטיבי אחד. ציון של קטגוריה הוא תמיד אחד משני דברים: שיעור
הבדיקות שעברו ב-`audit` של אותה מערכת, או ערך רציף שנמדד שם ועובר
דרך מדרון (`critics.ramp_up`/`ramp_down`/`band`) שגבולותיו כתובים
במפורש. כל ציון נושא איתו את **שמות** הראיות ששקללו אותו, ולכן
אפשר לפתוח אותו ולראות למה הוא מה שהוא.

**2 · "לא נמדד" אינו "נכשל", ו"אין מערכת" אינו "לא נמדד".** שלושה
מצבים ולא שניים, וזה הלקח של `selfheal` מ-30/09 בכיוון ההפוך:
מדידה שלא יצאה לדרך (חסר GLB, דפדפן לא נפתח) מסומנת `unmeasured`
ואינה נכנסת לממוצע כלל - אחרת תקלת סביבה נראית כמו נסיגה באיכות.
אבל קטגוריה שאין לה מערכת בכלל מקבלת **0 עם סיבה**, כי זה המצב
האמיתי שלה, וזה בדיוק מה שמדידת בסיס אמורה לחשוף.

**3 · הבסיס אינו נהרס.** `BASELINE_V0` נכתב פעם אחת. `freeze_v0`
מסרב לדרוס קובץ קיים אלא עם `force=True` מפורש, ובכל מקרה שומר
עותק `BASELINE_V0.<חותמת>.json` לפני. "Never destroy the baseline"
היא דרישה, לא המלצה.

---

## למה הממוצע משוקלל בהיקף הראיות ולא שווה לכולן

קטגוריה שיש בה 14 בדיקות חזקות וקטגוריה שיש בה שתיים אינן שוות
במשקל ההוכחה שלהן, ומיצוע פשוט נותן למדידה הדלה לקבוע את התוצאה.
`Report.mean` הוא ממוצע משוקלל ב-`weight` של כל קטגוריה, ו-`weight`
נגזר ממספר הראיות - לא נקבע בידיים. יש גם `mean_flat` לשקיפות,
כדי שאפשר לראות את שני המספרים.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
import time
import traceback
from dataclasses import dataclass, field, asdict
from datetime import datetime
from pathlib import Path
from typing import Callable

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from studio import critics as C                              # noqa: E402

#: איפה נשמרות המדידות. בתוך הפרויקט, כדי שהן ייכנסו למאגר הגרסאות.
STORE = ROOT / "production" / "baseline"

#: שם הבסיס המוגן.
V0 = "BASELINE_V0"


# ------------------------------------------------------------- מבנים

@dataclass
class Score:
    """ציון של קטגוריה אחת, עם הראיות שהולידו אותו."""

    key: str
    label: str
    value: float | None               # 0-100, או None כשלא נמדד
    state: str                        # measured / unmeasured / missing
    evidence: list[str] = field(default_factory=list)
    detail: dict = field(default_factory=dict)
    note: str = ""

    @property
    def weight(self) -> float:
        """משקל בממוצע = היקף הראיות, בתקרה של 1.0.

        קטגוריה עם ראיה אחת שווה חמישית מקטגוריה עם חמש. התקרה
        מונעת ממערכת שמחזירה ארבעים בדיקות להשתלט על הממוצע.
        """
        if self.state == "unmeasured":
            return 0.0
        if self.state == "missing":
            # מערכת שאינה קיימת נכנסת לממוצע במשקל מינימלי: היא
            # עובדה, אבל אין לה ראיות שמצדיקות משקל מלא.
            return 0.2
        return min(1.0, max(0.2, len(self.evidence) / 5.0))


@dataclass
class Report:
    """תמונת מצב מלאה של המערכת ברגע נתון."""

    tag: str
    at: str
    scores: list[Score]
    seconds: float = 0.0
    quality: str = "fast"

    def by_key(self) -> dict[str, Score]:
        return {s.key: s for s in self.scores}

    @property
    def measured(self) -> list[Score]:
        return [s for s in self.scores if s.state == "measured"]

    @property
    def scored(self) -> list[Score]:
        """מי משתתף בממוצע: נמדד, **וגם** 'אין מערכת' כאפס.

        זה היה באג אמיתי ולא דקדוק, והוא נתפס בבדיקה ולא בקריאת
        הקוד: הגרסה הראשונה מיצעה את `measured` בלבד, ולכן הבסיס
        דיווח ממוצע 95 בזמן ששתי מערכות מתוך שתים-עשרה (מצלמה
        ותאורה) לא היו קיימות כלל. ממוצע שמתעלם ממה שחסר הוא
        בדיוק ההטעיה שמדידת בסיס נועדה למנוע. "לא נמדד" כן יוצא
        מהממוצע - תקלת סביבה אינה נסיגה באיכות - ו"אין מערכת"
        נשאר בו עם משקל מינימלי, כי הוא עובדה על המערכת.
        """
        return [s for s in self.scores
                if s.state in ("measured", "missing") and s.value is not None]

    @property
    def mean(self) -> float:
        """ממוצע משוקלל בהיקף הראיות. 'לא נמדד' אינו משתתף."""
        ms = self.scored
        if not ms:
            return 0.0
        wsum = sum(s.weight for s in ms)
        if wsum <= 0:
            return 0.0
        return round(sum(s.value * s.weight for s in ms) / wsum, 1)

    @property
    def mean_flat(self) -> float:
        ms = self.scored
        return round(sum(s.value for s in ms) / len(ms), 1) if ms else 0.0

    def as_dict(self) -> dict:
        return {"tag": self.tag, "at": self.at, "quality": self.quality,
                "seconds": round(self.seconds, 2),
                "mean": self.mean, "mean_flat": self.mean_flat,
                "measured": len(self.measured), "scored": len(self.scored),
                "categories": len(self.scores),
                "scores": [asdict(s) for s in self.scores]}


def _report_from(d: dict) -> Report:
    scores = [Score(**{k: v for k, v in s.items()
                       if k in Score.__dataclass_fields__})
              for s in d.get("scores", [])]
    return Report(tag=d.get("tag", "?"), at=d.get("at", ""), scores=scores,
                  seconds=d.get("seconds", 0.0),
                  quality=d.get("quality", "fast"))


# ------------------------------------------------- גזירת ציון ממדידה

def from_checks(checks: dict, prefix: str = "") -> tuple[float, list[str]]:
    """ציון משיעור הבדיקות שעברו ב-`audit` שמחזיר טבלת checks.

    הצורה שכל ה-audit-ים כאן מחזירים היא
    ``{"שם": {"value":..., "limit":..., "pass": bool}}``, ולכן אין
    צורך לפרש כלום: סופרים.
    """
    items = [(k, v) for k, v in (checks or {}).items()
             if isinstance(v, dict) and "pass" in v]
    if not items:
        return 0.0, []
    ok = [k for k, v in items if bool(v["pass"])]
    ev = [f"{prefix}{k}{'' if k in ok else ' ✗'}" for k, _ in items]
    return round(100.0 * len(ok) / len(items), 1), ev


#: מדד רציף מתחת לזה נחשב **ראיה שנפלה** ומסומן ב-``✗``, בדיוק
#: כמו בדיקה בוליאנית ב-``from_checks``.
#:
#: למה בכלל צריך סימון, ולמה הוא נוסף כאן ולא בקורא: עד 07/10 היו
#: שני פורמטי ראיות בפרויקט הזה — ``from_checks`` סימן ``"שם ✗"``,
#: ו-``from_metrics`` החזיר ``"שם=0.265"`` בלי שום סימן. כל קורא
#: שחיפש ראיה שנפלה חיפש ``endswith("✗")``, ולכן **כל** המודדים
#: הרציפים (פנים, דיבור, גוף, ידיים, רגש) החזירו רשימת כשלים
#: ריקה — כלומר האבחון השורשי אמר "אין בדיקות שנפלו" על ממד
#: שנמדד 75.5. באג שקט לגמרי: אין חריגה, אין שגיאה, והמסקנה
#: הייתה שספר התיקונים ריק.
#:
#: הסף אינו 1.0 אלא 0.95: מדד רציף נוגע בשוליים מעוגלים, ו-0.997
#: אינו כשל שמישהו צריך לפתוח קובץ בשבילו. רשימת כשלים שמכילה
#: את כל מה שאינו מושלם היא רעש, ורעש מסתיר את ה-0.265.
EV_FAIL = 0.95


def from_metrics(ms: list[tuple[str, float]]) -> tuple[float, list[str]]:
    """ציון ממדדים רציפים שכבר נורמלו ל-0..1 בידי מדרון מוצהר.

    הראיה נושאת גם את הערך וגם את הפסק: ``"שם=0.265 ✗"``. הערך
    נשאר בתוך הראיה כדי שהאבחון יוכל לדרג — ראיה גרועה יותר היא
    זו שכדאי לפתוח קודם.
    """
    ms = [(k, v) for k, v in ms if v is not None and not _isnan(v)]
    if not ms:
        return 0.0, []
    val = sum(v for _, v in ms) / len(ms)
    ev = [f"{k}={round(v, 3)}" + ("" if v >= EV_FAIL else " ✗")
          for k, v in ms]
    return round(100.0 * max(0.0, min(1.0, val)), 1), ev


def ev_value(evidence: str) -> float | None:
    """הערך שבתוך ראיה בצורת ``"שם=0.265 ✗"``, או ``None``.

    ראיה בוליאנית (``"מצלמה/headroom ✗"``) אין בה ערך, וזה תקין —
    המדרג נופל אחורה לסדר שבו המודד רשם אותה.
    """
    txt = str(evidence).rstrip(" ✗")
    if "=" not in txt:
        return None
    try:
        return float(txt.rsplit("=", 1)[1])
    except (TypeError, ValueError):
        return None


def _isnan(x) -> bool:
    try:
        return math.isnan(float(x))
    except (TypeError, ValueError):
        return True


# ------------------------------------------------------ גלאי המדידות
# כל גלאי מחזיר (ציון, ראיות, פרטים) או זורק. חריגה = `unmeasured`.
# שום גלאי לא מקבל ציון במתנה: אם המערכת שלו אינה קיימת הוא מחזיר
# `None` בציון ואת הסיבה, וזה מתורגם ל-`missing` עם 0.

def _p_identity(q: str):
    from rig import dimorph
    d = dimorph.audit_shape(quality=q)
    sc, ev = from_checks(d.get("checks", {}), "צורה/")
    return sc, ev, {"pairs": d.get("pair", d.get("shape", {}))}


def _p_face(q: str):
    from rig import acting, arkit, face
    a = acting.audit()
    per = a.get("per_region", {})
    # שלוש ראיות מדידות: כמה אזורים נשלטים בנפרד, כמה יחידות תנועה
    # מוגדרות, וכמה ממשק ARKit-52 התקני מונע בפועל.
    #
    # **המדד השלישי תוקן (08/10), והוא לא מדד את מה שהתיימר למדוד.**
    # עד כאן הוא השווה את *מספר ה-blendshapes* (27) ל-52 משבצות
    # ARKit, וזו השוואה בין שני דברים שונים: הריג כאן היברידי
    # בכוונה, ורוב משבצות ARKit של עצימה, מבט, לסת וגבות מונעות
    # **בעצם** ולא בצורה - בדיוק כפי שהוחלט ב-TASK 02 אחרי דעת
    # המועצה. לכן ריג תקין לחלוטין נמדד 0.265 ונצבע כפער.
    #
    # מה שנמדד עכשיו הוא הדבר שבאמת חשוב לכלי חיצוני: כמה מ-52
    # שמות התקן באמת מניעים את הפנים. `shared` מקבל חצי ניקוד -
    # הוא **כן** מזיז, אך לא בנפרד לכל צד, וזו מגבלה אמיתית.
    # גבולות המדרון הם 0 ו-52, כלומר **התקן עצמו** ולא מספר
    # שנבחר כדי לעבור סף.
    cov = arkit.coverage()
    iface = cov["exact"] + 0.5 * cov["shared"]
    ms = [("אזורי פנים עצמאיים", C.ramp_up(len(per), 6, 10)),
          ("יחידות תנועה מוגדרות", C.ramp_up(a.get("named", 0), 24, 48)),
          ("ממשק ARKit-52 מונע", C.ramp_up(iface, 0, len(arkit.ARKIT_52)))]
    sc, ev = from_metrics(ms)
    # הפער נשאר **נראה** בראיות גם כשהציון עלה: משבצת נעדרת היא
    # מידע שצריך להישאר על השולחן, לא להיעלם בתוך ממוצע.
    ev = ev + [f"צורות פנים בריג={len(face.NAMES)}",
               f"מדויקים={cov['exact']} משותפי־צד={cov['shared']}",
               f"נעדרים מהתקן={cov['absent']}: "
               + ", ".join(arkit.absent())]
    return sc, ev, {"regions": len(per), "aus": a.get("named"),
                    "shapes": len(face.NAMES), "arkit": cov}


def _p_eyes(q: str):
    from rig import eyes
    d = eyes.audit()
    f = d.get("features", {})
    probs = d.get("problems", [])
    # הציון הוא שיעור הדרישות שהתקיימו: המודול עצמו מכריז על
    # `requirements` ועל `problems`, ולכן אין כאן שום פרשנות שלי.
    req = max(1, int(d.get("requirements", 1)))
    sc = round(100.0 * (req - len(probs)) / req, 1)
    ev = [f"דרישות={req}", f"כשלים={len(probs)}",
          f"קיבועים={f.get('fixations')}", f"מצמוצים={f.get('blinks')}",
          f"השהיית תגובה={f.get('reaction_latency')}"]
    # ``בעיה:`` היא בהגדרה ראיה שנפלה, ולכן היא נושאת את הסימן.
    # בלעדיו היא נראית לאבחון בדיוק כמו ראיה שעברה.
    return sc, ev + [f"בעיה: {p} ✗" for p in probs], {"features": f}


def _p_lipsync(q: str):
    from rig import speech
    a = speech.audit()
    fe = speech.features()
    dr = speech.drive_report()
    # "הפה אינו המנוע" הוא הדרישה של שלב 3, ולכן המדד המרכזי הוא
    # עד כמה ההנעה המכנית *אינה* מסבירה את הפנים. `sine_corr` גבוה
    # פירושו פה שנפתח לפי גלגל שיניים.
    mech = fe.get("sine_corr")
    base = fe.get("sine_corr_old")
    ms = [("ויזמות", C.ramp_up(a.get("visemes", 0), 8, 14)),
          ("פונמות ממופות", C.ramp_up(a.get("phonemes", 0), 20, 34)),
          ("קולות רגש", C.ramp_up(a.get("emotions", 0), 5, 10))]
    if mech is not None:
        ms.append(("אינו מכני", C.ramp_down(abs(float(mech)), 0.25, 0.75)))
    # **וגם ההשתפרות מול הבסיס המכני, ולא רק הערך המוחלט.**
    # `sine_corr_old` הוא בדיוק מה שפה שנפתח לפי גלגל שיניים היה
    # מחזיר (נמדד 0.92), ו-`sine_corr` הוא מה שהמנוע מחזיר בפועל
    # (0.45). היחס ביניהם מודד את מה שהדרישה ביקשה - שהדיבור
    # לא יהיה המנוע - ואילו ערך מוחלט לבדו תלוי גם באורך המשפט.
    if mech is not None and base:
        drop = 1.0 - abs(float(mech)) / abs(float(base))
        ms.append(("ריחוק מהנעה מכנית", C.ramp_up(drop, 0.15, 0.60)))
    sc, ev = from_metrics(ms)
    return sc, ev, {"audit": a, "mechanical": mech, "mechanical_base": base,
                    "drive": {k: v for k, v in list(dr.items())[:6]}}


def _p_body(q: str):
    from rig import body
    d = body.audit()
    bad = (len(d.get("controls_missing", [])) +
           len(d.get("intentions_missing", [])) +
           len(d.get("illegal_plays", [])))
    ms = [("סוגי מחווה", C.ramp_up(d.get("kinds", 0), 4, 8)),
          ("כוונות", C.ramp_up(d.get("intentions", 0), 6, 10)),
          ("עמידות", C.ramp_up(d.get("shapes", 0), 8, 15)),
          ("בלי חורים בטבלה", 1.0 if bad == 0 else 0.0)]
    sc, ev = from_metrics(ms)
    return sc, ev, d


def _p_hands(q: str):
    from rig import body, controls
    d = body.audit()
    # ידיים ואצבעות הן תת-מערכת נפרדת, ולכן נמדדות בנפרד: כמה
    # ערוצי אצבע קיימים, וכמה צורות יד הטבלה באמת מגדירה.
    fing = [k for k in controls.CONTROLS
            if any(t in k for t in ("finger", "thumb", "index", "curl",
                                    "spread", "hand"))]
    shapes = int(d.get("shapes", 0))
    ms = [("ערוצי יד ואצבע", C.ramp_up(len(fing), 6, 14)),
          ("צורות יד מוגדרות", C.ramp_up(shapes, 8, 15))]
    sc, ev = from_metrics(ms)
    return sc, ev, {"finger_controls": sorted(fing)[:20], "shapes": shapes}


def _p_emotion(q: str):
    from rig import emotion
    d = emotion.audit()
    probs = d.get("problems", [])
    ms = [("רגשות", C.ramp_up(d.get("emotions", 0), 8, 16)),
          ("כוונות", C.ramp_up(d.get("intentions", 0), 6, 10)),
          ("סצנות נבדקות", C.ramp_up(d.get("scenes", 0), 4, 8)),
          ("בלי כשלים", 1.0 if not probs else 0.0)]
    sc, ev = from_metrics(ms)
    return sc, ev, d


def _p_animation(q: str):
    from rig import principles
    d = principles.audit()
    n = max(1, int(d.get("measured", 1)))
    sc = round(100.0 * int(d.get("passed", 0)) / n, 1)
    ev = [f"{r['principle']}{'' if r['ok'] else ' ✗'}"
          for r in d.get("results", [])]
    if d.get("missing"):
        ev += [f"חסר: {m} ✗" for m in d["missing"]]
    return sc, ev, {"passed": d.get("passed"), "measured": n}


def _p_camera(q: str):
    """בימוי מצלמה - שלב 9.

    הקיים כאן עד עכשיו הוא **רציפות** (`rig.cinema`), כלומר האם
    המצלמה לא שוברת את הסצנה. מה שאינו קיים הוא **בימוי**: בחירת
    סוג שוט וזווית מתוך חלופות לפי מטרה רגשית. אם המודול קיים -
    הציון מגיע ממבחן הקבלה שלו; אם לא - 0 עם סיבה, ולא "לא נמדד".
    """
    try:
        from rig import camera as cam_mod
    except ImportError:
        return None, [], {"why": "אין מודול בימוי מצלמה"}
    d = cam_mod.audit()
    sc, ev = from_checks(d.get("checks", {}), "מצלמה/")
    return sc, ev, {"strategies": d.get("strategies"),
                    "passed": d.get("passed")}


def _p_lighting(q: str):
    """תאורה ומראה - שלב 10."""
    try:
        from rig import look
    except ImportError:
        return None, [], {"why": "אין ספר סגנון"}
    d = look.audit()
    sc, ev = from_checks(d.get("checks", {}), "תאורה/")
    return sc, ev, {"moods": d.get("moods"), "passed": d.get("passed")}


def _p_rendering(q: str):
    from rig import appeal
    chars = _chars(appeal)
    if not chars:
        raise RuntimeError("אין דמויות מרוגגות למדידה")
    d = appeal.evaluate(chars)
    sc, ev = from_checks(d.get("checks", {}), "מראה/")
    return sc, ev, {"chars": [c.name for c in chars],
                    "seconds": d.get("seconds")}


def _p_continuity(q: str):
    from rig import cinema, duet
    a = cinema.audit()
    b = duet.audit()
    sa, ea = from_checks(a.get("checks", {}), "שקט/")
    sb, eb = from_checks(b.get("checks", {}), "דואט/")
    # שתי המערכות נמדדות יחד כי שתיהן בודקות את אותו דבר מזוויות
    # שונות: האם הרגש מחזיק מעבר לשורה ובין שתי דמויות.
    na, nb = len(ea), len(eb)
    sc = round((sa * na + sb * nb) / max(1, na + nb), 1)
    return sc, ea + eb, {"silent_passed": a.get("passed"),
                         "duet_passed": b.get("passed")}


def _chars(appeal_mod, names=("lucas", "maya")):
    """טוען דמויות מרוגגות אם הן קיימות על הדיסק, ואחרת רשימה ריקה."""
    out = []
    for n in names:
        if (appeal_mod.RIG_DIR / f"{n}.glb").exists():
            try:
                out.append(appeal_mod.Char(n, appeal_mod.RIG_DIR))
            except Exception:
                pass
    return out


# ------------------------------------------------- שתים-עשרה הקטגוריות

@dataclass(frozen=True)
class Cat:
    key: str
    label: str
    probe: Callable[[str], tuple]


CATEGORIES: tuple[Cat, ...] = (
    Cat("identity",    "זהות הדמות",        _p_identity),
    Cat("face",        "איכות הפנים",       _p_face),
    Cat("eyes",        "משחק עיניים",       _p_eyes),
    Cat("lipsync",     "סינכרון דיבור",     _p_lipsync),
    Cat("body",        "תנועת גוף",         _p_body),
    Cat("hands",       "תנועת ידיים",       _p_hands),
    Cat("emotion",     "הבעה רגשית",        _p_emotion),
    Cat("animation",   "איכות אנימציה",     _p_animation),
    Cat("camera",      "מצלמה",             _p_camera),
    Cat("lighting",    "תאורה",             _p_lighting),
    Cat("rendering",   "רינדור ומראה",      _p_rendering),
    Cat("continuity",  "רציפות",            _p_continuity),
)


def measure(quality: str = "fast", only: list[str] | None = None,
            tag: str = "wip") -> Report:
    """מריץ את כל הגלאים ומחזיר תמונת מצב.

    גלאי שזרק חריגה אינו מפיל את המדידה כולה - הקטגוריה שלו
    מסומנת `unmeasured` עם השגיאה. מדידה שנופלת בגלל קטגוריה
    אחת היא מדידה שלא תרוץ בלילה שבו היא באמת נחוצה.
    """
    t0 = time.time()
    scores: list[Score] = []
    for cat in CATEGORIES:
        if only and cat.key not in only:
            continue
        try:
            sc, ev, detail = cat.probe(quality)
        except Exception as exc:                    # noqa: BLE001
            scores.append(Score(cat.key, cat.label, None, "unmeasured",
                                note=f"{type(exc).__name__}: {exc}"[:200],
                                detail={"traceback":
                                        traceback.format_exc()[-400:]}))
            continue
        if sc is None:
            scores.append(Score(cat.key, cat.label, 0.0, "missing",
                                evidence=ev, detail=detail,
                                note=detail.get("why", "המערכת אינה קיימת")))
        else:
            scores.append(Score(cat.key, cat.label, float(sc), "measured",
                                evidence=ev, detail=detail))
    return Report(tag=tag, at=datetime.now().isoformat(timespec="seconds"),
                  scores=scores, seconds=time.time() - t0, quality=quality)


# -------------------------------------------------------- שמירה וטעינה

def path_of(tag: str) -> Path:
    return STORE / f"{tag}.json"


def save(rep: Report, tag: str | None = None) -> Path:
    """שומר מדידה. **מסרב** לדרוס את הבסיס המוגן דרך המסלול הרגיל."""
    tag = tag or rep.tag
    if tag == V0:
        raise ValueError("הבסיס המוגן נשמר רק דרך freeze_v0")
    STORE.mkdir(parents=True, exist_ok=True)
    p = path_of(tag)
    rep.tag = tag
    p.write_text(json.dumps(rep.as_dict(), ensure_ascii=False, indent=1),
                 encoding="utf-8")
    return p


def load(tag: str) -> Report | None:
    p = path_of(tag)
    if not p.exists():
        return None
    try:
        return _report_from(json.loads(p.read_text(encoding="utf-8")))
    except (ValueError, OSError):
        return None


def freeze_v0(rep: Report, force: bool = False) -> tuple[Path, str]:
    """כותב את BASELINE_V0.

    הבסיס אינו נהרס: אם הוא קיים, הכתיבה נדחית אלא אם ביקשו
    במפורש, ובכל מקרה נשמר עותק מתוארך של הקודם לפני הדריסה.
    """
    STORE.mkdir(parents=True, exist_ok=True)
    p = path_of(V0)
    if p.exists() and not force:
        return p, "קיים - לא נדרס"
    kept = ""
    if p.exists():
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        keep = STORE / f"{V0}.{stamp}.json"
        keep.write_text(p.read_text(encoding="utf-8"), encoding="utf-8")
        kept = f" (הקודם נשמר כ-{keep.name})"
    rep.tag = V0
    p.write_text(json.dumps(rep.as_dict(), ensure_ascii=False, indent=1),
                 encoding="utf-8")
    return p, "נכתב" + kept


# --------------------------------------------------------- השוואה

#: מתחת לזה נסיגה אינה נסיגה אלא רעש מדידה. נגזר מכך שהציונים
#: כאן הם שיעורי מעבר על טבלאות של 8-14 בדיקות, ולכן בדיקה אחת
#: שווה 7-12 נקודות; חצי נקודה אינה יכולה להיות שינוי אמיתי.
NOISE = 0.6


def compare(new: Report, base: Report) -> dict:
    """דלתא לכל קטגוריה, מול הבסיס.

    שלוש תוצאות ולא שתיים, וההבדל חשוב: `regressed` הוא נסיגה
    אמיתית, `lost` הוא קטגוריה שהייתה נמדדת ועכשיו אינה נמדדת
    (כלומר תקלת מדידה, שאינה נסיגה באיכות אבל כן מידע שאבד),
    ו-`gained` הוא מה שנוסף.
    """
    nb, bb = new.by_key(), base.by_key()
    rows, regressed, improved, lost, gained = [], [], [], [], []
    for key in sorted(set(nb) | set(bb)):
        n, b = nb.get(key), bb.get(key)
        row = {"key": key,
               "label": (n or b).label,
               "base": None if (b is None or b.value is None) else b.value,
               "new": None if (n or Score("", "", None, "")).value is None
               else n.value,
               "base_state": b.state if b else "absent",
               "new_state": n.state if n else "absent"}
        if row["base"] is not None and row["new"] is not None:
            row["delta"] = round(row["new"] - row["base"], 1)
            if row["delta"] < -NOISE:
                regressed.append(key)
            elif row["delta"] > NOISE:
                improved.append(key)
        else:
            row["delta"] = None
            if b and b.state == "measured" and (not n or n.state != "measured"):
                lost.append(key)
            if n and n.state == "measured" and (not b or b.state != "measured"):
                gained.append(key)
        rows.append(row)
    return {"base_tag": base.tag, "new_tag": new.tag,
            "base_mean": base.mean, "new_mean": new.mean,
            "mean_delta": round(new.mean - base.mean, 1),
            "rows": rows, "regressed": regressed, "improved": improved,
            "lost_measurement": lost, "newly_measured": gained,
            "ok": not regressed and not lost}


def gate(new: Report, base_tag: str = V0) -> dict:
    """שער הקבלה של שלב 1: אפשר להשוות כל גרסה מול הבסיס.

    מחזיר `ok=False` אם אין בסיס בכלל - זה לא כשל איכות, זה
    כשל קיום, והוא חייב להיראות אחרת.
    """
    base = load(base_tag)
    if base is None:
        return {"ok": False, "why": f"אין בסיס בשם {base_tag}"}
    cmp = compare(new, base)
    cmp["ok"] = bool(cmp["ok"])
    return cmp


# ------------------------------------------------------------- הדפסה

def _bar(v: float | None, w: int = 20) -> str:
    if v is None:
        return "·" * w
    n = int(round(w * max(0.0, min(100.0, v)) / 100.0))
    return "█" * n + "░" * (w - n)


def render_text(rep: Report, cmp: dict | None = None) -> str:
    out = [f"=== מדידת בסיס · {rep.tag} · {rep.at} ==="]
    for s in rep.scores:
        if s.state == "measured":
            mark, val = "✓", f"{s.value:5.1f}"
        elif s.state == "missing":
            mark, val = "✗", "  0.0"
        else:
            mark, val = "?", "   --"
        line = f" {mark} {s.label:14s} {val} {_bar(s.value if s.state != 'unmeasured' else None)}"
        if cmp and cmp.get("rows"):
            row = next((r for r in cmp["rows"] if r["key"] == s.key), None)
            if row and row.get("delta") is not None:
                d = row["delta"]
                line += f"  {'+' if d > 0 else ''}{d}"
        out.append(line)
        if s.note:
            out.append(f"      {s.note}")
        if s.evidence:
            bad = [e for e in s.evidence if e.endswith("✗")
                   or e.startswith("בעיה") or e.startswith("חסר")]
            out.append(f"      ראיות: {len(s.evidence)}"
                       + (f" · כשלו: {', '.join(bad[:4])}" if bad else ""))
    out.append(f"\nממוצע משוקלל: {rep.mean} · ממוצע פשוט: {rep.mean_flat} "
               f"· נמדדו {len(rep.measured)}/{len(rep.scores)} "
               f"· {round(rep.seconds, 1)}ש")
    if cmp:
        if "why" in cmp:
            out.append(f"השוואה: {cmp['why']}")
        else:
            out.append(f"מול {cmp['base_tag']}: {cmp['base_mean']} → "
                       f"{cmp['new_mean']} ({cmp['mean_delta']:+})")
            if cmp["regressed"]:
                out.append("נסיגה: " + ", ".join(cmp["regressed"]))
            if cmp["improved"]:
                out.append("שיפור: " + ", ".join(cmp["improved"]))
            if cmp["lost_measurement"]:
                out.append("אבדה מדידה: " + ", ".join(cmp["lost_measurement"]))
            if cmp["newly_measured"]:
                out.append("נמדד לראשונה: " + ", ".join(cmp["newly_measured"]))
    return "\n".join(out)


def main(argv=None) -> int:
    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(description="שלב 1 · מדידת בסיס")
    ap.add_argument("--tag", default="wip", help="שם המדידה")
    ap.add_argument("--quality", default="fast", choices=("fast", "full"))
    ap.add_argument("--only", default="", help="קטגוריות, מופרדות בפסיק")
    ap.add_argument("--freeze-v0", action="store_true",
                    help="לקבע את המדידה הזו כבסיס המוגן")
    ap.add_argument("--force", action="store_true",
                    help="לדרוס בסיס קיים (נשמר עותק)")
    ap.add_argument("--against", default=V0, help="מול מה להשוות")
    ap.add_argument("--no-save", action="store_true")
    a = ap.parse_args(argv)

    only = [s.strip() for s in a.only.split(",") if s.strip()] or None
    rep = measure(quality=a.quality, only=only, tag=a.tag)

    cmp = None
    if a.freeze_v0:
        p, how = freeze_v0(rep, force=a.force)
        print(f"BASELINE_V0: {how} → {p}")
    else:
        if not a.no_save:
            print(f"נשמר: {save(rep, a.tag)}")
        cmp = gate(rep, a.against)

    print(render_text(rep, cmp))
    if cmp and not cmp.get("ok", True) and "why" not in cmp:
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
