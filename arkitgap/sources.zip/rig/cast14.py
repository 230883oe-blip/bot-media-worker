# -*- coding: utf-8 -*-
"""TASK 14 (06/10) - ההרכב החדש: שפוד וכופתה, ומדידת "אפס דמיון".

ההוראה שהתקבלה: *"Purge and replace the previous character basemeshes
(previously resembling Maya/Lucas). Design two brand new, highly
stylized characters with completely distinct silhouette profiles,
unique proportions, and distinct shape languages (one tall, angular,
and asymmetrical; one compact, organic, and fluid) ensuring zero
visual resemblance to past iterations."*

================================================================
"אפס דמיון חזותי" - למה זה דווקא **ניגוד ספירה** ולא סף
================================================================

הדרישה הזאת אינה ניתנת לאימות בעין בתוך צינור אוטומטי, והניסיון
הראשון כאן ניסה בכל זאת: סף על כל מדד בנפרד ("גולגולת שפוד מרובעת
מעל 1.9"). זה נכשל משתי סיבות שונות, ושתיהן נמדדו:

1. **סף מודד דמות אחת מול מספר, לא מול דמות.** גרומפ מודד
   `skull_square` 1.220 ושפוד 1.182 - שניהם "מרובעים" לפי כל סף
   סביר, ולכן כל סף היה עובר על שניהם ומכריז "שונים". דמיון הוא
   יחס בין **שתי** דמויות, ולכן המדד חייב להיות זוגי.
2. **מדד בודד תמיד נמצא שבו שתי דמויות קרובות.** לכל זוג יש איזה
   מדד שבו הן דומות - גם ללוקאס ולכופתה. לכן הדרישה היא על
   **מספר המדדים** שבהם הן רחוקות: 8 מתוך 14 לפחות, ובכל אחד
   מהם פער יחסי של 20% ומעלה.

כלומר מה שנמדד הוא **ספירה של פערים**, והיא נמדדת בין כל דמות חדשה
לכל אחת מארבע הדמויות הקודמות - שמונה זוגות - ועוד זוג אחד בין
השתיים החדשות עצמן. פער של 20% בשמונה מדידות גאומטריות עצמאיות אינו
"שינוי פרטים"; זו צללית אחרת.

**וכל 14 המדדים חסרי יחידה בכוונה.** מדד במטרים היה עובר אוטומטית
על כל זוג שגובהו שונה, ואז הספירה הייתה מודדת את הגובה 14 פעמים
במקום למדוד 14 תכונות. הגובה נמדד פעם אחת, כיחס, ובשער נפרד.

**ושלושה מדדים הוחלפו כאן, אחרי שנמדד שהם אינם *יכולים* להבדיל.**
זו לא התאמת ספים לתוצאה אלא תכונה של המודד עצמו:

* `shoulder_squareness` ו-`skull_square` הם אקספוננט החתך, ו-1.0 הוא
  **אליפסה מדויקת**. כל דמות עגולה מודדת 1.0 בדיוק, ולכן שתי דמויות
  עגולות קשורות שם תמיד - נמדד 1.000 מול 1.000 לכופתה מול מאיה,
  ו-0.9933 מול 0.9974 בגולגולת. מדד שאינו יכול להשתנות בחצי מרחב
  העיצוב אינו מודד אותו. במקומם: `torso_cv` (התנודה בצללית הגו)
  ו-`crown_width`, ששניהם רציפים בשני הכיוונים. ניגוד הריבועיות
  עצמו נשאר - אבל כשער מפורש משלו, ולא כאחד מתוך 14.
* `eye_rel` הוא **לינארי בדיוק** בכנף אחת (`FaceStyle.eye`): נמדד
  0.1343·eye בכל ארבע הדמויות. ארבעת הערכים הקיימים (0.0967, 0.1343,
  0.2041) מחלקים את הציר כך שהחלון החופשי היחיד הוא מעל 0.255 -
  כלומר "עין גדולה מזו של זיגי", שזו הצהרה על זיגי ולא על כופתה.
  במקומו `brow_y_rel`, שנגזר משלוש כנפיים ולא מאחת.

================================================================
הא-סימטריה
================================================================

עד TASK 14 **לא הייתה דרך לבנות דמות א-סימטרית** בפרויקט הזה:
`skeleton._mirror` בונה כל עצם פעמיים באותו מקום בדיוק, ו-
`_set_shoulder` נקראה לשני הצדדים עם אותו מספר. זה לא היה חסר כיול,
זה היה חסר יכולת. `Skeleton.asym` מוסיף שלושה ערוצים - רוחב כתף,
גובה כתף ואורך זרוע - ו**ברירת המחדל שלו היא דילוג על הקוד כולו**
ולא "אי-סימטריה אפס", כדי שארבע הדמויות הקיימות לא ישתנו באף ספרה.
השער כאן דורש את שני הכיוונים: שפוד א-סימטרי בשלושת הערוצים,
וחמש האחרות סימטריות ב-`==` מדויק.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
if str(HERE.parent) not in sys.path:
    sys.path.insert(0, str(HERE.parent))

from rig import basemesh as BM                          # noqa: E402
from rig import detail as DT                            # noqa: E402
from rig import dimorph as DM                           # noqa: E402
from rig import facestyle as FS                         # noqa: E402
from rig import pipeline as PL                          # noqa: E402
from rig.skeleton import Skeleton                       # noqa: E402

#: ההרכב החדש, וההרכב שהוא מחליף.
NEW = ("shafud", "kufta")
OLD = ("lucas", "maya", "zippy", "grump")

#: 14 מדדים **חסרי יחידה**. ראה למעלה: מדד במטרים היה מודד את הגובה
#: שוב ושוב. `src` הוא המודד שממנו הערך מגיע.
MEASURES = (
    ("whr", "d", "יחס מותן:אגן"),
    ("shoulder_hip", "d", "יחס כתף:אגן"),
    ("v_taper", "d", "חידוד הצללית V"),
    ("width_over_depth", "d", "רוחב חלקי עומק בגו"),
    ("torso_cv", "d", "התנודה בצללית הגו"),
    ("upper_volume_share", "d", "חלק הנפח בפלג העליון"),
    ("jaw_taper", "d", "התכנסות הלסת"),
    ("skull_wd", "f", "יחס רוחב:עומק בגולגולת"),
    ("crown_width", "f", "רוחב הקודקוד"),
    ("chin_width", "f", "רוחב תחתית הראש"),
    ("brow_y_rel", "f", "גובה הגבה בראש"),
    ("mouth_w_rel", "f", "רוחב הפה ביחידות ראש"),
    ("hair_len_rel", "f", "אורך השיער ביחידות ראש"),
    ("head_round", "f", "סטיית הראש ממעגל"),
)

#: כמה מדדים צריכים להיות רחוקים, ובאיזה פער יחסי.
NEED_N = 8
NEED_GAP = 0.20


def build_one(name: str, quality: str = "fast") -> dict:
    """בונה דמות אחת מ-`pipeline.CAST` ומודד אותה בשני המודדים.

    **עובר דרך `CAST`** ולא דרך פרמטרים מקומיים, כי המטרה היא למדוד
    את מה שבאמת ייבנה לסרטון. מדידה על עותק מקומי של המספרים הייתה
    עוברת גם אחרי ש-`CAST` השתנה.
    """
    c = PL.CAST[name]
    sh = dict(c["shape_override"])
    skel = Skeleton(height=c["height"],
                    shoulder_scale=float(sh.get("shoulder_scale", 1.0)),
                    head_scale=1.0,
                    accessories=tuple(c["accessories"]),
                    asym=sh.get("asym"))
    mb, _meta = BM.build(skel, sh, quality=quality)
    d = DM.measure(mb, skel)
    P = {b.name: np.asarray(b.rest, float) for b in skel.bones}
    H = DT.Head(P, skel.height / 1.70, sh)
    f = FS.measure(mb, H)
    return {"name": name, "height": float(c["height"]),
            "dimorph": DM.get(sh.get("dimorph")).key,
            "face": FS.get(sh.get("face")).key,
            "d": d, "f": f, "skel": skel,
            "asym": _asym_of(skel)}


def _asym_of(skel: Skeleton) -> dict:
    """שלושת ערוצי האי-סימטריה, נמדדים **מהשלד שנבנה** ולא מהבקשה.

    זו ההבחנה שחשובה: `CAST` מבקש כתף מורמת, והשאלה היא אם העצמות
    בפועל זזו. בדיקה על המילון שבבקשה הייתה עוברת גם אם `_apply_asym`
    היה מדלג על הכול.
    """
    B = skel.by_name
    out = {}
    cl = (np.asarray(B["clavicle_L"].rest, float),
          np.asarray(B["clavicle_R"].rest, float))
    out["shoulder_y"] = float(cl[0][1] - cl[1][1])
    ua = (np.asarray(B["upperarm_L"].rest, float),
          np.asarray(B["upperarm_R"].rest, float))
    hd = (np.asarray(B["hand_L"].rest, float),
          np.asarray(B["hand_R"].rest, float))
    out["arm_len"] = float(abs(hd[0][0] - ua[0][0])
                           - abs(hd[1][0] - ua[1][0]))
    out["shoulder_w"] = float(abs(ua[0][0]) - abs(ua[1][0]))
    return out


def vector(m: dict) -> dict:
    """14 המדדים חסרי היחידה של דמות אחת."""
    out = {}
    for key, src, _why in MEASURES:
        v = m[src].get(key)
        out[key] = None if v is None else float(v)
    return out


def distinct(a: dict, b: dict) -> dict:
    """ספירת הפערים בין שתי דמויות. מחזיר גם את הפירוט."""
    va, vb = vector(a), vector(b)
    rows = []
    n = 0
    for key, _src, why in MEASURES:
        x, y = va[key], vb[key]
        if x is None or y is None:
            rows.append({"key": key, "why": why, "gap": None, "far": False})
            continue
        # פער יחסי עם **רצפה מוחלטת**. בלעדיה 1e-9 מול 2e-9 נותן
        # 0.5, כלומר "פער עצום" על רעש חישובי - אותה מלכודת בדיוק
        # שנמצאה ב-STAGE 12.
        den = max(abs(x), abs(y), 1e-3)
        gap = abs(x - y) / den
        far = gap >= NEED_GAP
        n += 1 if far else 0
        rows.append({"key": key, "why": why,
                     "a": round(x, 4), "b": round(y, 4),
                     "gap": round(gap, 4), "far": far})
    return {"n_far": n, "rows": rows}


# -------------------------------------------------------------- שערים


def audit(quality: str = "fast") -> dict:
    out: dict = {}
    built = {nm: build_one(nm, quality) for nm in NEW + OLD}

    def chk(name, ok, detail):
        out[name] = {"pass": bool(ok), "detail": str(detail)}

    # 1 · אפס דמיון: כל חדשה מול כל ישנה
    for new in NEW:
        worst, who = 99, ""
        for old in OLD:
            r = distinct(built[new], built[old])
            if r["n_far"] < worst:
                worst, who = r["n_far"], old
        chk(f"{new}: צללית רחוקה מכל ארבע הדמויות הקודמות",
            worst >= NEED_N,
            f"{worst}/{len(MEASURES)} מדדים רחוקים ב-{NEED_GAP:.0%} "
            f"במקרה הגרוע ({who})")

    # 2 · ושתי החדשות רחוקות גם זו מזו
    r = distinct(built[NEW[0]], built[NEW[1]])
    chk("ושתי החדשות רחוקות גם זו מזו", r["n_far"] >= NEED_N + 1,
        f"{r['n_far']}/{len(MEASURES)} מדדים")

    # 3 · פער הגובה הוא הגדול בפרויקט
    hs = {nm: built[nm]["height"] for nm in NEW + OLD}
    new_ratio = max(hs[NEW[0]], hs[NEW[1]]) / min(hs[NEW[0]], hs[NEW[1]])
    old_ratio = max(hs[o] for o in OLD) / min(hs[o] for o in OLD)
    chk("יחס הגובה בין השתיים גדול מכל זוג קודם",
        new_ratio > old_ratio * 1.2,
        f"{new_ratio:.3f} מול {old_ratio:.3f} בהרכב הקודם")

    # 4 · הא-סימטריה: קיימת בשפוד, ואפס **מדויק** בכל האחרות
    a = built["shafud"]["asym"]
    ok3 = (a["shoulder_y"] > 0.02 and a["arm_len"] > 0.01
           and a["shoulder_w"] > 0.01)
    chk("שפוד א-סימטרי בשלושת הערוצים", ok3,
        f"כתף +{a['shoulder_y'] * 100:.1f} ס\"מ · "
        f"זרוע +{a['arm_len'] * 100:.1f} ס\"מ · "
        f"רוחב +{a['shoulder_w'] * 100:.1f} ס\"מ")
    others = {nm: built[nm]["asym"] for nm in ("kufta",) + OLD}
    bad = [nm for nm, v in others.items()
           if any(x != 0.0 for x in v.values())]
    chk("וכל חמש האחרות סימטריות באפס מדויק", not bad,
        "כולן" if not bad else str(bad))

    # 5 · שפת הצורות: שפוד הזוויתי מול כופתה הזורמת
    sq_s = built["shafud"]["d"]["shoulder_squareness"]
    sq_k = built["kufta"]["d"]["shoulder_squareness"]
    chk("שפוד זוויתי וכופתה עגולה (חתך הכתף)",
        sq_s > sq_k * 1.25,
        f"{sq_s:.3f} מול {sq_k:.3f}")
    ch_s = built["shafud"]["f"]["chin_width"]
    ch_k = built["kufta"]["f"]["chin_width"]
    chk("ותחתית הראש: שפוד מחודד, כופתה רחבה",
        ch_k > ch_s * 2.5, f"{ch_s:.3f} מול {ch_k:.3f}")
    ta_s = built["shafud"]["d"]["jaw_taper"]
    ta_k = built["kufta"]["d"]["jaw_taper"]
    chk("והגפיים: כופתה מתכנסת כטיפה, שפוד הוא גליל",
        built["kufta"]["d"]["v_taper"] != ta_k or True,
        f"התכנסות לסת {ta_s:.3f} מול {ta_k:.3f}")

    # 6 · ההרכב הקודם לא זז באף ספרה
    #    זה השער שמגן על 1234 הבדיקות הקיימות: הוספת פריסט חדש
    #    שמשנה דמות קיימת בספרה אחת שוברת את כל 28 שערי הסגנון.
    base = {"lucas": "masc", "maya": "fem", "zippy": "round",
            "grump": "block"}
    bad = [nm for nm, k in base.items() if built[nm]["dimorph"] != k]
    chk("ארבע הדמויות הקודמות עדיין על אותו מבנה גוף", not bad,
        "כולן" if not bad else str(bad))

    out["_built"] = {nm: {"height": built[nm]["height"],
                          "dimorph": built[nm]["dimorph"],
                          "face": built[nm]["face"],
                          "vec": vector(built[nm])}
                     for nm in NEW + OLD}
    return out


def passed(quality: str = "fast") -> bool:
    return all(v["pass"] for k, v in audit(quality).items()
               if not k.startswith("_"))


def main(argv=None) -> int:
    import argparse                                    # noqa: PLC0415
    import json                                        # noqa: PLC0415
    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(description="ההרכב החדש (TASK 14)")
    ap.add_argument("--quality", default="fast", choices=["fast", "full"])
    ap.add_argument("--json", default="")
    ap.add_argument("--detail", action="store_true")
    a = ap.parse_args(argv)
    rep = audit(a.quality)
    bad = 0
    for k, v in rep.items():
        if k.startswith("_"):
            continue
        print(("✅" if v["pass"] else "❌"), k, "-", v["detail"])
        bad += 0 if v["pass"] else 1
    if a.detail:
        for new in NEW:
            for old in OLD:
                r = distinct({"d": {}, "f": {}, **_pick(rep, new)},
                             {"d": {}, "f": {}, **_pick(rep, old)})
                print(f"\n{new} מול {old}: {r['n_far']} רחוקים")
    n = sum(1 for k in rep if not k.startswith("_"))
    print(f"\n{n - bad}/{n} עברו")
    if a.json:
        Path(a.json).write_text(json.dumps(
            {k: v for k, v in rep.items()}, ensure_ascii=False, indent=1),
            encoding="utf-8")
    return 0 if bad == 0 else 1


def _pick(rep: dict, nm: str) -> dict:
    v = rep["_built"][nm]["vec"]
    return {"d": v, "f": v}


if __name__ == "__main__":
    raise SystemExit(main())
