# -*- coding: utf-8 -*-
"""צינור הדמות: מתמונה/רשת ייחוס -> נכס GLB מרוגג, מוכן להפקה.

מה שהיה כאן קודם: תמונה של דמות + הזזת פיקסלים, ואחר כך רשת סרוקה
מתמונה בלי שלד, שבה "פתיחת פה" הייתה דחיפת קודקודים ו"סיבוב ראש"
היה סיבוב כל המודל. שתיהן נשברות ברגע שמזיזים את המצלמה.

מה שיש כאן: דמות שנבנית סביב שלד של 69 עצמות, עם עור, ריג פנים,
אצבעות, IK ותנועה משנית - ושאותה אפשר להציב בכל פוזה מכל זווית בלי
שהזהות תזוז, כי הצורה לא נגזרת מהתמונה בזמן ההצגה.

התמונה והרשת שנוצרו מ-AI משמשות **רק** כמקור פרמטרי זהות (מידות
וצבעים), ולא כגאומטריה.
"""
from __future__ import annotations

import json
import time
from pathlib import Path

import numpy as np

from . import acting, basemesh, controls, face, glbio, identity
from .skeleton import Skeleton

DEFAULT_PALETTE = {
    "skin": [0.91, 0.74, 0.62],
    "hair": [0.28, 0.17, 0.12],
    "brow": [0.20, 0.12, 0.09],
    "eye_white": [0.95, 0.95, 0.96],
    "iris": [0.26, 0.42, 0.52],
    "shirt": [0.22, 0.40, 0.62],
    "pants": [0.19, 0.21, 0.27],
    "shoe": [0.12, 0.12, 0.14],
    "lip": [0.74, 0.44, 0.42],
    "tongue": [0.72, 0.33, 0.35],
}


# ------------------------------------------------------------ פרמטרי זהות


def shape_from_reference(ref_glb: str | Path | None) -> dict:
    """מודד את רשת הייחוס ומחזיר פרמטרי זהות. אם אין רשת - ברירת מחדל.

    נמדד כאן: Hunyuan3D מחזיר לפעמים חזה (ראש+כתפיים) ולפעמים גוף שלם.
    יחס הגובה לרוחב הוא מה שמפריד ביניהם בצורה יציבה; זיהוי "צוואר"
    לפי היצרות החתך נכשל, כי שיער שיורד לכתפיים לא מצר שום דבר.
    """
    shape = {"head_width": 1.0, "girth": 1.0, "shoulder_scale": 1.0,
             "source": "default"}
    if not ref_glb:
        return shape
    p = Path(ref_glb)
    if not p.exists():
        return shape
    try:
        pos = glbio.first_mesh_positions(p)
    except Exception as e:                                  # noqa: BLE001
        shape["source"] = f"קריאת הרשת נכשלה: {type(e).__name__}"
        return shape
    lo, hi = pos.min(axis=0), pos.max(axis=0)
    size = hi - lo
    aspect = size[1] / max(1e-6, max(size[0], size[2]))
    bust = aspect < 1.9
    # הראש הוא 26% מגוף שלם, ו-62% מחזה - שני המקרים נמדדו כאן
    head_frac = 0.62 if bust else 0.26
    head_h = size[1] * head_frac
    # רוחב הראש: הפרוסה העליונה ברוחב 30% מגובה הראש
    y0 = hi[1] - head_h * 0.80
    sel = pos[:, 1] > y0
    head_w = (pos[sel, 0].max() - pos[sel, 0].min()) if sel.sum() > 20 else head_h * 0.72
    ratio = float(head_w / max(1e-6, head_h))
    shape["head_width"] = float(np.clip(ratio / 0.74, 0.86, 1.18))
    shape["girth"] = float(np.clip(size[0] / max(1e-6, size[1]) /
                                   (0.37 if bust else 0.27), 0.86, 1.22))
    shape["shoulder_scale"] = float(np.clip(shape["girth"] * 0.5 + 0.5,
                                            0.90, 1.14))
    shape["source"] = ("חזה" if bust else "גוף שלם") + f" {p.name}"
    shape["ref_aspect"] = float(aspect)
    return shape


def foreground_mask(a: np.ndarray, tol: float = 0.075) -> np.ndarray:
    """מסכת הדמות מול הרקע.

    "בהיר מ-0.955 = רקע" נוסה כאן ונכשל: הרקע של התמונות שנוצרות
    הוא אפור בהיר **עם הדרגתיות** (0.93 למעלה, 0.97 למטה), ולכן חצי
    מהרקע נספר כדמות, תיבת הדמות יצאה כמעט כל התמונה, ולוח הצבעים
    כולו יצא אפרפר-אחיד. כאן הרקע נלמד מהמסגרת של התמונה.
    """
    h, w = a.shape[:2]
    b = max(3, int(min(h, w) * 0.01))
    border = np.concatenate([a[:b].reshape(-1, 3), a[-b:].reshape(-1, 3),
                             a[:, :b].reshape(-1, 3), a[:, -b:].reshape(-1, 3)])
    bg = np.median(border, axis=0)
    d = np.linalg.norm(a - bg[None, None, :], axis=2)
    return d > tol


def shape_from_image(ref_png: str | Path | None) -> dict:
    """מידות זהות מתוך התמונה: גובה הראש, רוחבו, ורוחב הכתפיים.

    זה מדויק יותר ממדידת רשת Hunyuan, כי ברשת שיער שיורד לכתפיים
    מטשטש לגמרי את קו הצוואר - נמדד כאן, וזו הסיבה שזיהוי "צוואר"
    לפי היצרות החתך נכשל ברשת ועובד בתמונה.
    """
    if not ref_png or not Path(ref_png).exists():
        return {}
    try:
        from PIL import Image
        a = np.asarray(Image.open(ref_png).convert("RGB")).astype(np.float64) / 255
        fg = foreground_mask(a)
        ys, xs = np.nonzero(fg)
        if len(ys) < 500:
            return {}
        y0, y1 = int(ys.min()), int(ys.max()) + 1
        rows = fg[y0:y1]
        width = rows.sum(axis=1).astype(np.float64)
        Hc = y1 - y0
        top = width[:int(Hc * 0.22)]
        if len(top) < 8:
            return {}
        head_w = float(top.max())
        # הצוואר: המינימום של רוחב השורה בשליש העליון, אחרי פסגת הראש
        peak = int(np.argmax(top))
        seg = width[peak:int(Hc * 0.30)]
        neck = peak + int(np.argmin(seg)) if len(seg) > 4 else int(Hc * 0.13)
        head_h = max(1.0, float(neck))
        shoulder = float(width[int(Hc * 0.20):int(Hc * 0.32)].max()) \
            if Hc > 40 else head_w * 2.4
        return {
            "head_width": float(np.clip((head_w / head_h) / 0.78, 0.84, 1.20)),
            "head_to_body": float(np.clip(head_h / Hc / 0.132, 0.80, 1.35)),
            "shoulder_scale": float(np.clip((shoulder / head_w) / 2.45,
                                            0.88, 1.18)),
            "girth": float(np.clip((shoulder / head_w) / 2.45, 0.90, 1.15)),
            "source": f"תמונה {Path(ref_png).name}",
        }
    except Exception:                                       # noqa: BLE001
        return {}


def palette_from_image(ref_png: str | Path | None) -> dict:
    """דוגם צבעים מתמונת הייחוס לפי רצועות גובה, ומחזיר לוח צבעים.

    חשוב: הצבעים נצרבים לקודקודים (COLOR_0) ולא ממופים בהיטל קדמי.
    היטל קדמי נראה מצוין מלפנים ונמרח לגמרי ב-45 מעלות - וזו בדיוק
    סחיפת הזהות שבדיקת הקבלה מחפשת.
    """
    pal = {k: list(v) for k, v in DEFAULT_PALETTE.items()}
    if not ref_png:
        return pal
    p = Path(ref_png)
    if not p.exists():
        return pal
    try:
        from PIL import Image
        im = Image.open(p).convert("RGB")
        a = np.asarray(im).astype(np.float64) / 255.0
        fg = foreground_mask(a)
        if fg.sum() < 200:
            return pal

        # הרצועות נמדדות בתוך תיבת הדמות ולא בתוך התמונה. מדידה על
        # התמונה כולה החזירה כאן לוח צבעים אפרפר-אחיד (שיער 0.79,
        # עור 0.80, חולצה 0.85), כי הרצועה העליונה של *התמונה* היא
        # בעיקר רקע לבן ולא שיער.
        ys, xs = np.nonzero(fg)
        by0, by1 = int(ys.min()), int(ys.max()) + 1
        bx0, bx1 = int(xs.min()), int(xs.max()) + 1
        bh, bw = by1 - by0, bx1 - bx0

        def band(y0, y1, cx=0.5, cw=0.6):
            m = np.zeros_like(fg)
            m[by0 + int(bh * y0):by0 + int(bh * y1),
              bx0 + int(bw * (cx - cw / 2)):bx0 + int(bw * (cx + cw / 2))] = True
            m &= fg
            if m.sum() < 50:
                return None
            px = a[m]
            # מרכז את המסה סביב הגוון החציוני, בלי קיצוני התאורה
            med = np.median(px, axis=0)
            d = np.linalg.norm(px - med, axis=1)
            keep = px[d < np.percentile(d, 70)]
            return [float(v) for v in keep.mean(axis=0)]

        # רצועות הדגימה נמדדות בתוך תיבת הדמות: למעלה שיער, גובה הפנים
        # ברצועה צרה במרכז, השמלה/החולצה בפלג הגוף, הרגליים והנעליים
        # בתחתית. התמונה עצמה היא דמות על רקע אחיד, ולכן זה יציב.
        hair = band(0.00, 0.07, 0.5, 0.40)
        skin = band(0.15, 0.21, 0.5, 0.14)
        shirt = band(0.38, 0.52, 0.5, 0.22)
        legs = band(0.72, 0.86, 0.5, 0.18)
        shoe = band(0.965, 1.0, 0.5, 0.45)
        if hair:
            pal["hair"] = hair
            pal["brow"] = [max(0.0, c * 0.72) for c in hair]
        if skin:
            pal["skin"] = skin
            pal["lip"] = [min(1.0, skin[0] * 0.94), skin[1] * 0.62,
                          skin[2] * 0.62]
        if shirt:
            pal["shirt"] = shirt
        if legs:
            pal["pants"] = legs
        # הרצועה התחתונה תופסת לפעמים את רצפת הסטודיו ולא את הנעל.
        # דגימה בהירה מאוד שם היא כמעט תמיד הרצפה - נמדד על maya.
        if shoe and float(np.mean(shoe)) < 0.72:
            pal["shoe"] = shoe
        pal["source"] = p.name
    except Exception as e:                                  # noqa: BLE001
        pal["source"] = f"דגימת צבע נכשלה: {type(e).__name__}"
    return pal


def _mul(c, f, red=1.0):
    return [float(min(1.0, c[0] * f * red)), float(min(1.0, c[1] * f)),
            float(min(1.0, c[2] * f))]


def expand_palette(pal: dict) -> dict:
    """גוני המשנה של תווי הפנים, שנגזרים מצבעי הבסיס שנדגמו מהתמונה.

    הם חייבים להיגזר ולא להיות קבועים: שפתיים אדומות על עור כהה, או
    אישון שחור על קשתית שחורה, נראים כמו מדבקה. כל גוון כאן הוא יחס
    לצבע שנדגם, ולכן הוא עובד על כל דמות.
    """
    p = dict(pal)
    hair = p.get("hair", DEFAULT_PALETTE["hair"])
    skin = p.get("skin", DEFAULT_PALETTE["skin"])
    lip = p.get("lip", DEFAULT_PALETTE["lip"])
    iris = p.get("iris", DEFAULT_PALETTE["iris"])
    p.setdefault("hair_dark", _mul(hair, 0.62))
    p.setdefault("lash", _mul(hair, 0.42))
    p.setdefault("brow", _mul(hair, 0.72))
    p.setdefault("blush", _mul(skin, 0.99, red=1.07))
    p.setdefault("ear", list(skin))
    p.setdefault("lip_up", _mul(lip, 0.80))
    p.setdefault("lip_lo", _mul(lip, 0.88))
    p.setdefault("lip_line", _mul(lip, 0.34))
    p.setdefault("nostril", _mul(skin, 0.42))
    p.setdefault("mouth_in", [0.21, 0.07, 0.08])
    p.setdefault("pupil", [0.035, 0.030, 0.035])
    p.setdefault("limbal", _mul(iris, 0.32))
    p.setdefault("catch", [1.0, 1.0, 1.0])
    p.setdefault("sclera", list(p.get("eye_white",
                                      DEFAULT_PALETTE["eye_white"])))
    return p


# שונות עדינה בין קודקודים סמוכים. בלי זה עור בתקריב נראה כמו פלסטיק
# ושיער נראה כמו גוש צבוע אחד. הזרע קבוע, כדי שרנדור חוזר של אותה
# פוזה יחזיר תמונה **זהה** - זו אחת מבדיקות הקבלה.
_GRAIN = {"skin": 0.022, "blush": 0.026, "hair": 0.085, "ear": 0.022,
          "brow": 0.10, "lip_up": 0.03, "lip_lo": 0.03, "iris": 0.07}

#: נסיגת השיער ההיקפי. ראה `hair_recession`.
HAIR_NEAR = 1.00        #: עד כאן (ברדיוסי ראש ממרכז הפנים) פרט מלא
HAIR_FAR = 2.20         #: מכאן ואילך מסה אחידה לגמרי
HAIR_FLATTEN = 0.86     #: כמה מהשונות בין קווצות שכנות מתאחדת
HAIR_DESAT = 0.62       #: כמה רוויה המסה ההיקפית מאבדת
HAIR_DARKEN = 0.26      #: כמה המסה ההיקפית מתכהה
HAIR_COOL = 0.055       #: כמה היא מתקררת (אדום יורד, כחול עולה)

#: נסיגת הלבוש. אותו עיקרון בדיוק, בטווח ובעוצמה של הגוף: הבגד
#: רחוק מהמוקד במרחקים של כמה רדיוסי ראש ולא של אחד-שניים, והוא
#: אינו נוגע בפנים - ולכן גם אין בו צורך בגרדיאנט חד ואין בו מה
#: לאחד (`flatten=0`: לבגד אין קווצות).
WEAR_TAGS = ("shirt", "pants", "shoe")
WEAR_NEAR = 2.20
WEAR_FAR = 5.50
WEAR_DESAT = 0.40
WEAR_DARKEN = 0.12
WEAR_COOL = 0.030


def focal_recession(col: np.ndarray, pos: np.ndarray, base: np.ndarray,
                    face_pt: np.ndarray, R: float, *,
                    near: float, far: float, flatten: float,
                    desat: float, darken: float, cool: float) -> np.ndarray:
    """מה שרחוק ממוקד הפנים מאבד פרט, רוויה ובהירות - נסיגה אטמוספרית.

    **מה זה פותר.** מנהל הקסם (TASK 09) מדד שהפנים של לוקאס מנצחות
    את שאר הדמות על תשומת הלב בפער 1.313, ואילו אצל מאיה 1.066 בלבד -
    שישית אחוז מעל גבול התקן. ההערה שנכתבה שם תלתה את זה ב"מסת השיער
    הארוך", ו**פירוק המדד למרכיביו הפריך את האבחון הזה**: האיבר
    הדומיננטי במדד הוא רוויה (0.45-0.47) ולא ניגודיות מקומית
    (0.02-0.04), ובלוח הצבעים שנמדד מתמונות הייחוס שיער מאיה הוא חום
    ברוויה 0.571 ושיער לוקאס אפרפר ברוויה 0.037. כלומר מה שהתחרה
    בפנים הוא **הצבע**, והמסה רק הכפילה אותו בשטח. אבחון לפי מסה היה
    שולח לקצר את השיער - כלומר לשנות זהות - בלי לגעת בסיבה.

    **וזה תיקון של העיצוב ולא של המדד.** זה העיקרון הקולנועי עצמו:
    המוקד מחזיק את הצבע והקונטרסט, ומה שסביבו נסוג. תסרוקת ארוכה
    בעיצוב דמות מקצועי *ממסגרת* את הפנים - הפרט נשאר במסגרת (פוני,
    קווצות רקה, קו שיער), והמסה שמאחור ומתחת מאוחדת לגוש אחד
    (value grouping), מאבדת רוויה, מתכהה ומתקררת. אותו דבר בלבוש:
    בגד עמום הוא מה שמשאיר את העין על הפנים. העין מקבלת מסלול:
    גוש → מסגרת → פנים. הגאומטריה, האורך, הצללית ולוח הצבעים
    עצמו לא נגעו.

    שלוש דעות חיצוניות שנשאלו בנפרד (05/10 - GPT-4, Qwen 3.8,
    Command A) החזירו את אותם צעדים ובאותו סדר: איחוד ערכים, ירידת
    רוויה וכהייה, חידוד הפנים אחרון. Qwen אף נקב במפורש ב"הפחת
    רוויה ב-20-30%" - והוא זה שהתאמת למדידה.

    `face_pt` היא נקודת המוקד (בערך מרכז הפנים) ו-`R` רדיוס הראש,
    ולכן המידה היא **ברדיוסי ראש** - היא נכונה גם כשגודל הראש משתנה
    בין דמות לדמות, וזה בדיוק המקרה כאן (ראשה של מאיה גדול ב-18%).
    """
    if not len(col):
        return col
    d = np.linalg.norm(pos - face_pt[None, :], axis=1) / max(1e-6, float(R))
    w = np.clip((d - near) / max(1e-6, far - near), 0.0, 1.0)
    w = (w * w * (3.0 - 2.0 * w))[:, None].astype(np.float32)
    b = base[None, :].astype(np.float32)
    # 1 · איחוד ערכים: ההפרש של כל קודקוד מצבע הבסיס מתכווץ, כלומר
    #     הקווצות ההיקפיות מפסיקות להיקרא בנפרד זו מזו. ללבוש זה
    #     אפס - אין בו קווצות, ושונות הגרעין שלו היא רעש בד.
    out = b + (col - b) * (1.0 - flatten * w)
    # 2 · ירידת רוויה - האיבר שמכריע. **כהייה כפלית אינה מורידה
    #     רוויה**: `(mx-mn)/mx` הוא יחס, והכפלה בקבוע לא משנה אותו.
    #     לכן המשיכה היא אל האפור של אותו קודקוד (luma) ולא הכפלה.
    #     זו הטעות שעלתה כאן סבב שלם: הגרסה הראשונה עשתה איחוד
    #     ערכים, כהייה וקירור - והזיזה את הפער ב-0.019 בלבד.
    lum = (0.2126 * out[:, 0:1] + 0.7152 * out[:, 1:2]
           + 0.0722 * out[:, 2:3])
    out = out * (1.0 - desat * w) + lum * (desat * w)
    # 3 · כהייה · 4 · קירור.
    out = out * (1.0 - darken * w)
    out = out * np.concatenate(
        [1.0 - cool * w, 1.0 - cool * 0.35 * w, 1.0 + cool * 0.55 * w],
        axis=1)
    return np.clip(out, 0.0, 1.0).astype(np.float32)


def hair_recession(col, pos, base, face_pt, R):
    """נסיגת השיער. ראה `focal_recession`."""
    return focal_recession(col, pos, base, face_pt, R, near=HAIR_NEAR,
                           far=HAIR_FAR, flatten=HAIR_FLATTEN,
                           desat=HAIR_DESAT, darken=HAIR_DARKEN,
                           cool=HAIR_COOL)


def wear_recession(col, pos, base, face_pt, R):
    """נסיגת הלבוש. ראה `focal_recession`."""
    return focal_recession(col, pos, base, face_pt, R, near=WEAR_NEAR,
                           far=WEAR_FAR, flatten=0.0, desat=WEAR_DESAT,
                           darken=WEAR_DARKEN, cool=WEAR_COOL)


def head_frame(skel: Skeleton) -> tuple[np.ndarray, np.ndarray, float]:
    """מרכז הראש, נקודת מוקד הפנים ורדיוס הראש - מקור אחד.

    היה מחושב פעמיים באותו קובץ עם אותם קבועים; מי שישנה אחד מהם
    יקבל שיער שנצבע במקום אחר מזה שבו הוא נסוג.
    """
    span = float(skel.by_name["head_tip"].rest[1] - skel.by_name["head"].rest[1])
    hc = np.asarray(skel.by_name["head"].rest) + np.array([0.0, span * 0.345, 0.0])
    R = span * 0.517
    face_pt = hc + np.array([0.0, -R * 0.18, R * 0.80])
    return hc, face_pt, R


def hair_from_image(ref_png, pal: dict) -> dict:
    """אורך השיער נמדד מהתמונה: עד איזה גובה יורדים פיקסלים בגוון השיער.

    למה לא קבוע לכל דמות: אורך השיער הוא מידת זהות ככל מידה אחרת.
    קבוע אחד נותן לשתי הדמויות אותה תסרוקת, וזה בדיוק מה שהופך אותן
    לאותה בובה בשני צבעים.
    """
    out = {"hair_len": 0.35, "hair_source": "ברירת מחדל"}
    if not ref_png or not Path(ref_png).exists():
        return out
    try:
        from PIL import Image
        a = np.asarray(Image.open(ref_png).convert("RGB")).astype(np.float64) / 255
        fg = foreground_mask(a)
        ys, xs = np.nonzero(fg)
        if len(ys) < 500:
            return out
        by0, by1 = int(ys.min()), int(ys.max()) + 1
        bx0, bx1 = int(xs.min()), int(xs.max()) + 1
        bh, bw = by1 - by0, bx1 - bx0
        hair = np.asarray(pal.get("hair", DEFAULT_PALETTE["hair"]))
        d = np.linalg.norm(a - hair[None, None, :], axis=2)
        m = (d < 0.16) & fg
        rows = m[by0:by1, bx0:bx1].sum(axis=1).astype(np.float64)
        # **רציפות מלמעלה** ולא "השורה הנמוכה ביותר שבה יש גוון שיער":
        # המדידה הראשונה כאן החזירה שיער עד 60% מהגוף לשתי הדמויות, כי
        # צללים כהים במכנסיים ובנעליים נכנסים לטווח של שיער שחור. שיער
        # הוא מסה **רצופה** מקודקוד הראש למטה, וזה מה שנמדד עכשיו.
        lim = int(bh * 0.72)
        top = rows[:max(8, int(bh * 0.30))]
        hmax = float(top.max())
        if hmax < max(4.0, bw * 0.04):
            return out                      # אין מסת שיער מזוהה בכלל
        # הסף נגזר ממסת השיער עצמה ולא מרוחב הדמות: ראש הוא כשליש
        # מרוחב הדמות כשהזרועות פרושות, ולכן סף ברוחב הגוף פוסל שיער
        # אמיתי לגמרי.
        # הסף נמוך (12%) בכוונה: בגובה הפנים השיער הוא שתי רצועות צרות
        # לצד הפנים, ולכן ספירת השורה צונחת שם ל-15% מהמסה שבקודקוד -
        # וסף של 22% חתך שיער ארוך בדיוק מתחת לסנטר.
        thr = max(3.0, hmax * 0.12)
        start = int(np.argmax(top))
        gap, last = 0, start
        for y in range(start, min(lim, len(rows))):
            if rows[y] > thr:
                last = y
                gap = 0
            else:
                gap += 1
                if gap > max(6, int(bh * 0.06)):
                    break
        rel = float(last) / max(1.0, bh)
        out["hair_len"] = float(np.clip((rel - 0.155) / 0.26, 0.0, 1.0))
        out["hair_rel"] = round(rel, 4)
        out["hair_source"] = Path(ref_png).name
    except Exception as e:                                  # noqa: BLE001
        out["hair_source"] = f"מדידת שיער נכשלה: {type(e).__name__}"
    return out


def _to_linear(c: np.ndarray) -> np.ndarray:
    """sRGB -> לינארי. **זה היה הבאג הגדול ביותר בצבע** (נמדד 05/10).

    הצבעים נדגמים מתמונת PNG, כלומר הם sRGB, ונכתבו כמו שהם ל-COLOR_0.
    אבל מפרט glTF מגדיר את COLOR_0 כ**לינארי**, ולכן המנוע התייחס
    ל-0.42 כאל 0.42 לינארי במקום 0.147 - פי 2.8 בהירות. התוצאה: כל
    גוון כהה נדחף לכיוון הלבן, שיער חום ועור בהיר יצאו כמעט באותו
    צבע, והפנים נראו שטופים ושטוחים. זה נראה בדיוק כמו "מטושטש"
    למרות שהגאומטריה הייתה מדויקת.
    """
    c = np.clip(np.asarray(c, np.float64), 0.0, 1.0)
    lo = c / 12.92
    hi = ((c + 0.055) / 1.055) ** 2.4
    return np.where(c <= 0.04045, lo, hi).astype(np.float32)


def _soften_hairline(mb, col, pos, pal, noise, face_pt, R_head):
    """פורשת את מדרגת הצבע שבגבול השיער לרצועה רציפה.

    **מה היה נראה בתקריב, ולמה זה לא היה תקלת רנדור.** צבע קודקוד הוא
    הכרעה אחת לכל קודקוד, ובין שני קודקודים הוא מתאינטרפל על פני פאה
    שלמה. קו השיער הוא גבול שעובר באלכסון לרשת וזז לאורכה (פסגת
    אלמנה, רקות נסוגות, גליות), ולכן הוא חותך כל עמוד של הרשת בגובה
    אחר - ומה שנראה הוא שיניים ברוחב מרובע שלם. זה גבול חד שנופל על
    רשת, לא אנטי-אליאסינג חסר.

    **והתיקון חייב לשמור על שלושה דברים שנשברים בקלות:**

    1. **הגבול לא זז.** `Head.hair_mix` מרוכז בדיוק בגובה שבו התגית
       מתחלפת, ולכן הרצועה סימטרית סביבו. ריכוך שמוזז אפילו במילימטר
       מזיז את קו השיער עצמו - כלומר משנה עיצוב.
    2. **הגרעין נשמר.** שני הצבעים מחושבים עם `noise` של **אותו**
       קודקוד, ולכן אין בגבול פס חלק בתוך משטח מגורען.
    3. **נסיגת השיער מוחלת גם על צד השיער של הרצועה.** בלעדיה הייתה
       נפתחת כאן טבעת של שיער בצבע מלא בתוך שיער נסוג - גבול חדש
       במקום זה שבוטל.
    """
    mix = getattr(mb, "mix", None)
    if not mix or len(mix) != len(col):
        return col
    m = np.array([-1.0 if x is None else float(x) for x in mix], np.float32)
    sel = np.nonzero((m > 0.0) & (m < 1.0))[0]
    if not len(sel):
        return col
    hb = np.asarray(pal["hair"], np.float32)
    sb = np.asarray(pal["skin"], np.float32)
    gh, gs = _GRAIN.get("hair", 0.0), _GRAIN.get("skin", 0.0)
    nz = noise[sel][:, None]
    c_hair = np.clip(hb[None, :] * (1.0 + nz * gh), 0.0, 1.0)
    c_hair = hair_recession(c_hair, pos[sel], hb, face_pt, R_head)
    c_skin = np.clip(sb[None, :] * (1.0 + nz * gs), 0.0, 1.0)
    t = m[sel][:, None]
    out = col.copy()
    out[sel] = (c_skin * (1.0 - t) + c_hair * t).astype(np.float32)
    return out


def bake_colors(mb: basemesh.MeshBuilder, skel: Skeleton, pal: dict) -> np.ndarray:
    """צובע כל קודקוד לפי האזור שלו. צבע קודקוד הוא בלתי תלוי במצלמה,
    ולכן הוא מניב אפס סחיפת זהות בין זוויות - בשונה מהיטל קדמי.

    הראש נצבע לפי **תגיות שהגאומטריה עצמה קבעה** (ראה MeshBuilder.tag)
    ולא לפי שחזור תנאי מיקום כאן. כששוחזרו כאן תנאים, קו השיער של
    הצבע לא התלכד עם קו השיער של כובע השיער, ונפתח ביניהם פס עור.
    """
    pal = expand_palette(pal)
    n = len(mb.v)
    col = np.tile(np.asarray(pal["skin"], np.float32), (n, 1))
    pos = np.asarray(mb.v, dtype=np.float64)

    # --- 1. כל מה שהגאומטריה תייגה
    tags = np.array([t if t is not None else "" for t in mb.tag], dtype=object)
    rng = np.random.default_rng(1704)
    noise = rng.standard_normal(n).astype(np.float32)
    tagged = np.zeros(n, dtype=bool)
    # מסגרת הראש נדרשת כבר כאן בשביל נסיגת השיער ההיקפי, ולא רק
    # בצביעה הגאומטרית שלמטה.
    hc, face_pt, R_head = head_frame(skel)
    for name in set(t for t in mb.tag if t):
        if name not in pal:
            continue
        sel = np.nonzero(tags == name)[0]
        if not len(sel):
            continue
        base = np.asarray(pal[name], np.float32)
        g = _GRAIN.get(name, 0.0)
        if g > 0:
            col[sel] = np.clip(base[None, :] *
                               (1.0 + noise[sel, None] * g), 0.0, 1.0)
        else:
            col[sel] = base
        if name == "hair":
            col[sel] = hair_recession(col[sel], pos[sel], base, face_pt,
                                      R_head)
        tagged[sel] = True
    col = _soften_hairline(mb, col, pos, pal, noise, face_pt, R_head)
    if tagged.all():
        return _to_linear(col)
    # TASK 21: קו המותניים שהגאומטריה קבעה (`basemesh`), אם קבעה.
    # `None` = ההתנהגות הישנה בדיוק, ולכן שמונה הדמויות שקדמו
    # לשוקת אינן משנות אף קודקוד.
    waist_y = getattr(mb, "waist_y", None)
    region = np.array(["skin"] * n, dtype=object)
    for name, v0, v1 in mb.groups:
        if name == "torso":
            region[v0:v1] = "shirt"
        elif name.startswith("leg_"):
            region[v0:v1] = "pants"
        elif name.startswith("foot_"):
            region[v0:v1] = "shoe"
        elif name.startswith("eyeball"):
            region[v0:v1] = "eye"
        elif name == "tongue":
            region[v0:v1] = "tongue"
        elif name.startswith("arm_"):
            region[v0:v1] = "arm"
    # מרכז הראש ורדיוסו נגזרים מעצמות הראש (`head_frame`), בדיוק כמו
    # במחולל הגאומטריה. כשגודל הראש הוא פרמטר זהות, קבוע נפרד כאן צובע
    # את השיער במקום הלא נכון ברגע שהראש גדל או קטן.
    for i in np.nonzero(~tagged)[0]:
        r = region[i]
        p = pos[i]
        if r == "shirt":
            # צוואר חשוף מעל קו הכתפיים
            if p[1] > skel.by_name["neck"].rest[1] - 0.01 * skel.height:
                col[i] = pal["skin"]
            elif waist_y is not None and p[1] < waist_y:
                # תחתית האגן היא **מתחת** לקו המותניים, ולכן מכנס
                col[i] = pal["pants"]
            else:
                col[i] = pal["shirt"]
        elif r == "pants":
            # ראש השוקת עולה מעל קו המותניים, ושם שולי החולצה מכסים
            col[i] = pal["shirt"] if (waist_y is not None
                                      and p[1] > waist_y) else pal["pants"]
        elif r == "shoe":
            col[i] = pal["shoe"]
        elif r == "tongue":
            col[i] = pal["tongue"]
        elif r == "arm":
            # שרוול עד מעל המרפק
            elbow = skel.by_name["forearm_L"].rest[0]
            col[i] = pal["shirt"] if abs(p[0]) < abs(elbow) * 0.72 else pal["skin"]
        elif r == "eye":
            # האישון הוא החלק הקדמי של גלגל העין
            col[i] = pal["iris"] if p[2] > hc[2] + R_head * 0.58 \
                else pal["eye_white"]
        else:
            # ראש: שיער על החלק העליון-אחורי, גבות, שפתיים
            rel = p - hc
            R = R_head
            if rel[1] > R * 0.18 and rel[2] < R * (0.62 - rel[1] / R * 0.35):
                col[i] = pal["hair"]
            elif rel[1] > R * 0.70 and rel[2] < R * 0.80:
                col[i] = pal["hair"]
            else:
                brow_d = min(
                    np.linalg.norm(p - np.asarray(skel.by_name[f"brow_{a}_{s}"].rest))
                    for a in ("in", "out") for s in ("L", "R"))
                if brow_d < R * 0.19:
                    col[i] = pal["brow"]
                elif abs(rel[2] - R * 0.86) < R * 0.30 and \
                        abs(rel[1] + R * 0.30) < R * 0.085 and abs(rel[0]) < R * 0.42:
                    col[i] = pal["lip"]
                else:
                    col[i] = pal["skin"]

    # --- נסיגת הלבוש. היא יושבת כאן ולא בלולאת התגיות למעלה מסיבה
    # מבנית: הגאומטריה **אינה** מתייגת בגד. חולצה, מכנס ונעל נגזרים
    # כאן מהקבוצה ומהמיקום, ולכן אין להם tag לחפש. הזיהוי הוא לפי
    # הצבע שנכתב בפועל (ולא לפי `region`, שבו "shirt" כולל גם את
    # הצוואר החשוף ו-"arm" כולל גם שרוול וגם עור) - ולבגד אין גרעין
    # ב-`_GRAIN`, ולכן ההשוואה מדויקת.
    for key in WEAR_TAGS:
        if key not in pal:
            continue
        kb = np.asarray(pal[key], np.float32)
        sel = np.nonzero((~tagged)
                         & np.all(np.abs(col - kb[None, :]) < 1e-6,
                                  axis=1))[0]
        if not len(sel):
            continue
        col[sel] = wear_recession(col[sel], pos[sel], kb, face_pt, R_head)
    return _to_linear(col)


# ------------------------------------------------------------ בנייה


#: ההרכב הקבוע של הסרטון. היה פזור בשורות פקודה, וכל בנייה מחדש הייתה
#: מסתמכת על הזיכרון של מי שהריץ - כולל **האביזרים**, שזו בדיוק הסיבה
#: שהמשקפיים נבנו ב-`detail.py`, נבדקו ב-`test_rig.py`, ומעולם לא הגיעו
#: לאף GLB: `build_character` לא קיבל `accessories`, ולכן `skel.by_name`
#: לא הכיל `glasses`, ולכן `basemesh.build` דילג על הגאומטריה בשקט.
#: `head_appeal` מוכפל במידת הראש שנמדדה מהתמונה, ואינו מחליף אותה.
#: הסיבה: המידה מהתמונה היא **זהות** (ראשה של מאיה גדול ב-18% מראשו
#: של לוקאס, וזה חייב להישאר), והמכפיל הוא **סגנון**. מנהל הקסם
#: (TASK 09) מדד שהגאומטריה שהייתה כאן נותנת 9.1 ראשים בגוף ללוקאס
#: ו-7.7 למאיה - זו פרופורציה של איור אופנה, והיא הסיבה שהפנים
#: "נעלמות" בשוט רחב. היעד: 7.0 ללוקאס ו-6.6 למאיה, ששניהם בתוך חלון
#: הדמות המסוגננת, ושונים זה מזה גם כדי שהצלליות יהיו מובחנות.
#: כתפיים ומבנה **שונים בכוונה** בין השניים, מאותה סיבה.
CAST = {
    "lucas": {"height": 1.78, "ref_png": "lucas_ref.png",
              "accessories": ("glasses",),
              "shape_override": {"girth": 0.95, "shoulder_scale": 1.02,
                                 "head_to_body": 1.35, "head_appeal": 1.298,
                                 "dimorph": "masc"}},
    "maya": {"height": 1.70, "ref_png": "maya_ref.png",
             "accessories": (),
             "shape_override": {"girth": 0.86, "shoulder_scale": 0.86,
                                "head_to_body": 1.35, "head_appeal": 1.165,
                                "shirt_desat": 0.42, "hair_desat": 0.34,
                                "dimorph": "fem"}},
    # --- 05/10: זיגי וגרומפ. ניגוד שפת צורות, לא ניגוד מין.
    # זיגי נמוכה וראשה גדול ביחס לגוף (`head_to_body` קטן = ראש גדול
    # יותר): פרופורציה ילדותית וקופצנית. גרומפ גבוה, כבד וראשו קטן
    # יחסית - כך הכתפיים הרחבות הן מה שקורא קודם בצללית.
    # --- 06/10 · TASK 11: `face` הוא שפת הצורות **מהצוואר ומעלה**.
    # עד כאן זיגי וגרומפ חלקו את הראש של לוקאס ומאיה בדיוק - אותו
    # אליפסואיד, אותו גלגל עין, אותה גבה ואותו פה. ראה `facestyle`.
    "zippy": {"height": 1.42, "ref_png": "maya_ref.png",
              "accessories": (),
              # 06/10: הכתף 0.82 -> 0.90. גולגולת כדורית רחבה
              # מאליפסואיד, ולכן הכתף של זיגי נעשתה צרה **ביחס לראש**
              # מתחת לחלון הקריאוּת. הקטנת הראש פתרה את זה אבל הפילה
              # את דירוג ההיררכיה החזותית (הפנים חדלו להיות האזור
              # הדומיננטי) - שני השערים מושכים לכיוונים הפוכים, ולכן
              # התיקון הוא בכתף ולא בראש.
              "shape_override": {"girth": 1.04, "shoulder_scale": 0.90,
                                 # 06/10: 1.30 -> 1.21. גולגולת כדורית
                                 # רחבה מאליפסואיד באותו רדיוס, ונמדד
                                 # שהצללית של זיגי עברה את חלון
                                 # `shoulder_to_head` (1.377 מול 1.45
                                 # מינימום). `head_appeal` הוא מכפיל
                                 # **סגנון** של גודל הראש, וזה המקום
                                 # הנכון לפצות - לא הקנה הכדורי.
                                 "head_to_body": 1.05, "head_appeal": 1.27,
                                 "dimorph": "round", "face": "joy"}},
    "grump": {"height": 1.74, "ref_png": "lucas_ref.png",
              "accessories": (),
              "shape_override": {"girth": 1.06, "shoulder_scale": 1.12,
                                 # 06/10: 1.10 -> 1.42. ראשו של גרומפ
                                 # נמדד כ-1/10.7 מגובהו, והחלון של
                                 # מבדק הערך החזותי הוא 5.9-7.5 ראשים.
                                 # זה לא כיול אסתטי: בשוט רחב הפנים
                                 # שלו היו 6.9 פיקסלים, כלומר הארכיטיפ
                                 # שלו לא נקרא - בדיוק מה שמבחן הקבלה
                                 # של המשימה דורש לוודא.
                                 "head_to_body": 1.52, "head_appeal": 1.36,
                                 "dimorph": "block", "face": "grim"}},
    # --- 06/10 · TASK 14: שפוד וכופתה. **החלפה ולא גרסה.**
    # הדרישה הייתה "אפס דמיון חזותי לאיטרציות קודמות", וההכרעה
    # שנגזרת ממנה היא שהניגוד חייב להיות ב**פרופורציה** ולא בפרטים:
    # 1.98 מ' מול 1.12 מ' - יחס 1.77, הפער הגדול ביותר בפרויקט
    # (זיגי מול גרומפ הוא 1.23) - ולכן שתי הצלליות נפרדות כבר
    # בשוט רחב, לפני שרואים פנים בכלל.
    #
    # ו**שפוד הוא הדמות הא-סימטרית הראשונה כאן.** `asym` מרים כתף
    # אחת, מרחיב אותה ומאריך את הזרוע שלה - שלושה ערוצים ולא אחד,
    # כי כתף מורמת לבדה נקראת כפוזה ולא כמבנה. הכתף השמאלית גבוהה
    # ב-3.6 ס"מ, רחבה ב-16% וזרועה ארוכה ב-7%.
    "shafud": {"height": 1.98, "ref_png": "lucas_ref.png",
               "accessories": (),
               "shape_override": {"girth": 0.62, "shoulder_scale": 1.18,
                                  "head_to_body": 1.62, "head_appeal": 1.30,
                                  "dimorph": "spire", "face": "edge",
                                  "asym": {"shoulder": [1.16, 0.95],
                                           "shoulder_y": 0.020,
                                           "arm": [1.07, 0.96]}}},
    "kufta": {"height": 1.12, "ref_png": "maya_ref.png",
              "accessories": (),
              "shape_override": {"girth": 1.42, "shoulder_scale": 0.76,
                                 "head_to_body": 0.80, "head_appeal": 1.22,
                                 "shirt_desat": 0.30,
                                 "dimorph": "fluid", "face": "drop"}},
    # --- 06/10 · TASK 15: בועז ותמר. **ניגוד מגדרי, ולא ניגוד סגנון.**
    # ההבדל מכל חמשת הזוגות שלפניהם: שם הניגוד היה שפת צורות (עגול מול
    # מרובע) או פרופורציה (1.98 מול 1.12). כאן שתי הדמויות הן אותו
    # סגנון ואותו עולם, והדבר היחיד שמפריד ביניהן הוא **מורפולוגיה
    # אנטומית** - יחס כתף:אגן, מותן, לסת וגבה. זה קשה יותר מניגוד
    # צורות, כי אין כאן פרמטר "קיצוני" להישען עליו; מה שקורא בצללית
    # הוא היחסים.
    #
    # הגבהים 1.85 ו-1.65 הם הדרישה המפורשת. יחס 1.12 - קטן מכל זוג
    # קודם כאן (שפוד/כופתה הוא 1.77), ולכן **הגובה אינו מה שמבדיל**
    # והשער המגדרי חייב למדוד יחסים חסרי יחידה. ראה `rig/gender.py`.
    "boaz": {"height": 1.85, "ref_png": "lucas_ref.png",
             "accessories": (),
             "shape_override": {"girth": 0.98, "shoulder_scale": 1.10,
                                "head_to_body": 1.44, "head_appeal": 1.30,
                                "dimorph": "male", "face": "male"}},
    "tamar": {"height": 1.65, "ref_png": "maya_ref.png",
              "accessories": (),
              "shape_override": {"girth": 0.90, "shoulder_scale": 0.86,
                                 # 06/10: 1.26 -> 1.12. נמדד במבדק
                                 # הערך החזותי שתמר יצאה 5.67 ראשים
                                 # בגובהה, כלומר **מתחת** לחלון
                                 # (5.9-7.5) - ראש גדול מדי לדמות
                                 # בוגרת, שקורא כפרופורציה ילדית
                                 # וסותר את הארכיטיפ. 1.12 נותן 6.38
                                 # וכל ששת המדדים בתוך החלון.
                                 # 06/10 TASK 16: 1.12 -> 1.16. חיתוך
                                 # הלסת עלה ל-0.72 (ראה `FEMALEF`),
                                 # והוא **מקטין** את תיבת הפנים - ואז
                                 # `visual_hierarchy` ירד ל-1.038.
                                 # 1.16 מחזיר את הפנים לראש ההיררכיה
                                 # ונשאר בתוך חלון הפרופורציות.
                                 "head_to_body": 1.28, "head_appeal": 1.16,
                                 # 06/10 TASK 16: 0.32 -> 0.48. השיער
                                 # עבר לגושים נפחיים, ובהם הוא תופס
                                 # יותר קשב; הורדת הרוויה היא הכלי
                                 # שמחזיר את הפנים לראש ההיררכיה בלי
                                 # לצמצם את הגושים עצמם.
                                 # החולצה היא המתחרה הישירה של הפנים
                                 # בהיררכיה (face>torso), ולכן הורדת
                                 # הרוויה שלה היא הכלי המכוון - בלי
                                 # לשנות שום גאומטריה.
                                 "shirt_desat": 0.58, "hair_desat": 0.60,
                                 "dimorph": "female", "face": "female"}},
}


def arm_clear_of(shape: dict | None) -> float:
    """מרווח הזרוע של הדמות, מתוך פרופיל הגוף שלה. 0.0 לכל דמות
    שלא ביקשה פרופיל, ולכל ששת הפרופילים שהיו לפני TASK 15."""
    from . import dimorph as _DM                         # noqa: PLC0415
    return float(_DM.get((shape or {}).get("dimorph")).arm_clear)


def cast_skeleton(name: str, **over) -> Skeleton:
    """שלד של דמות מ-`CAST`, **באותו מסלול** שבו היא נבנית לסרטון.

    נוסף ב-TASK 15 אחרי שנמדד שחמישה מודולי שער בונים `Skeleton`
    בעצמם מתוך `CAST` - וכל אחד מהם היה צריך להיזכר לבד בכל פרמטר
    חדש. שער שבונה שלד אחר מזה שנבנה בפועל מודד דמות שלא קיימת.
    """
    c = CAST[name]
    sh = dict(c["shape_override"])
    kw = {"height": float(c["height"]),
          "shoulder_scale": float(sh.get("shoulder_scale", 1.0)),
          "head_scale": 1.0,
          "accessories": tuple(c["accessories"]),
          "asym": sh.get("asym"),
          "arm_clear": arm_clear_of(sh)}
    kw.update(over)
    return Skeleton(**kw)


def build_character(name: str, out_dir, *, ref_glb=None, ref_png=None,
                    height: float = 1.70, quality: str = "full",
                    shape_override: dict | None = None,
                    accessories: tuple = ()) -> dict:
    t0 = time.time()
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)

    shape = shape_from_reference(ref_glb)
    shape.update(shape_from_image(ref_png))     # התמונה גוברת על הרשת
    pal = expand_palette(palette_from_image(ref_png))
    shape.update(hair_from_image(ref_png, pal))
    shape.update(shape_override or {})
    # סגנון כפול זהות, בסדר הזה. ההפרש בין הדמויות נשמר.
    if shape.get("head_appeal"):
        shape["head_width"] = float(shape["head_width"]
                                    * shape["head_appeal"])
    # משמעת רוויה בבגד. מנהל הקסם (TASK 09) מדד שאצל מאיה **הגו**
    # מנצח את הפנים בדירוג ההיררכיה החזותית (0.962 פער), כלומר
    # החולצה צועקת יותר מהפנים. זו בעיית עיצוב ולא בעיית מדידה:
    # הבגד הוא שטח גדול, ואם הוא גם הרווי ביותר העין נעצרת בו.
    # ההנמכה מערבבת את הצבע אל הבהירות שלו עצמו - כלומר משאירה את
    # הגוון והבהירות ומורידה רק את העוצמה.
    if shape.get("shirt_desat"):
        k = float(shape["shirt_desat"])
        for part in ("shirt", "pants"):
            c = np.asarray(pal.get(part, [0.5, 0.5, 0.5]), float)
            lum = float(0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2])
            pal[part] = (c * (1.0 - k) + lum * k).tolist()
    # אותה משמעת, על השיער. נדרשה אחרי הדימורפיזם (TASK 10ב): פלג
    # הגוף והגפיים של מאיה נעשו צרים יותר, כלומר שטחם קטן, ואז
    # **השיער עלה למקום השני** בדירוג ההיררכיה החזותית - האזור
    # שמנהל הקסם (TASK 09) דורש שלא יתחרה בפנים. ההנמכה שומרת גוון
    # ובהירות ומורידה רק עוצמה, בדיוק כמו בבגד.
    if shape.get("hair_desat"):
        k = float(shape["hair_desat"])
        for part in ("hair", "brow"):
            c = np.asarray(pal.get(part, [0.3, 0.2, 0.15]), float)
            lum = float(0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2])
            pal[part] = (c * (1.0 - k) + lum * k).tolist()

    # **TASK 22 · דריסת לוח צבעים מפורשת, והיא האחרונה בסדר.**
    # הצבעים נדגמים מתמונת הייחוס (`ref_png`), ובהרכב של שמונה יש
    # שתי תמונות ייחוס בלבד - ולכן שמונה דמויות יצאו באותה חולצה
    # כחולה ובאותו שיער חום. זה נראה בדף הדמויות של 06/10 ואי אפשר
    # היה לפספס: שמונה תאים, אותו בגד.
    #
    # ההוראה דורשת "distinct clothing styles", וסגנון לבוש הוא
    # קודם כול **צבע וגוון** באותה גאומטריית בגד. הדריסה מגיעה
    # אחרי שתי ההנמכות ולא לפניהן, כי מי שכותב צבע מפורש מבקש
    # בדיוק אותו - הנמכה שתרוץ אחריו הייתה הופכת את הבקשה להצעה.
    for _k, _v in (shape.get("palette") or {}).items():
        pal[_k] = [float(x) for x in _v]

    # **TASK 15.** מרווח הזרוע נגזר מ**הגוף** ולא נכתב ב-`CAST`:
    # הוא תכונה של היחס כתף:אגן, ושדה נפרד היה מאפשר דמות עם אגן
    # רחב ובלי מרווח - כלומר בדיוק הבאג. `arm_clear` של כל ששת
    # הפרופילים הקיימים הוא 0.0, ולכן אין כאן שינוי לאף דמות.
    skel = Skeleton(height=height,
                    shoulder_scale=float(shape.get("shoulder_scale", 1.0)),
                    head_scale=float(shape.get("head_width", 1.0)),
                    accessories=tuple(accessories),
                    asym=shape.get("asym"),
                    arm_clear=arm_clear_of(shape))
    mb, meta = basemesh.build(skel, shape, quality=quality)
    attrs = basemesh.to_arrays(mb, skel)
    colors = bake_colors(mb, skel, pal)
    # צורות הפנים (TASK 02). נגזרות מאותה גאומטריה שנבנתה כרגע, ולכן
    # נכונות לדמות הזו בלי כיול - גם אם הראש שלה גדול ב-20%.
    morphs = face.build(mb, mb.head)
    acting.audit()          # טבלת הקבוצות חייבת להיות שלמה לפני כתיבה

    glb_path = out / f"{name}.glb"
    # tags: חלוקת הרשת לחומרים (שיער מט / עור / גלגל עין מבריק).
    # בלעדיהן כל הדמות נכתבת בחומר אחד, והשיער יוצא פלסטיק מבריק.
    info = glbio.write_skinned_glb(glb_path, attrs, skel, name=name,
                                   color=colors, morphs=morphs,
                                   tags=list(mb.tag))

    health = identity.weight_health(attrs, skel)
    lib = controls.pose_library(skel)
    poses, pose_report = {}, {}
    for pname, (ctl, ik) in lib.items():
        q = controls.evaluate(skel, ctl, ik)
        poses[pname] = q
        pos = identity.skin(skel, attrs, q)
        pose_report[pname] = {
            "bones_moved": len(q),
            "finite": bool(np.all(np.isfinite(pos))),
            "face": identity.face_measures(skel, q),
        }
    dr = identity.identity_report(skel, attrs, poses)

    rig = {
        "name": name,
        "height_m": height,
        "created": time.strftime("%Y-%m-%d %H:%M:%S"),
        "glb": glb_path.name,
        # **חייב להיישמר.** כל צרכן שבונה `Skeleton` מה-rig.json (הסרטון,
        # בדיקת הקבלה, מנהל הקסם) חייב לקבל בדיוק את אותה רשימת עצמות
        # ובאותו סדר - אחרת אינדקס עצם אחד מוזז, וכל פוזה מוחלת על
        # האיבר הלא נכון בלי שום שגיאה.
        "accessories": list(accessories),
        "mesh": meta,
        "skeleton": {"bones": skel.names, "counts": skel.counts()},
        "controls": {k: {"min": v[0], "max": v[1], "default": v[2],
                         "group": v[3]} for k, v in controls.CONTROLS.items()},
        "control_groups": controls.GROUPS,
        # --- TASK 02: מערכת המשחק
        "face": {
            "shapes": morphs["names"],
            "shape_report": morphs["report"],
            "regions": acting.REGIONS,
            "region_sizes": acting.audit()["per_region"],
            "action_units": {k: {"region": v.region, "facs": v.facs,
                                 "sided": v.sided}
                             for k, v in acting.AUS.items()},
            "expressions": {k: acting.describe(k) for k in acting.EXPRESSIONS},
            "driven": acting.DRIVEN,
            "antagonists": acting.ANTAGONISTS,
        },
        "ik_chains": ["hand_L", "hand_R", "foot_L", "foot_R"],
        "secondary_motion": list(controls.SecondaryMotion.LAG),
        "identity": {"shape": shape, "palette": pal,
                     "geometry_drift": dr},
        "weights": health,
        "poses": sorted(lib),
        "pose_report": pose_report,
        "glb_info": info,
        "build_seconds": round(time.time() - t0, 2),
    }
    # תגית לכל קודקוד ותחומי האזורים. נשמרים כאן כי זו הנקודה היחידה
    # שבה הגאומטריה עוד יודעת מה היא בנתה. בלעדיהם כל צרכן שרוצה לדעת
    # "איפה השיער" או "איפה המשקפיים" חייב לשחזר את זה מתנאים על
    # מיקום הקודקוד - וזה בדיוק מה שפתח פס עור בין השיער לגולגולת.
    rig["mesh"]["group_ranges"] = [[g[0], int(g[1]), int(g[2])]
                                   for g in mb.groups]
    (out / f"{name}.rig.json").write_text(
        json.dumps(rig, ensure_ascii=False, indent=1), encoding="utf-8")
    np.savez_compressed(out / f"{name}.attrs.npz", **attrs, color=colors,
                        tag=np.array([t or "" for t in mb.tag]))
    return rig


def skeleton_from_rig(rig: dict) -> Skeleton:
    """שלד שזהה **בדיוק** לזה שבנה את ה-GLB: גובה, כתפיים, גודל ראש
    ואביזרים.

    זה הקוד היחיד שמותר לבנות ממנו שלד מתוך rig.json, ובמתכוון: שלושה
    צרכנים עשו את זה בנפרד, ושלושתם השמיטו `head_scale` (ולכן אצל מאיה,
    שראשה גדול ב-20%, כל עצמות הפנים בפייתון יושבו במקום אחר מאשר
    בכריכה שב-GLB) ושניים מהם גם את `accessories`.
    """
    shape = rig.get("identity", {}).get("shape", {})
    return Skeleton(height=rig["height_m"],
                    shoulder_scale=float(shape.get("shoulder_scale", 1.0)),
                    head_scale=float(shape.get("head_width", 1.0)),
                    accessories=tuple(rig.get("accessories") or ()),
                    # **הא-סימטריה חייבת לעבור כאן גם.** השלד הזה הוא
                    # מה שפייתון מודד ומזין ל-IK, וה-GLB הוא מה
                    # שהדפדפן מכריך. שלד סימטרי מול כריכה א-סימטרית
                    # הוא בדיוק הבאג שמתואר למעלה, רק בצד השני.
                    asym=shape.get("asym"),
                    # **וגם מרווח הזרוע, מאותה סיבה בדיוק (TASK 15).**
                    # זה הצרכן האמיתי: הסרטון, מבחן הקבלה ומבדק הערך
                    # החזותי כולם בונים את השלד מכאן. שלד שנבנה בלי
                    # המרווח היה מצמיד את הזרוע בכל פריים שמרונדר -
                    # כלומר התיקון היה עובר את השער ולא מגיע למסך.
                    # הוא נגזר מ-`shape["dimorph"]` ולא נשמר כשדה
                    # נפרד, ולכן קובץ rig.json שנכתב לפני TASK 15
                    # מחזיר 0.0 ואינו משתנה.
                    arm_clear=arm_clear_of(shape))


def build_cast(out_dir, refs=r"D:\claude-bot\out\char3d", quality="full",
               names=None) -> dict:
    """בונה את כל ההרכב מ-`CAST`. זו הדרך לשחזר את הדמויות בלי לזכור
    שורת פקודה."""
    refs = Path(refs)
    done = {}
    for name in (names or list(CAST)):
        c = CAST[name]
        done[name] = build_character(
            name, out_dir, ref_png=refs / c["ref_png"],
            height=c["height"], quality=quality,
            shape_override=dict(c["shape_override"]),
            accessories=tuple(c["accessories"]))
    return done


def main(argv=None):
    import argparse
    import sys
    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(description="בניית דמות מרוגגת")
    ap.add_argument("name", nargs="?", default=None,
                    help="שם דמות, או ריק עם --cast")
    ap.add_argument("--cast", action="store_true",
                    help="לבנות את כל ההרכב מ-CAST")
    ap.add_argument("--refs", default=r"D:\claude-bot\out\char3d")
    ap.add_argument("--out", default=r"D:\claude-bot\out\char3d\rigged")
    ap.add_argument("--ref-glb", default=None)
    ap.add_argument("--ref-png", default=None)
    ap.add_argument("--height", type=float, default=1.70)
    ap.add_argument("--quality", default="full", choices=["full", "fast"])
    a = ap.parse_args(argv)
    if a.cast:
        built = build_cast(a.out, refs=a.refs, quality=a.quality)
    elif a.name in CAST:
        # **TASK 16 · באג אמיתי שנתפס בהרצה.** עד כאן שם של דמות
        # מ-`CAST` נבנה דרך `build_character` **בלי** `shape_override`
        # ובלי `accessories` - כלומר `python -m rig.pipeline boaz`
        # כתב קובץ בשם boaz שהוא דמות **ברירת מחדל**: בלי דימורפיזם,
        # בלי שפת פנים ובלי מרווח זרוע. ההסגרה: שני קבצים שנבנו כך
        # יצאו **13626 KB שניהם בדיוק**, ומבדק ההפרדה החזיר 0.000.
        # אין לזה שגיאה, רק דמות שקטה ולא נכונה - ולכן התיקון כאן
        # ולא בשורת הפקודה שהרצתי.
        built = build_cast(a.out, refs=a.refs, quality=a.quality,
                           names=[a.name])
    elif a.name:
        built = {a.name: build_character(
            a.name, a.out, ref_glb=a.ref_glb, ref_png=a.ref_png,
            height=a.height, quality=a.quality)}
    else:
        ap.error("חסר שם דמות, או --cast")
    for name, r in built.items():
        print(f"✓ {name}: {r['mesh']['vertices']} קודקודים, "
              f"{r['mesh']['triangles']} משולשים, {r['mesh']['bones']} עצמות"
              + (f", אביזרים: {', '.join(r['accessories'])}"
                 if r["accessories"] else ""))
        print(f"  קובץ: {r['glb_info']['path']} "
              f"({r['glb_info']['bytes'] // 1024} KB)")
        print(f"  משקולות: סכום תקין={r['weights']['sum_ok']}, "
              f"עצמות בשימוש={r['weights']['bones_used']}")
        g = r["identity"]["geometry_drift"]
        print(f"  סחיפת זהות גאומטרית: {g['max_rel_drift'] * 100:.6f}% | "
              f"שחזור מנוחה {g['rest_recovery_worst_mm']:.4f} מ\"מ | "
              f"הפרדת פוזות {g['pose_separation']['min_mean_pct']:.2f}% | "
              f"עובר={g['passes']}")
        print(f"  {r['build_seconds']}ש")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
