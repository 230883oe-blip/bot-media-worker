# -*- coding: utf-8 -*-
"""
שכבת סביבה צרובה לסצנת חוץ - "Environment Optimization & Layered
Compositing Pipeline" (05/10, בקשה מפורשת).

**מה הבעיה שזה פותר.** הבמה (`stage.html`) בנויה לתאורת אולפן: שני-
שלושה אורות מכוונים, רצפה אחת עם `ShadowMaterial`, ושתי דמויות. סצנת
חוץ "אמיתית" הייתה דורשת מאות אלפי משולשי עלים, צל שמש על כולם
ו-GI - וזה רינדור של שעות על מכונה בלי כרטיס גרפי, פר פריים.

**מה נעשה כאן במקום.** הסביבה מצוירת **פעם אחת** למספר תמונות PNG
("matte painting" / skybox), ובדפדפן היא רק `background-image` מאחורי
הקנבס השקוף. עלות פר פריים: אפס חישוב גאומטרי. מה שנשאר למנוע
התלת-ממד הוא בדיוק מה שחשוב - הדמויות.

ארבע השכבות, מהרחוק לקרוב:
  `sky`    - שמיים, שמש, הילה ועננים. השכבה שלא זזה כמעט.
  `far`    - קו עצים רחוק, צללית מעומעמת (פרספקטיבה אטמוספרית).
  `ground` - דשא, שביל, ספסל, ו**הצללים הארוכים צרובים בתוכו**.
  `near`   - כתרי עצים בקדמת הפריים + מסגור. זזים הכי הרבה בסחיפה.
ולצידן `dapple` - אריח של אור מנוקד בין העלים, שמונח כשכבת-על.

**למה הצללים צרובים ולא מחושבים.** זווית השמש בתסריט קבועה
(`sun_azimuth_deg`, `sun_elevation_deg`), העצים אינם זזים ממקומם,
ולכן הצל שלהם על הדשא הוא **תמונה קבועה**. אין שום מידע שמתקבל
מחישובו מחדש 1500 פעמים. הצל שכן חייב להיות דינמי הוא רק זה של
הדמויות, והוא נשאר ב-three.js כמישור צל מוקרן.

**הלופ.** תנועת העלים ותנועת העננים הן סינוס עם מחזור שמתחלק
במדויק באורך הסרט (`LOOP_SEC`), ולכן הפריים הראשון והאחרון זהים
והרקע מתלכד. מחזור שאינו מתחלק יוצר קפיצה בתפר - וזה נראה בדיוק
כמו פריים שאבד.
"""
from __future__ import annotations

import colorsys
import json
import math
import random
from pathlib import Path

#: רוחב השכבות גדול מרוחב הפריים: המצלמה סוחפת, והשכבות נעות בפרלקס.
#: שכבה ברוחב הפריים בדיוק הייתה חושפת פס שחור בקצה ברגע שהיא זזה.
PAD = 1.35

#: מחזור הלופ בשניות. 10 מתחלק ב-50 חמש פעמים בדיוק.
LOOP_SEC = 10.0

#: מהירות הפרלקס לכל שכבה (יחידות מסך לכל יחידת סחיפה).
#: שמיים כמעט נייחים, קדמת הפריים זזה הרבה - כך נקרא עומק.
PARALLAX = {"sky": 0.06, "far": 0.22, "ground": 0.55, "near": 1.0}


# --------------------------------------------------------------- צבע

def _hsv(h: float, s: float, v: float) -> tuple[int, int, int]:
    r, g, b = colorsys.hsv_to_rgb(h, s, v)
    return int(r * 255), int(g * 255), int(b * 255)


def _mix(a: tuple, b: tuple, u: float) -> tuple[int, int, int]:
    u = max(0.0, min(1.0, u))
    return tuple(int(a[i] + (b[i] - a[i]) * u) for i in range(3))


def shadow_vector(azimuth_deg: float, elevation_deg: float) -> tuple[float, float]:
    """(dx, dy) לכל יחידת גובה: לאן נופל הצל ובאיזה אורך.

    `elevation` נמוך = צל ארוך. אורך הצל הוא `1/tan(elevation)`, וזו
    הסיבה שהתסריט ביקש 24 מעלות: שמש גבוהה נותנת כתם מתחת לרגל ולא
    "צללים ארוכים מכיוון אחד".

    הגנה: elevation שמתקרב לאפס היה נותן אורך אינסופי ו-PIL היה
    מצייר אליפסה בגודל מיליוני פיקסלים עד לקריסת זיכרון. לכן יש
    תקרה מפורשת.
    """
    el = max(4.0, min(86.0, float(elevation_deg)))
    length = 1.0 / math.tan(math.radians(el))
    length = min(length, 6.0)
    az = math.radians(float(azimuth_deg))
    # azimuth שלילי = השמש משמאל => הצל נמשך ימינה.
    return (-math.sin(az) * length, math.cos(az) * length * 0.42)


# --------------------------------------------------------------- ציור

def _blur(img, px: int):
    from PIL import ImageFilter
    return img.filter(ImageFilter.GaussianBlur(px)) if px > 0 else img


def _sky(w: int, h: int, sun_px: tuple[float, float], rng: random.Random):
    """שמיים + שמש + הילה + עננים. אין כאן שקיפות: זו השכבה האחורית."""
    from PIL import Image, ImageDraw
    top, horizon = _hsv(0.58, 0.62, 0.92), _hsv(0.54, 0.16, 1.00)
    img = Image.new("RGB", (w, h), top)
    d = ImageDraw.Draw(img)
    for y in range(h):
        u = (y / max(1, h - 1)) ** 0.78
        d.line([(0, y), (w, y)], fill=_mix(top, horizon, u))

    # הילת השמש: שכבה נפרדת ב-screen, אחרת היא "מולבנת" לכדור לבן.
    glow = Image.new("RGB", (w, h), (0, 0, 0))
    gd = ImageDraw.Draw(glow)
    sx, sy = sun_px
    for r, v in ((h * 0.95, 0.20), (h * 0.52, 0.34), (h * 0.26, 0.58),
                 (h * 0.12, 0.90)):
        c = _hsv(0.12, 0.30, v)
        gd.ellipse([sx - r, sy - r, sx + r, sy + r], fill=c)
    glow = _blur(glow, int(h * 0.05))
    from PIL import ImageChops
    img = ImageChops.screen(img, glow)
    # גרעין השמש עצמה, אחרי הטשטוש, אחרת היא מתפזרת ונעלמת.
    d = ImageDraw.Draw(img)
    r = h * 0.035
    d.ellipse([sx - r, sy - r, sx + r, sy + r], fill=(255, 252, 238))

    # עננים: אשכולות אליפסות מטושטשות. שכבה נפרדת כדי לטשטש רק אותן.
    cl = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    cd = ImageDraw.Draw(cl)
    for _ in range(9):
        cx = rng.uniform(0, w)
        cy = rng.uniform(h * 0.05, h * 0.42)
        cw = rng.uniform(w * 0.07, w * 0.19)
        for _ in range(7):
            ex = cx + rng.uniform(-cw, cw)
            ey = cy + rng.uniform(-cw * 0.16, cw * 0.16)
            er = rng.uniform(cw * 0.22, cw * 0.46)
            a = int(rng.uniform(70, 135))
            cd.ellipse([ex - er, ey - er * 0.62, ex + er, ey + er * 0.62],
                       fill=(255, 255, 255, a))
    cl = _blur(cl, int(h * 0.012))
    img = Image.alpha_composite(img.convert("RGBA"), cl)
    return img


def _crown(d, cx: float, cy: float, r: float, base, lit, sun_dir: float,
           rng: random.Random, blobs: int = 26) -> None:
    """כתר עץ: אשכול כתמים, ולא עיגול אחד.

    עיגול אחד נראה כמו סוכרייה. כתמים בגדלים שונים נותנים את הקו
    המשונן של עלווה, והבהרה **בצד השמש בלבד** היא מה שמקשר את העץ
    לכיוון התאורה של הדמויות. בלי הקישור הזה הרקע נראה מודבק.
    """
    for i in range(blobs):
        a = rng.uniform(0, math.tau)
        rad = r * rng.uniform(0.05, 0.86)
        bx, by = cx + math.cos(a) * rad, cy + math.sin(a) * rad * 0.78
        br = r * rng.uniform(0.20, 0.40)
        # 1 בצד השמש, 0 בצד הצל.
        side = 0.5 + 0.5 * ((bx - cx) / max(1e-6, r)) * (-sun_dir)
        col = _mix(base, lit, side ** 1.6 * 0.95)
        d.ellipse([bx - br, by - br, bx + br, by + br], fill=col)


def _trees(w: int, h: int, spec: list, sun_dir: float, rng: random.Random,
           alpha: int = 255):
    """שכבת עצים שקופה. spec = [(x_rel, y_rel, scale), ...]."""
    from PIL import Image, ImageDraw
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    bark_d, bark_l = _hsv(0.07, 0.56, 0.26), _hsv(0.09, 0.44, 0.52)
    leaf_d, leaf_l = _hsv(0.30, 0.66, 0.30), _hsv(0.22, 0.62, 0.86)
    for xr, yr, sc in spec:
        cx, base_y = xr * w, yr * h
        th = h * 0.52 * sc                  # גובה העץ
        tw = max(3.0, th * 0.075)           # עובי הגזע
        # הגזע: שני מלבנים, בהיר בצד השמש. מרקם זול שקורא כנפח.
        d.polygon([(cx - tw, base_y), (cx + tw, base_y),
                   (cx + tw * 0.55, base_y - th * 0.62),
                   (cx - tw * 0.55, base_y - th * 0.62)], fill=bark_d)
        d.polygon([(cx + tw * sun_dir * -0.25, base_y),
                   (cx + tw * sun_dir * -1.0, base_y),
                   (cx + tw * sun_dir * -0.55, base_y - th * 0.62),
                   (cx + tw * sun_dir * -0.25, base_y - th * 0.62)],
                  fill=bark_l)
        _crown(d, cx, base_y - th * 0.78, th * 0.46, leaf_d, leaf_l,
               sun_dir, rng, blobs=34)
    if alpha < 255:
        r, g, b, a = img.split()
        a = a.point(lambda v: int(v * alpha / 255))
        img = Image.merge("RGBA", (r, g, b, a))
    return img


def _ground(w: int, h: int, tree_spec: list, shadow: tuple[float, float],
            rng: random.Random):
    """דשא + שביל + ספסל + **צללים ארוכים צרובים**.

    הצל של כל עץ הוא אליפסה מוטה בכיוון `shadow`, באורך פרופורציונלי
    לגובה העץ. היא מטושטשת כי צל שמש אינו חד בקצה (penumbra), וצל חד
    הוא בדיוק מה שנראה כמו מדבקה.
    """
    from PIL import Image, ImageDraw
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    g_far, g_near = _hsv(0.26, 0.52, 0.62), _hsv(0.29, 0.62, 0.40)
    top = int(h * 0.56)                     # קו האופק של הדשא
    for y in range(top, h):
        u = (y - top) / max(1, h - top)
        d.line([(0, y), (w, y)], fill=_mix(g_far, g_near, u ** 0.7) + (255,))

    # שביל: שתי קימורים שמתרחבים לכיוון המצלמה (פרספקטיבה).
    path = _hsv(0.10, 0.28, 0.80)
    pts_l, pts_r = [], []
    for i in range(41):
        u = i / 40
        y = top + (h - top) * u
        cx = w * (0.50 + 0.10 * math.sin(u * 1.9))
        half = w * (0.012 + 0.085 * u ** 1.5)
        pts_l.append((cx - half, y))
        pts_r.append((cx + half, y))
    d.polygon(pts_l + pts_r[::-1], fill=path + (255,))

    # צללים: שכבה נפרדת, כדי לטשטש אותם בלי לטשטש את הדשא.
    sh = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    sd = ImageDraw.Draw(sh)
    dx, dy = shadow
    for xr, yr, sc in tree_spec:
        cx, base_y = xr * w, yr * h
        th = h * 0.52 * sc
        ex, ey = cx + dx * th, base_y + dy * th * 0.30
        rr = th * 0.34
        sd.ellipse([min(cx, ex) - rr, base_y - rr * 0.30,
                    max(cx, ex) + rr, base_y + rr * 0.42],
                   fill=(14, 26, 18, 120))
        sd.ellipse([ex - rr * 0.9, ey - rr * 0.34,
                    ex + rr * 0.9, ey + rr * 0.34],
                   fill=(14, 26, 18, 96))
    sh = _blur(sh, max(2, int(h * 0.010)))
    img = Image.alpha_composite(img, sh)

    # ספסל עץ, שמאל-מרכז. הוא הוזכר בתסריט ("צל של הספסל הזה").
    d = ImageDraw.Draw(img)
    bx, by = w * 0.205, h * 0.845
    bw, bh = w * 0.090, h * 0.030
    wood_d, wood_l = _hsv(0.07, 0.58, 0.44), _hsv(0.09, 0.50, 0.66)
    bsh = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    ImageDraw.Draw(bsh).ellipse(
        [bx - bw * 0.3 + dx * bh * 2.4, by + bh * 0.4,
         bx + bw * 1.5 + dx * bh * 2.4, by + bh * 1.5],
        fill=(14, 26, 18, 110))
    img = Image.alpha_composite(img, _blur(bsh, max(2, int(h * 0.006))))
    d = ImageDraw.Draw(img)
    for i in range(3):                      # מסעד: שלושה לוחות
        yy = by - bh * (2.3 + i * 0.52)
        d.rectangle([bx, yy, bx + bw, yy + bh * 0.34], fill=wood_l + (255,))
    d.rectangle([bx - bw * 0.05, by - bh * 0.9, bx + bw * 1.05, by - bh * 0.45],
                fill=wood_d + (255,))      # מושב
    for xx in (bx + bw * 0.06, bx + bw * 0.88):
        d.rectangle([xx, by - bh * 0.5, xx + bw * 0.05, by + bh * 0.5],
                    fill=wood_d + (255,))  # רגליים

    # גבעולי דשא בקדמת הפריים: קווים דקים, ולא מרקם. זה מה שמונע
    # את ה"מדשאה מפלסטיק" בשורה התחתונה של הפריים.
    for _ in range(1400):
        gx = rng.uniform(0, w)
        gy = rng.uniform(h * 0.72, h)
        gl = rng.uniform(h * 0.006, h * 0.020) * (gy / h)
        c = _mix(g_near, g_far, rng.uniform(0.0, 0.5))
        d.line([(gx, gy), (gx + rng.uniform(-2, 2), gy - gl)],
               fill=c + (170,), width=1)
    return img


#: **מקומות האביזרים האינטראקטיביים (TASK 13, 06/10), ביחידות פריים
#: מנורמלות.** הם קבועים ומשותפים לשני הצדדים: `_props` מצייר כאן את
#: הגוף הסטטי, ו-`rig.ensemble` מניח כאן את החלק הדינמי (אור מהבהב,
#: עלים שמתפזרים). שני מקומות נפרדים לאותו אביזר הם בדיוק הבאג שבו
#: הפנס דולק במקום אחד והצל שלו נופל במקום אחר.
PROPS = {
    #: פנס פארק: בסיס, ראש הפנס, וגובה. הוא ימינה למרכז כדי שהצל
    #: שלו ייפול אל תוך הפריים ולא יצא ממנו.
    "lamp": {"base": (0.775, 0.880), "head": (0.775, 0.475),
             "arm": 0.028, "glow_r": 0.085},
    #: ערימת עלי שלכת על השביל, בדיוק במקום שזיגי נוחתת בו.
    #:
    #: **המספרים האלה אינם "נראה טוב" - הם תוצאה של הקרנה.** הערימה
    #: קיימת פעמיים: כאן כציור צרוב בשכבת הקרקע, וב-`rig.ensemble`
    #: כעלים תלת-ממדיים שעפים. אם שני המקומות אינם מתלכדים, הערימה
    #: "קופצת" ברגע שהאנימציה מתחילה - עלים יוצאים ממקום אחד
    #: ונעלמים ממקום אחר. לכן המקום כאן חושב מההקרנה של עוגן העלים
    #: בעולם (`ensemble.LEAF_ANCHOR`) דרך מצלמת הפתיחה של השוט,
    #: והבדיקה `ensemble.audit` מודדת את הפער בין השניים.
    "leaves": {"at": (0.5037, 0.8598), "r": (0.105, 0.030), "n": 46},
    #: סל פיקניק על מושב הספסל. הספסל מצויר ב-`_ground` ב-0.205.
    "basket": {"at": (0.248, 0.818), "w": 0.042, "h": 0.034},
}

#: צבעי השלכת. שלושה גוונים ולא אחד: ערימה בצבע אחד נקראת כשטיח.
LEAF_HUES = ((0.075, 0.78, 0.82), (0.045, 0.85, 0.68), (0.115, 0.62, 0.74))


def leaf_color(i: int) -> tuple[int, int, int]:
    """צבע העלה ה-i. דטרמיניסטי לפי אינדקס, ולכן זהה בפייתון
    ובדפדפן - עלה שמחליף צבע ברגע שהוא מתפזר הוא פגם שרואים."""
    h, s, v = LEAF_HUES[i % len(LEAF_HUES)]
    k = ((i * 37) % 11) / 11.0
    return _hsv(h + 0.012 * (k - 0.5), s, v * (0.82 + 0.26 * k))


def leaf_rest(i: int, n: int) -> tuple[float, float, float]:
    """(x, y, זווית) של העלה ה-i במנוחה, ביחידות פריים מנורמלות.

    פרישה בספירלת פיבונאצ'י ולא `random`: ערימה שנצרבת ב-PIL עם
    זרע אחד וב-`ensemble` עם זרע אחר נותנת עלים שמשנים מקום בפריים
    שבו האנימציה מתחילה - קפיצה שרואים.
    """
    cx, cy = PROPS["leaves"]["at"]
    rx, ry = PROPS["leaves"]["r"]
    g = 2.39996323                           # הזווית הזהובה
    u = (i + 0.5) / max(1, n)
    rad = math.sqrt(u)
    th = i * g
    return (cx + rx * rad * math.cos(th),
            cy + ry * rad * math.sin(th),
            math.degrees(th) % 180.0)


def _props(w: int, h: int, shadow: tuple[float, float], rng: random.Random):
    """פנס פארק, ערימת שלכת וסל פיקניק - **הגוף הסטטי שלהם**.

    מה שדינמי (הבהוב האור, עלה שעף) אינו כאן: הוא מחושב פר פריים
    ב-`rig.ensemble` ומצויר מעל. מה שכן כאן הוא כל מה שאינו זז -
    עמוד הפנס, הסל, והעלים שלא נגעו בהם. זו אותה החלטה שנעשתה
    בשכבות הסביבה: מה שלא זז נצרב פעם אחת.
    """
    from PIL import Image, ImageDraw
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    dx, dy = shadow

    # --- צל הפנס: ראשון, כדי שכל השאר יישב מעליו.
    sh = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    sd = ImageDraw.Draw(sh)
    L = PROPS["lamp"]
    bx, by = L["base"][0] * w, L["base"][1] * h
    hx, hy = L["head"][0] * w, L["head"][1] * h
    ph = by - hy                                   # גובה הפנס בפיקסלים
    ex, ey = bx + dx * ph, by + dy * ph * 0.30
    sd.line([(bx, by), (ex, ey)], fill=(14, 26, 18, 120),
            width=max(3, int(w * 0.006)))
    sd.ellipse([ex - ph * 0.10, ey - ph * 0.035,
                ex + ph * 0.10, ey + ph * 0.035], fill=(14, 26, 18, 108))
    img = Image.alpha_composite(img, _blur(sh, max(2, int(h * 0.008))))

    # --- ערימת השלכת. נצרבת לפני הפנס: היא על הקרקע.
    d = ImageDraw.Draw(img)
    n = int(PROPS["leaves"]["n"])
    for i in range(n):
        lx, ly, ang = leaf_rest(i, n)
        px, py = lx * w, ly * h
        r = h * 0.0115 * (0.80 + 0.45 * (((i * 29) % 7) / 7.0))
        c = leaf_color(i)
        a = math.radians(ang)
        # עלה = אליפסה מוטה. שני קודקודים ומרכז, ולא עיגול: עיגול
        # חום על דשא נקרא כאבן.
        pts = []
        for k in range(10):
            th = 2 * math.pi * k / 10
            ux, uy = math.cos(th) * r, math.sin(th) * r * 0.46
            pts.append((px + ux * math.cos(a) - uy * math.sin(a),
                        py + ux * math.sin(a) + uy * math.cos(a)))
        d.polygon(pts, fill=c + (235,))

    # --- סל פיקניק על הספסל: גוף קלוע, שתי טבעות וידית.
    B = PROPS["basket"]
    bax, bay = B["at"][0] * w, B["at"][1] * h
    bw, bh = B["w"] * w, B["h"] * h
    wick_d, wick_l = _hsv(0.09, 0.62, 0.52), _hsv(0.11, 0.48, 0.78)
    d.rounded_rectangle([bax - bw * 0.5, bay - bh * 0.5,
                         bax + bw * 0.5, bay + bh * 0.5],
                        radius=int(bh * 0.22), fill=wick_d + (255,))
    for k in range(4):                            # קליעה: קווים אופקיים
        yy = bay - bh * 0.5 + bh * (0.22 + 0.19 * k)
        d.line([(bax - bw * 0.46, yy), (bax + bw * 0.46, yy)],
               fill=wick_l + (210,), width=max(1, int(bh * 0.07)))
    d.arc([bax - bw * 0.34, bay - bh * 1.25, bax + bw * 0.34, bay - bh * 0.05],
          200, 340, fill=wick_l + (255,), width=max(2, int(bh * 0.10)))
    # מטלית משובצת שמשתלשלת - זה מה שאומר "פיקניק" ולא "ארגז".
    d.polygon([(bax - bw * 0.42, bay - bh * 0.42),
               (bax + bw * 0.10, bay - bh * 0.52),
               (bax + bw * 0.02, bay - bh * 0.10),
               (bax - bw * 0.38, bay - bh * 0.04)],
              fill=_hsv(0.99, 0.55, 0.86) + (235,))

    # --- עמוד הפנס. אחרון, ולכן הוא מול הסל ומול העלים.
    pole_d, pole_l = _hsv(0.60, 0.16, 0.22), _hsv(0.60, 0.10, 0.38)
    pw = max(2.0, w * L["arm"] * 0.22)
    d.polygon([(bx - pw * 1.9, by), (bx + pw * 1.9, by),
               (bx + pw * 0.7, hy + ph * 0.06), (bx - pw * 0.7, hy + ph * 0.06)],
              fill=pole_d + (255,))
    d.line([(bx - pw * 0.25, by), (bx - pw * 0.25, hy)],
           fill=pole_l + (190,), width=max(1, int(pw * 0.5)))
    d.ellipse([bx - pw * 2.6, by - pw * 0.9, bx + pw * 2.6, by + pw * 0.9],
              fill=pole_d + (255,))              # בסיס
    # ראש הפנס: זכוכית טרפזית בתוך מסגרת, וכובע מעליה.
    gw, gh = w * L["arm"] * 0.95, ph * 0.105
    d.polygon([(hx - gw * 0.40, hy - gh * 0.5), (hx + gw * 0.40, hy - gh * 0.5),
               (hx + gw * 0.52, hy + gh * 0.5), (hx - gw * 0.52, hy + gh * 0.5)],
              fill=_hsv(0.13, 0.26, 0.90) + (238,))
    d.polygon([(hx - gw * 0.62, hy - gh * 0.52), (hx + gw * 0.62, hy - gh * 0.52),
               (hx, hy - gh * 1.05)], fill=pole_d + (255,))
    return img


def _dapple(size: int, rng: random.Random):
    """אריח אור מנוקד בין העלים. מונח כשכבת-על ונע בלופ.

    שחור = שקוף תחת `screen`, ולכן האריח מוסיף אור בלבד ולא מחשיך.

    **האריח חייב להתלכד עם עצמו, וזו תקלה שנראתה ברנדור המלא.**
    בדפדפן הוא מונח `background-repeat:repeat`, כלומר הוא חוזר כל
    `size` פיקסלים לרוחב כל הפריים. בניסיון הראשון הוא צויר כמו
    תמונה רגילה: כתם שמרכזו ליד הקצה נחתך בקצה ולא המשיך בצדו
    השני, והטשטוש משך פנימה את פיקסלי השפה. התוצאה הייתה **קו
    אנכי חד שעבר מלמעלה עד למטה בכל 1024 פיקסלים** - נמדד בפועל
    על ארבע תמונות בדיקה, תמיד באותו מרווח בדיוק. שני תיקונים
    נחוצים כאן, ואחד מהם לבדו אינו מספיק:
      1. כל כתם מצויר תשע פעמים, גם מעבר לארבעת הקצוות, כדי שמה
         שיוצא מצד אחד ייכנס מהצד השני.
      2. הטשטוש נעשה על פרישה של 3x3 אריחים וממנה נחתך המרכז,
         כי טשטוש על אריח בודד מערבב פיקסלי שפה עם עצמם ומשאיר
         שפה שאינה ממשיכה את האריח הבא.
    """
    from PIL import Image, ImageDraw
    img = Image.new("RGB", (size, size), (0, 0, 0))
    d = ImageDraw.Draw(img)
    # **כתמים גדולים ומעטים, ולא הרבה קטנים.** בניסיון הראשון היו
    # 90 כתמים ברדיוס של עד 5% מהאריח, והתוצאה על פנים בתקריב
    # נראתה כמו רעש או עובש ולא כמו אור שעבר בין עלים. אור מנוקד
    # אמיתי הוא כמה כתמים רחבים ומטושטשים מאוד.
    for _ in range(26):
        x, y = rng.uniform(0, size), rng.uniform(0, size)
        r = rng.uniform(size * 0.07, size * 0.17)
        v = rng.uniform(0.30, 0.90)
        c = _hsv(0.13, 0.20, v)
        for ox in (-size, 0, size):          # ציור מעוטף (שלב 1)
            for oy in (-size, 0, size):
                d.ellipse([x + ox - r, y + oy - r * 0.8,
                           x + ox + r, y + oy + r * 0.8], fill=c)
    # טשטוש מעוטף (שלב 2): פורש 3x3, מטשטש, וחותך את האריח המרכזי.
    big = Image.new("RGB", (size * 3, size * 3), (0, 0, 0))
    for ix in range(3):
        for iy in range(3):
            big.paste(img, (ix * size, iy * size))
    big = _blur(big, max(4, int(size * 0.055)))
    return big.crop((size, size, size * 2, size * 2))


def tile_seam(img) -> tuple[float, float]:
    """(תפר_אופקי, תפר_אנכי) של אריח - כמה הוא *לא* מתלכד עם עצמו.

    מחזיר את ההפרש הממוצע בין עמודת הקצה לעמודה שאמורה להמשיך
    אותה כשהאריח חוזר, **פחות** ההפרש הפנימי הטבעי בין שתי עמודות
    שכנות. אריח מתלכד נותן מספר סביב אפס; אריח שאינו מתלכד נותן
    מספר גדול, וזה בדיוק גודל הקפיצה שנראית כקו אנכי.
    """
    import numpy as np
    a = np.asarray(img.convert("L"), dtype=np.float32)
    wrap_x = float(np.abs(a[:, 0] - a[:, -1]).mean())
    inner_x = float(np.abs(a[:, 1] - a[:, 0]).mean())
    wrap_y = float(np.abs(a[0, :] - a[-1, :]).mean())
    inner_y = float(np.abs(a[1, :] - a[0, :]).mean())
    return (round(wrap_x - inner_x, 3), round(wrap_y - inner_y, 3))


# --------------------------------------------------------------- ציבורי

def bake(out_dir, location: dict, width: int = 1920, height: int = 1080,
         seed: int = 7) -> dict:
    """מצייר את כל שכבות הסביבה ל-PNG ומחזיר מניפסט.

    נקרא **פעם אחת** לפני הרינדור. המניפסט הוא מה שעובר לדפדפן.
    """
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    rng = random.Random(seed)
    w, h = int(width * PAD), int(height)

    az = float(location.get("sun_azimuth_deg", -62.0))
    el = float(location.get("sun_elevation_deg", 24.0))
    sun_dir = -1.0 if az < 0 else 1.0       # -1 = השמש משמאל
    shadow = shadow_vector(az, el)

    # מקום השמש על שכבת השמיים: azimuth לרוחב, elevation לגובה.
    sun_px = (w * (0.5 + az / 180.0 * 1.25),
              h * (0.52 - el / 90.0 * 0.95))

    # **קנה המידה נגזר מהמצלמה, ולא "נראה טוב".** דמות של 1.4 מ'
    # במרחק 4.3 מ' בשדה ראייה של 34 מעלות ממלאת כחצי פריים; עץ
    # פארק של 8 מ' במרחק 15 מ' ממלא כ-85%. הניסיון הראשון צייר
    # עצים בגובה 38% מהפריים, והתוצאה הייתה דמות שנראית ענקית
    # מול שיחים - הפריים "לא התחבר" בלי שאפשר להצביע על מה.
    # הכיול נעשה על שתי תמונות בדיקה ולא על נוסחה: 0.74 נתן דמות
    # שנראית ענקית מול שיחים, ו-1.6 חסם את השמיים לגמרי והפריים
    # נראה חנוק. הערך שעובד נותן עץ גבוה בערך פי שלושה מהדמות
    # ומשאיר רצועת שמיים מעל קו העצים.
    far_spec = [(i / 13 + rng.uniform(-0.02, 0.02), 0.572,
                 rng.uniform(0.46, 0.60)) for i in range(14)]
    ground_spec = [(0.11, 0.605, 1.12), (0.345, 0.585, 0.98),
                   (0.70, 0.596, 1.06), (0.925, 0.618, 1.24)]
    near_spec = [(0.015, 1.12, 2.10), (0.985, 1.16, 2.25)]

    files = {}
    _sky(w, h, sun_px, rng).convert("RGB").save(out / "sky.png")
    files["sky"] = "sky.png"
    _trees(w, h, far_spec, sun_dir, rng, alpha=150).save(out / "far.png")
    files["far"] = "far.png"
    gnd = _ground(w, h, ground_spec, shadow, rng)
    from PIL import Image
    gnd = Image.alpha_composite(
        gnd, _trees(w, h, ground_spec, sun_dir, rng))
    # האביזרים האינטראקטיביים (TASK 13) נצרבים **מעל** העצים של
    # שכבת הקרקע ומתחת לשכבה הקרובה: הם יושבים על השביל, לא ביניהם.
    gnd = Image.alpha_composite(gnd, _props(w, h, shadow, rng))
    gnd.save(out / "ground.png")
    files["ground"] = "ground.png"
    _trees(w, h, near_spec, sun_dir, rng).save(out / "near.png")
    files["near"] = "near.png"
    _dapple(1024, rng).convert("RGB").save(out / "dapple.png")
    files["dapple"] = "dapple.png"

    man = {
        "name": location.get("name", ""),
        "width": w, "height": h, "pad": PAD,
        "frame": [width, height],
        "sun": {"azimuth_deg": az, "elevation_deg": el,
                "px": [round(sun_px[0], 1), round(sun_px[1], 1)],
                "dir": sun_dir},
        "shadow": {"dx": round(shadow[0], 4), "dy": round(shadow[1], 4),
                   "length_per_height": round(math.hypot(*shadow), 4)},
        "wind": dict(location.get("wind") or {"speed": 0.35, "gust": 0.12}),
        "loop_sec": LOOP_SEC,
        # אורך הסרט. הלופ חייב להתחלק בו, ולכן הוא חייב להיות מוצהר
        # ולא מונח: 50 היה מקודד בקשיחות בתוך הבדיקה, וברגע שהתסריט
        # התארך ל-60 הבדיקה המשיכה לבדוק את המספר הקודם בשקט.
        "total_sec": float(location.get("total_seconds", 50.0)),
        "parallax": dict(PARALLAX),
        "layers": files,
        # מקומות האביזרים, כדי שהשכבה הדינמית תניח את האור ואת העלים
        # בדיוק על הגוף הסטטי שנצרב כאן.
        "props": {k: dict(v) for k, v in PROPS.items()},
        "baked_once": True,
    }
    (out / "env.json").write_text(
        json.dumps(man, ensure_ascii=False, indent=1), encoding="utf-8")
    return man


def validate(man: dict, out_dir) -> dict:
    """חוזה שכבת הסביבה. כל כלל כאן הוא תקלה שהייתה נראית רק ברנדור."""
    out: dict = {}
    d = Path(out_dir)

    def chk(name: str, ok, detail) -> None:
        out[name] = {"pass": bool(ok), "detail": str(detail)}

    need = ("sky", "far", "ground", "near", "dapple")
    miss = [k for k in need if not (d / man["layers"].get(k, "")).exists()]
    chk("כל חמש שכבות הסביבה נצרבו לקובץ", not miss, miss or sorted(need))

    chk("השכבות רחבות מהפריים כדי לאפשר סחיפה בלי פס שחור",
        man["width"] > man["frame"][0], (man["width"], man["frame"][0]))

    # **התקלה שנמדדה ברנדור המלא של 05/10.** אריח האור המנוקד מונח
    # ב-repeat, ואריח שאינו מתלכד עם עצמו מצייר קו אנכי חד בכל
    # מרווח של רוחב האריח, מלמעלה עד למטה. זה נראה רק בפריים מלא,
    # ולכן הוא נמדד כאן על הקובץ הצרוב ולא על העין.
    dap = d / man["layers"].get("dapple", "dapple.png")
    if dap.exists():
        from PIL import Image
        sx, sy = tile_seam(Image.open(dap))
        chk("אריח האור המנוקד מתלכד עם עצמו ואינו מצייר קו אנכי",
            max(sx, sy) <= 1.5, f"תפר אופקי {sx}, אנכי {sy}")
    else:
        chk("אריח האור המנוקד מתלכד עם עצמו ואינו מצייר קו אנכי",
            False, "אין קובץ אריח")

    # צל ארוך = שמש נמוכה. זו הדרישה המפורשת בתסריט.
    chk("הצל ארוך לפחות פעמיים מגובה העצם",
        man["shadow"]["length_per_height"] >= 2.0,
        man["shadow"]["length_per_height"])

    # השמש משמאל => הצל נמשך ימינה. סימן הפוך = צל שנופל לכיוון השמש.
    chk("הצל נופל אל מול השמש ולא לכיוונה",
        man["sun"]["dir"] * man["shadow"]["dx"] < 0,
        (man["sun"]["dir"], man["shadow"]["dx"]))

    chk("הפרלקס עולה מהרקע לקדמת הפריים",
        (man["parallax"]["sky"] < man["parallax"]["far"]
         < man["parallax"]["ground"] < man["parallax"]["near"]),
        man["parallax"])

    # לופ שאינו מתחלק באורך הסרט יוצר קפיצה בתפר.
    tot = float(man.get("total_sec", 50.0))
    chk("מחזור הלופ מתחלק באורך הסרט בדיוק",
        abs(tot / man["loop_sec"] - round(tot / man["loop_sec"])) < 1e-9,
        f"{tot}ש / {man['loop_sec']}ש")

    # --- האביזרים האינטראקטיביים (TASK 13)
    pr = man.get("props") or {}
    chk("שלושת האביזרים האינטראקטיביים רשומים במניפסט",
        set(pr) >= {"lamp", "leaves", "basket"}, sorted(pr))
    if pr:
        lam, lv, bs = pr["lamp"], pr["leaves"], pr["basket"]
        # ראש הפנס חייב להיות **מעל** הבסיס בציר התמונה (y קטן יותר),
        # אחרת הצל שמחושב מההפרש יוצא שלילי והוא נופל כלפי מעלה.
        chk("ראש הפנס מעל בסיסו, ולכן הצל שלו נופל לקרקע",
            lam["head"][1] < lam["base"][1] - 0.15,
            (lam["head"][1], lam["base"][1]))
        chk("ערימת העלים על השביל ולא באוויר",
            lv["at"][1] > 0.80, lv["at"])
        chk("בערימה לפחות 24 עלים", int(lv["n"]) >= 24, lv["n"])
        chk("סל הפיקניק יושב על גובה מושב הספסל",
            0.78 <= bs["at"][1] <= 0.87, bs["at"])
        # עלים שנצרבו בספירלה דטרמיניסטית: אותו אינדקס -> אותו מקום,
        # תמיד. בלי זה הפריים הראשון של האנימציה קופץ.
        a1 = leaf_rest(7, int(lv["n"]))
        a2 = leaf_rest(7, int(lv["n"]))
        chk("מקום העלה דטרמיניסטי לפי אינדקס", a1 == a2, a1)
        xs = [leaf_rest(i, int(lv["n"]))[0] for i in range(int(lv["n"]))]
        ys = [leaf_rest(i, int(lv["n"]))[1] for i in range(int(lv["n"]))]
        chk("הערימה פרושה ואינה נקודה אחת",
            max(xs) - min(xs) > lv["r"][0] and max(ys) - min(ys) > lv["r"][1] * 0.9,
            (round(max(xs) - min(xs), 4), round(max(ys) - min(ys), 4)))
        chk("כל העלים בתוך גבולות הפריים",
            all(0.0 < x < 1.0 for x in xs) and all(0.0 < y < 1.0 for y in ys),
            (round(min(xs), 3), round(max(xs), 3)))

    chk("יש רוח שמניעה את העלווה", (man["wind"].get("speed") or 0) > 0,
        man["wind"])

    # ההגנה מפני elevation אפס: אורך צל חסום.
    chk("אורך הצל חסום ולא מתפוצץ בשמש נמוכה",
        shadow_vector(-62.0, 0.0001)[0] ** 2 <= 36.0 + 1e-6,
        shadow_vector(-62.0, 0.0001))
    return out


def passed(man: dict, out_dir) -> bool:
    return all(v["pass"] for v in validate(man, out_dir).values())


def main(argv=None) -> int:
    import sys
    sys.stdout.reconfigure(encoding="utf-8")
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    from production.script import sunbeam50
    dest = Path(argv[0]) if argv else Path(
        r"D:\claude-bot\out\char3d\env\park")
    man = bake(dest, sunbeam50.LOCATION)
    rep = validate(man, dest)
    for k, v in rep.items():
        print(("✅" if v["pass"] else "❌"), k, "-", v["detail"])
    print(f"\n{dest}  ·  {man['width']}x{man['height']}  ·  "
          f"צל {man['shadow']['length_per_height']}x גובה")
    return 0 if passed(man, dest) else 1


if __name__ == "__main__":
    import sys
    raise SystemExit(main(sys.argv[1:]))
