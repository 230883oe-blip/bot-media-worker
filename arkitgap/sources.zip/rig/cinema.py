# -*- coding: utf-8 -*-
"""מבחן המשחק הקולנועי · TASK 10.

**מה המבחן הזה שואל, ולמה הוא שונה מכל מה שנבדק כאן עד היום.**
תשע המשימות הקודמות בדקו *יכולות*: יש ריג פנים, יש מנוע רגש, יש
משחק עיניים, יש תנועה משנית, הדמות נשארת מזוהה בשמונה תנאי צילום.
כל אלה נכונים וכולם עוברים - ואף אחד מהם אינו שואל את השאלה
שמבדילה בין להניע מודל לבין לביים שחקן:

    **האם אפשר להבין מה הדמות מרגישה כשמשתיקים את הקול?**

זה המבחן. סצנת דיאלוג של עשר שניות: דמות A אומרת משפט ניטרלי
רגשית, דמות B שומעת אותו ונעשית בהדרגה לא נוחה. על B לעשות שמונה
דברים - להביט ב-A, להבין את מה שנאמר, להסס, להסיט מבט לרגע, לשנות
הבעה, להעביר משקל, להגיב, ולשמור על רציפות רגשית גם אחרי שסיימה
לדבר. השינוי הרגשי חייב להיות מובן גם בלי שמע.

---

## שלושת הדברים שהופכים את זה למבחן ולא להצהרה

**1 · הקריאה אינה יודעת את התסריט.** `find_events` אינו מקבל את
לוח הזמנים; הוא **מוצא** את שמונת האירועים מתוך מסלול הבקרות -
מתי המבט עזב ואל מי חזר, מתי המהירות צנחה, מתי מרכז הכובד עבר רגל,
מתי וקטור הפנים החליף אשכול. רק אחרי שמצא, התוצאה מושווית ללוח
הזמנים. בדיקה שמקבלת את התשובה מראש אינה בדיקה.

**2 · ערוץ השמע מנותק בקוד, לא בהבטחה.** `visual_only` מסיר כל
בקרה שמונעת מההגאים - הלסת, השפתיים, הלשון, רוחב הפה. אם מישהו
יוסיף מחר ערוץ פה חדש, `AUDIO_DRIVEN` יתפוס אותו לפי התחילית
ולא לפי רשימה שמישהו יזכור לעדכן. זו הוכחה מבנית ש"בלי קול" -
המדידה **לא יכולה** לראות את הפה גם אם תרצה.

**3 · ציון אי-הנוחות נגזר מ-FACS ולא מהבחירות שלי.** זו הסכנה
האמיתית כאן: מי שגם מנפיש וגם מגדיר את מדד ההצלחה מודד את עצמו.
לכן המשקלים ב-`FACS_DISCOMFORT` הם יחידות התנועה שספרות הבעת
הפנים מייחסת למבוכה ולאי-נוחות - AU4 (כיווץ גבות), AU7 (התהדקות
עפעף), AU14 (גומה), AU24 (לחיצת שפתיים), AU15 (הורדת זווית פה),
והסטת מבט - ו-`acting.AU` כבר מחזיק את קודי ה-FACS האלה מ-TASK 02,
לפני שהמבחן הזה נכתב. ו**מה שבאמת שובר את המעגל** הוא `CONTROLS`:
חמש גרסאות ביקורת שחייבות **ליפול**. מדד שגם הן עוברות אותו אינו
מודד כלום, וזה מה שהבדיקה מוודאת.

---

## רציפות רגשית מול קיפאון - ההבחנה שהכריעה

"הרגש נשאר אחרי הדיבור" אפשר לזייף בדרך הגרועה ביותר: להקפיא את
הדמות. הציון יישאר גבוה והמדד יעבור, והתוצאה על המסך היא בובה.
דעה חיצונית (GLM, 05/10) נתנה את ההפרדה הנכונה, והיא מיושמת כאן
כשני תנאים שחייבים להתקיים **יחד**:

* הציון בזנב נשאר לפחות `TAIL_KEEP` ממה שהיה בשיא (רציפות), **וגם**
* יש מיקרו-תנועה - סטיית התקן של הערוצים הוויזואליים בזנב אינה
  אפס (חיים).

גרסת הביקורת `freeze` עוברת את הראשון ונופלת בשני; `reset` עוברת
את השני ונופלת בראשון. שתיהן בדוח.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
from dataclasses import dataclass, field, replace

import numpy as np

from . import acting, emotion as E

# ------------------------------------------------------------- התסריט

#: המשפט של A. **ניטרלי רגשית במתכוון** - אין בו מילת רגש, אין בו
#: האשמה ואין בו שאלה. כל מה שקורה ל-B קורה בגללה ולא בגלל הניסוח,
#: וזו בדיוק הדרישה: "Character A says something emotionally neutral".
A_LINE = "ראיתי את הרשימה על השולחן."

#: והתשובה של B. גם היא ניטרלית במילים - התוכן הרגשי כולו בהופעה.
B_LINE = "שכחתי אותה שם."

SCENE_LEN = 10.0
FPS = 30

#: חלון הדיבור של A, ושל B. הפער ביניהם הוא החלל שבו כל המשחק קורה.
A_SPEECH = (0.55, 3.53)
B_SPEECH = (6.60, 8.79)

#: לוח הזמנים של שמונת האירועים. **אינו** מועבר ל-`find_events` -
#: הוא רק מה שמשווים אליו אחרי שהאירועים נמצאו. הטווחים רחבים
#: בכוונה: מבחן שדורש אירוע בפריים מדויק מודד את התזמון שלי ולא
#: את המשחק.
BEAT_WINDOWS: dict[str, tuple[float, float]] = {
    "look_at_a":       (0.00, 2.60),
    "understand":      (3.20, 4.60),
    "hesitate":        (3.90, 5.60),
    "look_away":       (4.40, 6.40),
    "expression_turn": (3.60, 6.60),
    # העברת המשקל מגיעה **לפני** שההבעה מתגבשת, וזה נכון ולא פשרה:
    # חלוקת משקל היא תגובה גופנית לא-רצונית, ומי שמחכה שהיא תקרה
    # אחרי ההבעה מקבל גוף שרץ אחרי הפנים. הדרישה היא שתקרה אחרי
    # שנאמר המשפט ולפני שהתגובה נגמרת.
    "weight_shift":    (3.80, 7.60),
    "respond":         (6.40, 8.80),
    "continuity":      (8.60, 10.00),
}


def beats() -> list[tuple[float, float, E.Situation]]:
    """שני הביטים של B, ומה שמפריד ביניהם.

    לא אחד. דמות ששומעת משפט ומשתנה בגללו עוברת **ביט** ברגע
    ההבנה, ולפניו היא באמת ניטרלית - לא "פחות לא נוחה". מצב אחד
    עם קשת רגש פרוסה על עשר שניות היה מתחיל להיות לא נוח כבר
    בשנייה הראשונה, כלומר לפני שנאמר לה משהו, וזה הכשל שהמבחן
    הזה אמור לתפוס אצל אחרים.
    """
    listen = E.Situation(
        knows="שהוא חזר מוקדם", wants="להקשיב", feels="neutral",
        hides="", looks_at="partner", change="",
        knows_more=0.0, want_strength=0.35, intensity=0.6,
        shot_len=4.2, line="")
    land = E.Situation(
        knows="מה היה כתוב ברשימה ושהיא לא הייתה אמורה להגיע אליו",
        wants="שזה פשוט ייעלם", feels="discomfort", hides="shame",
        looks_at="partner", change="neutral->discomfort",
        knows_more=1.0, want_strength=0.85, intensity=1.0,
        shot_len=SCENE_LEN - 3.6, line=B_LINE)
    return [(0.0, 3.6, listen), (3.6, SCENE_LEN, land)]


def situation_a() -> E.Situation:
    """A. מוסר מידע, לא מאשים. זה מה שהופך את המשפט לניטרלי גם
    בהופעה ולא רק במילים - אם A היה מאשים, אי-הנוחות של B הייתה
    תגובה לטון ולא להבנה."""
    return E.Situation(
        knows="שהוא ראה את הרשימה", wants="להגיד את זה ולהמשיך",
        feels="neutral", hides="", looks_at="partner", change="",
        knows_more=0.0, want_strength=0.3, intensity=0.5,
        shot_len=SCENE_LEN, line=A_LINE)


# ------------------------------------------- מה המדידה מותר לה לראות

#: ערוצי בקרה שההגאים מניעים. המדידה **אינה נוגעת בהם**, וזו
#: המשמעות המעשית של "מובן גם כשהקול מושתק": לא הצהרה בדוח אלא
#: סינון בקוד, שחל גם על ערוץ שייווסף מחר.
AUDIO_DRIVEN = ("jaw_", "mouth_", "lip_", "tongue_", "viseme",
                "teeth", "smile")

#: ולא רק תחיליות - גם שמות מלאים שאינם נושאים תחילית מזהה.
AUDIO_EXACT = frozenset({"jaw", "chin_raise"})


def is_audio_driven(key: str) -> bool:
    return key in AUDIO_EXACT or key.startswith(AUDIO_DRIVEN)


def visual_only(frame: dict) -> dict:
    """הפריים בלי שום ערוץ שהשמע מניע."""
    return {k: v for k, v in frame.items() if not is_audio_driven(k)}


# --------------------------------------------- ציון אי-נוחות לפי FACS

#: יחידות התנועה שספרות הבעת הפנים מייחסת למבוכה/אי-נוחות, והמשקל
#: של כל אחת. השמות הם שמות `acting.AU`, ולכן הקוד **מאמת** שכל אחד
#: מהם קיים ומה קוד ה-FACS שלו - שם שיומצא כאן ייפול ב-`audit`.
FACS_DISCOMFORT: dict[str, float] = {
    "brow_lower":      1.00,   # AU4  · כיווץ גבות
    "lid_tighten":     0.90,   # AU7  · התהדקות עפעף תחתון
    "lip_press":       0.85,   # AU24 · לחיצת שפתיים
    "dimple":          0.55,   # AU14 · גומה (מתח בזווית הפה)
    "corner_depress":  0.70,   # AU15 · הורדת זווית הפה
    "brow_inner_raise": 0.45,  # AU1  · גבה פנימית - האיבר שדולף
    "cheek_hollow":    0.35,   # AU35
}

#: ...ושלושה סימנים שאינם פנים. הסטת מבט היא הסימן ההתנהגותי
#: החזק ביותר למבוכה, והתכנסות הגוף (כתף קדימה, עמוד שדרה פנימה)
#: היא מה שמבדיל אי-נוחות מריכוז.
FACS_BODY = {
    "gaze_aversion": 1.10,
    "shoulder_fwd":  0.60,
    "head_down":     0.50,
}

#: שלושת האלה **אינם** אי-נוחות והם מקוזזים, אחרת כל פנים פעילות
#: מקבלות ציון. חיוך ופתיחת עיניים הם ההפך הגמור ממבוכה.
FACS_RELIEF = {"cheek_raise": 0.55, "lid_raise": 0.30}


def _au_channels(au_name: str) -> list[str]:
    """שמות הבקרות וצורות הפנים שיחידת תנועה נוגעת בהן, **משני
    הצדדים**. נגזר מ-`acting.AU` ולא נכתב כאן: רשימה ידנית מתיישנת
    ברגע שמישהו מוסיף בקרה ליחידה."""
    au = acting.AUS.get(au_name) if hasattr(acting, "AUS") else None
    if au is None:
        au = next((a for a in getattr(acting, "AU_LIST", [])
                   if a.name == au_name), None)
    if au is None:
        return []
    out = []
    for src in (au.ctl or {}, au.mph or {}):
        for base in src:
            out += ([f"{base}_L", f"{base}_R"] if au.sided else [base])
    return out


def discomfort(frame: dict) -> float:
    """ציון אי-הנוחות של פריים אחד, מהערוצים הוויזואליים בלבד.

    הערך אינו מנורמל ל-0..1 ואין בכך צורך: כל המבחנים כאן הם על
    **יחסים ועל סדר** (עולה? הפער גדול מהרעש? הזנב שומר על אחוז
    מהשיא?), ונרמול שרירותי רק היה מוסיף קבוע שאפשר לכוון אותו
    עד שהבדיקה תעבור.
    """
    vis = visual_only(frame)
    s = 0.0
    for au_name, w in FACS_DISCOMFORT.items():
        chans = _au_channels(au_name)
        if not chans:
            continue
        v = sum(abs(float(vis.get(c, 0.0))) for c in chans) / len(chans)
        s += w * v
    for au_name, w in FACS_RELIEF.items():
        chans = _au_channels(au_name)
        if not chans:
            continue
        v = sum(max(0.0, float(vis.get(c, 0.0))) for c in chans) / len(chans)
        s -= w * v
    # הסטת מבט: המרחק של כיוון המבט ממרכז. `eye_aim` מנורמל, ולכן
    # הגודל הזה הוא ישירות "כמה היא לא מסתכלת עליו".
    ax = float(vis.get("eye_aim_x", 0.0))
    ay = float(vis.get("eye_aim_y", 0.0))
    s += FACS_BODY["gaze_aversion"] * min(1.0, math.hypot(ax, ay))
    s += FACS_BODY["shoulder_fwd"] * max(0.0, float(vis.get("shoulder_fwd", 0.0)))
    s += FACS_BODY["head_down"] * max(0.0, -float(vis.get("head_pitch", 0.0)))
    return float(s)


# ------------------------------------------------------------- הדגימה

@dataclass
class Track:
    """מסלול הבקרות של דמות אחת לאורך הסצנה."""
    name: str
    times: np.ndarray
    frames: list[dict]
    variant: str = "full"
    speech: tuple[float, float] = (0.0, 0.0)

    @property
    def fps(self) -> float:
        return 1.0 / float(self.times[1] - self.times[0])

    def channel(self, key: str) -> np.ndarray:
        return np.array([float(f.get(key, 0.0)) for f in self.frames])

    def score(self) -> np.ndarray:
        return np.array([discomfort(f) for f in self.frames])

    def visual_matrix(self) -> tuple[list[str], np.ndarray]:
        """כל הערוצים הוויזואליים כמטריצה (זמן × ערוץ)."""
        keys = sorted({k for f in self.frames for k in f
                       if not is_audio_driven(k)})
        m = np.array([[float(f.get(k, 0.0)) for k in keys]
                      for f in self.frames])
        return keys, m

    def at(self, t: float) -> dict:
        return self.frames[int(np.clip(np.searchsorted(self.times, t), 0,
                                       len(self.frames) - 1))]

    def window(self, t0: float, t1: float) -> np.ndarray:
        return (self.times >= t0) & (self.times <= t1)


#: גרסאות הביקורת. כל אחת שוברת **דרישה אחת** של התסריט, וחייבת
#: ליפול בדיוק במבחן שמגן עליה. זה כל מה שמונע מהמדד למדוד את עצמו.
CONTROLS = {
    "neutral": "B נשארת ניטרלית לגמרי - רק הפה זז לפי ההגאים",
    "flat":    "B לא נוחה באותה עוצמה מהשנייה הראשונה, בלי התפתחות",
    "reset":   "B חוזרת לניטרלי ברגע שסיימה לדבר",
    "freeze":  "B קופאת לגמרי אחרי הדיבור - ציון גבוה בלי חיים",
    "mute":    "B מגיבה רק בפה, בלי עיניים, פנים או גוף",
}


def take(variant: str = "full", who: str = "b", fps: int = FPS) -> Track:
    """דוגם את הסצנה. `variant="full"` היא הסצנה האמיתית; השאר הן
    גרסאות הביקורת מ-`CONTROLS`.

    הבנייה עוברת דרך `showreel._emotion_actor` - **אותו מסלול
    שמייצר את הסרטון עצמו**, ולא דרך שכבה מקבילה. מבחן שבונה לעצמו
    נתונים בדרך אחרת מזו שרצה בייצור בודק קוד שאיש אינו מריץ.
    """
    n = int(round(SCENE_LEN * fps)) + 1
    ts = np.linspace(0.0, SCENE_LEN, n)
    fn = actor(variant, who)
    # **הפריים הוא ctl *וגם* mph.** חצי מטבלת ה-FACS יושבת בצורות
    # פנים ולא בבקרות עצמות - `lid_tighten` (AU7), `lip_press`
    # (AU24), `mouth_corner_down` (AU15) ו-`mouth_dimple` (AU14)
    # כולן mph. גרסה שלקחה רק את ה-ctl מדדה שלוש יחידות מתוך שבע
    # והחזירה ציון שעובד, וזו בדיוק הסכנה: מדידה חלקית שמצליחה
    # אינה מסגירה את עצמה.
    frames = []
    for t in ts:
        ctl, _, mph = fn(0.0, float(t))
        frames.append({**ctl, **mph})
    return Track("A" if who == "a" else "B", ts, frames,
                 "full" if who == "a" else variant,
                 A_SPEECH if who == "a" else B_SPEECH)


def actor(variant: str = "full", who: str = "b"):
    """פונקציית הסצנה: `(u, t) -> (ctl, {}, mph)`.

    **אותה פונקציה בדיוק** משרתת את המבחן ואת הסרטון. זו לא נוחות:
    מבחן שבונה לעצמו נתונים בדרך אחרת מזו שרצה בייצור בודק קוד
    שאיש אינו מריץ, ואז "עבר" ו"נראה טוב" מתפצלים בלי שאיש ישים
    לב. הבנייה עוברת דרך `showreel._emotion_actor`, שהוא המסלול
    שמייצר את הסרטון עצמו.
    """
    from . import showreel as SR                      # noqa: PLC0415
    if variant not in CONTROLS and variant != "full":
        raise ValueError(f"גרסה לא מוכרת: {variant}")

    if who == "a":
        fa, _ = SR._emotion_actor(situation_a(), seed=11.0, phase=0.0,
                                  speech=(A_SPEECH,), voice="avri", body=True)
        return fa

    bs = beats()
    # --- הגרסאות שמשנות את **המצב** ולא את הפלט.
    if variant in ("neutral", "mute"):
        bs = [(t0, t1, replace(s, feels="neutral", hides="",
                               change="", intensity=0.0))
              for t0, t1, s in bs]
    elif variant == "flat":
        # אותה אי-נוחות בדיוק מהשנייה הראשונה, בלי קשת.
        bs = [(0.0, SCENE_LEN, replace(bs[1][2], change="",
                                       shot_len=SCENE_LEN))]

    acts = []
    for t0, t1, s in bs:
        sp = ((B_SPEECH[0] - t0, B_SPEECH[1] - t0),) if s.line else ()
        fb, _ = SR._emotion_actor(
            s, seed=7.0, phase=0.4, speech=sp,
            reacts=((max(0.0, 3.55 - t0), 1.0),) if s.hides else (),
            hesitate=(0,) if s.hides else (),
            voice="hila" if s.line else "", body=True)
        acts.append((t0, t1, fb))

    def fn(u, t):
        t = float(t)
        i = max(0, sum(1 for t0, _, _ in acts if t >= t0) - 1)
        t0, _, f = acts[i]
        cur = f(0.0, t - t0)[0]
        # מעבר רך בין ביטים: בימאי לא מחליף מצב בפריים אחד, והמעבר
        # הזה הוא גם מה שמייצר את העיכוב הקוגניטיבי שנראה על המסך.
        if i > 0:
            pt0, _, pf = acts[i - 1]
            w = float(np.clip((t - t0) / BLEND, 0.0, 1.0))
            w = w * w * (3.0 - 2.0 * w)
            if w < 1.0:
                prev = pf(0.0, t - pt0)[0]
                cur = {k: prev.get(k, 0.0) * (1.0 - w) + v * w
                       for k, v in cur.items()}
        # הזנב מוחל על **שני** הערוצים. גרסה שהקפיאה רק את בקרות
        # העצמות השאירה את צורות הפנים חיות, ולכן `freeze` עברה את
        # מבחן הרציפות - כלומר ההפרכה שנועדה לתפוס בובה מוקפאת
        # עברה בעצמה. נתפס בהרצה.
        return (_tail_frame(cur, t, variant), {},
                _tail_frame(f(0.0, t - t0)[2], t, variant, "mph"))

    # חלון הדיבור נחשף **בציר הסצנה המלא** ולא בציר הביט. פס הקול
    # של הסרטון (`showreel.soundtrack_cues`) נשען על `fn.speech
    # .windows[0][0]` כדי לדעת מתי להתחיל את ההקלטה, ובציר הביט
    # הערך הוא 3.0 במקום 6.6 - כלומר ההקלטה הייתה נכנסת שלוש
    # שניות ושש עשיריות מוקדם מדי, בלי שום שגיאה.
    class _Win:
        windows = (B_SPEECH,)

    fn.speech = _Win()
    fn.track = getattr(acts[-1][2], "track", None)
    fn.body = getattr(acts[-1][2], "body", None)
    fn.spk = getattr(acts[-1][2], "speech", None)
    return fn


BLEND = 0.75        #: שניות המעבר בין שני הביטים


_FREEZE_HOLD: dict[str, dict] = {}


def _tail_frame(f: dict, t: float, variant: str, lane: str = "ctl") -> dict:
    """גרסאות הביקורת שפוגעות **בזנב** - אחרי שהדיבור נגמר."""
    if variant == "mute":
        # רק הפה. כל ערוץ ויזואלי מאופס - זו "אנימציית שפתיים"
        # קלאסית, וזה בדיוק מה שהמבחן הזה אמור לפסול.
        return {k: (v if is_audio_driven(k) else 0.0) for k, v in f.items()}
    end = B_SPEECH[1]
    key = f"{variant}/{lane}"
    if variant not in ("reset", "freeze"):
        return f
    if t < end:
        _FREEZE_HOLD.pop(key, None)
        return f
    if variant == "reset":
        u = float(np.clip((t - end) / 0.25, 0.0, 1.0))
        return {k: (v if is_audio_driven(k) else v * (1.0 - u))
                for k, v in f.items()}
    hold = _FREEZE_HOLD.setdefault(key, dict(f))
    return {k: (v if is_audio_driven(k) else hold.get(k, 0.0))
            for k, v in f.items()}


# ------------------------------------------- איתור שמונת האירועים

SMOOTH_S = 0.25         #: חלון ההחלקה, שניות


def _smooth(x: np.ndarray, dt: float, secs: float = SMOOTH_S) -> np.ndarray:
    """ממוצע נע לפני כל איתור אירוע.

    **זו לא קוסמטיקה אלא תיקון של מה שנמדד.** בלי החלקה כל הגלאים
    כאן ירו ב-2.4 שניות, על **מצמוץ אחד** של שחקן העיניים: שני
    פריימים שבהם הציון קפץ מ-0.02 ל-0.46 וחזר. צופה אינו רואה
    ספייק של 70 מילישניות כשינוי רגשי - הוא רואה מגמה, והמבחן הזה
    שואל מה *מובן לצופה*. גלאי שתופס מצמוץ כ"היא הבינה" מודד
    רעש ומדווח עליו בביטחון מלא.
    """
    k = max(1, int(round(secs / max(dt, 1e-9))))
    if k < 2 or len(x) < k:
        return np.asarray(x, float)
    pad = k // 2
    p = np.pad(np.asarray(x, float), (pad, pad), mode="edge")
    return np.convolve(p, np.ones(k) / k, mode="valid")[:len(x)]


#: עד כאן זו **התייצבות פוזת המנוחה** ולא משחק. `BodyActor` מביא
#: את המשקל לערך של היציבה דרך `_lag` עם קבוע זמן של כ-0.4 שניות,
#: כלומר שלוש-ארבע שניות עד התייצבות מלאה - וזה קורה בכל שוט בלי
#: קשר לתוכן. נמדד שגלאי העברת המשקל ירה על ההתייצבות הזו (2.6ש,
#: לפני שנאמר לדמות משהו בכלל). הגבול נקבע לסוף המשפט של A, כי
#: לפניו אין בכלל למה להגיב.
SETTLE_T = A_SPEECH[1]


def find_events(tb: Track, ta: Track | None = None) -> dict:
    """מאתר את שמונת האירועים **מתוך התנועה**, בלי לדעת את התסריט.

    זו הנקודה שהופכת את הקובץ הזה למבחן. אם הייתי מקבל כאן את
    `BEAT_WINDOWS` ובודק שהערך בחלון גבוה, הייתי בודק שהמספר שכתבתי
    נמצא היכן שכתבתי אותו. כל אירוע כאן מוגדר כ**תופעה** - מבט
    שעזב וחזר, מהירות שצנחה, מרכז כובד שעבר רגל - והזמן שלו נמצא.
    """
    t = tb.times
    dt = float(t[1] - t[0])
    sc = _smooth(tb.score(), dt)
    ax, ay = tb.channel("eye_aim_x"), tb.channel("eye_aim_y")
    aim = _smooth(np.hypot(ax, ay), dt)
    keys, M = tb.visual_matrix()
    speed = _smooth(np.abs(np.gradient(M, dt, axis=0)).mean(axis=1), dt)
    found: dict[str, dict] = {}

    # 1 · מביטה ב-A: המבט קרוב למרכז (היעד "partner" הוא אפס) לאורך
    #     רצף ממשי לפני שהיא מגיבה.
    on = aim <= GAZE_ON
    idx = _longest_run(on & (t <= 4.0))
    found["look_at_a"] = {
        "found": bool(idx is not None and (idx[1] - idx[0]) * dt >= 0.8),
        "at": round(float(t[idx[0]]), 2) if idx else None,
        "how": (f"מבט על בן השיח ברצף {((idx[1]-idx[0])*dt):.2f}ש"
                if idx else "אין רצף מבט"),
    }

    # 2 · הבינה: הפעם הראשונה שהציון עובר רבע מהדרך מקו הבסיס אל
    #     השיא. **לא** "חצה שלוש סטיות מהרקע" - נמדד שסף כזה נדלק
    #     על מצמוץ, כי סטיית התקן של שתי שניות שקטות היא כמעט אפס
    #     וכל ספייק חוצה אותה. סף שנגזר מהטווח הדינמי של הסצנה
    #     עצמה הוא מה שהצופה באמת רואה: "היא התחילה להשתנות".
    base = float(np.median(sc[t <= 2.0]))
    peak = float(sc.max())
    thr = base + UNDERSTAND_RISE * (peak - base)
    # **חצייה מתמשכת ולא חצייה.** סף לבדו לא מספיק בשום גובה: ב-0.25
    # הוא נחצה רק ב-4.87 (מאוחר מדי), וב-0.15 כבר ב-2.50 - על רעד
    # חולף שחוזר מיד. ההבדל בין רעד להבנה אינו הגובה אלא ה**משך**:
    # רגש שנחת נשאר. לכן נדרש רצף של `UNDERSTAND_HOLD` שניות מעל
    # הסף, ובכל סף בטווח הסביר התשובה יוצאת אותה תשובה.
    hold = max(1, int(round(UNDERSTAND_HOLD / dt)))
    runs = [r for r in _runs((sc > thr) & (t > 1.0))
            if r[1] - r[0] >= hold]
    found["understand"] = {
        "found": bool(runs),
        "at": round(float(t[runs[0][0]]), 2) if runs else None,
        "how": (f"הציון חצה {thr:.3f} ({UNDERSTAND_RISE:.0%} מהדרך מקו "
                f"הבסיס {base:.3f} אל השיא {peak:.3f}) ונשאר שם "
                f"{UNDERSTAND_HOLD}ש לפחות"
                if runs else "הציון לא חרג מקו הבסיס ברצף"),
    }
    a_end = (ta.speech[1] if ta else A_SPEECH[1])
    found["understand"]["after_a_finished"] = bool(
        runs and t[runs[0][0]] >= a_end - 0.25)

    # 3 · היססה: האטה **אחרי שהבינה ולפני שהגיבה**. זה בדיוק החלל
    #     שבו היסוס אנושי יושב - אחרי שנפל האסימון, לפני שנפתח הפה -
    #     והחיפוש מוגבל אליו ולא לכל הסצנה. ההאטה היא המינימום
    #     המקומי של המהירות, כלומר הרגע שבו היא הכי קפאה בין השניים.
    u_at = found["understand"].get("at")
    lo = (u_at if u_at is not None else 2.0) + 0.2
    live = (t > lo) & (t < B_SPEECH[0] - 0.2)
    if live.any() and speed[live].max() > 1e-9:
        ref = float(speed[(t > lo - 1.2) & (t < lo)].max()
                    if ((t > lo - 1.2) & (t < lo)).any() else speed[live].max())
        idx = np.nonzero(live)[0]
        lim = max(ref, speed[live].max()) * HESITATE_DROP
        under = idx[speed[idx] <= lim]
        # ההאטה **הראשונה** ולא העמוקה ביותר: העמוקה ביותר היא תמיד
        # השקט שרגע לפני פתיחת הפה, וזה כבר לא היסוס אלא נשימה.
        k = int(under[0]) if len(under) else int(idx[0])
        ok = bool(len(under))
    else:
        ref, k, ok = 0.0, 0, False
    found["hesitate"] = {
        "found": ok,
        "at": round(float(t[k]), 2) if ok else None,
        "how": (f"המהירות צנחה ל-{speed[k]:.4f} - {HESITATE_DROP:.0%} מרמת "
                f"התנועה שלפניה ({ref:.4f}) - בין ההבנה לתגובה"
                if ok else "לא נמצאה האטה בין ההבנה לתגובה"),
    }

    # 4 · הסיטה מבט וחזרה: המבט עזב את בן השיח וחזר. **ההסטה
    #     הדומיננטית ולא הראשונה** - saccade של מנוחה עובר אף הוא
    #     את הסף, ובחירת הראשון החזירה מצמוץ בשנייה 2.4. הדירוג
    #     הוא לפי שטח (עומק × משך): זה מה שהצופה רואה כ"היא הסיטה
    #     מבט", ולא קפיצה בת שני פריימים.
    away = aim > GAZE_AWAY
    cand = [(i, j) for i, j in _runs(away & (t > SETTLE_T))
            if LOOK_AWAY_MIN <= (j - i) * dt <= LOOK_AWAY_MAX
            and j < len(t) - 1]
    hit = max(cand, key=lambda p: float(aim[p[0]:p[1]].sum())) if cand \
        else None
    found["look_away"] = {
        "found": hit is not None,
        "at": round(float(t[hit[0]]), 2) if hit else None,
        "how": (f"המבט עזב ל-{((hit[1]-hit[0])*dt):.2f}ש בעומק "
                f"{float(aim[hit[0]:hit[1]].max()):.2f} וחזר"
                if hit else "אין הצצה הצידה שחוזרת"),
    }

    # 5 · שינתה הבעה: וקטור הפנים (בלי פה, בלי מבט) התרחק מעצמו
    #     בתחילת הסצנה יותר מכפי שהוא נע בתוך ההתחלה.
    fk = [i for i, k in enumerate(keys)
          if any(k.startswith(p) for p in FACE_PREFIX)]
    found["expression_turn"] = _turn(t, M[:, fk], dt, "הבעת הפנים")

    # 6 · העבירה משקל: **קצב** השינוי ולא המרחק מההתחלה. המדידה
    #     הראשונה כאן לקחה `argmax|w - w[0]|` וקיבלה 2.6 שניות -
    #     וזו לא העברת משקל אלא **התייצבות פוזת המנוחה** של
    #     `BodyActor`, שנמשכת כשתי שניות מתחילת השוט בכל שוט שהוא.
    #     מה שהעין קוראת כהעברת משקל הוא הרגע שבו הגוף עובר רגל,
    #     כלומר שיא המהירות - ולכן גם חלון ההתייצבות מוחרג.
    wch = tb.channel("weight_shift")
    if not np.any(np.abs(wch) > 1e-9):
        wch = tb.channel("hips_shift")
    ws = _smooth(wch, dt, 0.35)
    rate = np.abs(np.gradient(ws, dt))
    ok_t = t > SETTLE_T
    k = int(np.nonzero(ok_t)[0][int(np.argmax(rate[ok_t]))])
    seg = ws[ok_t]
    swing = float(seg.max() - seg.min())
    found["weight_shift"] = {
        "found": bool(swing >= WEIGHT_MIN),
        "at": round(float(t[k]), 2),
        "how": f"מרכז הכובד עבר {swing:.3f} (מינימום {WEIGHT_MIN}), "
               f"בשיא קצב של {rate[k]:.3f} ליחידת זמן",
    }

    # 7 · הגיבה: הפה נפתח ברצף. **זה האירוע היחיד שמותר לו להסתכל
    #     על ערוץ הפה**, כי "להגיב" פירושו לדבר - וגם כאן נמדדת
    #     פתיחת לסת ולא פס הקול.
    jaw = tb.channel("jaw_open")
    talk = _longest_run(jaw > 0.05)
    found["respond"] = {
        "found": bool(talk is not None and (talk[1] - talk[0]) * dt >= 0.5),
        "at": round(float(t[talk[0]]), 2) if talk else None,
        "how": (f"הלסת נפתחה ברצף {((talk[1]-talk[0])*dt):.2f}ש"
                if talk else "הפה לא נפתח"),
    }

    # 8 · רציפות רגשית: ראה `continuity`.
    found["continuity"] = continuity(tb)
    return found


GAZE_ON = 0.22          #: מתחת לזה - מביטה בבן השיח
GAZE_AWAY = 0.30        #: מעל זה - המבט עזב
LOOK_AWAY_MIN = 0.18    #: הצצה קצרה מזה היא מצמוץ, לא הסטה
LOOK_AWAY_MAX = 2.60    #: ארוכה מזה אינה "briefly"
HESITATE_DROP = 0.55
WEIGHT_MIN = 0.12
#: כמה מהדרך מקו הבסיס אל השיא נחשב "התחילה להשתנות". ‎15%‎ ולא
#: ‎25%‎: המדידה כוללת גם צורות פנים, ולכן השיא גבוה יותר וסף
#: יחסי גבוה מאחר את זיהוי ההבנה בשבע עשיריות השנייה. זה הסף
#: שבו השינוי יוצא מתחום הרעש ונעשה נראה.
UNDERSTAND_RISE = 0.18
UNDERSTAND_HOLD = 0.60  #: וחייב להישאר שם, אחרת זה רעד ולא הבנה
#: ערוצי ההבעה. **`blink` אינו ברשימה, וזה לא השמטה.** מצמוץ הוא
#: רפלקס ולא הבעה: הוא מרים את מרחק וקטור הפנים ל-1.05 לשני
#: פריימים ומחזיר אותו, ובדיוק הוא זה שגרם לגלאי לדווח "ההבעה
#: התחלפה" בשנייה 2.4 - לפני שנאמר לדמות דבר. squint (AU44) כן
#: נשאר: צמצום עפעפיים מרצון הוא חלק מההבעה.
FACE_PREFIX = ("brow_", "lid_", "squint", "cheek_", "nose_", "eye_wide")
TAIL_KEEP = 0.55        #: הזנב שומר לפחות כך מהשיא
TAIL_LIFE = 2e-4        #: ומתחת לזה הוא קפוא ולא רגוע


def _turn(t, M, dt, what: str) -> dict:
    """האם הווקטור `M` **החליף מצב** - התרחק מההתחלה יותר מכפי
    שהוא נע בתוך ההתחלה עצמה. ההשוואה לרעש הפנימי היא מה שמונע
    מרעידה קטנה להיחשב כשינוי הבעה."""
    if M.shape[1] == 0:
        return {"found": False, "at": None, "how": f"אין ערוצי {what}"}
    head = M[t <= 1.5]
    ref = head.mean(axis=0)
    noise = float(np.linalg.norm(head - ref[None, :], axis=1).max())
    d = _smooth(np.linalg.norm(M - ref[None, :], axis=1), dt)
    # **חצי העלייה ולא חציית הסף.** המרחק חוצה כל סף סביר כבר
    # במצמוץ הראשון; הזמן שבו הוא מגיע לחצי מהשינוי הכולל הוא
    # מדד יציב של "מתי ההבעה באמת התחלפה", והוא אינו תלוי בסף.
    # הקצה נמדד בחציון של הזנב ולא ב-`max`: מצמוץ אחד מרים את
    #     המקסימום, ואז "חצי השינוי" נופל מוקדם מדי. חציון עמיד לו.
    lo = float(d[t <= 1.5].mean())
    hi = float(np.median(d[t >= t[-1] - 2.0]))
    rise = hi - lo
    half = lo + 0.5 * rise
    over = np.nonzero(d >= half)[0]
    return {
        "found": bool(rise > max(noise * 2.0, 0.04) and len(over)),
        "at": round(float(t[over[0]]), 2) if len(over) else None,
        "how": (f"{what} התרחקה {rise:.3f} מקו הפתיחה (פי "
                f"{rise/max(noise,1e-6):.1f} מהרעש בתוכו), וחצי מהשינוי "
                f"הושלם כאן"),
    }


def continuity(tb: Track) -> dict:
    """הרגש נשאר אחרי הדיבור - **ולא בגלל שהדמות קפאה**.

    שני תנאים שחייבים להתקיים יחד, וזו כל ההבחנה: ציון שנשאר גבוה
    (רציפות) **וגם** מיקרו-תנועה שלא נעלמה (חיים). תנאי אחד לבדו
    נותן ציון מלא לבובה מוקפאת, וזו הדרך הקלה ביותר לזייף את
    הדרישה הזו.
    """
    t, sc = tb.times, tb.score()
    tail = t > tb.speech[1]
    mid = (t > tb.speech[0] - 2.0) & (t <= tb.speech[1])
    if not tail.any() or not mid.any():
        return {"found": False, "how": "אין זנב אחרי הדיבור"}
    base = float(sc[t <= 1.5].mean())
    peak = float(sc[mid].max())
    keep = (float(sc[tail].mean()) - base) / max(1e-6, peak - base)
    _, M = tb.visual_matrix()
    life = float(np.abs(np.diff(M[tail], axis=0)).mean()) if tail.sum() > 1 \
        else 0.0
    return {
        "found": bool(keep >= TAIL_KEEP and life >= TAIL_LIFE),
        "at": round(float(t[tail][0]), 2),
        "keep": round(keep, 3), "life": round(life, 6),
        "how": (f"הזנב שומר {keep:.0%} מהשיא (מינימום {TAIL_KEEP:.0%}) "
                f"ומיקרו-תנועה {life:.2e} (מינימום {TAIL_LIFE:.0e})"),
    }


def _runs(mask: np.ndarray) -> list[tuple[int, int]]:
    out, i = [], 0
    m = np.asarray(mask)
    while i < len(m):
        if m[i]:
            j = i
            while j + 1 < len(m) and m[j + 1]:
                j += 1
            out.append((i, j + 1))
            i = j + 1
        else:
            i += 1
    return out


def _longest_run(mask: np.ndarray):
    r = _runs(mask)
    return max(r, key=lambda p: p[1] - p[0]) if r else None


# --------------------------------- האם זה מובן כשהקול מושתק

def _spearman(a: np.ndarray, b: np.ndarray) -> float:
    ra = np.argsort(np.argsort(a)).astype(float)
    rb = np.argsort(np.argsort(b)).astype(float)
    ra -= ra.mean()
    rb -= rb.mean()
    d = float(np.linalg.norm(ra) * np.linalg.norm(rb))
    return float(ra @ rb / d) if d > 1e-12 else 0.0


MONO_MIN = 0.55         #: מתאם מינימלי בין הזמן לציון
SEPARATION_MIN = 3.0    #: הפער בין הסוף להתחלה, ביחידות רעש
NO_AUDIO_KEYS = 0       #: כמה ערוצי שמע מותר שייכנסו למדידה


def silent_readability(tb: Track) -> dict:
    """ארבעת המבחנים של "מובן בלי קול"."""
    t, sc = tb.times, tb.score()
    head = sc[t <= 1.5]
    tail = sc[t >= SCENE_LEN - 1.5]
    noise = float(max(head.std(), tail.std(), 1e-6))
    sep = (float(tail.mean()) - float(head.mean())) / noise
    rho = _spearman(t, sc)
    keys, _ = tb.visual_matrix()
    leaked = [k for k in keys if is_audio_driven(k)]
    out = {
        "monotone": {"value": round(rho, 3), "limit": f">={MONO_MIN}",
                     "pass": bool(rho >= MONO_MIN),
                     "how": "אי-הנוחות עולה לאורך הסצנה ולא מקרטעת"},
        "separation": {"value": round(sep, 2),
                       "limit": f">={SEPARATION_MIN} רעשים",
                       "pass": bool(sep >= SEPARATION_MIN),
                       "how": "הפער בין הסוף להתחלה גדול מהרעש הפנימי"},
        "no_audio_channel": {"value": len(leaked),
                             "limit": f"=={NO_AUDIO_KEYS}",
                             "pass": len(leaked) == NO_AUDIO_KEYS,
                             "how": "אף ערוץ שההגאים מניעים לא נכנס למדידה"},
    }
    c = continuity(tb)
    out["continuity"] = {"value": f"שמירה {c.get('keep')}, חיים "
                                  f"{c.get('life')}",
                         "limit": f"שמירה>={TAIL_KEEP} וחיים>={TAIL_LIFE:.0e}",
                         "pass": bool(c["found"]), "how": c["how"]}
    return out


# ------------------------------------------------------------- האימות

def audit(fps: int = FPS) -> dict:
    """הסצנה, שמונת האירועים, ארבעת מבחני ההשתקה, וחמש ההפרכות."""
    import time                                       # noqa: PLC0415
    t0 = time.time()
    rep: dict = {"task": "TASK 10 - מבחן המשחק הקולנועי",
                 "scene": {"len": SCENE_LEN, "fps": fps,
                           "a_line": A_LINE, "b_line": B_LINE,
                           "a_speech": list(A_SPEECH),
                           "b_speech": list(B_SPEECH)}}
    checks: dict[str, dict] = {}

    # --- 0 · טבלת ה-FACS אינה המצאה: כל שם קיים ויש לו קוד.
    missing = [n for n in list(FACS_DISCOMFORT) + list(FACS_RELIEF)
               if not _au_channels(n)]
    codes = {}
    for n in FACS_DISCOMFORT:
        au = acting.AUS.get(n) if hasattr(acting, "AUS") else None
        codes[n] = getattr(au, "facs", "") if au else ""
    checks["facs_table_real"] = {
        "value": f"{len(FACS_DISCOMFORT)} יחידות, קודים: "
                 + ", ".join(sorted(set(v for v in codes.values() if v))),
        "limit": "כל שם קיים ב-acting.AU", "pass": not missing,
        "how": "המשקלים מצביעים על יחידות FACS שהוגדרו ב-TASK 02, "
               "לפני שהמבחן הזה נכתב"}

    ta = take("full", who="a", fps=fps)
    tb = take("full", who="b", fps=fps)
    ev = find_events(tb, ta)
    rep["events"] = ev

    # --- 1 · שמונת האירועים: נמצאו, ובחלון הנכון.
    for name, win in BEAT_WINDOWS.items():
        e = ev[name]
        at = e.get("at")
        inside = at is not None and win[0] <= at <= win[1]
        checks[f"beat/{name}"] = {
            "value": f"{at}ש · {e['how']}" if at is not None else e["how"],
            "limit": f"בחלון {win[0]}-{win[1]}ש",
            "pass": bool(e["found"] and inside), "how": e["how"]}
    checks["beat/understand_is_delayed"] = {
        "value": ev["understand"].get("at"),
        "limit": f">={A_SPEECH[1] - 0.25}ש (אחרי שהמשפט נגמר)",
        "pass": bool(ev["understand"].get("after_a_finished")),
        "how": "התגובה מתחילה אחרי המשפט ולא תוך כדי - זה העיכוב "
               "הקוגניטיבי, וזה ההבדל בין להבין לבין להגיב לרעש"}

    # --- 2 · A באמת ניטרלי. בלי זה אי-הנוחות של B עשויה להיות
    #     תגובה להופעה שלו ולא להבנה שלה.
    sa = ta.score()
    sb = tb.score()
    checks["a_stays_neutral"] = {
        "value": f"טווח A {float(sa.max()-sa.min()):.3f} מול "
                 f"{float(sb.max()-sb.min()):.3f} אצל B",
        "limit": "טווח A קטן מחצי מזה של B",
        "pass": bool((sa.max() - sa.min()) < 0.5 * (sb.max() - sb.min())),
        "how": "A מוסר מידע ואינו מאשים, ולכן מה שקורה ל-B קורה "
               "בגלל ההבנה ולא בגלל הטון"}

    # --- 3 · ארבעת מבחני ההשתקה.
    sil = silent_readability(tb)
    rep["silent"] = sil
    for k, v in sil.items():
        checks[f"silent/{k}"] = v

    # --- 4 · חמש ההפרכות. **זה מה ששובר את המעגליות.**
    rep["controls"] = {}
    for var, why in CONTROLS.items():
        tc = take(var, who="b", fps=fps)
        s = silent_readability(tc)
        e = find_events(tc, ta)
        failed = [k for k, v in s.items() if not v["pass"]]
        failed += [f"beat/{k}" for k in BEAT_WINDOWS
                   if not (e[k]["found"] and e[k].get("at") is not None
                           and BEAT_WINDOWS[k][0] <= e[k]["at"]
                           <= BEAT_WINDOWS[k][1])]
        rep["controls"][var] = {"why": why, "failed": failed}
        checks[f"control/{var}"] = {
            "value": (", ".join(failed[:3]) + (" ..." if len(failed) > 3
                                               else "")) or "עברה הכול",
            "limit": "חייבת ליפול לפחות במבחן אחד",
            "pass": bool(failed), "how": why}
    # ...ושכל אחת תיפול במבחן שנכתב **בשבילה**.
    for var, guard in (("flat", "monotone"),
                       ("reset", "continuity"),
                       ("freeze", "continuity"),
                       ("mute", "separation")):
        f = rep["controls"][var]["failed"]
        checks[f"control/{var}_falls_on_its_own_guard"] = {
            "value": ", ".join(f[:4]) or "לא נפלה",
            "limit": f"נופלת ב-{guard}", "pass": guard in f,
            "how": "הפרכה שנופלת במבחן אחר אינה מוכיחה שהמבחן הזה מפריד"}

    rep["checks"] = checks
    rep["passed"] = all(v["pass"] for v in checks.values())
    rep["seconds"] = round(time.time() - t0, 2)
    return rep


def main(argv=None) -> int:
    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(description="מבחן המשחק הקולנועי (TASK 10)")
    ap.add_argument("--fps", type=int, default=FPS)
    ap.add_argument("--json", default="")
    a = ap.parse_args(argv)
    rep = audit(fps=a.fps)
    print(f"=== {rep['task']} ===")
    print(f"  A: «{A_LINE}»  ({A_SPEECH[0]}-{A_SPEECH[1]}ש)")
    print(f"  B: «{B_LINE}»  ({B_SPEECH[0]}-{B_SPEECH[1]}ש)\n")
    for k, v in rep["checks"].items():
        print(f"  {'✓' if v['pass'] else '✗'} {k}: {v['value']} "
              f"(גבול {v['limit']})")
    print(f"\n{'עבר' if rep['passed'] else 'נכשל'} · {rep['seconds']}ש")
    if a.json:
        from pathlib import Path                      # noqa: PLC0415
        Path(a.json).write_text(json.dumps(rep, ensure_ascii=False, indent=1,
                                           default=str), encoding="utf-8")
        print(f"דוח: {a.json}")
    return 0 if rep["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
