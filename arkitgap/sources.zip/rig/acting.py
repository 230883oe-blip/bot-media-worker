# -*- coding: utf-8 -*-
"""מערכת משחק פנים · TASK 02.

מה הבעיה שזה פותר. ב-TASK 01 נבנה ריג פנים: 76 בקרות שכל אחת מזיזה
משהו. אבל ריג אינו משחק. אנימטור לא אומר "גבה שמאל 0.4" - הוא אומר
"היא חושדת", והחשד מורכב מכמה דברים שקורים **יחד ובזמנים שונים**:
גבה אחת עולה לפני השנייה, העפעף התחתון מתהדק, הראש נוטה, והמבט
מגיע באיחור של שבריר שנייה. אם כל זה קורה בבת אחת ובסימטריה מושלמת,
זה נקרא כמסכה - לא כאדם.

ולכן שלושה עקרונות שנאכפים כאן בקוד, ולא בשיקול דעת:

1. **אין ביטוי אטומי.** אין בקרה "happy" ואין בקרה "sad". יש יחידות
   תנועה (AU) - "הרמת גבה פנימית", "התהדקות עפעף תחתון", "הורדת
   זווית הפה" - וביטוי הוא **רשימה** שלהן. מי שרוצה ביטוי חדש מרכיב
   אותו מאותן יחידות, ולא מוסיף preset.
2. **לכל יחידה ציר זמן משלה.** השהיה, עלייה, החזקה, ירידה. ביטוי
   שכל חלקיו מתחילים באותו רגע הוא דגל אדום, לא ברירת מחדל.
3. **אסימטריה היא פרמטר, לא תקלה.** לכל יחידה דו-צדדית יש `bias`
   שמטה אותה לצד אחד. פנים סימטריות לחלוטין הן פנים של בובה.

עשר קבוצות הפנים (`REGIONS`) נשלטות בנפרד: הקוד **מאמת** שכל בקרה
וכל צורת פנים שייכות לקבוצה אחת בלבד, ושאין קבוצה ריקה. זו הדרישה
הראשונה של TASK 02, והיא נבדקת ולא מוצהרת.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field, replace

from . import controls, face

# ------------------------------------------------------------ הקבוצות
# כל שם מופיע **פעם אחת בלבד** בכל הטבלה. ctl = בקרת עצמות,
# mph = צורת פנים (blendshape). ההפרדה הזו היא מה שמאפשר לומר
# "הזז רק את האף" ולהוכיח את זה במדידה.

REGIONS: dict[str, dict[str, list[str]]] = {
    "brows": {
        "ctl": ["brow_up_L", "brow_up_R", "brow_inner_up_L", "brow_inner_up_R",
                "brow_outer_up_L", "brow_outer_up_R",
                "brow_furrow_L", "brow_furrow_R"],
        "mph": [],
    },
    "eyelids": {
        "ctl": ["blink_L", "blink_R", "squint_L", "squint_R"],
        "mph": ["eye_wide_L", "eye_wide_R", "lid_tighten_L", "lid_tighten_R"],
    },
    "gaze": {
        "ctl": ["eye_aim_x", "eye_aim_y", "eye_converge"],
        "mph": ["pupil_dilate_L", "pupil_dilate_R"],
    },
    "cheeks": {
        "ctl": ["cheek_puff_L", "cheek_puff_R"],
        "mph": ["cheek_raise_L", "cheek_raise_R",
                "cheek_hollow_L", "cheek_hollow_R"],
    },
    "nose": {
        "ctl": [],
        "mph": ["nose_flare", "nose_wrinkle", "nose_sneer_L", "nose_sneer_R"],
    },
    "mouth": {
        "ctl": ["smile_L", "smile_R"],
        "mph": ["mouth_corner_up_L", "mouth_corner_up_R",
                "mouth_corner_down_L", "mouth_corner_down_R",
                "mouth_stretch", "mouth_dimple",
                # 08/10: הזזת הפה לרוחב. **לא** `jaw_side` - זו הלסת.
                "mouth_shift_L", "mouth_shift_R"],
    },
    "jaw": {
        "ctl": ["jaw_open", "jaw_side", "jaw_fwd"],
        "mph": ["jaw_thrust"],
    },
    "lips": {
        "ctl": [],
        "mph": ["lip_pucker", "lip_funnel", "lip_press",
                "lip_up_raise_L", "lip_up_raise_R", "lip_lo_depress",
                # 08/10: חמש הצורות שסגרו את פערי ARKit באזור השפתיים.
                # השיוך כאן אינו פורמליות - `audit` מסרב לכתוב דמות
                # שיש בה צורה בלי קבוצה, וזה בדיוק מה שתפס את הפער
                # הזה בענן לפני שהוא הגיע לסרטון.
                "mouth_close", "lip_roll_up", "lip_roll_lo",
                "lip_shrug_up", "lip_shrug_lo"],
    },
    "tongue": {
        "ctl": ["tongue_up", "tongue_out"],
        "mph": [],
    },
    "head": {
        "ctl": ["head_yaw", "head_pitch", "head_roll",
                "neck_yaw", "neck_pitch", "neck_roll"],
        "mph": [],
    },
}

#: בקרות שאין להן יישום עצמות ומומשו כצורת פנים. השכבה הזו קיימת כדי
#: שבקרה ותיקה לא תהפוך לשקרית: `jaw_fwd` הוגדרה ב-TASK 01 ומעולם לא
#: הזיזה דבר, כי דחיפת לסת היא הזזה ולא סיבוב.
DRIVEN: dict[str, tuple[str, float]] = {"jaw_fwd": ("jaw_thrust", 1.0)}

#: זוגות שמבטלים זה את זה. בלי זה "זווית פה למעלה" ו"זווית פה למטה"
#: מתחברים לכדי עיוות, במקום פשוט להתקזז - וזה קורה כל פעם ששני
#: ביטויים מתערבבים (חיוך שנמחק מהפנים).
#: אנטגוניסטים **בין** בקרת עצמות לצורת פנים. טבלת `ANTAGONISTS`
#: מקזזת רק בתוך אותה טבלה, ולכן היא לא יכלה לתפוס את ההתנגשות
#: הזאת - והיא התגלתה ברנדור: המצמוץ האוטומטי (עצם `eyelid_up`
#: שמסתובבת למטה) נפל בדיוק על רגע ההפתעה (צורת `eye_wide`
#: שמגלגלת את אותו עפעף מעלה). שני הדברים הופעלו יחד על אותה
#: גאומטריה, והעין נראתה כחור כהה. פיזיולוגית אי אפשר לעשות את
#: שניהם, ולכן הפקיחה **מדכאת** את המצמוץ ולא מתווספת לו.
SUPPRESS: list[tuple[str, str, float]] = [
    ("blink_L", "eye_wide_L", 1.0),
    ("blink_R", "eye_wide_R", 1.0),
    ("squint_L", "eye_wide_L", 0.8),
    ("squint_R", "eye_wide_R", 0.8),
    ("blink_L", "lid_tighten_L", 0.45),
    ("blink_R", "lid_tighten_R", 0.45),
]

ANTAGONISTS: list[tuple[str, str]] = [
    ("mouth_corner_up_L", "mouth_corner_down_L"),
    ("mouth_corner_up_R", "mouth_corner_down_R"),
    ("cheek_raise_L", "cheek_hollow_L"),
    ("cheek_raise_R", "cheek_hollow_R"),
    ("eye_wide_L", "lid_tighten_L"),
    ("eye_wide_R", "lid_tighten_R"),
    ("lip_pucker", "mouth_stretch"),
    ("lip_press", "lip_funnel"),
    # 08/10: גלילת שפה פנימה ודחיקתה חוצה הן אותו שריר בשני כיוונים -
    # אי אפשר לעשות את שניהם, ובלי קיזוז הם מצטברים לעיוות במקום
    # להתבטל. בדיוק אותו היגיון של `lip_press`/`lip_funnel` למעלה.
    ("lip_roll_up", "lip_shrug_up"),
    ("lip_roll_lo", "lip_shrug_lo"),
    # והפה אינו יכול לזוז שמאלה וימינה בבת אחת.
    ("mouth_shift_L", "mouth_shift_R"),
]


def region_of(name: str) -> str:
    for r, d in REGIONS.items():
        if name in d["ctl"] or name in d["mph"]:
            return r
    raise KeyError(f"{name!r} אינו משויך לשום קבוצת פנים")


def audit() -> dict:
    """מאמת את ההפרדה בין הקבוצות. נקרא גם מהבדיקות וגם מהצינור -
    טבלה שנשברה בעריכה חייבת להתפוצץ, לא להתברר אחר כך בסרטון."""
    seen: dict[str, str] = {}
    dup = []
    for r, d in REGIONS.items():
        if not d["ctl"] and not d["mph"]:
            raise ValueError(f"קבוצת פנים ריקה: {r}")
        for nm in list(d["ctl"]) + list(d["mph"]):
            if nm in seen:
                dup.append((nm, seen[nm], r))
            seen[nm] = r
    if dup:
        raise ValueError(f"שמות בשתי קבוצות: {dup}")
    bad_ctl = [n for r, d in REGIONS.items() for n in d["ctl"]
               if n not in controls.CONTROLS]
    bad_mph = [n for r, d in REGIONS.items() for n in d["mph"]
               if n not in face.NAMES]
    if bad_ctl:
        raise ValueError(f"בקרות שאינן קיימות: {bad_ctl}")
    if bad_mph:
        raise ValueError(f"צורות שאינן קיימות: {bad_mph}")
    missing_mph = [n for n in face.NAMES if n not in seen]
    if missing_mph:
        raise ValueError(f"צורות שלא שויכו לקבוצה: {missing_mph}")
    return {"regions": len(REGIONS), "controls": len(bad_ctl) == 0,
            "named": len(seen),
            "per_region": {r: len(d["ctl"]) + len(d["mph"])
                           for r, d in REGIONS.items()}}


# ------------------------------------------------------------ יחידות תנועה


@dataclass(frozen=True)
class AU:
    """יחידת תנועה אחת. השמות בתוכה **ללא סיומת צד**; הצד מתווסף
    ב-`resolve` לפי `bias`, וזה מה שהופך אסימטריה לפרמטר."""
    name: str
    region: str
    ctl: dict = field(default_factory=dict)
    mph: dict = field(default_factory=dict)
    sided: bool = True
    facs: str = ""          # מספר ה-AU המקביל ב-FACS, לתיעוד בלבד


AUS: dict[str, AU] = {}


def _au(name, region, ctl=None, mph=None, sided=True, facs=""):
    AUS[name] = AU(name, region, dict(ctl or {}), dict(mph or {}),
                   sided, facs)


# --- גבות
_au("brow_inner_raise", "brows", ctl={"brow_inner_up": 1.0}, facs="AU1")
_au("brow_outer_raise", "brows", ctl={"brow_outer_up": 1.0}, facs="AU2")
_au("brow_raise", "brows", ctl={"brow_up": 1.0}, facs="AU1+2")
_au("brow_lower", "brows", ctl={"brow_furrow": 1.0}, facs="AU4")
# --- עפעפיים
_au("lid_raise", "eyelids", mph={"eye_wide": 1.0}, facs="AU5")
_au("lid_tighten", "eyelids", mph={"lid_tighten": 1.0}, facs="AU7")
_au("squint", "eyelids", ctl={"squint": 1.0}, facs="AU44")
_au("lid_close", "eyelids", ctl={"blink": 1.0}, facs="AU43/45")
# --- מבט ואישון
_au("gaze_left", "gaze", ctl={"eye_aim_x": 1.0}, sided=False, facs="AU61")
_au("gaze_right", "gaze", ctl={"eye_aim_x": -1.0}, sided=False, facs="AU62")
_au("gaze_up", "gaze", ctl={"eye_aim_y": 1.0}, sided=False, facs="AU63")
_au("gaze_down", "gaze", ctl={"eye_aim_y": -1.0}, sided=False, facs="AU64")
_au("gaze_converge", "gaze", ctl={"eye_converge": 1.0}, sided=False)
_au("pupil_dilate", "gaze", mph={"pupil_dilate": 1.0}, facs="AU-pupil")
# --- לחיים
_au("cheek_raise", "cheeks", mph={"cheek_raise": 1.0}, facs="AU6")
_au("cheek_puff", "cheeks", ctl={"cheek_puff": 1.0}, facs="AU33")
_au("cheek_hollow", "cheeks", mph={"cheek_hollow": 1.0}, facs="AU35")
# --- אף
_au("nose_flare", "nose", mph={"nose_flare": 1.0}, sided=False, facs="AU38")
_au("nose_wrinkle", "nose", mph={"nose_wrinkle": 1.0}, sided=False, facs="AU9")
_au("sneer", "nose", mph={"nose_sneer": 1.0}, facs="AU9+10")
# --- פה
_au("corner_raise", "mouth", ctl={"smile": 1.0},
    mph={"mouth_corner_up": 1.0}, facs="AU12")
_au("corner_depress", "mouth", mph={"mouth_corner_down": 1.0}, facs="AU15")
_au("mouth_stretch", "mouth", mph={"mouth_stretch": 1.0}, sided=False,
    facs="AU20")
_au("dimple", "mouth", mph={"mouth_dimple": 1.0}, sided=False, facs="AU14")
# --- לסת
_au("jaw_drop", "jaw", ctl={"jaw_open": 1.0}, sided=False, facs="AU26")
_au("jaw_slide", "jaw", ctl={"jaw_side": 1.0}, sided=False, facs="AU30")
_au("jaw_thrust", "jaw", mph={"jaw_thrust": 1.0}, sided=False, facs="AU29")
# --- שפתיים
_au("lip_pucker", "lips", mph={"lip_pucker": 1.0}, sided=False, facs="AU18")
_au("lip_funnel", "lips", mph={"lip_funnel": 1.0}, sided=False, facs="AU22")
_au("lip_press", "lips", mph={"lip_press": 1.0}, sided=False, facs="AU24")
_au("upper_lip_raise", "lips", mph={"lip_up_raise": 1.0}, facs="AU10")
_au("lower_lip_depress", "lips", mph={"lip_lo_depress": 1.0}, sided=False,
    facs="AU16")
# --- לשון
_au("tongue_raise", "tongue", ctl={"tongue_up": 1.0}, sided=False)
_au("tongue_show", "tongue", ctl={"tongue_out": 1.0}, sided=False, facs="AU19")
# --- ראש (כיוון הראש הוא אחת מעשר הקבוצות שהמשתמש דרש)
_au("head_turn_left", "head", ctl={"head_yaw": 0.75, "neck_yaw": 0.35},
    sided=False, facs="AU51")
_au("head_turn_right", "head", ctl={"head_yaw": -0.75, "neck_yaw": -0.35},
    sided=False, facs="AU52")
_au("head_up", "head", ctl={"head_pitch": 0.8, "neck_pitch": 0.35},
    sided=False, facs="AU53")
_au("head_down", "head", ctl={"head_pitch": -0.8, "neck_pitch": -0.35},
    sided=False, facs="AU54")
_au("head_tilt_left", "head", ctl={"head_roll": 0.8, "neck_roll": 0.3},
    sided=False, facs="AU55")
_au("head_tilt_right", "head", ctl={"head_roll": -0.8, "neck_roll": -0.3},
    sided=False, facs="AU56")


def _sides(bias: float) -> tuple[float, float]:
    """bias ב-[-1,1]: +1 = רק שמאל, -1 = רק ימין, 0 = סימטרי.

    התאמה **לא** ליניארית בכוונה: ב-bias=0.3 הצד החזק מגיע ל-1.0
    והחלש ל-0.7, ולא 1.3/0.7 - אחרת הטיה קטנה מעיפה את הצד החזק
    מעל התחום ונחתכת, וההטיה נראית כאילו היא לא עובדת.
    """
    b = max(-1.0, min(1.0, float(bias)))
    return (1.0, 1.0 - abs(b)) if b >= 0 else (1.0 - abs(b), 1.0)


def resolve(au_name: str, amount: float = 1.0, bias: float = 0.0) -> dict:
    """מחזיר {"ctl": {...}, "mph": {...}} בשמות מלאים (עם L/R)."""
    if au_name not in AUS:
        raise KeyError(f"אין יחידת תנועה בשם {au_name!r}")
    au = AUS[au_name]
    wl, wr = _sides(bias)
    out = {"ctl": {}, "mph": {}}
    for kind, table in (("ctl", au.ctl), ("mph", au.mph)):
        for base, gain in table.items():
            if au.sided:
                for tag, w in (("L", wl), ("R", wr)):
                    out[kind][f"{base}_{tag}"] = gain * amount * w
            else:
                out[kind][base] = gain * amount
    return out


# ------------------------------------------------------------ ציר הזמן


@dataclass
class Beat:
    """הפעלה של יחידת תנועה על ציר הזמן.

    delay הוא **עיקר העניין**: "delayed reaction" שהמשתמש דרש בחשד
    אינו אפקט - הוא ההבדל בין פנים שמגיבות כמו מכונה לפנים שמגיבות
    כמו אדם שקודם שמע ורק אחר כך הבין.
    """
    au: str
    peak: float = 1.0
    bias: float = 0.0
    delay: float = 0.0
    rise: float = 0.18
    hold: float = 0.60
    fall: float = 0.40
    ease: str = "smooth"        # smooth | snap | drift
    sustain: bool = False       # נשאר ב-peak ולא דועך

    def end(self) -> float:
        if self.sustain:
            return float("inf")
        return self.delay + self.rise + self.hold + self.fall


def _ease(u: float, kind: str) -> float:
    u = max(0.0, min(1.0, u))
    if kind == "snap":          # התחלה חדה, סוף רך - הלם, בהלה
        return 1.0 - (1.0 - u) ** 3
    if kind == "drift":         # התחלה איטית - עצב, עייפות, הבנה
        return u ** 2.2
    return u * u * (3.0 - 2.0 * u)


def envelope(b: Beat, t: float, speed: float = 1.0) -> float:
    """עוצמת הביט בזמן t. speed>1 = מהר יותר (כל הזמנים מתכווצים).

    speed הוא מה שהופך "sadness = slower movement" לדבר שנמדד: אותו
    ביט בדיוק, עם speed=0.55, מגיע ל-50% כמעט בכפול זמן.
    """
    sp = max(1e-3, float(speed))
    tt = float(t) * sp
    if tt < b.delay:
        return 0.0
    tt -= b.delay
    if b.rise > 1e-9 and tt < b.rise:
        return b.peak * _ease(tt / b.rise, b.ease)
    tt -= b.rise
    if b.sustain or tt < b.hold:
        return b.peak
    tt -= b.hold
    if b.fall <= 1e-9:
        return 0.0
    if tt >= b.fall:
        return 0.0
    return b.peak * (1.0 - _ease(tt / b.fall, "smooth"))


@dataclass
class Expression:
    """קומבינציה. **זה** המושג המרכזי של TASK 02.

    ביטוי אינו ערך - הוא רשימת יחידות תנועה עם תזמונים. שני ביטויים
    יכולים להשתמש באותן יחידות ולהיקרא שונה לגמרי, בגלל התזמון
    והאסימטריה בלבד.
    """
    name: str
    beats: list[Beat]
    speed: float = 1.0
    note: str = ""

    def regions(self) -> set[str]:
        return {AUS[b.au].region for b in self.beats}

    def duration(self) -> float:
        if any(b.sustain for b in self.beats):
            return float("inf")
        return max((b.end() for b in self.beats), default=0.0) / \
            max(1e-3, self.speed)

    def scaled(self, intensity: float = 1.0, speed: float = 1.0,
               bias: float = 0.0) -> "Expression":
        """אותו ביטוי בעוצמה/מהירות/אסימטריה אחרת. לא משנה את המקור."""
        bs = [replace(b, peak=b.peak * intensity,
                      bias=max(-1.0, min(1.0, b.bias + bias)))
              for b in self.beats]
        return Expression(self.name, bs, self.speed * speed, self.note)

    def solve(self, t: float) -> dict:
        acc = {"ctl": {}, "mph": {}}
        for b in self.beats:
            a = envelope(b, t, self.speed)
            if abs(a) < 1e-6:
                continue
            r = resolve(b.au, a, b.bias)
            for kind in ("ctl", "mph"):
                for k, v in r[kind].items():
                    acc[kind][k] = acc[kind].get(k, 0.0) + v
        return acc


# ------------------------------------------------------------ הקומבינציות
# שלוש הראשונות הן **בדיוק** מה שהמשתמש כתב ב-TASK 02, מרכיב מול
# מרכיב. השאר נבנו מאותן יחידות כדי להראות שזו מערכת ולא טבלה:
# אף אחת מהן אינה "happy/sad/angry", וכולן מורכבות.

EXPRESSIONS: dict[str, Expression] = {}


def _ex(name, beats, speed=1.0, note=""):
    EXPRESSIONS[name] = Expression(name, beats, speed, note)
    return EXPRESSIONS[name]


# הפתעה: גבות מורמות + עיניים נפקחות + לסת יורדת + שינוי מבט +
# תנועת ראש קטנה. העלייה חדה (snap) וההחזקה קצרה - הפתעה שנמשכת
# שנייה שלמה היא לא הפתעה.
_ex("surprise", [
    Beat("brow_raise", 0.95, 0.06, 0.00, 0.11, 0.30, 0.45, "snap"),
    Beat("lid_raise", 1.00, 0.00, 0.02, 0.09, 0.32, 0.40, "snap"),
    Beat("jaw_drop", 0.62, 0.00, 0.05, 0.14, 0.26, 0.50, "snap"),
    Beat("gaze_up", 0.35, 0.00, 0.03, 0.12, 0.24, 0.40),
    Beat("pupil_dilate", 0.75, 0.00, 0.06, 0.20, 0.40, 0.55),
    Beat("head_up", 0.22, 0.00, 0.08, 0.16, 0.22, 0.52),
    Beat("head_turn_right", 0.14, 0.00, 0.10, 0.18, 0.20, 0.50),
], note="גבות + פקיחה + לסת + מבט + ראש · עלייה חדה, החזקה קצרה")

# חשד: גבות **אסימטריות** + עיניים מצומצמות + הטיית ראש קלה +
# תגובה מאוחרת. ההשהיות כאן אינן קוסמטיקה - הגבה עולה 0.1 שנייה
# לפני שהעפעף מתהדק, והראש נוטה רק 0.35 שנייה אחרי.
_ex("suspicion", [
    Beat("brow_raise", 0.55, 0.85, 0.00, 0.26, 0.90, 0.55),
    Beat("brow_lower", 0.45, -0.80, 0.08, 0.30, 0.85, 0.50),
    Beat("lid_tighten", 0.70, 0.25, 0.14, 0.34, 0.95, 0.60),
    Beat("squint", 0.35, 0.30, 0.18, 0.36, 0.90, 0.55),
    Beat("head_tilt_right", 0.30, 0.00, 0.35, 0.40, 0.75, 0.60, "drift"),
    Beat("gaze_left", 0.28, 0.00, 0.46, 0.30, 0.70, 0.50, "drift"),
    Beat("lip_press", 0.30, 0.00, 0.22, 0.40, 0.85, 0.55),
    Beat("dimple", 0.22, 0.00, 0.30, 0.45, 0.80, 0.50),
], speed=0.85, note="אסימטריה בגבות + צמצום + הטיה + תגובה מאוחרת")

# עצב: הרמת גבה **פנימית** + פקיחת עין מופחתת + דחיסת שפתיים +
# ראש מורד + תנועה איטית. speed=0.55 הוא המרכיב "slower movement",
# ו-ease="drift" נותן התחלה איטית - עצב לא "נדלק".
_ex("sadness", [
    Beat("brow_inner_raise", 0.85, 0.12, 0.00, 0.55, 1.60, 1.10, "drift"),
    Beat("brow_lower", 0.22, 0.00, 0.10, 0.60, 1.50, 1.00, "drift"),
    Beat("lid_close", 0.30, 0.00, 0.15, 0.65, 1.70, 1.10, "drift"),
    Beat("corner_depress", 0.70, 0.10, 0.20, 0.70, 1.60, 1.20, "drift"),
    Beat("lip_press", 0.45, 0.00, 0.12, 0.60, 1.65, 1.10, "drift"),
    Beat("lower_lip_depress", 0.20, 0.00, 0.30, 0.70, 1.40, 1.00, "drift"),
    Beat("head_down", 0.45, 0.00, 0.25, 0.90, 1.70, 1.30, "drift"),
    Beat("gaze_down", 0.50, 0.00, 0.18, 0.75, 1.80, 1.20, "drift"),
], speed=0.55, note="גבה פנימית + עין מוצרת + דחיסת שפתיים + ראש מורד + איטי")

# --- עוד קומבינציות, מאותן יחידות. אין כאן שום preset חדש.
_ex("contempt", [
    Beat("corner_raise", 0.55, 1.00, 0.00, 0.22, 0.95, 0.55),
    Beat("sneer", 0.40, 1.00, 0.06, 0.26, 0.90, 0.50),
    Beat("lid_tighten", 0.35, 0.60, 0.10, 0.30, 0.85, 0.55),
    Beat("head_tilt_left", 0.20, 0.00, 0.20, 0.35, 0.70, 0.55),
    Beat("head_turn_left", 0.16, 0.00, 0.26, 0.38, 0.65, 0.55, "drift"),
], speed=0.9, note="זווית פה בצד אחד בלבד + גועל קל + הטיה")

_ex("doubt", [
    Beat("brow_inner_raise", 0.50, -0.70, 0.00, 0.32, 1.00, 0.60),
    Beat("brow_lower", 0.35, 0.70, 0.06, 0.34, 0.95, 0.55),
    Beat("squint", 0.28, 0.00, 0.16, 0.36, 0.90, 0.55),
    Beat("lip_pucker", 0.30, 0.00, 0.22, 0.42, 0.85, 0.60),
    Beat("gaze_up", 0.30, 0.00, 0.34, 0.34, 0.60, 0.55, "drift"),
    Beat("gaze_left", 0.34, 0.00, 0.34, 0.34, 0.60, 0.55, "drift"),
    Beat("head_tilt_right", 0.18, 0.00, 0.40, 0.42, 0.65, 0.60, "drift"),
], speed=0.8, note="גבות הפוכות + מבט מוסח + שפתיים מכווצות")

_ex("realization", [
    Beat("brow_raise", 0.70, -0.15, 0.00, 0.14, 0.45, 0.60, "snap"),
    Beat("lid_raise", 0.55, 0.00, 0.02, 0.12, 0.40, 0.55, "snap"),
    Beat("jaw_drop", 0.30, 0.00, 0.06, 0.18, 0.35, 0.60),
    Beat("gaze_converge", 0.45, 0.00, 0.10, 0.22, 0.50, 0.55),
    Beat("corner_raise", 0.40, 0.25, 0.30, 0.34, 0.60, 0.70, "drift"),
    Beat("cheek_raise", 0.35, 0.20, 0.34, 0.38, 0.60, 0.70, "drift"),
    Beat("head_up", 0.18, 0.00, 0.08, 0.20, 0.35, 0.60),
], note="הלם קצר שהופך לחיוך · שני גלים בתזמון שונה")

_ex("discomfort", [
    Beat("brow_lower", 0.45, 0.30, 0.00, 0.30, 1.00, 0.55),
    Beat("lid_tighten", 0.45, 0.00, 0.08, 0.32, 0.95, 0.55),
    Beat("nose_wrinkle", 0.35, 0.00, 0.12, 0.34, 0.90, 0.55),
    Beat("upper_lip_raise", 0.40, 0.35, 0.14, 0.34, 0.90, 0.55),
    Beat("mouth_stretch", 0.30, 0.00, 0.20, 0.36, 0.85, 0.55),
    Beat("cheek_hollow", 0.25, 0.00, 0.24, 0.40, 0.80, 0.60),
    Beat("head_turn_right", 0.22, 0.00, 0.30, 0.40, 0.70, 0.60, "drift"),
], speed=0.9, note="גועל/אי-נוחות: אף + שפה עליונה + צמצום")

_ex("amusement", [
    Beat("corner_raise", 0.85, 0.20, 0.00, 0.16, 0.70, 0.60),
    Beat("cheek_raise", 0.80, 0.15, 0.02, 0.18, 0.75, 0.60),
    Beat("squint", 0.45, 0.10, 0.06, 0.22, 0.70, 0.60),
    Beat("dimple", 0.45, 0.00, 0.04, 0.20, 0.70, 0.60),
    Beat("jaw_drop", 0.30, 0.00, 0.10, 0.20, 0.55, 0.60),
    Beat("brow_outer_raise", 0.30, 0.25, 0.08, 0.22, 0.60, 0.60),
    Beat("head_tilt_left", 0.16, 0.00, 0.14, 0.26, 0.60, 0.60),
], note="חיוך דושן: הלחי עולה עם הפה · בלי זה זה חיוך מנומס")

_ex("polite_smile", [
    Beat("corner_raise", 0.60, 0.00, 0.00, 0.20, 0.90, 0.55),
    Beat("dimple", 0.30, 0.00, 0.04, 0.22, 0.85, 0.55),
    Beat("lid_tighten", 0.12, 0.00, 0.10, 0.30, 0.80, 0.55),
], note="אותה יחידת פה כמו שעשוע, **בלי** הלחי - ולכן נקרא כמנומס")

_ex("concentration", [
    Beat("brow_lower", 0.60, -0.20, 0.00, 0.34, 1.40, 0.70, "drift"),
    Beat("lid_tighten", 0.40, 0.00, 0.10, 0.38, 1.35, 0.65, "drift"),
    Beat("gaze_converge", 0.55, 0.00, 0.06, 0.40, 1.40, 0.70),
    Beat("lip_press", 0.40, 0.00, 0.16, 0.42, 1.30, 0.70, "drift"),
    Beat("jaw_thrust", 0.25, 0.00, 0.26, 0.50, 1.20, 0.70, "drift"),
    Beat("head_down", 0.20, 0.00, 0.20, 0.55, 1.30, 0.75, "drift"),
], speed=0.75, note="מיקוד: גבות למטה + התכנסות מבט + לסת קדימה")

_ex("relief", [
    Beat("lid_close", 0.55, 0.00, 0.00, 0.30, 0.55, 0.80, "drift"),
    Beat("brow_inner_raise", 0.30, 0.00, 0.04, 0.34, 0.60, 0.80, "drift"),
    Beat("jaw_drop", 0.35, 0.00, 0.08, 0.34, 0.50, 0.90),
    Beat("nose_flare", 0.45, 0.00, 0.06, 0.26, 0.40, 0.80),
    Beat("corner_raise", 0.30, 0.15, 0.40, 0.45, 0.70, 0.90, "drift"),
    Beat("head_down", 0.25, 0.00, 0.12, 0.45, 0.60, 0.90, "drift"),
], speed=0.7, note="נשימה + עצימת עיניים + חיוך שמגיע באיחור")

_ex("flinch", [
    Beat("lid_close", 1.00, 0.00, 0.00, 0.05, 0.08, 0.22, "snap"),
    Beat("brow_lower", 0.70, 0.00, 0.00, 0.06, 0.10, 0.30, "snap"),
    Beat("mouth_stretch", 0.50, 0.00, 0.01, 0.07, 0.10, 0.28, "snap"),
    Beat("nose_wrinkle", 0.45, 0.00, 0.01, 0.07, 0.10, 0.28, "snap"),
    Beat("head_tilt_right", 0.30, 0.00, 0.02, 0.08, 0.08, 0.30, "snap"),
], speed=1.4, note="רפלקס: הכול בבת אחת ומהר · ההיפך מעצב")

_ex("fatigue", [
    Beat("lid_close", 0.52, 0.10, 0.00, 0.90, 2.20, 1.30, "drift"),
    Beat("brow_outer_raise", -0.25, 0.00, 0.10, 0.95, 2.10, 1.30, "drift"),
    Beat("corner_depress", 0.35, -0.15, 0.20, 1.00, 2.00, 1.40, "drift"),
    Beat("jaw_drop", 0.18, 0.00, 0.30, 1.10, 1.90, 1.40, "drift"),
    Beat("head_down", 0.35, 0.00, 0.25, 1.20, 2.00, 1.50, "drift"),
    Beat("gaze_down", 0.35, 0.00, 0.30, 1.10, 2.00, 1.40, "drift"),
], speed=0.45, note="הכול איטי ונופל · גבה חיצונית **שלילית**")

_ex("interest", [
    Beat("brow_raise", 0.45, -0.25, 0.00, 0.20, 0.95, 0.55),
    Beat("lid_raise", 0.30, 0.00, 0.04, 0.22, 0.90, 0.55),
    Beat("gaze_converge", 0.35, 0.00, 0.08, 0.26, 0.90, 0.55),
    Beat("head_turn_left", 0.20, 0.00, 0.10, 0.28, 0.80, 0.60),
    Beat("head_up", 0.12, 0.00, 0.12, 0.30, 0.80, 0.60),
    Beat("corner_raise", 0.20, 0.30, 0.24, 0.34, 0.80, 0.60, "drift"),
], note="נטייה קדימה: גבה קלה + פקיחה + ראש פונה")


# ------------------------------------------------------------ ההצגה


def _frac(x: float) -> float:
    """רעש דטרמיניסטי ב-[0,1). אין random: אותה הצגה חייבת לצאת זהה
    בכל רנדור, אחרת אי אפשר לבדוק אותה ואי אפשר לחזור על צילום."""
    s = math.sin(x * 127.1 + 311.7) * 43758.5453123
    return s - math.floor(s)


@dataclass
class _Cue:
    expr: Expression
    at: float
    weight: float = 1.0


class Performance:
    """ציר זמן שלם: כמה ביטויים, חופפים, ועליהם מיקרו-תנועות.

    בלי המיקרו-תנועות הפנים נראות מתות בין הביטויים: אדם אמיתי ממצמץ,
    המבט שלו קופץ (saccades), והוא נושם. זה מה שמונע מהפנים להיראות
    כתמונה שמחכה לאפקט הבא.
    """

    def __init__(self, seed: float = 0.0, micro: bool = True,
                 blink_rate: float = 3.4, saccade_rate: float = 1.1,
                 eyes_own: bool = False):
        self.seed = float(seed)
        self.micro_on = bool(micro)
        self.blink_rate = float(blink_rate)
        self.saccade_rate = float(saccade_rate)
        #: כש-TASK 04 פעיל, העיניים הן מערכת בפני עצמה (`rig.eyes`)
        #: והיא בעלת המצמוץ והסקאדות. בלי הדגל הזה שתי מערכות כותבות
        #: לאותן בקרות: המצמוץ נספר פעמיים (ואז העין נעצמת פי שניים
        #: חזק) והסקאדה הפרימיטיבית כאן מושכת את המבט מהמטרה שהמערכת
        #: החדשה בחרה. הנשימה ורעד הגבות נשארים - הם לא של העיניים.
        self.eyes_own = bool(eyes_own)
        self.cues: list[_Cue] = []

    # --- בנייה
    def add(self, expr, at: float = 0.0, intensity: float = 1.0,
            speed: float = 1.0, bias: float = 0.0, weight: float = 1.0):
        """מוסיף ביטוי בזמן `at`. `expr` הוא שם או Expression."""
        e = EXPRESSIONS[expr] if isinstance(expr, str) else expr
        self.cues.append(_Cue(e.scaled(intensity, speed, bias),
                              float(at), float(weight)))
        return self

    def duration(self) -> float:
        out = 0.0
        for c in self.cues:
            d = c.expr.duration()
            out = max(out, c.at + (0.0 if d == float("inf") else d))
        return out

    # --- מיקרו-תנועות
    def _blink(self, t: float) -> float:
        """מצמוץ לא-מחזורי. מצמוץ בקצב קבוע נראה כמו נורה מהבהבת."""
        per = max(0.6, self.blink_rate)
        i = math.floor(t / per)
        # ג'יטר של עד ±40% מהמרווח, דטרמיניסטי לפי מספר המצמוץ
        tc = (i + 0.35 + 0.5 * _frac(i * 7.3 + self.seed)) * per
        dt = t - tc
        dur = 0.075 + 0.045 * _frac(i * 3.1 + self.seed + 11.0)
        if dt < -0.02 or dt > dur * 2.6:
            return 0.0
        u = dt / (dur * 2.6)
        u = max(0.0, min(1.0, u))
        # סגירה מהירה, פקיחה איטית - כך זה בעין אמיתית
        return math.sin(math.pi * (u ** 0.55)) ** 1.4

    def _saccade(self, t: float) -> tuple[float, float]:
        """המבט קופץ לנקודה חדשה ונח שם. בין הקפיצות - כמעט ללא
        תנועה, וזה הדבר שהופך מבט ל"מסתכל" ולא ל"סורק"."""
        per = max(0.25, self.saccade_rate)
        i = math.floor(t / per)
        u = (t - i * per) / per
        ax, ay = _frac(i * 13.1 + self.seed) * 2 - 1, \
            _frac(i * 29.7 + self.seed + 5.0) * 2 - 1
        bx, by = _frac((i + 1) * 13.1 + self.seed) * 2 - 1, \
            _frac((i + 1) * 29.7 + self.seed + 5.0) * 2 - 1
        k = _ease(min(1.0, u / 0.12), "snap")       # הקפיצה עצמה מהירה
        return (ax + (bx - ax) * k) * 0.34, (ay + (by - ay) * k) * 0.20

    def _micro(self, t: float) -> dict:
        if not self.micro_on:
            return {"ctl": {}, "mph": {}}
        bl = self._blink(t)
        gx, gy = self._saccade(t)
        br = math.sin(2 * math.pi * t / 3.6 + self.seed)
        # רעד עדין ולא סימטרי בגבות - 2% בלבד, אבל הוא מה שמוציא
        # את הפנים ממצב "קפואות"
        jl = (_frac(math.floor(t * 3.0) * 5.1 + self.seed) - 0.5) * 0.05
        jr = (_frac(math.floor(t * 3.0) * 9.7 + self.seed) - 0.5) * 0.05
        out = {"ctl": {"breath": br * 0.55,
                       "brow_outer_up_L": jl, "brow_outer_up_R": jr},
               "mph": {}}
        if not self.eyes_own:
            out["ctl"].update({"blink_L": bl, "blink_R": bl * 0.97,
                               "eye_aim_x": gx, "eye_aim_y": gy})
        return out

    # --- הפתרון
    def solve(self, t: float) -> tuple[dict, dict]:
        """מחזיר (בקרות, צורות) לזמן t. זו הפונקציה היחידה שהרנדור
        קורא, והיא נקייה: אין בה מצב פנימי ואין בה אקראיות."""
        acc = {"ctl": {}, "mph": {}}
        base = self._micro(t)
        for kind in ("ctl", "mph"):
            acc[kind].update(base[kind])
        for c in self.cues:
            lt = t - c.at
            if lt < -1e-9:
                continue
            r = c.expr.solve(lt)
            for kind in ("ctl", "mph"):
                for k, v in r[kind].items():
                    acc[kind][k] = acc[kind].get(k, 0.0) + v * c.weight
        return finalize(acc["ctl"], acc["mph"])


# ------------------------------------------------------------ איחוד וחיתוך


def _soft(x: float, lo: float, hi: float) -> float:
    """רוויה רכה בתוך התחום. חיתוך קשה (min/max) גורם לכך ששני
    ביטויים חופפים "נדבקים" לקיר ופתאום לא זזים בכלל - נראה בדיוק
    כמו פנים קפואות באמצע תנועה."""
    if lo < 0 <= hi and x < 0:
        return -_soft(-x, 0.0, -lo)
    span = hi - lo
    if span <= 1e-9:
        return lo
    u = (x - lo) / span
    if u <= 0.72:
        return lo + u * span
    if u >= 10.0:
        return hi
    # מעל 72% מהתחום - דחיסה אסימפטוטית אל hi
    over = u - 0.72
    return lo + (0.72 + 0.28 * (1.0 - math.exp(-over / 0.28))) * span


def finalize(ctl: dict, mph: dict) -> tuple[dict, dict]:
    """מקזז אנטגוניסטים, מפעיל בקרות מונָעוֹת, וחותך בריכוך."""
    ctl = dict(ctl)
    mph = dict(mph)
    # בקרה שמומשה כצורה
    for src, (dst, gain) in DRIVEN.items():
        v = ctl.pop(src, 0.0)
        if abs(v) > 1e-9:
            mph[dst] = mph.get(dst, 0.0) + v * gain
    # קיזוז: שני צדי אותו שריר
    for a, b in ANTAGONISTS:
        for tab in (ctl, mph):
            if a in tab and b in tab:
                d = tab[a] - tab[b]
                tab[a], tab[b] = max(0.0, d), max(0.0, -d)
    # דיכוי חוצה-טבלאות: בקרת עצמות מול צורת פנים על אותו שריר
    for src, dom, k in SUPPRESS:
        v = ctl.get(src)
        w = mph.get(dom)
        if v is None or not w:
            continue
        ctl[src] = v * max(0.0, 1.0 - k * abs(float(w)))
    out_c = {}
    for k, v in ctl.items():
        if k not in controls.CONTROLS:
            raise KeyError(f"אין בקרה בשם {k!r}")
        lo, hi, _d, _g = controls.CONTROLS[k]
        out_c[k] = _soft(float(v), lo, hi)
    out_m = {}
    for k, v in mph.items():
        if k not in face.NAMES:
            raise KeyError(f"אין צורת פנים בשם {k!r}")
        out_m[k] = _soft(float(v), -1.0, 1.0)
    return out_c, out_m


def pose_of(expr, t: float | None = None, intensity: float = 1.0,
            speed: float = 1.0, bias: float = 0.0, micro: bool = False):
    """קיצור: הפוזה של ביטוי אחד בשיא שלו (או בזמן t). מיועד לבדיקות
    ולתצוגה, ולכן ברירת המחדל היא **בלי** מיקרו-תנועות - אחרת כל
    מדידה מקבלת מצמוץ אקראי לתוכה."""
    e = EXPRESSIONS[expr] if isinstance(expr, str) else expr
    e = e.scaled(intensity, speed, bias)
    if t is None:
        t = apex_time(e)
    p = Performance(micro=micro)
    p.cues.append(_Cue(e, 0.0, 1.0))
    return p.solve(t)


def apex_time(e: Expression) -> float:
    """הרגע שבו סך העוצמות מקסימלי. ביטוי מורכב אינו מגיע לשיא בזמן
    אחד - חלקיו מתחילים בזמנים שונים - ולכן "השיא" חייב להימצא
    במדידה ולא בהנחה."""
    if not e.beats:
        return 0.0
    hi = max(b.delay + b.rise + b.hold for b in e.beats) / \
        max(1e-3, e.speed)
    best, bt = -1.0, 0.0
    n = 140
    for i in range(n + 1):
        t = hi * i / n
        s = sum(abs(envelope(b, t, e.speed)) for b in e.beats)
        if s > best:
            best, bt = s, t
    return bt


#: יחידה מייצגת אחת או שתיים לכל אזור, להדגמה ולבדיקת ההפרדה. **לא**
#: כל היחידות באזור: `corner_raise` ו-`corner_depress` הן שני צדי אותו
#: שריר, והפעלה של שתיהן מתקזזת לאפס - מה שהיה נראה כאילו האזור לא זז.
SHOWCASE: dict[str, list[str]] = {
    "brows": ["brow_inner_raise", "brow_outer_raise"],
    "eyelids": ["lid_raise"],
    "gaze": ["gaze_left", "gaze_up", "pupil_dilate"],
    "cheeks": ["cheek_raise"],
    "nose": ["nose_flare", "nose_wrinkle"],
    "mouth": ["corner_raise", "dimple"],
    "jaw": ["jaw_drop", "jaw_slide"],
    "lips": ["lip_funnel"],
    "tongue": ["tongue_show", "tongue_raise"],
    "head": ["head_turn_left", "head_tilt_right"],
}


def isolate(region: str, amount: float = 1.0, bias: float = 0.0):
    """מפעיל **רק** את האזור הזה. זו ההוכחה הישירה לדרישה הראשונה של
    TASK 02: אם `isolate("nose")` מזיז גם את השפתיים, השליטה אינה
    עצמאית - והבדיקה נופלת."""
    if region not in REGIONS:
        raise KeyError(f"אין קבוצת פנים בשם {region!r}")
    acc = {"ctl": {}, "mph": {}}
    for au in SHOWCASE[region]:
        r = resolve(au, amount, bias)
        for kind in ("ctl", "mph"):
            for k, v in r[kind].items():
                acc[kind][k] = acc[kind].get(k, 0.0) + v
    return finalize(acc["ctl"], acc["mph"])


def region_activity(ctl: dict, mph: dict) -> dict:
    """כמה "אנרגיה" יש בכל אחת מעשר הקבוצות. זה המדד שמוכיח שביטוי
    הוא קומבינציה ולא הפעלה של אזור אחד."""
    out = {r: 0.0 for r in REGIONS}
    for tab in (ctl, mph):
        for k, v in tab.items():
            try:
                out[region_of(k)] += abs(float(v))
            except KeyError:
                continue        # בקרות גוף (breath, גפיים) אינן פנים
    return {k: round(v, 4) for k, v in out.items()}


def describe(name: str) -> dict:
    e = EXPRESSIONS[name]
    ctl, mph = pose_of(name)
    return {"name": name, "note": e.note, "beats": len(e.beats),
            "speed": e.speed, "regions": sorted(e.regions()),
            "duration": round(e.duration(), 3),
            "apex": round(apex_time(e), 3),
            "activity": region_activity(ctl, mph),
            "aus": [b.au for b in e.beats],
            "delays": sorted({round(b.delay, 3) for b in e.beats})}


def main(argv=None):
    import json
    import sys
    sys.stdout.reconfigure(encoding="utf-8")
    print(json.dumps({"audit": audit(),
                      "aus": len(AUS),
                      "expressions": {k: describe(k) for k in EXPRESSIONS}},
                     ensure_ascii=False, indent=1))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
