# -*- coding: utf-8 -*-
"""תקריב ראש של דמות משלוש זוויות - כלי אבחון, לא כלי הפקה.

**למה זה קיים.** TASK 12 נפתח כששער עיצוב אחד עשרה עברו במלואם
(25/25) בעוד התקריב הראה בדיוק את הפגם שהתלונה תיארה. שני הפגמים
שנמצאו שם - קו חיתוך משונן בין כובע השיער לגולגולת, ותחתית ראש
שנחתכה למדף - לא נמדדו באף שער קיים, כי כל שערי הגולגולת מודדים
את הכיפה בלבד. אבחון של "זה נראה לא טוב" מתחיל בלהסתכל.

שימוש::

    python -m rig.closeup zippy
    python -m rig.closeup grump --dist 0.7

והוא **קורא את ה-GLB הבנוי**, ולכן יש להריץ לפניו
``python -m rig.pipeline --cast`` אחרת מסתכלים על נכס ישן.
"""
from __future__ import annotations

import argparse
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from rig import showreel as SR                          # noqa: E402

#: הזוויות. 0 = חזית, 90 = פרופיל מלא.
ANGLES = (("front", 0.0), ("q34", 32.0), ("side", 88.0))

#: מיקום הדמויות על הבמה בסצנת `sunbeam` - A משמאל, B מימין.
STAGE_X = {"A": -0.52, "B": 0.52}


def main(argv=None) -> int:
    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(description="תקריב ראש לאבחון")
    ap.add_argument("who", nargs="?", default="zippy")
    ap.add_argument("--other", default="")
    ap.add_argument("--dist", type=float, default=0.62)
    ap.add_argument("--size", type=int, default=1200)
    a = ap.parse_args(argv)

    other = a.other or ("grump" if a.who != "grump" else "zippy")
    rig, _skel, _lib = SR.load_char(a.who, SR.RIG_DIR)
    # גובה המטרה הוא גובה הראש, והוא נגזר מגובה הדמות ולא מוקלד:
    # זיגי וגרומפ נבדלים ב-32 ס"מ, ומצלמה שמכוונת לגובה אחד משני
    # הצילומים ממלאת את הפריים בכתף באחד מהם.
    ty = float(rig["height_m"]) * 0.93
    tx = STAGE_X["A"]

    def cam(yaw):
        return lambda _u: {"yaw": yaw, "pitch": 0.0, "dist": a.dist,
                           "tx": tx, "ty": ty, "fov": 26}

    shots = [SR.Shot(f"cu_{a.who}_{tag}", 0.6, " ", " ", "תקריב ראש",
                     cam(y), vis={"A": True, "B": False}, light="studio")
             for tag, y in ANGLES]
    rep = asyncio.run(SR.produce(
        SR.OUT_DIR / f"cu_{a.who}.mp4", SR.RIG_DIR, task=50, title=" ",
        probe=True, fps=30, width=a.size, height=a.size,
        shots_override=shots, cast=(a.who, other)))
    for p in rep["probes"]:
        print(p)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
