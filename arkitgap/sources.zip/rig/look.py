# -*- coding: utf-8 -*-
"""שלב 10 · ספר הסגנון, ומצבי תאורה רגשיים.

**הדרישה, ומה בה קשה.** "אותה סצנה בשלוש תאורות — ניטרלית, חמה,
דרמטית — והדמות נשארת עקבית בזמן שהאטמוספרה משתנה." שתי הדרישות
האלה **מנוגדות זו לזו**, וזה כל העניין: תאורה שלא משנה כלום עוברת
את הראשונה ונכשלת בשנייה, ותאורה שמשנה הכול עושה את ההפך. לכן
יש כאן שני מדדים נפרדים ששניהם חייבים להתקיים יחד, ולא ציון אחד.

---

## איך נמדד "הדמות נשארה עקבית" בלי לפתוח דפדפן

לא בהשוואת צבע מוחלט — זה היה אוסר על תאורה לעשות את עבודתה.
מה שנמדד הוא **ההיררכיה**: בכל מצב תאורה, סדר הבהירות של אזורי
הדמות (עור, שיער, שפתיים, לבן העין, אישון, בגד) חייב להישמר.
אדם מזוהה לפי שהשיער שלו כהה מהעור ושלבן העין בהיר מהקשתית; אם
בתאורה הדרמטית השיער נעשה בהיר מהעור, זו אינה אותה דמות — גם אם
אף פיקסל לא "שגוי". המדד הוא מתאם הדירוג (Spearman) בין המצבים.

החישוב אינו הערכה: הוא משחזר את מודל התאורה שרץ בפועל ב-
``stage.html`` — Lambert לשלושת האורות, אור סביבה חצי-כיפתי,
מונח שפה, ואז מיפוי טונים ACES ותיקון גמא. אותו מודל, אותם
מספרים, ולכן מצב שנראה טוב כאן נראה טוב שם.

## ואיך נמדד "האטמוספרה אכן השתנתה"

שלושה דברים שאפשר למדוד ואי אפשר לזייף: **טמפרטורת הצבע** של
הפריים (יחס אדום-כחול), **הקונטרסט** בין האזור המואר לאזור הצל,
ו**הפרדת הנושא מהרקע**. מצב שלא הזיז לפחות שניים מהשלושה אינו
מצב רגשי אחר אלא אותו מצב בשם אחר.

---

## למה הטבלה יושבת פעמיים, ולמה יש בדיקה שמשווה אותן

מצבי התאורה חייבים להיות ב-``stage.html``, כי שם הם באמת רצים,
ובפייתון, כי שם הם נמדדים. שני סטים של מספרים לאותו מצב הם שתי
מערכות שיתפצלו תוך שבוע — זה נמדד כאן על ``keepawake`` ב-30/09
ועל התמלול ב-27/09. לכן ``audit`` **קורא את ה-HTML** ומשווה
מספר-מספר. טבלה שמישהו יעדכן רק בצד אחד מפילה את הבדיקה.
"""
from __future__ import annotations

import argparse
import json
import math
import re
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
STAGE_HTML = HERE / "stage.html"


# -------------------------------------------------------- ספר הסגנון

#: **שפת הצבע.** שלושה גוונים ולא יותר: גוון ראשי שהדמויות לובשות,
#: גוון משלים לרקע ולאור המשני, וגוון הדגשה שמופיע רק במוקד.
#: פלטה של שבעה גוונים אינה שפה אלא היעדר שפה.
COLOR_LANGUAGE = {
    "primary":   {"hex": "#e8c9a8", "role": "עור וטונים חמים - הנושא"},
    "complement": {"hex": "#9ec6ff", "role": "אור משני ורקע - קריר, נסוג"},
    "accent":    {"hex": "#ffb27a", "role": "הדגשה, מופיעה רק במוקד"},
    "shadow":    {"hex": "#1b2232", "role": "צל - כחול ולא שחור"},
}

#: **חומרים.** אלה הפרמטרים ש-``glbio.material_def`` ו-``stage.html``
#: מקבלים בפועל. ``sss`` הוא פיזור תת-עורי, והוא קיים רק בעור -
#: שיער ובגד שמפזרים אור נראים כמו שעווה.
MATERIALS = {
    "skin":     {"roughness": 0.62, "metalness": 0.0, "sss": 0.85,
                 "note": "פיזור רך; ברק נקודתי בלבד על המצח והאף"},
    "eyes":     {"roughness": 0.12, "metalness": 0.0, "sss": 0.0,
                 "note": "חלק ורטוב - הנקודה המבריקה היחידה בפנים"},
    "hair":     {"roughness": 0.46, "metalness": 0.0, "sss": 0.12,
                 "note": "אניזוטרופי לאורך הקווצה, בלי ברק פלסטי"},
    "clothing": {"roughness": 0.78, "metalness": 0.0, "sss": 0.0,
                 "note": "בד מט; הוא לא מתחרה בפנים על תשומת הלב"},
    "environment": {"roughness": 0.90, "metalness": 0.0, "sss": 0.0,
                    "note": "רקע מט ומונמך בניגודיות - הוא לא הנושא"},
}

#: **אזורי הדמות וצבע הבסיס שלהם**, בליניארי 0..1. הערכים נגזרים
#: מ-``pipeline.DEFAULT_PALETTE`` ולא נכתבים כאן פעמיים.
def albedo() -> dict[str, np.ndarray]:
    from . import pipeline                              # noqa: PLC0415
    pal = pipeline.expand_palette(dict(pipeline.DEFAULT_PALETTE))
    pick = {"skin": "skin", "hair": "hair", "lip": "lip",
            "sclera": "sclera", "iris": "iris", "pupil": "pupil",
            "brow": "brow", "cloth": "shirt"}
    out = {}
    for key, pkey in pick.items():
        v = pal.get(pkey)
        if v is None:
            continue
        out[key] = np.asarray(v, float)[:3]
    if "cloth" not in out:
        # אם לפלטה אין בגד, הוא נגזר מהגוון המשלים - לא מומצא.
        out["cloth"] = np.array([0.24, 0.30, 0.42])
    return out


#: הנורמלים המייצגים של כל אזור, במרחב המצלמה: לאן האזור פונה.
#: עור המצח פונה קדימה-למעלה, הלחי קדימה-הצידה, השיער האחורי אחורה.
#: אלה הכיוונים שקובעים מי נתפס בכל אור, וזה כל הטעם במדידה.
NORMALS = {
    "skin":   (0.00, 0.22, 0.97),
    "hair":   (-0.35, 0.55, 0.76),
    "lip":    (0.00, -0.10, 0.99),
    "sclera": (0.08, 0.05, 0.99),
    "iris":   (0.00, 0.00, 1.00),
    "pupil":  (0.00, 0.00, 1.00),
    "brow":   (0.00, 0.40, 0.92),
    "cloth":  (0.00, -0.25, 0.97),
}


# ------------------------------------------------------- מצבי התאורה

@dataclass(frozen=True)
class Mood:
    """מצב תאורה רגשי אחד.

    השמות והשדות זהים לאלה שב-``stage.html`` (``k``/``kc``/``f``/
    ``fc``/``r``/``rc``/``a``/``e``) ועוד שלושה שרק פייתון משתמש
    בהם לתיעוד: ``bounce``, ``atmosphere`` ו-``reflection``.
    """

    key: str
    label: str
    k: float         # עוצמת האור הראשי
    kc: int          # צבעו
    f: float         # אור מילוי
    fc: int
    r: float         # אור שפה
    rc: int
    a: float         # אור סביבה
    e: float         # חשיפה
    bounce: float    # אור מוחזר מהרצפה
    shadow: float    # רכות הצל: 0 = חד, 1 = רך לגמרי
    atmosphere: float  # אובך
    reflection: float  # עוצמת ההחזרות
    emphasis: str    # על מה התאורה מדגישה
    serves: str      # איזה רגש היא משרתת


def _hex(c: int) -> np.ndarray:
    return np.array([((c >> 16) & 255) / 255.0, ((c >> 8) & 255) / 255.0,
                     (c & 255) / 255.0])


#: שלושת המצבים שהדרישה מונה, ועוד שניים שהיו כאן קודם ונשמרים
#: כדי שלא לשבור את ``appeal.CONDITIONS``. **ההבדל בין השלושה הוא
#: בכל ארבעת האורות יחד ולא רק בעוצמת הראשי** - שינוי עוצמה לבד
#: מייצר "אותה תמונה כהה יותר", לא אווירה אחרת.
MOODS: dict[str, Mood] = {m.key: m for m in (
    Mood("neutral", "ניטרלי",
         k=1.95, kc=0xfff4e8, f=0.62, fc=0x9ec6ff, r=1.05, rc=0xd8ecff,
         a=0.52, e=1.00, bounce=0.18, shadow=0.55, atmosphere=0.06,
         reflection=0.20,
         emphasis="קריאות: כל אזור בפנים נראה, בלי העדפה",
         serves="סצנה שבה המידע הוא מה שנאמר ונעשה"),
    # **ההפרש בין המצבים הוגדל אחרי מדידה, ולא לפניה.** הגרסה
    # הראשונה נתנה ל"חם" מילוי 0.78 בגוון 0xffd9a8, והמדידה
    # החזירה הזזת גוון של 5% בלבד מול הניטרלי - כלומר תאורה
    # שנקראת חמה ואינה חמה. מה שמזיז טמפרטורה בפועל הוא **אור
    # המילוי**, לא האור הראשי: הראשי פוגע בשטח קטן ובזווית, והמילוי
    # צובע את כל מה שבצל. לכן המילוי עבר מ-0.78 ל-1.05 ולגוון חם
    # יותר, ובמתוח - לכחול קר יותר ולא רק לעוצמה נמוכה.
    Mood("warm", "חם ושמח",
         k=2.25, kc=0xffd27a, f=1.05, fc=0xffc98a, r=1.25, rc=0xffe8c0,
         a=0.86, e=1.08, bounce=0.34, shadow=0.82, atmosphere=0.14,
         reflection=0.26,
         emphasis="פנים פתוחות: צל רך, מילוי גבוה, בלי שקעים",
         serves="אושר, הקלה, ביטחון"),
    Mood("tense", "מתוח ודרמטי",
         k=2.70, kc=0xfff6ea, f=0.14, fc=0x4a6ccf, r=1.70, rc=0xa8c8ff,
         a=0.16, e=0.90, bounce=0.05, shadow=0.12, atmosphere=0.22,
         reflection=0.36,
         emphasis="חצי פנים בצל, שפה חדה - המבט נתפס בעין המוארת",
         serves="חשד, פחד, הסתרה, עימות"),
    Mood("rim", "שפה בלבד",
         k=0.40, kc=0xffe9d2, f=0.20, fc=0x8fb6ff, r=3.10, rc=0xe8f4ff,
         a=0.26, e=1.05, bounce=0.03, shadow=0.20, atmosphere=0.30,
         reflection=0.44,
         emphasis="צללית: מי זה, בלי מה הוא מרגיש",
         serves="מתח, אנונימיות, רגע לפני חשיפה"),
    Mood("hard_key", "אור ראשי קשה",
         k=3.70, kc=0xfff2dd, f=0.06, fc=0x6f8fcf, r=0.20, rc=0xbcd4ff,
         a=0.12, e=0.92, bounce=0.02, shadow=0.05, atmosphere=0.10,
         reflection=0.30,
         emphasis="בדיקת עמידות: הקשה ביותר לזהות דמות",
         serves="בדיקה, ולא בימוי"),
    # שלושת אלה היו קיימים **רק** ב-``stage.html``, והבדיקה
    # הדו-כיוונית תפסה את זה: מצב תאורה שרץ בלי רשומה בפייתון
    # הוא מצב שאיש אינו מודד, ובדיוק שם סחיפה מצטברת בשקט.
    Mood("studio", "אולפן (כינוי לניטרלי)",
         k=1.95, kc=0xfff4e8, f=0.62, fc=0x9ec6ff, r=1.05, rc=0xd8ecff,
         a=0.52, e=1.00, bounce=0.18, shadow=0.55, atmosphere=0.06,
         reflection=0.20,
         emphasis="זהה לניטרלי; נשמר כדי לא לשבור קריאות קיימות",
         serves="ברירת המחדל של הבמה"),
    Mood("dusk", "דמדומים",
         k=0.85, kc=0xffb27a, f=0.45, fc=0x5f7fd8, r=0.95, rc=0x9fc0ff,
         a=0.40, e=0.88, bounce=0.12, shadow=0.70, atmosphere=0.34,
         reflection=0.28,
         emphasis="אור נמוך וחם מול צל כחול - שעת הזהב",
         serves="נוסטלגיה, סוף יום, רוך"),
    Mood("sun_hard_left", "שמש קופחת משמאל",
         k=3.05, kc=0xfff1d6, f=0.48, fc=0x9ec9ff, r=0.70, rc=0xe6f2ff,
         a=0.88, e=1.09, bounce=0.42, shadow=0.18, atmosphere=0.16,
         reflection=0.22,
         emphasis="צל חד בכיוון הרקע הצרוב - סצנת חוץ",
         serves="חוץ ביום, אנרגיה גבוהה"),
)}

#: שלושת המצבים של מבחן הקבלה. ``rim`` ו-``hard_key`` אינם בהם:
#: הם קיימים לבדיקת עמידות ולא כבימוי רגשי, וערבוב ביניהם היה
#: הופך את המבחן לרחב ולכן חלש.
TRIO = ("neutral", "warm", "tense")

#: כיווני האורות, זהים ל-``stage.html``. נקודה: הם **אינם** נעים
#: עם המצב - תאורה שזזה מערבבת "האור שונה" עם "הדמות זזה", ואז
#: אי אפשר להפריד ביניהם במדידה.
L_KEY = np.array([-2.6, 3.4, 3.4])
L_FILL = np.array([3.4, 0.8, 2.0])
L_RIM = np.array([0.9, 2.4, -3.4])
VIEW = np.array([0.0, 0.0, 1.0])


def _unit(v) -> np.ndarray:
    v = np.asarray(v, float)
    n = float(np.linalg.norm(v))
    return v / n if n > 1e-9 else v


def _aces(x: np.ndarray) -> np.ndarray:
    """מיפוי טונים ACES, בדיוק הקירוב שרץ ב-three.js."""
    a, b, c, d, e = 2.51, 0.03, 2.43, 0.59, 0.14
    return np.clip((x * (a * x + b)) / (x * (c * x + d) + e), 0.0, 1.0)


def shade(region: str, mood: Mood, alb: dict[str, np.ndarray],
          shadowed: bool = False) -> np.ndarray:
    """צבע סופי של אזור תחת מצב תאורה, אחרי מיפוי טונים וגמא.

    משחזר את מודל התאורה של ``stage.html``: שלושה אורות מכוונים
    (Lambert), אור סביבה חצי-כיפתי, מונח שפה לפי הזווית לצופה,
    ואור מוחזר מהרצפה. זו אינה הדמיה חלופית - אלה אותם מספרים.
    """
    n = _unit(NORMALS.get(region, (0.0, 0.0, 1.0)))
    base = np.asarray(alb[region], float)
    out = np.zeros(3)
    # אור ראשי. בצל הוא נחסם, והצל עצמו רך לפי `shadow`.
    ndl = max(0.0, float(np.dot(n, _unit(L_KEY))))
    occl = mood.shadow if shadowed else 1.0
    out += base * _hex(mood.kc) * mood.k * ndl * occl
    # מילוי - תמיד מגיע, זו כל התכלית שלו.
    out += base * _hex(mood.fc) * mood.f * max(0.0, float(np.dot(n, _unit(L_FILL))))
    # שפה: חזק כשהנורמל מאונך לצופה.
    rl = max(0.0, float(np.dot(n, _unit(L_RIM))))
    fres = (1.0 - abs(float(np.dot(n, VIEW)))) ** 2.2
    out += base * _hex(mood.rc) * mood.r * rl * fres
    # סביבה חצי-כיפתית: שמיים מלמעלה, צל קריר מלמטה.
    up = (float(n[1]) + 1.0) * 0.5
    sky, ground = _hex(0xbcd4ff), _hex(0x1b2232)
    out += base * (sky * up + ground * (1.0 - up)) * mood.a
    # אור מוחזר מהרצפה - מגיע מלמטה, ולכן ממלא את מתחת הסנטר.
    out += base * _hex(0xcfbfa8) * mood.bounce * max(0.0, -float(n[1]) + 0.35)
    # פיזור תת-עורי מוסיף אדום לעור בלבד.
    if region in ("skin", "lip", "brow"):
        sss = MATERIALS["skin"]["sss"]
        out += base * np.array([0.10, 0.03, 0.02]) * sss * ndl * occl
    return np.power(_aces(out * mood.e), 1.0 / 2.2)


def _luma(c: np.ndarray) -> float:
    return float(0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2])


def _spearman(a: list[float], b: list[float]) -> float:
    """מתאם דירוג. מודד **סדר** ולא ערך, וזה בדיוק מה שצריך כאן."""
    if len(a) < 3:
        return 0.0
    ra = np.argsort(np.argsort(np.asarray(a, float))).astype(float)
    rb = np.argsort(np.argsort(np.asarray(b, float))).astype(float)
    ra -= ra.mean()
    rb -= rb.mean()
    den = float(np.linalg.norm(ra) * np.linalg.norm(rb))
    return float(ra @ rb / den) if den > 1e-9 else 0.0


# -------------------------------------------------------- המדידה

def render_signature(mood: Mood, alb: dict | None = None) -> dict:
    """חתימה מדידה של מצב תאורה אחד.

    ``hierarchy`` - בהירות כל אזור, בסדר קבוע. זו הזהות.
    ``warmth``    - יחס אדום-כחול. זו האטמוספרה.
    ``contrast``  - הפער בין מואר למוצל. זו הדרמה.
    """
    alb = alb or albedo()
    keys = sorted(alb)
    lit = {k: shade(k, mood, alb, shadowed=False) for k in keys}
    dark = {k: shade(k, mood, alb, shadowed=True) for k in keys}
    hier = [_luma(lit[k]) for k in keys]
    allc = np.array([lit[k] for k in keys] + [dark[k] for k in keys])
    # **החום נמדד ביחס לאלבדו ולא כערך מוחלט.** זה היה הבאג
    # הראשון כאן, והמדידה היא שחשפה אותו: יחס אדום-כחול מוחלט
    # נשלט בצבע העור (שכבר חם), ולכן הוא זז 5% בין תאורה ניטרלית
    # לחמה גם כשאור המילוי עבר מכחול לכתום. מה שאנחנו רוצים למדוד
    # הוא כמה **התאורה** הזיזה את הגוון, ולכן מחלקים ביחס של
    # צבע הבסיס עצמו.
    raw = np.array([alb[k] for k in keys])
    base_wb = float(raw[:, 0].mean() / max(1e-6, raw[:, 2].mean()))
    lit_wb = float(allc[:, 0].mean() / max(1e-6, allc[:, 2].mean()))
    warm = lit_wb / max(1e-6, base_wb)
    # ניגודיות הצל: רק אזורים שהאור הראשי בכלל מגיע אליהם.
    pairs = [(_luma(lit[k]), _luma(dark[k])) for k in keys]
    diffs = [a - b for a, b in pairs if a > 0.02]
    contrast = float(np.mean(diffs)) if diffs else 0.0
    # הפרדת נושא מרקע: הפער בין בהירות הדמות לבהירות הסביבה
    # תחת אותו אור. סביבה מט כהה, לפי ספר הסגנון.
    env = np.array([0.22, 0.25, 0.30])
    env_lit = np.power(_aces((env * _hex(mood.fc) * (mood.f + mood.a)
                              * (0.55 + 0.45 * mood.atmosphere)) * mood.e),
                       1.0 / 2.2)
    subj = float(np.mean([_luma(lit[k]) for k in ("skin", "hair", "cloth")
                          if k in lit]))
    sep = abs(subj - _luma(env_lit))
    return {"mood": mood.key, "keys": keys,
            "hierarchy": [round(v, 5) for v in hier],
            "warmth": round(warm, 4), "contrast": round(contrast, 4),
            "separation": round(sep, 4),
            "mean_luma": round(float(np.mean(hier)), 4)}


#: מתחת לזה הדמות השתנתה. 0.90 ולא 1.0: היפוך בין שני אזורים
#: שהבהירות שלהם קרובה מאוד (קשתית ואישון בתאורה כהה) אינו
#: "דמות אחרת", והוא יקרה בכל מצב דרמטי אמיתי.
IDENTITY_MIN = 0.90

#: **מרחק האווירה** שמעליו האווירה אכן זזה, ולא ספירת צירים.
#: ספירת צירים הייתה המדד הראשון כאן והיא שגויה: היא נותנת לשינוי
#: של 81% בניגודיות (בין ניטרלי למתוח) אותו משקל כמו 9% בגוון,
#: ולכן פסלה תאורה דרמטית תקינה. תאורה דרמטית באמת **אינה** קרה
#: יותר בממוצע - היא מנוגדת יותר, והמילוי בה כמעט אפס.
#:
#: הסף נגזר ממדידה ולא מניחוש (05-06/10): שלושת הזוגות האמיתיים
#: נותנים מרחק 0.77 / 0.81 / 0.96, וגרסת ביקורת שמשנה **רק** את
#: החשיפה נותנת 0.04 / 0.09 / 0.15 / 0.24 בחשיפות 1.1 עד 1.7.
#: 0.35 יושב בתוך פער של פי שלושה בין שתי הקבוצות.
ATMO_MIN = 0.35


def compare_moods(a: str, b: str, alb: dict | None = None) -> dict:
    """שני מצבים זה מול זה: מה נשמר ומה השתנה."""
    alb = alb or albedo()
    sa = render_signature(MOODS[a], alb)
    sb = render_signature(MOODS[b], alb)
    ident = _spearman(sa["hierarchy"], sb["hierarchy"])
    d_warm = abs(sa["warmth"] - sb["warmth"]) / max(sa["warmth"], sb["warmth"])
    d_cont = abs(sa["contrast"] - sb["contrast"]) / \
        max(1e-6, max(sa["contrast"], sb["contrast"]))
    d_luma = abs(sa["mean_luma"] - sb["mean_luma"]) / \
        max(1e-6, max(sa["mean_luma"], sb["mean_luma"]))
    dist = math.sqrt(d_warm ** 2 + d_cont ** 2 + d_luma ** 2)
    return {"pair": f"{a}|{b}", "identity": round(ident, 4),
            "warmth_delta": round(d_warm, 4),
            "contrast_delta": round(d_cont, 4),
            "luma_delta": round(d_luma, 4),
            "atmo_distance": round(dist, 4),
            "identity_ok": ident >= IDENTITY_MIN,
            "atmosphere_ok": dist >= ATMO_MIN}


# --------------------------------------- סנכרון מול הבמה שבאמת רצה

def html_moods(path: Path | None = None) -> dict[str, dict]:
    """קורא את טבלת התאורה מתוך ``stage.html``.

    זה מה שהופך "הטבלה כתובה פעמיים" מבאג להגנה: אי אפשר לעדכן
    צד אחד ולהישאר ירוק.
    """
    txt = (path or STAGE_HTML).read_text(encoding="utf-8")
    m = re.search(r"const\s+LIGHTS\s*=\s*\{(.*?)\n\};", txt, re.S)
    if not m:
        return {}
    body = m.group(1)
    out: dict[str, dict] = {}
    for mm in re.finditer(r"(\w+)\s*:\s*\{([^{}]*(?:\{[^{}]*\}[^{}]*)*)\}",
                          body):
        name, fields = mm.group(1), mm.group(2)
        d = {}
        for fm in re.finditer(r"\b([kfrae]c?)\s*:\s*(0x[0-9a-fA-F]+|[\d.]+)",
                              fields):
            key, val = fm.group(1), fm.group(2)
            d[key] = int(val, 16) if val.startswith("0x") else float(val)
        if d:
            out[name] = d
    return out


def sync_report(path: Path | None = None) -> dict:
    """משווה את טבלת פייתון לטבלת ה-HTML, שדה-שדה."""
    hm = html_moods(path)
    rows, bad = {}, []
    for key, mood in MOODS.items():
        h = hm.get(key)
        if h is None:
            bad.append(f"{key}: חסר ב-stage.html")
            rows[key] = {"in_html": False}
            continue
        diffs = []
        for f in ("k", "kc", "f", "fc", "r", "rc", "a", "e"):
            pv, hv = getattr(mood, f), h.get(f)
            if hv is None:
                diffs.append(f"{f} חסר")
            elif isinstance(pv, int) and f.endswith("c"):
                if int(hv) != pv:
                    diffs.append(f"{f}: py={hex(pv)} html={hex(int(hv))}")
            elif abs(float(hv) - float(pv)) > 1e-6:
                diffs.append(f"{f}: py={pv} html={hv}")
        rows[key] = {"in_html": True, "diffs": diffs}
        bad += [f"{key}: {d}" for d in diffs]
    extra = [k for k in hm if k not in MOODS]
    return {"rows": rows, "mismatch": bad, "html_only": extra,
            "ok": not bad}


# ------------------------------------------------------------- ביקורת

def audit() -> dict:
    """מבחן הקבלה של שלב 10.

    אותה דמות, שלושה מצבי תאורה. **שני תנאים מנוגדים שחייבים
    להתקיים יחד** - הזהות נשמרת, והאטמוספרה זזה - ועוד שער
    שלישי שמוכיח שהמדד אינו מרוכך: מצב ביקורת שמשנה רק את
    החשיפה חייב **להיכשל** בבדיקת האטמוספרה.
    """
    t0 = time.time()
    alb = albedo()
    sigs = {k: render_signature(MOODS[k], alb) for k in TRIO}
    pairs = [compare_moods(a, b, alb)
             for i, a in enumerate(TRIO) for b in TRIO[i + 1:]]
    sync = sync_report()

    # --- גרסת ביקורת: אותו ניטרלי, רק חשוף יותר. היא **חייבת**
    #     ליפול בבדיקת האטמוספרה, אחרת המדד מאשר "אותה תמונה
    #     בהירה יותר" כאווירה חדשה, וזו בדיוק הטעות הנפוצה.
    base = MOODS["neutral"]
    fake = Mood(**{**base.__dict__, "key": "control_exposure", "e": 1.22})
    MOODS["control_exposure"] = fake
    try:
        ctrl = compare_moods("neutral", "control_exposure", alb)
    finally:
        MOODS.pop("control_exposure", None)

    ident_min = min(p["identity"] for p in pairs)
    atmo_all = all(p["atmosphere_ok"] for p in pairs)

    checks = {
        "שלושה מצבים רגשיים": {
            "value": len(TRIO), "limit": ">=3", "pass": len(TRIO) >= 3},
        "לכל מצב יש רגש שהוא משרת": {
            "value": sum(1 for k in MOODS if MOODS[k].serves),
            "limit": f"=={len(MOODS)}",
            "pass": all(MOODS[k].serves and MOODS[k].emphasis for k in MOODS)},
        "שפת צבע מוגדרת": {
            "value": len(COLOR_LANGUAGE), "limit": ">=3",
            "pass": len(COLOR_LANGUAGE) >= 3},
        "חומרים מוגדרים לכל המשטחים": {
            "value": len(MATERIALS), "limit": ">=5",
            "pass": all(k in MATERIALS for k in
                        ("skin", "eyes", "hair", "clothing", "environment"))},
        "ארבעת האורות ואור מוחזר בכל מצב": {
            "value": sum(1 for m in MOODS.values()
                         if m.k > 0 and m.f > 0 and m.r > 0 and m.a > 0),
            "limit": f"=={len(MOODS)}",
            "pass": all(m.k > 0 and m.f > 0 and m.r > 0 and m.a > 0
                        for m in MOODS.values())},
        "צל ואובך והחזרות לכל מצב": {
            "value": len(MOODS), "limit": "כולם",
            "pass": all(0.0 <= m.shadow <= 1.0 and m.atmosphere >= 0.0
                        and m.reflection >= 0.0 for m in MOODS.values())},
        "הדמות נשארת זהה בכל שלושת המצבים": {
            "value": round(ident_min, 4), "limit": f">={IDENTITY_MIN}",
            "pass": ident_min >= IDENTITY_MIN},
        "האטמוספרה משתנה בכל זוג": {
            "value": round(min(p["atmo_distance"] for p in pairs), 4),
            "limit": f">={ATMO_MIN}", "pass": atmo_all},
        "ביקורת: חשיפה לבדה אינה אווירה": {
            "value": ctrl["atmo_distance"], "limit": f"<{ATMO_MIN}",
            "pass": not ctrl["atmosphere_ok"]},
        "המתוח דרמטי יותר מהניטרלי": {
            "value": round(sigs["tense"]["contrast"]
                           - sigs["neutral"]["contrast"], 4),
            "limit": ">0",
            "pass": sigs["tense"]["contrast"] > sigs["neutral"]["contrast"]},
        "החם חם יותר מהניטרלי": {
            "value": round(sigs["warm"]["warmth"]
                           - sigs["neutral"]["warmth"], 4),
            "limit": ">0",
            "pass": sigs["warm"]["warmth"] > sigs["neutral"]["warmth"]},
        "הפרדת נושא מרקע בכל מצב": {
            "value": round(min(s["separation"] for s in sigs.values()), 4),
            "limit": ">=0.05",
            "pass": min(s["separation"] for s in sigs.values()) >= 0.05},
        "טבלת התאורה זהה ל-stage.html": {
            "value": len(sync["mismatch"]), "limit": "==0",
            "pass": sync["ok"]},
    }
    passed = all(v["pass"] for v in checks.values())
    return {"task": "שלב 10 - ספר הסגנון והתאורה",
            "moods": len(MOODS), "trio": list(TRIO),
            "signatures": sigs, "pairs": pairs, "control": ctrl,
            "sync": sync, "bible": {"color": COLOR_LANGUAGE,
                                    "materials": MATERIALS},
            "checks": checks, "passed": passed,
            "seconds": round(time.time() - t0, 2)}


def main(argv=None) -> int:
    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(description="שלב 10 · ספר הסגנון והתאורה")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args(argv)
    rep = audit()
    if a.json:
        print(json.dumps(rep, ensure_ascii=False, indent=1, default=str))
        return 0 if rep["passed"] else 1
    print(f"=== {rep['task']} ===")
    print("מצבי התאורה:")
    for k in MOODS:
        m = MOODS[k]
        star = "★" if k in TRIO else " "
        print(f" {star} {k:16s} {m.label:14s} {m.emphasis}")
        print(f"      משרת: {m.serves}")
    print("\nחתימות שלושת המצבים:")
    for k, s in rep["signatures"].items():
        print(f"  {k:10s} חום={s['warmth']:.3f} ניגודיות={s['contrast']:.3f} "
              f"הפרדה={s['separation']:.3f} בהירות={s['mean_luma']:.3f}")
    print("\nזוגות:")
    for p in rep["pairs"]:
        print(f"  {p['pair']:20s} זהות={p['identity']:.3f} "
              f"(חום {p['warmth_delta']:.3f} · ניגודיות {p['contrast_delta']:.3f}"
              f" · בהירות {p['luma_delta']:.3f}) מרחק אווירה="
              f"{p['atmo_distance']:.3f}")
    print("\nמבחני הקבלה:")
    for k, v in rep["checks"].items():
        print(f"  {'✓' if v['pass'] else '✗'} {k}: {v['value']} "
              f"(גבול {v['limit']})")
    if rep["sync"]["mismatch"]:
        for d in rep["sync"]["mismatch"][:8]:
            print(f"      פער: {d}")
    print(f"\n{'עבר' if rep['passed'] else 'נכשל'} · {rep['seconds']}ש")
    return 0 if rep["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
