# -*- coding: utf-8 -*-
"""סרטון ההדגמה של לוקאס ומאיה - מופק מחדש אחרי כל משימה בתוכנית השדרוג.

העיקרון: הסרטון הזה אינו "עוד סצנה". הוא **הראיה הנראית** שהיכולות
שנוספו באמת עובדות על שתי דמויות שונות, ולא רק עוברות בדיקת יחידה.
לכן כל סצנה בו ממופה ליכולת מוגדרת, וה-JSON שנשמר לידו רושם איזו
יכולת הוכחה בכל סצנה ובאיזה פריימים.

כל חישוב הפוזה נעשה כאן בפייתון (FK, IK, בקרות פנים, תנועה משנית)
ונבדק ב-`test_rig.py`. הדפדפן רק מקבל קוורטניונים מוכנים ומצלם, כך
שבאג בריג נתפס בבדיקת יחידה ולא "אולי זה WebGL".

הרצה:
    python -m rig.showreel                     # סרטון מלא
    python -m rig.showreel --probe             # תמונת בדיקה לכל סצנה
    python -m rig.showreel --task 2 --title "..."   # אחרי משימה חדשה
"""
from __future__ import annotations

import argparse
import asyncio
import base64
import functools
import http.server
import json
import math
import shutil
import socketserver
import sys
import tempfile
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

import numpy as np

HERE = Path(__file__).resolve().parent
STUDIO = HERE.parent
if str(STUDIO) not in sys.path:
    sys.path.insert(0, str(STUDIO))

from rig import acting, controls, face, pipeline, secondary  # noqa: E402
from rig.skeleton import Skeleton, quat_slerp              # noqa: E402

#: הזוויות הרכות של הפריים האחרון שנפתר, לפי דמות. נכתב ב-`produce`
#: ונקרא בכתוביות של סצנות TASK 08.
SOFT_LIVE: dict = {"A": {}, "B": {}, "eA": 0.0, "eB": 0.0}

RIG_DIR = Path(r"D:\claude-bot\out\char3d\rigged")
OUT_DIR = Path(r"D:\claude-bot\out\char3d\showreel")

FPS = 30
WIDTH, HEIGHT = 1920, 1080


# ------------------------------------------------------------------ עזרים

def smooth(u: float) -> float:
    u = min(1.0, max(0.0, u))
    return u * u * (3 - 2 * u)


def lerp(a: float, b: float, u: float) -> float:
    return a + (b - a) * smooth(u)


def blink(t: float, period: float = 3.1, phase: float = 0.0,
          dur: float = 0.14) -> float:
    """מצמוץ: אפס כמעט כל הזמן, וקימור חד בחלון קצר. מצמוץ בסינוס
    נראה כמו ישנוניות, לא כמו מצמוץ."""
    x = (t + phase) % period
    if x > dur:
        return 0.0
    return math.sin(math.pi * x / dur) ** 0.6


def idle(t: float, phase: float = 0.0) -> dict:
    """נשימה, העברת משקל ומצמוץ. בלי זה דמות במנוחה נראית מאובנת,
    וזה מה שהפך את הרנדורים הראשונים ל"תמונה" ולא ל"שוט"."""
    return {
        "breath": 0.55 * math.sin(2 * math.pi * (t * 0.26 + phase)),
        "spine_side": 0.10 * math.sin(2 * math.pi * (t * 0.13 + phase)),
        "spine_twist": 0.07 * math.sin(2 * math.pi * (t * 0.10 + phase + 0.3)),
        "hips_roll": 0.09 * math.sin(2 * math.pi * (t * 0.13 + phase)),
        "head_yaw": 0.10 * math.sin(2 * math.pi * (t * 0.09 + phase + 0.6)),
        "head_pitch": 0.05 * math.sin(2 * math.pi * (t * 0.12 + phase)),
        "blink_L": blink(t, 3.1, phase * 2.0),
        "blink_R": blink(t, 3.1, phase * 2.0),
        "smile_L": 0.18, "smile_R": 0.18,
        # arm_down=1.0 מוריד את הזרוע 70 מעלות מפוזת הכריכה (צלב).
        # 0.80 השאיר אותן פרושות ב-34 מעלות מהגוף, וזה נראה כמו בובת
        # ראווה ולא כמו אדם עומד. 0.93 מצמיד בלי לחדור לגוף.
        "arm_down_L": 0.93, "arm_down_R": 0.93,
        "arm_fwd_L": 0.06, "arm_fwd_R": 0.06,
        "curl_index_L": 0.18, "curl_middle_L": 0.20, "curl_ring_L": 0.22,
        "curl_pinky_L": 0.24, "curl_thumb_L": 0.12,
        "curl_index_R": 0.18, "curl_middle_R": 0.20, "curl_ring_R": 0.22,
        "curl_pinky_R": 0.24, "curl_thumb_R": 0.12,
    }


def merge(*dicts) -> dict:
    out: dict = {}
    for d in dicts:
        if d:
            out.update(d)
    return out


def blend_q(qa: dict, qb: dict, u: float) -> dict:
    """מיזוג שתי פוזות בקוורטניונים. איחוד שמות העצמות, ועצם שחסרה
    באחת הפוזות נחשבת סיבוב יחידה - בדיוק כמו שהצופה מתנהג."""
    I = np.array([0.0, 0.0, 0.0, 1.0])
    out = {}
    for name in set(qa) | set(qb):
        out[name] = quat_slerp(qa.get(name, I), qb.get(name, I), u)
    return out


# ------------------------------------------------------------------ סצנות

@dataclass
class Shot:
    key: str
    secs: float
    cap: str
    sub: str
    proves: str                       # איזו יכולת הסצנה מוכיחה
    cam: Callable[[float], dict]
    a: Callable[[float, float], tuple] = lambda u, t: ({}, {})
    b: Callable[[float, float], tuple] = lambda u, t: ({}, {})
    labels: dict = field(default_factory=dict)
    sec_strength: float = 1.0
    #: מצב התאורה של הבמה (TASK 09). קבוע לכל הסצנה.
    light: str = "studio"
    vis: dict = field(default_factory=dict)       # {"A": bool, "B": bool}
    #: שכבת הסביבה הצרובה (05/10). u -> {"pan","dap","flare"}.
    #: שוט בלי `env_of` מרונדר על רקע האולפן בדיוק כמו קודם, ולכן
    #: כל 11 המשימות הקודמות אינן מושפעות.
    env_of: Callable[[float], dict] | None = None
    #: כתובית שמתחלפת בתוך הסצנה (u -> טקסט). בסצנת בידוד האזורים
    #: הכתובית **היא** ההוכחה: בלי לדעת איזו קבוצה פועלת כרגע, הצופה
    #: רואה פנים שזזות ולא יכול לאמת שהן נשלטות בנפרד.
    caption_of: Callable[[float], str] | None = None
    #: הלהקה (TASK 13). t בשניות **מתחילת השוט** -> מטען הלהקה
    #: (`ensemble.Take.payload`). שוט בלי `ens_of` מרונדר בדיוק כמו
    #: קודם, ולכן אף אחת מ-12 המשימות הקודמות אינה משתנה.
    ens_of: Callable[[float], dict] | None = None
    #: תנועת מקום (TASK 14). t בשניות מתחילת השוט -> {"A": {"ox","oy",
    #: "oz"}, "B": ...}, בצירי הדמות. שוט שנושא את זה **מחליף** את
    #: נעילת הרצפה ואת `lift_of` לדמויות שמופיעות בו, ולא מתווסף
    #: אליהן: ראה ההערה ב-`stage.html`. דמות שאינה במילון ממשיכה
    #: בנעילת הרצפה הרגילה, ולכן אפשר להניע אחת ולהשאיר אחת.
    move_of: Callable[[float], dict] | None = None


def build_shots(h: float, lib_a: dict, lib_b: dict) -> list[Shot]:
    """ציר הזמן. h = גובה הדמות במטרים; יעדי ה-IK מתוקננים אליו."""
    k = h / 1.7

    # --- 1. השלד: שתי דמויות שלמות, מצלמה מקיפה
    def cam1(u):
        return {"yaw": lerp(-26, 24, u), "pitch": lerp(4, 9, u),
                "dist": lerp(4.5, 4.0, u), "ty": 0.98, "fov": 30}

    s1 = Shot(
        "skeleton", 4.6,
        "שלד אמיתי של 82 עצמות",
        "גוף שלם · עור · פוזה היא סיבוב עצמות, לא הזזת פיקסלים",
        "שתי דמויות מרוגגות בתנועה בו-זמנית, מצלמה מקיפה",
        cam1,
        a=lambda u, t: (idle(t, 0.00), {}),
        b=lambda u, t: (idle(t, 0.37), {}),
        labels={"a": "לוקאס", "b": "מאיה", "y": 1.86},
    )

    # --- 2. ריג הפנים: תקריב על מאיה
    def cam2(u):
        return {"yaw": lerp(-16, 12, u), "pitch": lerp(1, -2, u),
                "dist": lerp(0.98, 0.84, u), "tx": 0.53, "ty": 1.575,
                "tz": 0.03, "fov": 30}

    def face_b(u, t):
        talk = max(0.0, math.sin(2 * math.pi * t * 2.3)) ** 0.7
        talk2 = max(0.0, math.sin(2 * math.pi * t * 1.4 + 1.1)) ** 0.8
        return merge(idle(t, 0.37), {
            "jaw_open": 0.18 + 0.62 * talk,
            "jaw_side": 0.22 * math.sin(2 * math.pi * t * 0.9),
            "tongue_up": 0.45 * talk2, "tongue_out": 0.18 * talk,
            "eye_aim_x": 0.55 * math.sin(2 * math.pi * t * 0.55),
            "eye_aim_y": 0.30 * math.sin(2 * math.pi * t * 0.38 + 0.8),
            "eye_converge": 0.25,
            "brow_up_L": 0.30 + 0.55 * talk2, "brow_up_R": 0.20 + 0.45 * talk2,
            "brow_furrow_L": 0.30 * (1 - talk2), "brow_furrow_R": 0.30 * (1 - talk2),
            "squint_L": 0.22 * talk, "squint_R": 0.22 * talk,
            "cheek_puff_L": 0.25 * talk2, "cheek_puff_R": 0.20 * talk2,
            "smile_L": 0.25 + 0.45 * talk2, "smile_R": 0.25 + 0.40 * talk2,
            "blink_L": blink(t, 1.9, 0.2), "blink_R": blink(t, 1.9, 0.2),
            "head_yaw": 0.16 * math.sin(2 * math.pi * t * 0.42),
            "head_pitch": 0.10 * math.sin(2 * math.pi * t * 0.6),
            "head_roll": -0.12 * math.sin(2 * math.pi * t * 0.33),
            "neck_yaw": 0.08 * math.sin(2 * math.pi * t * 0.42),
        }), {}

    s2 = Shot(
        "face", 4.6,
        "ריג פנים: לסת, לשון, עיניים, עפעפיים, גבות, לחיים",
        "הפה נפתח מהלסת והעיניים מכוונות בנפרד - לא תמונה שמתחלפת",
        "15 עצמות פנים בתנועה בתקריב, כולל מצמוץ ומבט",
        cam2,
        a=lambda u, t: (merge(idle(t, 0.0), {"head_yaw": 0.35,
                                             "eye_aim_x": 0.5,
                                             "smile_L": 0.3, "smile_R": 0.3}), {}),
        b=face_b,
        sec_strength=0.7,
        vis={"A": False, "B": True},
    )

    # --- 3. האצבעות: תקריב על יד לוקאס
    hand = (0.26 * k, 1.30 * k, 0.40 * k)

    def cam3(u):
        return {"yaw": lerp(34, 14, u), "pitch": lerp(14, 4, u),
                "dist": lerp(1.00, 0.84, u),
                "tx": -0.20, "ty": 1.30, "tz": 0.38, "fov": 32}

    def fingers_a(u, t):
        g = 0.5 - 0.5 * math.cos(2 * math.pi * t * 0.62)      # סגירה/פתיחה
        wave = lambda ph: 0.5 - 0.5 * math.cos(
            2 * math.pi * t * 1.25 - ph)                       # גלישת אצבעות
        return merge(idle(t, 0.0), {
            "head_pitch": -0.35, "head_yaw": 0.30, "neck_pitch": -0.2,
            "eye_aim_x": 0.45, "eye_aim_y": -0.45, "squint_L": 0.3,
            "squint_R": 0.3, "smile_L": 0.3, "smile_R": 0.3,
            "spine_twist": -0.18,
            "spread_L": 0.75 * (1 - g),
            "wrist_pitch_L": 0.25 - 0.45 * g,
            "wrist_yaw_L": 0.25 * math.sin(2 * math.pi * t * 0.8),
            "curl_thumb_L": 0.15 + 0.80 * wave(0.0),
            "curl_index_L": 0.10 + 0.88 * wave(0.9),
            "curl_middle_L": 0.10 + 0.90 * wave(1.6),
            "curl_ring_L": 0.10 + 0.90 * wave(2.3),
            "curl_pinky_L": 0.10 + 0.88 * wave(3.0),
        }), {"hand_L": {"target": hand,
                        "pole": (0.62 * k, 0.95 * k, -0.20 * k)}}

    s3 = Shot(
        "fingers", 4.4,
        "30 עצמות אצבעות · פריסה, כיפוף וסיבוב פרק כף היד",
        "כל אצבע נשלטת לחוד, וכף היד מגיעה למקום דרך IK",
        "אצבעות נעות בנפרד בתקריב, יד מוחזקת ביעד IK קבוע",
        cam3,
        a=fingers_a,
        b=lambda u, t: (merge(idle(t, 0.37),
                              {"head_yaw": -0.42, "eye_aim_x": -0.6,
                               "brow_up_L": 0.35, "brow_up_R": 0.35,
                               "smile_L": 0.4, "smile_R": 0.4}), {}),
        sec_strength=0.6,
        vis={"A": True, "B": False},
    )

    # --- 4. IK: הושטת יד למטרה נעה
    def cam4(u):
        return {"yaw": lerp(-34, -8, u), "pitch": lerp(6, 3, u),
                "dist": lerp(3.5, 3.1, u), "ty": 1.05, "fov": 31}

    def ik_a(u, t):
        ph = 2 * math.pi * t * 0.42
        tgt = (0.20 * k + 0.26 * k * math.cos(ph),
               (1.18 + 0.55 * (0.5 + 0.5 * math.sin(ph))) * k,
               (0.30 + 0.16 * math.cos(ph * 0.7)) * k)
        look = 0.5 + 0.5 * math.sin(ph)
        return merge(idle(t, 0.0), {
            "head_pitch": -0.15 + 0.55 * look, "head_yaw": 0.28,
            "eye_aim_y": -0.3 + 0.8 * look, "eye_aim_x": 0.35,
            "brow_up_L": 0.25 + 0.4 * look, "brow_up_R": 0.25 + 0.4 * look,
            "jaw_open": 0.10 + 0.25 * look,
            "spine_bend": -0.18 * look, "spine_twist": -0.22,
            "spread_L": 0.45, "wrist_pitch_L": 0.2,
            "curl_index_L": 0.12, "curl_middle_L": 0.15,
            "curl_ring_L": 0.18, "curl_pinky_L": 0.2,
        }), {"hand_L": {"target": tgt,
                        "pole": (0.65 * k, 1.0 * k, -0.25 * k)}}

    def wave_b(u, t):
        sw = math.sin(2 * math.pi * t * 1.55)
        return merge(idle(t, 0.37), {
            "head_yaw": -0.20, "head_roll": 0.10 * sw,
            "smile_L": 0.7, "smile_R": 0.7, "squint_L": 0.3, "squint_R": 0.3,
            "brow_up_L": 0.45, "brow_up_R": 0.45, "jaw_open": 0.22,
            "spine_twist": 0.18, "spread_R": 0.6,
            "wrist_yaw_R": 0.55 * sw, "wrist_pitch_R": 0.25,
            "curl_thumb_R": 0.0, "curl_index_R": 0.0, "curl_middle_R": 0.0,
            "curl_ring_R": 0.05, "curl_pinky_R": 0.1,
        }), {"hand_R": {"target": (-0.34 * k + 0.07 * k * sw,
                                   1.60 * k + 0.05 * k * abs(sw),
                                   0.18 * k),
                        "pole": (-0.58 * k, 1.05 * k, -0.30 * k)}}

    s4 = Shot(
        "ik", 4.6,
        "IK: היד מגיעה ליעד במרחב",
        "קובעים נקודה - והכתף, המרפק והיד נפתרים אליה לבד",
        "יד לוקאס עוקבת אחרי יעד נע; מאיה מנופפת עם IK משלה",
        cam4, a=ik_a, b=wave_b,
    )

    # --- 5. ספריית הפוזות + זהות יציבה, מצלמה מקיפה
    order = ["rest", "wave", "point", "crouch", "reach_up", "talk_closeup"]
    order_a = [p for p in order if p in lib_a]
    order_b = [p for p in order if p in lib_b]

    def cam5(u):
        # טווח ההקפה מוגבל ל-110 מעלות בכוונה: מעבר לזה שתי הדמויות
        # מתיישרות זו מאחורי זו ונראות כגוש אחד.
        return {"yaw": lerp(-55, 55, u), "pitch": lerp(3, 13, u),
                "dist": lerp(4.3, 4.8, u), "ty": 1.0, "fov": 30}

    s5 = Shot(
        "poses", 5.4,
        "אותה דמות בכל פוזה ומכל זווית",
        "הצורה נבנית פעם אחת ולא נגזרת מהתמונה - לכן הזהות לא זזה",
        "מעבר רציף בין פוזות ספרייה בזמן שהמצלמה מקיפה 110 מעלות",
        cam5,
        labels={"a": "לוקאס", "b": "מאיה", "y": 1.92},
    )
    s5.pose_cycle = (order_a, order_b)       # מטופל בנפרד ברנדור

    # --- 6. תנועה משנית
    def cam6(u):
        return {"yaw": lerp(18, -14, u), "pitch": 5,
                "dist": lerp(3.0, 2.7, u), "ty": 1.12, "fov": 31}

    def snap(t, phase=0.0):
        """תנועה חדה ועצירה - זה מה שחושף פיגור. סינוס חלק מסתיר אותו."""
        x = ((t + phase) % 1.7) / 1.7
        return math.tanh(6.5 * math.sin(2 * math.pi * x))

    def sec_a(u, t):
        s = snap(t)
        return merge(idle(t, 0.0), {
            "hips_yaw": 0.75 * s, "spine_twist": 0.45 * s,
            "spine_side": 0.25 * s, "head_yaw": 0.30 * s,
            "arm_down_L": 0.86, "arm_down_R": 0.86,
            "arm_fwd_L": 0.25, "arm_fwd_R": 0.25,
            "elbow_L": 0.35, "elbow_R": 0.35,
            "brow_up_L": 0.3, "brow_up_R": 0.3, "jaw_open": 0.12,
        }), {}

    def sec_b(u, t):
        s = snap(t, 0.55)
        return merge(idle(t, 0.37), {
            "hips_yaw": -0.70 * s, "spine_twist": -0.42 * s,
            "spine_side": -0.22 * s, "head_yaw": -0.28 * s,
            "arm_down_L": 0.88, "arm_down_R": 0.88,
            "arm_fwd_L": 0.22, "arm_fwd_R": 0.22,
            "elbow_L": 0.30, "elbow_R": 0.30,
            "smile_L": 0.35, "smile_R": 0.35,
        }), {}

    s6 = Shot(
        "secondary", 4.4,
        "תנועה משנית: החזה והראש מגיעים באיחור",
        "האגן עוצר - והגוף ממשיך רגע. זה מה שמבדיל תנועה חיה ממדויקת",
        "סיבוב אגן חד וחוזר, עם קפיץ מרוסן על חזה/צוואר/ראש",
        cam6, a=sec_a, b=sec_b, sec_strength=1.5,
    )

    # --- 7. תקריב פנים ושיער על מאיה (TASK 02)
    def cam7(u):
        return {"yaw": lerp(-38, 30, u), "pitch": lerp(6, -3, u),
                "dist": lerp(0.80, 0.70, u), "tx": 0.53, "ty": 1.585,
                "tz": 0.02, "fov": 30}

    def closeup_b(u, t):
        return merge(idle(t, 0.37), {
            "head_yaw": 0.10 * math.sin(2 * math.pi * t * 0.30),
            "head_pitch": 0.06 * math.sin(2 * math.pi * t * 0.22),
            "head_roll": -0.05 * math.sin(2 * math.pi * t * 0.18),
            "eye_aim_x": 0.22 * math.sin(2 * math.pi * t * 0.33),
            "eye_aim_y": 0.12 * math.sin(2 * math.pi * t * 0.26),
            "blink_L": blink(t, 2.7, 0.4), "blink_R": blink(t, 2.7, 0.4),
            "brow_up_L": 0.22, "brow_up_R": 0.18,
            "smile_L": 0.34, "smile_R": 0.32, "jaw_open": 0.06,
        }), {}

    s7 = Shot(
        "closeup_maya", 5.0,
        "תווי פנים ושיער כגאומטריה, לא כאזורי צבע",
        "שיער עם נפח, גבות, ריסים, שפתיים וקשתית - לכל אחד יש קצה משלו",
        "תקריב איטי על מאיה: שיער, גבות, ריסים, שפתיים, אישון ונצנוץ",
        cam7, b=closeup_b, sec_strength=0.5, vis={"A": False, "B": True},
    )

    # --- 8. אותו תקריב על לוקאס: ההוכחה שזו שיטה ולא כוונון לדמות אחת
    def cam8(u):
        return {"yaw": lerp(26, -22, u), "pitch": lerp(-2, 7, u),
                "dist": lerp(0.78, 0.68, u), "tx": -0.53, "ty": 1.585,
                "tz": 0.02, "fov": 30}

    def closeup_a(u, t):
        return merge(idle(t, 0.0), {
            "head_yaw": -0.12 * math.sin(2 * math.pi * t * 0.28),
            "head_pitch": 0.05 * math.sin(2 * math.pi * t * 0.24),
            "eye_aim_x": -0.20 * math.sin(2 * math.pi * t * 0.31),
            "blink_L": blink(t, 2.3, 0.9), "blink_R": blink(t, 2.3, 0.9),
            "brow_up_L": 0.26, "brow_up_R": 0.30,
            "smile_L": 0.40, "smile_R": 0.38, "jaw_open": 0.08,
        }), {}

    s8 = Shot(
        "closeup_lucas", 4.6,
        "אותה שיטה, דמות אחרת",
        "אורך השיער, גוון העור והשפתיים נמדדים מתמונת הייחוס של כל דמות",
        "תקריב על לוקאס: שיער קצר שנמדד מהתמונה, מול שיער ארוך של מאיה",
        cam8, a=closeup_a, sec_strength=0.5, vis={"A": True, "B": False},
    )

    return [s1, s2, s3, s4, s5, s6, s7, s8]


# ------------------------------------------------- סצנות TASK 02 (משחק פנים)
# למה סט נפרד ולא עוד סצנה בסוף: הסרטון של כל משימה אמור להראות את
# **היכולות של אותה משימה**. דחיסת 8 סצנות TASK 01 ועוד 7 חדשות לסרטון
# אחד הפכה כל סצנה לשנייה וחצי, ואי אפשר לראות בה כלום.


def _ar(a: float, b: float, u: float) -> float:
    return a + (b - a) * u


def build_shots_acting(h: float) -> list[Shot]:
    """ציר הזמן של TASK 02. כל סצנה מוכיחה **טענה אחת** שאפשר להכחיש:
    הפרדת אזורים, קומבינציה, אסימטריה, השהיה, מהירות, וערבוב."""
    REG = ["brows", "eyelids", "gaze", "cheeks", "nose",
           "mouth", "jaw", "lips", "tongue", "head"]
    HEB = {"brows": "גבות", "eyelids": "עפעפיים", "gaze": "אישונים ומבט",
           "cheeks": "לחיים", "nose": "אף", "mouth": "פה", "jaw": "לסת",
           "lips": "שפתיים", "tongue": "לשון", "head": "כיוון הראש"}

    # --- 1. הפרדת האזורים: עשרה אזורים, אחד-אחד, על אותן פנים
    def cam1(u):
        return {"yaw": _ar(-14, 12, u), "pitch": _ar(2, -2, u),
                "dist": _ar(0.74, 0.68, u), "tx": 0.53, "ty": 1.585,
                "tz": 0.02, "fov": 30}

    def iso_b(u, t):
        """כל אזור מקבל חלון זמן משלו, עם עלייה וירידה - כדי שרואים
        מה בדיוק זז, ולא מצב סופי שכבר אי אפשר להשוות אליו."""
        span = 1.0 / len(REG)
        i = min(len(REG) - 1, int(u / span))
        v = (u - i * span) / span
        amp = math.sin(math.pi * min(1.0, max(0.0, v))) ** 0.7
        ctl, mph = acting.isolate(REG[i], 0.95 * amp,
                                  bias=0.35 if i % 3 == 1 else 0.0)
        return merge(idle(t, 0.37), ctl), {}, mph

    s1 = Shot(
        "isolation", 10.0,
        "עשר קבוצות הפנים · כל אחת נשלטת לבד",
        "גבות · עפעפיים · אישונים · לחיים · אף · פה · לסת · שפתיים · לשון · ראש",
        "בידוד: כל קבוצה מופעלת לבדה, והשאר במנוחה מדודה",
        cam1, b=iso_b, sec_strength=0.4, vis={"A": False, "B": True},
        caption_of=lambda u: "קבוצה " + HEB[REG[min(len(REG) - 1,
                                                    int(u * len(REG)))]],
    )

    # --- 2. הפתעה: קומבינציה עם תזמון פנימי
    def cam2(u):
        return {"yaw": _ar(-20, -4, u), "pitch": _ar(0, 2, u),
                "dist": _ar(0.92, 0.76, u), "tx": -0.53, "ty": 1.585,
                "tz": 0.02, "fov": 30}

    def perf(name, seed, cues=((0.45, 1.0, 1.0),)):
        """ביטוי אמיתי נמשך כשנייה-שתיים, והסצנה נמשכת חמש. לכן כל
        סצנה מריצה אותו **יותר מפעם אחת**, בעוצמה ובמהירות שונות.

        זה לא קוסמטיקה: המדידה שתפסה את זה היא `max_shapes_active=0`
        בסצנות `surprise` ו-`duchenne` - הביטוי נגמר ברביע הראשון,
        ומאותו רגע הפנים חזרו לנייטרל ו"היכולת החדשה" לא הייתה
        בפריים בכלל. פריים בודד באמצע הסצנה היה נראה תקין לגמרי.
        """
        p = acting.Performance(seed=seed)
        for at, inten, sp in cues:
            p.add(name, at=at, intensity=inten, speed=sp)

        def fn(u, t):
            ctl, mph = p.solve(t)
            return merge(idle(t, seed * 0.37), ctl), {}, mph
        return fn

    s2 = Shot(
        "surprise", 4.2,
        "הפתעה = גבות + פקיחת עיניים + לסת + מבט + ראש",
        "שבע יחידות תנועה, כל אחת בהשהיה אחרת · עלייה חדה, החזקה קצרה",
        "קומבינציה עם תזמון פנימי, לא ביטוי אטומי",
        cam2, sec_strength=0.7, vis={"A": True, "B": False},
        a=perf("surprise", 0.0, cues=((0.35, 1.0, 1.0), (2.20, 0.72, 0.85))),
    )

    # --- 3. חשד: אסימטריה + תגובה מאוחרת
    def cam3(u):
        return {"yaw": _ar(16, -6, u), "pitch": _ar(-1, 3, u),
                "dist": _ar(0.88, 0.70, u), "tx": -0.53, "ty": 1.588,
                "tz": 0.02, "fov": 30}

    s3 = Shot(
        "suspicion", 5.0,
        "חשד = גבות אסימטריות + צמצום + הטיה + תגובה מאוחרת",
        "גבה שמאל עולה, ימין יורדת · הראש נוטה רק 0.35 שנייה אחר כך",
        "אסימטריה והשהיה כפרמטרים, לא כאפקט",
        cam3, sec_strength=0.6, vis={"A": True, "B": False},
        a=perf("suspicion", 1.0, cues=((0.30, 1.0, 1.0), (2.40, 0.85, 1.1))),
    )

    # --- 4. עצב: גבה פנימית ותנועה איטית
    def cam4(u):
        return {"yaw": _ar(-10, 8, u), "pitch": _ar(4, -1, u),
                "dist": _ar(0.80, 0.68, u), "tx": 0.53, "ty": 1.578,
                "tz": 0.02, "fov": 30}

    s4 = Shot(
        "sadness", 6.0,
        "עצב = גבה פנימית + עין מוצרת + שפתיים דחוסות + ראש מורד",
        "מהירות 0.55: אותה עקומה בדיוק, פי שניים זמן · ואף אחד מהחלקים לא לבד",
        "תנועה איטית כפרמטר מדיד, והרמת גבה פנימית בלבד",
        cam4, sec_strength=0.5, vis={"A": False, "B": True},
        b=perf("sadness", 2.0, cues=((0.25, 1.0, 1.0),)),
    )

    # --- 5. אותה יחידת פה, שני ביטויים שונים לגמרי
    def cam5(u):
        return {"yaw": _ar(-22, 20, u), "pitch": _ar(3, 6, u),
                "dist": _ar(2.05, 1.80, u), "ty": 1.56, "fov": 30}

    pa = acting.Performance(seed=3.0)
    pb = acting.Performance(seed=4.0)
    for _at, _in in ((0.40, 1.0), (2.30, 0.85)):
        pa.add("polite_smile", at=_at, intensity=_in)
        pb.add("amusement", at=_at, intensity=_in)

    def five_a(u, t):
        ctl, mph = pa.solve(t)
        return merge(idle(t, 0.0), ctl), {}, mph

    def five_b(u, t):
        ctl, mph = pb.solve(t)
        return merge(idle(t, 0.37), ctl), {}, mph

    s5 = Shot(
        "duchenne", 4.6,
        "אותה זווית פה · הלחי היא ההבדל",
        "לוקאס: פה בלבד - נקרא כחיוך מנומס · מאיה: פה + לחי + עפעף - חיוך אמיתי",
        "ההוכחה שביטוי הוא קומבינציה: הורדת יחידה אחת משנה את המשמעות",
        cam5, a=five_a, b=five_b, sec_strength=0.7,
        labels={"a": "פה בלבד", "b": "פה + לחי + עפעף", "y": 1.86},
    )

    # --- 6. ערבוב: ביטוי שנכנס לתוך ביטוי
    def cam6(u):
        return {"yaw": _ar(8, -14, u), "pitch": _ar(1, 4, u),
                "dist": _ar(0.90, 0.72, u), "tx": 0.53, "ty": 1.585,
                "tz": 0.02, "fov": 30}

    p6 = acting.Performance(seed=5.0)
    p6.add("doubt", at=0.3, intensity=0.9)
    p6.add("realization", at=2.5, intensity=1.0)
    p6.add("amusement", at=3.9, intensity=0.85)

    def six_b(u, t):
        ctl, mph = p6.solve(t)
        return merge(idle(t, 0.37), ctl), {}, mph

    s6 = Shot(
        "blend", 6.4,
        "שלושה ביטויים חופפים: ספק → הבנה → שעשוע",
        "הם לא מחליפים זה את זה · הם מתערבבים, והשרירים הנגדיים מתקזזים",
        "ערבוב ביטויים בו-זמנית, עם קיזוז אנטגוניסטים",
        cam6, b=six_b, sec_strength=0.6, vis={"A": False, "B": True},
    )

    # --- 7. אסימטריה ומהירות כמחוגים
    def cam7(u):
        return {"yaw": _ar(-6, 6, u), "pitch": 1.0,
                "dist": 0.72, "tx": -0.53, "ty": 1.585, "tz": 0.02, "fov": 30}

    def seven_a(u, t):
        """אותו ביטוי בדיוק, והמחוגים זזים מול העיניים: ההטיה עוברת
        מימין לשמאל, והמהירות מואטת."""
        bias = math.sin(2 * math.pi * u)
        sp = 1.5 - 1.0 * u
        e = acting.EXPRESSIONS["contempt"].scaled(0.95, sp, 0.0)
        ctl, mph = acting.pose_of(e, t=acting.apex_time(e), bias=bias)
        return merge(idle(t, 0.0), ctl), {}, mph

    s7 = Shot(
        "dials", 5.0,
        "אסימטריה ומהירות הן מחוגים, לא תקלות",
        "אותו ביטוי · ההטיה עוברת מצד לצד, והתנועה מואטת פי שלושה",
        "bias ו-speed משנים את אותו ביטוי בזמן אמת",
        cam7, a=seven_a, sec_strength=0.5, vis={"A": True, "B": False},
    )

    return [s1, s2, s3, s4, s5, s6, s7]


# ------------------------------- סצנות TASK 04 (משמעות ומשחק עיניים)
#
# **זו הסצנה שלא נכנסה ב-TASK 03.** מנוע הרגש נבנה ונבדק, אבל סצנות
# הסרטון המשיכו לקרוא ל-`acting.EXPRESSIONS["sadness"]` ישירות - כלומר
# הן המשיכו לבצע *הבעה* ולא *משמעות*. כאן כל סצנה מתחילה מ-`Situation`
# (מה היא יודעת / רוצה / מרגישה / מסתירה / במי מסתכלת / מה השתנה),
# והפנים, הגוף, המחווה, התזמון והמבט **נגזרים** ממנה.
#
# וההוכחה הנראית: הכתובית מראה את המשפט שנאמר ואת המשמעות שמתחתיו,
# ואת שם הכוונה שהמנוע בחר. אם הדמות הייתה מבצעת את הדיאלוג ולא את
# המשמעות, הכתובית הייתה סותרת את מה שרואים.


def _emotion_actor(sit, seed: float, phase: float,
                   speech: tuple = (), reacts: tuple = (),
                   hesitate: tuple = (), line: str | None = None,
                   delivery=None, voice: str = "", body: bool = False):
    """(פונקציית סצנה, שחקן העיניים) למצב נתון.

    שחקן העיניים **ושחקן הדיבור** נבנים פעם אחת ולא בכל פריים:
    התוכנית שלהם (רצף נקודות המבט, רצף הפונמות, הנשימות) חייבת
    להיות זהה בכל הפריימים, אחרת בכל פריים נבנה שוט אחר - המבט
    קופץ והפה מקרטע.

    **TASK 05.** עד כאן הפה הונע מכאן בגל סינוס אחד (`_talk`), בלי
    קשר למה שנאמר ובלי קשר לרגש. במקומו `rig.speech`: המשפט של
    הסצנה (`sit.line`) מפוענח לפונמות, הפונמות לויזמות, וההגשה
    נגזרת מאותו `Situation` שממנו נגזרים הפנים - ולכן דמות שמסתירה
    משהו גם *מדברת* שקט ובשפתיים לחוצות.
    """
    from rig import emotion as E                     # noqa: PLC0415
    from rig import speech as S                      # noqa: PLC0415
    eye = E.eye_actor(sit, seed=seed, speech=speech, reacts=reacts)
    txt = line if line is not None else sit.line
    # **TASK 06 - הקול האמיתי.** `voice.load` קורא מהדיסק בלבד ולא
    # פונה לרשת: הוא נקרא מתוך בניית השוט, ובקשת רשת שם הייתה
    # הופכת רנדור של אלפי פריימים לבלתי אפשרי (הלקח של `need_credit`
    # מ-23/09). אין הקלטה -> `track=None` והמסלול הישן ממשיך לעבוד.
    track = None
    if voice and speech:
        from rig import voice as V                   # noqa: PLC0415
        track = V.load(txt, voice)
    spk = None
    if speech:
        spk = S.SpeechActor(txt, speech, delivery or S.voice_from(sit),
                            seed=seed, hesitate=hesitate, track=track)
    #: שחקן הגוף נבנה פעם אחת, מאותה סיבה בדיוק: בחירת המחוות
    #: וחלוקת המשקל חייבות להיות זהות בכל פריים.
    bod = None
    if body:
        from rig import body as B                    # noqa: PLC0415
        win = spk.windows if spk is not None else speech
        bod = B.actor_for(sit, seed=seed, speech=win, line=txt, track=track)

    def fn(u, t):
        ctl, mph = E.solve(sit, t, seed=seed, eye=eye)
        base = idle(t, phase)
        # תנועת המנוחה נוספת ל**גוף** ולראש, ואינה דורסת את מה שהמנוע
        # ומערכת העיניים קבעו. merge לבדו היה מוחק את סיבוב הראש
        # שנגזר מהמבט, ואז "הראש מאחר אחרי העיניים" נעלם מהתמונה.
        for k in ("head_yaw", "head_pitch", "head_roll",
                  "spine_side", "spine_twist", "hips_roll"):
            ctl[k] = ctl.get(k, 0.0) + base.get(k, 0.0) * 0.45
        if spk is not None:
            r = spk.raw(t)
            for k, v in r["ctl"].items():
                ctl[k] = ctl.get(k, 0.0) + v
            for k, v in r["mph"].items():
                mph[k] = mph.get(k, 0.0) + v
            # --- TASK 07 · Squash & Stretch, במקום היחיד שבו הוא
            #     מתאים לדמות אנושית: הפנים. לסת שנפתחת מותחת את
            #     הפנים לגובה, ושימור נפח מחייב שהלחיים יישאבו
            #     פנימה באותו שיעור בדיוק. בלי זה פה פתוח נראה
            #     כאילו הראש **גדל**, וזה הכשל הקלאסי של ריג
            #     סיבובי בלי קנה מידה.
            from rig import principles as P           # noqa: PLC0415
            for k, v in P.face_squash(ctl.get("jaw_open", 0.0)).items():
                mph[k] = mph.get(k, 0.0) + v
            # finalize חוזר **אחרי** חיבור הדיבור, ולא לפניו. בלעדיו
            # "פינת פה למעלה" מהחיוך שבדיבור ו"פינת פה למטה" מהעצב
            # שמתחתיו מתחברות לעיוות במקום להתקזז - וזה בדיוק המצב
            # בסצנה של עצב מוסתר, שבה שתיהן פעילות באותו רגע.
            ctl, mph = acting.finalize(ctl, mph)
        # --- מחוות הידיים הן **תוספת לפוזת המנוחה**, לא ערך מוחלט.
        # זה נתפס ברנדור: `_GESTURE_SHAPE` מחזיר arm_down=-0.30 כהיסט,
        # ו-merge רגיל דרס איתו את arm_down=0.93 של העמידה - התוצאה
        # הייתה יד שמורמת אופקית הצידה כמו מחסום חניה, באמצע סצנה
        # שבה הדמות אמורה רק לעמוד.
        out = dict(base)
        for k, v in ctl.items():
            if k.startswith(("arm_", "elbow_", "spread_", "wrist_",
                             "curl_", "fist")):
                out[k] = base.get(k, 0.0) + v
            else:
                out[k] = v
        # --- TASK 06: הגוף המלא. הוא **דורס** את בקרות היציבה
        # (משקל, כתפיים, רגליים) ו**מוסיף** למחוות הידיים, בדיוק
        # כמו שהדיבור מוסיף לפה. הסיבה לפיצול זהה: חלוקת משקל היא
        # מצב מוחלט של הגוף, ומחווה היא היסט על פוזת המנוחה.
        if bod is not None:
            for k, v in bod.solve(t).items():
                if k == "breath":
                    # **ממוצע ולא סכום.** שני המודולים מעריכים את
                    # *אותו* גודל פיזי - התפשטות בית החזה: `emotion`
                    # מהרגש (עומק וקצב), ו-`BodyActor` מהיציבה
                    # (פתיחת חזה ומתח בכתפיים). חיבור שני אמדנים של
                    # אותו גודל, כששניהם בטווח המלא, מוציא אותו
                    # מהטווח: נמדד 05/10 שאצל מאיה הסכום מגיע ל-1.211
                    # ולכן **28% מהפריימים נקטמים על 1.0** - כלומר
                    # בית החזה שלה נעצר בשיא כל נשימה ולא זז. ממוצע
                    # הוא מה שעושים לשני אמדנים, והוא גם מה שמשאיר
                    # מרווח לנשימה התגובתית של TASK 10.
                    out[k] = 0.5 * (out.get(k, 0.0) + v)
                elif k in ("spine_side", "spine_twist", "spine_bend",
                           "head_roll"):
                    # הגוף **מוסיף** לעמוד השדרה ולראש ולא דורס אותם:
                    # שם כבר יושבת שפת הגוף הרגשית מ-TASK 03, ודריסה
                    # הייתה מוחקת אותה.
                    out[k] = out.get(k, 0.0) + v
                else:
                    # כל השאר **נדרס**, וזה מכוון: `BodyActor.solve`
                    # כבר מחזיר מנוחה + מחווה מחוברות יחד. חיבור כאן
                    # היה מכפיל את פוזת הזרועות על זו של `idle` ויוצא
                    # מחוץ לטווח - נתפס בפריים הראשון שרונדר.
                    out[k] = v
        return out, {}, mph
    #: שחקן הדיבור נחשף על הפונקציה כדי שהסצנה תוכל להציג **למה**
    #: הפה עושה את מה שהוא עושה, בזמן אמת. בלי זה "יש כאן נשימה
    #: ובליעה" היא טענה שאי אפשר לראות בפריים אחד.
    fn.speech = spk
    fn.body = bod
    fn.track = track
    return fn, eye


def _speech_cap(fn, secs: float):
    """כתובית שמראה מה הפה עושה ברגע זה: הגייה, פאוזה או אירוע."""
    spk = getattr(fn, "speech", None)

    def cap(u: float) -> str:
        t = u * secs
        if spk is None:
            return ""
        for e in spk.events:
            if e.at <= t <= e.at + e.dur:
                return {"breath": "נשימה — לפני שהיא מתחילה",
                        "swallow": "בליעה — בפאוזה",
                        "hesitation": "היסוס — «אֶה…»",
                        "react": "תגובה בלי מילים"}.get(e.kind, e.kind)
        if not spk.speaking(t):
            return "שקט"
        near = min(spk.phones, key=lambda p: abs(p.at - t), default=None)
        if near is None:
            return "שקט"
        if near.kind == "pause":
            return "פאוזה בתוך המשפט"
        from rig import speech as S                   # noqa: PLC0415
        return f"הגייה · {S.VISEMES[near.vis].note.split('·')[0].strip()}"
    return cap


def _why_at(eye, secs: float):
    """כתובית שמראה **למה** המבט נמצא איפה שהוא נמצא, בזמן אמת."""
    from rig import eyes as EY                       # noqa: PLC0415

    def cap(u: float) -> str:
        t = u * secs
        f = eye.fixes[eye._idx(t)]
        heb = {"partner": "בבן השיח", "away": "הצידה", "away2": "הצידה",
               "down": "מטה", "object": "על העצם", "inward": "פנימה",
               "audience": "אל המצלמה", "hands": "על הידיים",
               "mouth": "על הפה"}
        return f"מביטה {heb.get(f.key, f.key)} · {EY.REASONS.get(f.reason, '')}"
    return cap


def build_shots_emotion(h: float) -> list[Shot]:
    """ציר הזמן של TASK 04. ארבע סצנות של **משמעות** (מנוע הרגש מניע
    את הסצנה) ושלוש סצנות של **עיניים** (משחק עיניים כמערכת)."""
    from dataclasses import replace as _rep          # noqa: PLC0415
    from rig import emotion as E                     # noqa: PLC0415

    def sit(name, secs, **kw):
        return _rep(E.SCENES[name], shot_len=secs, **kw)

    def says_means(s, intention_he=True):
        p = E.plan(s)
        def cap(u):
            if u < 0.46:
                return f"אומרת: «{s.line}»"
            if u < 0.78:
                return f"מתכוונת: {p.subtext}"
            return f"כוונה: {E.INTENTIONS[p.intention].split('.')[0]}"
        return cap

    # --- 1. אומרת דבר אחד ומתכוונת לאחר: מסכה ונזילה
    s_hide = sit("עצב-מוסתר", 6.4)
    sp1 = ((1.50, 3.10), (4.30, 5.60))
    fb1, eye1 = _emotion_actor(s_hide, 2.0, 0.37, speech=sp1)

    def cam1(u):
        return {"yaw": lerp(-18, 10, u), "pitch": lerp(2, -2, u),
                "dist": lerp(0.80, 0.66, u), "tx": 0.53, "ty": 1.566,
                "tz": 0.02, "fov": 30}

    s1 = Shot(
        "meaning", 6.4,
        "אומרת דבר אחד, מתכוונת לאחר",
        "מסכה על הפה (נשלט) ונזילה בגבות ובעפעפיים (לא נשלט) - בבת אחת",
        "הסצנה נבנית מ-Situation: feels=neutral, hides=sadness",
        cam1, b=fb1, sec_strength=0.5, vis={"A": False, "B": True},
        caption_of=says_means(s_hide),
    )

    # --- 2. אותו משפט, פער ידע הפוך -> שתי הופעות שונות לגמרי
    s_more = sit("יודעת-יותר", 6.0)
    s_less = sit("לא-מבינה", 6.0)
    fa2, _ = _emotion_actor(s_more, 1.0, 0.0, speech=((0.80, 2.00),))
    fb2, _ = _emotion_actor(s_less, 3.0, 0.37, speech=((2.60, 4.10),),
                            reacts=((2.05, 1.0),))

    def cam2(u):
        return {"yaw": lerp(-16, 14, u), "pitch": lerp(3, 6, u),
                "dist": lerp(2.45, 2.10, u), "ty": 1.50, "fov": 30}

    s2 = Shot(
        "knowing", 6.0,
        "אותו משפט · «נו? מה קרה שם?»",
        "לוקאס יודע ושותק - מבט ישר, מעט תנועה · מאיה לא יודעת - מבט נע, מחווה",
        "knows_more=+0.9 מול -0.9: אותו דיאלוג, כוונה הפוכה",
        cam2, a=fa2, b=fb2, sec_strength=0.8,
        labels={"a": "יודע יותר", "b": "לא מבינה", "y": 1.86},
    )

    # --- 3. מפנה רגשי בתוך השוט: הבנה -> כעס
    s_turn = sit("הבנה-לכעס", 5.8)
    arc3 = E.arc(s_turn)
    fa3, _ = _emotion_actor(s_turn, 0.0, 0.0, speech=((0.70, 2.30),),
                            reacts=((arc3.turn - 0.45, 1.0),))

    def cam3(u):
        return {"yaw": lerp(20, -12, u), "pitch": lerp(-1, 4, u),
                "dist": lerp(0.84, 0.66, u), "tx": -0.53, "ty": 1.598,
                "tz": 0.02, "fov": 30}

    s3 = Shot(
        "turn", 5.8,
        "מה השתנה רגשית בשוט: הבנה → כעס",
        f"המפנה בשנייה {arc3.turn:.1f} · זמן המעבר נגזר מהפער באנרגיה, לא נקבע ביד",
        "change='realization->anger': שתי תוכניות ונקודת מפנה",
        cam3, a=fa3, sec_strength=0.9, vis={"A": True, "B": False},
        caption_of=lambda u, _a=arc3: (
            "הבנה — מעבד את מה שנאמר" if u * 5.8 < _a.turn
            else "כעס — ועכשיו הוא יודע את מי להאשים"),
    )

    # --- 4. לעצור צחוק: המסכה היא עצירה, לא חיוך
    s_laugh = sit("צחוק-שנעצר", 4.8)
    fb4, _ = _emotion_actor(s_laugh, 4.0, 0.37, speech=((1.10, 2.20),))

    def cam4(u):
        return {"yaw": lerp(10, -16, u), "pitch": lerp(1, 3, u),
                "dist": lerp(0.76, 0.64, u), "tx": 0.53, "ty": 1.564,
                "tz": 0.02, "fov": 30}

    s4 = Shot(
        "held_laugh", 4.8,
        "מסתירה צחוק - והמסכה היא לחיצת שפתיים",
        "hides=amusement · הפה נעצר, והלחיים עולות בכל זאת. זו הנזילה",
        "המסכה נבחרת לפי מה שאנשים עושים, ולא כהיפוך מתמטי של הרגש",
        cam4, b=fb4, sec_strength=0.5, vis={"A": False, "B": True},
        caption_of=says_means(s_laugh),
    )

    # --- 5. העיניים כמערכת: תקריב קצר על העיניים בלבד
    s_eye = sit("עצב-מוסתר", 7.0)
    fb5, eye5 = _emotion_actor(s_eye, 5.0, 0.37, speech=((2.40, 3.90),),
                               reacts=((5.10, 1.0),))

    def cam5(u):
        return {"yaw": lerp(-9, 7, u), "pitch": lerp(1, -1, u),
                "dist": lerp(0.62, 0.54, u), "tx": 0.53, "ty": 1.578,
                "tz": 0.02, "fov": 28}

    s5 = Shot(
        "eye_acting", 7.0,
        "משחק עיניים: הסטה · הקדמה · ריצוד · מיקוד · מצמוץ נגרר",
        "אורך הסקאדה נגזר ממשרעתה · הראש מאחר אחרי העיניים · העפעפיים אינם זהים",
        "11 יכולות העיניים על תקריב של מאיה, עם כתובית שמראה למה",
        cam5, b=fb5, sec_strength=0.35, vis={"A": False, "B": True},
        caption_of=_why_at(eye5, 7.0),
    )

    # --- 6. אחד מחזיק מבט, השנייה שוברת אותו
    s_hold = _rep(E.Situation(knows="שהוא צודק", wants="שתודה",
                              feels="suspicion", looks_at="partner",
                              knows_more=0.8, want_strength=0.7,
                              line="אני מחכה."), shot_len=6.0)
    s_break = _rep(E.Situation(knows="שהיא טעתה", wants="לא להיות מול זה",
                               feels="shame", looks_at="partner",
                               hides="guilt", want_strength=0.9,
                               line="אני לא יודעת מה לומר."), shot_len=6.0)
    fa6, eye6a = _emotion_actor(s_hold, 6.0, 0.0)
    fb6, eye6b = _emotion_actor(s_break, 7.0, 0.37, speech=((2.80, 4.20),))

    def cam6(u):
        return {"yaw": lerp(-12, 10, u), "pitch": lerp(2, 1, u),
                "dist": lerp(2.30, 2.00, u), "ty": 1.50, "fov": 30}

    s6 = Shot(
        "eye_contact", 6.0,
        "אחד מחזיק מבט · השנייה שוברת אותו",
        "לוקאס: control גבוה, נעיצה ארוכה, מצמוץ מדוכא · מאיה: מורידה מבט, חוזרת לבדוק",
        "הישירות וזמן ההחזקה נגזרים מהרגש, ולכן שני המבטים הפוכים",
        cam6, a=fa6, b=fb6, sec_strength=0.6,
        labels={"a": "מחזיק מבט", "b": "שוברת מבט", "y": 1.84},
    )

    # --- 7. הדיבור אינו מפעיל את העיניים
    s_talk = _rep(E.Situation(knows="בדיוק מה קרה", wants="להסביר",
                              feels="doubt", looks_at="partner",
                              want_strength=0.7,
                              line="זה לא היה ככה בכלל."), shot_len=7.2)
    sp7 = ((1.20, 2.55), (3.40, 4.60), (5.40, 6.80))
    fb7, eye7 = _emotion_actor(s_talk, 6.0, 0.37, speech=sp7)

    def cam7(u):
        return {"yaw": lerp(14, -10, u), "pitch": 1.0,
                "dist": lerp(0.74, 0.62, u), "tx": 0.53, "ty": 1.570,
                "tz": 0.02, "fov": 30}

    def cap7(u):
        t = u * 7.2
        talking = any(a <= t <= b for a, b in sp7)
        f = eye7.fixes[eye7._idx(t)]
        pre = f.reason == "pre_speech"
        return ("מדברת" if talking else "שותקת") + \
            (" · והמבט עזב עוד לפני שהתחילה" if pre else
             " · והמבט רץ בקצב שלו")

    s7 = Shot(
        "eye_vs_speech", 7.2,
        "המבט אינו מסונכרן לדיבור",
        "שלוש פעמים היא מסיטה מבט **לפני** שהיא מדברת · ובאמצע המשפט המבט נח",
        "קורלציה מתחת ל-0.25 בין מהירות העין לעוצמת הדיבור - נמדד, לא מוצהר",
        cam7, b=fb7, sec_strength=0.5, vis={"A": False, "B": True},
        caption_of=cap7,
    )

    # --- 8. TASK 05: הפה כהופעה · פאוזה, היסוס, נשימה, בליעה
    #
    # **זו הסצנה שמחליפה את הליפ-סינק המכני בתמונה.** עד כאן הפה
    # הונע מגל סינוס אחד: הוא נפתח ונסגר באותו קצב מתחילת החלון ועד
    # סופו, ולא היה בו אף רגע של שקט. כאן הוא מונע מרצף הפונמות של
    # המשפט בפועל, והכתובית מראה בכל רגע מה הפה עושה - הגייה, פאוזה,
    # נשימה, בליעה או היסוס.
    s_sp = _rep(E.Situation(knows="שהיא אמרה יותר ממה שרצתה",
                            wants="לחזור אחורה", feels="discomfort",
                            looks_at="partner", hides="shame",
                            want_strength=0.8,
                            line="לא התכוונתי שזה יישמע ככה."),
                shot_len=8.6)
    sp8 = ((0.90, 2.60), (3.70, 5.50), (7.00, 8.30))
    fb8, _eye8 = _emotion_actor(s_sp, 8.0, 0.37, speech=sp8, hesitate=(1,))

    def cam8(u):
        return {"yaw": lerp(-7, 9, u), "pitch": lerp(-3, -5, u),
                "dist": lerp(0.60, 0.50, u), "tx": 0.53, "ty": 1.542,
                "tz": 0.02, "fov": 28}

    s8 = Shot(
        "speech_perf", 8.6,
        "הפה מונע מפונמות ומהופעה — לא מגל סינוס",
        "פאוזות בתוך המשפט · נשימה לפני כל חלון · בליעה בפאוזה · היסוס «אֶה»",
        "קורלציית פתיחת הלסת מול הסינוס הטוב ביותר יורדת מ-0.92 ל-0.45",
        cam8, b=fb8, sec_strength=0.35, vis={"A": False, "B": True},
        caption_of=_speech_cap(fb8, 8.6),
    )

    # --- 9. אותו משפט, שתי הגשות: כועס בקול · עצובה בשקט
    #
    # ההוכחה שההגשה אינה קוסמטיקה: אותן פונמות בדיוק, אותו תזמון
    # חלון, ושני פרצופים שונים לגמרי. בכעס פתיחת הפה חדה, השפתיים
    # לחוצות בין ההגיות והאף מתרחב; בעצב הפתיחה יורדת ל-62% והפינות
    # נופלות **תוך** הדיבור.
    from rig import speech as S                      # noqa: PLC0415
    same = "אמרתי לך שזה יקרה."
    s_ang = _rep(E.Situation(knows="שהוא הזהיר", wants="שיודו שטעו",
                             feels="anger", looks_at="partner",
                             knows_more=0.9, want_strength=0.9,
                             line=same), shot_len=6.4)
    s_sadv = _rep(E.Situation(knows="שאיש לא הקשיב", wants="שזה ייגמר",
                              feels="sadness", looks_at="down",
                              want_strength=0.5, line=same), shot_len=6.4)
    sp9 = ((1.00, 2.70), (4.00, 5.60))
    fa9, _e9a = _emotion_actor(s_ang, 9.0, 0.0, speech=sp9,
                               delivery=S.Delivery(emotion="anger",
                                                   loudness=1.15, rate=1.1,
                                                   tension=0.5))
    fb9, _e9b = _emotion_actor(s_sadv, 10.0, 0.37, speech=sp9,
                               delivery=S.Delivery(emotion="sadness",
                                                   loudness=0.34, rate=0.8))

    def cam9(u):
        return {"yaw": lerp(-13, 11, u), "pitch": lerp(2, 4, u),
                "dist": lerp(2.35, 1.98, u), "ty": 1.52, "fov": 30}

    s9 = Shot(
        "delivery", 6.4,
        f"אותו משפט · «{same}»",
        "לוקאס בכעס: פתיחה חדה, שפתיים לחוצות, אף מתרחב · "
        "מאיה בשקט ובעצב: הפה כמעט לא נפתח",
        "אותן פונמות, אותו תזמון - ההגשה היא מה שמשתנה, ולכן הפה שונה",
        cam9, a=fa9, b=fb9, sec_strength=0.7,
        labels={"a": "כועס · בקול", "b": "עצובה · בשקט", "y": 1.86},
    )

    return [s1, s2, s3, s4, s5, s6, s7, s8, s9]


def build_shots_body(h: float) -> list[Shot]:
    """ציר הזמן של TASK 06 - משחק גוף מלא וקול אמיתי.

    כל סצנה כאן מוכיחה **דבר אחד שלא היה אפשרי קודם**, ולכל אחת
    כתובית שאומרת מה בדיוק לראות. סצנה שאי אפשר לאמת בעין היא
    הדגמה ולא הוכחה.
    """
    from dataclasses import replace as _rep          # noqa: PLC0415
    from rig import body as B                        # noqa: PLC0415
    from rig import emotion as E                     # noqa: PLC0415

    def sit(name, secs, **kw):
        return _rep(E.SCENES[name], shot_len=secs, **kw)

    out: list[Shot] = []

    # --- 1. חלוקת משקל: אותה דמות, אותו רגש, שתי רגליים
    s_w = sit("יודעת-יותר", 8.6)
    # **הזמנים מרווחים לפי אורך ההקלטה ולא לפי החלון שהוצהר.**
    # הקלטה אמיתית ארוכה מהחלון המומצא (3.3ש מול 1.6), ובגרסה
    # הראשונה שני הקולות חפפו - שתי דמויות שאומרות את אותו משפט
    # באותה שנייה נשמעות כמו הד, לא כמו דיאלוג. נמדד בפס הקול.
    fa1, _ = _emotion_actor(s_w, 0.0, 0.0, speech=((0.8, 2.4),),
                            voice="hila", body=True)
    fb1, _ = _emotion_actor(s_w, 1.0, 0.31, speech=((4.7, 6.3),),
                            voice="avri", body=True)

    def cam1(u):
        # המרחק והגובה כאן נקבעו אחרי שתמונת הבדיקה הראשונה החזירה
        # דמות עם ראש חתוך: ב-`ty = h*0.56` המצלמה מכוונת למותניים,
        # ובמרחק 2.7 מטר הדמות גדולה מהפריים. מסגור של גוף מלא דורש
        # גובה יעד סביב החזה ומרחק של כ-3 מטר.
        return {"yaw": lerp(-20, 18, u), "pitch": lerp(4, 6, u),
                "dist": lerp(3.25, 2.95, u), "ty": h * 0.70, "fov": 30}

    def cap1(u, _a=fa1, _b=fb1):
        t = u * 8.6
        wa = _a.body.weight_at(t) if _a.body else 0.0
        wb = _b.body.weight_at(t) if _b.body else 0.0
        def leg(w):
            return "ימין" if w > 0.12 else ("שמאל" if w < -0.12 else "שתיהן")
        return (f"משקל: שמאלית על {leg(wa)} · ימני על {leg(wb)} — "
                "ואחד מהם מחליף רגל באמצע")

    out.append(Shot(
        "weight", 8.6, "חלוקת משקל — אף אחד לא עומד על שתי רגליים שוות",
        "האגן מוטה, העמוד מתקזז, הכתפיים מתקזזות הפוך, הראש נשאר באופק",
        "body.Stance.weight מזין את כל שרשרת ה-contrapposto",
        cam1, a=fa1, b=fb1, sec_strength=0.55,
        vis={"A": True, "B": True}, caption_of=cap1))

    # --- 2. שרשרת העברת המשקל: מי מגיע ראשון ומי אחרון
    s_c = sit("לא-מבינה", 6.0)
    fb2, _ = _emotion_actor(s_c, 3.0, 0.0, speech=((1.2, 2.9),),
                            voice="hila", body=True)

    def cam2(u):
        # `tx` הוא **חובה** בסצנה של דמות אחת: הדמויות עומדות
        # ב-x=±0.53, והמצלמה בלי tx מביטה למרכז הריק ביניהן - הדמות
        # יוצאת נדחקת לקצה הפריים. נתפס בתמונת הבדיקה הראשונה.
        return {"yaw": lerp(26, -8, u), "pitch": lerp(2, 5, u),
                "dist": lerp(2.45, 2.00, u), "tx": 0.53,
                "ty": h * 0.66, "fov": 30}

    def cap2(u, _b=fb2):
        t = u * 6.0
        c = _b.body.solve(t) if _b.body else {}
        return (f"אגן {c.get('hips_shift', 0):+.2f} → "
                f"עמוד {c.get('spine_side', 0):+.2f} → "
                f"כתף {c.get('shoulder_up_R', 0):+.2f} → "
                f"ראש {c.get('head_roll', 0):+.2f} — כל חוליה מאחרת")

    out.append(Shot(
        "chain", 6.0, "שרשרת הגוף — האגן מוביל, הראש מגיע אחרון",
        "זה מה שהופך העברת משקל לתנועה ולא להחלפת פוזה",
        "body._lag עם עיכוב עולה לאורך השרשרת",
        cam2, b=fb2, sec_strength=0.6,
        vis={"A": False, "B": True}, caption_of=cap2))

    # --- 3. מחווה עם סיבה סמנטית, בארבע פאזות
    s_g = sit("לא-מבינה", 7.0, want_strength=0.95)
    fb3, _ = _emotion_actor(s_g, 5.0, 0.0, speech=((1.4, 3.1),),
                            voice="hila", body=True)

    def cam3(u):
        return {"yaw": lerp(-12, 16, u), "pitch": lerp(3, 2, u),
                "dist": lerp(1.95, 1.55, u), "tx": 0.53,
                "ty": h * 0.70, "fov": 30}

    def cap3(u, _b=fb3):
        return _b.body.describe(u * 7.0) if _b.body else ""

    out.append(Shot(
        "gesture", 7.0, "מחווה שיש לה סיבה — ולא ניפנוף",
        "הכנה → הדגשה → החזקה → חזרה, וההדגשה נופלת על המילה",
        "Gesture בלי reason זורק GestureError בבנייה",
        cam3, b=fb3, sec_strength=0.7,
        vis={"A": False, "B": True}, caption_of=cap3))

    # --- 4. אותה כוונה, שתי עוצמות רצון: גודל המחווה נגזר מהדחף
    s_lo = sit("לא-מבינה", 8.4, want_strength=0.15)
    s_hi = sit("לא-מבינה", 8.4, want_strength=1.0)
    # ברצף ולא בבת אחת: אותו משפט בשני קולות זהים באותה שנייה הוא
    # הכפלת עוצמה, לא השוואה. ההשוואה נראית דווקא כשהיא עוקבת.
    fa4, _ = _emotion_actor(s_lo, 0.0, 0.0, speech=((0.7, 2.4),),
                            voice="hila", body=True)
    fb4, _ = _emotion_actor(s_hi, 1.0, 0.0, speech=((4.6, 6.3),),
                            voice="hila", body=True)

    def cam4(u):
        return {"yaw": lerp(-14, 12, u), "pitch": 5,
                "dist": lerp(3.10, 2.85, u), "ty": h * 0.70, "fov": 30}

    g_lo = fa4.body.gestures if fa4.body else []
    g_hi = fb4.body.gestures if fb4.body else []
    out.append(Shot(
        "drive", 8.4, "אותה כוונה · רצון חלש מול רצון חזק",
        f"מחווה {g_lo[0].amount if g_lo else 0:.2f} מול "
        f"{g_hi[0].amount if g_hi else 0:.2f} — אותה צורה, דחף אחר",
        "gestures_for משקלל want_strength ו-arousal",
        cam4, a=fa4, b=fb4, sec_strength=0.55,
        vis={"A": True, "B": True},
        labels={"a": "רצון חלש", "b": "רצון חזק", "y": 1.86}))

    # --- 5. הסתרה מקפיאה את הגוף (ההפך האינטואיטיבי)
    s_h = sit("עצב-מוסתר", 8.2)
    s_o = sit("עצב-גלוי", 8.2)
    fa5, _ = _emotion_actor(s_o, 0.0, 0.0, speech=((0.8, 2.6),),
                            voice="hila", body=True)
    fb5, _ = _emotion_actor(s_h, 1.0, 0.0, speech=((4.5, 6.3),),
                            voice="hila", body=True)

    def cam5(u):
        return {"yaw": lerp(10, -14, u), "pitch": 5,
                "dist": lerp(3.05, 2.80, u), "ty": h * 0.70, "fov": 30}

    sw_o = fa5.body.stance.sway if fa5.body else 0.0
    sw_h = fb5.body.stance.sway if fb5.body else 0.0
    out.append(Shot(
        "hold", 8.2, "הסתרה ממעיטה בתנועה — לא מרבה בה",
        f"נדנוד {sw_o:.2f} בעצב גלוי מול {sw_h:.2f} במוסתר",
        "stance_for: hides מקטין sway ומעלה מתח בכתפיים",
        cam5, a=fa5, b=fb5, sec_strength=0.5,
        vis={"A": True, "B": True},
        labels={"a": "עצב גלוי", "b": "עצב מוסתר", "y": 1.86}))

    # --- 6. הקול האמיתי: הפה נע לפי מה שנשמע
    s_v = sit("מודה-ולא-אומרת", 6.6)
    fb6, _ = _emotion_actor(s_v, 2.0, 0.0, speech=((1.2, 3.0),),
                            voice="hila", body=True)

    def cam6(u):
        return {"yaw": lerp(8, -10, u), "pitch": lerp(1, 3, u),
                "dist": lerp(0.80, 0.66, u), "tx": 0.53,
                "ty": 1.566, "tz": 0.02, "fov": 30}

    def cap6(u, _b=fb6):
        t = u * 6.6
        tr = _b.track
        if tr is None:
            return "אין הקלטה — הפה נופל למסלול הישן"
        rel = t - 1.2
        v, e = tr.viseme_at(rel) if rel >= 0 else ("sil", 0.0)
        heb = {"a": "אַ", "e": "אֶ", "i": "אִ", "o": "אוֹ", "u": "אוּ",
               "s": "ס/שׁ", "f": "פֿ/ו", "m": "מ/ב (שפתיים סגורות)",
               "sil": "שקט"}
        return f"נשמע עכשיו: {heb.get(v, v)} · עוצמה {e:.2f} — נמדד מהקול"

    out.append(Shot(
        "voiced", 6.6, "הפה מסונכרן לקול אמיתי, לא לחלון זמן",
        "התנועות נמדדו מהפורמנטים של ההקלטה — בלי ניקוד ובלי ניחוש",
        "voice.analyze → speech.SpeechActor(track=...)",
        cam6, b=fb6, sec_strength=0.45,
        vis={"A": False, "B": True}, caption_of=cap6))

    return out


# ------------------------------- סצנות TASK 07 (עקרונות האנימציה)
#
# **כל כתובית כאן היא מדידה שרצה בזמן אמת**, ולא תיאור של מה שאמור
# לקרות. זו ההחלטה המרכזית בסצנות האלה: עיקרון אנימציה הוא בדיוק
# סוג הדבר שקל להכריז עליו ואי אפשר לראות בפריים בודד - "יש כאן
# אנטיציפציה" נראה זהה ל"אין כאן אנטיציפציה" אם לא אומרים לצופה
# לאן להסתכל ובאיזה רגע. ולכן הכתובית מציגה את המספר שהמדידה
# (`rig.principles.m_*`) מחזירה על אותו פריים.


def build_shots_principles(h: float) -> list[Shot]:
    """ציר הזמן של TASK 07 - שנים-עשר העקרונות, כל אחד נראה ונמדד."""
    from dataclasses import replace as _rep          # noqa: PLC0415
    from rig import emotion as E                     # noqa: PLC0415
    from rig import principles as P                  # noqa: PLC0415

    k = h / 1.7

    def sit(name, secs, **kw):
        return _rep(E.SCENES[name], shot_len=secs, **kw)

    out: list[Shot] = []

    # --- 1. אנטיציפציה + חריגה: ארבע הפאזות, בשמן, על המחווה עצמה
    s1 = sit("לא-מבינה", 7.4, want_strength=0.95)
    f1, _ = _emotion_actor(s1, 1.0, 0.0, speech=((1.3, 3.0),),
                           voice="hila", body=True)

    def cam_a(u):
        return {"yaw": lerp(-16, 14, u), "pitch": lerp(3, 4, u),
                "dist": lerp(2.10, 1.70, u), "tx": 0.53,
                "ty": h * 0.72, "fov": 30}

    def cap_a(u, _f=f1):
        t = u * 7.4
        bod = _f.body
        if bod is None or not bod.gestures:
            return "אין מחווה בסצנה"
        g = max(bod.gestures, key=lambda x: abs(x.weight(t)))
        w = g.weight(t)
        ph = {"idle": "מנוחה", "anticipation": "נסיגה מכינה (אנטיציפציה)",
              "preparation": "הכנה", "stroke": "הדגשה",
              "hold": "החזקה", "retraction": "חזרה"}[g.phase(t)]
        if g.overshooting(t):
            ph = "חריגה מעבר לפוזה (follow-through)"
        return f"{ph} · משקל {w:+.2f}" + ("  ← שלילי: היד נסוגה"
                                          if w < -0.001 else "")

    out.append(Shot(
        "anticipate", 7.4, "1+6 · אנטיציפציה וחריגה — היד נסוגה לפני שיצאה",
        "המשקל יורד מתחת לאפס לפני ההכנה, ועולה מעל 1.00 ברגע ההדגשה",
        "body.Gesture.weight: אנטיציפציה, חריגה והתיישבות בתוך העקומה",
        cam_a, b=f1, sec_strength=0.7,
        vis={"A": False, "B": True}, caption_of=cap_a))

    # --- 2. חפיפה: אותה יד, ארבעה מפרקים, ארבעה זמני הגעה
    s2 = sit("יודעת-יותר", 7.0)
    f2, _ = _emotion_actor(s2, 0.0, 0.0, speech=((1.2, 2.9),),
                           voice="hila", body=True)

    def cam_b(u):
        return {"yaw": lerp(22, -6, u), "pitch": 6,
                "dist": lerp(2.00, 1.72, u), "tx": -0.53,
                "ty": h * 0.66, "fov": 30}

    def cap_b(u, _f=f2):
        from rig import body as B                    # noqa: PLC0415
        t = u * 7.0
        bod = _f.body
        if bod is None or not bod.gestures:
            return "אין מחווה בסצנה"
        g = bod.gestures[0]
        parts = (("כתף", "arm_down"), ("מרפק", "elbow"),
                 ("שורש", "wrist_pitch"), ("אצבעות", "curl_pinky"))
        bits = []
        for name, key in parts:
            lag = B.DISTAL_LAG.get(key, 0.06)
            bits.append(f"{name} {g.weight(t - lag):+.2f}")
        return " → ".join(bits) + "  (כל מפרק בזמן שלו)"

    out.append(Shot(
        "overlap", 7.0, "7 · חפיפה — הכתף מובילה, האצבעות מגיעות אחרונות",
        "אותו מהלך, ארבעה זמני הגעה: 0 · 25 · 55 · 120 מילישניות",
        "body.DISTAL_LAG ו-shape_ctl_at דוגמים כל בקרה בזמן שלה",
        cam_b, a=f2, sec_strength=0.75,
        vis={"A": True, "B": False}, caption_of=cap_b))

    # --- 3. תזמון וריווח: אותה מחווה, שתי עוררויות
    s_lo = sit("עצב-גלוי", 8.6)
    s_hi = sit("הבנה-לכעס", 8.6)
    f3a, _ = _emotion_actor(s_lo, 0.0, 0.0, speech=((0.8, 2.5),),
                            voice="hila", body=True)
    f3b, _ = _emotion_actor(s_hi, 1.0, 0.33, speech=((4.7, 6.4),),
                            voice="avri", body=True)

    def cam_c(u):
        return {"yaw": lerp(-18, 16, u), "pitch": 5,
                "dist": lerp(3.20, 2.90, u), "ty": h * 0.70, "fov": 30}

    def _span(fn):
        bod = getattr(fn, "body", None)
        if bod is None or not bod.gestures:
            return 0.0
        g = bod.gestures[0]
        return g.end - g.opens

    d_lo, d_hi = _span(f3a), _span(f3b)
    out.append(Shot(
        "timing", 8.6, "3+4 · תזמון וריווח — עוררות נמוכה היא גוף כבד",
        f"אותה מחווה: {d_lo:.2f} שניות באיטית מול {d_hi:.2f} בערה — "
        "ובשתיהן מהירות השיא גדולה פי שניים מהממוצעת",
        "gestures_for גוזר prep/hold/retract מהעוררות; m_timing מאמת",
        cam_c, a=f3a, b=f3b, sec_strength=0.55,
        vis={"A": True, "B": True},
        labels={"a": "עוררות נמוכה — איטי", "b": "עוררות גבוהה — חד",
                "y": 1.86}))

    # --- 4. קשתות: היד נוסעת על קשת, ב-IK, ולא בקו ישר
    s4 = sit("מודה-ולא-אומרת", 7.2)
    f4, _ = _emotion_actor(s4, 1.0, 0.0, speech=((1.1, 2.8),),
                           voice="hila", body=True)
    #: המסלול מחושב **פעם אחת** ומשותף לכל הפריימים, אחרת כל פריים
    #: היה מקבל קשת אחרת וההדגמה הייתה חסרת משמעות.
    ARC = P.arc_path((0.20 * k, 0.98 * k, 0.12 * k),
                     (0.40 * k, 1.52 * k, 0.36 * k),
                     bulge=0.34, up=(0.85, 0.0, 0.50))
    ARC_V = P.m_arcs(ARC)
    T0, T1 = 0.9, 3.4

    def _arc_u(t):
        if t <= T0:
            return 0.0
        if t >= T1:
            return 1.0
        # ease-in/ease-out על המסע עצמו: העיקרון חל גם על המסלול
        # וגם על הקצב שבו הוא נעשה.
        return P.smoothstep((t - T0) / (T1 - T0))

    def f4_arc(u, t, _base=f4):
        ctl, _ik, mph = _base(u, t)
        i = int(round(_arc_u(t) * (len(ARC) - 1)))
        p = ARC[i]
        return ctl, {"hand_L": {"target": (float(p[0]), float(p[1]),
                                           float(p[2])),
                                "pole": (0.62 * k, 1.05 * k, -0.30 * k)}}, mph

    f4_arc.speech = f4.speech
    f4_arc.body = f4.body
    f4_arc.track = f4.track

    def cam_d(u):
        return {"yaw": lerp(12, -16, u), "pitch": lerp(4, 2, u),
                "dist": lerp(2.05, 1.72, u), "tx": 0.53,
                "ty": h * 0.70, "fov": 30}

    def cap_d(u):
        t = u * 7.2
        uu = _arc_u(t)
        return (f"היד על הקשת · {uu:6.0%} מהמסע · "
                f"קמירות {ARC_V.score:.1%} מאורך המיתר "
                f"({'קשת' if ARC_V.ok else 'קו ישר'})")

    out.append(Shot(
        "arcs", 7.2, "5 · קשתות — כף היד נוסעת בקשת, לא בקו ישר",
        f"מסלול Bézier אמיתי ב-IK, קמירות {ARC_V.score:.1%}; "
        "קו ישר בין אותן נקודות נכשל במדידה",
        "principles.arc_path מזין יעד IK, ו-m_arcs מודדת את הסטייה",
        cam_d, b=f4_arc, sec_strength=0.6,
        vis={"A": False, "B": True}, caption_of=cap_d))

    # --- 5. שימור נפח בפנים: לסת נפתחת, לחיים נשאבות
    s5 = sit("מודה-ולא-אומרת", 6.8)
    f5, _ = _emotion_actor(s5, 2.0, 0.0, speech=((1.2, 3.0),),
                           voice="hila", body=True)

    def cam_e(u):
        return {"yaw": lerp(7, -9, u), "pitch": lerp(1, 3, u),
                "dist": lerp(0.78, 0.64, u), "tx": 0.53,
                "ty": 1.566, "tz": 0.02, "fov": 30}

    def cap_e(u, _f=f5):
        t = u * 6.8
        ctl, _ik, mph = _f(u, t)
        jo = max(0.0, min(1.0, ctl.get("jaw_open", 0.0)))
        sy, sx = P.squash(jo * P.SQUASH_MAX, "jaw")
        return (f"לסת {jo:.2f} · מתיחה לגובה ×{sy:.3f} · "
                f"לחיים ×{sx:.3f} · נפח ×{sy * sx * sx:.3f}")

    out.append(Shot(
        "squash", 6.8, "2 · מעיכה ומתיחה — בשימור נפח, ורק בפנים",
        "לסת שנפתחת מותחת לגובה, והלחיים נשאבות פנימה באותו שיעור: "
        "הנפח נשאר 1.000",
        "principles.squash חוסם מעל 12% ומחוץ להקשר - שער ולא פרמטר",
        cam_e, b=f5, sec_strength=0.45,
        vis={"A": False, "B": True}, caption_of=cap_e))

    # --- 6. תנועה משנית: הכתף הנגדית והנשימה נגררות מהיד
    s6 = sit("הבנה-לכעס", 7.0, want_strength=0.9)
    f6, _ = _emotion_actor(s6, 0.0, 0.0, speech=((1.2, 2.9),),
                           voice="avri", body=True)

    def cam_f(u):
        return {"yaw": lerp(-10, 18, u), "pitch": 6,
                "dist": lerp(2.35, 1.95, u), "tx": -0.53,
                "ty": h * 0.68, "fov": 30}

    def cap_f(u, _f=f6):
        t = u * 7.0
        bod = _f.body
        if bod is None:
            return ""
        dr = bod.drive(t)
        tr = bod._trail(t)
        return (f"ידיים {dr:.2f} → נגררת {tr:.2f} (מאוחרת ב-0.13ש) · "
                f"נשימה {bod.solve(t).get('breath', 0):+.2f}")

    out.append(Shot(
        "secondary", 7.0, "10 · תנועה משנית — הכתף הנגדית מגיבה באיחור",
        "לא העתק מוקטן של היד אלא פעולה אחרת שנגררת ממנה: 4% מהמשרעת, "
        "0.13 שניות אחריה",
        "BodyActor._trail גורר את הכתף הנגדית ואת הנשימה",
        cam_f, a=f6, sec_strength=0.8,
        vis={"A": True, "B": False}, caption_of=cap_f))

    # --- 7. במה וקסם: שתי הדמויות, קו פעולה ואסימטריה שנמדדים
    s7a = sit("עצב-מוסתר", 8.4)
    s7b = sit("יודעת-יותר", 8.4)
    f7a, _ = _emotion_actor(s7a, 0.0, 0.0, speech=((0.8, 2.6),),
                            voice="hila", body=True)
    f7b, _ = _emotion_actor(s7b, 1.0, 0.4, speech=((4.6, 6.3),),
                            voice="avri", body=True)

    def cam_g(u):
        # המצלמה **עוקבת אחרי הדובר**: עד 3.6 שניות הנושא הוא A,
        # אחר כך B. זו ה-Staging, והיא נמדדת: הנושא חייב להיות
        # קרוב למרכז יותר מהשני.
        tx = lerp(-0.30, 0.30, smooth(min(1.0, max(0.0, (u - 0.38) / 0.22))))
        return {"yaw": lerp(-12, 12, u), "pitch": 5,
                "dist": lerp(3.05, 2.75, u), "tx": tx,
                "ty": h * 0.70, "fov": 30}

    def cap_g(u, _a=f7a, _b=f7b):
        t = u * 8.4
        pa = controls.normalize(_a(u, t)[0])
        pb = controls.normalize(_b(u, t)[0])
        v = P.m_appeal([pa, pb])
        spk = "שמאלית" if t < 3.6 else "ימני"
        st = P.Staging(subject_x=(-0.52 if t < 3.6 else 0.52),
                       others_x=[0.52 if t < 3.6 else -0.52],
                       cam_tx=cam_g(u).get("tx", 0.0), caption="•")
        sv = P.m_staging(st)
        return (f"נושא: {spk} ({'קריא' if sv.ok else 'לא ממוקד'}) · "
                f"{v.detail}")

    out.append(Shot(
        "staging", 8.4, "11+12 · במה וקסם — המצלמה הולכת אל מי שמדבר",
        "הנושא תמיד קרוב למרכז יותר מהשני, ואף פוזה אינה סימטרית "
        "או ישרה",
        "m_staging מודדת מרכוז והפרדה, m_appeal קו פעולה ואסימטריה",
        cam_g, a=f7a, b=f7b, sec_strength=0.6,
        vis={"A": True, "B": True}, caption_of=cap_g))

    return out


def _ramp(t: float, t0: float, rise: float = 0.14) -> float:
    """מדרגה מוחלקת: 0 לפני t0, 1 אחרי t0+rise."""
    return smooth(max(0.0, min(1.0, (t - t0) / max(1e-6, rise))))


def _with_drive(base, extra):
    """עוטף שחקן קיים ומוסיף עליו תנועה **ראשית** מפורשת.

    התנועה המשנית לא נכתבת כאן בכלל - היא נגזרת מזה בפותר. זה
    בדיוק מה שהסצנות האלה מוכיחות: אני כותב רק את הראשית.
    """
    def fn(u, t, _b=base, _e=extra):
        r = _b(u, t)
        ctl = dict(r[0])
        ctl.update(_e(u, t))
        return (ctl, r[1]) + tuple(r[2:])
    # **כל** התכונות של השחקן המקורי עוברות, ולא רק אלה שנזכרו כאן
    # בשם. `soundtrack_cues` קורא `fn.track`, ובגרסה הראשונה הוא לא
    # הועבר - הסרטון יצא שלם ובלי פס קול, בלי שום שגיאה.
    for attr in ("speech", "body", "track", "eye", "sit", "voice"):
        if hasattr(base, attr):
            setattr(fn, attr, getattr(base, attr))
    return fn


def _soft_cap(who: str, bones: tuple, title: str):
    """כתובית שמדווחת את זוויות התנועה המשנית של הפריים הנוכחי."""
    names = {"hair_front": "פוני", "hair_side_L": "קווצה שמאל",
             "hair_side_R": "קווצה ימין", "hair_back": "עורף",
             "sleeve_L": "שרוול שמאל", "sleeve_R": "שרוול ימין",
             "coat_L": "מכפלת שמאל", "coat_R": "מכפלת ימין",
             "hand_L": "כף יד שמאל", "hand_R": "כף יד ימין",
             "glasses": "משקפיים", "head": "ראש", "chest": "חזה"}

    def cap(_u: float) -> str:
        live = SOFT_LIVE.get(who) or {}
        bits = [f"{names.get(b, b)} {live.get(b, 0.0):.1f}°" for b in bones]
        return f"{title}: " + " · ".join(bits)
    return cap


def build_shots_secondary(h: float) -> list[Shot]:
    """ציר הזמן של TASK 08 - תנועה משנית שנגררת מהראשית.

    כל סצנה כאן בנויה אותו דבר: אני כותב **רק** תנועה ראשית (ראש,
    זרוע, אגן), והשיער/הבד/האביזר מגיעים מהפותר. הכתובית מדווחת את
    הזווית שנפתרה באותו פריים, ולכן אפשר לראות בעין שהיא גדלה
    כשהגוף נע ויורדת לאפס כשהוא נח.
    """
    from dataclasses import replace as _rep              # noqa: PLC0415
    from rig import emotion as E                         # noqa: PLC0415

    out: list[Shot] = []

    def sit(name, secs, **kw):
        return _rep(E.SCENES[name], shot_len=secs, **kw)

    # --- 1. שיער: שלוש פניות ראש חדות, והשיער מגיע באיחור
    s1 = sit("יודעת-יותר", 7.2)
    f1, _ = _emotion_actor(s1, 0.0, 0.0, speech=((1.0, 2.7),),
                           voice="hila", body=True)

    def drive1(_u, t):
        y = 0.52 * (_ramp(t, 1.1, 0.13) - 2 * _ramp(t, 2.7, 0.11)
                    + 2 * _ramp(t, 4.3, 0.11) - _ramp(t, 5.8, 0.20))
        return {"head_yaw": y, "neck_yaw": y * 0.45,
                "head_roll": -y * 0.16, "spine_twist": y * 0.22}

    b1 = _with_drive(f1, drive1)
    out.append(Shot(
        "hair_follow", 7.2,
        "שיער — שלוש פניות ראש חדות, והשיער מגיע אחרי הראש",
        "הפוני, שתי הקווצות והעורף נפתרים בקפיץ נפרד לכל אחד; "
        "אני כותב רק את זווית הראש",
        "secondary.SoftRig: ארבע עצמות שיער רכות, קפיץ על מקום הקצה",
        lambda u: {"yaw": lerp(-14, 12, u), "pitch": 3,
                   "dist": lerp(1.62, 1.42, u), "tx": 0.53,
                   "ty": h * 0.855, "fov": 30},
        b=b1, sec_strength=1.0, vis={"A": False, "B": True},
        caption_of=_soft_cap("B", ("hair_front", "hair_side_L",
                                   "hair_side_R", "hair_back"), "שיער")))

    # --- 2. בגד: הזרוע עולה ונעצרת, והשרוול ממשיך רגע
    s2 = sit("מודה-ולא-אומרת", 6.8)
    f2, _ = _emotion_actor(s2, 1.0, 0.0, speech=((1.2, 3.0),),
                           voice="avri", body=True)

    def drive2(_u, t):
        a = _ramp(t, 1.0, 0.26) - _ramp(t, 3.1, 0.22) + _ramp(t, 4.5, 0.18)
        return {"arm_fwd_L": 0.62 * a, "arm_down_L": 0.86 - 0.42 * a,
                "elbow_L": 0.30 * a, "wrist_pitch_L": 0.45 * a}

    a2 = _with_drive(f2, drive2)
    out.append(Shot(
        "sleeve_cloth", 6.8,
        "בגד ושרוול — הזרוע נעצרת, הבד ממשיך",
        "השרוול משוקלל לעצם רכה על הזרוע, וכף היד מאחרת אחרי האמה",
        "secondary.bind: 38% מהמשקולת של בד הזרוע עוברת לעצם השרוול",
        lambda u: {"yaw": lerp(26, -4, u), "pitch": 6,
                   "dist": lerp(2.20, 1.80, u), "tx": -0.52,
                   "ty": h * 0.66, "fov": 30},
        a=a2, sec_strength=1.0, vis={"A": True, "B": False},
        caption_of=_soft_cap("A", ("sleeve_L", "hand_L", "chest"), "בד")))

    # --- 3. מכפלת: העברת משקל באגן
    s3 = sit("עצב-גלוי", 6.6)
    f3, _ = _emotion_actor(s3, 0.0, 0.0, speech=((1.1, 2.9),),
                           voice="hila", body=True)

    def drive3(_u, t):
        w = _ramp(t, 1.0, 0.45) - 2 * _ramp(t, 2.9, 0.40) + \
            _ramp(t, 4.7, 0.40)
        return {"hips_yaw": 0.30 * w, "hips_pitch": 0.06 * abs(w),
                "spine_bend": 0.05 * w, "leg_out_L": 0.10 * max(0.0, w),
                "leg_out_R": 0.10 * max(0.0, -w)}

    b3 = _with_drive(f3, drive3)
    out.append(Shot(
        "coat_hem", 6.6,
        "מכפלת — האגן מעביר משקל, והבד למטה מגיב",
        "המכפלת תלויה על האגן בקפיץ רך; תנועת אגן של 17 מעלות "
        "מזיזה אותה בשתיים-שלוש",
        "secondary.CLOTH: coat_L/coat_R, קפיץ k=40 עם תקרה של 13°",
        lambda u: {"yaw": lerp(-20, 14, u), "pitch": 2,
                   "dist": lerp(2.60, 2.30, u), "tx": 0.50,
                   "ty": h * 0.52, "fov": 30},
        b=b3, sec_strength=1.0, vis={"A": False, "B": True},
        caption_of=_soft_cap("B", ("coat_L", "coat_R", "hair_back"),
                             "מכפלת")))

    # --- 4. ההוכחה: גוף שעומד -> אפס תנועה משנית
    #
    # זו הסצנה שמוכיחה את הדרישה של המשימה ולא רק מדגימה אותה. שתי
    # הדמויות באותה שורה: אחת נעה, אחת עומדת. אם התנועה המשנית
    # הייתה מתנד עצמאי, גם העומדת הייתה מתנדנדת.
    s4a = sit("לא-מבינה", 7.4)
    s4b = sit("הבנה-לכעס", 7.4)
    f4a, _ = _emotion_actor(s4a, 1.0, 0.0, voice="hila", body=True)
    f4b, _ = _emotion_actor(s4b, 0.0, 0.33, speech=((1.4, 3.2),),
                            voice="avri", body=True)

    def drive4b(_u, t):
        y = 0.46 * (_ramp(t, 1.3, 0.12) - 2 * _ramp(t, 3.0, 0.12)
                    + 2 * _ramp(t, 4.6, 0.12) - _ramp(t, 6.1, 0.22))
        return {"head_yaw": y, "neck_yaw": y * 0.4,
                "spine_twist": y * 0.35, "hips_yaw": y * 0.18}

    # הדמות השמאלית **קפואה לגמרי**, ולא "רק לא מניעה את הראש":
    # שחקן רגיל ממשיך לנשום ולמצמץ, וזו תנועה ראשית לכל דבר -
    # ואז התנועה המשנית שנולדת ממנה היא 8 מעלות, והכתובית שמבטיחה
    # אפס נעשית שקר. הפריים הראשון של השחקן נלקח פעם אחת ומוקפא.
    _frozen = f4a(0.0, 0.0)

    def still_a(_u, _t, _f=_frozen):
        return _f

    def cap4(_u):
        la = SOFT_LIVE.get("A") or {}
        lb = SOFT_LIVE.get("B") or {}
        ma = max([abs(v) for v in la.values()] or [0.0])
        mb2 = max([abs(v) for v in lb.values()] or [0.0])
        return (f"עומדת: תנועה משנית {ma:.2f}°   |   "
                f"נע: {mb2:.2f}°   —  המשנית נולדת מהראשית, "
                f"לא מעצמה")

    out.append(Shot(
        "respond_not_independent", 7.4,
        "ההוכחה — מי שלא נע, גם השיער שלו לא נע",
        "אותה מערכת בשתי הדמויות. בשמאל אין תנועה ראשית, ולכן "
        "התנועה המשנית היא אפס מדויק",
        "קפיץ שנמשך למטרה: גוף קפוא -> המסה יושבת על המטרה",
        lambda u: {"yaw": lerp(-10, 8, u), "pitch": 4,
                   "dist": lerp(3.25, 2.95, u), "ty": h * 0.70, "fov": 30},
        a=still_a, b=_with_drive(f4b, drive4b),
        sec_strength=1.0, vis={"A": True, "B": True},
        labels={"a": "ללא תנועה ראשית", "b": "עם תנועה ראשית",
                "y": 1.86},
        caption_of=cap4))

    # --- 5. התיישבות: עצירה פתאומית והדעיכה אחריה
    s5 = sit("מודה-ולא-אומרת", 6.4)
    f5, _ = _emotion_actor(s5, 0.5, 0.0, speech=((0.9, 2.4),),
                           voice="hila", body=True)

    def drive5(_u, t):
        y = 0.60 * (_ramp(t, 0.8, 0.10) - _ramp(t, 2.3, 0.09))
        return {"head_yaw": y, "neck_yaw": y * 0.5, "head_pitch": -0.10 * y,
                "spine_twist": y * 0.30}

    a5 = _with_drive(f5, drive5)

    def cap5(_u):
        e = SOFT_LIVE.get("eB", 0.0)
        live = SOFT_LIVE.get("B") or {}
        m = max([abs(v) for v in live.values()] or [0.0])
        # הדמות ממשיכה לנשום גם אחרי שהראש עצר, ולכן האנרגיה לא
        # יורדת לאפס מוחלט בסרטון - היא יורדת לרמת הנשימה. הספים
        # כאן הם מה שנמדד בפועל ולא "אפס" תיאורטי.
        state = ("נע" if e > 0.08 else
                 "מתיישב" if e > 0.012 else "נרגע — רק נשימה")
        return f"אנרגיה בקפיצים {e:.4f} ({state}) · זווית שיא {m:.1f}°"

    out.append(Shot(
        "settle", 6.4,
        "התיישבות — אחרי העצירה האנרגיה דועכת לאפס",
        "הראש נעצר בשנייה 2.4, והשיער ממשיך ואז נרגע. "
        "אין תנועה שנמשכת בלי סיבה",
        "קפיץ מרוסן: האנרגיה דועכת אקספוננציאלית אחרי שהמטרה קפאה",
        lambda u: {"yaw": lerp(16, -8, u), "pitch": 4,
                   "dist": lerp(1.58, 1.46, u), "tx": 0.53,
                   "ty": h * 0.855, "fov": 30},
        b=a5, sec_strength=1.0, vis={"A": False, "B": True},
        caption_of=cap5))

    return out


def build_shots_appeal(h: float, lib_a: dict, lib_b: dict) -> list[Shot]:
    """ציר הזמן של TASK 09 - קסם הדמות.

    הסצנות כאן אינן "עוד זוויות". הן **בדיוק תשעת תנאי הרנדור**
    שהמשימה מונה (תקריב, בינוני, רחב, פרופיל, שלושה-רבעים, זווית
    נמוכה, זווית גבוהה, ושתי תאורות), והכתובית בכל סצנה אומרת מה
    מנהל הקסם מדד שם. הסרטון הוא הצד הנראה של `rig/appeal.py`:
    המספרים שם, והעין כאן.
    """
    from rig import appeal as AP                          # noqa: PLC0415

    out: list[Shot] = []
    rep = _APPEAL_CACHE.get("rep")
    chars = _APPEAL_CACHE.get("chars")

    def at(name):
        return next(c for c in AP.CONDITIONS if c[0] == name)

    def cam_of(cond, u, who="both"):
        """אותה מצלמה של `appeal`, מתורגמת לפרמטרים של הבמה."""
        _, yaw, pitch, dmul, cymul, fov, _ = cond
        both = who == "both"
        # שתי דמויות עומדות במרחק 1.06 מ' זו מזו; מרחק מצלמה שמתאים
        # לדמות אחת חותך להן את הרגליים. נמדד בתמונת בדיקה.
        tx = 0.0 if both else (-0.53 if who == "A" else 0.53)
        return {"yaw": yaw + lerp(-7, 7, u), "pitch": pitch,
                "dist": h * (2.55 if both else dmul * 0.92),
                "tx": tx,
                "ty": h * (0.52 if both else cymul), "fov": fov}

    def pose_pair(name_a, name_b):
        """פוזה מהספרייה. **חובה להעביר אותה במפורש**: ברירת המחדל של
        `Shot` היא מילון ריק, כלומר סיבובי יחידה - וזו פוזת ה*כריכה*
        של השלד, שהיא צלב עם זרועות פרושות. סצנה בלי פוזה מפורשת
        מציגה שתי בובות ראווה."""
        return (lambda u, t: (lib_a[name_a][0], lib_a[name_a][1]),
                lambda u, t: (lib_b[name_b][0], lib_b[name_b][1]))

    pa, pb = pose_pair("point", "wave")
    ra, rb = pose_pair("rest", "rest")

    def num(nm, path, fmt="{}"):
        try:
            v = rep["characters"][nm]
            for k in path:
                v = v[k]
            return fmt.format(v)
        except Exception:                                  # noqa: BLE001
            return "—"

    # --- 1. צללית: הפוזה היא שמייצרת קריאוּת
    out.append(Shot(
        "appeal_silhouette", 7.0,
        "צללית — הקריאוּת נמדדת על פוזה, לא על עמידה",
        f"לוקאס: קמירות {num('lucas', ('silhouette', 'wide', 'solidity'))}, "
        f"{num('lucas', ('silhouette', 'wide', 'extremities'))} קצוות · "
        f"מאיה: קמירות {num('maya', ('silhouette', 'wide', 'solidity'))}, "
        f"{num('maya', ('silhouette', 'wide', 'extremities'))} קצוות",
        "appeal.silhouette: קמירות, ספירת קצוות ומובחנות בין הדמויות",
        lambda u: cam_of(at("wide"), u),
        a=pa, b=pb, sec_strength=0.9))

    # --- 2. פרופורציות: אותה דמות, שוט רחב
    out.append(Shot(
        "appeal_proportions", 6.4,
        "פרופורציות — מספר הראשים בגוף נכנס לחלון הדמות המסוגננת",
        f"לוקאס {num('lucas', ('proportions', 'values', 'heads_tall'))} "
        f"ראשים · מאיה "
        f"{num('maya', ('proportions', 'values', 'heads_tall'))} ראשים "
        f"(קודם 9.1 ו-7.7)",
        "appeal.proportions: שש מידות שנמדדות מהרשת, כולן בחלון",
        lambda u: cam_of(at("wide"), u),
        a=pa, b=pb, sec_strength=0.8))

    # --- 3-7. חמשת השוטים שבהם הזהות חייבת לשרוד
    for key, who, secs in (("close_up", "A", 5.4), ("medium", "B", 5.0),
                           ("side_profile", "A", 4.6),
                           ("three_quarter", "B", 4.6),
                           ("low_angle", "A", 4.4), ("high_angle", "B", 4.4)):
        cond = at(key)
        heb = {"close_up": "תקריב", "medium": "שוט בינוני",
               "side_profile": "פרופיל", "three_quarter": "שלושה-רבעים",
               "low_angle": "זווית נמוכה", "high_angle": "זווית גבוהה"}[key]
        nm = "lucas" if who == "A" else "maya"
        out.append(Shot(
            f"appeal_{key}", secs,
            f"{heb} — אותה דמות, מסגור אחר",
            f"סחיפת החתימה של {'לוקאס' if who == 'A' else 'מאיה'} בשוט הזה: "
            f"{_appeal_drift(rep, nm, key)} · שולי הזיהוי בכל התנאים "
            f"{rep['recognizability']['margin'] if rep else '—'}",
            "appeal.recognizability: חתימת ראש מנורמלת, סחיפה מול הפרדה",
            lambda u, c=cond, w=who: cam_of(c, u, w),
            a=pa, b=pb, vis={"A": who == "A", "B": who == "B"},
            sec_strength=0.9))

    # --- 8-9. שתי תאורות
    for key, heb in (("light_rim", "תאורת קו אחורית"),
                     ("light_hard_key", "מקור קשה יחיד")):
        cond = at(key)
        out.append(Shot(
            f"appeal_{key}", 4.6,
            f"{heb} — התאורה התחלפה, הדמות לא",
            f"סחיפת הצבע בין התאורות: "
            f"{_appeal_light(rep)} (הגבול 0.30)",
            "stage.__light: מצב תאורה בשם, קבוע ואינו נע עם המצלמה",
            lambda u, c=cond: cam_of(c, u),
            a=pa, b=pb, sec_strength=0.9, light=cond[6]))

    return out


#: הדוח של מנהל הקסם, כדי שהכתוביות יציגו **מה שנמדד** ולא טקסט קבוע.
_APPEAL_CACHE: dict = {}


def _appeal_drift(rep, name, shot):
    try:
        return rep["recognizability"]["head"]["drift"][name]["per_shot"][shot]
    except Exception:                                      # noqa: BLE001
        return "—"


def _appeal_light(rep):
    try:
        return max(r["lighting_color_drift"]
                   for r in rep.get("render", {}).values())
    except Exception:                                      # noqa: BLE001
        return "נמדד בנפרד"


def build_shots_cinema(h: float) -> list[Shot]:
    """ציר הזמן של TASK 10 - מבחן המשחק הקולנועי.

    **שלוש פעמים אותן עשר שניות.** זה לא מילוי אורך אלא מבנה
    המבחן עצמו: שוט רחב שבו רואים את שתי הדמויות ואת מי שמדבר,
    תקריב על B שבו רואים את המשחק, ושוב אותו תקריב - הפעם עם
    כתובית שאומרת מה קורה **בלי להזכיר מה נאמר**. אם הצופה מבין
    את השלישי, הדמות ביימה את עצמה ולא רק הזיזה שפתיים.

    הדמויות נבנות מ-`cinema.actor`, כלומר **אותה פונקציה בדיוק**
    שהמבחן מודד. סרטון שמראה משהו אחר ממה שנמדד הוא דוח שקרי.
    """
    from rig import cinema as C                          # noqa: PLC0415

    fa = C.actor("full", "a")
    fb = C.actor("full", "b")
    L = C.SCENE_LEN

    def two(u):
        return {"yaw": lerp(-16, 12, u), "pitch": 3.0,
                "dist": h * 2.45, "tx": 0.0, "ty": h * 0.54, "fov": 30}

    def on_b(u):
        return {"yaw": lerp(14, -6, u), "pitch": lerp(1.5, -1.0, u),
                "dist": lerp(1.00, 0.86, u), "tx": 0.53,
                "ty": h * 0.925, "tz": 0.03, "fov": 30}

    def who_talks(u):
        t = u * L
        if C.A_SPEECH[0] <= t <= C.A_SPEECH[1]:
            return f"לוקאס: «{C.A_LINE}»"
        if C.B_SPEECH[0] <= t <= C.B_SPEECH[1]:
            return f"מאיה: «{C.B_LINE}»"
        return "— שקט —"

    #: הכתובית של השוט השלישי. היא מתארת **מה הגוף עושה**, לא מה
    #: נאמר, ולכן היא עצמה מדגימה את הטענה: כל המידע הרגשי כאן
    #: אינו בפס הקול.
    def silent_cap(u):
        t = u * L
        for lo, hi, txt in (
                (0.0, 3.2, "מביטה בו · קשובה · משקל על רגל אחת"),
                (3.2, 4.6, "נוחתת: הגבה הפנימית עולה, העפעף מתהדק"),
                (4.6, 5.2, "מהססת — התנועה נעצרת לרגע"),
                (5.2, 6.4, "מסיטה מבט, קצר, וחוזרת"),
                (6.4, 8.6, "עונה — וההבעה כבר לא חוזרת לאחור"),
                (8.6, L + 1, "אחרי שסיימה: אי-הנוחות נשארת")):
            if lo <= t < hi:
                return txt
        return ""

    return [
        Shot("cine_wide", L,
             "סצנת דיאלוג · עשר שניות",
             "לוקאס אומר משפט ניטרלי · מאיה שומעת אותו",
             "שתי דמויות בדיאלוג מלא: קול, הגאים, מבט, גוף",
             two, a=fa, b=fb,
             labels={"a": "לוקאס", "b": "מאיה", "y": 1.86},
             caption_of=who_talks),
        Shot("cine_close", L,
             "אותן עשר שניות · תקריב על מאיה",
             "מבט → הבנה → היסוס → הסטה → הבעה → משקל → תגובה",
             "שמונת אירועי המשחק, כולם נמדדים ב-rig/cinema.py",
             on_b, a=fa, b=fb,
             vis={"A": False, "B": True}, light="studio"),
        Shot("cine_mute", L,
             "ועכשיו בלי להסתכל על הפה",
             "כל מה שכתוב למטה נמדד מהעיניים, מהגבות ומהגוף בלבד",
             "המבחן: השינוי הרגשי מובן גם כשהקול מושתק",
             on_b, a=fa, b=fb,
             vis={"A": False, "B": True}, light="studio",
             caption_of=silent_cap),
    ]


def build_shots_duet(h: float) -> list[Shot]:
    """ציר הזמן של TASK 10ב - דימורפיזם ודיאלוג חופף.

    **ארבע סצנות, ושתי הראשונות הן על הגאומטריה ולא על המשחק.**
    חצי מהמשימה הוא פיסול, ופיסול אינו נראה בתקריב על הפנים: צללית
    נקראת בשוט רחב ובפרופיל. לכן הסצנה הראשונה היא סריקה מחזיתית
    לפרופיל על שתי הדמויות, עם המספרים שנמדדו על הרשת בכתובית -
    וזה מה שהופך את "כתפיים רחבות" לדבר שאפשר לראות ולאמת באותו
    פריים.

    שתי האחרונות הן הדיאלוג: שוט רחב שבו רואים את החפיפה (הכתובית
    אומרת "שניהם מדברים" בדיוק ב-0.46 השניות האלה), ואחריו תקריב
    על לוקאס ברגע שחותכים אותו - שם יושבת השאיפה החדה.
    """
    from rig import dimorph as DM                          # noqa: PLC0415
    from rig import duet as D                              # noqa: PLC0415

    fa = D.actor("lucas")
    fb = D.actor("maya")
    L = D.SCENE_LEN

    # --- המידות נמדדות **פעם אחת, מהרשת**, ונכנסות לכתובית.
    try:
        mm = DM.build_pair("fast")
    except Exception:                                      # noqa: BLE001
        mm = {}

    def _sil(name: str, heb: str):
        m = mm.get(name, {})
        if not m:
            return f"{heb}: (לא נמדד)"
        return (f"{heb}: כתף/מותן {m['v_taper']:.2f} · "
                f"מותן/אגן {m['whr']:.2f} · "
                f"כתף/אגן {m['shoulder_hip']:.2f}")

    def sil_cap(u: float) -> str:
        return _sil("lucas", "לוקאס") + "   |   " + _sil("maya", "מאיה")

    def rest(_u, _t):
        return {}, {}, {}

    def orbit(u):
        # חזית -> 3/4 -> פרופיל. הצללית נקראת בדיוק במעבר הזה.
        return {"yaw": lerp(0, 86, smooth(u)), "pitch": 2.0,
                "dist": h * 2.30, "tx": 0.0, "ty": h * 0.52, "fov": 30}

    def torso_cam(u):
        return {"yaw": lerp(-8, 8, u), "pitch": 1.0,
                "dist": h * 1.15, "tx": 0.0, "ty": h * 0.66, "fov": 30}

    def two(u):
        return {"yaw": lerp(-14, 10, u), "pitch": 3.0,
                "dist": h * 2.50, "tx": 0.0, "ty": h * 0.54, "fov": 30}

    def on_a(u):
        return {"yaw": lerp(-16, 4, u), "pitch": lerp(1.5, -1.0, u),
                "dist": lerp(1.02, 0.88, u), "tx": -0.53,
                "ty": h * 0.935, "tz": 0.03, "fov": 30}

    def who_talks(u):
        t = u * L
        a = D.L_SPEECH[0] <= t <= D.L_SPEECH[1]
        b = D.M_SPEECH[0] <= t <= D.M_SPEECH[1]
        if a and b:
            return f"שניהם מדברים — חפיפה של {D.OVERLAP:.2f}ש"
        if a:
            return f"לוקאס: «{D.LUCAS_LINE}»"
        if b:
            return f"מאיה: «{D.MAYA_LINE}»"
        return "— שקט —"

    def body_cap(u: float) -> str:
        t = u * L
        for lo, hi, txt in (
                (0.0, D.L_SPEECH[0], "מתגונן עוד לפני שפתח: כתפיים "
                                     "עולות וסוגרות, משקל אחורה"),
                (D.L_SPEECH[0], D.CUT_IN, "מסביר · משקל על רגל אחת"),
                (D.CUT_IN, D.CUT_IN + 0.75,
                 "נחתך — שאיפה חדה, בית החזה נתפס"),
                (D.CUT_IN + 0.75, D.M_SPEECH[1],
                 "היא מדברת והוא מחזיק: נשימה רדודה, מחליף רגל"),
                (D.M_SPEECH[1], L + 1, "אחרי שהיא סיימה — ההתגוננות "
                                       "נשארת")):
            if lo <= t < hi:
                return txt
        return ""

    return [
        Shot("dimo_pair", 7.0,
             "מבנה גוף מובחן — אותה מצלמה, שתי צלליות",
             "לוקאס: כתפיים רחבות ומרובעות, מותן צרה, שריר זרוע. "
             "מאיה: שעון חול, כתף ואגן כמעט שווים",
             "rig/dimorph.py — פרופיל פרמטרי, חתך סופר-אליפסה, "
             "והמידות נמדדות מהקודקודים",
             orbit, a=rest, b=rest,
             labels={"a": "לוקאס", "b": "מאיה", "y": 1.92},
             caption_of=sil_cap),
        Shot("dimo_torso", 5.0,
             "ולמה זה לא היה נראה קודם",
             "פלג הגוף נבנה בציר הפוך: רוחב 0.195 מ' מול עומק "
             "0.302 מ'. עכשיו הוא רחב מעומקו, כמו גוף",
             "basemesh.tube(frame=...) — מסגרת צירים מפורשת",
             torso_cam, a=rest, b=rest,
             labels={"a": "לוקאס", "b": "מאיה", "y": 1.92}),
        Shot("duet_wide", L,
             "דיאלוג חופף — ורגשות מנוגדים",
             "הוא מתגונן (defend), היא משועשעת וספקנית (test). "
             "שתי הכוונות נגזרות מהרגש ולא נכתבות",
             "rig/duet.py — חפיפה בציר הזמן, נשימה תגובתית, "
             "יציבות שאינן תמונת ראי",
             two, a=fa, b=fb,
             labels={"a": "לוקאס", "b": "מאיה", "y": 1.86},
             caption_of=who_talks),
        Shot("duet_lucas", L,
             "אותן תשע שניות · תקריב על לוקאס",
             "הרגע שבו חותכים אותו: שאיפה חדה, ואחריה נשימה רדודה "
             "כל עוד היא מדברת",
             "duet.reactive_breath — שלושה איברים שמקורם בבן השיח",
             on_a, a=fa, b=fb,
             vis={"A": True, "B": False}, light="studio",
             caption_of=body_cap),
    ]


def shots_for(task: int, h: float, lib_a: dict, lib_b: dict) -> list[Shot]:
    if task >= 11:
        return build_shots_duet(h)
    if task >= 10:
        return build_shots_cinema(h)
    if task >= 9:
        return build_shots_appeal(h, lib_a, lib_b)
    if task >= 8:
        return build_shots_secondary(h)
    if task >= 7:
        return build_shots_principles(h)
    if task >= 6:
        return build_shots_body(h)
    if task >= 4:
        return build_shots_emotion(h)
    return build_shots_acting(h) if task >= 2 else \
        build_shots(h, lib_a, lib_b)


def _probe_frame(shot: Shot, n: int, fps: int) -> int:
    """הפריים הייצוגי של הסצנה: זה שבו הפנים הכי פעילות.

    קודם זה היה 55% מהסצנה בקביעות, וזה נתן תמונות מטעות - בסצנת
    ההפתעה הפריים נפל 0.11 שנייה אחרי תחילת הגל השני, כשהלסת עוד
    בדרך למטה, ולכן "הפתעה" הוצגה עם פה סגור. הסריקה כאן היא
    בפייתון בלבד ולוקחת מילישניות.
    """
    # אתחול ב-0.0 ולא ב--1.0: סצנה שאין בה פעילות פנים כלל (למשל
    # סצנות TASK 09, שבהן הפוזה סטטית והמצלמה היא שנעה) החזירה את
    # **פריים אפס** - שבו הכתובית עוד שקופה לגמרי והחיתוך עוד כהה.
    # עם 0.0 פריים חסר פעילות נופל על ברירת המחדל שבאמצע הסצנה.
    best, bi = 0.0, int(n * 0.55)
    scores: list[float] = []
    for i in range(n):
        t, u = i / fps, i / max(1, n - 1)
        s = 0.0
        for fn in (shot.a, shot.b):
            r = fn(u, t)
            if len(r) > 2 and r[2]:
                s += sum(abs(float(v)) for v in r[2].values())
            # גם בקרות פנים נספרות: אזורי הגבות, הלשון והראש מיוצגים
            # בעצמות בלבד, ובלעדיהן סצנת הבידוד הייתה נדגמת תמיד
            # באותם שלושה אזורים שיש להם צורות.
            for k, v in (r[0] or {}).items():
                # מצמוץ **לא** נספר. הוא בקרת פנים לכל דבר, ולכן
                # הניקוד העדיף דווקא פריים שבו העיניים עצומות -
                # ותמונת "הפתעה" יצאה עם עיניים סגורות למחצה.
                if k.startswith("blink_"):
                    continue
                try:
                    acting.region_of(k)
                except KeyError:
                    continue
                s += abs(float(v)) * 0.5
            # **TASK 07.** בסצנה שכל עניינה הידיים, הפריים המייצג
            # חייב להיות רגע המחווה - ולא הרגע שבו הפנים הכי
            # פעילות. נתפס בגיליון המגע הראשון של TASK 07: שבע
            # תמונות, ובכולן הכתובית אמרה "מנוחה · משקל +0.00",
            # כי שיא פעילות הפנים נופל אחרי שהיד כבר חזרה.
            bod = getattr(fn, "body", None)
            if bod is not None and bod.gestures:
                s += max(abs(g.weight(t)) for g in bod.gestures) * 3.0
        scores.append(s)
        if s > best:
            best, bi = s, i
    # סצנה שבה הניקוד **קבוע** (פוזה סטטית, מצלמה שנעה - כל סצנות
    # TASK 09) הייתה מחזירה את פריים אפס, כי הוא הראשון שעבר את
    # האתחול. בפריים אפס הכתובית עדיין שקופה לגמרי והחיתוך כהה,
    # ולכן כל תמונות הבדיקה יצאו בלי כתובית. כשהניקוד שטוח בוחרים
    # את אמצע הסצנה.
    if scores and max(scores) - min(scores) < 1e-9:
        return int(n * 0.55)
    return bi


def scene_coverage(h: float = 1.70, fps: int = 30, eps: float = 0.02,
                   task: int = 2) -> dict:
    """סורק את סצנות TASK 02 **בלי דפדפן** ומודד לכל אחת כמה זמן יש
    בה ביטוי פעיל, ומה החלון הריק הארוך ביותר.

    למה זה קיים: תמונת בדיקה היא פריים **אחד**, והיא נראתה תקינה
    לחלוטין גם כששתי סצנות היו ריקות לגמרי ברגע שנדגם. המדידה הזאת
    עוברת על כל הפריימים, רצה בשבריר שנייה, ולכן היא זו שנועלת את
    התוצאה בבדיקות.
    """
    out = {}
    shots = build_shots_emotion(h) if task >= 4 else build_shots_acting(h)
    for shot in shots:
        n = max(2, int(round(shot.secs * fps)))
        active, gap, worst = 0, 0.0, 0.0
        peak = 0
        for i in range(n):
            t, u = i / fps, i / (n - 1)
            cnt = 0
            for fn in (shot.a, shot.b):
                r = fn(u, t)
                if len(r) > 2 and r[2]:
                    cnt += sum(1 for v in r[2].values() if abs(v) > eps)
            peak = max(peak, cnt)
            if cnt:
                active += 1
                gap = 0.0
            else:
                gap += 1 / fps
                worst = max(worst, gap)
        out[shot.key] = {"seconds": shot.secs, "frames": n,
                         "active_frames": active,
                         "active_pct": round(100.0 * active / n, 1),
                         "worst_gap_sec": round(worst, 3),
                         "peak_shapes": peak}
    return out


# ------------------------------------------------------------------ במה

def _serve(root: Path):
    h = functools.partial(http.server.SimpleHTTPRequestHandler,
                          directory=str(root))
    srv = socketserver.ThreadingTCPServer(("127.0.0.1", 0), h)
    srv.daemon_threads = True
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, srv.server_address[1]


def _stage(glb_a: Path, glb_b: Path, env_dir: Path | None = None) -> Path:
    """תיקיית הגשה זמנית. file:// חוסם ES modules ו-fetch של GLB
    (origin null), והכשל שקט לגמרי - אין שגיאה בקונסולה."""
    d = Path(tempfile.mkdtemp(prefix="showreel_"))
    shutil.copytree(STUDIO / "lib", d / "lib")
    # GLTFLoader.module.js מייבא ../utils/BufferGeometryUtils.js. בלי
    # הקובץ הזה המודול נכשל בטעינה **בשקט**.
    shutil.copytree(STUDIO / "utils", d / "utils")
    shutil.copy2(HERE / "stage.html", d / "stage.html")
    shutil.copy2(glb_a, d / "a.glb")
    shutil.copy2(glb_b, d / "b.glb")
    # שכבות הסביבה הצרובות. הן מוגשות מאותו שרת כמו הדף, אחרת
    # הדפדפן חוסם אותן כ-origin זר ו-`background-image` נשאר ריק
    # **בלי שום שגיאה** - הרקע פשוט שחור.
    if env_dir and Path(env_dir).exists():
        shutil.copytree(Path(env_dir), d / "env")
    return d


def load_char(name: str, rig_dir: Path):
    """הדמות כפי שנבנתה - כולל גודל ראש ואביזרים.

    נמדד 05/10: כאן נבנה שלד בלי `head_scale` ובלי `accessories`. בלי
    האביזרים אין בכלל עצם `glasses`, ולכן גם אחרי שהמשקפיים נכנסו
    ל-GLB הם לא היו זזים; ובלי `head_scale` עצמות הפנים של מאיה יושבות
    בפייתון 20% קרוב יותר למרכז הראש מאשר בכריכה שב-GLB.
    """
    rig = json.loads((rig_dir / f"{name}.rig.json").read_text(encoding="utf-8"))
    skel = pipeline.skeleton_from_rig(rig)
    return rig, skel, controls.pose_library(skel)


def _jsonable(q: dict) -> dict:
    return {k: [float(x) for x in v] for k, v in q.items()}


FOOT_BONES = ("foot_L", "toe_L", "toe_tip_L", "foot_R", "toe_R", "toe_tip_R")


def _foot_idx(skel: Skeleton) -> list[int]:
    """מדד העצמות שנוגעות ברצפה.

    **לא** מינימום על כל העצמות: `root` יושבת על y=0 בכל פוזה, ולכן
    מינימום גלובלי מחזיר 0 תמיד וההיסט יוצא אפס - תיקון שנראה כאילו
    הוא עובד ולמעשה אינו עושה דבר. נתפס בבדיקת יחידה ב-05/10.
    """
    names = list(skel.names)
    return [names.index(n) for n in FOOT_BONES if n in names]


def rest_floor(skel: Skeleton) -> float:
    """גובה כף הרגל הנמוכה בפוזת המנוחה - קו הרצפה של הדמות."""
    idx = _foot_idx(skel)
    return float(skel.forward({})[idx, 1, 3].min())


def ground_offset(skel: Skeleton, q: dict, floor: float) -> float:
    """היסט אנכי שמחזיר את כפות הרגליים לרצפה.

    שורש הדמות אינו זז עם הפוזה: בכפיפה הברכיים מתכופפות, כפות
    הרגליים עולות - והדמות **מרחפת** מעל הצל שלה. זה נראה בדיוק כמו
    באג עיגון, והוא לא נתפס בבדיקת הקבלה כי שם כל פוזה מצולמת לחוד.
    """
    idx = _foot_idx(skel)
    return floor - float(skel.forward(q)[idx, 1, 3].min())


FADE = 0.28          # שניות של החשכה בכל חיתוך


def _fade_at(t: float, secs: float) -> float:
    if t < FADE:
        return 1.0 - t / FADE
    if t > secs - FADE:
        return 1.0 - (secs - t) / FADE
    return 0.0


def _cap_opacity(t: float, secs: float) -> float:
    """הכתובית נכנסת אחרי החיתוך ויוצאת לפניו."""
    inn = min(1.0, max(0.0, (t - FADE) / 0.45))
    out = min(1.0, max(0.0, (secs - FADE - t) / 0.45))
    return round(smooth(min(inn, out)), 3)


async def produce(out_mp4: Path, rig_dir: Path = RIG_DIR,
                  task: int = 1, title: str = "", probe: bool = False,
                  fps: int = FPS, width: int = WIDTH, height: int = HEIGHT,
                  on_progress=None, ss: int = 2,
                  shots_override: list | None = None,
                  cast: tuple = ("lucas", "maya"),
                  env_manifest: dict | None = None,
                  env_dir: Path | None = None) -> dict:
    import engine                                          # noqa: PLC0415

    rig_a, skel_a, lib_a = load_char(cast[0], rig_dir)
    rig_b, skel_b, lib_b = load_char(cast[1], rig_dir)
    if task >= 9 and "rep" not in _APPEAL_CACHE:
        # הכתוביות של TASK 09 מצטטות מספרים שנמדדו, ולכן הדוח נבנה
        # **לפני** הסצנות. אם הוא לא נבנה, הכתובית הייתה טקסט יפה
        # בלי כיסוי - וזו בדיוק ההצהרה שהמשימה אוסרת.
        from rig import appeal as _AP
        try:
            _chars = [_AP.Char(n, rig_dir) for n in ("lucas", "maya")]
            _APPEAL_CACHE["chars"] = _chars
            _APPEAL_CACHE["rep"] = _AP.evaluate(_chars)
            old = Path(r"D:\claude-bot\out\char3dppealppeal.json")
            if old.exists():
                _APPEAL_CACHE["rep"]["render"] = json.loads(
                    old.read_text(encoding="utf-8")).get("render", {})
        except Exception as e:                             # noqa: BLE001
            raise RuntimeError(f"דוח מנהל הקסם לא נבנה: {e}") from e
    # `shots_override` הוא מה שמאפשר ללולאת השיפור (TASK 11) לרנדר
    # **את אותו שוט** שוב ושוב עם ידיות שונות, בלי להמציא מסלול
    # רינדור מקביל. רינדור הבדיקה חייב להיות רינדור הייצור, אחרת
    # הציון שהפאנל נותן אינו הציון של הסרטון שיישלח.
    shots = shots_override or shots_for(task, rig_a["height_m"],
                                        lib_a, lib_b)

    tag = title or f"אולפן האנימציה · תוכנית שדרוג האיכות · TASK {task:02d}"

    # פוזות הספרייה מחושבות פעם אחת (סצנה 5 ממזגת ביניהן)
    lib_q_a = {k: controls.evaluate(skel_a, *lib_a[k]) for k in lib_a}
    lib_q_b = {k: controls.evaluate(skel_b, *lib_b[k]) for k in lib_b}
    floor_a, floor_b = rest_floor(skel_a), rest_floor(skel_b)

    stage = _stage(rig_dir / rig_a["glb"], rig_dir / rig_b["glb"], env_dir)
    srv, port = _serve(stage)
    br = engine.Browser(width, height)
    t0 = time.time()
    enc = None
    probes: list[Path] = []
    scene_log: list[dict] = []
    frames_done = 0
    info = {}
    try:
        await br.start()
        # ss=2: הבמה מציירת בכפל רזולוציה והדפדפן מקטין. בלי זה מנעול
        # שיער או קו ריסים נופלים בין פיקסל לפיקסל ומהבהבים בין פריימים.
        url = (f"http://127.0.0.1:{port}/stage.html"
               f"?w={width}&h={height}&a=a.glb&b=b.glb&ss={ss}")
        await br.cmd("Page.navigate", {"url": url})
        for _ in range(400):
            if await br.js("!!window.__ready"):
                break
            await asyncio.sleep(0.1)
        err = await br.js("window.__err ? window.__err() : 'הבמה לא נטענה'")
        if err:
            raise RuntimeError(f"הבמה החזירה שגיאה: {err}")
        info = json.loads(await br.js("JSON.stringify(window.__info||null)")
                          or "null") or {}
        for k in ("A", "B"):
            if not info.get(k) or info[k].get("bones", 0) < 1:
                raise RuntimeError(f"דמות {k} נטענה בלי עצמות: {info.get(k)}")
            # **הבדיקה שמונעת את הכשל השקט של TASK 02.** GLB עם
            # morph targets אבל בלי `extras.targetNames` נטען בלי
            # תלונה, ו-three.js פשוט מתעלם מכל שם צורה - הפנים
            # נשארות ניטרליות וזה נראה כאילו המשחק לא נכתב.
            if task >= 2:
                sh = info[k].get("shapes") or []
                if len(sh) < len(face.NAMES):
                    raise RuntimeError(
                        f"דמות {k}: נטענו {len(sh)} צורות פנים מתוך "
                        f"{len(face.NAMES)} (morphs={info[k].get('morphs')}). "
                        "כנראה חסר extras.targetNames ב-GLB.")

        # שכבות הסביבה נטענות **פעם אחת**, לפני הפריים הראשון. זו כל
        # עלות הרקע בסרטון כולו: מכאן והלאה הוא רק זז.
        env_on = 0
        if env_manifest:
            spec = json.dumps(json.dumps(dict(env_manifest, base="env/")))
            env_on = await br.js(
                f"window.__env ? window.__env(JSON.parse({spec})) : -1")
            if not isinstance(env_on, (int, float)) or env_on < 1:
                raise RuntimeError(
                    f"שכבות הסביבה לא נטענו בבמה (הוחזר {env_on!r}). "
                    "סצנת חוץ בלי רקע היא אולפן שחור, ולכן זו עצירה.")

        # הלהקה (TASK 13): סנאי, ענן עלים והילת פנס. נטענת פעם אחת
        # בדיוק כמו שכבות הסביבה, ורק אם יש בכלל שוט שמשתמש בה -
        # כל 12 המשימות הקודמות אינן נוגעות בה ולכן אינן משתנות.
        ens_on = 0
        if any(getattr(s, "ens_of", None) is not None for s in shots):
            from rig import ensemble as ENS            # noqa: PLC0415
            espec = json.dumps(json.dumps(ENS.stage_spec()))
            ens_on = await br.js(
                f"window.__ensemble ? window.__ensemble(JSON.parse({espec}))"
                " : -1")
            if not isinstance(ens_on, (int, float)) or ens_on < 1:
                raise RuntimeError(
                    f"הלהקה לא נטענה בבמה (הוחזר {ens_on!r}). שוט שמבוים "
                    "סביב פיזור עלים ובלי עלים הוא שוט ריק, ולכן זו עצירה.")
            lx, ly, lr = ENS.lamp_screen()
            await br.js(f"window.__lamp ? window.__lamp({lx},{ly},{lr}) : -1")

        if not probe:
            enc = engine.Encoder(out_mp4, width, height, fps, crf=19)

        total = sum(int(round(s.secs * fps)) for s in shots)
        t_abs = 0.0            # תחילת השוט על ציר הזמן של הסרט כולו
        for shot in shots:
            n = int(round(shot.secs * fps))
            # TASK 08: מערכת התנועה המשנית המלאה (שיער, בגד, שרוול,
            # מכפלת, אביזר, כפות ידיים, ראש וחזה) מחליפה את הפיגור
            # הישן שעבד על ארבע עצמות בלבד. אחת לכל דמות **ולכל
            # סצנה** - מצב קפיץ שנשאר בין חתכי מצלמה היה מייצר קפיצה
            # בפריים הראשון של הסצנה הבאה.
            sm_a = secondary.SoftRig(skel_a, shot.sec_strength)
            sm_b = secondary.SoftRig(skel_b, shot.sec_strength)
            cyc = getattr(shot, "pose_cycle", None)
            idx = list(range(n)) if not probe else [_probe_frame(shot, n, fps)]
            applied_min = 10 ** 9
            # כמה צורות פנים היו **פעילות בפועל** בסצנה, לפי מה שהבמה
            # דיווחה. סצנה של TASK 02 שבה זה 0 היא סצנה שהצורות שלה
            # לא הגיעו לדפדפן - כשל שאי אפשר לראות בעין על פריים בודד.
            morph_max = 0
            for i in idx:
                t = i / fps
                u = i / max(1, n - 1)
                ma, mb_ = {}, {}
                if cyc:
                    qa = _cycle_pose(lib_q_a, cyc[0], u)
                    qb = _cycle_pose(lib_q_b, cyc[1], u)
                else:
                    # הסצנה מחזירה (בקרות, IK) או (בקרות, IK, צורות).
                    # שלושה איברים = סצנה שמשתמשת במשחק הפנים של
                    # TASK 02; שניים = סצנה ותיקה, וזה נשאר תקף.
                    ra, rb = shot.a(u, t), shot.b(u, t)
                    ca, ika = ra[0], ra[1]
                    cb, ikb = rb[0], rb[1]
                    if len(ra) > 2:
                        ma = ra[2] or {}
                    if len(rb) > 2:
                        mb_ = rb[2] or {}
                    qa = controls.evaluate(skel_a, ca, ika)
                    qb = controls.evaluate(skel_b, cb, ikb)
                qa = sm_a.solve(dict(qa), 1 / fps)
                qb = sm_b.solve(dict(qb), 1 / fps)
                # הזוויות שנפתרו *בפריים הזה* זמינות לכתוביות: בסצנות
                # TASK 08 הכתובית היא ההוכחה, כי תנועה משנית של שלוש
                # מעלות נראית בעין אבל אי אפשר לאמת אותה בלי מספר.
                SOFT_LIVE["A"] = dict(sm_a.last)
                SOFT_LIVE["B"] = dict(sm_b.last)
                SOFT_LIVE["eA"] = sm_a.energy()
                SOFT_LIVE["eB"] = sm_b.energy()

                payload = {
                    "A": _jsonable(qa), "B": _jsonable(qb),
                    "MA": {k: round(float(v), 4) for k, v in ma.items()},
                    "MB": {k: round(float(v), 4) for k, v in mb_.items()},
                    "cam": shot.cam(u),
                    "light": getattr(shot, "light", "studio"),
                    "cap": (shot.caption_of(u) if shot.caption_of
                            else shot.cap),
                    "sub": shot.sub, "tag": tag,
                    "cap_o": _cap_opacity(t, shot.secs),
                    "fade": 0.0 if probe else round(_fade_at(t, shot.secs), 3),
                    "vis": shot.vis or {"A": True, "B": True},
                    "oy": {"A": round(ground_offset(skel_a, qa, floor_a), 4),
                           "B": round(ground_offset(skel_b, qb, floor_b), 4)},
                }
                # תנועת מקום אנכית (קפיצה / שקיעה במשקל). היא
                # **נוספת** לנעילת הרצפה ולא דורסת אותה: נעילת הרצפה
                # מתקנת כפיפת ברכיים, והקפיצה מרימה את הדמות כולה.
                # דריסה הייתה מחזירה את הדמות לרחף בכל כפיפה.
                lift = getattr(shot, "lift_of", None)
                if lift is not None:
                    payload["oy"]["A"] = round(
                        payload["oy"]["A"] + lift(cast[0], t), 5)
                    payload["oy"]["B"] = round(
                        payload["oy"]["B"] + lift(cast[1], t), 5)
                # תנועת מקום (TASK 14): היסט **מוחלט** בשלושה צירים,
                # שמחליף את נעילת הרצפה למי שנושא אותו. הסדר כאן
                # אינו חופשי - הוא אחרי `lift_of` ולא לפניו, כי
                # `lift_of` כותב ל-`oy` והבמה מתעלמת מ-`oy` כשיש
                # `mv`. אחרת דמות שרצה הייתה מקבלת גם קפיצה.
                move = getattr(shot, "move_of", None)
                if move is not None:
                    mv = move(t) or {}
                    if mv:
                        payload["mv"] = {k: {kk: round(float(vv), 5)
                                             for kk, vv in v.items()}
                                         for k, v in mv.items()}
                if shot.labels:
                    payload["labels"] = dict(
                        shot.labels,
                        o=round(_cap_opacity(t, shot.secs) * 0.92, 3))
                if shot.env_of is not None:
                    # `t_abs` ולא `t`: הלופ של הרוח והעננים נמדד על
                    # ציר הזמן של **הסרט**, לא של השוט. איפוס בכל חיתוך
                    # היה מחזיר את העלווה לאותה תנוחה בדיוק אחרי כל
                    # חיתוך, וזה נקרא מיד כרקע שקופא.
                    payload["env"] = dict(shot.env_of(u),
                                          t=round(t_abs + t, 4))
                # הלהקה: עלים, סנאי, פנס ועומק שדה. `t` של **השוט**
                # ולא של הסרט: הכוריאוגרפיה של הפיזור מתוזמנת מתחילת
                # השוט, ולא מתחילת הסרט.
                ens = getattr(shot, "ens_of", None)
                if ens is not None:
                    payload["ens"] = ens(t)
                res = await br.js(
                    "window.__frame(" + json.dumps(json.dumps(payload)) + ")")
                if not isinstance(res, str) or res == "err":
                    raise RuntimeError(f"רנדור נכשל בסצנה {shot.key} פריים {i}")
                ap = json.loads(res)
                applied_min = min(applied_min, ap["A"], ap["B"])
                morph_max = max(morph_max, ap.get("MA", 0), ap.get("MB", 0))
                if probe:
                    # צילום מסך ולא toDataURL של הקנבס: הרקע, הכתוביות
                    # ותגיות השם הן DOM, ו-toDataURL לא רואה אותן בכלל.
                    p = out_mp4.parent / f"probe_{shot.key}.jpg"
                    p.write_bytes(await br.shot())
                    probes.append(p)
                else:
                    enc.add_jpeg(await br.shot())
                frames_done += 1
                if on_progress and frames_done % fps == 0:
                    on_progress(frames_done, total)
            scene_log.append({
                "key": shot.key, "caption": shot.cap, "proves": shot.proves,
                "seconds": shot.secs, "frames": n,
                "min_bones_posed": applied_min,
                "max_shapes_active": morph_max,
            })
            t_abs += shot.secs
    finally:
        if enc is not None:
            enc.close()
        await br.close()
        srv.shutdown()
        shutil.rmtree(stage, ignore_errors=True)

    rep = {
        "task": task, "tag": tag,
        "when": time.strftime("%Y-%m-%d %H:%M:%S"),
        "characters": [
            {"name": r["name"], "bones": r["mesh"]["bones"],
             "vertices": r["mesh"]["vertices"], "controls": len(r["controls"])
             if isinstance(r.get("controls"), (list, dict)) else None}
            for r in (rig_a, rig_b)],
        "viewer_info": info,
        "cast": list(cast),
        "env": ({"layers_loaded": env_on,
                 "baked_once": bool(env_manifest.get("baked_once")),
                 "sun": env_manifest.get("sun"),
                 "shadow": env_manifest.get("shadow"),
                 "loop_sec": env_manifest.get("loop_sec")}
                if env_manifest else None),
        "ensemble": ({"leaves_loaded": ens_on,
                      "shots": [s.key for s in shots
                                if getattr(s, "ens_of", None) is not None]}
                     if ens_on else None),
        "scenes": scene_log,
        "fps": fps, "width": width, "height": height, "supersample": ss,
        "render_sec": round(time.time() - t0, 1),
        "probe": probe,
        "probes": [str(p) for p in probes],
    }
    if not probe:
        rep["mp4"] = str(out_mp4)
        rep["seconds"] = round(frames_done / fps, 2)
        rep["size_mb"] = round(out_mp4.stat().st_size / 1048576, 2)
        rep.update(attach_audio(out_mp4, shots, rep["seconds"]))
    return rep


def soundtrack_cues(shots: list[Shot]) -> list[tuple[float, object]]:
    """(זמן בסרטון, Track) לכל קטע דיבור שיש לו הקלטה.

    הזמן הגלובלי הוא **תחילת הסצנה בציר הזמן** ועוד תחילת חלון
    הדיבור בתוכה. חישוב לפי מספרי הפריימים ולא לפי `secs` מצטבר:
    המקודד עובד בפריימים שלמים, וצבירת שברי שנייה מזיזה את הקול
    ביחס לתמונה בסוף סרטון ארוך - סחיפה שמצטברת בשקט.
    """
    cues: list[tuple[float, object]] = []
    t0 = 0.0
    for shot in shots:
        for fn in (shot.a, shot.b):
            spk = getattr(fn, "speech", None)
            tr = getattr(fn, "track", None)
            if spk is None or tr is None or not spk.windows:
                continue
            cues.append((round(t0 + spk.windows[0][0], 4), tr))
        t0 += shot.secs
    return cues


def attach_audio(out_mp4: Path, shots: list[Shot], seconds: float) -> dict:
    """בונה פס קול מההקלטות וממזג אותו לסרטון.

    נכשל **ברכות**: סרטון בלי קול הוא עדיין סרטון, וקריסה כאן
    הייתה מאבדת רנדור של כמה דקות בגלל שלב של שבריר שנייה.
    """
    try:
        from rig import voice as V                   # noqa: PLC0415
        cues = soundtrack_cues(shots)
        if not cues:
            return {"audio": None, "audio_cues": 0}
        wav = out_mp4.with_suffix(".wav")
        V.write_wav(V.mix(cues, seconds), wav)
        tmp = out_mp4.with_name(out_mp4.stem + "_snd.mp4")
        V.mux(out_mp4, wav, tmp)
        tmp.replace(out_mp4)
        return {"audio": str(wav), "audio_cues": len(cues),
                "size_mb": round(out_mp4.stat().st_size / 1048576, 2)}
    except Exception as exc:                          # noqa: BLE001
        return {"audio": None, "audio_error": f"{type(exc).__name__}: {exc}"}


def _cycle_pose(lib_q: dict, order: list[str], u: float) -> dict:
    """מחזיר פוזה ממוזגת לפי מיקום במחזור הפוזות, עם החזקה קצרה על
    כל פוזה ומעבר חלק ביניהן."""
    m = len(order)
    x = u * m
    i = min(m - 1, int(x))
    j = (i + 1) % m
    f = x - i
    hold = 0.45                      # 45% מהקטע הדמות עומדת בפוזה
    w = 0.0 if f < hold else smooth((f - hold) / (1 - hold))
    return blend_q(lib_q[order[i]], lib_q[order[j]], w)


# ------------------------------------------------------------------ CLI

def main(argv=None):
    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(
        description="סרטון הדגמה של לוקאס ומאיה עם היכולות החדשות")
    ap.add_argument("--task", type=int, default=1)
    ap.add_argument("--title", default="")
    ap.add_argument("--dir", default=str(RIG_DIR))
    ap.add_argument("--out", default="")
    ap.add_argument("--probe", action="store_true",
                    help="תמונת בדיקה אחת לכל סצנה, בלי רנדור סרטון")
    ap.add_argument("--fps", type=int, default=FPS)
    ap.add_argument("--width", type=int, default=WIDTH)
    ap.add_argument("--height", type=int, default=HEIGHT)
    ap.add_argument("--ss", type=int, default=2,
                    help="דגימת-על ברנדור (1=כבוי)")
    a = ap.parse_args(argv)

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    out = Path(a.out) if a.out else OUT_DIR / f"task{a.task:02d}_lucas_maya.mp4"

    def prog(i, t):
        print(f"  פריים {i}/{t}", flush=True)

    rep = asyncio.run(produce(out, Path(a.dir), task=a.task, title=a.title,
                              probe=a.probe, fps=a.fps, width=a.width,
                              height=a.height, on_progress=prog, ss=a.ss))
    (out.with_suffix(".json")).write_text(
        json.dumps(rep, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"\n=== סרטון הדגמה · TASK {rep['task']:02d} ===")
    for s in rep["scenes"]:
        print(f"  {s['key']:10s} {s['seconds']:4.1f}ש  "
              f"עצמות בפוזה: {s['min_bones_posed']:3d}  {s['proves']}")
    if rep.get("mp4"):
        print(f"\n{rep['seconds']}ש · {rep['size_mb']}MB · "
              f"רנדור {rep['render_sec']}ש\n{rep['mp4']}")
    else:
        for p in rep["probes"]:
            print("  " + p)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
