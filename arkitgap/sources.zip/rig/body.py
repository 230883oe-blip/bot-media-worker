# -*- coding: utf-8 -*-
"""TASK 06 - משחק גוף מלא. כל שוט מייצר הופעה גופנית **מכוונת**.

=== הדרישה, ומה היא באמת אומרת ===

    Every dialogue shot must generate intentional body performance.
    Control: weight distribution, shoulders, spine, head, hands,
    fingers, elbows, hips, feet.
    Gestures must have a semantic reason.
    Never use random hand waving merely to make the character appear
    animated. Every major gesture must support the character's intention.

שתי השורות האחרונות הן העיקר, והן **אכיפה ולא כוונה טובה**:

* `Gesture` בלי `reason` זורק `ValueError` בבנייה. אי אפשר ליצור
  מחווה בלי לכתוב מה היא אומרת. זה לא תיעוד - זה שער.
* `Gesture` שסוגה אינו ברשימת הסוגים שהכוונה מרשה נדחה גם הוא.
  "מנפנפת ידיים כדי שתיראה מונפשת" אינו סוג, ולכן אי אפשר לבקש אותו.
* `BodyActor` **אינו** מוסיף תנועת יד משלו. כל מה שהידיים עושות
  מגיע מרשימת מחוות שעברה את שני השערים האלה. תנועה בלי מקור היא
  בדיוק מה שהדרישה אוסרת.

=== למה חלוקת משקל היא הציר, ולא עוד בקרה ===

עד TASK 05 הגוף היה שלוש בקרות עמוד שדרה ושלוש אגן. דמות עם משקל
מחולק שווה בין שתי רגליים, כתפיים סימטריות וכפות רגליים מקבילות,
נקראת בעין כבובת ראווה - גם אם הפנים מושלמות. אדם אמיתי *תמיד*
נשען יותר על רגל אחת, ומעביר אותה מדי כמה שניות.

חלוקת המשקל מייצרת שרשרת שלמה, ו**כל חוליה מתעכבת אחרי הקודמת**:

    משקל -> אגן (הטיה + הזזה) -> עמוד שדרה (קיזוז) -> כתפיים
    (קיזוז הפוך לאגן) -> ראש (יישור לאופק)

העיכוב הוא מה שהופך את זה לתנועה ולא להחלפת פוזה. בגוף אמיתי
האגן מוביל והראש מגיע אחרון, וזה בדיוק מה ש-`_lag` עושה.

=== ארבע הפאזות של מחווה ===

מחווה אנושית אינה "יד למעלה ל-0.6 שניות". היא
`preparation -> stroke -> hold -> retraction`, וה-**stroke** (הרגע
החד) חייב ליפול על המילה המודגשת. מחווה שה-stroke שלה נופל אחרי
המילה נראית כמו דיבוב לא מסונכרן, גם כשהצורה נכונה לחלוטין.
"""
from __future__ import annotations

import math
import sys
from dataclasses import dataclass, field

from rig import controls as C

# ==================================================== סוגי מחווה
#
# הטקסונומיה היא של McNeill (1992), והיא לא מובאת כאן לקישוט: היא
# הדבר שהופך "מחווה" לקטגוריה סמנטית שאפשר לאמת מולה. מחווה חייבת
# להשתייך לאחד מאלה, ולכל אחד יש תנאי שימוש שנבדק בקוד.

KINDS: dict[str, str] = {
    "deictic":    "הצבעה על משהו ממשי או מופשט - 'זה', 'אתה', 'שם'",
    "beat":       "הדגשת מילה. התנועה הקטנה והמהירה, נושאת קצב ולא תוכן",
    "iconic":     "מצייר צורה או פעולה שהמילה מתארת",
    "metaphoric": "מצייר מושג מופשט - משקל, מרחק, איזון",
    "adaptor":    "נגיעה עצמית. אינה מופנית לזולת - היא ויסות של מתח",
    "emblem":     "מחווה מוסכמת שעומדת בפני עצמה - עצירה, הסכמה",
    "regulator":  "מנהלת את התור בשיחה - 'רגע', 'תמשיך'",
}

#: מה כל כוונה **רשאית** לעשות בידיים. זה הלב של "every major gesture
#: must support the character's intention": רשימה סגורה לכל כוונה,
#: ומה שלא ברשימה נדחה בבנייה ולא מסונן אחר כך.
ALLOWED: dict[str, tuple[str, ...]] = {
    "withhold": ("adaptor", "beat"),
    "test":     ("deictic", "beat", "regulator"),
    "seek":     ("deictic", "beat", "regulator", "metaphoric"),
    "defend":   ("emblem", "adaptor", "beat"),
    "appease":  ("metaphoric", "beat", "adaptor"),
    "assert":   ("deictic", "beat", "emblem"),
    "connect":  ("metaphoric", "iconic", "beat"),
    "withdraw": ("adaptor",),
    "conceal":  ("adaptor",),
    "observe":  (),                      # מתבוננת - הידיים דוממות
}


class GestureError(ValueError):
    """מחווה שאין לה סיבה סמנטית, או שאינה תומכת בכוונה."""


# ==================================================== מחווה

@dataclass
class Gesture:
    """מחווה אחת, עם כל מה שצריך כדי להצדיק אותה.

    `reason` ו-`kind` אינם אופציונליים. זו האכיפה של
    "Never use random hand waving".
    """
    kind: str
    reason: str                    # מה המחווה *אומרת*. חובה.
    shape: str                     # הצורה הפיזית (ראה `SHAPES`)
    hand: str = "R"
    amount: float = 0.6
    stroke: float = 0.0            # רגע ההדגשה, שניות מתחילת השוט
    anchor: str = ""               # המילה שה-stroke נופל עליה
    prep: float = 0.22             # הכנה - היד יוצאת לדרך
    hold: float = 0.18             # החזקה אחרי ההדגשה
    retract: float = 0.45          # חזרה למנוחה
    intention: str = ""            # הכוונה שהולידה אותה
    #: **TASK 07 - אנטיציפציה.** היד נסוגה מעט לפני שהיא יוצאת.
    #: זה הדבר שהופך "היד עלתה" ל"היד *נזרקה*", וזו גם הסיבה
    #: שהעין מספיקה לקרוא את המחווה: הנסיגה מכינה אותה.
    anticipate: float = 0.16       # שבר מהמהלך, בכיוון ההפוך
    #: **TASK 07 - follow-through.** החריגה מעבר לשיא וההתיישבות
    #: אחריה. יד שעוצרת בדיוק על השיא עוצרת כמו מכונה.
    overshoot: float = 0.14

    def __post_init__(self) -> None:
        if self.kind not in KINDS:
            raise GestureError(
                f"סוג מחווה לא מוכר: {self.kind!r}. "
                f"מותר: {', '.join(sorted(KINDS))}")
        if not (self.reason or "").strip():
            raise GestureError(
                f"מחווה {self.kind!r} בלי סיבה סמנטית. כל מחווה חייבת "
                "לומר למה היא קיימת - זו הדרישה של TASK 06.")
        if self.shape not in SHAPES:
            raise GestureError(f"צורה לא מוכרת: {self.shape!r}")
        if self.hand not in ("L", "R"):
            raise GestureError(f"יד לא חוקית: {self.hand!r}")
        if self.intention:
            ok = ALLOWED.get(self.intention)
            if ok is None:
                raise GestureError(f"כוונה לא מוכרת: {self.intention!r}")
            if self.kind not in ok:
                raise GestureError(
                    f"מחווה {self.kind!r} אינה תומכת בכוונה "
                    f"{self.intention!r}. מותר שם: "
                    f"{', '.join(ok) if ok else 'כלום - הידיים דוממות'}")
        # מחווה גדולה שאין לה עוגן במילה היא מחווה שה-stroke שלה
        # צף. beat ו-adaptor פטורים: beat הוא קצב, ו-adaptor אינו
        # מופנה לזולת ולכן אינו צריך להיתלות במילה.
        if self.amount >= 0.45 and self.kind not in ("beat", "adaptor") \
                and not self.anchor:
            raise GestureError(
                f"מחווה {self.kind!r} בעוצמה {self.amount} בלי מילת עוגן. "
                "ה-stroke חייב ליפול על מילה, אחרת זו תנועה בלי סיבה.")

    # ---- ציר זמן

    @property
    def start(self) -> float:
        return self.stroke - self.prep

    @property
    def lead(self) -> float:
        """אורך הנסיגה המכינה (TASK 07). 0 כשאין אנטיציפציה."""
        return self.prep * 0.42 if self.anticipate > 0.0 else 0.0

    @property
    def settle(self) -> float:
        """אורך ההתיישבות אחרי החריגה (TASK 07).

        היא יושבת **בתוך** ההחזקה ולא מאריכה את המחווה: החריגה
        קורית ברגע ההדגשה, והיד מתיישבת על הפוזה בזמן שהיא מוחזקת.
        """
        if self.overshoot <= 0.0:
            return 0.0
        return min(self.hold * 0.80, max(0.05, self.retract * 0.30))

    @property
    def opens(self) -> float:
        """הרגע שבו המחווה **מתחילה לזוז** - כולל הנסיגה המכינה."""
        return self.start - self.lead

    @property
    def end(self) -> float:
        # **ה-0.06 אינו קוסמטי.** זה אורך ההדגשה עצמה, והוא היה חסר
        # כאן: הסוף חושב כ-`stroke+hold+retract` בעוד ההחזרה מתחילה
        # ב-`stroke+0.06+hold`, ולכן העקומה נקטעה 60 מילישניות לפני
        # שסיימה - עם ערך שאינו אפס. ברמת העין זה לא נראה, אבל
        # `m_ease_out` תפסה את זה מיד: מהירות שאינה אפס בכניסה
        # למנוחה. ease-out שבור הוא בדיוק מה ש-TASK 07 בא לתקן.
        return self.stroke + 0.06 + self.hold + self.retract

    def phase(self, t: float) -> str:
        if t < self.opens:
            return "idle"
        if t < self.start:
            return "anticipation"
        if t < self.stroke:
            return "preparation"
        if t < self.stroke + 0.06:
            return "stroke"
        if t < self.stroke + 0.06 + self.hold:
            return "hold"
        if t < self.end:
            return "retraction"
        return "idle"

    def weight(self, t: float) -> float:
        """כמה מהצורה מופעלת ברגע t. **שלילי** בזמן הנסיגה המכינה.

        העקומה אינה סימטרית בכוונה: ההכנה רכה (ease-in), ההדגשה
        חדה, וההחזרה איטית יותר מההכנה. יד שחוזרת באותה מהירות
        שבה יצאה נראית ממוכנת - נמדד בגיליון המגע.

        **TASK 07.** שלושה עקרונות אפויים כאן, ולא מודבקים אחר כך:
        אנטיציפציה (ערך שלילי לפני ההכנה), חריגה מעבר לשיא ברגע
        ההדגשה, והתיישבות דועכת אחריה. מי שקורא רק `weight(t)`
        מקבל את שלושתם בלי לדעת עליהם.
        """
        if t <= self.opens or t >= self.end:
            return 0.0
        if t < self.start:
            # --- אנטיציפציה: היד **נסוגה** לפני שהיא יוצאת.
            u = (t - self.opens) / max(1e-6, self.lead)
            return -self.anticipate * _ease_in_out(u)
        if t < self.stroke:
            u = (t - self.start) / max(1e-6, self.prep)
            lo = -self.anticipate
            return lo + (0.82 - lo) * _ease_in_out(u)
        peak = 1.0 + self.overshoot
        if t < self.stroke + 0.06:
            u = (t - self.stroke) / 0.06
            return 0.82 + (peak - 0.82) * u   # ההדגשה - הקפיצה לשיא
        k = self.stroke + 0.06 + self.hold
        if t < k:
            sd = self.settle
            if sd > 0.0 and t < self.stroke + 0.06 + sd:
                # --- follow-through: חריגה שמתיישבת, ולא יעד חדש.
                u = (t - self.stroke - 0.06) / sd
                return 1.0 + self.overshoot * math.exp(-4.2 * u) \
                    * math.cos(math.pi * 1.5 * u)
            return 1.0
        u = (t - k) / max(1e-6, self.retract)
        return 1.0 - _ease_in_out(u)

    def overshooting(self, t: float) -> bool:
        """האם ברגע זה היד **מעבר** לפוזה שלה (follow-through)."""
        return self.weight(t) > 1.0 + 1e-9

    def as_dict(self) -> dict:
        return {"kind": self.kind, "reason": self.reason,
                "shape": self.shape, "hand": self.hand,
                "amount": round(self.amount, 3),
                "stroke": round(self.stroke, 3), "anchor": self.anchor,
                "intention": self.intention,
                "window": [round(self.start, 3), round(self.end, 3)]}


def _ease_out(u: float) -> float:
    u = max(0.0, min(1.0, u))
    return 1.0 - (1.0 - u) ** 2


def _ease_in_out(u: float) -> float:
    u = max(0.0, min(1.0, u))
    return u * u * (3.0 - 2.0 * u)


# ==================================================== צורות
#
# כל צורה היא היסט על פוזת המנוחה, ולא ערך מוחלט - זה הלקח שנרשם
# ב-showreel אחרי שיד "הורמה" לאופק כמו מחסום חניה. המפתחות הם
# שמות בקרות בלי הסיומת של הצד.

SHAPES: dict[str, dict] = {
    # --- deictic
    "point_near": {"arm_down": -0.34, "arm_fwd": 0.30, "elbow": 0.42,
                   "elbow_out": 0.18, "curl_index": -0.25,
                   "curl_middle": 0.72, "curl_ring": 0.80,
                   "curl_pinky": 0.84, "curl_thumb": 0.45,
                   "wrist_pitch": 0.12},
    "point_self": {"arm_down": -0.22, "arm_fwd": 0.46, "elbow": 0.70,
                   "elbow_out": -0.20, "curl_index": -0.20,
                   "curl_middle": 0.70, "curl_ring": 0.78,
                   "curl_pinky": 0.82, "wrist_pitch": -0.25},
    # --- beat
    "beat_small": {"arm_down": -0.14, "arm_fwd": 0.12, "elbow": 0.36,
                   "wrist_pitch": 0.26, "spread": 0.10},
    "beat_firm":  {"arm_down": -0.22, "arm_fwd": 0.18, "elbow": 0.44,
                   "wrist_pitch": 0.40, "fist": 0.30},
    # --- metaphoric
    "offer_palm": {"arm_down": -0.30, "arm_fwd": 0.28, "elbow": 0.34,
                   "elbow_out": 0.22, "spread": 0.42, "wrist_pitch": 0.34,
                   "curl_thumb": -0.15},
    "weigh":      {"arm_down": -0.26, "arm_fwd": 0.22, "elbow": 0.52,
                   "spread": 0.30, "wrist_pitch": 0.46},
    "push_away":  {"arm_down": -0.30, "arm_fwd": 0.44, "elbow": 0.24,
                   "spread": 0.35, "wrist_pitch": 0.62},
    # --- iconic
    "shape_round": {"arm_down": -0.28, "arm_fwd": 0.30, "elbow": 0.48,
                    "spread": 0.26, "curl_index": 0.30, "curl_middle": 0.30,
                    "curl_ring": 0.32, "curl_pinky": 0.34},
    # --- adaptor
    "touch_neck": {"arm_down": -0.20, "arm_fwd": 0.26, "elbow": 0.84,
                   "elbow_out": -0.28, "curl_index": 0.35,
                   "curl_middle": 0.35, "wrist_pitch": -0.30},
    "rub_arm":    {"arm_down": -0.10, "arm_fwd": 0.24, "elbow": 0.66,
                   "elbow_out": -0.34, "curl_index": 0.42,
                   "curl_middle": 0.44, "curl_ring": 0.42},
    "clasp":      {"arm_down": -0.12, "arm_fwd": 0.30, "elbow": 0.72,
                   "elbow_out": -0.22, "fist": 0.22, "spread": -0.25},
    # --- emblem
    "stop_palm":  {"arm_down": -0.34, "arm_fwd": 0.40, "elbow": 0.30,
                   "spread": 0.40, "wrist_pitch": 0.70},
    "guard":      {"arm_down": -0.20, "arm_fwd": 0.38, "elbow": 0.64,
                   "elbow_out": -0.25, "fist": 0.26, "spread": -0.20},
    # --- regulator
    "hold_on":    {"arm_down": -0.26, "arm_fwd": 0.24, "elbow": 0.56,
                   "curl_index": -0.22, "curl_middle": 0.68,
                   "curl_ring": 0.74, "curl_pinky": 0.78,
                   "wrist_pitch": 0.30},
    "rest":       {},
}


def shape_ctl(g: Gesture, w: float) -> dict:
    """ההיסטים שהמחווה מוסיפה לפוזה ברגע שמשקלה w."""
    out: dict[str, float] = {}
    for k, v in SHAPES.get(g.shape, {}).items():
        out[f"{k}_{g.hand}"] = v * g.amount * w
    return out


# ---------------------------------------------- TASK 07: Overlapping Action
#
# **הפיגור הוא לפי מרחק מהגוף, וזה לא שרירותי.** תנועה של זרוע
# מתחילה בכתף, והאצבעות הן הדבר האחרון שמגיע - כי הן בקצה השרשרת
# ולהן המסה הקטנה ביותר. ההפרש הזה הוא מה שהופך יד שזזה ליד
# ש*נזרקת*; בלי הפיגור כל המפרקים מגיעים לפוזה באותו פריים, והעין
# קוראת את זה כבובת עץ. הערכים בשניות.

DISTAL_LAG: dict[str, float] = {
    "arm_down": 0.0, "arm_fwd": 0.0, "arm_twist": 0.0,
    "elbow": 0.025, "elbow_out": 0.025,
    "wrist_pitch": 0.055, "wrist_yaw": 0.055,
    "spread": 0.080, "fist": 0.080,
    "curl_thumb": 0.095, "curl_index": 0.095, "curl_middle": 0.105,
    "curl_ring": 0.110, "curl_pinky": 0.120,
}


def shape_ctl_at(g: Gesture, t: float) -> dict:
    """ההיסטים של המחווה ברגע t, **עם פיגור לפי מרחק מהגוף**.

    זו `shape_ctl` עם Overlapping Action: כל בקרה נדגמת בזמן שלה,
    ולכן שיא התנועה של האצבעות נופל כעשירית שנייה אחרי שיא הכתף.
    """
    out: dict[str, float] = {}
    for k, v in SHAPES.get(g.shape, {}).items():
        w = g.weight(t - DISTAL_LAG.get(k, 0.06))
        if w == 0.0:
            continue
        out[f"{k}_{g.hand}"] = v * g.amount * w
    return out


# ==================================================== יציבה

@dataclass
class Stance:
    """חלוקת המשקל והיציבה הבסיסית של השוט.

    `weight` הוא הציר: -1 שמאל, +1 ימין. השאר נגזר ממנו בשכבת
    הבקרות (`controls.evaluate`), ולכן כל קורא מקבל contrapposto
    נכון בלי לדעת עליו.
    """
    weight: float = 0.35          # על איזו רגל נשענים
    drop: float = 0.0             # כריעה קלה - נפילת מרכז הכובד
    lean: float = 0.0             # קדימה חיובי
    hips_shift: float = 0.0       # הזזה צידית של האגן
    stance_width: float = 0.10    # פיסוק
    shoulder_up: float = 0.0      # מתח בכתפיים (שתיהן)
    shoulder_fwd: float = 0.0     # התכנסות קדימה
    shoulder_tilt: float = 0.0    # הפרש בין הכתפיים
    chest_open: float = 0.0       # פתיחת חזה - ביטחון
    #: **פוזת המנוחה של הזרועות.** זו אינה מחווה - זו היציבה, ולכן
    #: מקומה כאן. נתפס ברנדור של TASK 06: `arm_down=0.93` השאיר את
    #: הזרועות פרושות כ-25° מהאופק, עם מרפקים ישרים לגמרי ואצבעות
    #: פרושות כמו מסרק. יד רפויה של אדם עומד נוגעת כמעט בירך, המרפק
    #: כפוף מעט, והאצבעות **מתעגלות מעצמן** - אצבע ישרה דורשת מאמץ.
    arm_rest: float = 0.99        # כמה הזרוע צמודה לגוף
    elbow_rest: float = 0.13      # כיפוף המרפק במנוחה
    finger_rest: float = 0.17     # התעגלות האצבעות במנוחה
    settle: float = 0.9           # שניות עד שהעברת משקל מתייצבת
    sway: float = 0.6             # כמה מתנדנדים במקום (0 = קפוא)
    note: str = ""

    def as_dict(self) -> dict:
        return {k: (round(v, 4) if isinstance(v, float) else v)
                for k, v in self.__dict__.items()}


def stance_for(intention: str, valence: float, arousal: float,
               control: float, hides: bool = False,
               want: float = 0.6, bias: float = 0.0,
               side: float = 1.0) -> Stance:
    """היציבה נגזרת מהכוונה ומהצירים הרגשיים - לא משם הרגש.

    זה אותו עיקרון של `emotion.build_body`, והוא נשמר בכוונה: כעס
    ופחד שניהם שליליים וערים, ויוצאים הפוכים לגמרי - הכועס נפתח
    ומעביר משקל קדימה, המפוחד מתכנס ואחורה. אם זה היה נגזר מהשם,
    כל רגש חדש היה דורש שורה חדשה.
    """
    st = Stance()
    closed = (1.0 - control) * (0.5 - 0.5 * valence)     # 0..1

    # **על איזו רגל נשענים - `side`, ולא bias.** בגרסה הראשונה
    # הכיוון נגזר מסימן ה-bias, ו-bias הוא אפס או חיובי כמעט תמיד
    # (הוא עולה רק מהסתרה). התוצאה שנמדדה: **כל שמונה התרחישים
    # יצאו נשענים על אותה רגל**, כלומר contrapposto קיים בקוד ולא
    # קיים בתמונה. הצד הוא תכונה של הדמות (`seed`), לא של הרגש.
    d = 1.0 if side >= 0 else -1.0
    st.weight = round(d * (0.58 - 0.26 * closed), 4)
    # ה-bias מוסיף **הטיה** על הצד הנבחר ולא קובע אותו: גוף שמסתיר
    # משהו מסיט מעט את המשקל, וזה מה שמסגיר צד.
    st.weight = round(st.weight - bias * 0.14 * d, 4)
    st.drop = round(0.12 * closed - 0.06 * control, 4)
    st.lean = round(-0.22 * closed + 0.10 * valence, 4)
    st.shoulder_up = round(0.34 * (1.0 - control) * arousal, 4)
    st.shoulder_fwd = round(0.40 * closed, 4)
    st.chest_open = round(0.30 * control + 0.22 * max(0.0, valence), 4)
    st.sway = round(0.35 + 0.55 * (1.0 - arousal), 4)
    st.settle = round(1.35 - 0.70 * arousal, 4)
    st.stance_width = round(0.06 + 0.16 * control, 4)

    if intention in ("assert", "test"):
        st.lean += 0.14
        st.chest_open += 0.18
        st.shoulder_fwd -= 0.16
        st.stance_width += 0.10          # רגליים רחבות = עמידה איתנה
        st.note = "עמידה פתוחה: משקל קדימה, חזה פתוח, רגליים רחבות"
    elif intention in ("defend", "withdraw"):
        st.lean -= 0.20
        st.shoulder_up += 0.22
        st.shoulder_fwd += 0.24
        st.stance_width -= 0.05
        st.note = "התכנסות: משקל אחורה, כתפיים עולות וסוגרות"
    elif intention == "appease":
        st.drop += 0.10                   # מקטינה את עצמה
        st.shoulder_up += 0.14
        st.shoulder_tilt += 0.18
        st.note = "הקטנה עצמית: ירידה קלה וכתף אחת מורמת"
    elif intention == "connect":
        st.lean += 0.18
        st.shoulder_fwd -= 0.08
        st.note = "נטייה קדימה - קרבה, לא התכנסות"
    elif intention == "seek":
        st.lean += 0.12
        st.sway += 0.18
        st.note = "משקל נע - חוסר מנוחה של מי שמחפשת תשובה"
    elif intention in ("withhold", "observe"):
        st.sway *= 0.45                   # שקט הוא גם מיעוט תנועה
        st.note = "גוף דומם - המיעוט הוא עצמו המסר"

    if hides:
        # **הסתרה מקפיאה את הגוף.** זה הסימן האמין ביותר, והוא
        # ההפך האינטואיטיבי: מי שמסתיר לא מרבה בתנועה - הוא *ממעיט*
        # בה, כי כל תנועה עלולה להסגיר. לכן sway יורד ולא עולה.
        st.sway *= 0.55
        st.shoulder_up += 0.16
        st.weight *= 0.80                 # לא מעז להישען לגמרי
        st.note = (st.note + " · " if st.note else "") + \
            "גוף מוחזק - הסתרה ממעיטה בתנועה ולא מרבה בה"

    st.weight = round(max(-0.95, min(0.95, st.weight * (0.6 + 0.4 * want))), 4)
    st.hips_shift = round(st.weight * 0.55, 4)
    for k in ("drop", "lean", "shoulder_up", "shoulder_fwd",
              "shoulder_tilt", "chest_open"):
        setattr(st, k, round(max(-1.0, min(1.0, getattr(st, k))), 4))
    st.stance_width = round(max(0.0, min(0.45, st.stance_width)), 4)
    return st


# ==================================================== בחירת מחוות
#
# הטבלה היא **מכוונה למחווה**, לא מרגש למחווה: אותו כעס מוליד
# הצבעה כשהכוונה היא לקבוע עובדה, ונגיעה עצמית כשהכוונה להסתיר.

_PLAYBOOK: dict[str, list[tuple[str, str, str]]] = {
    #                kind         shape         reason
    "assert":   [("deictic", "point_near",
                  "מצביעה על מה שהיא קובעת - ההצבעה היא הטיעון"),
                 ("beat", "beat_firm",
                  "מדגישה את המילה שנושאת את העובדה")],
    "test":     [("regulator", "hold_on",
                  "עוצרת את התור כדי שהתשובה תגיע ממנו ולא ממנה"),
                 ("beat", "beat_small", "מסמנת את השאלה בקצה המשפט")],
    "seek":     [("deictic", "point_near",
                  "מצביעה לכיוון מה שהיא מנסה להבין"),
                 ("metaphoric", "offer_palm",
                  "כף יד פתוחה - בקשה למידע, לא דרישה")],
    "defend":   [("emblem", "guard",
                  "חוצצת בין עצמה לבין מה שנאמר")],
    "appease":  [("metaphoric", "offer_palm",
                  "פתיחת כף יד - אני לא מאיימת"),
                 ("beat", "beat_small", "מרככת את סוף המשפט")],
    "connect":  [("metaphoric", "offer_palm",
                  "מושיטה את המילה, לא רק אומרת אותה")],
    "withhold": [("adaptor", "clasp",
                  "אוחזת בידיה - ויסות של מה שהיא לא אומרת")],
    "conceal":  [("adaptor", "touch_neck",
                  "נגיעה בצוואר - ויסות המתח של ההסתרה")],
    "withdraw": [("adaptor", "rub_arm",
                  "מחליקה על הזרוע - הרגעה עצמית בזמן נסיגה")],
    "observe":  [],
}


def _words(text: str) -> list[str]:
    return [w for w in (text or "").replace("...", " ").split() if w.strip()]


def stressed_word(text: str) -> tuple[int, str]:
    """(אינדקס, מילה) - המילה שנושאת את ההדגשה במשפט.

    הכלל פשוט ונבדק: מילת שאלה או מילת היפוך בפתיחה גוררת את
    ההדגשה אליה ("**רגע**... אז זה היה אתה?"), ואחרת ההדגשה נופלת
    על המילה הארוכה ביותר במחצית השנייה - שם יושב בעברית גרעין
    המידע החדש. מילת עוגן היא מה שמעגן את ה-stroke, ולכן מספיק
    שתהיה *סבירה*; מה שאסור הוא שלא תהיה בכלל.
    """
    ws = _words(text)
    if not ws:
        return -1, ""
    head = {"רגע", "נו", "באמת", "אז", "למה", "מה", "איך", "מי", "כן", "לא"}
    first = ws[0].strip("?!.,…")
    if first in head:
        return 0, ws[0]
    half = len(ws) // 2
    tail = ws[half:] or ws
    best = max(range(len(tail)), key=lambda i: len(tail[i].strip("?!.,…")))
    return half + best, tail[best]


def word_time(text: str, index: int, t0: float, t1: float) -> float:
    """מתי המילה ה-index נאמרת, בין t0 ל-t1.

    החלוקה היא **לפי אורך האותיות ולא שווה**, כי מילה ארוכה לוקחת
    יותר זמן. זה קירוב - אבל כשיש מסלול שמע (`rig.voice`) הקורא
    מעביר את הזמן האמיתי ישירות, והקירוב לא נכנס לתמונה בכלל.
    """
    ws = _words(text)
    if not ws or index < 0 or index >= len(ws):
        return (t0 + t1) * 0.5
    lens = [max(1, len(w.strip("?!.,…"))) for w in ws]
    tot = sum(lens)
    before = sum(lens[:index])
    return t0 + (t1 - t0) * (before + lens[index] * 0.5) / tot


def gestures_for(intention: str, line: str = "", t0: float = 0.0,
                 t1: float = 1.6, want: float = 0.6, arousal: float = 0.5,
                 control: float = 0.5, hides: bool = False,
                 anchor_time: float | None = None) -> list[Gesture]:
    """רשימת המחוות של השוט. כולן עוברות את שערי `Gesture`.

    **אם אין כוונה שמולידה מחווה - מוחזרת רשימה ריקה.** זה המצב
    הנכון ב-`observe` ולעיתים ב-`withhold`, והוא עדיף בהרבה על
    מחווה שהומצאה כדי שיהיה מה להראות.
    """
    plays = _PLAYBOOK.get(intention, [])
    if not plays:
        return []

    idx, word = stressed_word(line)
    at = anchor_time if anchor_time is not None else word_time(line, idx, t0, t1)
    # רצון חלש ועוררות נמוכה = מחווה קטנה. מחווה גדולה בלי דחף
    # מאחוריה היא בדיוק "ניפנוף כדי שתיראה מונפשת".
    base = (0.34 + 0.46 * want) * (0.62 + 0.38 * arousal)
    if hides:
        base *= 0.72             # מי שמסתיר ממעיט גם במחווה

    out: list[Gesture] = []
    hand = "R" if control >= 0.35 else "L"
    for i, (kind, shape, reason) in enumerate(plays):
        amt = base * (1.0 if i == 0 else 0.62)
        if amt < 0.10:
            continue
        # המחווה הראשונה מעוגנת במילה המודגשת. `beat` ו-`adaptor`
        # פטורים מעוגן: beat הוא קצב, ו-adaptor אינו מופנה לזולת.
        #
        # **שני באגים נתפסו כאן ב-05/10, ושניהם היו קריסה מלאה
        # של בניית השוט (`GestureError`):**
        #
        # 1. דמות שאינה מדברת בשוט - מצב לגיטימי לגמרי בדיאלוג של
        #    שניים. `stressed_word("")` מחזיר מילה ריקה, והמחווה
        #    נדחתה בחריגה במקום שלא להיווצר. ההתנהגות הנכונה כתובה
        #    בראש הפונקציה: לא להמציא מחווה. הידיים דוממות,
        #    והיציבה והנשימה ממשיכות לרוץ כרגיל.
        #
        # 2. **המחווה השנייה לא קיבלה עוגן לעולם.** זה הסתדר במקרה
        #    בכל הכוונות שהיו בשימוש, כי שם המחווה השנייה היא
        #    `beat`. ב-`seek` היא `metaphoric`, ולכן הכוונה הזאת
        #    קרסה **גם עם טקסט מלא** - היא פשוט לא נבחרה עד היום.
        #    הפתרון אינו לפטור אותה מעוגן אלא לתת לה עוגן נכון:
        #    ה-stroke השני נופל מאוחר יותר במשפט, ולכן הוא נתלה על
        #    **המילה שאחרי** המודגשת.
        if kind in ("beat", "adaptor"):
            anc = ""
        elif i == 0:
            anc = word
        else:
            ws = _words(line)
            anc = ws[min(len(ws) - 1, idx + 1)] if ws else ""
        if not anc and kind not in ("beat", "adaptor"):
            continue
        stroke = at if i == 0 else min(t1, at + 0.42 + 0.18 * i)
        g = Gesture(kind=kind, reason=reason, shape=shape, hand=hand,
                    amount=round(min(0.95, amt), 4),
                    stroke=round(stroke, 4), anchor=anc,
                    prep=round(0.30 - 0.12 * arousal, 4),
                    hold=round(0.12 + 0.26 * control, 4),
                    retract=round(0.55 - 0.18 * arousal, 4),
                    intention=intention)
        out.append(g)
    return out


# ==================================================== השחקן

def _lag(value: float, t: float, delay: float, tau: float) -> float:
    """ערך שמגיע ליעדו **אחרי** עיכוב, בעקומה אקספוננציאלית.

    זו השרשרת: האגן מקבל delay=0, החזה 0.07, הכתפיים 0.12, הראש
    0.18. העין קוראת את ההפרשים האלה כ"גוף אחד שזז", ואת היעדרם
    כ"כל העצמות קפצו יחד".
    """
    u = t - delay
    if u <= 0.0:
        return 0.0
    return value * (1.0 - math.exp(-u / max(1e-3, tau)))


@dataclass
class BodyActor:
    """פותר את כל הגוף בזמן t. זה מה שהסצנה קוראת לו בכל פריים."""
    stance: Stance
    gestures: list[Gesture] = field(default_factory=list)
    seed: float = 0.0
    breathe: float = 1.0
    shift_at: float = 0.0      # מתי העברת המשקל מתחילה
    #: החלפת רגל באמצע השוט. אדם שעומד יותר מכמה שניות מחליף רגל,
    #: וזה אחד הדברים שהכי מסגירים דמות קפואה.
    reshift: float = 0.0       # 0 = אין החלפה

    def __post_init__(self) -> None:
        for g in self.gestures:
            if not isinstance(g, Gesture):
                raise GestureError("רק אובייקטי Gesture נכנסים לשחקן - "
                                   "מילון עוקף את שערי הסיבה הסמנטית")

    # ---- רכיבים

    def weight_at(self, t: float) -> float:
        st = self.stance
        w = _lag(st.weight, t, self.shift_at, st.settle * 0.45)
        if self.reshift > 0.0 and t > self.reshift:
            # ההחלפה היא מעבר דרך האמצע, לא קפיצה.
            w += _lag(-2.0 * st.weight, t, self.reshift, st.settle * 0.55)
        # נדנוד במקום: שני גלים לא-מתואמים, אחרת זה נראה כמו מטרונום.
        s = self.seed
        w += st.sway * 0.055 * math.sin(2 * math.pi * (t * 0.21 + s))
        w += st.sway * 0.028 * math.sin(2 * math.pi * (t * 0.37 + s * 1.7))
        return round(max(-1.0, min(1.0, w)), 5)

    def breath_at(self, t: float) -> float:
        st = self.stance
        # קצב נשימה עולה עם המתח בכתפיים ועם צמצום הנדנוד.
        rate = 0.26 + 0.16 * st.shoulder_up
        return self.breathe * (0.45 * math.sin(2 * math.pi * (t * rate
                                                              + self.seed)))

    def active(self, t: float) -> list[Gesture]:
        return [g for g in self.gestures if g.opens <= t < g.end]

    # ---- TASK 07: תנועה משנית
    #
    # **מה נחשב כאן "משנית" ומה לא.** פיגור של האצבעות אחרי הכתף
    # אינו תנועה משנית - הוא Overlap של *אותה* תנועה. תנועה משנית
    # היא פעולה **אחרת** שנגררת מהראשית: כשיד אחת נזרקת קדימה,
    # הכתף הנגדית נסוגה מעט והנשימה נתפסת. זה מה שמיושם כאן, והוא
    # קטן בכוונה - משנית שגדולה כמו הראשית מתחרה בה על תשומת הלב.

    def drive(self, t: float) -> float:
        """סך פעילות הידיים ברגע t - זה האות שגורר את המשנית."""
        return sum(abs(g.weight(t)) for g in self.gestures)

    def _trail(self, t: float, lag: float = 0.13,
               tau: float = 0.11) -> float:
        """אות הגרירה: ממוצע של `drive` בחלון שמסתיים לפני t.

        בלי מצב ובלי זיכרון בין פריימים, בכוונה: רנדור מדלג על
        פריימים (גיליון מגע, בדיקות), ומסנן עם מצב היה מחזיר שם
        ערכים אחרים מאותו t - ואז הבדיקה והסרטון לא מודדים את אותו
        דבר.
        """
        s = 0.0
        for k in range(3):
            s += self.drive(t - lag - tau * k / 2.0)
        return s / 3.0

    # ---- הפתרון המלא

    def solve(self, t: float) -> dict:
        st = self.stance
        w = self.weight_at(t)
        out: dict[str, float] = {}

        # --- שרשרת המשקל. כל חוליה מאחרת אחרי קודמתה.
        out["weight_shift"] = w
        out["hips_shift"] = round(w * 0.55, 5)
        out["weight_drop"] = round(_lag(st.drop, t, 0.02, 0.35), 5)
        out["weight_fwd"] = round(_lag(st.lean, t, 0.04, 0.40), 5)
        # קיזוז העמוד מגיע **אחרי** האגן, וזה מה שמייצר את הגל.
        out["spine_side"] = round(-_lag(w * 0.26, t, 0.07, 0.30), 5)
        out["spine_twist"] = round(_lag(st.chest_open * 0.10, t, 0.09, 0.4), 5)
        out["spine_bend"] = round(_lag(-st.chest_open * 0.14
                                       + st.drop * 0.30, t, 0.05, 0.40), 5)
        out["breath"] = round(self.breath_at(t) + st.chest_open * 0.20, 5)

        # --- כתפיים. הקיזוף של הכתפיים הוא **הפוך** לזה של האגן -
        #     זה מה שמייצר את הקו ה-S של עמידה אנושית.
        tilt = st.shoulder_tilt - w * 0.22
        for s, sg in (("L", -1.0), ("R", 1.0)):
            up = st.shoulder_up + sg * tilt * 0.5
            out[f"shoulder_up_{s}"] = round(_lag(up, t, 0.12, 0.38), 5)
            out[f"shoulder_fwd_{s}"] = round(
                _lag(st.shoulder_fwd - st.chest_open * 0.35, t, 0.12, 0.42), 5)

        # --- ראש: מיושר לאופק, ומגיע אחרון בשרשרת.
        out["head_roll"] = round(_lag(-w * 0.10, t, 0.18, 0.45), 5)

        # --- רגליים. הרגל הטעונה ישרה, החופשית מתכופפת ומסתובבת
        #     החוצה. הרוחב הוא פיסוק אמיתי ולא רק זווית.
        for s, side in (("L", -1.0), ("R", 1.0)):
            free = max(0.0, -w * side)
            out[f"leg_out_{s}"] = round(st.stance_width
                                        + free * 0.10, 5)
            out[f"knee_{s}"] = round(free * 0.18 + st.drop * 0.26, 5)
            out[f"foot_turn_{s}"] = round(0.22 + free * 0.26, 5)
            out[f"foot_roll_{s}"] = round(free * 0.30, 5)
            out[f"ankle_{s}"] = round(-free * 0.06, 5)

        # --- זרועות במנוחה. זו **יציבה ולא מחווה**: היא קבועה בזמן
        #     (פרט לנשימה), ולכן היא לא יכולה להיקרא "ניפנוף". מה
        #     שאסור הוא תנועה בלי סיבה, לא פוזה.
        for s in ("L", "R"):
            out[f"arm_down_{s}"] = round(st.arm_rest, 5)
            out[f"elbow_{s}"] = round(st.elbow_rest, 5)
            # **פוזת המנוחה קבועה בזמן, בכוונה.** בגרסה הראשונה
            # `arm_fwd` היה תלוי בחלוקת המשקל ("האגן דוחף את הזרוע
            # פנימה"), וההפרש היה 0.04 - בלתי נראה בעין, אבל הוא
            # הפך את הידיים למשהו שזז בלי מחווה, ובדיוק זה מה
            # שהדרישה אוסרת. כשההשפעה זניחה ממילא, עדיף גבול חד.
            out[f"arm_fwd_{s}"] = 0.05
            out[f"elbow_out_{s}"] = round(-0.12 - st.shoulder_fwd * 0.18, 5)
            for i, f in enumerate(("thumb", "index", "middle",
                                   "ring", "pinky")):
                # ההתעגלות עולה מהאגודל לזרת - זו הצורה הטבעית של
                # יד רפויה, ואצבעות באותו ערך נראות כמו כפפה.
                out[f"curl_{f}_{s}"] = round(
                    st.finger_rest * (0.55, 0.90, 1.0, 1.05, 1.10)[i], 5)
            out[f"spread_{s}"] = -0.18

        # --- ידיים: **רק** ממחוות מאושרות. אין כאן שום תנועה
        #     שמקורה אינו ב-Gesture שעבר את שערי הסיבה.
        #
        #     **TASK 07.** הסינון הוא על |משקל| ולא על משקל חיובי:
        #     בזמן האנטיציפציה המשקל **שלילי** (היד נסוגה), ותנאי
        #     `wt <= 0` היה מוחק בדיוק את ההכנה שהעיקרון דורש.
        for g in self.gestures:
            if abs(g.weight(t)) < 1e-6 and not (g.opens <= t < g.end):
                continue
            for k, v in shape_ctl_at(g, t).items():
                out[k] = round(out.get(k, 0.0) + v, 5)

        # --- תנועה משנית: נגררת מהידיים, קטנה, ומאוחרת.
        dr = self._trail(t)
        if dr > 1e-6:
            hands = {g.hand for g in self.gestures}
            for s in ("L", "R"):
                if s in hands:
                    continue
                # הכתף הנגדית נסוגה מעט - זה המשקל הנגדי של הזריקה.
                k = f"shoulder_fwd_{s}"
                out[k] = round(out.get(k, 0.0) - 0.085 * min(1.0, dr), 5)
                k = f"shoulder_up_{s}"
                out[k] = round(out.get(k, 0.0) + 0.045 * min(1.0, dr), 5)
            out["breath"] = round(out.get("breath", 0.0)
                                  + 0.09 * min(1.0, dr), 5)

        return out

    def describe(self, t: float) -> str:
        """מה הגוף עושה ברגע זה, במילים. זה מה שהכתובית מציגה."""
        act = self.active(t)
        if act:
            g = max(act, key=lambda x: x.weight(t))
            ph = {"anticipation": "נסיגה מכינה", "preparation": "הכנה",
                  "stroke": "הדגשה", "hold": "החזקה",
                  "retraction": "חזרה"}.get(g.phase(t), "")
            if g.overshooting(t):
                ph = "חריגה"
            tail = f" · «{g.anchor}»" if g.anchor else ""
            return f"{g.reason} ({ph}{tail})"
        w = self.weight_at(t)
        leg = "ימין" if w > 0.12 else ("שמאל" if w < -0.12 else "שתיהן")
        return f"משקל על {leg} · {self.stance.note or 'עמידה'}"

    def as_dict(self) -> dict:
        return {"stance": self.stance.as_dict(),
                "gestures": [g.as_dict() for g in self.gestures],
                "reshift": round(self.reshift, 3)}


# ==================================================== מהסצנה לגוף

def actor_for(sit, intention: str = "", seed: float = 0.0,
              speech: tuple = (), line: str | None = None,
              track=None) -> BodyActor:
    """`emotion.Situation` -> שחקן גוף מלא.

    `track` הוא `rig.voice.Track` אופציונלי. כשהוא קיים, ה-stroke
    של המחווה הראשונה נתלה על **שיא האנרגיה האמיתי** של הדיבור ולא
    על חלוקת אותיות - כלומר היד מדגישה בדיוק את הרגע שבו הקול
    מדגיש. זה הקשר בין TASK 06 לבין תיקון הקול.
    """
    from rig import emotion as E                     # noqa: PLC0415
    if not intention:
        intention, _ = E.choose_intention(sit)
    e = sit.feel()
    tm = E.build_timing(sit, intention)
    txt = line if line is not None else getattr(sit, "line", "")

    t0, t1 = (speech[0] if speech else (0.4, 0.4 + 1.4))
    anchor_t = None
    if track is not None:
        anchor_t = t0 + _peak_time(track)

    gs = gestures_for(intention, txt, t0, t1,
                      want=getattr(sit, "want_strength", 0.6),
                      arousal=e.arousal, control=e.control,
                      hides=bool(sit.hides), anchor_time=anchor_t)
    # המחווה מגיעה **אחרי** שהפנים הגיבו. זה נשמר מ-TASK 03: יד
    # שזזה לפני הפנים נראית כמו אנימציה שהודבקה.
    for g in gs:
        g.stroke = round(max(g.prep + 0.05, g.stroke + tm.delay * 0.5), 4)

    # הצד הוא תכונה של הדמות ולא של הרגש, ולכן הוא נגזר מה-seed:
    # אותה דמות נשענת תמיד על אותה רגל, ושתי דמויות בפריים אינן
    # עומדות כמו תמונת ראי.
    side = 1.0 if (int(seed) % 2 == 0) else -1.0
    st = stance_for(intention, e.valence, e.arousal, e.control,
                    hides=bool(sit.hides),
                    want=getattr(sit, "want_strength", 0.6), bias=tm.bias,
                    side=side)
    shot = max(1.0, float(getattr(sit, "shot_len", 3.0)))
    return BodyActor(stance=st, gestures=gs, seed=seed,
                     shift_at=round(0.10 + 0.25 * (1.0 - e.arousal), 3),
                     reshift=round(shot * 0.62, 3) if shot >= 3.0 else 0.0)


def _peak_time(track) -> float:
    """הרגע (בשניות מתחילת השמע) שבו הדיבור הכי חזק."""
    import numpy as np                               # noqa: PLC0415
    if track is None or not len(track.rms):
        return 0.6
    i = int(np.argmax(track.rms))
    return float(i * track.hop)


# ==================================================== דוח

def audit() -> dict:
    """בדיקה עצמית של המודול: כל הצורות תקפות, כל הכוונות מכוסות."""
    bad_ctl: list[str] = []
    for shape, spec in SHAPES.items():
        for k in spec:
            for s in ("L", "R"):
                if f"{k}_{s}" not in C.CONTROLS:
                    bad_ctl.append(f"{shape}.{k}_{s}")
    missing = [i for i in ALLOWED if i not in _PLAYBOOK]
    illegal: list[str] = []
    for intention, plays in _PLAYBOOK.items():
        for kind, _shape, _why in plays:
            if kind not in ALLOWED.get(intention, ()):
                illegal.append(f"{intention}:{kind}")
    return {"kinds": len(KINDS), "shapes": len(SHAPES),
            "intentions": len(ALLOWED),
            "controls_missing": bad_ctl,
            "intentions_missing": missing,
            "illegal_plays": illegal,
            "new_controls": sorted(
                k for k in C.CONTROLS
                if k.startswith(("weight_", "hips_shift", "shoulder_",
                                 "foot_turn", "foot_roll", "elbow_out")))}


def main(argv=None) -> int:
    sys.stdout.reconfigure(encoding="utf-8")
    rep = audit()
    print("=== TASK 06 · משחק גוף מלא ===")
    print(f"סוגי מחווה: {rep['kinds']} · צורות: {rep['shapes']} · "
          f"כוונות: {rep['intentions']}")
    print(f"בקרות גוף חדשות ({len(rep['new_controls'])}): "
          f"{', '.join(rep['new_controls'])}")
    for key, label in (("controls_missing", "בקרות חסרות"),
                       ("intentions_missing", "כוונות בלי מחוות"),
                       ("illegal_plays", "מחוות שאינן תומכות בכוונה")):
        bad = rep[key]
        print(f"  {label}: {'אין ✓' if not bad else ', '.join(bad)}")

    from rig import emotion as E                     # noqa: PLC0415
    print("\n--- הגוף בכל תרחיש ---")
    for name, sit in E.SCENES.items():
        inten, _ = E.choose_intention(sit)
        act = actor_for(sit, inten, speech=((0.5, 2.0),))
        st = act.stance
        print(f"  {name:16s} {inten:9s} משקל {st.weight:+.2f} "
              f"כתף {st.shoulder_up:+.2f} נטייה {st.lean:+.2f} "
              f"· {len(act.gestures)} מחוות")
        for g in act.gestures:
            print(f"        [{g.kind}] {g.reason}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
