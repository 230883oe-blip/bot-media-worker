# -*- coding: utf-8 -*-
"""TASK 10 · דיאלוג חופף ומשחק שתי דמויות.

=== הדרישה ===

    Create an overlapping dialogue scene where Lucas and Maya have
    conflicting emotional reactions (e.g. Lucas is defensive/surprised,
    Maya is amused/skeptical). Implement shifting weight, reactive
    breathing, and asymmetric postures that reflect their distinct
    personalities, moving entirely away from mirrored or static stances.

=== מה חדש כאן ומה כבר היה ===

חלוקת משקל קיימת מ-TASK 06, ונשימה קיימת שם גם היא. **שתיהן היו
עצמיות**: `BodyActor.breath_at` הוא סינוס של הזמן ושל ה-seed, והוא
מחזיר בדיוק אותו דבר אם בן השיח מדבר, שותק או אינו קיים. כלומר עד
כאן שתי הדמויות היו שני מונולוגים שהורכבו באותו פריים.

שלושת הדברים שנוספו, וכולם **חיבור** בין שתי הדמויות:

**1 · חפיפה אמיתית בציר הזמן.** חלון הדיבור של מאיה נפתח 0.46
שניות לפני שלוקאס סיים. זה לא פרט תזמון - זו הסצנה: ההפרעה היא
האירוע, והיא מה שמוליד את ההפתעה שלו. `rig.voice.mix` כבר מחבר
קטעים שנופלים זה על זה ומגביל רך, ולכן גם פס הקול חופף ולא
"מתחלף".

**2 · נשימה תגובתית.** הנשימה מקבלת שלושה איברים שמקורם **בבן
השיח**: שאיפה חדה ברגע שנחתכים (catch of breath), נשימה רדודה
ומהירה כל עוד הזולת מדבר ואני מחזיק את מה שרציתי לומר, ונשימת
התאוששות עמוקה אחרי שהפסקתי לדבר. ההוכחה שזו תגובה ולא קישוט היא
גרסת הביקורת `solo`: אותה דמות בדיוק, רק בלי בן שיח. אם העקומה
יוצאת זהה - אין כאן תגובתיות, והבדיקה נופלת.

**3 · יציבות א-סימטריות שאינן תמונת ראי.** זו הדרישה הקשה
למדידה, כי "לא מראה" אינו מצב אלא **מרחק**. לכן `mirror` ממפה
פריים דרך החלפת צד (כל `_L`/`_R` מתחלפים, וכל ערוץ עם סימן צדי
מתהפך), ו-`mirror_similarity` הוא קוסינוס הדמיון בין הפריים
הממופה של האחד לפריים של השנייה. אם הם היו עומדים כתמונת ראי
הערך היה שואף ל-1.

=== הרגשות המנוגדים אינם נכתבים - הם נגזרים ===

לוקאס מקבל `feels="guilt"` ומאיה `feels="amusement"`. הכוונות
(`defend` ו-`test`) **נגזרות** מהן ב-`emotion.choose_intention` ולא
נבחרות כאן, ולכן הניגוד אינו הצהרה: ‎valence‎ ‎-0.58‎ מול ‎+0.72‎,
‎control‎ ‎0.30‎ מול ‎0.72‎, ושתי רשימות מחוות מותרות שאינן נחתכות
(‎defend‎: emblem/adaptor/beat · ‎test‎: deictic/beat/regulator).
ההפתעה שלו אינה רגש נפרד אלא `react` ברגע ההפרעה - וזה נכון
דרמטית: הוא לא "מופתע" לאורך הסצנה, הוא מופתע **ברגע שחותכים
אותו**.
"""
from __future__ import annotations

import argparse
import json
import math
import sys

import numpy as np

from . import emotion as E

# ------------------------------------------------------------- התסריט

LUCAS_LINE = "לא אמרתי שזה בגללך."
MAYA_LINE = "אמרת. בדיוק את זה אמרת."

#: אורכי ההקלטות בפועל (edge-tts): 2.664 ו-3.960 שניות. החלונות
#: נגזרים מהם ולא נבחרים, אחרת הפה "מדבר" אחרי שהקול נגמר.
L_DUR = 2.664
M_DUR = 3.960

L_SPEECH = (0.90, round(0.90 + L_DUR, 3))      # 0.90 - 3.564
M_SPEECH = (3.10, round(3.10 + M_DUR, 3))      # 3.10 - 7.060

#: הזמן שבו מאיה נכנסת לדבריו. זה **הרגע** של הסצנה.
CUT_IN = M_SPEECH[0]
OVERLAP = round(L_SPEECH[1] - M_SPEECH[0], 4)

SCENE_LEN = 9.0
FPS = 30


def situation_lucas() -> E.Situation:
    """מתגונן. `guilt` ולא `fear`: הוא לא מפוחד - הוא נתפס.

    `choose_intention` מחזירה מכאן `defend` (valence שלילי, שליטה
    נמוכה, עוררות בינונית), וזה נגזר ולא נכתב.
    """
    return E.Situation(
        knows="שהוא כן אמר את זה, ובאיזה טון",
        wants="שהשיחה הזאת תיגמר בלי שהוא יודה",
        feels="guilt", hides="", looks_at="partner",
        change="", knows_more=0.0, want_strength=0.78,
        intensity=0.95, shot_len=SCENE_LEN, line=LUCAS_LINE)


def situation_maya() -> E.Situation:
    """משועשעת וספקנית. `knows_more=0.8` עם שליטה גבוהה מחזיר
    `test` - היא לא מאשימה, היא נותנת לו להיכשל בעצמו."""
    return E.Situation(
        knows="בדיוק מה הוא אמר ומתי",
        wants="שהוא ישמע את עצמו",
        feels="amusement", hides="", looks_at="partner",
        change="", knows_more=0.8, want_strength=0.62,
        intensity=0.9, shot_len=SCENE_LEN, line=MAYA_LINE)


SITS = {"lucas": situation_lucas, "maya": situation_maya}
LINES = {"lucas": LUCAS_LINE, "maya": MAYA_LINE}
WINDOWS = {"lucas": L_SPEECH, "maya": M_SPEECH}
VOICES = {"lucas": "avri", "maya": "hila"}
#: ה-seed קובע גם את הצד שעליו נשענים. **שניהם זוגיים בכוונה**,
#: כלומר שניהם נשענים על אותו צד - שתי דמויות שנשענות לכיוונים
#: הפוכים בפריים אחד נקראות כתמונת ראי, וזה בדיוק מה שהמשימה
#: אוסרת. ההבדל ביניהם בא מהכוונה ומהרגש, לא מהיפוך.
SEEDS = {"lucas": 4.0, "maya": 6.0}
#: מתי כל אחד מעביר משקל. **לא באותו רגע** - שתי דמויות שמעבירות
#: משקל יחד נראות כמו אנימציה אחת שהוכפלה.
SHIFT_AT = {"lucas": 0.35, "maya": 1.25}
RESHIFT = {"lucas": 4.10, "maya": 6.65}


def partner_of(who: str) -> str:
    return "maya" if who == "lucas" else "lucas"


# ------------------------------------------------- נשימה תגובתית


def _envelope(who: str):
    """מעטפת האנרגיה של הדיבור של דמות, בציר הזמן של הסצנה.

    נמדדת מההקלטה עצמה (`voice.Track.rms`) ולא מחלון הזמן, ולכן
    "בן השיח מדבר עכשיו" הוא מה שנשמע בפועל - כולל הפאוזות בתוך
    המשפט, שהן בדיוק הרגעים שבהם אדם מנצל לנשום.
    """
    from . import voice as V                           # noqa: PLC0415
    tr = V.load(LINES[who], VOICES[who])
    t0 = WINDOWS[who][0]
    if tr is None or not len(tr.rms):
        lo, hi = WINDOWS[who]

        def box(t: float) -> float:
            return 1.0 if lo <= t <= hi else 0.0
        return box
    r = np.asarray(tr.rms, float)
    r = r / max(1e-9, float(r.max()))
    hop = float(tr.hop)

    def env(t: float) -> float:
        i = (float(t) - t0) / hop
        if i < 0 or i >= len(r) - 1:
            return 0.0
        j = int(i)
        f = i - j
        return float(r[j] * (1.0 - f) + r[j + 1] * f)
    return env


_ENV_CACHE: dict[str, object] = {}


def envelope(who: str):
    if who not in _ENV_CACHE:
        _ENV_CACHE[who] = _envelope(who)
    return _ENV_CACHE[who]


#: עוצמות שלושת האיברים. קטנות בכוונה: נשימה שנראית היא נשימה
#: גרועה, והמדידה כאן היא על **הפרש** בין "עם בן שיח" ל"בלי",
#: ולא על גודל מוחלט.
CATCH = 0.34          # שאיפה חדה ברגע שחותכים אותך
HOLD_SHALLOW = 0.17   # נשימה רדודה ומהירה כל עוד הזולת מדבר
RECOVER = 0.26        # נשימת התאוששות אחרי שסיימת לדבר
CATCH_RISE = 0.09     # שניות עד שיא השאיפה
CATCH_FALL = 0.55     # ודעיכתה
AMUSED = 0.15         # עצירות נשימה של מי שמשועשעת ממה שהיא שומעת
HELD = 0.11           # ואחיזת נשימה של מי שמתוח ממה שהוא שומע


def reactive_breath(who: str, t: float, with_partner: bool = True) -> float:
    """התוספת לערוץ הנשימה, שמקורה **בבן השיח**.

    `with_partner=False` היא גרסת הביקורת: אותה דמות בדיוק, בלי
    שיהיה מי שידבר אליה. אם הפלט זהה - אין כאן תגובתיות אלא
    אנימציה שמריצה את עצמה, וזה מה ש-`audit` תופס.
    """
    t = float(t)
    me = WINDOWS[who]
    out = 0.0

    # --- 1 · נשימת התאוששות אחרי שסיימתי לדבר. זו **אינה** תגובה
    #     לזולת, ולכן היא קיימת גם ב-solo: אדם שסיים משפט ארוך
    #     נושם, בלי קשר למי שמולו.
    if t > me[1]:
        u = (t - me[1])
        out += RECOVER * math.exp(-u / 1.5) * \
            math.sin(2 * math.pi * (u * 0.42))

    if not with_partner:
        return round(out, 5)

    pa = partner_of(who)
    pw = WINDOWS[pa]
    env = envelope(pa)

    # --- 2 · שאיפה חדה ברגע שבן השיח נכנס לדברַי. מתקיים רק אם
    #     הוא נכנס **בתוך** חלון הדיבור שלי - אחרת זו לא הפרעה
    #     אלא תור תקין, ואין ממה להיבהל.
    if me[0] <= pw[0] <= me[1]:
        u = t - pw[0]
        if u >= -0.02:
            att = min(1.0, max(0.0, u / CATCH_RISE))
            dec = math.exp(-max(0.0, u - CATCH_RISE) / CATCH_FALL)
            out += CATCH * att * dec

    # --- 3 · כל עוד הוא מדבר ואני מחזיק את מה שרציתי לומר:
    #     רדוד ומהיר. התדר כפול מתדר המנוחה, והעומק קטן - וזה
    #     נגזר מהמעטפת שלו, כלומר דווקא בפאוזות שלו אני נושם.
    e = env(t)
    if e > 0.02:
        out += HOLD_SHALLOW * e * math.sin(2 * math.pi * (t * 0.58 +
                                                          SEEDS[who] * 0.31))
        # --- 4 · **איך אני נושם כשהוא מדבר תלוי במה שאני מרגישה
        #     כלפיו**, וזה נגזר מצירי הרגש ולא משם הדמות - בדיוק
        #     כמו ב-`body.stance_for`. מאיה אינה נחתכת ולכן אין לה
        #     שאיפה חדה; האיבר הזה הוא התגובה שכן יש לה, והוא גם
        #     מה שהיה חסר כדי שהתגובתיות שלה תהיה נמדדת ולא זניחה.
        #
        #     ערכיות חיובית -> עצירות נשימה קצרות וגבוהות: צחוק
        #     מרוסן של מי שמשועשעת ממה שהיא שומעת. ערכיות שלילית
        #     עם שליטה נמוכה -> אחיזת נשימה, כלומר **בלימה** של
        #     העומק. שתי התגובות הפוכות בסימן, ושתיהן אמיתיות.
        fe = SITS[who]().feel()
        if fe.valence > 0.20:
            h = math.sin(2 * math.pi * (t * 1.35 + SEEDS[who] * 0.17))
            out += AMUSED * fe.valence * e * max(0.0, h) ** 2
        elif fe.valence < -0.20:
            out -= HELD * (1.0 - fe.control) * e
    return round(out, 5)


# ------------------------------------------------------------- השחקנים


def actor(who: str, variant: str = "full"):
    """`(u, t) -> (ctl, {}, mph)` לדמות אחת בסצנת הדואט.

    עובר דרך `showreel._emotion_actor`, כלומר **אותו מסלול בדיוק**
    שמייצר את הסרטון. מבחן שבונה לעצמו נתונים בדרך אחרת מזו שרצה
    בייצור בודק קוד שאיש אינו מריץ.
    """
    from . import showreel as SR                       # noqa: PLC0415
    if variant not in VARIANTS and variant != "full":
        raise ValueError(f"גרסה לא מוכרת: {variant}")
    sit = SITS[who]()
    win = WINDOWS[who]
    pa = partner_of(who)

    if variant == "sequential":
        # בלי חפיפה: מאיה מחכה בנימוס עד שהוא יסיים.
        win = (L_SPEECH if who == "lucas"
               else (L_SPEECH[1] + 0.25, L_SPEECH[1] + 0.25 + M_DUR))

    # ההפתעה היא `react` ברגע ההפרעה, ולא רגש נפרד לאורך הסצנה.
    reacts = ()
    if who == "lucas" and variant not in ("sequential", "solo"):
        reacts = ((CUT_IN - 0.04, 1.0),)

    fb, eye = SR._emotion_actor(
        sit, seed=SEEDS[who], phase=0.0 if who == "lucas" else 0.45,
        speech=(win,), reacts=reacts,
        voice=VOICES[who], body=True)

    bod = getattr(fb, "body", None)
    if bod is not None:
        bod.shift_at = SHIFT_AT[who]
        bod.reshift = 0.0 if variant == "static" else RESHIFT[who]
        if variant == "sync":
            bod.shift_at = SHIFT_AT["lucas"]
            bod.reshift = RESHIFT["lucas"]
        if variant == "static":
            bod.stance.sway = 0.0

    with_partner = variant != "solo"
    mirror_src = (variant == "mirror" and who == "maya")
    held: dict = {}

    def fn(u, t):
        if mirror_src:
            # גרסת הביקורת: מאיה עומדת כתמונת ראי של לוקאס.
            fa = actor("lucas", "full")
            ctl, _x, mph = fa(u, t)
            return mirror(ctl), {}, mph
        ctl, _x, mph = fb(u, t)
        ctl = dict(ctl)
        b = ctl.get("breath", 0.0) + reactive_breath(who, t, with_partner)
        ctl["breath"] = round(max(-1.0, min(1.0, b)), 5)
        if variant == "static":
            # **יציבה קפואה באמת.** אפס sway ואפס החלפת רגל לא הספיקו:
            # `weight_at` עדיין מטפס מאפס אל ערך היציבה דרך `_lag`,
            # והטיפוס הזה לבדו נתן טווח של 0.86 - כלומר ההפרכה "עמידה
            # סטטית" עברה את מבחן "המשקל זז". לכן כל ערוצי היציבה
            # מוחזקים על הפריים של שנייה 1.0, אחרי ההתייצבות.
            if not held:
                h, _y, _z = fb(0.0, 1.0)
                held.update({k: v for k, v in h.items()
                             if k.startswith(POSE_PREFIX)})
            ctl.update(held)
        return ctl, {}, mph

    fn.speech = getattr(fb, "speech", None)
    fn.body = bod
    fn.track = getattr(fb, "track", None)
    fn.eye = eye
    fn.window = win
    return fn


#: גרסאות הביקורת. כל אחת שוברת **דרישה אחת** של המשימה, וחייבת
#: ליפול בדיוק במבחן שמגן עליה. בלעדיהן המדדים כאן מודדים את עצמם.
VARIANTS = {
    "mirror":     "מאיה עומדת כתמונת ראי מדויקת של לוקאס",
    "sync":       "שניהם מעבירים משקל באותם רגעים בדיוק",
    "static":     "בלי החלפת רגל ובלי נדנוד - יציבה קפואה",
    "solo":       "אין בן שיח: הנשימה מריצה את עצמה",
    "sequential": "בלי חפיפה - כל אחד מחכה לתורו",
}


# -------------------------------------------------- מראה והשוואה


#: ערוצים שסימנם הוא **צד**. היפוך צד מחייב גם היפוך סימן, אחרת
#: "מראה" אינה מראה: דמות שנשענת ימינה ומסובבת ראש ימינה, במראה,
#: נשענת שמאלה ומסובבת שמאלה.
SIGNED = ("weight_shift", "hips_shift", "spine_side", "spine_twist",
          "head_yaw", "head_roll", "hips_roll", "eye_aim_x",
          "gaze_x", "look_x")


def mirror(frame: dict) -> dict:
    """הפריים כפי שהיה נראה בראי: צדדים מוחלפים, ערוצים צדיים
    מתהפכים בסימן."""
    out: dict[str, float] = {}
    for k, v in frame.items():
        if k.endswith("_L"):
            out[k[:-2] + "_R"] = v
        elif k.endswith("_R"):
            out[k[:-2] + "_L"] = v
        elif k in SIGNED:
            out[k] = -v
        else:
            out[k] = v
    return out


#: ערוצי היציבה. הפנים והפה אינם כאן בכוונה: השאלה היא אם
#: **הגוף** עומד כתמונת ראי, והבעת פנים אינה יציבה.
POSE_PREFIX = ("weight_", "hips_", "spine_", "shoulder_", "leg_",
               "knee_", "foot_", "ankle_", "arm_", "elbow_", "head_roll")


def pose_vector(frame: dict, keys: list[str]) -> np.ndarray:
    return np.array([float(frame.get(k, 0.0)) for k in keys])


def pose_keys(*frames: dict) -> list[str]:
    ks = set()
    for f in frames:
        ks |= {k for k in f if k.startswith(POSE_PREFIX)}
    return sorted(ks)


def _cos(a: np.ndarray, b: np.ndarray) -> float:
    na, nb = float(np.linalg.norm(a)), float(np.linalg.norm(b))
    if na < 1e-12 or nb < 1e-12:
        return 0.0
    return float(a @ b / (na * nb))


# ------------------------------------------------------------- הדגימה


def sample(variant: str = "full", fps: int = FPS) -> dict:
    """דוגם את שתי הדמויות על אותו ציר זמן."""
    n = int(round(SCENE_LEN * fps)) + 1
    ts = np.linspace(0.0, SCENE_LEN, n)
    out = {"times": ts, "variant": variant, "frames": {}, "actors": {}}
    for who in ("lucas", "maya"):
        fn = actor(who, variant)
        out["actors"][who] = fn
        out["frames"][who] = [fn(0.0, float(t))[0] for t in ts]
    return out


_SOLO_BREATH: dict[tuple, np.ndarray] = {}


def _solo_breath(who: str, ts: np.ndarray) -> np.ndarray:
    """ערוץ הנשימה של אותה דמות **בלי בן שיח**, מהמסלול המלא.

    ממוטמע לפי (דמות, מספר הפריימים): הוא נדרש שוב ושוב בכל
    גרסאות הביקורת, והבנייה שלו כוללת טעינת ההקלטה ובניית שחקן
    הדיבור.
    """
    key = (who, len(ts), float(ts[-1]))
    if key not in _SOLO_BREATH:
        fn = actor(who, "solo")
        _SOLO_BREATH[key] = np.array(
            [float(fn(0.0, float(t))[0].get("breath", 0.0)) for t in ts])
    return _SOLO_BREATH[key]


def measure(variant: str = "full", fps: int = FPS) -> dict:
    s = sample(variant, fps)
    ts = s["times"]
    dt = float(ts[1] - ts[0])
    fl, fm = s["frames"]["lucas"], s["frames"]["maya"]
    keys = pose_keys(fl[0], fm[0])
    L = np.array([pose_vector(f, keys) for f in fl])
    M = np.array([pose_vector(f, keys) for f in fm])
    Lm = np.array([pose_vector(mirror(f), keys) for f in fl])

    rep: dict = {"variant": variant, "channels": len(keys)}

    # --- 1 · חפיפה אמיתית בציר הזמן
    wl = s["actors"]["lucas"].window
    wm = s["actors"]["maya"].window
    rep["windows"] = {"lucas": list(wl), "maya": list(wm)}
    rep["overlap"] = round(min(wl[1], wm[1]) - max(wl[0], wm[0]), 4)

    # --- 2 · הרגשות מנוגדים (נגזר מהמנוע, לא מהתסריט)
    el = situation_lucas().feel()
    em = situation_maya().feel()
    il, _ = E.choose_intention(situation_lucas())
    im, _ = E.choose_intention(situation_maya())
    rep["emotion"] = {
        "lucas": {"feels": "guilt", "valence": round(el.valence, 3),
                  "control": round(el.control, 3), "intention": il},
        "maya": {"feels": "amusement", "valence": round(em.valence, 3),
                 "control": round(em.control, 3), "intention": im},
        "valence_opposite": bool(el.valence * em.valence < 0),
        "intentions_differ": bool(il != im)}

    # --- 3 · לא תמונת ראי, וגם לא אותה יציבה
    mir = float(np.mean([_cos(Lm[i], M[i]) for i in range(len(ts))]))
    raw = float(np.mean([_cos(L[i], M[i]) for i in range(len(ts))]))
    rep["mirror_similarity"] = round(mir, 4)
    rep["raw_similarity"] = round(raw, 4)

    # --- 4 · חלוקת משקל: שתיהן זזות, ולא באותם רגעים
    wsh = {}
    for who, F in (("lucas", fl), ("maya", fm)):
        w = np.array([float(f.get("weight_shift", 0.0)) for f in F])
        rate = np.abs(np.gradient(w, dt))
        wsh[who] = {"swing": round(float(w.max() - w.min()), 4),
                    "peak_at": round(float(ts[int(np.argmax(rate))]), 3),
                    "std": round(float(w.std()), 5)}
    rep["weight"] = wsh
    rep["shift_gap"] = round(abs(wsh["lucas"]["peak_at"]
                                 - wsh["maya"]["peak_at"]), 3)

    # --- 5 · נשימה תגובתית: מול **אותה סצנה בגרסת solo**.
    #
    # כאן היה הכשל שנתפס בהרצה הראשונה: המדידה קראה ישירות
    # ל-`reactive_breath(with_partner=True/False)` ולכן החזירה את
    # אותו הפרש **בכל הגרסאות**, כולל בגרסת `solo` עצמה. כלומר
    # ההפרכה שנועדה להוכיח שהנשימה תגובתית עברה את המבחן שלה.
    # עכשיו הערוץ נלקח מהפריימים שנדגמו בפועל בגרסה הנבדקת, ומול
    # ערוץ הנשימה של אותה דמות כשאין לה בן שיח.
    br = {}
    for who, F in (("lucas", fl), ("maya", fm)):
        with_p = np.array([float(f.get("breath", 0.0)) for f in F])
        solo = _solo_breath(who, ts) if variant != "solo" else with_p
        env = envelope(partner_of(who))
        pe = np.array([env(float(t)) for t in ts])
        d = with_p - solo
        br[who] = {
            "delta_rms": round(float(np.sqrt(np.mean(d ** 2))), 5),
            "delta_max": round(float(np.abs(d).max()), 5),
            "partner_corr": round(_cos(d - d.mean(), pe - pe.mean()), 4),
            "range": round(float(with_p.max() - with_p.min()), 5)}
    rep["breath"] = br

    # --- 6 · לא קפוא
    rep["motion"] = {
        "lucas": round(float(np.abs(np.diff(L, axis=0)).mean()), 6),
        "maya": round(float(np.abs(np.diff(M, axis=0)).mean()), 6)}

    # --- 7 · מחוות: שתי רשימות מותרות שאינן נחתכות
    gl = s["actors"]["lucas"].body
    gm = s["actors"]["maya"].body
    rep["gestures"] = {
        "lucas": [g.kind for g in (gl.gestures if gl else [])],
        "maya": [g.kind for g in (gm.gestures if gm else [])]}
    rep["gesture_overlap"] = sorted(set(rep["gestures"]["lucas"])
                                    & set(rep["gestures"]["maya"]))
    return rep


# ------------------------------------------------------------- האימות

MIRROR_MAX = 0.80       #: מעל זה - השתיים עומדות כתמונת ראי
SAME_MAX = 0.92         #: ומעל זה הן באותה יציבה בכלל
OVERLAP_MIN = 0.25      #: שניות חפיפה מינימליות
SHIFT_GAP_MIN = 0.40    #: הפרש זמני העברת המשקל
BREATH_DELTA_MIN = 0.02  #: הפרש הנשימה בין "עם בן שיח" ל"בלי"
MOTION_MIN = 1e-4       #: מתחת לזה היציבה קפואה
SWING_MIN = 0.12        #: טווח העברת המשקל


def _checks(m: dict) -> dict:
    c: dict[str, dict] = {}

    def chk(key, value, limit, ok, how):
        c[key] = {"value": value, "limit": limit, "pass": bool(ok),
                  "how": how}

    chk("dialogue_overlaps", m["overlap"], f">={OVERLAP_MIN}ש",
        m["overlap"] >= OVERLAP_MIN,
        "מאיה נכנסת לדבריו לפני שסיים - זו 'overlapping dialogue'")
    chk("emotions_conflict",
        f"{m['emotion']['lucas']['intention']} ({m['emotion']['lucas']['valence']}) "
        f"מול {m['emotion']['maya']['intention']} "
        f"({m['emotion']['maya']['valence']})",
        "ערכיות הפוכה וכוונות שונות",
        m["emotion"]["valence_opposite"] and m["emotion"]["intentions_differ"],
        "הכוונות נגזרות ב-choose_intention ולא נכתבות כאן")
    chk("gesture_repertoires_disjoint", m["gesture_overlap"] or "אין חיתוך",
        "אין סוג מחווה משותף", not m["gesture_overlap"],
        "אותו רגש היה מוליד אותן מחוות - הניגוד נראה גם בידיים")
    chk("not_mirrored", m["mirror_similarity"], f"<={MIRROR_MAX}",
        m["mirror_similarity"] <= MIRROR_MAX,
        "קוסינוס הדמיון בין היציבה של לוקאס במראה לזו של מאיה")
    chk("not_the_same_stance", m["raw_similarity"], f"<={SAME_MAX}",
        m["raw_similarity"] <= SAME_MAX,
        "ולא רק שאינן מראה - הן גם אינן אותה יציבה")
    chk("weight_shifts_desynced", m["shift_gap"], f">={SHIFT_GAP_MIN}ש",
        m["shift_gap"] >= SHIFT_GAP_MIN,
        "שתי דמויות שמעבירות משקל יחד נראות כאנימציה אחת שהוכפלה")
    for who in ("lucas", "maya"):
        chk(f"{who}/weight_moves", m["weight"][who]["swing"],
            f">={SWING_MIN}", m["weight"][who]["swing"] >= SWING_MIN,
            "חלוקת המשקל אינה שווה ואינה קבועה")
        chk(f"{who}/not_static", m["motion"][who], f">={MOTION_MIN}",
            m["motion"][who] >= MOTION_MIN,
            "תנועת היציבה הממוצעת לפריים - 0 פירושו בובה")
        chk(f"{who}/breath_is_reactive", m["breath"][who]["delta_rms"],
            f">={BREATH_DELTA_MIN}",
            m["breath"][who]["delta_rms"] >= BREATH_DELTA_MIN,
            "ההפרש בין הנשימה עם בן שיח לבין אותה דמות לבדה")
    chk("catch_of_breath_on_interruption",
        m["breath"]["lucas"]["delta_max"], ">= חצי מעוצמת השאיפה",
        m["breath"]["lucas"]["delta_max"] >= CATCH * 0.5,
        "השאיפה החדה ברגע שחותכים אותו היא האירוע הגופני של הסצנה")
    return c


def audit(fps: int = FPS) -> dict:
    import time                                        # noqa: PLC0415
    t0 = time.time()
    m = measure("full", fps)
    checks = _checks(m)

    # --- גרסאות הביקורת: כל אחת חייבת ליפול, ובמבחן שלה.
    controls_rep = {}
    for var, why in VARIANTS.items():
        mv = measure(var, fps)
        cv = _checks(mv)
        failed = [k for k, v in cv.items() if not v["pass"]]
        controls_rep[var] = {"why": why, "failed": failed}
        checks[f"control/{var}"] = {
            "value": ", ".join(failed[:3]) or "עברה הכול",
            "limit": "חייבת ליפול לפחות במבחן אחד",
            "pass": bool(failed), "how": why}
    for var, guard in (("mirror", "not_mirrored"),
                       ("sync", "weight_shifts_desynced"),
                       ("solo", "lucas/breath_is_reactive"),
                       ("sequential", "dialogue_overlaps")):
        f = controls_rep[var]["failed"]
        checks[f"control/{var}_falls_on_its_own_guard"] = {
            "value": ", ".join(f[:4]) or "לא נפלה",
            "limit": f"נופלת ב-{guard}", "pass": guard in f,
            "how": "הפרכה שנופלת במבחן אחר אינה מוכיחה שהמבחן מפריד"}
    # `static` מגן על שני המבחנים של הקיפאון, ודי באחד מהם.
    f = controls_rep["static"]["failed"]
    checks["control/static_falls_on_its_own_guard"] = {
        "value": ", ".join(f[:4]) or "לא נפלה",
        "limit": "נופלת ב-not_static או ב-weight_moves",
        "pass": any(k.endswith(("not_static", "weight_moves")) for k in f),
        "how": "יציבה קפואה חייבת להיתפס כקפואה"}

    return {"task": "TASK 10 - דיאלוג חופף ומשחק שתי דמויות",
            "scene": {"len": SCENE_LEN, "fps": fps,
                      "lucas_line": LUCAS_LINE, "maya_line": MAYA_LINE,
                      "lucas_speech": list(L_SPEECH),
                      "maya_speech": list(M_SPEECH),
                      "overlap": OVERLAP},
            "measured": m,
            "controls": controls_rep,
            "checks": checks,
            "passed": all(v["pass"] for v in checks.values()),
            "seconds": round(time.time() - t0, 2)}


def main(argv=None) -> int:
    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(description="דיאלוג חופף (TASK 10)")
    ap.add_argument("--fps", type=int, default=FPS)
    ap.add_argument("--json", default="")
    a = ap.parse_args(argv)
    rep = audit(fps=a.fps)
    print(f"=== {rep['task']} ===")
    print(f"  לוקאס: «{LUCAS_LINE}»  ({L_SPEECH[0]}-{L_SPEECH[1]}ש)")
    print(f"  מאיה:  «{MAYA_LINE}»  ({M_SPEECH[0]}-{M_SPEECH[1]}ש)")
    print(f"  חפיפה: {OVERLAP}ש\n")
    for k, v in rep["checks"].items():
        print(f"  {'✓' if v['pass'] else '✗'} {k}: {v['value']} "
              f"(גבול {v['limit']})")
    print(f"\n{'עבר' if rep['passed'] else 'נכשל'} · {rep['seconds']}ש")
    if a.json:
        from pathlib import Path                        # noqa: PLC0415
        Path(a.json).write_text(json.dumps(rep, ensure_ascii=False, indent=1,
                                           default=str), encoding="utf-8")
        print(f"דוח: {a.json}")
    return 0 if rep["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
