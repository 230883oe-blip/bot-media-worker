# -*- coding: utf-8 -*-
"""TASK 13 (06/10) - הרחבת הסצנה ללהקה, ועקרונות דיסני הקלאסיים.

ההוראה שהתקבלה:
    Introduce a secondary character that darts across the scene ·
    rich interactive props (autumn leaves, malfunctioning lamppost,
    picnic basket) · maximize dynamic buoyancy for Zippy with
    exaggerated squash & stretch · heavy resistant motion with ground
    impact shakes and micro-expressions for Grump · choreograph a
    physical interaction where Zippy scatters the leaves and Grump
    reacts · a dynamic sweeping camera arc with depth of field.

================================================================
שלוש הכרעות ארכיטקטורה, וכל אחת מהן נגד אלטרנטיבה שנשקלה ונפסלה
================================================================

**1. העלים הם ענן נקודות אחד, ולא 46 גופים.** 46 רשתות ב-three.js
הן 46 קריאות ציור ו-46 מטריצות פר פריים, על מכונה בלי כרטיס גרפי
וב-1500 פריימים. ענן נקודות (`THREE.Points`) הוא buffer אחד וקריאת
ציור אחת: מה שמתעדכן פר פריים הוא מערך מספרים, ולא היררכיית אובייקטים.
את ההכרעה הזו אישר גם יועץ חיצוני (Command A, 06/10) באותו נימוק.

**2. הסנאי הוא גוף תלת-ממדי מפרימיטיבים, ולא ספריט דו-ממדי.**
ספריט דו-ממדי בשכבת-על היה זול יותר, אבל הוא **שובר את העומק**:
הסנאי חייב לעבור מאחורי גרומפ ולפני הספסל, ושכבת-על נמצאת תמיד
לפני הכול או תמיד אחרי הכול. כמה כדורים בעלי רזולוציה נמוכה בקבוצה
אחת פותרים את זה בחינם - אין להם עור, אין להם שלד, ואין להם מפת צל.

**3. הפנס נצרב בסביבה והאור שלו בלבד דינמי.** עמוד פנס הוא גוף
שאינו זז, ולכן הוא שייך לשכבת ה-PNG הצרובה (`park._props`). מה
שמהבהב הוא האור - והוא שכבת-על רדיאלית אחת שעוצמתה מגיעה מפייתון.
אור שני אמיתי ב-three.js היה מכפיל את מפות הצל, וזה החישוב היחיד
בסצנה שבאמת יקר.

================================================================
מה נמדד כאן, ולמה דווקא זה
================================================================

הדרישה "אנימציה בסטנדרט דיסני" אינה ניתנת לאימות בעין בתוך צינור
אוטומטי, אבל **כל אחד מהעקרונות שהוזמנו כן ניתן למדידה**:

* מעיכה ומתיחה מוגזמות - נמדדות מול תקרת **דרגת הסגנון** שנוספה
  ב-`principles.STYLE_TIERS`. זיגי מקבלת 45%, גרומפ 26%, ולוקאס
  ומאיה נשארים על 12% בדיוק כפי שהיו. הגזמה אינה היתר לשנות נפח,
  ולכן `sy*sx² = 1` נדרש בכל הדרגות.
* הכנה (anticipation) - נמדדת כנסיגה בכיוון ההפוך לפני כל קפיצה.
* תנועה עוקבת (follow-through) - שיא הזנב של הסנאי חייב להגיע
  **אחרי** שיא הגוף, ונמדד בפריימים. זנב שמגיע יחד עם הגוף הוא
  זנב מודבק.
* משקל - צעד של גרומפ חייב להיות איטי מקפיצה של זיגי (מדידה
  מונוטונית), והזעזוע שלו חייב **לדעוך** ולא להמשיך לנצח.
* סיבתיות - שיא מהירות העלים חייב להקדים את שיא תגובת גרומפ.
  זו הבדיקה שמפרידה "שתי אנימציות שרצות במקביל" מ"אינטראקציה":
  תגובה שמגיעה לפני הסיבה היא דמות שקוראת מחשבות, ותגובה שמגיעה
  שנייה וחצי אחריה היא דמות שלא שמה לב.

הכול נבנה **פעם אחת** ל-`Take` של אורך השוט, ומשם כל פריים הוא
אינדקס במערך. זה מה שמאפשר למדוד את העקומה כולה (שיא, דעיכה,
פיגור) ולא רק את הערך בנקודה אחת - ומדידה על נקודה אחת לא הייתה
מגלה אף אחת מהתקלות שלמעלה.
"""
from __future__ import annotations

import json
import math
from dataclasses import dataclass, field

import numpy as np

from . import park
from . import principles as P

FPS = 30

# ===================================================== דמות המשנה
#
# נאטסי - סנאי שמזנק לרוחב הפריים, נעצר ליד סל הפיקניק, חוטף אגוז
# ומסתלק. שפת הצורות שלו היא **עיגול קטן ומהיר**, והיא מנוגדת לשתי
# הדמויות הקיימות: זיגי עגולה אך גדולה, גרומפ מרובע וכבד. הניגוד
# הזה הוא כל הסיבה להוסיף דמות שלישית - עוד דמות באותה שפת צורות
# לא מוסיפה דבר לפריים.

#: כל איבר: (מזהה, רדיוס במטרים, מרכז מקומי, מתיחה אנכית, צבע).
#: הכול כדורים, ובכוונה: `sphericity` של כל איבר נמדד ב-`audit`,
#: והוא מה שאוכף את שפת הצורות העגולה בפועל ולא בהצהרה.
CRITTER_PARTS: tuple[dict, ...] = (
    {"id": "body", "r": 0.082, "at": (0.0, 0.098, 0.0),
     "sy": 1.22, "sz": 1.10, "color": "#8a5a33"},
    {"id": "haunch_L", "r": 0.046, "at": (0.044, 0.062, -0.022),
     "sy": 1.0, "sz": 1.0, "color": "#7d5130"},
    {"id": "haunch_R", "r": 0.046, "at": (-0.044, 0.062, -0.022),
     "sy": 1.0, "sz": 1.0, "color": "#7d5130"},
    {"id": "head", "r": 0.058, "at": (0.0, 0.186, 0.040),
     "sy": 1.0, "sz": 1.08, "color": "#96643a"},
    {"id": "muzzle", "r": 0.030, "at": (0.0, 0.168, 0.086),
     "sy": 0.86, "sz": 1.0, "color": "#d8c0a2"},
    # האוזניים: **פקעת מעוגלת ולא משולש.** הניסיון הראשון היה
    # (1.35, 0.70) - אוזן מחודדת - והמדידה תפסה אותו: 0.519
    # כדוריות, כלומר איבר מרובע בתוך דמות שהוכרזה עגולה. סנאי
    # קריקטורי הוא פקעות, והמדד הוא מה שאכף את זה.
    {"id": "ear_L", "r": 0.023, "at": (0.031, 0.230, 0.028),
     "sy": 1.18, "sz": 0.82, "color": "#7d5130"},
    {"id": "ear_R", "r": 0.023, "at": (-0.031, 0.230, 0.028),
     "sy": 1.18, "sz": 0.82, "color": "#7d5130"},
    {"id": "eye_L", "r": 0.0135, "at": (0.029, 0.198, 0.082),
     "sy": 1.0, "sz": 1.0, "color": "#120d0a"},
    {"id": "eye_R", "r": 0.0135, "at": (-0.029, 0.198, 0.082),
     "sy": 1.0, "sz": 1.0, "color": "#120d0a"},
    {"id": "paw_FL", "r": 0.017, "at": (0.036, 0.020, 0.052),
     "sy": 0.82, "sz": 1.22, "color": "#6f4729"},
    {"id": "paw_FR", "r": 0.017, "at": (-0.036, 0.020, 0.052),
     "sy": 0.82, "sz": 1.22, "color": "#6f4729"},
    {"id": "paw_BL", "r": 0.020, "at": (0.042, 0.020, -0.040),
     "sy": 0.82, "sz": 1.24, "color": "#6f4729"},
    {"id": "paw_BR", "r": 0.020, "at": (-0.042, 0.020, -0.040),
     "sy": 0.82, "sz": 1.24, "color": "#6f4729"},
)

#: הזנב הוא קבוצה נפרדת עם ציר סיבוב משלה, ולכן הוא יכול לפגר
#: אחרי הגוף. זה **כל** הקטע של תנועה עוקבת: זנב שהוא איבר באותה
#: קבוצה כמו הגוף מגיע איתו בדיוק באותו פריים, וזה נראה מודבק.
CRITTER_TAIL = {
    "pivot": (0.0, 0.105, -0.072),
    "beads": (
        {"r": 0.040, "at": (0.0, 0.030, -0.030), "color": "#9a6a3e"},
        {"r": 0.050, "at": (0.0, 0.088, -0.056), "color": "#a8743f"},
        {"r": 0.052, "at": (0.0, 0.152, -0.058), "color": "#b5813f"},
        {"r": 0.044, "at": (0.0, 0.208, -0.038), "color": "#c08a44"},
        {"r": 0.032, "at": (0.0, 0.248, -0.008), "color": "#cf9a4e"},
    ),
}

#: האגוז. הוא **האינטראקציה** של הסנאי עם הסביבה: הוא שוכב ליד סל
#: הפיקניק, הסנאי נעצר, חוטף אותו, וממשיך איתו. אביזר שאף דמות
#: אינה נוגעת בו הוא רקע, לא אביזר.
CRITTER_NUT = {"r": 0.026, "color": "#6b4a24"}

CRITTER = {
    "name": "nutsy", "kind": "squirrel", "tier": "cartoon",
    "shape_language": "round", "height_m": 0.27,
    "parts": CRITTER_PARTS, "tail": CRITTER_TAIL, "nut": CRITTER_NUT,
}


def critter_spec() -> dict:
    """המפרט שנשלח לבמה פעם אחת. אין בו שום דבר שמשתנה פר פריים."""
    return {
        "name": CRITTER["name"],
        "parts": [dict(p) for p in CRITTER_PARTS],
        "tail": {"pivot": list(CRITTER_TAIL["pivot"]),
                 "beads": [dict(b) for b in CRITTER_TAIL["beads"]]},
        "nut": dict(CRITTER_NUT),
    }


#: מידות העלה המרונדר במטרים. עלה אמיתי של שלכת הוא כ-9 ס"מ.
LEAF_W, LEAF_H = 0.082, 0.046


def stage_spec() -> dict:
    """כל מה שהבמה צריכה **פעם אחת**. אין כאן שום ערך שמשתנה בזמן.

    ההפרדה הזו היא מה שמונע את התקלה הקלאסית בצינור הזה: בנייה
    מחדש של גאומטריה בכל פריים. מה שנבנה פעם אחת מועבר כאן, ומה
    שמשתנה עובר ב-`Take.payload`.
    """
    cols = ["#%02x%02x%02x" % park.leaf_color(i) for i in range(LEAF_N)]
    return {
        "critter": critter_spec(),
        "leaves": {"n": LEAF_N, "w": LEAF_W, "h": LEAF_H, "colors": cols},
    }


def lamp_screen() -> tuple[float, float, float]:
    """(x, y, רדיוס) של הילת הפנס ביחידות **שכבת הקרקע** המנורמלות.

    לא ביחידות פריים: השכבה רחבה מהפריים ב-`park.PAD` והיא נעה
    בפרלקס, וההילה חייבת לזוז איתה. המרה ליחידות פריים כאן הייתה
    מנתקת את האור מהעמוד בכל סחיפה.
    """
    L = park.PROPS["lamp"]
    return (float(L["head"][0]), float(L["head"][1]), float(L["glow_r"]))


def sphericity(part: dict) -> float:
    """כמה האיבר כדורי: הציר הקטן חלקי הציר הגדול.

    1.0 = כדור מושלם. זה המדד שאוכף את שפת הצורות העגולה על
    **הגאומטריה שנבנתה בפועל**, ולא על ההצהרה בשם האיבר.
    """
    sx, sy, sz = 1.0, float(part.get("sy", 1.0)), float(part.get("sz", 1.0))
    return min(sx, sy, sz) / max(sx, sy, sz)


# ======================================================= מסלול הזינוק

#: תחנות הסנאי: (שנייה, x, z). הוא נכנס מימין, מזגזג בעומק, נעצר
#: ליד הספסל, ואז מסתלק שמאלה. העצירה היא חלק מהבימוי ולא פשרה:
#: דמות שחוצה פריים במהירות אחידה אינה נקראת כחיה - היא נקראת
#: כחפץ שנגרר, וזה מה ש-`m_spacing` מודד כאן.
DART: tuple[tuple[float, float, float], ...] = (
    (0.00, 2.35, -0.30),
    (0.95, 1.55, 0.26),
    (1.80, 0.92, -0.18),
    (2.65, 0.34, 0.30),
    (3.70, -0.06, 0.12),      # בלימה לקראת הסל
    (4.55, -0.30, 0.05),      # עצירה: רטיטה וחטיפת האגוז
    (5.60, -0.33, 0.04),      # עדיין עומד (אותו מקום כמעט)
    (6.45, -0.95, -0.22),
    (7.40, -1.70, 0.18),
    (8.60, -2.60, -0.10),
    (10.00, -3.40, -0.26),
)

#: מתי הסנאי חוטף את האגוז, ומתי הוא מתחיל להחזיק אותו קרוב לפה.
NUT_GRAB = 4.85


def _dart_at(t: float) -> tuple[float, float, int]:
    """(x, z, מספר המקטע) בזמן t, עם האטה בקצות כל מקטע.

    `hermite` עם ease א-סימטרי: הסנאי **יוצא חד ונכנס רך** לכל
    תחנה - זינוק ואז בלימה. ease סימטרי היה נותן תנועה של מטרונום.
    """
    pts = DART
    if t <= pts[0][0]:
        return pts[0][1], pts[0][2], 0
    for i in range(len(pts) - 1):
        t0, x0, z0 = pts[i]
        t1, x1, z1 = pts[i + 1]
        if t <= t1:
            u = (t - t0) / max(1e-9, t1 - t0)
            e = P.hermite(u, ease_in=0.08, ease_out=0.72)
            return x0 + (x1 - x0) * e, z0 + (z1 - z0) * e, i
    return pts[-1][1], pts[-1][2], len(pts) - 2


def _hop_height(t: float) -> float:
    """גובה הזינוק. חצי סינוס לכל מקטע, ואפס כשהוא עומד.

    המקטע שבו הוא עומד (4.55 -> 5.60) מזוהה לפי **אורך המקטע
    במרחב** ולא לפי אינדקס: דמות שעומדת וממשיכה לקפוץ במקום
    נראית כמו באג בלופ, וזיהוי לפי אינדקס היה נשבר ברגע שמוסיפים
    תחנה.
    """
    pts = DART
    for i in range(len(pts) - 1):
        t0, x0, z0 = pts[i]
        t1, x1, z1 = pts[i + 1]
        if t0 <= t <= t1:
            span = math.hypot(x1 - x0, z1 - z0)
            if span < 0.12:
                return 0.0
            u = (t - t0) / max(1e-9, t1 - t0)
            # שני זינוקים קטנים לכל מקטע: סנאי לא עושה קפיצה אחת
            # ארוכה, הוא עושה סדרה של ניתורים.
            k = 2.0
            return abs(math.sin(math.pi * u * k)) * min(0.16, 0.085 * span)
    return 0.0


# ========================================================= שדה העלים

#: פיזיקה. גרר ליניארי ולא ריבועי: עלה קל מאוד ומהירותו נמוכה,
#: ובתחום הזה גרר ליניארי הוא גם הקירוב הנכון וגם ניתן לפתרון
#: סגור - כלומר אפשר לדגום כל זמן בלי לשמור מצב.
G = 9.81
DRAG = 3.4            # 1/שנייה. גבוה: עלה עוצר באוויר מהר.
SPIN_DECAY = 2.2

#: מרכז הערימה בעולם (מטרים), ורדיוס הפרישה. x שלילי = צד זיגי.
LEAF_ANCHOR = (-0.52, 0.0, 0.46)
LEAF_SPREAD = (0.40, 0.17)
LEAF_N = int(park.PROPS["leaves"]["n"])

#: רגע הנחיתה של זיגי בתוך הערימה, ועוצמת הבעיטה.
IMPACT_T = 2.45
IMPACT_V = 3.15


def leaf_rest_world(i: int, n: int = LEAF_N) -> np.ndarray:
    """מקום המנוחה של העלה ה-i בעולם.

    אותה ספירלה זהובה כמו בערימה הצרובה (`park.leaf_rest`), ולכן
    העלה שמתחיל לעוף יוצא **מאותו מקום** שבו הוא צויר בשכבת
    הרקע. שתי פרישות שונות לאותה ערימה הן קפיצה בפריים הראשון.
    """
    g = 2.39996323
    u = (i + 0.5) / max(1, n)
    rad = math.sqrt(u)
    th = i * g
    return np.array([LEAF_ANCHOR[0] + LEAF_SPREAD[0] * rad * math.cos(th),
                     0.006 + 0.010 * ((i * 13) % 5) / 5.0,
                     LEAF_ANCHOR[2] + LEAF_SPREAD[1] * rad * math.sin(th)])


def leaf_impulse(i: int, n: int = LEAF_N,
                 foot: tuple = (-0.52, 0.0, 0.46)) -> np.ndarray:
    """מהירות העלה ברגע הבעיטה.

    הכיוון הוא **רדיאלי מנקודת הפגיעה**, והעוצמה דועכת עם המרחק
    ממנה. זה מה שהופך את הפיזור לפיזור שנגרם: פיזור בכיוונים
    אקראיים נראה כמו רוח, ולא כמו רגל שנחתה.
    """
    p = leaf_rest_world(i, n)
    d = p - np.array([foot[0], 0.0, foot[2]])
    r = float(math.hypot(d[0], d[2]))
    u = np.array([d[0], 0.0, d[2]]) / max(1e-6, r)
    fall = 1.0 / (1.0 + (r / 0.22) ** 2)            # דעיכה עם המרחק
    side = ((i * 7) % 11) / 11.0 - 0.5              # פיזור צדי קטן
    rot = np.array([u[0] * math.cos(side) - u[2] * math.sin(side), 0.0,
                    u[0] * math.sin(side) + u[2] * math.cos(side)])
    up = 0.55 + 0.75 * fall + 0.25 * (((i * 17) % 9) / 9.0)
    return IMPACT_V * fall * rot + np.array([0.0, IMPACT_V * 0.42 * up, 0.0])


def _leaf_path(p0: np.ndarray, v0: np.ndarray, tau: np.ndarray) -> np.ndarray:
    """פתרון סגור לתנועה בגרר ליניארי. (n,3) לכל זמן ב-tau.

    אופקי:  x = x0 + vx0*(1-e^{-k·t})/k
    אנכי:   y = y0 + (vy0 + g/k)*(1-e^{-k·t})/k - g·t/k
    זה הפתרון המדויק של `v' = -k·v - g·ŷ`, ולא קירוב. היתרון
    המעשי: אפשר לדגום פריים 1400 בלי לחשב את 1399 שלפניו, ולכן
    אותה עקומה נמדדת בבדיקה ומוצגת ברינדור.
    """
    k = DRAG
    e = np.exp(-k * tau)[:, None]
    tt = tau[:, None]
    out = p0[None, :] + v0[None, :] * (1.0 - e) / k
    out[:, 1] = (p0[1] + (v0[1] + G / k) * (1.0 - e[:, 0]) / k
                 - G * tau / k)
    return out


@dataclass
class LeafField:
    """46 עלים, כל אחד עם זמן נחיתה משלו.

    זמן הנחיתה מחושב **פעם אחת** בבנייה (חיפוש בינארי על הפתרון
    הסגור), וממנו והלאה העלה שוכב. בלי זה עלה היה ממשיך למטה אל
    מינוס אינסוף - וזה לא נראה בפריים כי הוא מחוץ לתמונה, כלומר
    באג שקט שמוריד עלים מהסצנה.
    """
    n: int = LEAF_N
    impact_t: float = IMPACT_T
    foot: tuple = (-0.52, 0.0, 0.46)
    t_land: np.ndarray = field(default_factory=lambda: np.zeros(0))

    def __post_init__(self) -> None:
        self.p0 = np.stack([leaf_rest_world(i, self.n)
                            for i in range(self.n)])
        self.v0 = np.stack([leaf_impulse(i, self.n, self.foot)
                            for i in range(self.n)])
        self.spin0 = np.array([((i * 23) % 17) / 17.0 * 2.0 - 1.0
                               for i in range(self.n)]) * 540.0
        self.t_land = np.array([self._land_of(i) for i in range(self.n)])

    def _land_of(self, i: int) -> float:
        """הזמן שבו העלה ה-i חוזר לגובה המנוחה שלו."""
        lo, hi = 0.0, 4.0
        y0 = float(self.p0[i, 1])
        for _ in range(42):
            mid = 0.5 * (lo + hi)
            y = float(_leaf_path(self.p0[i], self.v0[i],
                                 np.array([mid]))[0, 1])
            if y > y0:
                lo = mid
            else:
                hi = mid
        return hi

    def at(self, t: float) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """(מקומות (n,3), זוויות סחרור (n,), מהירויות (n,)) בזמן t."""
        tau = np.clip(t - self.impact_t, 0.0, None)
        if tau <= 0.0:
            return self.p0.copy(), np.zeros(self.n), np.zeros(self.n)
        taus = np.minimum(np.full(self.n, tau), self.t_land)
        pos = np.stack([_leaf_path(self.p0[i], self.v0[i],
                                   np.array([taus[i]]))[0]
                        for i in range(self.n)])
        pos[:, 1] = np.maximum(pos[:, 1], self.p0[:, 1])
        # רטט נפילה: עלה אינו נופל בקו - הוא מתנדנד. מחזור קצר
        # שנעלם עם הנחיתה, ולא סינוס שממשיך על הקרקע.
        air = (taus < self.t_land - 1e-6).astype(float)
        flut = np.sin(taus * 7.3 + np.arange(self.n) * 1.7) * 0.035 * air
        pos[:, 0] += flut
        pos[:, 2] += flut * 0.6
        spin = (self.spin0 * (1.0 - np.exp(-SPIN_DECAY * taus))
                / SPIN_DECAY)
        # מהירות: נגזרת הפתרון הסגור, מאופסת אחרי הנחיתה.
        k = DRAG
        e = np.exp(-k * taus)
        vx = self.v0[:, 0] * e
        vz = self.v0[:, 2] * e
        vy = (self.v0[:, 1] + G / k) * e - G / k
        spd = np.sqrt(vx ** 2 + vy ** 2 + vz ** 2) * air
        return pos, spin, spd


# ====================================================== הפנס המקולקל

#: הבהוב. **לא** סינוס: פנס מקולקל דולק רוב הזמן, ואז מגמגם.
#: טבלת (זמן, אורך, עומק) של הגמגומים, ונרטטת מעל אור יציב.
FLICKER: tuple[tuple[float, float, float], ...] = (
    (1.15, 0.22, 0.62),
    (2.47, 0.09, 0.85),      # מיד אחרי הפגיעה - הזעזוע מנתק מגע
    (2.68, 0.14, 0.45),
    (4.05, 0.07, 0.72),
    (5.30, 0.31, 0.55),
    (7.42, 0.46, 0.90),      # הגמגום הגדול
    (8.05, 0.11, 0.40),
    (9.10, 0.18, 0.66),
)

LAMP_BASE = 0.74             # עוצמת האור כשהוא תקין


def lamp_at(t: float) -> float:
    """עוצמת האור ב-[0,1] בזמן t.

    הגמגום הוא **חלון מרובע עם קצוות מרוככים ועם רטט בתוכו**, ולא
    דעיכה חלקה: מגע שמתנתק מנתק מיד. הרטט בתוך החלון הוא מה
    שהופך "האור כבה" ל"האור מגמגם".
    """
    v = LAMP_BASE
    for t0, dur, depth in FLICKER:
        if t0 - 0.03 <= t <= t0 + dur + 0.03:
            u = (t - t0) / max(1e-9, dur)
            edge = P.smoothstep(min(1.0, max(0.0, u / 0.12))) * \
                P.smoothstep(min(1.0, max(0.0, (1.0 - u) / 0.18)))
            buzz = 0.5 + 0.5 * math.sin(t * 61.0 + t0 * 11.0)
            v -= LAMP_BASE * depth * edge * (0.62 + 0.38 * buzz)
    return max(0.0, min(1.0, v))


# ================================================ זיגי: ציפה מוגזמת

#: זמני הקפיצות של זיגי בשוט. כל ערך הוא **רגע הנגיעה בקרקע**,
#: והקפיצה עצמה היא מה שלפניו.
#:
#: **המרווח בין קפיצות אינו קישוט.** בניסיון הראשון היו כאן קפיצות
#: ב-0.75 וב-1.58, והמדידה תפסה את התוצאה: מעיכת הנחיתה של הראשונה
#: (0.30 שניות) נמשכה **אל תוך** פריימי ההכנה של השנייה, ולכן לא
#: הייתה שום נסיגה לזהות - ההכנה נבלעה בריקושט. מרווח של 1.5 שניות
#: נותן לכל קפיצה הכנה משלה, וזה גם מה שנראה בעין: דמות קופצנית
#: היא דמות שמתכוננת, לא דמות שמרצדת.
ZIPPY_HOPS: tuple[float, ...] = (0.95, IMPACT_T, 5.95, 7.30, 8.55)
HOP_RISE = 0.34               # שניות באוויר לעלייה
HOP_H = 0.42                  # גובה הקפיצה במטרים


def zippy_lift(t: float) -> float:
    """גובה שורש הדמות. פרבולה לכל קפיצה, ואפס בין קפיצות."""
    for t0 in ZIPPY_HOPS:
        if t0 - HOP_RISE * 1.6 <= t <= t0:
            # מהנקודה הגבוהה אל הנחיתה: t0 הוא רגע הנגיעה בקרקע.
            u = (t0 - t) / (HOP_RISE * 1.6)
            return HOP_H * math.sin(math.pi * min(1.0, u)) ** 0.85
    return 0.0


def zippy_squash(t: float) -> tuple[float, float]:
    """(קנה מידה אנכי, קנה מידה רוחבי) של זיגי בזמן t, בדרגת קריקטורה.

    שלושה שלבים לכל קפיצה, וזה בדיוק הסדר של דיסני:
      1. **הכנה**: מעיכה למטה לפני ההמראה (צבירת כוח).
      2. **מתיחה** באוויר, בכיוון התנועה.
      3. **מעיכה חדה** בנחיתה, שמשתחררת מהר.
    הנפח נשמר בכל שלב - זה מה שמונע מהדמות "לגדול" בקפיצה.
    """
    a = 0.0
    for t0 in ZIPPY_HOPS:
        pre0, pre1 = t0 - HOP_RISE * 1.95, t0 - HOP_RISE * 1.62
        if pre0 <= t < pre1:                       # הכנה
            u = (t - pre0) / (pre1 - pre0)
            a += -0.30 * math.sin(math.pi * u)
        elif t0 - HOP_RISE * 1.62 <= t < t0:       # מתיחה באוויר
            u = (t - (t0 - HOP_RISE * 1.62)) / (HOP_RISE * 1.62)
            a += 0.26 * math.sin(math.pi * u) ** 0.7
        elif t0 <= t <= t0 + 0.30:                 # מעיכה בנחיתה
            u = (t - t0) / 0.30
            a += -0.40 * (1.0 - u) ** 2.0
    a = max(-0.44, min(0.44, a))
    return P.squash_styled(a, "jump", tier=P.tier_of("zippy"))


def zippy_anticipation(t: float) -> float:
    """ערוץ ההכנה כעקומה לבדה - זה מה ש-`m_anticipation` מודד.

    החזרת "גובה" בלבד לא הייתה מספיקה: ההכנה היא תנועה **למטה**
    לפני תנועה למעלה, ובערוץ הגובה היא נראית כמו אפס.
    """
    y = zippy_lift(t)
    sy, _sx = zippy_squash(t)
    return y + (sy - 1.0) * 0.26


# ================================================== גרומפ: משקל כבד

#: צעדי גרומפ. איטיים, ולא אחידים: 0.78 שנייה לצעד מול 0.34 לקפיצה
#: של זיגי, וזו המדידה המונוטונית של `m_timing`.
GRUMP_STEPS: tuple[float, ...] = (3.95, 4.73, 5.51, 6.29, 7.07)
STEP_DUR = 0.78
SHAKE_DECAY = 7.5

#: עיכוב התגובה. 0.42 שנייה - מהר מספיק להיות תגובה, אטי מספיק
#: להיות תגובה **אנושית** ולא רפלקס של מכונה.
REACT_LAG = 0.42


def ground_shake(t: float) -> float:
    """זעזוע הקרקע מהפגיעות. דועך אקספוננציאלית, ואף פעם לא לופ.

    שתי מקורות: נחיתת זיגי בערימה (חדה) וצעדי גרומפ (כבדים
    ורחבים). השתיים נראות שונה כי הן **נמדדות** שונה: תדירות
    הרעד של צעד כבד נמוכה, ושל נחיתה קלה גבוהה.
    """
    v = 0.0
    for t0 in ZIPPY_HOPS:
        if t <= t0:
            continue
        tau = t - t0
        amp = 0.0062 if abs(t0 - IMPACT_T) > 1e-6 else 0.0115
        v += amp * math.exp(-SHAKE_DECAY * tau) * math.sin(tau * 78.0)
    for t0 in GRUMP_STEPS:
        if t <= t0:
            continue
        tau = t - t0
        v += 0.0098 * math.exp(-5.2 * tau) * math.sin(tau * 41.0)
    return v


def grump_lift(t: float) -> float:
    """שקיעה אנכית בכל צעד. **תמיד שלילית** - גרומפ לא עף.

    צעד כבד הוא ירידה ואז עלייה איטית, ולא נדנוד סימטרי: המשקל
    נופל על הרגל הקדמית ורק אחר כך נדחף.
    """
    v = -0.004
    for t0 in GRUMP_STEPS:
        if t0 - STEP_DUR * 0.45 <= t <= t0 + STEP_DUR * 0.55:
            u = (t - (t0 - STEP_DUR * 0.45)) / STEP_DUR
            v -= 0.030 * math.sin(math.pi * max(0.0, min(1.0, u))) ** 1.6
    return v


def grump_squash(t: float) -> tuple[float, float]:
    """מעיכה בדרגת `stylized`: נראית, אבל גרומפ אינו כדור גומי."""
    a = 0.0
    for t0 in GRUMP_STEPS:
        if t0 <= t <= t0 + 0.26:
            u = (t - t0) / 0.26
            a += -0.17 * (1.0 - u) ** 1.7
    # אנחת ייאוש: החזה נשמט. זו מעיכה איטית וארוכה, לא פגיעה.
    s0 = IMPACT_T + REACT_LAG + 0.55
    if s0 <= t <= s0 + 1.30:
        u = (t - s0) / 1.30
        a += -0.13 * math.sin(math.pi * u) ** 0.8
    a = max(-0.25, min(0.25, a))
    return P.squash_styled(a, "step", tier=P.tier_of("grump"))


#: **הערוצים של המיקרו-הבעות, מאומתים מול מרשם הבקרות של הריג.**
#:
#: 06/10, תקלה אמיתית ששרפה רינדור של 17 דקות: כאן היה `nose_flare`,
#: שהוא שם של **יחידת פעולה בפנים** (`rig.acting`) ולא של בקרה.
#: `controls.normalize` זורק `KeyError` על שם לא מוכר, והוא נזרק
#: בפריים 1586 - כלומר רק בפריימים שבהם הערך אינו אפס, אחרי שכל
#: שאר הסרט כבר רונדר. בדיקת פריים בודד לא יכלה לתפוס את זה.
#:
#: האימות נעשה **בזמן טעינת המודול**: שם שגוי מפיל את הייבוא מיד,
#: ולא אחרי רבע שעה של רינדור.
MICRO_KEYS: tuple[str, ...] = (
    "brow_furrow_L", "brow_furrow_R", "squint_L", "squint_R",
    "breath", "spine_bend", "head_pitch", "jaw_open",
)


def _assert_micro_keys() -> None:
    from . import controls as _C                       # noqa: PLC0415
    bad = [k for k in MICRO_KEYS if k not in _C.CONTROLS]
    if bad:
        raise KeyError(
            f"מיקרו-הבעות מפנות לשמות שאינם בקרות של הריג: {bad}. "
            "שם כזה מפיל את הרינדור רק בפריים שבו הערך אינו אפס.")


_assert_micro_keys()


def grump_micro(t: float) -> dict:
    """מיקרו-הבעות של מורת רוח, כבקרות אמיתיות של הריג.

    הערכים הם שמות בקרה קיימים (`brow_furrow_*`, `breath`,
    `spine_bend`), ולכן הם נכנסים לאותו `ctl` שהמנוע מקבל. ערוץ
    "רגש" שאינו ממופה לבקרה הוא ערוץ שלא נראה בפריים.
    """
    r0 = IMPACT_T + REACT_LAG
    out = {k: 0.0 for k in MICRO_KEYS}
    if t < r0:
        return out
    tau = t - r0
    # רטיטת גבה: שתי פעימות קצרות, אסימטריות. גבה שמתכווצת
    # סימטרית ובאיטיות נקראת כעצב, לא כעצבנות.
    for k, (dt, amp) in enumerate(((0.00, 1.00), (0.52, 0.72),
                                   (1.45, 0.48))):
        if dt <= tau <= dt + 0.20:
            u = (tau - dt) / 0.20
            pulse = math.sin(math.pi * u) ** 0.6 * amp
            out["brow_furrow_L"] += pulse * 0.62
            out["brow_furrow_R"] += pulse * 0.52      # אסימטרי בכוונה
            out["squint_L"] += pulse * 0.30
            out["squint_R"] += pulse * 0.24
    # אנחה: שאיפה קצרה ואז התרוקנות ארוכה של החזה.
    s0 = 0.55
    if s0 <= tau <= s0 + 1.30:
        u = (tau - s0) / 1.30
        out["breath"] = (math.sin(math.pi * min(1.0, u / 0.22)) * 0.85
                         if u < 0.22
                         else -0.78 * P.smoothstep((u - 0.22) / 0.78))
        out["spine_bend"] = 0.16 * P.smoothstep(min(1.0, (u - 0.2) / 0.6))
        out["head_pitch"] = -0.13 * P.smoothstep(min(1.0, (u - 0.2) / 0.6))
        out["jaw_open"] = 0.10 * math.sin(math.pi * min(1.0, u / 0.5))
    for k in out:
        out[k] = round(max(-1.0, min(1.0, out[k])), 4)
    return out


def grump_annoy(t: float) -> float:
    """עוצמת מורת הרוח כערוץ אחד - זה מה שנמדד מול הסיבתיות."""
    m = grump_micro(t)
    return (abs(m["brow_furrow_L"]) + abs(m["brow_furrow_R"])
            + abs(m["breath"]) * 0.7 + abs(m["spine_bend"]) * 0.8)


# =================================================== מצלמה: קשת סחיפה

def arc_camera(u: float, ha: float, hb: float, shake: float = 0.0) -> dict:
    """קשת מצלמה סוחפת סביב האקשן, עם מרחק מיקוד שעוקב אחרי הנושא.

    **למה קשת ולא פאן.** פאן מסביב ציר אחד מזיז את הרקע הצרוב
    לרוחב ומסגיר שהוא שטוח. קשת משנה גם זווית וגם מרחק, ולכן
    הפרספקטיבה בין הדמויות משתנה - וזה מה שנקרא כעומק.

    `focus` הוא המרחק האמיתי מהמצלמה אל הנושא הפעיל, ולא מספר
    קבוע: עומק שדה עם מרחק מיקוד קבוע מטשטש את הנושא בדיוק כשהוא
    מתקרב.
    """
    tall = max(ha, hb)
    yaw = P.hermite(u, 0.7, 0.7) * 64.0 - 30.0        # -30 -> +34
    pitch = 4.0 + 13.0 * math.sin(math.pi * u) ** 0.9
    dist = tall * (2.70 - 0.52 * math.sin(math.pi * u))
    tx = -0.28 + 0.46 * P.smoothstep(u)
    # **מרכז הפריים יורד באמצע הקשת, ולא עולה.** הניסיון הראשון
    # הרים אותו (+0.07) כי "מצלמה שעולה היא דרמטית", והמדידה תפסה
    # את התוצאה: ענן העלים יצא מתחתית הפריים בדיוק בשניות שבהן הוא
    # מתפזר - כלומר האירוע המרכזי של השוט לא היה בתמונה. האקשן
    # כאן הוא על הקרקע, ולכן המצלמה יורדת אליו.
    ty = tall * (0.50 - 0.12 * math.sin(math.pi * u))
    cam = {"yaw": round(yaw, 4), "pitch": round(pitch + shake * 60.0, 4),
           "dist": round(dist, 4), "tx": round(tx, 4),
           "ty": round(ty + shake, 5), "tz": 0.0,
           "fov": round(33.0 - 3.0 * math.sin(math.pi * u), 3)}
    cam["focus"] = round(cam["dist"], 4)
    # עומק שדה: הפתח נפתח בשיא הקשת (רקע מטושטש יותר), כדי
    # שההפרדה בין הדמות לרקע תהיה חזקה דווקא בתקריב של הקשת.
    cam["dof"] = round(0.22 + 0.42 * math.sin(math.pi * u) ** 1.4, 4)
    return cam


def cam_pos(cam: dict) -> np.ndarray:
    """מקום המצלמה בעולם, באותה נוסחה בדיוק שהבמה מחשבת.

    שתי נוסחאות לאותה מצלמה הן בדיוק הבאג שבו הבדיקה עוברת
    והרנדור מראה משהו אחר, ולכן זו העתקה מכוונת של שלוש השורות
    מ-`stage.html`.
    """
    ry = math.radians(cam.get("yaw", 0.0))
    rp = math.radians(cam.get("pitch", 0.0))
    d = cam.get("dist", 4.6)
    tx, ty, tz = cam.get("tx", 0.0), cam.get("ty", 0.95), cam.get("tz", 0.0)
    return np.array([tx + math.sin(ry) * math.cos(rp) * d,
                     ty + math.sin(rp) * d,
                     tz + math.cos(ry) * math.cos(rp) * d])


def project(world, cam: dict, aspect: float = 16 / 9) -> tuple[float, float]:
    """נקודת עולם -> (x, y) מנורמלים בפריים, 0..1. מחוץ לטווח = מחוץ לפריים.

    זה מה שמאפשר לבדוק **בפייתון** שהסנאי באמת בתוך הפריים ושענן
    העלים אינו מצויר מחוץ לתמונה, בלי לרנדר אף פריים.
    """
    p = np.asarray(world, float)
    eye = cam_pos(cam)
    tgt = np.array([cam.get("tx", 0.0), cam.get("ty", 0.95),
                    cam.get("tz", 0.0)])
    fwd = tgt - eye
    fwd /= max(1e-9, np.linalg.norm(fwd))
    up0 = np.array([0.0, 1.0, 0.0])
    right = np.cross(fwd, up0)
    nr = np.linalg.norm(right)
    right = (right / nr) if nr > 1e-9 else np.array([1.0, 0.0, 0.0])
    up = np.cross(right, fwd)
    rel = p - eye
    z = float(np.dot(rel, fwd))
    if z <= 1e-6:
        return (-9.0, -9.0)
    f = 1.0 / math.tan(math.radians(cam.get("fov", 32.0)) * 0.5)
    ndc_y = float(np.dot(rel, up)) / z * f
    ndc_x = float(np.dot(rel, right)) / z * f / aspect
    return (0.5 + 0.5 * ndc_x, 0.5 - 0.5 * ndc_y)


# ============================================================ ה-Take

@dataclass
class Take:
    """כל ערוצי השוט, מחושבים פעם אחת על רשת פריימים.

    זה הלב של המודול. הבנייה המוקדמת היא מה שמאפשר למדוד **עקומה**
    ולא נקודה: פיגור הזנב, דעיכת הזעזוע והסיבתיות בין העלים לגרומפ
    הם כולם יחסים בין שיאים בזמן, ואי אפשר לראות אותם בערך בודד.
    """
    secs: float = 10.0
    fps: int = FPS
    ha: float = 1.42
    hb: float = 1.74

    def __post_init__(self) -> None:
        n = int(round(self.secs * self.fps))
        self.n = n
        self.t = np.arange(n) / float(self.fps)
        self.u = self.t / max(1e-9, self.secs)

        # --- עלים
        self.leaves = LeafField(impact_t=IMPACT_T,
                                foot=(LEAF_ANCHOR[0], 0.0, LEAF_ANCHOR[2]))
        pos, spin, spd = [], [], []
        for tt in self.t:
            p, s, v = self.leaves.at(float(tt))
            pos.append(p)
            spin.append(s)
            spd.append(v)
        self.leaf_pos = np.stack(pos)            # (n, L, 3)
        self.leaf_spin = np.stack(spin)
        self.leaf_spd = np.stack(spd)
        self.leaf_energy = self.leaf_spd.sum(axis=1)

        # --- סנאי
        cx, cz, cy = [], [], []
        for tt in self.t:
            x, z, _i = _dart_at(float(tt))
            cx.append(x)
            cz.append(z)
            cy.append(_hop_height(float(tt)))
        self.crit_pos = np.stack([np.array(cx), np.array(cy),
                                  np.array(cz)], axis=1)
        self.crit_spd = np.r_[0.0, np.linalg.norm(
            np.diff(self.crit_pos, axis=0), axis=1)] * self.fps

        # מעיכה של הסנאי: נגזרת הגובה. עולה -> מתיחה, נוחת -> מעיכה.
        vy = np.gradient(self.crit_pos[:, 1], self.t)
        amp = np.clip(vy * 0.14, -0.40, 0.40)
        pairs = [P.squash_styled(float(a), "dart", tier="cartoon")
                 for a in amp]
        self.crit_scale = np.array(pairs)        # (n, 2) = (sy, sx)

        # --- הזנב: קפיץ שנמשך אל כיוון התנועה, ולכן **מפגר** אחריו.
        self.tail_deg = self._tail_spring()

        # --- זיגי וגרומפ
        self.z_lift = np.array([zippy_lift(float(x)) for x in self.t])
        self.z_ant = np.array([zippy_anticipation(float(x)) for x in self.t])
        self.z_squash = np.array([zippy_squash(float(x)) for x in self.t])
        self.g_lift = np.array([grump_lift(float(x)) for x in self.t])
        self.g_squash = np.array([grump_squash(float(x)) for x in self.t])
        self.g_annoy = np.array([grump_annoy(float(x)) for x in self.t])
        self.shake = np.array([ground_shake(float(x)) for x in self.t])
        self.lamp = np.array([lamp_at(float(x)) for x in self.t])

        # --- מצלמה
        self.cams = [arc_camera(float(uu), self.ha, self.hb,
                                float(sh))
                     for uu, sh in zip(self.u, self.shake)]
        self.cpos = np.stack([cam_pos(c) for c in self.cams])

    def _tail_spring(self) -> np.ndarray:
        """זווית הזנב, כקפיץ מרוסן שנמשך אל מהירות הגוף.

        **מיקום ולא זווית**: הקפיץ נמשך אל כיוון התנועה בעולם,
        ולכן הוא מגיב גם לסיבוב הגוף. זו אותה החלטה שנעשתה
        ב-`rig.secondary`, ומאותה סיבה.
        """
        k, zeta = 52.0, 0.42
        c = 2.0 * zeta * math.sqrt(k)
        dt = 1.0 / self.fps
        vx = np.r_[0.0, np.diff(self.crit_pos[:, 0])] * self.fps
        vy = np.r_[0.0, np.diff(self.crit_pos[:, 1])] * self.fps
        out = np.zeros(self.n)
        ang, vel = 0.0, 0.0
        for i in range(self.n):
            # המטרה: הזנב נזרק הפוך לתנועה (אינרציה), ונזקף בניתור.
            target = -float(vx[i]) * 11.0 + float(vy[i]) * 7.0
            target = max(-46.0, min(46.0, target))
            acc = k * (target - ang) - c * vel
            vel += acc * dt
            ang += vel * dt
            ang = max(-52.0, min(52.0, ang))
            out[i] = ang
        return out

    # ------------------------------------------------------ פר פריים

    def _idx(self, t: float) -> int:
        return int(max(0, min(self.n - 1, round(t * self.fps))))

    def payload(self, t: float) -> dict:
        """המטען שנשלח לבמה בפריים הזה. מספרים בלבד.

        העלים נשלחים כמערך שטוח (x,y,z,spin) ולא כרשימת אובייקטים:
        זה מה שמאפשר לבמה לכתוב ישירות ל-buffer של ענן הנקודות
        בלי לבנות 46 אובייקטים בכל פריים.
        """
        i = self._idx(t)
        flat: list[float] = []
        for j in range(self.leaves.n):
            p = self.leaf_pos[i, j]
            flat += [round(float(p[0]), 4), round(float(p[1]), 4),
                     round(float(p[2]), 4),
                     round(float(self.leaf_spin[i, j]), 2)]
        sy, sx = self.crit_scale[i]
        return {
            "leaves": flat,
            "crit": {"x": round(float(self.crit_pos[i, 0]), 4),
                     "y": round(float(self.crit_pos[i, 1]), 4),
                     "z": round(float(self.crit_pos[i, 2]), 4),
                     "sy": round(float(sy), 4), "sx": round(float(sx), 4),
                     "tail": round(float(self.tail_deg[i]), 3),
                     "yaw": round(float(self._crit_yaw(i)), 2),
                     "nut": 1 if t >= NUT_GRAB else 0},
            "lamp": round(float(self.lamp[i]), 4),
            "shake": round(float(self.shake[i]), 5),
            "dof": self.cams[i]["dof"], "focus": self.cams[i]["focus"],
        }

    def _crit_yaw(self, i: int) -> float:
        """לאן הסנאי מסתכל: לכיוון התנועה. חיה שרצה שמאלה ומביטה
        ימינה היא הדבר הראשון שנראה שבור."""
        j = min(self.n - 1, i + 1)
        dx = float(self.crit_pos[j, 0] - self.crit_pos[max(0, i - 1), 0])
        dz = float(self.crit_pos[j, 2] - self.crit_pos[max(0, i - 1), 2])
        if abs(dx) < 1e-6 and abs(dz) < 1e-6:
            return -78.0
        return math.degrees(math.atan2(dx, dz))

    def controls_for(self, who: str, t: float) -> dict:
        """תוספות הבקרה של הדמות בזמן הזה (נמרגות על מנוע הרגש)."""
        if who == "grump":
            return grump_micro(t)
        return {}

    def lift_for(self, who: str, t: float) -> float:
        i = self._idx(t)
        if who == "zippy":
            return float(self.z_lift[i])
        if who == "grump":
            return float(self.g_lift[i])
        return 0.0


# ============================================================ מדידה

def audit(take: Take | None = None) -> dict:
    """חוזה TASK 13. {שם: {"pass": bool, "detail": str}}.

    כל בדיקה כאן היא דרישה מפורשת מההוראה שהתקבלה, או תקלה שהיא
    מונעת. בדיקה שאינה יכולה להיכשל אינה בדיקה, ולכן יש כאן גם
    שלוש בדיקות-בקרה שמוכיחות שהשער באמת סוגר.
    """
    tk = take or Take()
    out: dict = {}

    def chk(name: str, ok, detail) -> None:
        out[name] = {"pass": bool(ok), "detail": str(detail)}

    # ---------------------------------------- 1. דמות המשנה והאביזרים
    chk("דמות משנה שלישית נרשמה עם שפת צורות משלה",
        CRITTER["name"] == "nutsy" and CRITTER["shape_language"] == "round",
        f"{CRITTER['name']} · {CRITTER['shape_language']}")
    sph = [sphericity(p) for p in CRITTER_PARTS]
    chk("הסנאי עגול בפועל: כל איבר מעל 0.60 כדוריות",
        min(sph) >= 0.60, f"מינימום {min(sph):.3f}, ממוצע {np.mean(sph):.3f}")
    chk("ולכן שפת הצורות שלו שונה מגרומפ המרובע",
        np.mean(sph) > 0.80, round(float(np.mean(sph)), 3))
    chk("הסנאי קטן מהותית משתי הדמויות",
        CRITTER["height_m"] < 0.35 and CRITTER["height_m"] < tk.ha * 0.30,
        f"{CRITTER['height_m']}מ' מול {tk.ha}מ'")
    chk("לזנב ציר סיבוב משלו (אחרת אין תנועה עוקבת)",
        len(CRITTER_TAIL["beads"]) >= 4
        and CRITTER_TAIL["pivot"][2] < 0.0, CRITTER_TAIL["pivot"])
    chk("שלושת האביזרים האינטראקטיביים קיימים בסביבה",
        set(park.PROPS) >= {"lamp", "leaves", "basket"}, sorted(park.PROPS))
    hues = [park.LEAF_HUES[i % len(park.LEAF_HUES)][0]
            for i in range(LEAF_N)]
    chk("צבעי העלים בטווח גווני השלכת",
        all(0.02 <= h <= 0.14 for h in hues),
        f"{min(hues):.3f}..{max(hues):.3f}")

    # ---------------------------------------- 2. מעיכה ומתיחה ודרגות
    pairs = [tuple(x) for x in tk.z_squash]
    v = P.m_squash_stretch(pairs)
    chk("הנפח נשמר בכל פריים של זיגי (sy·sx²=1)", v.ok, v.detail)
    v2 = P.m_squash_stretch([tuple(x) for x in tk.crit_scale])
    chk("והנפח נשמר גם בסנאי", v2.ok, v2.detail)
    amp = float(np.max(np.abs(tk.z_squash[:, 0] - 1.0)))
    chk("המעיכה של זיגי מוגזמת בפועל (מעל התקרה הריאליסטית)",
        amp > P.SQUASH_MAX * 1.8, f"{amp:.3f} מול תקרת אדם {P.SQUASH_MAX}")
    gamp = float(np.max(np.abs(tk.g_squash[:, 0] - 1.0)))
    chk("וגרומפ נמעך פחות ממנה - הוא נוקשה",
        gamp < amp * 0.72, f"גרומפ {gamp:.3f} מול זיגי {amp:.3f}")

    # בדיקות-בקרה: השער **לא** הורפה לדמויות הריאליסטיות.
    try:
        P.squash_styled(0.30, "jump", tier="human")
        hard = False
    except P.StyleError:
        hard = True
    chk("השער על דמות ריאליסטית נשאר סגור (0.30 נדחה)", hard, "StyleError")
    try:
        P.squash(0.30, "jaw")
        old = False
    except P.StyleError:
        old = True
    chk("והפונקציה המקורית לא נגעו בה בכלל", old, "StyleError")
    try:
        P.squash_styled(0.20, "jump", tier="stylized")
        ctx = False
    except P.StyleError:
        ctx = True
    chk("הקשר שאינו בדרגה נדחה (קפיצה אינה בדרגת stylized)", ctx,
        "StyleError")
    chk("לוקאס ומאיה נשארו בדרגת אדם",
        P.tier_of("lucas") == "human" and P.tier_of("maya") == "human",
        (P.tier_of("lucas"), P.tier_of("maya")))

    # ---------------------------------------- 3. הכנה ותנועה עוקבת
    # **החלון נגמר בשיא הקפיצה ולא בנחיתה.** `ZIPPY_HOPS` מחזיק את
    # רגע **הנגיעה בקרקע**, והמהלך העיקרי הוא העלייה שלפניו. חלון
    # שנגמר בנחיתה מכיל גם את המעיכה שאחרי הנגיעה, והמדידה קראה
    # אותה כ"מהלך עיקרי כלפי מטה" - כלומר חיפשה הכנה בכיוון ההפוך
    # ולא מצאה. זו טעות מדידה, לא טעות אנימציה.
    hop = [t for t in ZIPPY_HOPS if t > 1.0][0]
    i0 = tk._idx(hop - 0.80)
    i1 = tk._idx(hop - 0.27)
    va = P.m_anticipation(tk.t[i0:i1], tk.z_ant[i0:i1], min_frac=0.05)
    chk("לפני הקפיצה של זיגי יש הכנה בכיוון ההפוך", va.ok, va.detail)

    # **פיגור הזנב נמדד בקורלציה צולבת ולא בהשוואת שיאים.** השוואת
    # שיאים גלובליים נכשלה כאן בצדק מצומצם: היא השוותה שיא של מקטע
    # זינוק אחד לשיא של מקטע אחר, כלומר שני אירועים שונים. מה
    # שמגדיר תנועה עוקבת הוא שהאות של הזנב הוא האות של הגוף
    # **מוזז בזמן**, וזה בדיוק מה שקורלציה צולבת מודדת.
    drive = np.r_[0.0, np.diff(tk.crit_pos[:, 0])] * tk.fps
    tail = tk.tail_deg.copy()
    drive -= drive.mean()
    tail -= tail.mean()
    best, blag = -2.0, -1
    for lag in range(0, tk.fps // 2 + 1):
        a = drive[:tk.n - lag]
        b = tail[lag:]
        den = float(np.linalg.norm(a) * np.linalg.norm(b))
        c = float(np.dot(a, b) / den) if den > 1e-9 else 0.0
        if abs(c) > best:
            best, blag = abs(c), lag
    chk("הזנב הוא הגוף מוזז בזמן (תנועה עוקבת)",
        blag >= 1 and best > 0.5,
        f"פיגור {blag} פריימים, קורלציה {best:.3f}")
    chk("והפיגור אינו מוגזם (מתחת לחצי שנייה)",
        0 < blag <= tk.fps // 2, f"{blag} פריימים")
    chk("הזנב בכלל נע בטווח משמעותי",
        float(np.ptp(tk.tail_deg)) > 12.0,
        f"{float(np.ptp(tk.tail_deg)):.1f} מעלות")

    # ---------------------------------------- 4. משקל, זעזוע ותזמון
    vt = P.m_timing([HOP_RISE * 1.6, STEP_DUR], [1.0, 2.6])
    chk("צעד כבד איטי מקפיצה קלה", vt.ok, vt.detail)
    chk("גרומפ לעולם אינו עולה מעל הקרקע",
        float(tk.g_lift.max()) <= 0.0, f"מקסימום {tk.g_lift.max():.4f}מ'")
    chk("זיגי כן עפה באוויר", float(tk.z_lift.max()) > 0.25,
        f"{tk.z_lift.max():.3f}מ'")
    ii = tk._idx(IMPACT_T)
    win = tk.shake[ii:tk._idx(IMPACT_T + 0.10)]
    chk("שיא הזעזוע הוא ברגע הפגיעה",
        float(np.abs(win).max()) >= float(np.abs(tk.shake).max()) * 0.90,
        f"{np.abs(win).max():.5f} מול {np.abs(tk.shake).max():.5f}")
    tail_sh = tk.shake[tk._idx(IMPACT_T + 0.75):tk._idx(IMPACT_T + 1.05)]
    chk("והזעזוע דועך ואינו ממשיך לנצח",
        float(np.abs(tail_sh).max()) < float(np.abs(tk.shake).max()) * 0.04,
        f"{np.abs(tail_sh).max():.6f}")

    # **הבדיקה שנולדה מרינדור שנפל (06/10).** כל ערוץ מיקרו-הבעה
    # חייב להיות בקרה אמיתית של הריג, ובכל **פריים** - לא רק בפריים
    # אחד. השם `nose_flare` עבר כאן בשקט כי ערכו אפס ברוב השוט,
    # והפיל את הרינדור רק בפריים 1586 מתוך 1800.
    from . import controls as _C                       # noqa: PLC0415
    badk, badv = set(), 0
    for i in range(tk.n):
        m = grump_micro(float(tk.t[i]))
        for k, v in m.items():
            if k not in _C.CONTROLS:
                badk.add(k)
            lo, hi, _d, _g = _C.CONTROLS.get(k, (-1, 1, 0, ""))
            if not (lo - 1e-9 <= v <= hi + 1e-9):
                badv += 1
    chk("כל ערוצי המיקרו-הבעות הם בקרות אמיתיות של הריג",
        not badk, sorted(badk) or f"{len(MICRO_KEYS)} ערוצים")
    chk("וכל הערכים בטווח החוקי שלהן בכל 300 הפריימים",
        badv == 0, f"{badv} חריגות")
    try:
        for i in range(0, tk.n, 7):
            _C.normalize(grump_micro(float(tk.t[i])))
        norm_ok = True
    except Exception as exc:                            # noqa: BLE001
        norm_ok = False
        badk.add(str(exc))
    chk("והריג מקבל אותן בלי לזרוק שגיאה", norm_ok,
        "normalize עבר" if norm_ok else sorted(badk))

    # ---------------------------------------- 5. האינטראקציה והסיבתיות
    chk("העלים במנוחה עד רגע הפגיעה",
        float(np.abs(tk.leaf_spd[:ii]).max()) == 0.0,
        f"{np.abs(tk.leaf_spd[:ii]).max():.6f}")
    li = int(np.argmax(tk.leaf_energy))
    rate = np.r_[0.0, np.diff(tk.g_annoy)]
    ri = int(np.argmax(rate))
    chk("העלים מתפזרים בפועל אחרי הנחיתה",
        float(tk.leaf_energy.max()) > 2.0 and li >= ii,
        f"אנרגיה {tk.leaf_energy.max():.2f} בפריים {li}")
    chk("**סיבתיות**: הפיזור מקדים את תגובת גרומפ",
        li < ri, f"עלים {li}, תגובה {ri}")
    lag = (ri - li) / tk.fps
    chk("והתגובה מגיעה בהשהיה אנושית (0.2-1.2 שניות)",
        0.20 <= lag <= 1.20, f"{lag:.2f} שניות")
    chk("גרומפ אדיש לחלוטין לפני הפגיעה",
        float(np.abs(tk.g_annoy[:ii]).max()) == 0.0,
        f"{np.abs(tk.g_annoy[:ii]).max():.4f}")
    mv = max(float(np.abs(tk.leaf_pos[:, :, 0]).max()),
             float(np.abs(tk.leaf_pos[:, :, 2]).max()))
    chk("העלים נעים מרחק שנראה בעין (מעל 20 ס\"מ)",
        float(np.abs(tk.leaf_pos[-1] - tk.leaf_pos[0]).max()) > 0.20,
        f"{np.abs(tk.leaf_pos[-1] - tk.leaf_pos[0]).max():.3f}מ'")
    chk("ואף עלה אינו שוקע מתחת לקרקע",
        float(tk.leaf_pos[:, :, 1].min()) >= 0.0,
        f"{tk.leaf_pos[:, :, 1].min():.5f}מ'")
    end = tk.leaf_spd[-1]
    chk("בסוף השוט כל העלים נחו", float(np.abs(end).max()) < 1e-6,
        f"{np.abs(end).max():.8f}")
    chk("הערימה פזורה בסוף רחב יותר מבתחילה",
        float(np.ptp(tk.leaf_pos[-1, :, 0]))
        > float(np.ptp(tk.leaf_pos[0, :, 0])) * 1.25,
        (round(float(np.ptp(tk.leaf_pos[0, :, 0])), 3),
         round(float(np.ptp(tk.leaf_pos[-1, :, 0])), 3)))

    # ---------------------------------------- 6. הסנאי חוצה ומאיץ
    chk("הסנאי חוצה את כל רוחב הסצנה",
        float(np.ptp(tk.crit_pos[:, 0])) > 4.0,
        f"{np.ptp(tk.crit_pos[:, 0]):.2f}מ'")
    vs = P.m_spacing(tk.t, tk.crit_pos[:, 0], min_ratio=1.5)
    chk("ומהירותו אינה אחידה (זינוק ועצירה ולא גרירה)", vs.ok, vs.detail)
    stop = tk.crit_spd[tk._idx(4.7):tk._idx(5.5)]
    chk("יש בו רגע עצירה מלאה ליד הסל",
        float(np.abs(stop).max()) < 0.35, f"{np.abs(stop).max():.3f} מ'/ש")
    chk("והוא חוטף את האגוז בזמן העצירה",
        4.55 <= NUT_GRAB <= 5.60, NUT_GRAB)
    chk("הסנאי מביט לכיוון התנועה",
        abs(tk._crit_yaw(tk._idx(1.0))
            - tk._crit_yaw(tk._idx(7.0))) > 20.0,
        (round(tk._crit_yaw(tk._idx(1.0)), 1),
         round(tk._crit_yaw(tk._idx(7.0)), 1)))

    # ---------------------------------------- 7. הפנס המקולקל
    chk("הפנס מהבהב בפועל", float(np.ptp(tk.lamp)) > 0.30,
        f"{tk.lamp.min():.3f}..{tk.lamp.max():.3f}")
    chk("והוא דולק רוב הזמן (פנס מקולקל, לא דיסקו)",
        float((tk.lamp > LAMP_BASE * 0.80).mean()) > 0.60,
        f"{(tk.lamp > LAMP_BASE * 0.80).mean():.1%} מהזמן")
    # לא סינוס: התאמת הסינוס הטוב ביותר משאירה שארית גדולה.
    sig = tk.lamp - tk.lamp.mean()
    sp = np.abs(np.fft.rfft(sig))
    kbest = int(np.argmax(sp[1:])) + 1
    ph = 2 * np.pi * kbest * np.arange(tk.n) / tk.n
    bas = np.stack([np.cos(ph), np.sin(ph)], axis=1)
    coef, *_ = np.linalg.lstsq(bas, sig, rcond=None)
    resid = float(np.linalg.norm(sig - bas @ coef) / max(1e-9,
                                                         np.linalg.norm(sig)))
    chk("ההבהוב אינו סינוס (שארית גדולה מהתאמה הרמונית)",
        resid > 0.55, f"שארית {resid:.2%}")
    hold = np.diff([f[1] for f in FLICKER])
    chk("אורכי הגמגום אינם קבועים",
        len({round(f[1], 3) for f in FLICKER}) >= 4,
        sorted({round(f[1], 3) for f in FLICKER}))

    # ---------------------------------------- 8. המצלמה והעומק
    chk("הקשת סוחפת לפחות 55 מעלות",
        float(np.ptp([c["yaw"] for c in tk.cams])) >= 55.0,
        f"{np.ptp([c['yaw'] for c in tk.cams]):.1f} מעלות")
    chk("וגם המרחק משתנה - זו קשת ולא פאן",
        float(np.ptp([c["dist"] for c in tk.cams])) > 0.35,
        f"{np.ptp([c['dist'] for c in tk.cams]):.3f}מ'")
    # קשת: מסלול המצלמה מעוקל. סטייה מהישר בין ההתחלה לסוף.
    a, b = tk.cpos[0], tk.cpos[-1]
    ab = b - a
    nab = float(np.linalg.norm(ab))
    dev = float(np.abs(np.cross(np.broadcast_to(ab, tk.cpos.shape),
                                tk.cpos - a)).max() / max(1e-9, nab))
    chk("מסלול המצלמה מעוקל ולא קו ישר", dev > 0.20, f"סטייה {dev:.3f}מ'")
    chk("המצלמה אינה נכנסת לתוך הדמויות",
        min(c["dist"] for c in tk.cams) > 1.10,
        f"{min(c['dist'] for c in tk.cams):.3f}מ'")
    chk("המצלמה אינה שוקעת מתחת לקרקע",
        float(tk.cpos[:, 1].min()) > 0.25, f"{tk.cpos[:, 1].min():.3f}מ'")
    foc = np.array([c["focus"] for c in tk.cams])
    dst = np.array([c["dist"] for c in tk.cams])
    chk("מרחק המיקוד עוקב אחרי הנושא ואינו קבוע",
        float(np.ptp(foc)) > 0.30
        and float(np.abs(foc - dst).max()) < 1e-6,
        f"{foc.min():.2f}..{foc.max():.2f}מ'")
    chk("עומק השדה נפתח בשיא הקשת",
        tk.cams[tk.n // 2]["dof"] > tk.cams[0]["dof"] * 1.5,
        (tk.cams[0]["dof"], tk.cams[tk.n // 2]["dof"]))

    # הכל בתוך הפריים: הסנאי והעלים מוקרנים לפי המצלמה בפועל.
    off = 0
    for i in range(0, tk.n, 3):
        sx, sy = project(tk.crit_pos[i] + np.array([0.0, 0.12, 0.0]),
                         tk.cams[i])
        if not (-0.35 <= sx <= 1.35):
            off += 1
    chk("הסנאי בפריים (או יוצא ממנו מרצון) ברוב השוט",
        off < tk.n // 3, f"{off} דגימות מחוץ לטווח")
    inside = 0
    for i in range(0, tk.n, 5):
        sx, sy = project(tk.leaf_pos[i].mean(axis=0), tk.cams[i])
        if 0.0 <= sx <= 1.0 and 0.0 <= sy <= 1.0:
            inside += 1
    chk("ענן העלים נמצא בתוך הפריים לכל אורך השוט",
        inside >= len(range(0, tk.n, 5)) - 1,
        f"{inside}/{len(range(0, tk.n, 5))}")

    # שתי השכבות מתלכדות: הערימה הצרובה והעלים התלת-ממדיים.
    # שכבת הקרקע רחבה מהפריים ב-PAD ומרוכזת, ולכן המרה ולא השוואה
    # ישירה. פער גדול כאן = ערימה שקופצת ברגע שהאנימציה מתחילה.
    sxp, syp = project(np.array(LEAF_ANCHOR), tk.cams[0])
    bx = (park.PROPS["leaves"]["at"][0] * park.PAD
          - (park.PAD - 1.0) / 2.0)
    by = park.PROPS["leaves"]["at"][1]
    chk("הערימה הצרובה והעלים התלת-ממדיים מתלכדים בפתיחה",
        abs(bx - sxp) < 0.06 and abs(by - syp) < 0.06,
        f"צרוב ({bx:.3f},{by:.3f}) מול מוקרן ({sxp:.3f},{syp:.3f})")

    # ---------------------------------------- 9. דטרמיניזם ומטען
    p1 = Take(secs=tk.secs, fps=tk.fps, ha=tk.ha, hb=tk.hb).payload(3.3)
    p2 = tk.payload(3.3)
    chk("אותו זמן -> אותו מטען בדיוק",
        json.dumps(p1, sort_keys=True) == json.dumps(p2, sort_keys=True),
        "זהה")
    pl = tk.payload(IMPACT_T + 0.5)
    chk("המטען מכיל את כל ערוצי הלהקה",
        set(pl) >= {"leaves", "crit", "lamp", "shake", "dof", "focus"},
        sorted(pl))
    chk("מערך העלים שטוח באורך 4 לכל עלה",
        len(pl["leaves"]) == LEAF_N * 4, len(pl["leaves"]))
    chk("ואין בו nan או inf",
        all(math.isfinite(x) for x in pl["leaves"]), "נקי")
    return out


def passed(take: Take | None = None) -> bool:
    return all(v["pass"] for v in audit(take).values())


def main(argv=None) -> int:
    import sys
    sys.stdout.reconfigure(encoding="utf-8")
    rep = audit()
    bad = 0
    for k, v in rep.items():
        print(("✅" if v["pass"] else "❌"), k, "-", v["detail"])
        bad += 0 if v["pass"] else 1
    print(f"\n{len(rep) - bad}/{len(rep)} עברו · "
          f"{LEAF_N} עלים · {len(CRITTER_PARTS)} איברי סנאי")
    return 0 if bad == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
