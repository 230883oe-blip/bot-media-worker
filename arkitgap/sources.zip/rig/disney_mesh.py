# -*- coding: utf-8 -*-
"""TASK 18 (06/10) - שפת הגיאומטריה האורגנית, נמדדת על הרשת עצמה.

`cast_disney` מגדיר את ארבע הדמויות; המודול הזה **מודד את מה שנבנה
בפועל**. ההפרדה אינה קוסמטית: אותה בקשה ל-`CAST` יכולה להיראות
נכונה לגמרי ולהפיק רשת פסולה, וזה מה שקרה כאן בשני מקומות.

================================================================
שני כשלים אמיתיים שנמצאו כאן, ולא היו נתפסים אחרת
================================================================

**1. "עיניים בוהות" הוא יחס, לא גודל.** האיסור בהוראה היה על
גלגל עין בלי ארובה שקועה. השער הקיים בפרויקט (`t_disney_appeal`)
בודק רק שהקרנית **פורצת** את העור - כלומר שיש עיניים - והוא עובר
גם כשהגלגל יושב כמעט כולו מחוץ לפנים. אריאל נמדד כאן בבליטה של
20.50 מ"מ מול רדיוס גלגל של 20.67: **0.992 מרדיוס העין מחוץ
לעור**. זו הגדרה מדויקת של עין מודבקת, והיא עברה כל שער קיים.
לכן השער כאן **דו-צדדי**: הבליטה חייבת להיות גדולה מ-0.5 מ"מ
(אחרת אין עיניים) וקטנה מ-45% מרדיוס הגלגל (אחרת העין מונחת על
העור ולא בתוכו).

**2. "אין צוואר-צינור" הוא צורת הפרופיל, לא מספר הטבעות.** גם
לוקאס - הצוואר-צינור המקורי - יש שמונה טבעות מעל מפרק הצוואר.
מה שמבדיל צינור מעקומת S הוא **מינימום פנימי** בחצי-הרוחב:
הצוואר מצטר כלפי מעלה, מגיע למינימום, ואז **מתרחב שוב** אל
בסיס הראש. בלוקאס הרוחב יורד מונוטונית עד הטבעת האחרונה
(0.168 -> 0.0490), כלומר חרוט; בארבע הדמויות כאן המינימום הוא
פנימי (0.0543 ואז 0.0558, 0.0645, 0.0700 אצל אריאל). מדידה של
מספר הטבעות בלבד הייתה מאשרת את לוקאס, ומדידת השבר המשיק בלבד
הייתה מאשרת חרוט חלק.

================================================================
מה נמדד, ועל מה
================================================================

הכול נמדד על `basemesh.build` של הדמות **דרך `CAST`**, ולא על
העתק מקומי של המספרים: המטרה היא למדוד את הרשת שתיכתב ל-GLB.
"""
from __future__ import annotations

import math
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
if str(HERE.parent) not in sys.path:
    sys.path.insert(0, str(HERE.parent))

from rig import basemesh as BM                           # noqa: E402
from rig import cast_disney as CD                        # noqa: E402
from rig import detail as DT                             # noqa: E402
from rig import dimorph as DM                            # noqa: E402
from rig import organic as O                             # noqa: E402
from rig import pipeline as PL                           # noqa: E402

#: חלון הבליטה של הקרנית, ביחידות רדיוס גלגל העין.
#: הרצפה היא "יש עיניים", התקרה היא "העין אינה מודבקת".
EYE_OUT_MIN_M = 0.0005
EYE_OUT_MAX_R = 0.45

#: מרווח מינימלי בין שתי העיניים (כדי שלא ייקראו כתם אחד).
EYE_GAP_MIN_M = 0.0015

#: תקרת החדות על פני העור. נמדד 115-153 בארבע הדמויות, והתקרה
#: 175 חוסמת הידרדרות בלי לחסום את מה שקיים.
SHARP_P99_MAX = 175.0

#: הצוואר: מספר טבעות מעל מפרק הצוואר, ושבר משיק מרבי.
NECK_RINGS_MIN = 6
TANGENT_BREAK_MAX = 3.5

#: TASK 19 · תקרת השבר ב**קו הצללית** מהחזה אל קודקוד הצוואר. זה
#: מדד אחר מ-`TANGENT_BREAK_MAX`, שמודד את ציר הטבעות: ראה
#: `organic.polyline_break`. נמדד 51.9°-59.5° לפני התיקון ו-
#: 12.9°-16.2° אחריו, והתקרה 20° חוסמת הידרדרות בלי לחסום את זה.
SIL_BREAK_MAX = 20.0

#: TASK 19 · קעירות הארובה המינימלית, ביחידות רדיוס גלגל העין.
#: הרצפה 0.10 היא "יש מכתש ולא מישור" - נמדד 0.135-0.539 בארבע.
SOCKET_DIP_MIN = 0.10

#: קופסתיות הכתף. 1.000 הוא אליפסה מדויקת.
SQUARENESS_MAX = 1.01

SPINE = ("hips", "spine_01", "spine_02", "chest", "neck")


#: TASK 20 · תקרת השבר ב**מעטפת הצללית** באזור האגן-ירך. נמדד
#: 65.1°-118.6° לפני התיקון, והתקרה 20° היא אותה תקרה שנקבעה
#: ב-`SIL_BREAK_MAX` לאזור החזה-צוואר - אותו סוג מדד, אותו סף.
HIP_BREAK_MAX = 20.0

#: TASK 20 · הפרש מינימלי בין שיא האונה לשקע הסטרנום, במטרים.
#: 0.0015 הוא "יש שתי אונות ולא אחת" ולא קוסמטיקה: הפרש אפס או
#: שלילי פירושו שהמקסימום יושב ב-x=0, כלומר בליטה מרכזית אחת.
BUST_DIP_MIN = 0.0015
#: והמרחק המינימלי בין שתי האונות, במטרים. בלעדיו שתי אונות
#: צמודות היו עוברות כ"דו-אוני" והן נראות כבליטה אחת.
BUST_GAP_MIN = 0.020


def _ring_outline(V: np.ndarray, lo: int, hi: int,
                  tol: float = 1e-6) -> list[tuple[float, float]]:
    """[(גובה, חצי-הרוחב המרבי)] לכל טבעת בקבוצה, מהרשת עצמה.

    הקיבוץ הוא לפי Y **מדויק**, וזה תקף כאן ולא מקרי: כל הצינורות
    בגוף נבנים עם ציר Y (`twist_axis=(0,1,0)` או מסגרת מפורשת
    X/-Z), ולכן כל טבעת שוכנת במישור אופקי אחד. בקיבוץ לפי מרחק
    היו שתי טבעות סמוכות מתלכדות לאחת ושבר ביניהן נעלם.
    """
    rows: dict[int, float] = {}
    cnt: dict[int, int] = {}
    for i in range(lo, hi):
        key = int(round(float(V[i, 1]) / tol))
        x = abs(float(V[i, 0]))
        cnt[key] = cnt.get(key, 0) + 1
        if x > rows.get(key, -1.0):
            rows[key] = x
    # **קודקוד בודד בגובה מסוים אינו טבעת, והסינון הזה הוא באג
    # שנמדד.** `tube` מוסיף למניפת הכיסוי קודקוד **מרכז** אחד,
    # וההחלקה מזיזה את טבעת הקצה בשבריר מילימטר - ולכן המרכז נשאר
    # לבד בגובה משלו. הוא נקרא כ"טבעת" בחצי-רוחב `cx` במקום
    # `cx+rx`, ונמדד 0.1139 -> 0.0701 על 0.1 מ"מ, כלומר שבר 88.9°
    # על גאומטריה שאינה נראית בכלל (היא קבורה בתוך הטורסו).
    return sorted((k * tol, w) for k, w in rows.items()
                  if cnt.get(k, 0) >= 4)


def hip_silhouette(mb, V: np.ndarray, y0: float, y1: float,
                   n: int = 48) -> list[tuple[float, float]]:
    """מעטפת הצללית בין `y0` ל-`y1`: חצי-הרוחב המרבי לכל גובה.

    **זו הנקודה שבה שתי מדידות קודמות שלי היו שגויות, ושתיהן
    בכיוון ההפוך זו מזו - לכן זה מתועד כאן ולא בהערת שורה.**

    1. **דגימה ברצועות Y של הקודקודים** החזירה 173°-178°. הסיבה:
       הטורסו והרגל הם שני צינורות עם מרווחי טבעות **שונים**,
       ורצועה צרה תופסת לפעמים טבעת של זה ולפעמים של זה - כלומר
       הפוליליין מקפץ בין שני משטחים שונים. זה מדד את הפרש
       הדגימה, לא את הצללית.
    2. **איחוד רשימות הטבעות של שני הצינורות** החזיר 88°, מאותה
       סיבה בכיוון הפוך: בגבהים שבהם לצינור אחד אין טבעת, הוא
       נעדר מהמעטפת לגמרי - גם כשהמשטח שלו הוא הרוחב המרבי שם.

    מה שנכון: כל צינור הוא משטח **ליניארי בין טבעותיו**, ולכן
    חצי-הרוחב שלו בכל גובה הוא אינטרפולציה - והצללית היא ה-max
    על הצינורות, בדיוק כמו שהעין רואה. צינור שהטווח שלו אינו
    מכסה את הגובה הנדגם אינו משתתף (ולא נמשך בקיצוע).
    """
    outs = []
    for name, lo, hi in mb.groups:
        if name != "torso" and not name.startswith("leg_"):
            continue
        ol = _ring_outline(V, lo, hi)
        if len(ol) >= 2:
            outs.append(ol)
    pts = []
    for j in range(n):
        y = y0 + (y1 - y0) * j / (n - 1)
        best = -1.0
        for ol in outs:
            if y < ol[0][0] - 1e-9 or y > ol[-1][0] + 1e-9:
                continue
            for (ya, wa), (yb, wb) in zip(ol, ol[1:]):
                if ya - 1e-9 <= y <= yb + 1e-9:
                    u = 0.0 if yb - ya < 1e-12 else (y - ya) / (yb - ya)
                    best = max(best, wa + (wb - wa) * u)
                    break
        if best > 0.0:
            pts.append((y, best))
    return pts


def bust_contour(V: np.ndarray, lo: int, hi: int, y_bust: float
                 ) -> list[tuple[float, float]]:
    """[(x, z)] של הטבעת הקדמית הקרובה לגובה האונות, ממוינת ב-X."""
    ys = sorted({round(float(V[i, 1]), 5) for i in range(lo, hi)})
    if not ys:
        return []
    yr = min(ys, key=lambda y: abs(y - y_bust))
    row = [(float(V[i, 0]), float(V[i, 2])) for i in range(lo, hi)
           if abs(float(V[i, 1]) - yr) < 1e-4 and float(V[i, 2]) > 0.0]
    return sorted(row)


def build(name: str, quality: str = "fast") -> dict:
    """בונה דמות ומחזיר את כל מה שנמדד עליה, פעם אחת.

    הבנייה היא הפעולה היקרה כאן (כ-8-10 אלף קודקודים), ושמונה
    השערים למטה צריכים את אותה רשת. בנייה פר שער הייתה שמונה
    בניות לאותה דמות - וגם סיכון שהן אינן זהות.
    """
    c = PL.CAST[name]
    sh = dict(c["shape_override"])
    skel = PL.cast_skeleton(name)
    P = {b.name: np.asarray(b.rest, float) for b in skel.bones}
    H = DT.Head(P, float(c["height"]) / 1.70, sh)
    mb, _meta = BM.build(skel, sh, quality=quality)
    V = np.asarray(mb.v, float)
    I = np.asarray(mb.f, np.uint32).reshape(-1)
    tag = np.array([t or "none" for t in mb.tag])

    probe = DT.skin_probe(mb, H)
    # הקרנית: הנקודה הקדמית ביותר של גלגל העין, במרחק מ**מרכז
    # הראש** - כי `skin_probe` מחזיר רדיוס לכיוון, ולא גובה מעל
    # מישור. חישוב ב-Z בלבד היה מודד נכון רק במרכז הפנים.
    d = H.eye_center("L") - H.hc + np.array([0.0, 0.0, H.eye_r])
    eye_out = float(np.linalg.norm(d)) - float(probe(d))
    eye_gap = abs(float(H.eye_center("L")[0] - H.eye_center("R")[0])) \
        - 2.0 * H.eye_r

    dm = DM.get(sh.get("dimorph"))
    prof = DM.torso_profile(dm)
    neck = [r for r in prof if r[0] > 1.0]
    # חצי-הרוחב מהחזה ומעלה. זה הקטע שבו נמצאת עקומת ה-S.
    seg = [r for r in prof if r[0] >= 0.90]
    w = [float(r[1]) for r in seg]
    amin = int(np.argmin(w)) if w else 0

    # השרשרת: מרכזי הטבעות על ספליין עמוד השדרה, בדיוק כמו
    # ש-`basemesh` בונה אותם.
    sp = [P[n] for n in SPINE]
    sp = ([sp[0] * 2 - sp[1]] + sp
          + [P["head"], P["head"] + (P["head"] - P["neck"]) * 1.25])
    un = float(len(SPINE) - 1)

    def C(t):
        if t <= 1.0:
            return O.catmull_rom(sp, un * max(0.0, t))
        return O.catmull_rom(sp, un + (t - 1.0) * 3.2)

    chain = [C(r[0]) for r in prof if r[0] >= 0.5]

    # --- TASK 19 · קו הצללית מהחזה אל קודקוד הצוואר, ביחידות אורך.
    # `k` מחזיר את חצי-הרוחב למטרים (הפרופיל הוא ביחידות גוף), ו-y
    # נלקח מהספליין עצמו - אחרת ההשוואה בין רוחב לגובה אינה גאומטרית.
    kh = float(c["height"]) / 1.70
    sil = [(float(r[1]) * kh, float(C(r[0])[1]))
           for r in prof if 0.60 <= r[0] <= 1.34]
    sil_break = O.polyline_break(sil)

    # --- TASK 19 · קעירות הארובה. הבליטה של הקרנית (`eye_out`) אינה
    # מעידה עליה כלל: עין יכולה לבלוט מעט גם ממשטח **שטוח לגמרי**,
    # וזה בדיוק המראה של "מדבקה על הפנים". כאן נמדד העור עצמו - רדיוס
    # העור בכיוון מרכז העין מול הרדיוס בטבעת סביבו. חיובי = מכתש.
    dips = []
    for side in ("L", "R"):
        e = H.eye_center(side) - H.hc
        e = e / max(1e-9, float(np.linalg.norm(e)))
        up = np.cross(e, np.array([1.0, 0.0, 0.0]))
        up = up / max(1e-9, float(np.linalg.norm(up)))
        rt = np.cross(up, e)
        rt = rt / max(1e-9, float(np.linalg.norm(rt)))
        ring = [float(probe(e * H.R + (math.cos(a) * rt + math.sin(a) * up)
                            * 1.7 * H.eye_r))
                for a in (2 * math.pi * j / 12 for j in range(12))]
        dips.append((float(np.mean(ring)) - float(probe(e * H.R)))
                    / float(H.eye_r))

    # --- TASK 20 · מעטפת הצללית מהאגן אל הירך. החלון נגזר מהשלד
    # (מפרק הירך ומפרק האגן) ולא מספרים קבועים, כי הוא צריך להיות
    # אותו אזור אנטומי בדמות של 1.20 מ' ובדמות של 1.85.
    y_thigh, y_hip = float(P["thigh_L"][1]), float(P["hips"][1])
    hip_sil = hip_silhouette(mb, V, y_thigh - 0.050 * kh,
                             y_hip + 0.080 * kh)
    hip_break = O.polyline_break([(w, y) for y, w in hip_sil])

    # --- TASK 20 · הקונטור הדו-אוני. `bust_dip` חייב להיות **חיובי**:
    # אפס פירושו שהמקסימום הקדמי יושב ב-x=0, וזו בליטה מרכזית אחת.
    tv = {g[0]: (g[1], g[2]) for g in mb.groups}.get("torso", (0, 0))
    bc = bust_contour(V, tv[0], tv[1], float(C(DM.BUST_T)[1]))
    if bc:
        z_mid = min(bc, key=lambda p: abs(p[0]))[1]
        px, pz = max(bc, key=lambda p: p[1])
        bust_dip, bust_gap = pz - z_mid, 2.0 * abs(px)
    else:
        bust_dip, bust_gap = 0.0, 0.0

    return {
        "hip_break": float(hip_break),
        "hip_sil_n": int(len(hip_sil)),
        "hip_blend": float(getattr(dm, "hip_blend", 0.0) or 0.0),
        "bust_lobe": float(getattr(dm, "bust_lobe", 0.0) or 0.0),
        "bust_moved": int(getattr(mb, "bust_moved", 0) or 0),
        "bust_dip": float(bust_dip),
        "bust_gap": float(bust_gap),
        "sil_break": float(sil_break),
        "socket_dip": float(min(dips)),
        "rings": int(len(prof)),
        "name": name, "height": float(c["height"]),
        "verts": int(len(V)), "faces": int(len(I) // 3),
        "eye_out": eye_out, "eye_r": float(H.eye_r),
        "eye_ratio": eye_out / float(H.eye_r),
        "eye_gap": eye_gap,
        "sharp": O.smoothness(V, I, None, tag),
        "degenerate": int(O.degenerate_faces(V, I)),
        "neck_rings": len(neck),
        "neck_w": w, "neck_argmin": amin,
        "neck_s": 0 < amin < len(w) - 1,
        "tangent_break": float(O.tangent_break(chain)),
        "squareness": float(DM.measure(mb, skel)["shoulder_squareness"]),
        "tags": sorted(set(tag.tolist())),
        "face_req": dict(sh.get("face") or {}),
    }


# ============================================================== שערים


def audit(quality: str = "fast") -> dict:
    out: dict = {}
    m = {nm: build(nm, quality) for nm in CD.CAST4}

    def chk(name, ok, detail):
        out[name] = {"pass": bool(ok), "detail": str(detail)}

    short = {nm: CD.ROLE[nm].split(" · ")[0] for nm in CD.CAST4}

    # 1 · העין: שני הצדדים. ראה הכשל הראשון בראש הקובץ.
    bad = [nm for nm in CD.CAST4 if m[nm]["eye_out"] <= EYE_OUT_MIN_M]
    chk("בכל ארבע הדמויות הקרנית פורצת את העור", not bad,
        bad or " · ".join(f"{short[nm]} {m[nm]['eye_out'] * 1000:.2f} מ\"מ"
                          for nm in CD.CAST4))
    bad = [nm for nm in CD.CAST4 if m[nm]["eye_ratio"] > EYE_OUT_MAX_R]
    chk(f"ואף עין אינה בולטת מעל {EYE_OUT_MAX_R:.0%} מרדיוס הגלגל",
        not bad,
        bad or " · ".join(f"{short[nm]} {m[nm]['eye_ratio']:.3f}"
                          for nm in CD.CAST4))
    bad = [nm for nm in CD.CAST4 if m[nm]["eye_gap"] <= EYE_GAP_MIN_M]
    chk("ושתי העיניים אינן מתלכדות לכתם אחד", not bad,
        bad or " · ".join(f"{short[nm]} {m[nm]['eye_gap'] * 1000:.1f} מ\"מ"
                          for nm in CD.CAST4))

    # 2 · הצוואר: עקומת S ולא צינור. ראה הכשל השני בראש הקובץ.
    bad = [nm for nm in CD.CAST4 if m[nm]["neck_rings"] < NECK_RINGS_MIN]
    chk(f"לכל צוואר לפחות {NECK_RINGS_MIN} טבעות", not bad,
        bad or " · ".join(f"{short[nm]} {m[nm]['neck_rings']}"
                          for nm in CD.CAST4))
    bad = [nm for nm in CD.CAST4 if not m[nm]["neck_s"]]
    chk("והפרופיל הוא S: מינימום פנימי ואז התרחבות אל הראש", not bad,
        bad or " · ".join(
            f"{short[nm]} מינימום ב-{m[nm]['neck_argmin']}"
            f"/{len(m[nm]['neck_w']) - 1}" for nm in CD.CAST4))
    bad = [nm for nm in CD.CAST4
           if m[nm]["tangent_break"] >= TANGENT_BREAK_MAX]
    chk(f"והשבר המשיק בשרשרת מתחת ל-{TANGENT_BREAK_MAX}°", not bad,
        bad or " · ".join(f"{short[nm]} {m[nm]['tangent_break']:.2f}°"
                          for nm in CD.CAST4))

    # 2ב · TASK 19: קו הצללית, ובסיס הצוואר בכלל זה.
    bad = [nm for nm in CD.CAST4 if m[nm]["sil_break"] > SIL_BREAK_MAX]
    chk(f"והשבר ב**קו הצללית** חזה->צוואר מתחת ל-{SIL_BREAK_MAX:.0f}°",
        not bad,
        bad or " · ".join(f"{short[nm]} {m[nm]['sil_break']:.1f}°"
                          for nm in CD.CAST4))

    # 2ד · TASK 20: האגן והירכיים הם משטח אחד רציף, לא גליל שנדחף
    #      לתוך דיסקה. זה מדד שלישי ונפרד: `tangent_break` מודד את
    #      ציר הטבעות, `sil_break` את קו הצללית **של הטורסו לבדו**
    #      מהחזה ומעלה, וכאן נמדדת ה**מעטפת** של הטורסו והרגל יחד -
    #      כלומר מה שהעין רואה במפגש בין שני הצינורות. שני המדדים
    #      הקיימים עברו בציון מלא בזמן שהמפגש הזה היה 65°-119°.
    bad = [nm for nm in CD.CAST4 if m[nm]["hip_break"] > HIP_BREAK_MAX]
    chk(f"ומעטפת הצללית אגן->ירך מתחת ל-{HIP_BREAK_MAX:.0f}°", not bad,
        bad or " · ".join(f"{short[nm]} {m[nm]['hip_break']:.1f}°"
                          for nm in CD.CAST4))
    bad = [nm for nm in CD.CAST4 if m[nm]["hip_blend"] <= 0.0]
    chk("וכל ארבע הדמויות ביקשו את המיזוג", not bad,
        bad or " · ".join(f"{short[nm]} {m[nm]['hip_blend']:.2f}"
                          for nm in CD.CAST4))

    # 2ה · TASK 20: הקונטור הנשי הוא **דו-אוני**, לא חזה גלילי
    #      שנדחף קדימה. `bust_dip<=0` פירושו שהנקודה הקדמית ביותר
    #      יושבת ב-x=0, וזו בליטה מרכזית אחת - בדיוק מה שנמדד לפני.
    lob = [nm for nm in CD.CAST4 if m[nm]["bust_lobe"] > 0.0]
    chk("יש בהרכב דמות עם קונטור חזה נשי", bool(lob),
        " · ".join(f"{short[nm]} {m[nm]['bust_lobe']:.3f}" for nm in lob)
        or "אין אף אחת")
    bad = [nm for nm in lob if m[nm]["bust_dip"] < BUST_DIP_MIN]
    chk("ושקע הסטרנום בין שתי האונות נמדד (המקסימום אינו ב-x=0)",
        not bad,
        bad or " · ".join(f"{short[nm]} {m[nm]['bust_dip'] * 1000:.2f} מ\"מ"
                          for nm in lob))
    bad = [nm for nm in lob if m[nm]["bust_gap"] < BUST_GAP_MIN]
    chk("והאונות מרוחקות זו מזו ואינן נקראות כבליטה אחת", not bad,
        bad or " · ".join(f"{short[nm]} {m[nm]['bust_gap'] * 1000:.0f} מ\"מ"
                          for nm in lob))
    bad = [nm for nm in lob if m[nm]["bust_moved"] <= 0]
    chk("והשדה באמת הוחל על קודקודים ולא רק הוגדר", not bad,
        bad or " · ".join(f"{short[nm]} {m[nm]['bust_moved']}" for nm in lob))

    # 2ג · TASK 19: הארובה היא מכתש בעור, ולא רק עין שבולטת ממשטח.
    bad = [nm for nm in CD.CAST4 if m[nm]["socket_dip"] < SOCKET_DIP_MIN]
    chk(f"והעור שוקע סביב העין לפחות {SOCKET_DIP_MIN:.2f} מרדיוס הגלגל",
        not bad,
        bad or " · ".join(f"{short[nm]} {m[nm]['socket_dip']:.3f}"
                          for nm in CD.CAST4))

    # 3 · פני העור: חדות ושלמות
    bad = [nm for nm in CD.CAST4
           if float(m[nm]["sharp"]["p99"]) > SHARP_P99_MAX]
    chk(f"חדות פני העור (p99) מתחת ל-{SHARP_P99_MAX:.0f}°", not bad,
        bad or " · ".join(f"{short[nm]} {m[nm]['sharp']['p99']:.0f}°"
                          for nm in CD.CAST4))
    bad = [nm for nm in CD.CAST4 if m[nm]["degenerate"]]
    chk("ואין אף פאה מנוונת", not bad,
        bad or f"0 בכל {len(CD.CAST4)}")

    # 4 · אפס קופסתיות
    bad = [nm for nm in CD.CAST4 if m[nm]["squareness"] > SQUARENESS_MAX]
    chk("אף חתך כתף אינו קופסתי", not bad,
        bad or " · ".join(f"{short[nm]} {m[nm]['squareness']:.3f}"
                          for nm in CD.CAST4))
    flat = ("skull_box", "crown_flat", "limb_square", "skull_square")
    bad = [f"{nm}/{k}" for nm in CD.CAST4 for k in flat
           if float(m[nm]["face_req"].get(k, 0.0)) != 0.0]
    chk("ואף ערוץ שיטוח אינו פעיל (קופסה, קודקוד שטוח, גפה מרובעת)",
        not bad, bad or "כל הערוצים באפס")

    # 5 · הקווים שחייבים להישאר חדים קיימים ברשת. בלעדיהם ההחלקה
    #     מורחת את השפתיים ואת הנחיריים אל תוך הלחיים - וזו הדרישה
    #     ההפוכה מ"רך ועגול", שמתקיימת רק בגלל תיוג הקצה.
    need = ("lip_up", "lip_lo", "lash", "iris", "sclera", "brow")
    bad = [f"{nm}:{k}" for nm in CD.CAST4 for k in need
           if k not in m[nm]["tags"]]
    chk("קווי השפתיים, הריס, הקשתית והגבה מתויגים בכל הארבע",
        not bad, bad or " · ".join(need))

    out["_measured"] = {nm: {k: v for k, v in m[nm].items()
                             if k not in ("neck_w", "tags", "face_req")}
                        for nm in CD.CAST4}
    return out


def passed(quality: str = "fast") -> bool:
    return all(v["pass"] for k, v in audit(quality).items()
               if not k.startswith("_"))


def main(argv=None) -> int:
    import argparse                                      # noqa: PLC0415
    import json                                          # noqa: PLC0415
    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(
        description="שפת הגיאומטריה האורגנית (TASK 18)")
    ap.add_argument("--quality", default="fast", choices=["fast", "full"])
    ap.add_argument("--json", default="")
    a = ap.parse_args(argv)
    rep = audit(a.quality)
    bad = 0
    for k, v in rep.items():
        if k.startswith("_"):
            continue
        print(("✅" if v["pass"] else "❌"), k, "-", v["detail"])
        bad += 0 if v["pass"] else 1
    n = sum(1 for k in rep if not k.startswith("_"))
    print(f"\n{n - bad}/{n} עברו")
    if a.json:
        Path(a.json).write_text(json.dumps(rep, ensure_ascii=False,
                                           indent=1, default=float),
                                encoding="utf-8")
    return 0 if bad == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
