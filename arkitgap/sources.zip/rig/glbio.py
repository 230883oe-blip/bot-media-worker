# -*- coding: utf-8 -*-
"""קריאה וכתיבה של GLB, כולל **שלד ועור** (skin/joints/inverseBindMatrices).

למה לכתוב כותב GLB ולא להסתפק בסצנה של three.js:
דמות שקיימת רק בתוך דף HTML אחד אינה צינור ייצור. GLB עם skin נטען
ב-Blender, ב-Unity, ב-Unreal, ב-three.js וב-Windows 3D Viewer - וזה
ההבדל בין "ציור שזז" לבין נכס הפקה.

מלכודות שנמדדו בפועל מול המפרט:
* כל bufferView חייב ליישור 4 בתים. אינדקסים של uint32 ו-JOINTS_0 של
  uint16 מייצרים אורכים שאינם כפולה של 4, והצופה פשוט מציג רשת ריקה
  בלי שגיאה. לכן יש padding אחרי כל view.
* accessor של POSITION **חייב** min/max, אחרת GLTFLoader זורק.
* WEIGHTS_0 חייב להיות מנורמל לסכום 1, אחרת הדמות מתנפחת.
* צומת הרשת לא יכולה להיות בת-צומת של מפרק (joint), אחרת הטרנספורם
  מוחל פעמיים והדמות עפה מהפריים.
"""
from __future__ import annotations

import base64
import json
import struct

import numpy as np

FLOAT, USHORT, UINT = 5126, 5123, 5125
ARRAY_BUFFER, ELEMENT_ARRAY = 34962, 34963


# ---------------------------------------------------------------- קריאה


def read_glb(path):
    """מחזיר (json, binary_chunk)."""
    b = open(path, "rb").read()
    magic, ver, total = struct.unpack_from("<III", b, 0)
    if magic != 0x46546C67:
        raise ValueError("זה לא GLB")
    off, js, bin_ = 12, None, b""
    while off < total:
        clen, ctype = struct.unpack_from("<II", b, off)
        data = b[off + 8: off + 8 + clen]
        if ctype == 0x4E4F534A:
            js = json.loads(data.decode("utf-8"))
        elif ctype == 0x004E4942:
            bin_ = data
        off += 8 + clen
    if js is None:
        raise ValueError("ב-GLB אין מקטע JSON")
    return js, bin_


_NCOMP = {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4, "MAT4": 16}
_DT = {5120: np.int8, 5121: np.uint8, 5122: np.int16, 5123: np.uint16,
       5125: np.uint32, 5126: np.float32}


def accessor(js, bin_, i):
    a = js["accessors"][i]
    n = _NCOMP[a["type"]]
    dt = _DT[a["componentType"]]
    bv = js["bufferViews"][a["bufferView"]]
    off = bv.get("byteOffset", 0) + a.get("byteOffset", 0)
    stride = bv.get("byteStride")
    cnt = a["count"]
    if stride and stride != n * np.dtype(dt).itemsize:
        out = np.empty((cnt, n), dtype=dt)
        for r in range(cnt):
            out[r] = np.frombuffer(bin_, dtype=dt, count=n,
                                   offset=off + r * stride)
        return out
    arr = np.frombuffer(bin_, dtype=dt, count=cnt * n, offset=off)
    return arr.reshape(cnt, n) if n > 1 else arr


def first_mesh_positions(path):
    """עמדות הרשת הראשונה ב-GLB, במרחב העולם. לשימוש בהעברת זהות."""
    js, bin_ = read_glb(path)
    prim = js["meshes"][0]["primitives"][0]
    pos = accessor(js, bin_, prim["attributes"]["POSITION"]).astype(np.float64)
    return pos


# ---------------------------------------------------------------- כתיבה


class _Blob:
    def __init__(self):
        self.parts = []
        self.size = 0

    def add(self, arr: np.ndarray, target=None):
        data = np.ascontiguousarray(arr).tobytes()
        pad = (-self.size) % 4
        if pad:
            self.parts.append(b"\0" * pad)
            self.size += pad
        off = self.size
        self.parts.append(data)
        self.size += len(data)
        return off, len(data)

    def bytes(self):
        pad = (-self.size) % 4
        return b"".join(self.parts) + b"\0" * pad


# --------------------------------------------------- חומרים (גימור פני השטח)
#
# למה בכלל יותר מחומר אחד (05/10, סבב רביעי):
# כל הדמות נכתבה בחומר יחיד עם roughnessFactor=0.55. 0.55 הוא גימור
# חצי-מבריק - בדיוק הטווח שבו אור מכוון מייצר הבהק לבן רחב - ולכן
# **השיער** נראה כפלסטיק יצוק. שיער כהה הוא כמעט דיפוזי לחלוטין,
# ולהפך: גלגל העין חייב להיות החלק הכי מבריק בדמות, אחרת העין יוצאת
# "מתה" בתקריב. חומר אחד אינו יכול להיות שני הדברים.
#
# הפיצול הוא ל-primitives שחולקים **בדיוק את אותם accessors** של
# POSITION/NORMAL/UV/JOINTS/WEIGHTS ואת אותם morph targets, ונבדלים
# רק ב-indices וב-material. זו הדרך התקנית בגלטף, היא לא משכפלת
# קודקוד אחד, והיא נטענת כמו שצריך גם בבלנדר וגם ב-three.js.
# (שלוש דעות חיצוניות נשאלו ב-05/10 והמליצו על זה פה אחד, מול
#  החלופה של קידוד roughness באלפא של COLOR_0 + onBeforeCompile,
#  שנפסלה כי היא שבירה מול skinning+morphs.)

MATERIALS = {
    # גימור מט לגמרי: שיער, גבות, ריסים. metallic=0 מוחלט.
    # 0.90+0.30 נמדד ברנדור כמט **מדי**: שיער שחור יצא כתם דיו שטוח
    # בלי שום קריאה של נפח. לשיער אמיתי יש הבהק - רק רך ורחב, ולא
    # נקודת אור חדה. 0.84/0.42 הוא הטווח שבו נראה המרקם ולא הפלסטיק.
    "hair": {"roughness": 0.84, "metallic": 0.0, "specular": 0.42},
    # עור: לא 0.55. עור אנושי מפזר יותר, וב-0.55 גם הוא קיבל ברק.
    "skin": {"roughness": 0.68, "metallic": 0.0, "specular": 1.0},
    # גלגל העין - הדבר היחיד בדמות שאמור להבריק.
    "eye": {"roughness": 0.08, "metallic": 0.0, "specular": 1.0},
}

# איזו תגית קודקוד שייכת לאיזה חומר. תגית שאינה כאן נופלת ל-skin.
TAG_MATERIAL = {
    "hair": "hair", "brow": "hair", "lash": "hair",
    "sclera": "eye", "iris": "eye", "pupil": "eye", "limbal": "eye",
}


def material_def(kind: str) -> dict:
    m = MATERIALS[kind]
    d = {
        "name": kind,
        "pbrMetallicRoughness": {
            "baseColorFactor": [1.0, 1.0, 1.0, 1.0],
            "metallicFactor": m["metallic"],
            "roughnessFactor": m["roughness"]},
        # דו-צדדי: הדמות מורכבת מעשרות גופים קטנים שנבנים בשיקוף
        # (עפעף שמאל/ימין, ריסים, גבות). שיקוף הופך את סדר הפאות,
        # ואז צד אחד נעלם ברנדור בלי שום שגיאה. 05/10.
        "doubleSided": True,
    }
    if m["specular"] < 1.0:
        # ההבהק עצמו, ולא רק פיזורו. גם ב-roughness 0.9 נשאר הבהק
        # רחב וחיוור על השיער; specularFactor מנמיך את עוצמתו.
        # הסיומת אופציונלית במפרט: צופה שאינו מכיר אותה פשוט מתעלם
        # ומקבל חומר מט תקין, ולכן היא אינה נכנסת ל-extensionsRequired.
        d["extensions"] = {"KHR_materials_specular":
                           {"specularFactor": m["specular"]}}
    return d


def split_indices(index: np.ndarray, tags) -> list:
    """מחלק את מערך האינדקסים לפי חומר, לפי התגיות של הקודקודים.

    משולש משויך לחומר רק אם **כל** שלושת קודקודיו שייכים לו. משולש
    מעורב (למשל על התפר שבין השיער לעור) נשאר ב-skin: הוא דק, הוא
    יושב בגבול, ושיוכו לחומר המט היה פותח שם קו מט לאורך כל קו
    השיער. מחזיר [(kind, index_array), ...] כש-skin תמיד ראשון.
    """
    kinds = np.array([TAG_MATERIAL.get(t or "", "skin") for t in tags])
    tri = np.asarray(index).reshape(-1, 3)
    out = []
    taken = np.zeros(tri.shape[0], dtype=bool)
    for kind in ("hair", "eye"):
        sel = (kinds[tri] == kind).all(axis=1) & ~taken
        if sel.any():
            taken |= sel
            out.append((kind, tri[sel].reshape(-1)))
    out.insert(0, ("skin", tri[~taken].reshape(-1)))
    return [(k, a) for k, a in out if a.size]


def write_skinned_glb(path, attrs: dict, skel, *, name="character",
                      color=None, material=None, morphs=None, tags=None):
    """כותב GLB עם SkinnedMesh אחת ושלד מלא.

    attrs: position/normal/uv/skinIndex/skinWeight/index (ראה basemesh)
    color: (N,3) או (N,4) float ב-[0,1] - נכתב כ-COLOR_0
    morphs: {"names": [...], "deltas": (S,N,3)} מ-`face.build` - נכתב
        כ-morph targets תקניים. השמות נכתבים ל-`mesh.extras.targetNames`,
        וזה **הדבר היחיד** שגורם ל-three.js לבנות `morphTargetDictionary`;
        בלי זה הצורות נטענות אבל אין להן שמות, וכל קריאה לפי שם
        נכשלת בשקט. אורך השמות חייב להיות בדיוק כמספר ה-targets,
        אחרת GLTFLoader מדפיס אזהרה **ומתעלם מכל השמות**.
    """
    blob = _Blob()
    views, accs = [], []

    def add_acc(arr, comp_type, atype, target, minmax=False, normalized=False):
        off, ln = blob.add(arr)
        views.append({"buffer": 0, "byteOffset": off, "byteLength": ln,
                      **({"target": target} if target else {})})
        a = {"bufferView": len(views) - 1, "componentType": comp_type,
             "count": int(arr.shape[0]), "type": atype}
        if normalized:
            a["normalized"] = True
        if minmax:
            a["min"] = [float(x) for x in np.min(arr, axis=0)]
            a["max"] = [float(x) for x in np.max(arr, axis=0)]
        accs.append(a)
        return len(accs) - 1

    a_pos = add_acc(attrs["position"].astype(np.float32), FLOAT, "VEC3",
                    ARRAY_BUFFER, minmax=True)
    a_nrm = add_acc(attrs["normal"].astype(np.float32), FLOAT, "VEC3",
                    ARRAY_BUFFER)
    a_uv = add_acc(attrs["uv"].astype(np.float32), FLOAT, "VEC2", ARRAY_BUFFER)
    a_ji = add_acc(attrs["skinIndex"].astype(np.uint16), USHORT, "VEC4",
                   ARRAY_BUFFER)
    a_jw = add_acc(attrs["skinWeight"].astype(np.float32), FLOAT, "VEC4",
                   ARRAY_BUFFER)
    attributes = {"POSITION": a_pos, "NORMAL": a_nrm, "TEXCOORD_0": a_uv,
                  "JOINTS_0": a_ji, "WEIGHTS_0": a_jw}
    if color is not None:
        c = np.asarray(color, dtype=np.float32)
        if c.shape[1] == 3:
            c = np.concatenate([c, np.ones((c.shape[0], 1), np.float32)], 1)
        attributes["COLOR_0"] = add_acc(c, FLOAT, "VEC4", ARRAY_BUFFER)
    # --- חלוקה ל-primitives לפי חומר (ראה MATERIALS למעלה)
    if tags is not None and material is None:
        groups = split_indices(attrs["index"], tags)
    else:
        groups = [("skin", np.asarray(attrs["index"]))]
    prim_specs = []
    for kind, arr in groups:
        ai = add_acc(arr.astype(np.uint32).reshape(-1, 1), UINT, "SCALAR",
                     ELEMENT_ARRAY)
        accs[ai]["count"] = int(arr.size)
        prim_specs.append((kind, ai))

    # --- morph targets (צורות פנים)
    targets, target_names = [], []
    if morphs:
        names = list(morphs["names"])
        deltas = np.asarray(morphs["deltas"], dtype=np.float32)
        if deltas.shape[0] != len(names):
            raise ValueError("מספר הדלתות אינו כמספר השמות")
        if deltas.shape[1] != attrs["position"].shape[0]:
            raise ValueError("דלתא באורך שונה ממספר הקודקודים")
        for i, nm in enumerate(names):
            # min/max חובה על POSITION של target לפי התקן, וגם נדרש
            # כדי שהתיבה החוסמת של הגאומטריה תכלול את התזוזה.
            a = add_acc(np.ascontiguousarray(deltas[i]), FLOAT, "VEC3",
                        ARRAY_BUFFER, minmax=True)
            targets.append({"POSITION": a})
            target_names.append(nm)

    # --- צמתי העצמות
    nodes = []
    node_of = {}
    for b in skel.bones:
        t = skel.local_rest(b.index)
        nodes.append({"name": b.name,
                      "translation": [float(t[0]), float(t[1]), float(t[2])],
                      "rotation": [0.0, 0.0, 0.0, 1.0]})
        node_of[b.name] = len(nodes) - 1
    for b in skel.bones:
        kids = [node_of[c] for c in b.children]
        if kids:
            nodes[node_of[b.name]]["children"] = kids

    ibm = np.zeros((len(skel.bones), 16), dtype=np.float32)
    for i in range(len(skel.bones)):
        # glTF הוא column-major; numpy הוא row-major, לכן transpose.
        ibm[i] = skel.inverse_bind[i].T.reshape(-1).astype(np.float32)
    a_ibm = add_acc(ibm, FLOAT, "MAT4", None)

    mesh_node = {"name": name, "mesh": 0, "skin": 0}
    nodes.append(mesh_node)
    i_mesh_node = len(nodes) - 1

    if material is not None:
        mats = [material]
        mat_of = {k: 0 for k, _ in prim_specs}
    else:
        kinds = []
        for k, _ in prim_specs:
            if k not in kinds:
                kinds.append(k)
        mats = [material_def(k) for k in kinds]
        mat_of = {k: i for i, k in enumerate(kinds)}
    prims = [(ai, mat_of[k]) for k, ai in prim_specs]

    js = {
        "asset": {"version": "2.0", "generator": "anim_studio.rig 1.0"},
        "scene": 0,
        "scenes": [{"nodes": [node_of["root"], i_mesh_node]}],
        "nodes": nodes,
        "meshes": [_mesh_def(name, attributes, prims, targets, target_names)],
        "materials": mats,
        "skins": [{"name": "rig", "inverseBindMatrices": a_ibm,
                   "skeleton": node_of["root"],
                   "joints": [node_of[b.name] for b in skel.bones]}],
        "accessors": accs,
        "bufferViews": views,
        "buffers": [{"byteLength": 0}],
    }
    if any("extensions" in m for m in mats):
        # רק Used ולא Required: צופה שאינו מכיר את הסיומת מקבל חומר
        # מט תקין ולא מסרב לטעון את הקובץ.
        js["extensionsUsed"] = ["KHR_materials_specular"]

    bin_chunk = blob.bytes()
    js["buffers"][0]["byteLength"] = len(bin_chunk)
    js_bytes = json.dumps(js, separators=(",", ":")).encode("utf-8")
    js_bytes += b" " * ((-len(js_bytes)) % 4)

    total = 12 + 8 + len(js_bytes) + 8 + len(bin_chunk)
    with open(path, "wb") as f:
        f.write(struct.pack("<III", 0x46546C67, 2, total))
        f.write(struct.pack("<II", len(js_bytes), 0x4E4F534A))
        f.write(js_bytes)
        f.write(struct.pack("<II", len(bin_chunk), 0x004E4942))
        f.write(bin_chunk)
    return {"path": str(path), "bytes": total,
            "vertices": int(attrs["position"].shape[0]),
            "triangles": int(attrs["index"].size // 3),
            "joints": len(skel.bones),
            "morph_targets": len(target_names),
            "morph_names": list(target_names),
            "materials": [m["name"] for m in mats],
            "primitives": {k: int(accs[ai]["count"] // 3)
                           for k, ai in prim_specs}}


def _mesh_def(name, attributes, prims, targets, target_names):
    """prims = [(index_accessor, material_index)].

    כל ה-primitives חולקים את אותו מילון attributes ואת אותם
    targets - אותם accessors בדיוק, ולכן אין שכפול של אף קודקוד
    ואף דלתא. targets **חייב** להופיע בכל primitive: ב-glTF הצורות
    הן תכונה של ה-primitive ולא של ה-mesh, ו-primitive בלי targets
    פשוט לא יזוז כשהפנים משחקות - כלומר השיער היה קופא בזמן שהפנים
    נעות, פגם שקט שאין עליו שום שגיאה.
    """
    plist = []
    for a_idx, mat in prims:
        prim = {"attributes": attributes, "indices": a_idx,
                "material": mat, "mode": 4}
        if targets:
            prim["targets"] = targets
        plist.append(prim)
    mesh = {"name": name, "primitives": plist}
    if targets:
        # weights ברמת ה-mesh הוא מצב ההתחלה. אפסים: הדמות נטענת
        # עם פנים ניטרליות, והמשחק מוחל בזמן ריצה.
        mesh["weights"] = [0.0] * len(targets)
        mesh["extras"] = {"targetNames": list(target_names)}
    return mesh
