# -*- coding: utf-8 -*-
"""TASK 25 (07/10) - שמונה קולות נבדלים, ואפס כפילות.

================================================================
הבעיה שנמדדה, ולמה היא לא הייתה נראית
================================================================

`cast_disney.VOICES` ממפה את שמונה הדמויות לשני קולות בלבד -
``avri`` (גברי) ו-``hila`` (נשי) - וזה כל מה שיש ל-``he-IL``
ב-edge_tts. נמדד 07/10 מול רשימת הקולות החיה: שני קולות
עבריים בעולם, ולא שמונה. כלומר ההרכב שמע **ארבעה זוגות של
תאומים זהים**: אריאל נשמע בדיוק כגדעון הסבא, ונעם הילד נשמע
בדיוק כליבי. הפגם הזה אינו נראה באף תמונת בדיקה והוא נשמע
מיד, וזו בדיוק הסיבה שהוא החזיק.

================================================================
הפתרון, ולמה דווקא resample ולא "קול אחר"
================================================================

אין קול עברי שלישי להביא. מה שכן אפשר הוא לשנות את **הגוף**
של הקול, ושלושת הפרמטרים שההוראה מונה הם בדיוק שלושת הצירים
העצמאיים שיש:

* ``pitch`` - גובה הצליל (F0). edge_tts מקבל אותו כהיסט ב-Hz.
* ``rate`` - קצב הדיבור. edge_tts מקבל אותו באחוזים.
* ``formant`` - **צורת חלל הפה**, וזה מה שמבדיל ילד מגבר שמדבר
  בקול גבוה. edge_tts אינו מקבל אותו, ולכן הוא נעשה כאן:
  דגימה מחדש (resample) של גל הקול בפקטור ``α`` מכפילה את
  **כל** התדרים ב-α - גם F0 וגם הפורמנטים.

ומכאן ההכרעה שכל המודול בנוי עליה: **הדגימה מחדש משנה גם את
ה-pitch, ולכן ה-pitch מוזמן מראש בערך המקזז.**

    F0_סופי = (F0_בסיס + היסט) · α        ⇒
    היסט = F0_בסיס · (יחס_F0 / α − 1)

כך α שולט בגוף הקול ו-``f0_mul`` שולט בגובהו, **בנפרד**. בלי
הקיזוז, כל העלאת פורמנט הייתה גוררת את הגובה איתה, ושני
הצירים היו מתלכדים לציר אחד - כלומר לא שמונה קולות אלא שמונה
נקודות על אותו קו.

אותו דבר בקצב: דגימה מחדש ב-α מאיצה את הדיבור ב-α, ולכן

    קצב_מוזמן = (1 + קצב_יעד) / α − 1

================================================================
מה **לא** נעשה, בכוונה
================================================================

* **אין phase vocoder ואין WORLD/pyworld.** הם היו נותנים
  שליטה נפרדת בלי קיזוז, במחיר תלות חדשה והרבה קוד עיבוד אות
  שאין לו כאן בדיקה. הקיזוז האנליטי נותן את אותה הפרדה בדיוק,
  והוא שלוש שורות.
* **α מוגבל ל-[0.86, 1.20] ולא פתוח.** מעל זה הדגימה מחדש
  מקפלת תדרים (aliasing) בדיבור של 16kHz, ומתחת זה הקול נשמע
  כהקלטה איטית. שני הקצוות נשמעו, לא הוערכו.
* **אין "ניחוש" ייחודיות.** `audit` מסנתז את שמונת הקולות
  בפועל, **מודד** מהגל את F0 ואת שני הפורמנטים הראשונים,
  ודורש שכל זוג מתוך 28 הזוגות ירחק זה מזה. הצהרה שהפרמטרים
  שונים אינה הוכחה שהקול שונה - שני פרמטרים יכולים לקזז זה
  את זה בדיוק (α גבוה עם pitch נמוך), וזה נתפס כאן במדידה.
"""
from __future__ import annotations

import json
import math
import sys
from dataclasses import dataclass
from pathlib import Path

import numpy as np

RIG_DIR = Path(__file__).resolve().parent
if str(RIG_DIR.parent) not in sys.path:
    sys.path.insert(0, str(RIG_DIR.parent))

RATE = 16000

#: גבולות α. ראה "מה לא נעשה": שני הקצוות נשמעו.
A_LO, A_HI = 0.86, 1.20

#: F0 הבסיסי של שני הקולות העבריים, בהרץ. **נמדד** מקובצי
#: ההקראה שכבר קיימים ב-`production/audio` (ראה `measure_base`),
#: ולא נלקח מתיעוד: ל-edge_tts אין מפרט F0 בכלל. נמדד 07/10 על
#: 14 הקראות לכל קול: avri 105.7, hila 210.5.
BASE_F0 = {"avri": 105.7, "hila": 210.5}


# ========================================================= הפרופיל

@dataclass(frozen=True)
class Profile:
    """פרופיל קול של דמות אחת.

    `f0_hz` - גובה הצליל **המוחלט** שהקול הזה אמור להישמע בו.
    `rate` - יחס קצב הדיבור הסופי (1.0 = כמו הבסיס).
    `formant` - α, פקטור הדגימה מחדש. **זה הגוף של הקול.**

    **`f0_hz` מוחלט ולא יחסי, וזה היה באג מלא בניסיון הראשון.**
    כשהגובה הוגדר כיחס לקול הבסיס, שתי דמויות שקיבלו יחסים
    שונים אבל בסיסים שונים נפלו לאותו הרץ בפועל - אריאל (0.97
    של avri) ותמיר (1.05 של avri) יצאו 103 ו-111 הרץ, כלומר
    חצי טון זה מזה, והשער המודד פסל אותם. גובה נשמע במוחלט,
    לא ביחס לשום דבר.
    """
    key: str
    base: str
    f0_hz: float
    rate: float
    formant: float
    label: str

    # --- מה שנשלח ל-edge_tts, אחרי הקיזוז

    @property
    def tts_pitch(self) -> str:
        """היסט ה-pitch שיוזמן מהמנוע, כך שאחרי α יצא `f0_hz`."""
        return f"{self.f0_hz / self.formant - BASE_F0[self.base]:+.0f}Hz"

    @property
    def tts_rate(self) -> str:
        """הקצב שיוזמן, כך שאחרי האצת α יצא `rate`."""
        return f"{(self.rate / self.formant - 1.0) * 100.0:+.0f}%"

    def target_f0(self) -> float:
        return float(self.f0_hz)

    def semitone(self) -> float:
        """הגובה בחצאי טונים מעל 55 הרץ - יחידת המרחק הנשמעת."""
        return 12.0 * math.log2(self.f0_hz / 55.0)


#: שמונת הפרופילים, פרושים על **סולם אחד של גבהים** עם יותר
#: משלושה חצאי טונים בין כל שתי דמויות שכנות: 84 · 102 · 122 ·
#: 146 · 176 · 212 · 254 · 304 הרץ. שלושה חצאי טונים הם המרווח
#: שמעליו שני קולות נשמעים כשני אנשים ולא כאותו אדם ביום אחר
#: (ראה `MIN_SEMITONES`), ולכן הסולם הזה הוא עצמו ההוכחה.
#:
#: הכיוון של כל שורה נגזר מהתפקיד ומהגובה ב-`cast_disney.ROLE`:
#: סבא = גובה נמוך, גוף גדול (פורמנט קטן) וקצב איטי; ילד = הפוך
#: בשלושת הצירים. הקצב הוא ציר שלישי עצמאי, ושמונה ערכים שונים.
PROFILES: tuple[Profile, ...] = (
    Profile("v_gidon", "avri", f0_hz=84.0, rate=0.84, formant=0.88,
            label="גדעון · הסבא החביב"),
    Profile("v_ariel", "avri", f0_hz=102.0, rate=1.05, formant=0.97,
            label="אריאל · הנער האתלטי"),
    Profile("v_tamir", "avri", f0_hz=122.0, rate=0.93, formant=1.02,
            label="תמיר · החבר הגבוה"),
    Profile("v_omer", "avri", f0_hz=146.0, rate=1.09, formant=1.08,
            label="עומר · הנער בסווטשירט"),
    Profile("v_libi", "hila", f0_hz=176.0, rate=1.00, formant=0.93,
            label="ליבי · החברה עם השיער הארוך"),
    Profile("v_shir", "hila", f0_hz=212.0, rate=1.21, formant=1.05,
            label="שיר · הנערה האנרגטית"),
    Profile("v_dafna", "hila", f0_hz=254.0, rate=1.27, formant=1.13,
            label="דפנה · הילדה עם הקוקיות"),
    Profile("v_noam", "hila", f0_hz=304.0, rate=1.16, formant=1.19,
            label="נעם · הילד הסקרן"),
)

BY_KEY = {p.key: p for p in PROFILES}

#: שיוך דמות -> פרופיל. **זה מה שמחליף את `cast_disney.VOICES`**
#: עבור תסריטים שמצהירים עליו, ו-`cast_disney` עצמו לא נגע -
#: ל-60 השניות יש כבר קבצים ממוטמנים על הקולות הישנים, ושינוי
#: שם הקול שם היה מאלץ סינתזה מחדש של כל השורות.
CAST_VOICE = {
    "dn_ariel": "v_ariel", "dn_shir": "v_shir",
    "dn_noam": "v_noam", "dn_gidon": "v_gidon",
    "dn_tamir": "v_tamir", "dn_libi": "v_libi",
    "dn_omer": "v_omer", "dn_dafna": "v_dafna",
}


def profile_of(name: str) -> Profile | None:
    """פרופיל לפי שם דמות או לפי מפתח פרופיל."""
    k = CAST_VOICE.get(name, name)
    return BY_KEY.get(k)


# ================================================ עיבוד גל הקול

def _lowpass(y: np.ndarray, keep: float) -> np.ndarray:
    """מסנן נמוכים פשוט (חלון הנינג), לפני העלאת תדר.

    נחוץ **רק** כש-α>1: דגימה מחדש שמעלה תדרים מקפלת את מה
    שמעל נייקוויסט חזרה אל התחום השמיע, וזה נשמע כצליל מתכתי
    שמופיע דווקא בעיצורים החדים. `keep` = חלק הרוחב שנשמר.
    """
    if keep >= 0.999:
        return y
    # אורך הגרעין נגזר מרוחב המעבר הדרוש; 31 מספיק ל-16kHz.
    n = 31
    fc = max(0.05, min(0.49, 0.5 * keep))
    k = np.arange(n) - (n - 1) / 2.0
    h = np.sinc(2 * fc * k) * np.hanning(n)
    h /= h.sum()
    return np.convolve(y, h, mode="same")


def respeed(y: np.ndarray, alpha: float) -> np.ndarray:
    """דגימה מחדש בפקטור `alpha`: כל התדרים כפול alpha.

    `alpha>1` -> קול "קטן" ומהיר; `alpha<1` -> קול "גדול" ואיטי.
    האורך מתקצר ב-1/alpha, וזה מה ש-`tts_rate` מקזז מראש.
    """
    a = float(alpha)
    if abs(a - 1.0) < 1e-6 or len(y) < 4:
        return y.astype(np.float32)
    src = y.astype(np.float32)
    if a > 1.0:
        src = _lowpass(src, 1.0 / a)
    n_out = max(2, int(round(len(src) / a)))
    idx = np.arange(n_out, dtype=np.float64) * a
    idx = np.clip(idx, 0.0, len(src) - 1.0)
    return np.interp(idx, np.arange(len(src), dtype=np.float64),
                     src).astype(np.float32)


def apply_profile(y: np.ndarray, prof: Profile) -> np.ndarray:
    """מחיל את חלק הפורמנט של הפרופיל על גל שהמנוע כבר הפיק."""
    a = max(A_LO, min(A_HI, float(prof.formant)))
    return respeed(y, a)


# ============================================== מדידה מתוך הגל

def _voiced_frames(y: np.ndarray, rate: int = RATE,
                   win: float = 0.040, hop: float = 0.020):
    """פריימים שיש בהם קול (לא שקט), עם האנרגיה שלהם."""
    n = int(round(win * rate))
    h = int(round(hop * rate))
    if len(y) < n:
        return []
    out = []
    for i in range(0, len(y) - n, h):
        f = y[i:i + n]
        e = float(np.sqrt(np.mean(f * f)))
        out.append((f, e))
    if not out:
        return []
    top = max(e for _f, e in out)
    # 22% מהשיא: מתחת לזה זה נשימה ורעש רצפה, ו-F0 שנמדד שם
    # הוא מספר אקראי שמזיז את החציון.
    return [f for f, e in out if e >= 0.22 * top]


def f0_of(y: np.ndarray, rate: int = RATE) -> float:
    """F0 חציוני, באוטוקורלציה. 0.0 אם אין קול.

    חציון ולא ממוצע: קפיצת אוקטבה בודדת (שגיאת זיהוי מקובלת
    בכל מאתר גובה) מזיזה ממוצע ב-50% ואינה מזיזה חציון בכלל.
    """
    lo, hi = int(rate / 420.0), int(rate / 60.0)
    vals = []
    for f in _voiced_frames(y, rate):
        g = f - f.mean()
        ac = np.correlate(g, g, mode="full")[len(g) - 1:]
        if ac[0] <= 1e-12 or hi >= len(ac):
            continue
        seg = ac[lo:hi]
        j = int(np.argmax(seg)) + lo
        if ac[j] / ac[0] < 0.30:          # מתאם חלש = פריים לא תנודתי
            continue
        vals.append(rate / float(j))
    return round(float(np.median(vals)), 1) if vals else 0.0


def formants_of(y: np.ndarray, rate: int = RATE) -> tuple[float, float]:
    """(F1, F2) חציוניים, דרך ה-LPC של `rig.voice`."""
    from rig import voice as V                          # noqa: PLC0415
    f1s, f2s = [], []
    for f in _voiced_frames(y, rate, win=0.025, hop=0.015):
        a, b = V._formants(f * np.hanning(len(f)), rate)
        if 200.0 <= a <= 1200.0 and 700.0 <= b <= 3600.0:
            f1s.append(a)
            f2s.append(b)
    if not f1s:
        return 0.0, 0.0
    return (round(float(np.median(f1s)), 1),
            round(float(np.median(f2s)), 1))


def fingerprint(y: np.ndarray, rate: int = RATE) -> dict:
    """טביעת הקול: F0, F1, F2 וקצב ההברות - ארבעה מספרים מהגל."""
    f1, f2 = formants_of(y, rate)
    return {"f0": f0_of(y, rate), "f1": f1, "f2": f2,
            "secs": round(len(y) / rate, 3)}


#: המרחק המינימלי בין שני קולות, ביחידות "חצי טון של F0" ו-
#: "אחוז של פורמנט". שני קולות שאחד מהם נבדל בשלושה חצאי טונים
#: **או** ב-9% פורמנט נשמעים כשני אנשים; מתחת לשניהם - כאותו
#: אדם בשני מצבי רוח.
MIN_SEMITONES = 3.0
MIN_FORMANT_PCT = 9.0


def distance(a: dict, b: dict) -> dict:
    """מרחק בין שתי טביעות: חצאי טונים ב-F0, אחוזים בפורמנטים."""
    def semi(x, y):
        if x <= 0 or y <= 0:
            return 0.0
        return abs(12.0 * math.log2(x / y))

    def pct(x, y):
        if x <= 0 or y <= 0:
            return 0.0
        return abs(x - y) / (0.5 * (x + y)) * 100.0

    fp = max(pct(a["f1"], b["f1"]), pct(a["f2"], b["f2"]))
    st = semi(a["f0"], b["f0"])
    return {"semitones": round(st, 2), "formant_pct": round(fp, 1),
            "ok": bool(st >= MIN_SEMITONES or fp >= MIN_FORMANT_PCT)}


# ================================================== סינתזה בפועל

#: משפט המבחן. הוא מכיל את חמש התנועות העבריות ושלושה עיצורים
#: חוככים, כך שמדידת הפורמנטים נשענת על אותו תוכן פונטי בכל
#: שמונת הקולות - אחרת מה שנמדד הוא ההבדל בין המשפטים.
TEST_LINE = "שלום, אני כאן בפארק ורואה את המזרקה הגדולה."


def synth(text: str, prof: Profile | str, force: bool = False) -> dict:
    """מסנתז שורה בקול של פרופיל, ומחזיר {path, secs, bounds}.

    הקובץ נשמר תחת **מפתח הפרופיל** ולא תחת הקול הבסיסי, ולכן
    `rig.voice.load(text, "v_noam")` מוצא אותו בלי שום שינוי
    בחוזה שלו.
    """
    import hashlib                                     # noqa: PLC0415
    import subprocess                                  # noqa: PLC0415
    import wave                                        # noqa: PLC0415
    from rig import voice as V                          # noqa: PLC0415

    p = prof if isinstance(prof, Profile) else BY_KEY[str(prof)]
    key = hashlib.md5((text + p.key).encode("utf-8")).hexdigest()[:10]
    stem = V.AUDIO_DIR / f"{p.key}_{key}"
    wav, meta = stem.with_suffix(".wav"), stem.with_suffix(".json")
    if not force and wav.exists() and meta.exists():
        m = json.loads(meta.read_text(encoding="utf-8"))
        return {"path": str(wav), "secs": m["seconds"],
                "bounds": m.get("bounds", []), "cached": True}

    stem.parent.mkdir(parents=True, exist_ok=True)
    raw = stem.with_name(stem.name + "_raw")
    if not V.TOOL_PYTHON.exists():
        raise RuntimeError(f"אין פייתון עם edge_tts: {V.TOOL_PYTHON}")
    # **`--rate=-9%` ולא `--rate -9%`.** היסט שלילי מתחיל במינוס,
    # ו-argparse בתהליך הבן קורא אותו כדגל לא מוכר ויוצא בקוד 2.
    # נתפס בהרצה הראשונה: שמונה סינתזות נכשלו על התחביר, לא על
    # הקול. הצורה עם `=` היא היחידה שחסינה לערך שלילי.
    subprocess.run(
        [str(V.TOOL_PYTHON), "-X", "utf8", str(V.TOOL),
         "--text", text, "--voice", p.base, "--stem", str(raw),
         f"--rate={p.tts_rate}", f"--pitch={p.tts_pitch}"],
        check=True, capture_output=True, timeout=300)

    y, rate = V.read_wav(raw.with_suffix(".wav"))
    out = apply_profile(y, p)
    pcm = np.clip(out, -1.0, 1.0)
    with wave.open(str(wav), "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(rate)
        wf.writeframes((pcm * 32767.0).astype("<i2").tobytes())

    rm = json.loads(raw.with_suffix(".json").read_text(encoding="utf-8"))
    a = max(A_LO, min(A_HI, p.formant))
    secs = round(len(out) / rate, 4)
    # **הגבולות מתכווצים ב-1/α יחד עם הגל.** בלי זה סינכרון הפה
    # מתבסס על חלונות של הקובץ שלפני העיבוד, כלומר הפה נע בזמן
    # הלא נכון - והפער גדל לקראת סוף המשפט.
    bounds = [{"start": round(b["start"] / a, 4),
               "end": round(b["end"] / a, 4),
               "text": b.get("text", ""), "kind": b.get("kind", "word")}
              for b in rm.get("bounds", [])]
    meta.write_text(json.dumps(
        {"text": text, "voice": p.key, "base": p.base,
         "seconds": secs, "rate": rate,
         "pitch": p.tts_pitch, "speed": p.tts_rate,
         "formant": a, "bounds": bounds},
        ensure_ascii=False, indent=1), encoding="utf-8")
    for suf in (".wav", ".json", ".mp3"):
        raw.with_suffix(suf).unlink(missing_ok=True)
    return {"path": str(wav), "secs": secs, "bounds": bounds,
            "cached": False}


def synth_all(lines, force: bool = False) -> dict:
    """מסנתז רשימת (מפתח_פרופיל, טקסט) ומחזיר אורך לכל אחת."""
    out = {}
    for pk, text in lines:
        r = synth(text, pk, force=force)
        out[(pk, text)] = r
    return out


# ================================================= מדידת הבסיס

def measure_base() -> dict:
    """F0 של שני הקולות הבסיסיים, מהקבצים שכבר על הדיסק.

    זו המדידה שממנה נגזר `BASE_F0`. היא קוראת כל קובץ `avri_*`
    ו-`hila_*` שקיים, ולכן היא מתייצבת כשיש יותר הקראות -
    ואינה דורשת רשת בכלל.
    """
    from rig import voice as V                          # noqa: PLC0415
    out = {}
    for base in ("avri", "hila"):
        vals = []
        for p in sorted(V.AUDIO_DIR.glob(f"{base}_*.wav"))[:14]:
            y, rate = V.read_wav(p)
            f = f0_of(y, rate)
            if f > 0:
                vals.append(f)
        out[base] = {"n": len(vals),
                     "f0": round(float(np.median(vals)), 1) if vals else 0.0}
    return out


# ======================================================== השערים

def audit_spec() -> dict:
    """שערים שאינם דורשים רשת: על הטבלה עצמה."""
    out: dict = {}

    def chk(name, ok, detail):
        out[name] = {"pass": bool(ok), "detail": str(detail)}

    chk("שמונה פרופילים", len(PROFILES) == 8, f"{len(PROFILES)}")
    chk("ולכל דמות בהרכב יש פרופיל",
        len(CAST_VOICE) == 8 and all(v in BY_KEY
                                     for v in CAST_VOICE.values()),
        f"{len(CAST_VOICE)} שיוכים")

    trips = [(p.f0_hz, p.rate, p.formant) for p in PROFILES]
    chk("אין שתי דמויות עם אותה שלישיית פרמטרים",
        len(set(trips)) == 8, f"{len(set(trips))} שלישיות שונות")
    chk("וגם שמונה קצבי דיבור שונים",
        len({p.rate for p in PROFILES}) == 8,
        " · ".join(f"{p.rate:.2f}" for p in PROFILES))

    # **לא די בשלישייה שונה.** שתי דמויות שנבדלות רק בקצב
    # נשמעות כאותו אדם מדבר מהר יותר, ולכן נדרש הבדל בגובה או
    # בגוף. המדד הוא **אוקלידי ולא מקסימום**: שתי נקודות שרחוקות
    # קצת בשני הצירים נשמעות שונות, ומקסימום היה פוסל אותן.
    worst = (99.0, "", "")
    for i, a in enumerate(PROFILES):
        for b in PROFILES[i + 1:]:
            d = math.hypot(abs(a.semitone() - b.semitone()) / MIN_SEMITONES,
                           abs(a.formant - b.formant) / 0.05)
            if d < worst[0]:
                worst = (d, a.key, b.key)
    chk("וכל זוג נבדל בגובה או בגוף הקול, לא רק בקצב",
        worst[0] >= 1.0,
        f"הזוג הקרוב: {worst[1]}/{worst[2]} · מדד {worst[0]:.2f}")
    gaps = sorted(p.semitone() for p in PROFILES)
    chk("והמרווח בין שתי דמויות שכנות בסולם הוא מעל שלושה חצאי טון",
        min(b - a for a, b in zip(gaps, gaps[1:])) >= MIN_SEMITONES,
        f"המרווח הקטן {min(b - a for a, b in zip(gaps, gaps[1:])):.2f} "
        f"חצאי טון · טווח "
        f"{min(p.f0_hz for p in PROFILES):.0f}–"
        f"{max(p.f0_hz for p in PROFILES):.0f} הרץ")

    chk("כל הפורמנטים בתוך הטווח שנשמע תקין",
        all(A_LO <= p.formant <= A_HI for p in PROFILES),
        f"{min(p.formant for p in PROFILES):.2f}–"
        f"{max(p.formant for p in PROFILES):.2f}")
    chk("וכל הקצבים בטווח שהמנוע מקבל",
        all(abs((p.rate / p.formant - 1.0) * 100.0) <= 60.0
            for p in PROFILES),
        "היסט הקצב המוזמן אינו חורג מ-60%")

    # שני המינים מיוצגים, ושני הבסיסים בשימוש - אחרת ארבעה
    # קולות הם וריאציות של אותו מנוע בלבד.
    bases = {p.base for p in PROFILES}
    chk("שני הקולות העבריים בשימוש", bases == {"avri", "hila"},
        " · ".join(sorted(bases)))
    return out


def audit(force: bool = False) -> dict:
    """השער האמיתי: מסנתז את שמונת הקולות ומודד את הגל.

    זה **דורש רשת** בפעם הראשונה, וממוטמן אחריה. שער שבודק רק
    את הטבלה אינו יכול לתפוס שני פרמטרים שמקזזים זה את זה.
    """
    from rig import voice as V                          # noqa: PLC0415
    out = dict(audit_spec())
    prints: dict[str, dict] = {}
    for p in PROFILES:
        r = synth(TEST_LINE, p, force=force)
        y, rate = V.read_wav(r["path"])
        prints[p.key] = fingerprint(y, rate) | {"label": p.label}

    def chk(name, ok, detail):
        out[name] = {"pass": bool(ok), "detail": str(detail)}

    chk("כל שמונת הקולות הופקו ונמדדו",
        all(v["f0"] > 0 for v in prints.values()),
        " · ".join(f"{k}:{v['f0']:.0f}Hz" for k, v in prints.items()))

    keys = list(prints)
    bad, worst = [], (999.0, "", "", {})
    for i, a in enumerate(keys):
        for b in keys[i + 1:]:
            d = distance(prints[a], prints[b])
            score = max(d["semitones"] / MIN_SEMITONES,
                        d["formant_pct"] / MIN_FORMANT_PCT)
            if score < worst[0]:
                worst = (score, a, b, d)
            if not d["ok"]:
                bad.append(f"{a}~{b}")
    chk("ואין שני קולות שנשמעים כאותו אדם",
        not bad,
        f"28 זוגות · הקרוב {worst[1]}/{worst[2]}: "
        f"{worst[3].get('semitones', 0)} חצאי טון, "
        f"{worst[3].get('formant_pct', 0)}% פורמנט"
        + (f" · נכשלו: {', '.join(bad)}" if bad else ""))

    f0s = sorted(v["f0"] for v in prints.values())
    chk("וטווח הגבהים מכסה מילד עד מבוגר",
        f0s[-1] / max(1.0, f0s[0]) >= 1.8,
        f"{f0s[0]:.0f}–{f0s[-1]:.0f} Hz · יחס {f0s[-1]/max(1.0,f0s[0]):.2f}")
    out["_prints"] = prints                            # לדיווח, לא שער
    return out


def passed(force: bool = False) -> bool:
    return all(v["pass"] for k, v in audit(force).items()
               if not k.startswith("_"))


def main(argv=None) -> int:
    import argparse                                    # noqa: PLC0415
    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(description="שמונה קולות נבדלים (TASK 25)")
    ap.add_argument("--spec", action="store_true",
                    help="רק שערי הטבלה, בלי רשת")
    ap.add_argument("--base", action="store_true",
                    help="למדוד את F0 של שני קולות הבסיס")
    ap.add_argument("--force", action="store_true")
    a = ap.parse_args(argv)

    if a.base:
        print(json.dumps(measure_base(), ensure_ascii=False, indent=1))
        return 0

    rep = audit_spec() if a.spec else audit(force=a.force)
    prints = rep.pop("_prints", None)
    for name, r in rep.items():
        print(f"  {'✓' if r['pass'] else '✗'} {name} — {r['detail']}")
    if prints:
        print("\nטביעות הקול:")
        for k, v in prints.items():
            print(f"  {k:9s} {v['label']:22s} "
                  f"F0 {v['f0']:6.1f}  F1 {v['f1']:6.1f}  "
                  f"F2 {v['f2']:7.1f}  {v['secs']:.2f}ש")
    bad = [n for n, r in rep.items() if not r["pass"]]
    print(f"\n{len(rep) - len(bad)}/{len(rep)} שערים עברו")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
