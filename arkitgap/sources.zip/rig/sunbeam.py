# -*- coding: utf-8 -*-
"""
בימוי והפקה של "קרן שמש בהפתעה" - 50 שניות בדיוק, זיגי וגרומפ בפארק.

הקובץ הזה הוא **הגשר** בין התסריט (`production/script/sunbeam50.py`,
שהוא נתונים בלבד) לבין מנוע ההפקה (`rig.showreel.produce`). הוא מתרגם
כל שוט בתסריט לשוט מרונדר: מצלמה, שני שחקנים, חלון דיבור, שכבת
סביבה, ותזמון.

**ההחלטה המרכזית - קומפוזיטינג בשכבות.** הסביבה אינה מרונדרת
בתלת-ממד. היא נצרבת פעם אחת ל-PNG ב-`rig.park`, ובדפדפן היא
`background-image` מאחורי קנבס שקוף. המנוע התלת-ממדי מטפל **רק**
בדמויות ובצל שלהן. התוצאה: רינדור של 1500 פריימים בזמן של סצנת
אולפן רגילה, במקום שעות של מעקב קרניים אחרי עלים.

ארבעת מעברי הרינדור, לפי ההוראה שהתקבלה:
  1. `park.bake`  - Background Skybox / Matte Painting (פעם אחת).
  2. `produce`    - Character Render Pass, תאורת דמויות בלבד.
  3. `aimSun`     - Baked Ground Shadows: מישור צל מוקרן, לא GI.
  4. `concat`+QA  - Final Composite ונעילת 50.000 שניות.

**התזמון ננעל בפריימים ולא בשניות.** 50 שניות ב-30 פריימים לשנייה
הן 1500 פריימים בדיוק; אם שוט אחד יוצא 299 פריימים במקום 300, הסרט
ייצא 49.967 שניות והקול יזוז. לכן `validate_timeline` מחשב את
הפריימים ונכשל על הפרש של פריים אחד.
"""
from __future__ import annotations

import json
import math
import sys
from dataclasses import dataclass
from pathlib import Path

HERE = Path(__file__).resolve().parent
STUDIO = HERE.parent
if str(STUDIO) not in sys.path:
    sys.path.insert(0, str(STUDIO))

from production.script import sunbeam50 as SB        # noqa: E402
from rig import ensemble as ENS                      # noqa: E402
from rig import park, showreel as SR                 # noqa: E402

#: ה-Take של שוט הלהקה. נבנה **פעם אחת** ברמת המודול כי הוא מחשב
#: 300 פריימים של פיזיקה, והוא נדרש גם למצלמה, גם לתנועת המקום,
#: גם למיקרו-ההבעות וגם למטען הבמה. ארבע בנייות של אותו Take היו
#: ארבע עקומות פיזיקה שונות לאותו שוט - כלומר העלים היו עפים
#: במקום אחד והמצלמה הייתה רועדת לפי אחר.
_TAKE: dict = {}


def take_of(secs: float, ha: float, hb: float) -> ENS.Take:
    key = (round(secs, 4), round(ha, 4), round(hb, 4))
    if key not in _TAKE:
        _TAKE[key] = ENS.Take(secs=secs, fps=FPS, ha=ha, hb=hb)
    return _TAKE[key]

#: A = זיגי, B = גרומפ. הסדר קבוע וחייב להישמר: הבמה מניחה את A
#: בצד שמאל ואת B בצד ימין, והמצלמות כאן מכוונות לפי זה.
CAST = ("zippy", "grump")
VOICES = {"zippy": "hila", "grump": "avri"}

ENV_DIR = Path(r"D:\claude-bot\out\char3d\env\park")
OUT_DIR = Path(r"D:\claude-bot\out\char3d\showreel")

FPS = 30


# ------------------------------------------------------- מצבי הדמויות

def sit_zippy(line: str, shot_len: float):
    """זיגי: רוצה לגרור את גרומפ לשחק, ואינה מסתירה דבר.

    `hides=""` הוא מה שמייצר את ההבעות הקיצוניות: דמות שאינה מסתירה
    כלום מקבלת מהמנוע עוצמה מלאה על הפנים, בלי הדיכוי שמופעל על
    רגש מוסתר.
    """
    from rig import emotion as E
    return E.Situation(
        knows="היום מושלם והכול אפשרי",
        wants="לגרור אותו לשחק איתה עכשיו",
        feels="joy", hides="", looks_at="partner",
        change="הוא מסרב", knows_more=True,
        want_strength=1.0, intensity=1.0,
        shot_len=shot_len, line=line)


def sit_grump(line: str, shot_len: float):
    """גרומפ: רוצה שיעזבו אותו. אדישות עם כעס מתחתיה."""
    from rig import emotion as E
    return E.Situation(
        knows="כל זה ייגמר בזיעה ובעייפות",
        wants="שיעזבו אותו בשקט בצל",
        feels="anger", hides="", looks_at="object",
        change="היא לא מוותרת", knows_more=False,
        want_strength=0.9, intensity=0.85,
        shot_len=shot_len, line=line)


SITS = {"zippy": sit_zippy, "grump": sit_grump}
SEEDS = {"zippy": 0.31, "grump": 0.77}
PHASE = {"zippy": 0.0, "grump": 0.52}


def _rest_actor(who: str, shot_len: float):
    """שחקן לשוט שבו הדמות אינה מדברת: היא עדיין משחקת.

    דמות שותקת שמקבלת `{}` קופאת לגמרי, וזה בדיוק מה שהופך שוט
    לתמונה. כאן היא מקבלת את אותו `Situation` בלי חלון דיבור -
    הרגש, המבט והנשימה ממשיכים לרוץ.
    """
    fn, eye = SR._emotion_actor(
        SITS[who]("", shot_len), seed=SEEDS[who], phase=PHASE[who],
        speech=(), voice="", body=True)
    return fn, eye


def _talking_actor(who: str, line, shot_start: float, shot_len: float):
    """שחקן לשוט שבו הדמות מדברת, עם חלון דיבור **יחסי לשוט**.

    זו המלכודת שהכי קל ליפול בה כאן: בתסריט הזמנים מוחלטים
    (`Line.at` הוא שנייה בסרט), ובמנוע הם יחסיים לשוט. חלון
    שנשלח מוחלט היה יושב מחוץ לשוט, הפה לא היה נפתח כלל - ושום
    בדיקה לא הייתה צועקת, כי "אין דיבור" הוא מצב חוקי.
    """
    t0 = round(line.at - shot_start, 4)
    win = (t0, round(t0 + line.secs, 4))
    fn, eye = SR._emotion_actor(
        SITS[who](line.text, shot_len), seed=SEEDS[who], phase=PHASE[who],
        speech=(win,), voice=VOICES[who], body=True)
    return fn, eye


# ------------------------------------------------------------- מצלמות

def _cam(camera: str, u: float, ha: float, hb: float) -> dict:
    """מצלמה לפי סוג הצילום שהתסריט הזמין.

    **שני גבהים ולא אחד, וזו תקלה שנתפסה בצפייה ברנדור המלא.**
    הניסיון הראשון חישב את כל המצלמות מגובה זיגי בלבד (1.42 מ'),
    וגרומפ גבוה ממנה ב-32 ס"מ: בתקריב עליו המצלמה כוונה לגובה
    החזה שלו ומילאה את הפריים בכתף, ובשוט הבינוני ראשו נחתך מעל
    הפריים. מצלמה שמחושבת מדמות אחת בסצנה של שתיים היא באג שנראה
    רק אחרי הרינדור המלא.

    כל סוג מקבל גם **תנועה** ולא רק מרחק: מצלמה נייחת לחלוטין בשוט
    של עשר שניות נקראת כצילום אבטחה. הסחיפה קטנה (כמה מעלות) כי
    סחיפה גדולה בשוט רחב גוררת את הרקע הצרוב מהר מדי וחושפת שהוא
    שטוח.
    """
    tall = max(ha, hb)
    if camera == "wide":
        # המרחק נגזר מהגבוה, וה-ty מהאמצע: כך שניהם נכנסים בשלמותם.
        return {"yaw": SR.lerp(-9, 7, u), "pitch": 3.2,
                "dist": tall * 3.00, "tx": 0.0, "ty": tall * 0.52,
                "fov": 34}
    if camera == "medium":
        return {"yaw": SR.lerp(26, 38, u), "pitch": 2.0,
                "dist": tall * 2.35, "tx": 0.0, "ty": tall * 0.56,
                "fov": 31}
    # close_up: חיתוך בין שתי הדמויות באמצע השוט. גובה המטרה הוא
    # גובה **הראש של מי שבפריים**, ולכן הוא שונה בין שני החצאים.
    if u < 0.5:
        v = u / 0.5
        return {"yaw": SR.lerp(-14, -4, v), "pitch": 0.5,
                "dist": 0.92, "tx": -0.52, "ty": ha * 0.93, "tz": 0.03,
                "fov": 30}
    v = (u - 0.5) / 0.5
    return {"yaw": SR.lerp(12, 3, v), "pitch": 0.5,
            "dist": 1.00, "tx": 0.52, "ty": hb * 0.94, "tz": 0.03, "fov": 30}


def _pullout_cam(u: float, ha: float, hb: float) -> dict:
    """השוט האחרון: המצלמה נסוגה לאחור ומעלה."""
    tall = max(ha, hb)
    return {"yaw": SR.lerp(4, -11, u), "pitch": SR.lerp(2.5, 13.0, u),
            "dist": tall * SR.lerp(2.5, 4.3, u), "tx": 0.0,
            "ty": tall * SR.lerp(0.54, 0.66, u), "fov": SR.lerp(32, 38, u)}


# ------------------------------------------------- שכבת הסביבה פר שוט

def _env_of(camera: str, flare: bool):
    """(u) -> {"pan","dap","flare"} לשכבות הרקע.

    `pan` נגזר מתנועת המצלמה של אותו שוט, כי זה כל מה שהרקע הצרוב
    יכול לעשות: הוא שטוח, ולכן הוא מגיב לסחיפה אופקית בלבד. pan
    שאינו עוקב אחרי המצלמה הוא בדיוק מה שמסגיר רקע מודבק.

    `dap` (אור מנוקד) חזק יותר בתקריב: שם האור שעובר בין העלים
    נופל על הפנים ומדגיש מרקם, וזה מה שהתסריט ביקש.
    """
    def fn(u: float) -> dict:
        if camera == "wide":
            pan = SR.lerp(-0.55, 0.45, u)
        elif camera == "medium":
            pan = SR.lerp(0.30, 0.70, u)
        elif camera == "arc":
            # **מתחיל ב-0 בדיוק.** מקום הערימה הצרובה חושב מההקרנה
            # של עוגן העלים דרך מצלמת הפתיחה בלי סחיפה, ולכן סחיפה
            # שאינה אפס בפריים הראשון מזיזה את הערימה הצרובה מתחת
            # לעלים התלת-ממדיים - והם היו יוצאים מהאוויר.
            pan = SR.lerp(0.0, 0.62, u)
        else:
            pan = -0.35 if u < 0.5 else 0.40
        # נמדד בעין על תמונת בדיקה 05/10: 0.42 בתקריב נראה כמו רעש
        # על הפנים ולא כמו אור. הערך שעובד נמוך בהרבה ממה שנראה
        # נכון במספרים - אפקט אטמוספרי שרואים אותו הוא אפקט שגוי.
        out = {"pan": round(pan, 4),
               "dap": 0.17 if camera == "close_up" else 0.11}
        if camera == "arc":
            # בשוט הקשת האור המנוקד מוחלש: עומק השדה מטשטש את הרקע,
            # וכתמי אור חדים על רקע מטושטש נקראים כלכלוך על העדשה.
            out["dap"] = 0.07
        if flare:
            # ההבזק נדלק בשליש האחרון ודועך, ולא קופץ: הבזק עדשה
            # שמופיע בפריים אחד נראה כמו פריים פגום.
            x = max(0.0, (u - 0.62) / 0.38)
            out["flare"] = round(math.sin(math.pi * min(1.0, x)) ** 1.5 * 0.85, 4)
        return out
    return fn


# ----------------------------------------------- קפיצה מול משקל כבד

def _lift_of(shot_key: str):
    """(דמות, t) -> הרמה אנכית במטרים.

    זה הניגוד שהתסריט בנוי עליו, והוא **אינו** נגזר ממנוע הרגש:
    זיגי קופצת, גרומפ גורר רגליים. שני ערוצים, שניהם מחזוריים
    ומתלכדים בקצה השוט כדי שהחיתוך לא יקפוץ.

    למה כאן ולא בשלד: הרמת שורש הדמות היא תנועת **מקום**, לא פוזה.
    פתרון IK היה מכופף ברכיים ומשאיר את כפות הרגליים על הרצפה -
    כלומר כפיפה, לא קפיצה.
    """
    def fn(who: str, t: float) -> float:
        if who == "zippy":
            # קפיצות: חצי סינוס חיובי בלבד (באוויר), וריצפה ביניהן.
            hop = max(0.0, math.sin(2 * math.pi * t * 1.35))
            amp = 0.20 if shot_key == "s1_park_wide" else 0.055
            return round(hop ** 1.4 * amp, 5)
        # גרומפ: נדנוד כבד ואיטי, תמיד שלילי (שקיעה במשקל).
        return round(-0.012 * (1.0 - math.cos(2 * math.pi * t * 0.42)), 5)
    return fn


# ------------------------------------------- מיקרו-הבעות על השחקן

def _with_micro(fn, take, who: str):
    """עוטף שחקן ומוסיף לו את המיקרו-הבעות של הלהקה.

    **העטיפה מעבירה את התכונות של השחקן המקורי, וזו לא קוסמטיקה.**
    `showreel.soundtrack_cues` בונה את פס הקול מהתכונות `speech`
    ו-`track` שתלויות על פונקציית השחקן. עטיפה רגילה מאבדת אותן
    בשקט - הרנדור מצליח, הסרטון יוצא, **והוא אילם**. זה כשל שלא
    מתגלה באף בדיקת פריים, ולכן ההעברה כאן מפורשת.

    התוספת היא **חיבור ולא דריסה**: מנוע הרגש כבר כתב לגבות ולנשימה
    של גרומפ, ודריסה הייתה מכבה את המשחק שלו לטובת רטיטה.
    """
    micro_of = (lambda t: take.controls_for(who, t))

    def wrapped(u: float, t: float):
        res = fn(u, t)
        ctl = dict(res[0])
        for k, v in micro_of(t).items():
            if v:
                ctl[k] = max(-1.0, min(1.0, float(ctl.get(k, 0.0)) + v))
        return (ctl,) + tuple(res[1:])

    for attr in ("speech", "track", "voice", "eye", "sit"):
        if hasattr(fn, attr):
            setattr(wrapped, attr, getattr(fn, attr))
    return wrapped


# --------------------------------------------------------------- בימוי

def build_shots(h: float, hb: float | None = None) -> list:
    """ארבעת שוטי התסריט, כשוטים של מנוע ההפקה.

    `h` = גובה זיגי (A), `hb` = גובה גרומפ (B). שניהם נחוצים: ראה
    `_cam`. ברירת המחדל שומרת על הקריאות הקיימות לפונקציה.
    """
    hb = h if hb is None else hb
    shots = []
    for s in SB.SHOTS:
        who_lines = {ln.who: ln for ln in s.lines}
        take = take_of(s.secs, h, hb) if s.camera == "arc" else None
        actors = {}
        for who in CAST:
            ln = who_lines.get(who)
            if ln is not None:
                actors[who] = _talking_actor(who, ln, s.start, s.secs)[0]
            else:
                actors[who] = _rest_actor(who, s.secs)[0]
            if take is not None:
                actors[who] = _with_micro(actors[who], take, who)

        # כתובית = הדיאלוג עצמו, ורק בזמן שהוא נאמר. זה סרט ולא
        # הדגמה טכנית, ולכן אין כאן כתוביות הסבר.
        def cap_of(u: float, _s=s):
            t = _s.start + u * _s.secs
            for ln in _s.lines:
                if ln.at - 0.15 <= t <= ln.at + ln.secs + 0.25:
                    return ln.text
            return ""

        if s.camera == "arc":
            # הזעזוע נכנס **אל המצלמה** ולא רק אל הדמות: רעידת
            # קרקע שרואים רק בדמות נראית כמו דמות שרועדת, ורעידה
            # שרואים בפריים כולו נקראת כקרקע שזזה. זה ההבדל בין
            # "הוא נבהל" לבין "היא נחתה בכל הכוח".
            def cam_fn(u: float, _tk=take, _a=h, _b=hb, _s=s.secs):
                i = _tk._idx(u * _s)
                return _tk.cams[i]
        elif s.key == "s4_pull_out":
            def cam_fn(u: float, _a=h, _b=hb):
                return _pullout_cam(u, _a, _b)
        else:
            def cam_fn(u: float, _c=s.camera, _a=h, _b=hb):
                return _cam(_c, u, _a, _b)

        shots.append(SR.Shot(
            key=s.key, secs=s.secs,
            cap="", sub="",
            proves=" · ".join(s.beats),
            cam=cam_fn,
            a=actors["zippy"], b=actors["grump"],
            light="sun_hard_left",
            sec_strength=1.15 if s.camera != "close_up" else 0.85,
            env_of=_env_of(s.camera, flare=(s.key == "s4_pull_out")),
            caption_of=cap_of,
            ens_of=((lambda t, _tk=take: _tk.payload(t))
                    if take is not None else None),
        ))
        if take is not None:
            # תנועת המקום בשוט הלהקה מגיעה מה-Take: אותה עקומה
            # בדיוק שמחושב ממנה הזעזוע והמעיכה. שני מקורות לגובה
            # היו דמות שקופצת בזמן אחד ומזעזעת את הקרקע בזמן אחר.
            shots[-1].lift_of = (lambda who, t, _tk=take:
                                 _tk.lift_for(who, t))
        else:
            shots[-1].lift_of = _lift_of(s.key)
    return shots


# --------------------------------------------------------------- חוזה

def validate_timeline(shots: list, fps: int = FPS) -> dict:
    """חוזה התזמון, בפריימים. שנייה היא יחידה רציפה; הסרט אינו."""
    out: dict = {}

    def chk(name: str, ok, detail) -> None:
        out[name] = {"pass": bool(ok), "detail": str(detail)}

    frames = [int(round(s.secs * fps)) for s in shots]
    total = sum(frames)
    want = int(round(SB.TOTAL_SECONDS * fps))
    chk(f"סך הפריימים הוא בדיוק {want}", total == want, f"{total} ({frames})")
    chk(f"ולכן האורך הוא {SB.TOTAL_SECONDS:.3f} שניות",
        abs(total / fps - SB.TOTAL_SECONDS) < 1e-9, f"{total / fps:.3f}")
    chk("כל שוט נושא את שכבת הסביבה",
        all(s.env_of is not None for s in shots),
        [s.key for s in shots if s.env_of is None] or "כולם")
    chk("כל שוט מואר בשמש החיצונית ולא בתאורת אולפן",
        all(s.light == "sun_hard_left" for s in shots),
        sorted({s.light for s in shots}))
    chk("סדר השוטים זהה לתסריט",
        [s.key for s in shots] == [s.key for s in SB.SHOTS],
        [s.key for s in shots])

    # --- TASK 13: שוט הלהקה
    ens = [s for s in shots if getattr(s, "ens_of", None) is not None]
    chk("שוט אחד נושא את הלהקה", len(ens) == 1, [s.key for s in ens])
    if ens:
        pl = ens[0].ens_of(ENS.IMPACT_T + 0.4)
        chk("ומטען הלהקה שלו מלא בפועל",
            len(pl.get("leaves", [])) == ENS.LEAF_N * 4
            and "crit" in pl and pl.get("lamp", 0) > 0,
            f"{len(pl.get('leaves', []))} מספרי עלים, אור {pl.get('lamp')}")
        # הקול: העטיפה של המיקרו-הבעות **לא** איבדה את ההקלטה.
        spk = [getattr(f, "track", None) for f in (ens[0].a, ens[0].b)]
        chk("השחקנים בשוט הלהקה שומרים על ההקלטה שלהם",
            all(x is not None for x in spk),
            [None if x is None else round(float(x.seconds), 2) for x in spk])
        cams = [ens[0].cam(i / 60.0) for i in range(61)]
        chk("והמצלמה שלו היא קשת סוחפת",
            max(c["yaw"] for c in cams) - min(c["yaw"] for c in cams) > 55.0,
            round(max(c["yaw"] for c in cams)
                  - min(c["yaw"] for c in cams), 1))
    return out


# ------------------------------------------------------------- הפקה

async def produce(out_mp4: Path, rig_dir: Path = SR.RIG_DIR,
                  fps: int = FPS, width: int = 1920, height: int = 1080,
                  ss: int = 2, on_progress=None,
                  env_dir: Path = ENV_DIR, probe: bool = False) -> dict:
    """מעבר 1 (רקע) + מעבר 2 (דמויות) + מעבר 3 (צל) + קומפוזיט."""
    man = park.bake(env_dir, SB.LOCATION, width=width, height=height)
    if not park.passed(man, env_dir):
        bad = [k for k, v in park.validate(man, env_dir).items()
               if not v["pass"]]
        raise RuntimeError(f"שכבת הסביבה לא עברה את החוזה: {bad}")

    rig_a = json.loads((rig_dir / f"{CAST[0]}.rig.json").read_text("utf-8"))
    rig_b = json.loads((rig_dir / f"{CAST[1]}.rig.json").read_text("utf-8"))
    shots = build_shots(rig_a["height_m"], rig_b["height_m"])
    bad = [k for k, v in validate_timeline(shots, fps).items() if not v["pass"]]
    if bad:
        raise RuntimeError(f"ציר הזמן לא נסגר: {bad}")

    # `title` ברווח בודד ולא ריק: `produce` מפרש מחרוזת ריקה כ"קח
    # את כותרת ברירת המחדל", וכותרת של אולפן בפינת פריים היא בדיוק
    # מה שמוציא סצנה קולנועית ממצב סרט למצב מצגת.
    rep = await SR.produce(
        out_mp4, rig_dir, task=50, title=" ",
        probe=probe, fps=fps, width=width, height=height,
        on_progress=on_progress, ss=ss, shots_override=shots,
        cast=CAST, env_manifest=man, env_dir=env_dir)
    rep["script"] = {"total_seconds": SB.TOTAL_SECONDS,
                     "location": SB.LOCATION["name"],
                     "shots": [s.key for s in SB.SHOTS],
                     "validate": SB.validate()}
    rep["env_validate"] = park.validate(man, env_dir)
    rep["timeline"] = validate_timeline(shots, fps)
    return rep


def main(argv=None) -> int:
    import argparse
    import asyncio
    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(description="קרן שמש בהפתעה - 50 שניות")
    ap.add_argument("--out", default="")
    ap.add_argument("--fps", type=int, default=FPS)
    ap.add_argument("--width", type=int, default=1920)
    ap.add_argument("--height", type=int, default=1080)
    ap.add_argument("--ss", type=int, default=2)
    ap.add_argument("--probe", action="store_true")
    a = ap.parse_args(argv)

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    out = Path(a.out) if a.out else OUT_DIR / "sunbeam50.mp4"

    def prog(i, t):
        print(f"  פריים {i}/{t}", flush=True)

    rep = asyncio.run(produce(out, fps=a.fps, width=a.width, height=a.height,
                              ss=a.ss, on_progress=prog, probe=a.probe))
    out.with_suffix(".json").write_text(
        json.dumps(rep, ensure_ascii=False, indent=1), encoding="utf-8")
    for k, v in rep["timeline"].items():
        print(("✅" if v["pass"] else "❌"), k, "-", v["detail"])
    if rep.get("mp4"):
        print(f"\n{rep['seconds']}ש · {rep['size_mb']}MB · "
              f"רנדור {rep['render_sec']}ש\n{rep['mp4']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
