# -*- coding: utf-8 -*-
"""דיבור כהופעה, ולא כסנכרון שפתיים · TASK 05.

מה הבעיה שזה פותר. עד כאן הפה הונע כך (showreel._talk):

    v = max(0, sin(2*pi*x*2.7))**0.7
    jaw_open = 0.08 + 0.50*v

כלומר הפה **הוא** האנימציה: גל אחד, בתדר אחד, בלי קשר למה שנאמר,
בלי קשר לרגש, ובלי שום רגע של שקט בתוך המשפט. זה בדיוק מה שהעין
קוראת כ"בובה שפותחת וסוגרת". ושתי תקלות נוספות נובעות מכך ישירות:
הפה הוא הדבר היחיד שזז בזמן דיבור (ולכן הוא **המניע הראשי** של
הפנים), ואין בו שום דבר לא-מילולי - אין נשימה, אין בליעה, אין היסוס,
אין חיוך תוך דיבור ואין תגובה בין מילים.

המבנה כאן הוא השרשרת שהמשתמש דרש:

    דיאלוג -> פונמות -> ויזמות -> **הופעה רגשית** -> פה, לסת, שפתיים

ושלושה עקרונות שנאכפים בקוד:

1. **אין ערוץ "פה פתוח".** יש רצף פונמות שלכל אחת אורך משלה לפי
   סוגה (סותם קצר, תנועה ארוך), ומה שנראה בפריים הוא ממוצע משוקלל
   של הפונמות השכנות - כלומר coarticulation אמיתי. לתנועות חלון
   השפעה רחב מזה של עיצורים, ולכן התנועה "דולפת" אחורה אל העיצור
   שלפניה, כמו בפה אנושי.
2. **הלסת מאחרת.** היא מסה ולא מתג. אותו רצף נפתר **פעמיים**, עם
   חלון רחב יותר ללסת מאשר לשפתיים. בלי זה הלסת מקרטעת בקצב
   הפונמות, וזה נראה כמו לועס.
3. **הרגש משנה את ההגייה עצמה, לא רק את הפנים סביבה.** דיבור בכעס
   אינו דיבור + גבות כועסות: פתיחת הפה חדה יותר, השפתיים לחוצות
   בין ההגיות, האף מתרחב. דיבור בעצב - הפוך. דיבור שקט מקטין את
   תנועת הפה בלי להקטין את מספר הפונמות.

המדידה שמוכיחה שזה הוחלף: `features()` מודדת את הקורלציה המקסימלית
של פתיחת הלסת מול כל סינוס בטווח 1.2-4.5 הרץ. מנוע סינוס מחזיר שם
כמעט 1.0; המנוע הזה מחזיר ערך נמוך - כי הקצב שלו נגזר מהטקסט.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

from . import acting

# ------------------------------------------------------------ ויזמות
#
# ויזמה אינה "צורת פה" אחת: היא **מטרה** בכמה ערוצים בבת אחת. jaw
# מופרד משאר הערוצים בכוונה - הוא הערוץ האיטי (עקרון 2).


@dataclass(frozen=True)
class Viseme:
    key: str
    jaw: float = 0.0
    ctl: dict = field(default_factory=dict)
    mph: dict = field(default_factory=dict)
    width: float = 1.0          # רוחב חלון ההשפעה (coarticulation)
    note: str = ""


VISEMES: dict[str, Viseme] = {}


def _vi(key, jaw=0.0, ctl=None, mph=None, width=1.0, note=""):
    VISEMES[key] = Viseme(key, jaw, dict(ctl or {}), dict(mph or {}),
                          width, note)


_vi("sil", 0.015, mph={"lip_press": 0.10}, width=1.30,
    note="שקט · הפה נח סגור ורפוי, לא עצום בכוח")
_vi("PP", 0.00, mph={"lip_press": 0.88}, width=0.72,
    note="m/b/p · חסימה שפתית מלאה - **הפה נסגר לגמרי**")
_vi("FF", 0.11, mph={"lip_lo_depress": 0.55, "lip_up_raise_L": 0.26,
                     "lip_up_raise_R": 0.26}, width=0.92,
    note="f/v · שפה תחתונה נכנסת מתחת לשיניים")
_vi("TH", 0.17, ctl={"tongue_out": 0.32}, mph={"lip_funnel": 0.12},
    width=0.90, note="th · קצה הלשון בין השיניים")
_vi("DD", 0.19, ctl={"tongue_up": 0.74}, width=0.78,
    note="t/d/l · הלשון נוגעת בחניכיים")
_vi("NN", 0.10, ctl={"tongue_up": 0.62}, mph={"nose_flare": 0.14},
    width=0.80, note="n · נזאלי: אוויר באף, הפה כמעט סגור")
_vi("KK", 0.27, ctl={"tongue_up": -0.46}, width=0.84,
    note="k/g/ח · חסימה אחורית, הפה פתוח אך הלשון שוקעת")
_vi("CH", 0.15, mph={"lip_funnel": 0.62, "lip_pucker": 0.30}, width=0.96,
    note="ש/צ'/ז' · שפתיים מוקרנות קדימה")
_vi("SS", 0.07, mph={"mouth_stretch": 0.32, "lip_press": 0.20}, width=0.90,
    note="s/z · שיניים כמעט נוגעות, הפה מתוח לרוחב")
_vi("RR", 0.21, ctl={"tongue_up": 0.26}, mph={"lip_funnel": 0.36},
    width=0.90, note="ר · עיגול קל")
_vi("aa", 0.80, mph={"mouth_stretch": 0.14}, width=1.16,
    note="a · הלסת הפתוחה ביותר")
_vi("E", 0.43, mph={"mouth_stretch": 0.44}, width=1.10,
    note="e · פתיחה בינונית + מתיחה לרוחב")
_vi("I", 0.20, mph={"mouth_stretch": 0.70}, width=1.04,
    note="i · רוחב מקסימלי, פתיחה מינימלית")
_vi("O", 0.47, mph={"lip_funnel": 0.56, "lip_pucker": 0.26}, width=1.16,
    note="o · פתוח ומעוגל")
_vi("U", 0.17, mph={"lip_pucker": 0.80, "lip_funnel": 0.26}, width=1.10,
    note="u · כיווץ מלא, פתיחה מינימלית")


# ------------------------------------------------------------ פונמות
#
# הערה חשובה ומוצהרת: אין כאן ניתוח פונולוגי של עברית מנוקדת (וגם
# לא יכול להיות - הטקסטים בסצנות אינם מנוקדים). מה שיש כאן הוא
# הערכה שמייצרת **מקצב וסוגי תנועות נכונים**, וזה מה שהעין רואה.
# הטענה של TASK 05 אינה "הפונמות מדויקות" אלא "הפה מונע מרצף
# פונמות ומהופעה, ולא מגל סינוס" - וזו טענה שהמדידה בודקת.

PH2VIS: dict[str, str] = {
    "m": "PP", "b": "PP", "p": "PP",
    "f": "FF", "v": "FF",
    "th": "TH",
    "t": "DD", "d": "DD", "l": "DD",
    "n": "NN",
    "k": "KK", "g": "KK", "x": "KK", "h": "KK", "q": "KK",
    "sh": "CH", "ch": "CH", "j": "CH",
    "s": "SS", "z": "SS", "ts": "SS",
    "r": "RR",
    "a": "aa", "e": "E", "i": "I", "o": "O", "u": "U",
    "w": "U", "y": "I",
    "_": "sil",
}

#: אורך יחסי של כל פונמה. **זה** מה שהורג את המחזוריות: סותם הוא
#: 0.42 ותנועה היא 1.0, ולכן הקצב נגזר מרצף האותיות בפועל.
PH_DUR: dict[str, float] = {
    "p": 0.42, "b": 0.44, "t": 0.40, "d": 0.42, "k": 0.44, "g": 0.46,
    "q": 0.44, "ts": 0.62,
    "f": 0.66, "v": 0.60, "s": 0.70, "z": 0.64, "sh": 0.74, "ch": 0.66,
    "j": 0.62, "x": 0.62, "h": 0.46, "th": 0.60,
    "m": 0.56, "n": 0.52,
    "l": 0.48, "r": 0.50, "w": 0.52, "y": 0.48,
    "a": 1.00, "e": 0.94, "i": 0.88, "o": 0.98, "u": 0.92,
    "_": 0.60,
}

#: אות עברית -> פונמה. מחרוזת ריקה = האות היא תנועה/שקט ותטופל להלן.
HEB: dict[str, str] = {
    "א": "", "ב": "b", "ג": "g", "ד": "d", "ה": "h", "ו": "v", "ז": "z",
    "ח": "x", "ט": "t", "י": "y", "כ": "k", "ך": "k", "ל": "l", "מ": "m",
    "ם": "m", "נ": "n", "ן": "n", "ס": "s", "ע": "", "פ": "p", "ף": "f",
    "צ": "ts", "ץ": "ts", "ק": "k", "ר": "r", "ש": "sh", "ת": "t",
}

LAT: dict[str, str] = {
    "a": "a", "e": "e", "i": "i", "o": "o", "u": "u", "y": "y",
    "b": "b", "c": "k", "d": "d", "f": "f", "g": "g", "h": "h",
    "j": "j", "k": "k", "l": "l", "m": "m", "n": "n", "p": "p",
    "q": "q", "r": "r", "s": "s", "t": "t", "v": "v", "w": "w",
    "x": "x", "z": "z",
}

#: תנועות המילוי. עיצור שאין אחריו תנועה מקבל אחת מאלה, לפי אינדקס
#: דטרמיניסטי - אותו טקסט מפיק אותו רצף בכל בנייה, ולכן אפשר לבדוק.
_FILL = ("a", "e", "i", "o", "a", "e")

#: הפסקות לפי פיסוק, ביחידות אורך פונמה.
_PUNCT = {",": 1.5, ";": 1.7, ":": 1.6, ".": 2.2, "!": 2.0, "?": 2.3,
          "-": 1.1, "–": 1.1, "…": 2.6}

_VOWELS = frozenset("aeiou")


def _frac(x: float) -> float:
    """רעש דטרמיניסטי ב-[0,1). אין random: אותו משפט חייב לצאת זהה
    בכל רנדור, אחרת אי אפשר לחזור על צילום ואי אפשר למדוד."""
    s = math.sin(x * 127.1 + 311.7) * 43758.5453123
    return s - math.floor(s)


def phonemize(text: str) -> list[tuple[str, float]]:
    """טקסט -> [(פונמה, אורך יחסי)]. גם עברית וגם לטינית.

    שתי החלטות שיש להן ביטוי בתמונה:
    * א/ע הן תנועה ולא עיצור; ו' בתחילת מילה היא v ובאמצעה o;
      י' בתחילת מילה היא y ובאמצעה i. בלי זה כל מילה עברית יוצאת
      כרצף עיצורים והפה כמעט לא נפתח.
    * אחרי עיצור שאין אחריו תנועה נוספת תנועת מילוי. זה מה שהופך
      "שלום" ל-sh-a-l-o-m ולא ל-sh-l-v-m, שבו הפה נשאר סגור.
    """
    out: list[tuple[str, float]] = []
    words = []
    cur = ""
    tail = ""
    for ch in str(text or ""):
        if ch in _PUNCT:
            if cur:
                words.append((cur, tail))
                cur, tail = "", ""
            words.append(("", ch))
        elif ch.isspace():
            if cur:
                words.append((cur, tail))
                cur, tail = "", ""
        else:
            cur += ch
    if cur:
        words.append((cur, tail))

    wi = 0
    for w, punct in words:
        if w:
            phs: list[str] = []
            n = len(w)
            for i, ch in enumerate(w):
                low = ch.lower()
                if ch in HEB:
                    p = HEB[ch]
                    if p == "":
                        p = "a"
                    elif ch == "ו" and i > 0:
                        p = "o"
                    elif ch in ("י", "ך") and i > 0 and ch == "י":
                        p = "i"
                elif low in LAT:
                    p = LAT[low]
                    if low == "y" and i > 0:
                        p = "i"
                else:
                    continue
                # דיגרף: sh/ch/th/ts בלטינית
                if phs and p == "h" and phs[-1] in ("s", "t", "c", "k"):
                    phs[-1] = {"s": "sh", "t": "th", "c": "ch",
                               "k": "ch"}[phs[-1]]
                    continue
                phs.append(p)
                # תנועת מילוי: רק אם הפונמה הבאה אינה תנועה
                if p not in _VOWELS and i + 1 < n:
                    nx = w[i + 1]
                    nxt_v = (nx in HEB and HEB[nx] == "") or \
                        (nx.lower() in LAT and LAT[nx.lower()] in _VOWELS) or \
                        nx == "ו" or (nx == "י" and i + 1 > 0)
                    if not nxt_v:
                        phs.append(_FILL[(wi * 2 + i) % len(_FILL)])
            if phs and phs[-1] not in _VOWELS and len(phs) < 3:
                phs.append(_FILL[wi % len(_FILL)])
            for k, p in enumerate(phs):
                # ג'יטר אורך של ±12%: דיבור אנושי אינו איזוכרוני.
                j = 0.88 + 0.24 * _frac(wi * 17.3 + k * 3.1)
                out.append((p, PH_DUR.get(p, 0.6) * j))
            wi += 1
            if not punct:
                out.append(("_", PH_DUR["_"]))
        if punct:
            out.append(("_", PH_DUR["_"] * _PUNCT.get(punct, 1.0)))
    while out and out[-1][0] == "_":
        out.pop()
    return out


# ------------------------------------------------------------ ציר הזמן


@dataclass
class Phone:
    ph: str
    vis: str
    at: float               # זמן המרכז בשניות
    dur: float              # אורך בשניות
    kind: str = "ph"        # ph | pause | filler


@dataclass
class Event:
    """אירוע לא-מילולי. **זה** הסעיף שלא היה קיים בכלל קודם."""
    kind: str               # breath | swallow | hesitation | react
    at: float
    dur: float
    amount: float = 1.0


# ------------------------------------------------------------ ההגשה


@dataclass
class Delivery:
    """איך מדברים, ולא מה אומרים.

    `loudness` הוא הדרישה "reduced mouth movement during quiet speech":
    הוא מכפיל את תנועת הפה בלבד, ואינו משנה את מספר הפונמות ואת
    הקצב - בדיוק כמו אדם שמלמל.
    """
    loudness: float = 1.0
    emotion: str = ""
    smile: float = 0.0          # חיוך תוך דיבור
    rate: float = 1.0           # מהירות הגייה
    tension: float = 0.0        # מתח: לחיצת שפתיים בין ההגיות


#: איך כל רגש משנה את ההגייה. jaw/stretch/press מכפילים או מוסיפים,
#: ו-`snap` משנה את חדות המעברים (רוחב חלון ה-coarticulation).
EMOTION_VOICE: dict[str, dict] = {
    "": {"jaw": 1.00, "press": 0.00, "flare": 0.00, "stretch": 0.00,
         "snap": 1.00, "corner": 0.00, "sneer": 0.00},
    "anger": {"jaw": 1.10, "press": 0.30, "flare": 0.36, "stretch": 0.18,
              "snap": 1.45, "corner": 0.00, "sneer": 0.22},
    "contempt": {"jaw": 0.80, "press": 0.26, "flare": 0.10, "stretch": 0.00,
                 "snap": 1.10, "corner": 0.20, "sneer": 0.30},
    "sadness": {"jaw": 0.62, "press": 0.24, "flare": 0.00, "stretch": 0.00,
                "snap": 0.70, "corner": -0.36, "sneer": 0.00},
    "shame": {"jaw": 0.58, "press": 0.28, "flare": 0.00, "stretch": 0.00,
              "snap": 0.72, "corner": -0.22, "sneer": 0.00},
    "amusement": {"jaw": 0.92, "press": 0.00, "flare": 0.12, "stretch": 0.10,
                  "snap": 1.12, "corner": 0.48, "sneer": 0.00},
    "fear": {"jaw": 0.86, "press": 0.00, "flare": 0.32, "stretch": 0.32,
             "snap": 1.32, "corner": 0.00, "sneer": 0.00},
    "suspicion": {"jaw": 0.84, "press": 0.22, "flare": 0.08, "stretch": 0.00,
                  "snap": 1.05, "corner": 0.10, "sneer": 0.08},
    "doubt": {"jaw": 0.82, "press": 0.20, "flare": 0.05, "stretch": 0.00,
              "snap": 0.92, "corner": 0.00, "sneer": 0.00},
    "guilt": {"jaw": 0.64, "press": 0.26, "flare": 0.00, "stretch": 0.00,
              "snap": 0.76, "corner": -0.28, "sneer": 0.00},
}


def voice_of(emotion: str, arousal: float = 0.5,
             control: float = 0.5) -> dict:
    """מקדמי ההגייה לרגש נתון, עם תיקון לפי עוררות ושליטה.

    שליטה גבוהה **מצמצמת** את תנועת הפה: אדם ששומר על עצמו לא פותח
    את הפה לרווחה. זה מה שמונע מדמות "שולטת" להיראות כמי שצועקת.
    """
    base = dict(EMOTION_VOICE.get(emotion, EMOTION_VOICE[""]))
    a = max(0.0, min(1.0, float(arousal)))
    c = max(0.0, min(1.0, float(control)))
    base["jaw"] *= 0.82 + 0.34 * a
    base["jaw"] *= 1.08 - 0.22 * c
    base["snap"] *= 0.84 + 0.32 * a
    base["press"] += 0.18 * c
    return base


# ------------------------------------------------------------ השחקן


class SpeechActor:
    """המערכת שמחליפה את הליפ-סינק המכני.

    נבנית **פעם אחת** לשוט ולא בכל פריים: רצף הפונמות, הפאוזות,
    ההיסוסים והנשימות חייב להיות זהה בכל הפריימים, אחרת כל פריים
    מקבל תכנון אחר והפה מקרטע.
    """

    def __init__(self, text: str, windows=(), delivery: Delivery | None = None,
                 seed: float = 0.0, hesitate: tuple = (),
                 breaths: bool = True, swallow: bool = True,
                 reacts: bool = True, track=None):
        self.text = str(text or "")
        self.windows = tuple(tuple(map(float, w)) for w in windows)
        self.d = delivery or Delivery()
        self.seed = float(seed)
        self.v = voice_of(self.d.emotion)
        #: `rig.voice.Track` - ניתוח של קובץ שמע אמיתי. כשהוא קיים,
        #: ההגאים נלקחים **ממנו** ולא מהטקסט. ראה `_plan_from_audio`.
        self.track = track
        self.phones: list[Phone] = []
        self.events: list[Event] = []
        self._plan(hesitate, breaths, swallow, reacts)

    # --- תכנון מתוך שמע אמיתי (TASK 06)
    def _plan_from_audio(self, breaths: bool, swallow: bool) -> None:
        """ההגאים מגיעים מ**מדידה של הקול**, לא מניתוח של הטקסט.

        זה סוגר את שני הפערים שנשארו פתוחים ב-TASK 05:

        1. *"אין קובץ קול, ולכן ההגאים מסונכרנים לחלונות הזמן של
           הדיבור ולא לשמע אמיתי."* - עכשיו יש קובץ קול, והחלון
           נמתח **אליו**: `t0` מהסצנה, והאורך מאורך ההקלטה. אם
           הסצנה הצהירה על חלון קצר מהשמע, השמע מנצח - הוא העובדה.
        2. *"ההגאים של העברית הם הערכה סבירה ולא ניתוח של טקסט
           מנוקד."* - אין יותר השלמת תנועות מרשימה מחזורית. כל
           תנועה כאן נמדדה מהפורמנטים של הקול שבאמת נשמע.

        הפאוזות אינן מוכנסות לפי כללי פיסוק אלא **נמדדות**: מקטע
        `sil` בתוך הדיבור הוא פאוזה אמיתית, באורך שבאמת היה.
        """
        tr = self.track
        a0 = self.windows[0][0]
        # ההגשה עדיין משפיעה על **הקצב** (דמות שמסתירה מדברת לאט),
        # אבל לא על *מה* נהגה. זו ההפרדה הנכונה: הרגש משנה את
        # האופן, הקול קובע את התוכן.
        rate = max(0.45, min(1.8, self.d.rate))
        for i, (s, e, v) in enumerate(tr.visemes):
            dur = (e - s) / rate
            at = a0 + (s / rate) + dur * 0.5
            ph = {"a": "a", "e": "e", "i": "i", "o": "o", "u": "u",
                  "s": "s", "f": "f", "m": "m", "sil": "_"}.get(v, "a")
            self.phones.append(Phone(ph, PH2VIS.get(ph, "sil"), at, dur,
                                     "pause" if v == "sil" else "ph"))
            # פאוזה ארוכה באמצע הדיבור היא הזדמנות לבליעה - וזו
            # פאוזה **שנמדדה** ולא כזו שהוחלט עליה לפי פסיק.
            if swallow and v == "sil" and dur > 0.30 and 0 < i < \
                    len(tr.visemes) - 1 and not any(
                        ev.kind == "swallow" for ev in self.events):
                self.events.append(Event("swallow", at, min(0.5, dur * 0.7),
                                         1.0))
        if breaths:
            self.events.append(Event("breath", a0 - 0.34, 0.40, 0.85))
        # חלון הדיבור האמיתי מחליף את זה שהוצהר בסצנה.
        self.windows = ((a0, round(a0 + tr.seconds / rate, 4)),)
        self.phones.sort(key=lambda p: p.at)

    # --- תכנון
    def _plan(self, hesitate, breaths, swallow, reacts) -> None:
        if not self.windows:
            return
        if self.track is not None:
            self._plan_from_audio(breaths, swallow)
            return
        seq = phonemize(self.text)
        if not seq:
            seq = [("a", 1.0), ("_", 0.6)]
        # חלוקת הפונמות בין חלונות הדיבור **לפי אורך החלון** ולא
        # בחלקים שווים: חלון ארוך מקבל יותר טקסט, ולכן קצב ההגייה
        # נשאר דומה בכל החלונות.
        tot = sum(max(0.05, b - a) for a, b in self.windows) or 1.0
        idx, n = 0, len(seq)
        hez = set(int(h) for h in hesitate)
        for wi, (a, b) in enumerate(self.windows):
            span = max(0.05, b - a)
            take = n - idx if wi == len(self.windows) - 1 else \
                max(1, int(round(n * span / tot)))
            chunk = seq[idx:idx + take]
            idx += take
            if not chunk:
                chunk = [("_", 0.6)]
            # היסוס: פונמת מילוי מתוחה בראש החלון ("אֶה...")
            if wi in hez:
                chunk = [("e", 2.1), ("_", 1.3)] + list(chunk)
                self.events.append(Event("hesitation", a, min(0.9, span * 0.4),
                                         1.0))
            base = sum(d for _p, d in chunk) or 1.0
            # קצב: אורך החלון קובע את יחידת הזמן. rate מהיר מכניס
            # יותר שקט בסוף במקום לדחוס את הפונמות.
            unit = span / (base * max(0.35, self.d.rate))
            t = a
            for p, d in chunk:
                dur = d * unit
                self.phones.append(Phone(p, PH2VIS.get(p, "sil"),
                                         t + dur * 0.5, dur,
                                         "pause" if p == "_" else "ph"))
                t += dur
            if breaths:
                # שאיפה **לפני** תחילת הדיבור. אדם לא מתחיל משפט
                # מאפס אוויר, וזו ההקדמה שהעין קוראת כ"עומדת לדבר".
                self.events.append(Event("breath", a - 0.34,
                                         0.40, 0.85 if wi == 0 else 0.6))
        # פאוזות ארוכות בין החלונות: בליעה / תגובה לא-מילולית.
        # הבליעה נכנסת לפאוזה ה**ארוכה ביותר** שמעל שנייה, ולא לפי
        # הגרלה: אדם בולע כשיש לו זמן, וזו גם הדרך היחידה שהיא
        # תיבדק - אירוע שתלוי במזל פעם נמדד ופעם לא.
        gaps = [(self.windows[i + 1][0] - self.windows[i][1], i)
                for i in range(len(self.windows) - 1)]
        if swallow and gaps:
            gap, gi = max(gaps)
            if gap > 1.0:
                g0 = self.windows[gi][1]
                self.events.append(Event("swallow", g0 + gap * 0.30,
                                         min(0.55, gap * 0.45), 1.0))
        for i in range(len(self.windows) - 1):
            g0, g1 = self.windows[i][1], self.windows[i + 1][0]
            gap = g1 - g0
            if gap < 0.45:
                continue
            r = _frac(i * 9.7 + self.seed)
            if reacts:
                self.events.append(Event("react", g0 + gap * 0.58,
                                         min(0.70, gap * 0.55),
                                         0.55 + 0.45 * r))
        self.phones.sort(key=lambda p: p.at)

    # --- פתרון
    def speaking(self, t: float) -> bool:
        return any(a <= t <= b for a, b in self.windows)

    def _blend(self, t: float, wscale: float = 1.0) -> tuple:
        """ממוצע משוקלל של הויזמות השכנות -> (jaw, ctl, mph).

        זה הלב. פונמה אינה "נדלקת ונכבית": לכל אחת חלון תמיכה
        קומפקטי שרוחבו נגזר מאורכה ומסוגה, והפלט הוא ממוצע. לכן
        בין m ל-a הפה עובר דרך כל ערכי הביניים, והתנועה מתחילה
        להיפתח עוד **בתוך** ה-m.
        """
        snap = max(0.45, self.v["snap"])
        sw = 0.0
        jaw = 0.0
        ctl: dict = {}
        mph: dict = {}
        for p in self.phones:
            vis = VISEMES[p.vis]
            hw = max(1e-4, p.dur * 0.62 * vis.width * wscale / snap)
            dt = abs(t - p.at)
            if dt >= hw:
                continue
            w = math.cos(math.pi * 0.5 * (dt / hw)) ** 2
            if w <= 1e-9:
                continue
            sw += w
            jaw += vis.jaw * w
            for k, val in vis.ctl.items():
                ctl[k] = ctl.get(k, 0.0) + val * w
            for k, val in vis.mph.items():
                mph[k] = mph.get(k, 0.0) + val * w
        if sw <= 1e-6:
            return 0.0, {}, {}
        return (jaw / sw, {k: v / sw for k, v in ctl.items()},
                {k: v / sw for k, v in mph.items()})

    def _nonverbal(self, t: float) -> tuple[dict, dict]:
        """נשימה, בליעה, היסוס ותגובה בין מילים.

        אלה אינם קוסמטיקה: בלעדיהם הפנים "מחכות" בין המשפטים, וזה
        הדבר שהעין קוראת כאנימציה שנגמרה באמצע.
        """
        ctl: dict = {}
        mph: dict = {}
        for e in self.events:
            if e.dur <= 1e-6:
                continue
            u = (t - e.at) / e.dur
            if u < 0.0 or u > 1.0:
                continue
            s = math.sin(math.pi * u) ** 1.2 * e.amount
            if e.kind == "breath":
                # שאיפה: אף מתרחב, לסת נפתחת מעט, החזה עולה.
                mph["nose_flare"] = mph.get("nose_flare", 0.0) + 0.52 * s
                ctl["jaw_open"] = ctl.get("jaw_open", 0.0) + 0.12 * s
                ctl["breath"] = ctl.get("breath", 0.0) + 0.70 * s
            elif e.kind == "swallow":
                # בליעה: הלשון עולה, הלסת נסגרת, הראש עולה קלות
                # ואז חוזר. זה מה שנראה כגרון שעובד.
                ctl["tongue_up"] = ctl.get("tongue_up", 0.0) + 0.78 * s
                ctl["jaw_open"] = ctl.get("jaw_open", 0.0) - 0.06 * s
                mph["lip_press"] = mph.get("lip_press", 0.0) + 0.40 * s
                ctl["head_pitch"] = ctl.get("head_pitch", 0.0) + 0.09 * s
                ctl["neck_pitch"] = ctl.get("neck_pitch", 0.0) + 0.05 * s
            elif e.kind == "hesitation":
                mph["lip_press"] = mph.get("lip_press", 0.0) + 0.30 * s
                mph["mouth_dimple"] = mph.get("mouth_dimple", 0.0) + 0.22 * s
                ctl["brow_inner_up_L"] = ctl.get("brow_inner_up_L", 0.0) + \
                    0.26 * s
                ctl["brow_inner_up_R"] = ctl.get("brow_inner_up_R", 0.0) + \
                    0.20 * s
            elif e.kind == "react":
                # תגובה לא-מילולית בין מילים: הסוג נגזר מהרגש, לא
                # אקראי. דמות עצובה לא מחייכת בפאוזה.
                c = self.v["corner"]
                if c >= 0.0:
                    mph["mouth_corner_up_L"] = \
                        mph.get("mouth_corner_up_L", 0.0) + (0.26 + c) * s
                    mph["mouth_corner_up_R"] = \
                        mph.get("mouth_corner_up_R", 0.0) + (0.20 + c) * s
                    mph["cheek_raise_L"] = \
                        mph.get("cheek_raise_L", 0.0) + 0.22 * s
                else:
                    mph["mouth_corner_down_L"] = \
                        mph.get("mouth_corner_down_L", 0.0) + 0.28 * s
                    mph["lip_lo_depress"] = \
                        mph.get("lip_lo_depress", 0.0) + 0.20 * s
                ctl["head_pitch"] = ctl.get("head_pitch", 0.0) - 0.07 * s
        return ctl, mph

    def raw(self, t: float) -> dict:
        """{"ctl":..., "mph":...} בזמן t. אינו קורא ל-finalize: הקורא
        מחבר את זה אל הרגש ואל הגוף ואז מסיים פעם אחת."""
        t = float(t)
        # הלסת מהחלון הרחב (עקרון 2), השפתיים מהצר.
        jaw_s, _c_s, _m_s = self._blend(t, 1.42)
        _j_f, ctl_f, mph_f = self._blend(t, 1.0)
        loud = max(0.0, min(1.5, self.d.loudness))
        # עקומת העוצמה אינה ליניארית: בלחישה הפה כמעט לא נפתח אבל
        # השפתיים ממשיכות לעבוד - וזה בדיוק מה שנראה כמלמול.
        g_jaw = (0.18 + 0.82 * loud ** 1.45) * self.v["jaw"]
        g_lip = 0.42 + 0.58 * loud
        ctl: dict = {}
        mph: dict = {}
        if jaw_s > 1e-6 or ctl_f or mph_f:
            ctl["jaw_open"] = jaw_s * g_jaw
            for k, val in ctl_f.items():
                ctl[k] = ctl.get(k, 0.0) + val * g_lip
            for k, val in mph_f.items():
                mph[k] = mph.get(k, 0.0) + val * g_lip
        # --- ההופעה הרגשית על גבי ההגייה
        sp = 1.0 if self.speaking(t) else 0.0
        if sp:
            v = self.v
            # לחיצת שפתיים בין ההגיות: חזקה כשהפה סגור, אפס כשפתוח.
            idle = max(0.0, 1.0 - jaw_s * 2.2)
            pr = (v["press"] + 0.35 * self.d.tension) * idle
            if pr > 1e-6:
                mph["lip_press"] = mph.get("lip_press", 0.0) + pr
            if v["flare"] > 1e-6:
                mph["nose_flare"] = mph.get("nose_flare", 0.0) + \
                    v["flare"] * (0.45 + 0.55 * jaw_s)
            if v["stretch"] > 1e-6:
                mph["mouth_stretch"] = mph.get("mouth_stretch", 0.0) + \
                    v["stretch"]
            if v["sneer"] > 1e-6:
                mph["nose_sneer_L"] = mph.get("nose_sneer_L", 0.0) + v["sneer"]
                mph["nose_sneer_R"] = mph.get("nose_sneer_R", 0.0) + \
                    v["sneer"] * 0.7
            # חיוך/נפילה **תוך** דיבור. corner_up ו-jaw_open יכולים
            # להתקיים יחד - אדם מחייך ומדבר בבת אחת.
            c = v["corner"] + self.d.smile
            if c > 1e-6:
                mph["mouth_corner_up_L"] = \
                    mph.get("mouth_corner_up_L", 0.0) + c
                mph["mouth_corner_up_R"] = \
                    mph.get("mouth_corner_up_R", 0.0) + c * 0.86
                mph["cheek_raise_L"] = mph.get("cheek_raise_L", 0.0) + c * 0.5
                mph["cheek_raise_R"] = mph.get("cheek_raise_R", 0.0) + c * 0.44
            elif c < -1e-6:
                mph["mouth_corner_down_L"] = \
                    mph.get("mouth_corner_down_L", 0.0) - c
                mph["mouth_corner_down_R"] = \
                    mph.get("mouth_corner_down_R", 0.0) - c * 0.84
            # הלסת נעה מעט הצידה בהגייה. גל איטי ולא בתדר הפונמות -
            # אחרת הוא מחזיר בדלת האחורית בדיוק את הסינוס שהוחלף.
            ctl["jaw_side"] = ctl.get("jaw_side", 0.0) + \
                0.08 * math.sin(t * 1.17 + self.seed) * loud
        nc, nm = self._nonverbal(t)
        for k, val in nc.items():
            ctl[k] = ctl.get(k, 0.0) + val
        for k, val in nm.items():
            mph[k] = mph.get(k, 0.0) + val
        return {"ctl": ctl, "mph": mph}

    # --- מידע
    def mouth_energy(self, t: float) -> float:
        r = self.raw(t)
        ctl, mph = acting.finalize(r["ctl"], r["mph"])
        act = acting.region_activity(ctl, mph)
        return act["mouth"] + act["jaw"] + act["lips"]

    def describe(self) -> dict:
        kinds: dict[str, int] = {}
        for e in self.events:
            kinds[e.kind] = kinds.get(e.kind, 0) + 1
        return {"text": self.text, "phones": len(self.phones),
                "pauses": sum(1 for p in self.phones if p.kind == "pause"),
                "visemes": sorted({p.vis for p in self.phones}),
                "events": kinds,
                "windows": len(self.windows),
                "emotion": self.d.emotion,
                "loudness": round(self.d.loudness, 3)}


# ------------------------------------------------------------ מדידות


def _corr(a: list, b: list) -> float:
    n = min(len(a), len(b))
    if n < 3:
        return 0.0
    ma = sum(a[:n]) / n
    mb = sum(b[:n]) / n
    va = sum((x - ma) ** 2 for x in a[:n])
    vb = sum((x - mb) ** 2 for x in b[:n])
    if va < 1e-12 or vb < 1e-12:
        return 0.0
    cv = sum((a[i] - ma) * (b[i] - mb) for i in range(n))
    return cv / math.sqrt(va * vb)


def sine_corr(xs: list, ts: list) -> float:
    """הקורלציה המקסימלית של האות מול **כל** סינוס בטווח הדיבור.

    זה המדד שמוכיח את ההחלפה. מנוע `0.08 + 0.50*sin(2*pi*t*2.7)`
    מחזיר כאן כ-1.0 בתדר 2.7; מנוע פונמות מחזיר ערך נמוך, כי אין
    לו תדר אחד - הקצב שלו נגזר מרצף האותיות.
    """
    best = 0.0
    f = 1.2
    while f <= 4.5:
        for ph in (0.0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0):
            ref = [max(0.0, math.sin(2 * math.pi * f * t + ph)) ** 0.7
                   for t in ts]
            best = max(best, abs(_corr(xs, ref)))
        f += 0.1
    return best


def _longest(windows) -> tuple[float, float]:
    """החלון הארוך ביותר. **המדידה חייבת להיות בתוך חלון אחד.**

    נמדד כאן שהמנוע הישן מקבל 0.70 בלבד כשמודדים אותו על כל השוט,
    כי הוא מאפס את הפאזה בתחילת כל חלון (`x = t - a`) והחלונות
    באורכים שונים - כלומר שבירת הפאזה בין חלונות מורידה את הניקוד
    של *מנוע הסינוס עצמו*, והמדד מפסיק להבדיל. בתוך חלון אחד
    הסינוס הוא סינוס טהור, ושם ההבדל אמיתי.
    """
    if not windows:
        return (0.0, 1.0)
    return max(windows, key=lambda w: w[1] - w[0])


def mechanical_baseline(windows, fps: int = 120) -> float:
    """`sine_corr` של המנוע **הישן** שהוחלף, על אותו חלון בדיוק.

    בלי מספר ההשוואה הזה "החלפנו את הליפ-סינק המכני" היא טענה בלי
    יחידות. זהו הקוד שהיה ב-`showreel._talk` עד TASK 05, מועתק
    כמות שהוא כדי שיימדד ולא ייזכר.
    """
    a, b = _longest(windows)
    ts, xs = [], []
    for i in range(int((b - a) * fps) + 1):
        x = i / fps
        v = max(0.0, math.sin(2 * math.pi * x * 2.7)) ** 0.7
        ts.append(a + x)
        xs.append(0.08 + 0.50 * v)
    return round(sine_corr(xs, ts), 4)


def features(text: str = "זה לא היה ככה בכלל.",
             windows=((0.6, 2.4), (3.4, 5.2), (6.5, 7.4)), fps: int = 120,
             shot_len: float = 7.8) -> dict:
    """כל מה ש-TASK 05 דרש, כמספרים. הבדיקות קוראות מכאן.

    החלונות שלושה ולא שניים, והפער בין השני לשלישי ארוך מ-1.0
    שנייה: בליעה מתוכננת רק בפאוזה שבאמת מספיקה לה, ולכן בשני
    חלונות צמודים היא לעולם לא נמדדת.
    """
    def run(d: Delivery, **kw):
        act = SpeechActor(text, windows, d, seed=1.0, **kw)
        ts, jaw, press, up, down, flare, stretch = [], [], [], [], [], [], []
        for i in range(int(shot_len * fps) + 1):
            t = i / fps
            r = act.raw(t)
            ts.append(t)
            jaw.append(r["ctl"].get("jaw_open", 0.0))
            press.append(r["mph"].get("lip_press", 0.0))
            up.append(r["mph"].get("mouth_corner_up_L", 0.0))
            down.append(r["mph"].get("mouth_corner_down_L", 0.0))
            flare.append(r["mph"].get("nose_flare", 0.0))
            stretch.append(r["mph"].get("mouth_stretch", 0.0))
        return act, ts, jaw, press, up, down, flare, stretch

    neutral, ts, jaw, _pr, _u, _d, _f, _s = run(Delivery())
    spk = [i for i, t in enumerate(ts) if neutral.speaking(t)]
    jaw_in = [jaw[i] for i in spk]
    ts_in = [ts[i] for i in spk]
    # ההשוואה לסינוס נעשית בתוך החלון הארוך בלבד (ראו `_longest`)
    wa, wb = _longest(windows)
    one = [i for i, t in enumerate(ts) if wa <= t <= wb]
    # רגעי שקט **בתוך** חלון דיבור: פאוזות והגיות סגורות
    closed = sum(1 for x in jaw_in if x < 0.06) / max(1, len(jaw_in))
    mx = max(jaw_in) if jaw_in else 0.0

    quiet, _t, jq, *_ = run(Delivery(loudness=0.28))
    ang, _t, ja, pa, _u, _d, fa, sa = run(Delivery(emotion="anger"))
    sad, _t, js, ps, _u, ds, _f, _s = run(Delivery(emotion="sadness"))
    amu, _t, jm, _p, um, _d, _f, _s = run(Delivery(emotion="amusement"))
    hez = SpeechActor(text, windows, Delivery(), seed=1.0, hesitate=(1,))
    plain = SpeechActor(text, windows, Delivery(), seed=1.0)
    no_nv = SpeechActor(text, windows, Delivery(), seed=1.0,
                        breaths=False, swallow=False, reacts=False)

    ev: dict[str, int] = {}
    for e in plain.events:
        ev[e.kind] = ev.get(e.kind, 0) + 1

    # חיוך תוך דיבור: הפינות למעלה **בעוד** הפה פתוח
    smile_open = max((um[i] for i in spk if jm[i] > 0.25), default=0.0)
    return {
        "phones": len(plain.phones),
        "visemes_used": len({p.vis for p in plain.phones}),
        "sine_corr": round(sine_corr([jaw[i] for i in one],
                                     [ts[i] for i in one]), 4),
        "sine_corr_old": mechanical_baseline(windows, fps),
        "jaw_max": round(mx, 4),
        "angry_jaw_max": round(max(ja) if ja else 0.0, 4),
        "closed_frac_in_speech": round(closed, 4),
        "quiet_jaw_ratio": round((max(jq) if jq else 0) / max(1e-6, mx), 4),
        "angry_press_max": round(max(pa) if pa else 0.0, 4),
        "angry_flare_max": round(max(fa) if fa else 0.0, 4),
        "angry_stretch_max": round(max(sa) if sa else 0.0, 4),
        "sad_corner_down_max": round(max(ds) if ds else 0.0, 4),
        "sad_jaw_ratio": round((max(js) if js else 0) / max(1e-6, mx), 4),
        "smile_while_open": round(smile_open, 4),
        "events": ev,
        "nonverbal_events": len(plain.events),
        "nonverbal_off": len(no_nv.events),
        "hesitation_phones": len(hez.phones) - len(plain.phones),
        "pauses": sum(1 for p in plain.phones if p.kind == "pause"),
    }


def drive_report(sit=None, text: str | None = None,
                 windows=((1.2, 2.55), (3.4, 4.6)), fps: int = 60,
                 shot_len: float = 5.6) -> dict:
    """האם הפה הוא **המניע הראשי** של הפנים? מדידה, לא הצהרה.

    הדרישה הראשונה של TASK 05 היא שסנכרון השפתיים יפסיק להיות
    המניע הראשי של אנימציית הפנים. המדד: סך האנרגיה באזורי
    פה+לסת+שפתיים מול סך האנרגיה בכל עשרת אזורי הפנים, לאורך שוט
    שלם שבו הדמות גם מדברת וגם מרגישה.
    """
    from . import emotion as E                           # noqa: PLC0415
    if sit is None:
        sit = E.SCENES["עצב-מוסתר"]
    line = text if text is not None else sit.line
    act = SpeechActor(line, windows, voice_from(sit), seed=2.0)
    eye = E.eye_actor(sit, seed=2.0, speech=windows)
    m_tot = f_tot = 0.0
    m_only = 0.0
    n = int(shot_len * fps) + 1
    for i in range(n):
        t = i / fps
        ctl, mph = E.solve(sit, t, seed=2.0, eye=eye)
        r = act.raw(t)
        c2 = dict(ctl)
        m2 = dict(mph)
        for k, v in r["ctl"].items():
            c2[k] = c2.get(k, 0.0) + v
        for k, v in r["mph"].items():
            m2[k] = m2.get(k, 0.0) + v
        c2, m2 = acting.finalize(c2, m2)
        a = acting.region_activity(c2, m2)
        mouth = a["mouth"] + a["jaw"] + a["lips"] + a["tongue"]
        m_tot += mouth
        f_tot += sum(a.values())
        m_only += act.mouth_energy(t)
    return {"mouth_share": round(m_tot / max(1e-9, f_tot), 4),
            "mouth_energy": round(m_only / n, 4),
            "face_energy": round(f_tot / n, 4),
            "frames": n}


def voice_from(sit) -> Delivery:
    """`Situation` -> `Delivery`. **זה** החיבור שהופך דיאלוג להופעה.

    שימו לב מה נגזר: הרגש הנשלט (`feels`) קובע את אופן ההגייה, אבל
    כשיש הסתרה (`hides`) העוצמה יורדת והמתח עולה - אדם שמסתיר דבר
    מדבר שקט ובשפתיים לחוצות, וזו הנזילה שנשמעת בקול.
    """
    from . import emotion as E                           # noqa: PLC0415
    p = E.plan(sit)
    e = p.emotion
    loud = 0.52 + 0.46 * e.arousal
    tension = 0.0
    name = sit.feels
    if sit.hides:
        loud *= 0.78
        tension += 0.42
    loud *= 1.06 - 0.20 * e.control
    sm = 0.0
    if sit.hides == "amusement":
        sm = 0.18        # הצחוק שנעצר **נזלג** לתוך הדיבור
    return Delivery(loudness=max(0.18, min(1.3, loud)), emotion=name,
                    smile=sm, rate=max(0.6, min(1.4, 0.88 + 0.3 * e.arousal)),
                    tension=min(1.0, tension + 0.3 * (1.0 - e.valence) * 0.5))


def audit() -> dict:
    """כל ויזמה חייבת להצביע על בקרות וצורות שקיימות, וכל פונמה על
    ויזמה שקיימת. טבלה שנשברה בעריכה מתפוצצת כאן ולא בסרטון."""
    from . import controls, face                         # noqa: PLC0415
    bad_c = [k for v in VISEMES.values() for k in v.ctl
             if k not in controls.CONTROLS]
    bad_m = [k for v in VISEMES.values() for k in v.mph
             if k not in face.NAMES]
    bad_v = sorted({v for v in PH2VIS.values() if v not in VISEMES})
    bad_d = sorted({p for p in PH2VIS if p not in PH_DUR})
    if bad_c:
        raise ValueError(f"ויזמה מצביעה על בקרות שאינן קיימות: {bad_c}")
    if bad_m:
        raise ValueError(f"ויזמה מצביעה על צורות שאינן קיימות: {bad_m}")
    if bad_v:
        raise ValueError(f"פונמה מצביעה על ויזמה שאינה קיימת: {bad_v}")
    if bad_d:
        raise ValueError(f"פונמה בלי אורך: {bad_d}")
    unused = sorted(set(VISEMES) - set(PH2VIS.values()))
    if unused:
        raise ValueError(f"ויזמה שאין אליה פונמה: {unused}")
    return {"visemes": len(VISEMES), "phonemes": len(PH2VIS),
            "emotions": len(EMOTION_VOICE)}


def main(argv=None) -> int:
    import json
    import sys
    sys.stdout.reconfigure(encoding="utf-8")
    act = SpeechActor("זה לא היה ככה בכלל.", ((0.6, 2.4), (3.2, 5.0)),
                      Delivery(emotion="doubt", loudness=0.8), seed=1.0)
    print(json.dumps({"audit": audit(), "actor": act.describe(),
                      "features": features(), "drive": drive_report()},
                     ensure_ascii=False, indent=1))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
