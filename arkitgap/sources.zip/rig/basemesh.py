# -*- coding: utf-8 -*-
"""מחולל גאומטריה של דמות שלמה, שנבנית **סביב** השלד.

ההחלטה המרכזית, ובמה היא שונה ממה שהיה כאן קודם:
קודם הדמות הייתה תמונה שהונפשה (ואחר כך רשת סרוקה מתמונה, בלי שלד).
כאן הגאומטריה נוצרת מתוך שרשרות העצמות, ולכן:

* לכל קודקוד יש משקולות **מדויקות** - הן נקבעות בזמן הבנייה לפי המקום
  שלו בשרשרת, ולא ע"י ניחוש מרחק מקפסולה אחרי מעשה. זה מה שמחסל את
  המרפקים ההרוסים ואת ה"מריחה" של תנועה מאזור לאזור.
* הטופולוגיה שלנו: רשתות quad מסודרות (טבעות × פרוסות), בלי משולשים
  מנוונים ובלי קודקודים כפולים - מה שנדרש כדי שהחלקה ו-subdivision
  יעבדו אחר כך.
* הצורה קבועה לנצח. תזוזת עצם לא משנה מידה אחת של הזהות, ולכן בדיקת
  הקבלה (5 זוויות × 5 פוזות בלי סחיפת זהות) עוברת מעצם הבנייה ולא
  ב"נדמה לי שזה אותו אדם".

מערכת צירים: Y מעלה, Z קדימה, X שמאלה.
"""
from __future__ import annotations

import math

import numpy as np

from . import detail
from .skeleton import Skeleton

TAU = math.pi * 2


class MeshBuilder:
    def __init__(self):
        self.v: list[list[float]] = []
        self.uv: list[list[float]] = []
        self.w: list[dict] = []
        self.f: list[tuple[int, int, int]] = []
        self.groups: list[tuple[str, int, int]] = []   # (שם אזור, v0, v1)
        # תגית צבע לכל קודקוד. היא נקבעת **כאן**, במקום שבו הגאומטריה
        # יודעת מה היא בנתה, ולא משוחזרת אחר כך בצביעה מתנאים על
        # המיקום. כשהתנאי שוחזר שם הוא לא התאים בדיוק לתנאי שבנה את
        # הכובע, ובין השיער לגולגולת נפתח פס עור.
        self.tag: list[str | None] = []
        self._tag: str | None = None
        # **ערבול צבע רציף לקודקוד** (06/10). `tag` הוא הכרעה, וממנה
        # נגזרים גם החומר וגם הגאומטריה - ולכן היא חייבת להישאר
        # הכרעה. אבל הכרעה היא מדרגה, ומדרגה על גבול שעובר באלכסון
        # לרשת היא בדיוק מה שנראה בתקריב כמעבר משונן. מי שיודע שיש
        # לו גבול רך (קו השיער) כותב כאן 0..1, והצביעה פורשת שם את
        # המדרגה לרצועה. `None` = אין גבול רך, והצבע נקבע מהתגית
        # לבדה - כלומר כל מי שלא ביקש אינו משתנה באף ספרה.
        self.mix: list[float | None] = []

    # ---------------------------------------------------------------- בסיס
    def _vert(self, p, uv, w, tag=None, mix=None):
        self.v.append([float(p[0]), float(p[1]), float(p[2])])
        self.uv.append([float(uv[0]), float(uv[1])])
        s = sum(w.values())
        self.w.append({k: val / s for k, val in w.items() if val > 0} if s > 0 else dict(w))
        self.tag.append(tag if tag is not None else self._tag)
        self.mix.append(None if mix is None else float(mix))
        return len(self.v) - 1

    def quad(self, a, b, c, d):
        """מוסיף quad כשני משולשים, **ומדלג על משולש מנוון**.

        06/10: נמדדו 464 פאות בשטח אפס ברשת המוכנה (256 בראש, 112
        בגלגלי העין, 96 בכובע השיער). המקור אחד - קוטב של כדור UV
        (ראה `sphere`) שבו הטבעת כולה מתכנסת לנקודה אחת, ולכן אחד
        משני המשולשים של כל quad בטבעת הראשונה הוא קו ולא משטח.
        פאה כזו היא **נורמל אבוד**: `_normals` מחלק באורך אפס, הנורמל
        של הקודקוד נמשך לכלום, ובתקריב זה פס צל כהה בקודקוד הראש
        ומתחת לסנטר - בדיוק מה שנקרא "גושני".
        בדיקת אינדקסים ולא מרחק: היא מדויקת (אותו קודקוד בדיוק),
        עולה אפס, ואינה תלויה בסקאלה של הדמות.
        """
        if a != b and b != c and c != a:
            self.f.append((a, b, c))
        if a != c and c != d and d != a:
            self.f.append((a, c, d))

    # ------------------------------------------------------- כיפה רדיאלית
    def cap(self, center, normal, radius: float, ang: float,
            rings: int = 8, seg: int = 24, name="cap", weights=None,
            tagger=None, tag=None):
        """כיפה כדורית רדיאלית (טבעות סביב מרכז) בכיוון normal.

        למה רדיאלית ולא פיסה מכדור UV: גבולות הצבע של הקשתית הם
        **עיגולים**, וכאן הם יושבים בדיוק על טבעות הרשת. בכדור UV הם
        חותכים את הטבעות באלכסון, וזה מה שהפך את האישון לכתם מרוח.
        """
        v0 = len(self.v)
        weights = weights or {}
        c = np.asarray(center, float)
        nz = np.asarray(normal, float)
        nz = nz / np.linalg.norm(nz)
        tmp = np.array([0.0, 1.0, 0.0]) if abs(nz[1]) < 0.9 else np.array([1.0, 0.0, 0.0])
        ex = np.cross(tmp, nz)
        ex /= np.linalg.norm(ex)
        ey = np.cross(nz, ex)
        prev = self._tag
        self._tag = tag
        ctr = self._vert(c + nz * radius, (0.5, 0.5), weights,
                         tag=(tagger(0.0, 0.0) if tagger else None))
        grid = []
        for ri in range(1, rings + 1):
            rr = ri / rings
            a = ang * rr
            row = []
            for si in range(seg):
                th = si / seg * TAU
                d = nz * math.cos(a) + (ex * math.cos(th) + ey * math.sin(th)) * math.sin(a)
                p = c + d * radius
                row.append(self._vert(
                    p, (0.5 + 0.5 * rr * math.cos(th),
                        0.5 + 0.5 * rr * math.sin(th)), weights,
                    tag=(tagger(rr, th) if tagger else None)))
            grid.append(row)
        for si in range(seg):
            s2 = (si + 1) % seg
            self.f.append((ctr, grid[0][si], grid[0][s2]))
        for ri in range(rings - 1):
            for si in range(seg):
                s2 = (si + 1) % seg
                self.quad(grid[ri][si], grid[ri + 1][si],
                          grid[ri + 1][s2], grid[ri][s2])
        self._tag = prev
        self.groups.append((name, v0, len(self.v)))
        return grid

    # ---------------------------------------------------------------- צינור
    def tube(self, rings, seg: int = 16, cap_start=True, cap_end=True,
             name="tube", twist_axis=(1.0, 0.0, 0.0), u0=0.0, u1=1.0,
             tag=None, frame=None):
        """rings = [(center, rx, rz, weights)] לאורך ציר הצינור, או
        [(center, rx, rz, weights, n)] כשרוצים חתך סופר-אליפסה.

        twist_axis הוא כיוון הציר ה"ארוך" המקומי; החתך נבנה בשני הצירים
        האנכיים לו. כך אותו קוד בונה גם רגל (ציר Y) וגם זרוע (ציר X).

        `frame=(e_rx, e_rz)` כופה מסגרת מפורשת, ואז rx ו-rz **באמת**
        שולטים על הצירים שבשמם. בלעדיה המסגרת נגזרת מ-`twist_axis`
        דרך מכפלה וקטורית עם ציר עזר - ולציר Y זה יוצא e1=-Z ו-e2=-X,
        כלומר `rx` שולט על **העומק** ו-`rz` על הרוחב. כל פלג הגוף
        נבנה כך, ולכן הדמות יצאה עמוקה פי 1.55 מרוחבה (נמדד 05/10:
        רוחב כתפיים 0.195 מ' מול עומק חזה 0.302 מ'). חובה לשמור על
        det>0 בהחלפה, אחרת כיווניות הפאות מתהפכת והרשת נראית מבפנים.

        `n` הוא אקספוננט הסופר-אליפסה: `|x/rx|^n + |z/rz|^n = 1`.
        n=2 היא האליפסה הרגילה **באופן זהה מספרית** (החישוב מצטמצם
        אליה ואין לה ענף נפרד), ולכן טבעת שלא ביקשה צורה אינה משתנה
        באף ספרה.
        """
        v0 = len(self.v)
        prev_tag = self._tag
        self._tag = tag
        if frame is not None:
            e1 = np.asarray(frame[0], float)
            e2 = np.asarray(frame[1], float)
            e1 = e1 / np.linalg.norm(e1)
            e2 = e2 / np.linalg.norm(e2)
        else:
            ax = np.asarray(twist_axis, float)
            ax /= np.linalg.norm(ax)
            tmp = np.array([0.0, 1.0, 0.0]) if abs(ax[1]) < 0.9 else np.array([1.0, 0.0, 0.0])
            e1 = np.cross(ax, tmp)
            e1 /= np.linalg.norm(e1)
            e2 = np.cross(ax, e1)
            e2 /= np.linalg.norm(e2)
        grid = []
        n = len(rings)
        for ri, ring in enumerate(rings):
            c, rx, rz, w = ring[0], ring[1], ring[2], ring[3]
            ex = 2.0 / float(ring[4]) if len(ring) > 4 else 1.0
            c = np.asarray(c, float)
            row = []
            vv = ri / max(1, n - 1)
            for si in range(seg):
                a = si / seg * TAU
                ca, sa = math.cos(a), math.sin(a)
                if abs(ex - 1.0) > 1e-12:
                    ca = math.copysign(abs(ca) ** ex, ca)
                    sa = math.copysign(abs(sa) ** ex, sa)
                p = c + e1 * (ca * rx) + e2 * (sa * rz)
                row.append(self._vert(p, (u0 + (u1 - u0) * si / seg, vv), w))
            grid.append(row)
        for ri in range(n - 1):
            for si in range(seg):
                s2 = (si + 1) % seg
                self.quad(grid[ri][si], grid[ri][s2],
                          grid[ri + 1][s2], grid[ri + 1][si])
        for do, idx, flip in ((cap_start, 0, True), (cap_end, n - 1, False)):
            if not do:
                continue
            c, rx, rz, w = (rings[idx][0], rings[idx][1],
                            rings[idx][2], rings[idx][3])
            ctr = self._vert(np.asarray(c, float), (0.5, 0.0 if idx == 0 else 1.0), w)
            for si in range(seg):
                s2 = (si + 1) % seg
                if flip:
                    self.f.append((ctr, grid[idx][s2], grid[idx][si]))
                else:
                    self.f.append((ctr, grid[idx][si], grid[idx][s2]))
        self._tag = prev_tag
        self.groups.append((name, v0, len(self.v)))
        return grid

    # ---------------------------------------------------------------- כדור
    def sphere(self, center, radius, seg=24, rings=16, name="sphere",
               weights=None, scale=(1.0, 1.0, 1.0), shaper=None,
               tag=None, phi_of=None, theta_of=None):
        """phi_of/theta_of ממפים את חלוקת הטבעות והפרוסות.

        בלי המיפוי הזה כדור UV מבזבז את רוב הקודקודים על קודקוד
        הגולגולת ועל הקוטב התחתון, ודווקא בפנים - האזור היחיד שמסתכלים
        עליו בתקריב - הצפיפות היא הנמוכה ביותר.
        """
        v0 = len(self.v)
        prev_tag = self._tag
        self._tag = tag
        weights = weights or {}
        center = np.asarray(center, float)
        sx, sy, sz = scale
        grid = []
        for ri in range(rings + 1):
            fr = ri / rings
            phi = (phi_of(fr) if phi_of else fr) * math.pi
            # **קוטב = קודקוד אחד, לא טבעת של seg עותקים.** ב-phi=0
            # (וב-phi=pi) הכיוון הוא (0,±1,0) לכל th, ולכן הגרסה
            # הקודמת יצרה 128 קודקודים **באותה נקודה בדיוק** בכל
            # קוטב: 254 קודקודים כפולים לראש, 256 פאות בשטח אפס,
            # ושכנות שבורה שגם מנעה כל החלקה אמיתית (קודקוד כפול
            # אין לו דרגה). עכשיו נבנה קודקוד אחד והאינדקס שלו
            # משוכפל לרוחב השורה - כך מבנה ה-grid שכל הקוראים
            # מסתמכים עליו (`grid[ri][si]`) נשמר בדיוק, ו-`quad`
            # מדלגת על המשולש המנוון שנוצר ממנו.
            # UV: הקוטב מקבל נקודת UV אחת. בטוח כאן, כי הצביעה
            # היא לכל קודקוד (`mb.tag`/`mb.mix`/`color`) ואין
            # טקסטורה שתימרח. משקולות ותגית: ה-shaper נקרא פעם
            # אחת, בנקודה האמיתית - זה החישוב הנכון ולא ממוצע.
            polar = abs(math.sin(phi)) < 1e-12
            row = []
            for si in range(seg):
                if polar and row:
                    row.append(row[0])
                    continue
                fs = si / seg
                th = (theta_of(fs) if theta_of else fs) * TAU
                d = np.array([math.sin(phi) * math.cos(th),
                              math.cos(phi),
                              math.sin(phi) * math.sin(th)])
                p = center + d * radius * np.array([sx, sy, sz])
                w = dict(weights)
                vtag = None
                vmix = None
                if shaper is not None:
                    res = shaper(p, d, w, fs, fr)
                    # shaper יכול להחזיר 2, 3 או 4 ערכים. הארוך הוא
                    # ערבול הצבע הרציף (ראה `MeshBuilder.mix`), והוא
                    # אופציונלי בכוונה: כל קורא קיים ממשיך לעבוד.
                    if len(res) == 4:
                        p, w, vtag, vmix = res
                    elif len(res) == 3:
                        p, w, vtag = res
                    else:
                        p, w = res
                row.append(self._vert(p, (fs, 1.0 - fr), w, tag=vtag,
                                      mix=vmix))
            grid.append(row)
        for ri in range(rings):
            for si in range(seg):
                s2 = (si + 1) % seg
                self.quad(grid[ri][si], grid[ri][s2],
                          grid[ri + 1][s2], grid[ri + 1][si])
        self._tag = prev_tag
        self.groups.append((name, v0, len(self.v)))
        return grid


# -------------------------------------------------------------------- עזר


def _blend(chain, t):
    """משקולות על שרשרת עצמות לפי מקום נורמלי t ב-[0,1].

    הפונקציה היא מה שמייצר מפרק נקי: בתוך פרק העצם המשקולת היא 1,
    וסביב המפרק יש מעבר חלק ברוחב 30% של הפרק. מעבר חד קורע את העור,
    מעבר רחב מדי מזיז את הבטן כשמכופפים אצבע.
    """
    n = len(chain) - 1
    x = max(0.0, min(1.0, t)) * n
    i = min(n - 1, int(math.floor(x)))
    f = x - i
    # החלקה S באזור המפרק בלבד
    edge = 0.30
    if f < edge:
        k = 0.5 * (f / edge)
    elif f > 1 - edge:
        k = 0.5 + 0.5 * ((f - (1 - edge)) / edge)
    else:
        k = 0.5
    return {chain[i]: 1.0 - k, chain[i + 1]: k}


def _lerp(a, b, t):
    a = np.asarray(a, float)
    b = np.asarray(b, float)
    return a + (b - a) * t


def _smoothstep(e0, e1, x):
    t = max(0.0, min(1.0, (x - e0) / (e1 - e0 + 1e-12)))
    return t * t * (3 - 2 * t)


def _densify(prof, mul: int):
    """מצפיף פרופיל (t, rx, rz[, n, dz]) בגורם שלם, לינארית.

    למה: הצללית של זרוע בת 5 טבעות היא קו שבור, וזה נראה כמו צינור
    משופע דווקא בתקריב. הצפפה כאן לא משנה שום מידה - נקודות הבקרה
    נשארות בדיוק באותו מקום - ולכן הזהות לא זזה.

    **כל העמודות מתאינטרפלטות, ולא רק שלוש.** אקספוננט החתך
    (סופר-אליפסה) וההיסט הקדמי הם עמודות בפרופיל בדיוק מהסיבה הזו:
    היועץ החיצוני (Command A, 05/10) הזהיר שקפיצת אקספוננט בין שתי
    טבעות סמוכות תיראה כקמט בהצללה. כשהוא עובר כאן, המעבר מכתף
    מרובעת לחזה עגול הוא מדורג על פני כל הטבעות שביניהן.
    """
    if mul <= 1 or len(prof) < 2:
        return list(prof)
    out = []
    for i in range(len(prof) - 1):
        a, b = prof[i], prof[i + 1]
        m = min(len(a), len(b))
        for j in range(mul):
            u = j / mul
            out.append(tuple(a[c] + (b[c] - a[c]) * u for c in range(m)))
    out.append(tuple(prof[-1]))
    return out


# -------------------------------------------------------------------- הבנייה


def build(skel: Skeleton, shape: dict | None = None, quality: str = "full"):
    """בונה את הדמות כולה. מחזיר (MeshBuilder, meta)."""
    shape = shape or {}
    P = {b.name: np.asarray(b.rest, float) for b in skel.bones}
    k = skel.height / 1.70
    # **צפיפות ההיקף היא המקום שבו "גליל" הופך ל"מנסרה", והיא
    # נמדדת ולא מוערכת (06/10).** הזווית הדיהדרלית בין שתי פאות
    # סמוכות על היקף צינור היא בדיוק 360/seg, ולכן:
    #     seg=8  -> 45.0°   seg=16 -> 22.5°   seg=24 -> 15.0°
    #     seg=32 -> 11.25°
    # נמדד על `zippy` בערכים הקודמים (24/16/8): זרוע p99 93.06° עם
    # **33.9% מהצלעות מעל 20°**, רגל 33.3%, אצבע 38.1%, כף יד 27.4%.
    # כלומר כל צלע אורכית בזרוע חרגה מעל הסף, כי 22.5 > 20 - האיבר
    # היה מנסרה בת 16 פאות ולא גליל. זה, ולא שום פרמטר של קמירות,
    # מה שהעין קוראת כ"מכני".
    # והחלקה **אינה** פותרת את זה: הזווית של מצולע משוכלל היא תכונה
    # של הטופולוגיה, ומשטח Catmull-Clark שמתכנס על מצולע סימטרי
    # משאיר אותה. לכן התיקון הוא בצפיפות, במקום שבו היא נקבעת.
    seg_body = {"full": 32, "fast": 12}[quality]
    seg_limb = {"full": 32, "fast": 8}[quality]
    # 8 פרוסות = 45° לפאה, המצולע הגרוע ברשת כולה. 20 נותן 18°,
    # מתחת לסף, ועדיין זול: אצבע ברדיוס 11 מ"מ היא 3.5 מ"מ לפאה.
    seg_fing = {"full": 20, "fast": 6}[quality]
    # צפיפות הראש: 32x24 נתנה 800 קודקודים לכל הראש, כלומר קודקוד לכל
    # 25 פיקסלים בתקריב - ולכן כל תו פנים יצא מרוח. 128x112 נותן
    # כ-14 אלף, ועם מיפוי הצפיפות (ראה _head) רובם נופלים על הפנים.
    head_seg = {"full": 128, "fast": 24}[quality]
    head_rings = {"full": 112, "fast": 18}[quality]

    girth = float(shape.get("girth", 1.0))
    dm = {"full": 3, "fast": 1}[quality]        # הצפפת פרופילי הגוף
    mb = MeshBuilder()

    # **TASK 10 · דימורפיזם מיני.** מידות פלג הגוף והגפיים אינן עוד
    # טבלה אחת לכל הדמויות אלא נגזרות מ-`dimorph.Dimorph`. הדגם
    # הניטרלי שומר על מידות דומות לקודם, ולכן דמות שלא ביקשה מבנה
    # אינה מקבלת צללית חדשה.
    from . import dimorph as DM                        # noqa: PLC0415
    bod = DM.get(shape.get("dimorph"))
    mb.dimorph = bod
    # **TASK 11 · הבגד.** `facestyle.garment` מחזיר מכפילי טבעת, ולכן
    # "בגד רך וזורם" מול "בגד בלוקי" הוא שינוי **צללית** ולא צבע.
    # `cloth="plain"` מחזיר (1,1,0) ואינו נוגע באף דמות קיימת.
    from . import facestyle as FS                       # noqa: PLC0415
    fst = FS.get(shape.get("face"))
    mb.facestyle = fst

    # ---------------------------------------------------- פלג גוף
    spine = ["hips", "spine_01", "spine_02", "chest", "neck"]
    # **TASK 18 · עמוד השדרה הוא ספליין, לא פוליליין.** נמדד 06/10
    # שכל השבר בשרשרת הגו יושב ב**נקודה אחת** - מפרק הצוואר -
    # ושווה שם 5.622°, בעוד כל שאר הצוואר מדד 0.000° בדיוק (כלומר
    # צינור ישר מושלם + פינה). הסיבה גאומטרית ולא אסתטית: המפרקים
    # hips..chest יושבים כולם על x=z=0, ורק `neck` חורג ל-z=+5.4 מ"מ
    # ואז `head` חוזר ל-0 - קו שבור בן שתי צלעות.
    # לכן מרכזי הטבעות נדגמים מכאן על ספליין Catmull-Rom צנטריפטלי
    # שעובר דרך כל המפרקים. שתי תוצאות נלוות שחשוב להבין:
    #   * בקטעים hips..spine_02 אין שום שינוי מספרי, כי שלוש נקודות
    #     קולינאריות עם שכן קולינארי נותנות בדיוק את הקו - ולכן
    #     אף דמות קיימת לא משנה צללית בגו ובמותן.
    #   * הקטע spine_02->chest כן מקבל הסטה זעירה ב-Z (שבריר מ"מ),
    #     כי המשיק ב-`chest` נגזר מ-`neck`. זה **בדיוק** המדף
    #     הטרפזיוס שעקומת ה-S צריכה, והוא נוסף בחינם.
    # הנקודות הווירטואליות בקצוות (`_pad`) נדרשות כי Catmull-Rom
    # מגדיר רק את הקטעים הפנימיים; הן השתקפות של השכן ולכן אינן
    # מוסיפות עקמומיות מלאכותית בקצה.
    from . import organic as ORG                           # noqa: PLC0415
    _sp = [P[n] for n in spine]
    _sp = ([_sp[0] * 2 - _sp[1]] + _sp
           + [P["head"], P["head"] + (P["head"] - P["neck"]) * 1.25])
    # u על הספליין: u=0 ב-hips, u=len(spine)-1 ב-neck. מעל זה ממשיכים
    # באותה פרמטריזציה של הנוסחה הקודמת (כפל 3.2 על neck->head), כדי
    # שטבעת ב-t=1.34 תגיע בדיוק לאותו גובה כמו קודם.
    _u_neck = float(len(spine) - 1)

    def _spine_center(t: float) -> np.ndarray:
        if t < 0.0:
            return P["hips"] + (P["hips"] - P["spine_01"]) * (-t)
        if t <= 1.0:
            return ORG.catmull_rom(_sp, _u_neck * t)
        return ORG.catmull_rom(_sp, _u_neck + (t - 1.0) * 3.2)

    rings = []
    for row in _densify(DM.torso_profile(bod), dm):
        t, rx, rz = row[0], row[1], row[2]
        nexp = row[3] if len(row) > 3 else 2.0
        dz = row[4] if len(row) > 4 else 0.0
        # **ההיסטוריה שמורה כאן בכוונה.** הניסיון הראשון (06/10) החליף
        # את הקו הישר `P["neck"] + (P["head"]-P["neck"])*(t-1)*3.2`
        # בעקומת Hermite עם משיקים מנוחשים, ומדד **גרוע יותר**:
        # 8.44° לזיגי ו-9.01° לתמר מול 5.62° בקו הישר. המסקנה שנרשמה
        # אז ("זה מיעוט טבעות ולא אינטרפולציה") הייתה חצי נכונה -
        # שני הדברים נדרשים *יחד*, ואף אחד מהם לבד לא מספיק:
        #   * 2 טבעות + עקומה  = הסטת שתי נקודות, מדד 8.44°.
        #   * 8 טבעות + קו ישר = צינור חלק עם פינה, השבר נשאר 5.62°.
        #   * 8 טבעות + ספליין = ראה `_spine_center` ואת השער ב-
        #     `test_rig` - השבר יורד מתחת למעלה אחת.
        c = _spine_center(t)
        # ההיסט הקדמי מזיז את **מרכז** הטבעת ולא את רדיוסיה. זה מה
        # שמייצר נפח א-סימטרי (חזה שבולט קדימה, אגן שבולט אחורה) בלי
        # לשבור את צורת הסופר-אליפסה ובלי להרחיב את הצללית מלפנים.
        c = np.asarray(c, float) + np.array([0.0, 0.0, dz * k * girth])
        gx, gz, gn = FS.garment(fst, t)
        rings.append((c, rx * k * girth * gx, rz * k * girth * gz,
                      _blend(spine, t), nexp + gn))
    # המסגרת מפורשת: rx הוא X (רוחב) ו-rz הוא Z (עומק). ראה `tube`.
    torso_grid = mb.tube(rings, seg_body, True, False, "torso",
                         (0.0, 1.0, 0.0),
                         frame=((1.0, 0.0, 0.0), (0.0, 0.0, -1.0)))
    torso_rings = list(rings)

    # ---------------------------------------------------- זרועות
    for side, s in (("L", 1.0), ("R", -1.0)):
        chain = [f"clavicle_{side}", f"upperarm_{side}",
                 f"forearm_{side}", f"hand_{side}"]
        rings = []
        for t, rx, rz in _densify(DM.arm_profile(bod), dm):
            x = t * (len(chain) - 1)
            i = min(len(chain) - 2, int(x))
            c = _lerp(P[chain[i]], P[chain[i + 1]], x - i)
            rings.append((c, rx * k, rz * k, _blend(chain, t)))
        mb.tube(rings, seg_limb, True, False, f"arm_{side}", (s, 0.0, 0.0))

        # כף יד: קובייה מעוגלת
        hp = P[f"hand_{side}"]
        palm = [(0.00, 0.030, 0.034), (0.50, 0.040, 0.030), (1.00, 0.038, 0.024)]
        rings = []
        for t, rx, rz in _densify(palm, dm):
            c = hp + np.array([s * 0.094 * k * t, 0.0, 0.0])
            rings.append((c, rx * k, rz * k, {f"hand_{side}": 1.0},
                          2.0 + fst.limb_square))
        mb.tube(rings, seg_limb, True, True, f"palm_{side}", (s, 0.0, 0.0))

        # אצבעות: שלושה פרקים, צינור לכל אצבע
        for fname in ("thumb", "index", "middle", "ring", "pinky"):
            ch = [f"{fname}_{j:02d}_{side}" for j in (1, 2, 3)] + \
                 [f"{fname}_tip_{side}"]
            r0 = 0.0115 if fname != "thumb" else 0.0135
            prof = [(0.0, r0, r0), (0.34, r0 * 0.92, r0 * 0.92),
                    (0.68, r0 * 0.80, r0 * 0.80), (1.0, r0 * 0.62, r0 * 0.62)]
            rings = []
            for t, rx, rz in _densify(prof, min(2, dm)):
                x = t * (len(ch) - 1)
                i = min(len(ch) - 2, int(x))
                c = _lerp(P[ch[i]], P[ch[i + 1]], x - i)
                rings.append((c, rx * k, rz * k, _blend(ch, t)))
            mb.tube(rings, seg_fing, True, True, f"{fname}_{side}", (s, 0.0, 0.0))

    # ---------------------------------------------------- רגליים
    for side, s in (("L", 1.0), ("R", -1.0)):
        chain = [f"thigh_{side}", f"shin_{side}", f"foot_{side}"]
        rings = []
        # **TASK 20 · שוקת הירך.** הטבעות שמעל מפרק `thigh`, שמעבירות
        # את חתך הירך אל חתך האגן על `smoothstep` - ולא "גליל שנדחף
        # לתוך מותניים שטוחות". `hip_blend=0` מחזיר רשימה ריקה,
        # ולכן אף דמות קיימת אינה מקבלת טבעת נוספת.
        # המשקולת עולה אל `hips` כלפי מעלה (`LOFT_BIND`): בלעדיה כל
        # מסת הירך הייתה קשיחה לעצם הירך, כלומר גוש שמתנתק מהאגן
        # בכל צעד - וזה היה **נראה בתנועה** ולא במדידה סטטית.
        tj = P[f"thigh_{side}"]
        # רוחב הטורסו בגובה ראש השוקת, מתוך `torso_rings` עצמן.
        # מקור אמת אחד: כל כיול של האגן, של הבגד או של המותן מגיע
        # לכאן מאליו, ואי אפשר שייפתח פער בין שני חישובים.
        _ly = P[f"thigh_{side}"][1] + DM.LOFT_RISE * k
        _wt, _mt = None, 0.0
        for (_ca, _ra, *_), (_cb, _rb, *_) in zip(torso_rings,
                                                  torso_rings[1:]):
            if float(_ca[1]) <= _ly <= float(_cb[1]):
                _dy = max(1e-12, float(_cb[1]) - float(_ca[1]))
                _u = (_ly - float(_ca[1])) / _dy
                _wt = _ra + (_rb - _ra) * _u
                # שיפוע הטורסו שם (מטר רוחב למטר גובה). הוא נמסר
                # לשוקת כמשיק הקצה, ולכן המשטחים נפגשים באותה
                # זווית ולא רק באותה נקודה.
                _mt = (_rb - _ra) / _dy
                break
        for dy, cx, rx, rz, bind in reversed(
                DM.hip_loft(bod, girth,
                            FS.garment(fst, (DM.LOFT_RISE - DM.HIP_DROP)
                                       / DM.HIP_SPAN)[0],
                            None if _wt is None else _wt / max(1e-9, k),
                            _mt)):
            c = np.array([s * cx * k * girth, tj[1] + dy * k, tj[2]])
            rings.append((c, rx * k * girth, rz * k * girth,
                          {f"thigh_{side}": 1.0 - bind, "hips": bind}))
        for t, rx, rz in _densify(DM.leg_profile(bod), dm):
            x = t * (len(chain) - 1)
            i = min(len(chain) - 2, int(x))
            c = _lerp(P[chain[i]], P[chain[i + 1]], x - i)
            rings.append((c, rx * k * girth, rz * k * girth, _blend(chain, t)))
        mb.tube(rings, seg_limb, True, False, f"leg_{side}", (0.0, 1.0, 0.0))
        # **TASK 21 · קו המותניים כגובה אחד, ולא כגבול של קבוצת רשת.**
        # עד כאן `pipeline.bake_colors` צבע את **כל** קבוצת `torso`
        # כחולצה ואת **כל** קבוצת `leg_` כמכנס. אחרי שהשוקת העלתה את
        # ראש הרגל אל מעל מפרק הירך, שני הגבולות האלה נחתכים: הכיפה
        # של האגן (torso) יורדת עד המפשעה ונצבעת חולצה, בעוד שתי
        # השוקתות (leg) עולות לצידה ונצבעות מכנס. ברנדור זה נראה
        # כטריז אפור שיורד בין שתי מסות כהות - כלומר בדיוק אותה
        # קריאה של "חלקים מודבקים" שהגאומטריה באה לבטל. הגובה הזה
        # הוא נקודת המפגש של שני המשטחים, ולכן תפר הצבע עליו הוא
        # קו אופקי יחיד שחופף לתפר הגאומטרי.
        #
        # **הגובה הוא מפרק הירך עצמו, ולא ראש השוקת.** ראש השוקת
        # יושב ב-t≈0.43 של עמוד השדרה, כלומר בדיוק בראש התרחבות
        # שולי החולצה (`facestyle.garment`, t=0.46->0.02). תפר שם
        # צובע את כל ההתרחבות הזאת כמכנס, וברנדור היא נראתה כחצאית
        # לבנה שבולטת מעל הירכיים עם צל מתחתיה. במפרק הירך
        # ההתרחבות נשארת חולצה (שוליים טבעיים של חולצה בגובה האגן),
        # וכיפת האגן שמתחתיה - שהיא שגרמה לטריז - נצבעת מכנס.
        if float(getattr(bod, "hip_blend", 0.0) or 0.0) > 1e-9:
            mb.waist_y = float(tj[1])
        # כף רגל
        fch = [f"foot_{side}", f"toe_{side}", f"toe_tip_{side}"]
        prof = [(0.00, 0.034, 0.030), (0.45, 0.038, 0.028), (1.00, 0.024, 0.016)]
        rings = []
        for t, rx, rz in _densify(prof, dm):
            x = t * (len(fch) - 1)
            i = min(len(fch) - 2, int(x))
            c = _lerp(P[fch[i]], P[fch[i + 1]], x - i)
            rings.append((c, rx * k, rz * k, _blend(fch, t),
                          2.0 + fst.limb_square))
        mb.tube(rings, seg_limb, True, True, f"foot_{side}", (0.0, 0.0, 1.0))

    # ---------------------------------------------------- ראש
    _head(mb, skel, P, k, head_seg, head_rings, shape)
    # אותו תיאור גולגולת בדיוק שבנה את הפנים, נשמר על ה-MeshBuilder כדי
    # ש-`face.build` יחשב את צורות הפנים **באותן יחידות**. בנייה חוזרת
    # היא חישוב סקלרי בלבד ולכן זולה, אבל היא חייבת לקבל את אותו
    # shape - אחרת צורות הפנים יישבו על ראש בגודל אחר.
    mb.head = detail.Head(P, k, shape)

    # אביזר: משקפיים, רק אם השלד נבנה איתם.
    if "glasses" in skel.by_name:
        detail.add_glasses(mb, mb.head, 20 if quality == "full" else 10)

    # TASK 08: העברת חלק מהמשקולות לעצמות הרכות. **אחרי** כל
    # הגאומטריה ולפני to_arrays - משקולת שלא הועברה כאן פירושה
    # עצם רכה שלא מזיזה אף קודקוד, כלומר תנועה משנית בלתי נראית.
    from . import secondary                                # noqa: PLC0415
    # TASK 11: ה-follow-through של השיער הוא **כמה מהמשקולת** עוברת
    # לעצמות הרכות. תלתל קפיצי נגרר הרבה, שיער קשיח כמעט לא - וזה
    # נמדד על הרשת (`facestyle.measure` · `hair_follow`).
    soft = secondary.bind(mb, skel, hair_follow=fst.hair_follow)

    # ------------------------------------------------ משטח אורגני
    # **כאן, ולא ב-`to_arrays`.** `face.build` מחשב את צורות הפנים
    # מתוך `mb.v`, ו-`appeal.Char.morphs` בונה את הרשת מחדש ומשווה -
    # כלומר החלקה שתיעשה אחרי זה הייתה מייצרת מורפים שיושבים על
    # גאומטריה אחרת מזו שבקובץ, וכל תזוזת פנים הייתה מקפיצה את
    # הקודקוד חזרה אל הצורה הלא מוחלקת.
    smoothed = _organic_pass(mb)

    # **TASK 20 · הקונטור הנשי הדו-אוני, ו*אחרי* ההחלקה.**
    # `bust_lobe=0` מחזיר 0 ואינו נוגע באף קודקוד, ולכן כל דמות
    # שלא ביקשה אינה משתנה באף ספרה.
    #
    # הסדר כאן הוא **באג שנמדד ותוקן**, ולא העדפה. בגרסה הראשונה
    # הבליטה הוחלה לפני `_organic_pass`, מתוך הנחה שההחלקה "תרכך
    # את האונה". מה שקרה בפועל: עמק הסטרנום הוא פיצ'ר ברוחב
    # σ=25 מ"מ, והמרווח בין קודקודים בחזית החזה הוא 48 מ"מ באיכות
    # "fast" - כלומר העמק הוא **קודקוד בודד**, והעמדה הגבולית של
    # Catmull-Clark (שהיא ממוצע משוקלל של השכנים) מחזירה אותו כמעט
    # במלואו. נמדד על שיר: המקסימום נשאר ב-x=0 והאונה יצאה 1.7
    # מ"מ **מתחת** למרכז, במקום 8.5 מ"מ מעליו שהחישוב נתן.
    # שדה גאוסיאני הוא C∞ מעצם טבעו ואינו זקוק להחלקה; הפעלתו
    # אחריה אינה מוסיפה שום קצה, והיא מה שמשמר את הצורה.
    mb.bust_moved = DM.apply_bust(
        mb, torso_grid, torso_rings, bod, seg_body, k, girth,
        float(_spine_center(DM.BUST_T)[1]))

    meta = {
        "vertices": len(mb.v),
        "triangles": len(mb.f),
        "organic": smoothed,
        "bones": len(skel.bones),
        "groups": [g[0] for g in mb.groups],
        "quality": quality,
        "secondary": soft,
    }
    return mb, meta


def _organic_pass(mb: MeshBuilder) -> dict:
    """מצמיד את הרשת למשטח Catmull-Clark הגבולי שלה, ומסיר פאות אבודות.

    שני שלבים, ושניהם נמדדו כנחוצים ב-06/10:

    1. **הסרת פאה שאין לה נורמל.** `_normals` מחלקת באורך המכפלה
       הווקטורית; פאה בשטח אפס מחזירה 0/0, הנורמל של כל קודקוד שנוגע
       בה נמשך לכלום, ובתקריב זה פס צל כהה. 464 כאלה נמדדו לפני
       התיקון בקוטבי ה-`sphere`; מה שנשאר אחריו הוא פאה **קולינארית**
       (שלושה קודקודים שונים על קו ישר), במקום שבו רדיוס טבעת קורס
       לאפס. אינדקסים שונים, ולכן `quad` לא תופסת אותה - צריך מדידה
       גיאומטרית, וכאן המקום היחיד שבה כל הרשת כבר בנויה.
    2. **העמדה גבולית של Catmull-Clark** (ראה `organic`). היא זו
       שמסירה את הקצה שנשאר *אחרי* שהצפיפות תוקנה: נמדד שהיא מורידה
       את ה-p99 של הטורסו מ-60.4° ל-39.6° ושל הזרוע מ-93.1° ל-82.6°,
       בשינוי צללית של פחות ממילימטר (גובה 1.4782 -> 1.4774 מ').
       קו השפתיים, הנחיר וקו השיער נשמרים חדים כי הם `crease`.
    """
    from . import organic as OG                           # noqa: PLC0415

    pos = np.asarray(mb.v, float)
    tri = np.asarray(mb.f, np.int64).reshape(-1, 3)
    n = np.cross(pos[tri[:, 1]] - pos[tri[:, 0]],
                 pos[tri[:, 2]] - pos[tri[:, 0]])
    live = np.linalg.norm(n, axis=1) > 1e-14
    dropped = int((~live).sum())
    if dropped:
        mb.f = [tuple(int(x) for x in t) for t in tri[live]]

    rigid = np.zeros(len(pos), bool)
    for name, v0, v1 in mb.groups:
        if any(name.startswith(p) for p in OG.RIGID_GROUPS):
            rigid[v0:v1] = True
    tag = np.asarray([t if t else "" for t in mb.tag], dtype=object).astype(str)
    idx = np.asarray(mb.f, np.int64).reshape(-1)
    before = OG.smoothness(pos, idx)
    out = OG.smooth(pos, idx, tag=tag, rigid=rigid, passes=1)
    for i in range(len(mb.v)):
        mb.v[i] = [float(out[i, 0]), float(out[i, 1]), float(out[i, 2])]
    after = OG.smoothness(out, idx)
    return {"degenerate_dropped": dropped,
            "p99_before": before["p99"], "p99_after": after["p99"],
            "over20_before": before["over20"], "over20_after": after["over20"],
            "moved_mm": round(float(np.abs(out - pos).max() * 1000.0), 3)}


def _head(mb: MeshBuilder, skel: Skeleton, P, k, seg, rings, shape):
    """הראש: כדור שעובר עיצוב אנטומי, ועליו נתפרים אזורי הריג של הפנים,
    ואחריו נבנים תווי הפנים והשיער כגאומטריה נפרדת (ראה detail.py).

    למה לא פשוט כדור עם משקולת 1 ל-head: אז הלסת לא תפתח כלום, העפעף
    לא ייסגר והגבה לא תזוז - בדיוק המצב שהיה כאן קודם, שבו "פתיחת פה"
    הייתה הזזת קודקודים בכוח בלי עצם.

    למה תווי הפנים אינם אזורי צבע: צבע קודקוד מתפרש לינארית, ולכן גבול
    צבע נמרח על כל המרווח בין שני קודקודים. בתקריב זה 25 פיקסלים של
    טשטוש על כל גבול, בכל רזולוציית רנדור. קצה גאומטרי חד תמיד.
    """
    H = detail.Head(P, k, shape)
    # מעבר ליחידת הראש (ראה detail.Head). שווה ל-k הישן בדיוק כשרוחב
    # הראש הוא 1.0, ולכן זה אינו משנה דבר בדמות התקן.
    k = H.k
    hc, R = H.hc, H.R
    # **מ-`H.eye_center` ולא מ-`P` ישירות** (TASK 16). זו הנקודה
    # היחידה שיודעת על `FaceStyle.eye_in`, וקריאה ישירה מ-`P` כאן
    # הייתה מזיזה את גלגל העין פנימה ומשאירה את הארובה ואת רצועת
    # הארובה הרציפה במקום - באג שאין לו שגיאה, רק עין מחוץ לבור.
    # ההיסט ב-Z שהפונקציה מוסיפה אינו משנה דבר כאן: כל השימושים
    # למטה הם ב-`[:2]` או ב-`[0]`/`[1]` בלבד.
    eyeL, eyeR = H.eye_center("L"), H.eye_center("R")

    # מיפוי הצפיפות: 70% מהטבעות ו-64% מהפרוסות נופלים על הפנים, ולא
    # על קודקוד הגולגולת (שמכוסה בשיער) ועל העורף (שלא מצולם בתקריב).
    phi_of = detail._pw([(0.0, 0.0), (0.12, 0.26), (0.86, 0.82), (1.0, 1.0)])
    theta_of = detail._pw([(0.0, 0.0), (0.18, 0.055), (0.82, 0.445), (1.0, 1.0)])

    # TASK 11: שפת הצורות של הפנים. `plain` זהה מספרית למה שהיה.
    fs = H.fs
    styled = fs.key != "plain"
    mouth_y = -0.30                      # ביחידות R סביב מרכז הראש
    mouth_w = 0.29 * fs.mouth_w
    # רצועת הארובה הרציפה (`socket_merge`): ארובה אחת רחבה ששתי
    # העיניים יושבות בה, כמו בדמות פיקסאר - ולא שני בורות נפרדים.
    eye_y = 0.5 * float(eyeL[1] + eyeR[1])
    eye_x = abs(float(eyeL[0] - hc[0]))

    # TASK 10: חידוד הלסת והסנטר לפי המבנה. 1.0 = הערכים שהיו.
    from . import dimorph as DM                        # noqa: PLC0415
    _bd = DM.get(shape.get("dimorph"))
    jaw_sharp = float(_bd.jaw_sharp)
    chin_sharp = float(_bd.chin_sharp)

    # TASK 22: חמשת שדות פיסול בובת האופנה. כולם 0.0 בכל פרופיל
    # קיים, וכל אחת מהפונקציות יוצאת ב-`return p` מיידי באפס -
    # ולכן תשע הדמויות הקודמות נבנות אות באות כמו קודם. ראה doll.py.
    from . import doll as DL                            # noqa: PLC0415
    dl_cheek = float(getattr(_bd, "doll_cheek", 0.0) or 0.0)
    dl_jaw = float(getattr(_bd, "doll_jaw", 0.0) or 0.0)
    dl_lid = float(getattr(_bd, "doll_lid", 0.0) or 0.0)
    dl_lip = float(getattr(_bd, "doll_lip", 0.0) or 0.0)
    dl_cran = float(getattr(_bd, "doll_cranium", 0.0) or 0.0)

    def shaper(p, d, w, u, v):
        p = p.copy()
        # --- TASK 11: עיוות שפת הצורות, **לפני** כל תו פנים ובאותה
        # נוסחה בדיוק שמשמשת את `Head.surf`. ראה facestyle.
        # TASK 22: והגולגולת הפרבולואידית ביניהם - **באותו סדר
        # בדיוק** של `Head.surf`, אחרת כובע השיער יושב על גולגולת
        # אחת והעור על אחרת.
        if styled:
            p = H.warp_xz(p)
        if dl_cran:
            p = H.cranium(p)
        if styled:
            p = H.warp_y(p)
        y_rel = (p[1] - (hc[1] - R)) / (2 * R)          # 0 סנטר, 1 קודקוד
        front = _smoothstep(0.0, 0.55, d[2])
        # --- עיצוב: גולגולת רחבה מעל, פנים צרים למטה
        narrow = H.narrow(y_rel)
        p[0] = hc[0] + (p[0] - hc[0]) * narrow
        # עורף שטוח יותר מהפנים
        if d[2] < 0:
            p[2] = hc[2] + (p[2] - hc[2]) * fs.back_flat

        # התגית נקבעת כאן - אחרי הצורה הגלובלית ולפני תווי הפנים -
        # כדי שקו השיער של הצבע יהיה **אותו** קו כמו של כובע השיער.
        hair = H.in_hair(p)
        tag = "hair" if hair > 0.5 else "skin"
        # **ערבול הצבע נקבע כאן, באותה נקודה שבה נקבעת התגית** - לא
        # אחר כך בצביעה. אם הוא ייגזר מהמיקום הסופי, תווי הפנים כבר
        # הזיזו את הקודקוד, והרצועה הרכה תיפול במילימטר אחר מזה שבו
        # התגית התחלפה. אז נפתח בין השתיים פס דק של צבע מלא - כלומר
        # בדיוק אותו גבול חד שהריכוך בא לבטל. ראה `Head.hair_mix`.
        hmix = H.hair_mix(p)

        xn = abs(p[0] - hc[0]) / R
        rel_y = (p[1] - hc[1]) / R

        # --- רכס גבות
        # רכס הגבות: **רחב ונמוך, לא מדף.** 11 מ"מ על טווח של 0.09
        # ביחידות y_rel יצר מדרגה כמעט אנכית מתחת לגבה, והיא תפסה פס
        # צל רחב וכהה לאורך כל המצח - שנראה בתקריב כמו לכלוך. רכס
        # אמיתי הוא שיפוע רך.
        bro = _smoothstep(0.155, 0.0, abs(y_rel - 0.705)) * front
        p[2] += 0.0068 * k * bro * fs.brow_ridge
        # רכס כבד **מצל**, ולכן הוא גם חייב לרדת על העין: גרומפ מקבל
        # מדף שיורד מעל הארובה, וזה מה שקורא כ"גבות מורדות לנצח".
        if fs.brow_ridge > 1.2:
            p[1] -= 0.0030 * k * bro * (fs.brow_ridge - 1.0)
        # --- ארובות עיניים: שקע סביב מקום העין
        for e in (eyeL, eyeR):
            # **TASK 22 · המטריקה היא שקדית, לא מעגלית.** `dl_lid=0`
            # מחזיר את `np.linalg.norm` בדיוק, ולכן אין שינוי בספרה
            # באף פרופיל קיים. ראה `doll.lid_metric`.
            dd = DL.lid_metric(p, e, dl_lid) if dl_lid else \
                np.linalg.norm(p[:2] - e[:2])
            # ארובה **רדודה וצרה**. הגרסה הקודמת חפרה 19 מ"מ על רדיוס
            # 42 מ"מ (45% מרדיוס הראש) כדי "לחשוף" את גלגל העין. נמדד
            # 05/10 שזה הפוך משתי בחינות: גלגל העין בלט 9.7 מ"מ מחוץ
            # לפנים כמו כדור מודבק, והבור עצמו - משטח קעור שכולו פונה
            # מהאור - הפך לכתם כהה ענק מעל העין, שנראה כמו חבורה.
            # הפתרון הנכון: ארובה רדודה, והזזת גלגל העין קדימה (ראה
            # detail.eye_center), כך שהקרנית בדיוק פורצת את פני העור.
            # הכיול נעשה **במדידה על הרשת הבנויה** ולא בחישוב: שלוש
            # השפעות נוספות (רכס הגבות, עצם הלחי, קימור האליפסואיד)
            # מזיזות את העור באזור העין, ולכן חישוב ידני של "העור ב-z
            # כזה" שגוי ב-2-3 מ"מ - וזה בדיוק הסדר גודל שמחליט אם יש
            # עיניים או אין. היעד שנמדד: קצה הקרנית כ-2 מ"מ **לפני**
            # ממוצע העור ברדיוס 6 מ"מ סביב העין.
            soc = _smoothstep(0.040 * k * fs.socket_r, 0.0, dd) * front
            p[2] -= 0.0105 * k * soc * fs.socket * DL.socket_gain(dl_lid)
            # TASK 22: קפל העפעף העליון, מעל הפתח. בלעדיו הארובה
            # השקדית היא בור בצורת שקד, ולא עפעף.
            if dl_lid:
                p = DL.lid_crease(p, e, k, front, dl_lid)
        # --- ארובה רציפה: רצועה אחת שעוברת מעל גשר האף ומחברת את
        # שתי הארובות. בלעדיה עין ענקית יושבת בבור מעוגל משלה, ובין
        # שני הבורות נשאר רכס אנכי שקורא כאף של דמות מציאותית - בדיוק
        # ההפך ממה שהמשימה מבקשת לזיגי.
        if fs.socket_merge > 1e-6:
            band = _smoothstep(0.034 * k, 0.0, abs(p[1] - eye_y)) * \
                _smoothstep(eye_x * 2.05, eye_x * 0.55, abs(p[0] - hc[0])) * \
                front
            p[2] -= 0.0105 * k * band * fs.socket_merge
        # --- עצמות לחיים: מלאות מתחת לעין, שקע מתחתן
        # **TASK 16 · `fs.cheek` הוא מכפיל, ו-1.0 אינו משנה אף ספרה.**
        # הרדיוס גדל יחד עם המסה (`0.055 -> 0.055*(1+0.35*(cheek-1))`):
        # מסה גדולה על אותו רדיוס היא בליטה חדה, כלומר "תפוח מודבק",
        # ולא לחי. הרחבת הרדיוס היא מה שהופך אותה לנפח שמתמזג אל הפה
        # ואל עצם הלחי - וזו הדרישה "שפתיים מחוברות בטבעיות לנפח
        # הלחיים", שאינה מתקיימת בהגדלת המסה לבדה.
        chk = float(getattr(fs, "cheek", 1.0) or 1.0)
        c_r = 0.055 * (1.0 + 0.35 * (chk - 1.0))
        for tagc in ("L", "R"):
            cp = P[f"cheek_{tagc}"]
            dc = np.linalg.norm(p - cp)
            p[2] += 0.009 * k * chk * \
                _smoothstep(c_r * k, 0.014 * k, dc) * front
        hollow = _smoothstep(0.10, 0.0, abs(y_rel - 0.40)) *             _smoothstep(0.22, 0.42, xn) * front
        p[2] -= 0.006 * k * hollow * float(getattr(fs, "cheek_hollow", 1.0))
        # TASK 22: הרכס הזיגומטי כגאוסיאן **מוטה**. הוא נוסף מעל
        # הבליטה הקיימת ולא מחליף אותה: הקיימת היא נפח הלחי (מסה
        # רכה), וזו העצם שמתחתיה - שתי צורות שונות באותו אזור.
        if dl_cheek:
            p = DL.cheekbone(p, hc, R, k, front, dl_cheek)
        # --- אף: שורש, גשר, קצה וכנפיים
        # **באג יחידות שנמדד 05/10.** שתי השורות האלה קראו את הגובה
        # ב-y_rel (0=סנטר, 1=קודקוד) בעוד שהנחיריים, השפתיים והפילטרום
        # שסביבן קוראות ב-rel_y (0=מרכז הראש, יחידות R). לכן "גשר האף"
        # נבנה ב-y_rel=0.14, כלומר **על הסנטר**, ו"קצה האף" ב-y_rel
        # שלילי - מתחת לראש, כלומר לא נבנה כלל. התוצאה שנראתה בתקריב:
        # אין אף, ויש רכס אנכי מיותר שיורד מהשפה התחתונה אל הסנטר.
        # כאן שתיהן עברו ל-rel_y, כמו כל שאר תווי הפנים.
        # **TASK 16 · ארבעה מכפילים, וכולם 1.0/0.0 בברירת המחדל.**
        # `n_w` מצר את **שלושת** החלונות ב-xn יחד (גשר, קצה, נחיר).
        # צמצום הבלט לבדו משאיר אף רחב ושטוח - "קומפקטי" הוא גם רוחב,
        # לא רק אורך; ולכן נמדד בפרופיל **וגם** חזיתית.
        n_len = float(getattr(fs, "nose_len", 1.0) or 1.0)
        n_w = float(getattr(fs, "nose_w", 1.0) or 1.0)
        n_tip = float(getattr(fs, "nose_tip", 1.0) or 1.0)
        n_up = float(getattr(fs, "nose_up", 0.0) or 0.0)
        bridge = _smoothstep(0.075 * n_w, 0.0, xn) *             _smoothstep(0.175, 0.0, abs(rel_y - 0.010)) * front
        tipn = _smoothstep(0.098 * n_w * n_tip, 0.0, xn) *             _smoothstep(0.072 * n_tip, 0.0, abs(rel_y + 0.080)) * front
        p[2] += (0.013 * k * bridge * n_len + 0.027 * k * tipn * n_len)
        p[1] -= 0.004 * k * tipn * _smoothstep(0.06, 0.0, xn)
        # הרמת הקצה: "מבנה מעוגל בטיפה". היא נמדדת בפרופיל כהפרש
        # הגובה בין קצה האף לשורשו, ולכן היא תכונה ולא קוסמטיקה.
        if n_up:
            p[1] += n_up * R * tipn
        # --- נחיריים: שני שקעים קטנים, ושם גם התגית הכהה
        nos = _smoothstep(0.060 * n_w, 0.022 * n_w, abs(xn - 0.075 * n_w)) *             _smoothstep(0.030, 0.0, abs(rel_y + 0.115)) * front
        if nos > 0.35:
            p[2] -= 0.010 * k * nos * n_len
            tag = "nostril" if tag == "skin" else tag
        # --- פילטרום (התלם מעל השפה)
        phil = _smoothstep(0.045, 0.0, xn) *             _smoothstep(0.045, 0.0, abs(rel_y + 0.205)) * front
        p[2] -= 0.004 * k * phil
        # --- קו הפה: תלם גאומטרי, ושם הצבע הכהה שבין שתי השפתיים
        ml = _smoothstep(0.030, 0.0, abs(rel_y - mouth_y)) *             _smoothstep(1.02, 0.80, xn / mouth_w) * front
        if ml > 0.25:
            p[2] -= 0.009 * k * ml
            if tag == "skin":
                tag = "lip_line"
        # TASK 22: קשת קופידון. **אחרי** תלם קו הפה ולא לפניו -
        # התלם הוא הגבול בין שתי השפתיים, והקשת היא הנפח שמעליו;
        # סדר הפוך היה מוחק את הקשת עם התלם.
        if dl_lip:
            p = DL.cupid_bow(p, hc, R, k, rel_y, xn, front,
                             mouth_y, mouth_w, dl_lip)
        # --- סנטר וקו הלסת
        # הקוטב התחתון של כדור הראש יוצא חרוט שנכנס לצוואר, וזה
        # נראה כמו משפך ולא כמו לסת. כאן הוא נמשך אחורה ולמעלה.
        # **TASK 12 · עוצמת החיתוך היא תכונה של שפת הצורות.** מכפלה
        # ב-1.0 אינה משנה אף ספרה, ולכן לוקאס, מאיה וגרומפ נבנים
        # בדיוק כמו קודם. לזיגי המכפיל נמוך, כי החיתוך הזה - ולא
        # הגולגולת - הוא מה שהפך את תחתית הכדור למדף שטוח ורחב.
        under = _smoothstep(0.20, 0.0, y_rel) * fs.jaw_under
        p[2] -= 0.40 * R * under * (0.35 + 0.65 * front)
        p[1] += 0.26 * R * under
        ch = _smoothstep(0.17, 0.0, y_rel) * front
        p[2] += 0.011 * k * ch * chin_sharp
        p[1] -= 0.004 * k * ch
        # **TASK 10 · חידוד קו הלסת.** שני דברים ולא אחד: הסרת נפח
        # מתחת לעצם הלחי (מה שעושה את הקו) **וגם** היצרות הרוחב שם.
        # רק החסרת עומק הייתה מעמיקה צל בלי לשנות את הצללית, וצללית
        # היא בדיוק מה שהמשימה מבקשת לחדד ("sharpen the jawline
        # silhouette"). ההיצרות מרוכזת בצד (xn גדול) ולכן הסנטר אינו
        # מתחדד איתה - סנטר יש לו פרמטר משלו.
        jawline = _smoothstep(0.16, 0.02, y_rel) * _smoothstep(0.18, 0.40, xn)
        p[2] -= 0.004 * k * jawline * jaw_sharp
        if jaw_sharp != 1.0:
            # **זווית הלסת (gonion) רחבה, והסנטר נאסף.** זו החלוקה
            # הנכונה, והיא לא הייתה כאן בניסיון הראשון: שם החידוד היה
            # היצרות אחידה של כל אזור הלסת, ואז הסנטר הצטמצם *יחד*
            # עם הזווית - כלומר הצללית נשארה אותה קשת, רק קטנה.
            # לסת מחודדת היא **ניגוד** בין זווית רחבה לסנטר צר, וזה
            # מה שנמדד ב-`dimorph.measure` כ-`jaw_angularity`.
            # הגבהים הם ב-`rel_y` (0 = מרכז הראש, יחידות R) ולא
            # ב-`y_rel`, ו**זה נמדד ולא הונח**: בניסיון הראשון הם
            # נכתבו ב-y_rel סביב 0.125, שהוא rel_y≈-0.75 - כלומר
            # מתחת ללסת, באזור שנמשך אחורה אל הצוואר, ולא על הסנטר.
            # מדידה על הרשת הבנויה (05/10) נתנה את הגבהים הנכונים:
            # טבעת הסנטר הקדמית ב-rel_y=-0.68, זווית הלסת ב--0.44.
            gon = _smoothstep(0.13, 0.0, abs(rel_y + 0.44)) * \
                _smoothstep(0.25, 0.50, xn)
            p[0] = hc[0] + (p[0] - hc[0]) * (
                1.0 + 0.085 * (jaw_sharp - 1.0) * gon)
            # הסנטר נאסף **בכל רוחב הטבעת** ולא רק במרכזה: שער על xn
            # השאיר את הקודקוד הרחב ביותר של טבעת הסנטר ללא שינוי,
            # כלומר רוחב הסנטר הנמדד לא זז בכלל.
            nar = _smoothstep(0.14, 0.0, abs(rel_y + 0.70))
            p[0] = hc[0] + (p[0] - hc[0]) * (
                1.0 - 0.090 * (jaw_sharp - 1.0) * nar)
        # TASK 22: מעטפת הלסת הגאוסיאנית. היא באה **אחרי**
        # `jaw_sharp` בכוונה: `jaw_sharp` הוא חידוד נקודתי בשני
        # חלונות smoothstep, ולכל smoothstep יש נגזרת מתאפסת
        # בקצותיו - כלומר מדף. הגאוסיאן שמעליו הוא C∞ ומושך את
        # כל הקו לעקומה אחת, וזה מה שמבטל את ה"קמיצה".
        if dl_jaw:
            p = DL.jawline(p, hc, R, dl_jaw)
        # --- סומק עדין על הלחיים: גבול צבע רך באזור בלי פרט, זה בסדר
        if tag == "skin" and front > 0.4 and 0.30 < y_rel < 0.52 and                 0.28 < xn < 0.56:
            tag = "blush"

        # --- משקולות: head הוא הבסיס, ועליו משקולות הריג
        w = {"head": 1.0}
        jaw_w = _smoothstep(0.46, 0.20, y_rel) * (0.35 + 0.65 * front)
        if jaw_w > 0.01:
            w["jaw"] = jaw_w
            w["head"] = 1.0 - jaw_w
        for e, tg in ((eyeL, "L"), (eyeR, "R")):
            dxy = np.linalg.norm(p[:2] - e[:2])
            up = _smoothstep(0.030 * k, 0.008 * k, dxy) * front *                 _smoothstep(-0.002 * k, 0.010 * k, p[1] - e[1])
            lo = _smoothstep(0.028 * k, 0.008 * k, dxy) * front *                 _smoothstep(-0.002 * k, 0.010 * k, e[1] - p[1])
            cheek = _smoothstep(0.052 * k, 0.018 * k,
                                np.linalg.norm(p - P[f"cheek_{tg}"])) * front
            bi = _smoothstep(0.030 * k, 0.008 * k,
                             np.linalg.norm(p - P[f"brow_in_{tg}"])) * front
            bo = _smoothstep(0.030 * k, 0.008 * k,
                             np.linalg.norm(p - P[f"brow_out_{tg}"])) * front
            for bn, bw in ((f"eyelid_up_{tg}", up * 0.95),
                           (f"eyelid_lo_{tg}", lo * 0.90),
                           (f"cheek_{tg}", cheek * 0.55),
                           (f"brow_in_{tg}", bi * 0.85),
                           (f"brow_out_{tg}", bo * 0.85)):
                if bw > 0.01:
                    w[bn] = w.get(bn, 0.0) + bw
        tot = sum(w.values())
        if tot > 1.0:
            # שומרים על head כבסיס אבל לא נותנים לסכום לעבור 1
            sc = 1.0 / tot
            w = {a: b * sc for a, b in w.items()}
        # רק באזור המעבר עצמו, ורק בין עור לשיער: נחיר, קו שפתיים
        # וסומק הם תגיות משל עצמן, הן אינן גובלות בשיער, וערבול שלהן
        # אל צבע השיער היה מכתים אותן.
        if tag not in ("skin", "hair") or not 1e-4 < hmix < 1.0 - 1e-4:
            hmix = None
        return p, w, tag, hmix

    mb.sphere(hc, R, seg, rings, "head", {"head": 1.0},
              scale=tuple(H.scale), shaper=shaper,
              phi_of=phi_of, theta_of=theta_of)

    # --- תווי הפנים והשיער כגאומטריה נפרדת
    fine = seg >= 64
    # האוזן היא העצם עם הקימור החד ביותר בראש, ולכן היא זו שנראית
    # "מרובעת" ראשונה: ב-18 פרוסות נשארות 9 נקודות על חצי ההיקף
    # שרואים בפרופיל, וזה מצולע ולא קשת. 05/10 - תלונה מפורשת.
    detail.add_ears(mb, H, 34 if fine else 22, 20 if fine else 14)
    detail.add_lips(mb, H, 18 if fine else 10)
    detail.add_brows(mb, H, 12 if fine else 8)
    detail.add_lashes(mb, H, 10 if fine else 6)
    detail.add_eyes(mb, H, 28 if fine else 12, 20 if fine else 10)
    detail.add_eyelids(mb, H, 16 if fine else 8, 5 if fine else 3)
    hair_info = detail.add_hair(mb, H, 96 if fine else 28,
                                56 if fine else 18)

    # לשון
    t1, t2 = P["tongue_01"], P["tongue_02"]
    rings_t = [(t1, 0.013 * k, 0.009 * k, {"tongue_01": 1.0}),
               (_lerp(t1, t2, 0.5), 0.012 * k, 0.008 * k,
                {"tongue_01": 0.5, "tongue_02": 0.5}),
               (t2, 0.008 * k, 0.005 * k, {"tongue_02": 1.0})]
    mb.tube(rings_t, max(8, seg // 8), True, True, "tongue",
            (0.0, 0.0, 1.0), tag="tongue")
    return hair_info


# -------------------------------------------------------------------- המרה


def to_arrays(mb: MeshBuilder, skel: Skeleton, influences: int = 4,
              smooth_passes: int = 2):
    """ממיר ל-numpy: עמדות, נורמלים, UV, skinIndex/skinWeight, אינדקסים.

    החלקת משקולות: רק באזורים "רכים" (גוף, פנים). באזורים קשיחים
    (גלגל עין, אצבעות) החלקה דווקא מזיקה - היועצים הזהירו מזה, ונמדד
    כאן שגלגל עין שמקבל גם משקולת ראש זולג מהארובה כשהראש מסתובב.
    """
    n = len(mb.v)
    pos = np.asarray(mb.v, dtype=np.float32)
    uv = np.asarray(mb.uv, dtype=np.float32)
    idx = np.asarray(mb.f, dtype=np.uint32).reshape(-1)
    name_to_i = {b.name: b.index for b in skel.bones}

    W = np.zeros((n, len(skel.bones)), dtype=np.float32)
    for i, w in enumerate(mb.w):
        for name, val in w.items():
            W[i, name_to_i[name]] += val
    s = W.sum(axis=1, keepdims=True)
    s[s == 0] = 1.0
    W /= s

    rigid = np.zeros(n, dtype=bool)
    for name, v0, v1 in mb.groups:
        if name.startswith("eyeball") or name in ("tongue",):
            rigid[v0:v1] = True
        if any(name.startswith(p) for p in
               ("thumb", "index", "middle", "ring", "pinky")):
            rigid[v0:v1] = True

    if smooth_passes > 0:
        ea, eb = _neighbors(idx, n)
        for _ in range(smooth_passes):
            acc = W.copy()
            cnt = np.ones((n, 1), dtype=np.float32)
            # np.add.at ולא acc[ea] += : אינדוקס מתוחכם *לא* מצטבר על
            # אינדקס שחוזר, ובלי זה קודקוד עם שבעה שכנים מקבל שכן אחד.
            np.add.at(acc, ea, W[eb])
            np.add.at(cnt, ea, 1.0)
            sm = acc / cnt
            W = np.where(rigid[:, None], W, 0.5 * W + 0.5 * sm)
        s = W.sum(axis=1, keepdims=True)
        s[s == 0] = 1.0
        W /= s

    order = np.argsort(-W, axis=1)[:, :influences]
    si = order.astype(np.uint16)
    sw = np.take_along_axis(W, order, axis=1).astype(np.float32)
    s = sw.sum(axis=1, keepdims=True)
    s[s == 0] = 1.0
    sw /= s

    nrm = _normals(pos, idx)
    return {"position": pos, "normal": nrm, "uv": uv,
            "skinIndex": si, "skinWeight": sw, "index": idx}


def _neighbors(idx, n):
    tri = idx.reshape(-1, 3)
    a = np.concatenate([tri[:, 0], tri[:, 1], tri[:, 2],
                        tri[:, 1], tri[:, 2], tri[:, 0]])
    b = np.concatenate([tri[:, 1], tri[:, 2], tri[:, 0],
                        tri[:, 0], tri[:, 1], tri[:, 2]])
    return a, b


def _normals(pos, idx):
    nrm = np.zeros_like(pos)
    tri = idx.reshape(-1, 3)
    p0, p1, p2 = pos[tri[:, 0]], pos[tri[:, 1]], pos[tri[:, 2]]
    fn = np.cross(p1 - p0, p2 - p0)
    for c in range(3):
        np.add.at(nrm, tri[:, c], fn)
    ln = np.linalg.norm(nrm, axis=1, keepdims=True)
    ln[ln == 0] = 1.0
    return (nrm / ln).astype(np.float32)
