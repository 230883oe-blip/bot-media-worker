# -*- coding: utf-8 -*-
"""שלב 9 · מנהל הצילום — בחירת שוט לפי מטרה רגשית, ולא לפי טעם.

**מה היה חסר כאן עד עכשיו.** המצלמה בפרויקט הזה הייתה כתובה ביד
בכל שוט: ``{"yaw": ..., "pitch": ..., "dist": ..., "fov": 30}``.
זה עובד, וזה גם אומר שאין דרך לענות על השאלה שהדרישה מציבה —
*למה אנחנו רואים את הדמות הזאת מהזווית הזאת ברגע הזה?* תשובה
אמיתית לשאלה הזו היא תמיד תשובה **מדידה**, והמדידה היא זו:

    האם מה שהצופה צריך לראות ברגע הזה **גדול מספיק בפריים
    כדי שאפשר יהיה לראות אותו?**

---

## הלב: הנראות היא גאומטריה, לא דעה

תנועת גבה היא כשלושה מילימטרים. תנועת אישון היא מילימטר וחצי.
הזזת משקל היא חמישה-עשר. כל אחד מהם נראה על המסך אם ורק אם הוא
תופס מספיק פיקסלים, וזה חישוב ולא שיקול דעת:

    גובה הפריים במטרים = 2 · מרחק · tan(fov/2)
    פיקסלים של פרט     = (גודל הפרט / גובה הפריים) · גובה התמונה

מכאן ``visibility(shot, region)`` — מספר בין 0 ל-1 שאומר כמה
האזור הזה קריא בשוט הזה. פרט שנופל מתחת לפיקסל בודד אינו נראה
כלל (הוא מתחת לרזולוציית הדגימה), ומעל ארבעה פיקסלים הוא נראה
היטב. בין לבין — מדרון.

**הבדיקה שאימתה את הגאומטריה:** ב-``appeal.CONDITIONS`` השוט
הרחב הוא מרחק 3.05 ושדה ראייה 32°, והדמות גבוהה 1.70. החישוב
נותן גובה פריים 1.75 מטר — כלומר הדמות ממלאת את הפריים בדיוק,
וזה מה שרואים בגיליון המגע שנצרב שם. הנוסחה אינה תיאורטית.

---

## למה זה פותר את "המערכת בוחרת את האסטרטגיה הטובה"

לסצנה יש מסלול בקרות אמיתי (``rig.cinema.take``), ובו רשום בכל
פריים מה זז. ``coverage`` חותך את המסלול לפי השוטים של אסטרטגיה
נתונה, ולכל ערוץ שזז מכפיל את עוצמת השינוי בנראות האזור שלו
בשוט שמוצג **באותו רגע**. התוצאה היא שבר אחד:

    שיעור המידע הרגשי שהגיע לצופה

אסטרטגיה שמציגה שוט רחב בדיוק כשהשינוי כולו בעיניים מפסידה את
השינוי, והמספר אומר את זה. זה לא ציון שבחרתי — זה שינוי שנמדד
במסלול, כפול נראות שחושבה בגאומטריה.

**ומה שמונע מהמדד למדוד את עצמו:** שלוש אסטרטגיות ביקורת
(``wide_only``, ``random_cuts``, ``static_single``) שחייבות
לקבל ציון נמוך מהאסטרטגיה הנבחרת. מדד שגם הן עוברות אותו אינו
מודד כלום — זה אותו עיקרון של ``cinema.CONTROLS``.

---

## מה שנדחה בכוונה

**אין כאן "חוק 180 מעלות" כבדיקה חוסמת.** הוא נכון בסצנת דיאלוג
קלאסית ושגוי ברגע שהבימוי רוצה לשבור אותו במכוון, ובדיקה שאוסרת
על בחירה אמנותית תקינה היא בדיקה שתכובה. מה שכן נמדד הוא
``continuity_cost`` — קפיצת זווית בין שוטים עוקבים — והוא נכנס
לציון כעלות, לא כווטו.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
import time
from dataclasses import dataclass, field

import numpy as np

# ---------------------------------------------------- גדלים פיזיקליים

#: גובה ראש אנושי בוגר, במטרים. ממנו נגזרים כל גדלי פרטי הפנים.
HEAD_M = 0.232

#: גובה תמונה שמולו נמדדת הקריאות. 1080 הוא מה שהפרויקט מרנדר.
IMG_H = 1080

#: גודל הפרט הקטן ביותר שחייב להיראות בכל אזור, במטרים.
#: **אלה מידות אנטומיות ולא כיול**: אישון נע כמילימטר וחצי, גבה
#: מתרוממת כשלושה, זווית פה נעה כחמישה, סיבוב ראש מזיז את קו
#: הלסת כשני סנטימטרים, והעברת משקל מזיזה את האגן כחמישה-עשר.
DETAIL_M = {
    "gaze":    0.0015,
    "eyelids": 0.0025,
    "brows":   0.0030,
    "cheeks":  0.0040,
    "nose":    0.0035,
    "lips":    0.0050,
    "mouth":   0.0050,
    "jaw":     0.0070,
    "tongue":  0.0060,
    "head":    0.0200,
    "torso":   0.0150,
    "hands":   0.0100,
    "stance":  0.0250,
}

#: גובה האזור על הדמות, כשבר מגובה הדמות. זה מה שמכריע אם האזור
#: **בתוך** הפריים או נחתך ממנו, ולכן הוא חייב להיות אנטומי:
#: קו העיניים הוא כ-0.93 מהגובה, הפה כ-0.885, מרכז הגו כ-0.72,
#: הידיים בעמידה נייטרלית כ-0.55, והאגן כ-0.52.
REGION_Y = {
    "gaze": 0.930, "eyelids": 0.930, "brows": 0.947, "nose": 0.905,
    "cheeks": 0.908, "lips": 0.885, "mouth": 0.885, "jaw": 0.868,
    "tongue": 0.885, "head": 0.940, "torso": 0.720, "hands": 0.550,
    "stance": 0.520,
}

#: מתחת לפיקסל אחד הפרט אינו קיים על המסך; מעל ארבעה הוא קריא.
PX_FLOOR, PX_FULL = 1.0, 4.0


def _ramp(v: float, lo: float, hi: float) -> float:
    if hi <= lo:
        return 1.0 if v >= hi else 0.0
    return max(0.0, min(1.0, (v - lo) / (hi - lo)))


# ----------------------------------------------------------- סוגי שוט

@dataclass(frozen=True)
class ShotKind:
    """סוג שוט: גאומטריה, ולמה הוא קיים.

    ``dist_f`` הוא מרחק כמכפלה של גובה הדמות, כדי שאותו שוט יעבוד
    על דמות של 1.55 ועל דמות של 1.85 בלי לכוון מחדש. ``ty_f`` הוא
    גובה נקודת המבט, גם הוא כשבר מגובה הדמות.
    """

    key: str
    label: str
    dist_f: float
    fov: float
    ty_f: float
    yaw: float = 0.0
    pitch: float = 0.0
    purpose: str = ""


#: שבעה סוגי מסגור ושתי זוויות גובה — כל מה שהדרישה מונה.
#: הערכים תואמים ל-``appeal.CONDITIONS`` כדי שאותו שוט ייראה אותו
#: דבר בשני המקומות; שני סטים של מספרים לאותו שוט הם שתי מערכות.
KINDS: dict[str, ShotKind] = {k.key: k for k in (
    ShotKind("wide", "שוט רחב", 1.79, 32.0, 0.50,
             purpose="איפה הדמויות ביחס זו לזו ולמקום"),
    ShotKind("medium", "שוט בינוני", 0.91, 32.0, 0.76,
             purpose="גוף ופנים יחד - שפת גוף עם הבעה"),
    ShotKind("close_up", "תקריב", 0.42, 26.0, 0.905,
             purpose="הבעה: גבות, עפעפיים, פה"),
    ShotKind("extreme_close_up", "תקריב קיצוני", 0.22, 24.0, 0.925,
             purpose="עיניים בלבד - מבט, אישון, היסוס"),
    ShotKind("over_shoulder", "מעל הכתף", 0.75, 30.0, 0.88, yaw=22.0,
             purpose="מי מקשיב למי - יחס, לא הבעה"),
    ShotKind("low_angle", "זווית נמוכה", 1.00, 32.0, 0.56, pitch=-22.0,
             purpose="מי שולט בשיחה"),
    ShotKind("high_angle", "זווית גבוהה", 1.00, 32.0, 0.82, pitch=28.0,
             purpose="מי נחשף, מי קטן ברגע הזה"),
)}

#: תנועות מצלמה. ``drift`` הוא שינוי המרחק לאורך השוט כשבר
#: (שלילי = התקרבות), ``swing`` הוא סחיפת זווית במעלות.
#: ``dof`` הוא עומק שדה: 0 = הכול חד, 1 = רקע מרוח לגמרי.
MOVES: dict[str, dict] = {
    "static":    {"drift": 0.00, "swing": 0.0, "tilt": 0.0, "dof": 0.25},
    "pan":       {"drift": 0.00, "swing": 7.0, "tilt": 0.0, "dof": 0.25},
    "tilt":      {"drift": 0.00, "swing": 0.0, "tilt": 5.0, "dof": 0.25},
    "dolly_in":  {"drift": -0.16, "swing": 1.5, "tilt": 0.0, "dof": 0.45},
    "dolly_out": {"drift": 0.18, "swing": -1.5, "tilt": 0.0, "dof": 0.30},
    "tracking":  {"drift": -0.05, "swing": 9.0, "tilt": 0.0, "dof": 0.35},
    "rack_focus": {"drift": 0.00, "swing": 0.0, "tilt": 0.0, "dof": 0.80},
}


@dataclass
class Shot:
    """שוט אחד בתוך אסטרטגיה: מה, מתי, ולמה."""

    kind: str
    t0: float
    t1: float
    move: str = "static"
    subject: str = "B"
    why: str = ""

    def __post_init__(self):
        if self.kind not in KINDS:
            raise ValueError(f"סוג שוט לא מוכר: {self.kind}")
        if self.move not in MOVES:
            raise ValueError(f"תנועת מצלמה לא מוכרת: {self.move}")
        if self.t1 <= self.t0:
            raise ValueError(f"שוט באורך אפס או שלילי: {self.t0}-{self.t1}")

    @property
    def secs(self) -> float:
        return self.t1 - self.t0

    def frame(self, u: float, height: float = 1.70) -> dict:
        """פרמטרי מצלמה בנקודה ``u`` (0..1) בתוך השוט.

        מוחזר בדיוק במבנה שמנוע ההפקה כבר מקבל (``yaw``/``pitch``/
        ``dist``/``ty``/``fov``), ולכן מנהל הצילום מתחבר לשוטים
        הקיימים בלי לשנות אותם — ועוד שדה אחד, ``dof``.
        """
        k = KINDS[self.kind]
        m = MOVES[self.move]
        dist = k.dist_f * height * (1.0 + m["drift"] * u)
        return {"yaw": round(k.yaw + m["swing"] * (u - 0.5), 3),
                "pitch": round(k.pitch + m["tilt"] * (u - 0.5), 3),
                "dist": round(dist, 4),
                "ty": round(k.ty_f * height, 4),
                "fov": k.fov,
                "dof": m["dof"] if self.move != "rack_focus"
                else round(0.15 + 0.65 * u, 3)}


# --------------------------------------------------------- נראות אזור

def frame_height_m(shot: Shot, height: float = 1.70, u: float = 0.5) -> float:
    """גובה מה שנכנס לפריים, במטרים. זו כל הגאומטריה."""
    f = shot.frame(u, height)
    return 2.0 * f["dist"] * math.tan(math.radians(f["fov"] / 2.0))


def detail_px(shot: Shot, region: str, height: float = 1.70,
              img_h: int = IMG_H) -> float:
    """כמה פיקסלים תופס הפרט הקטן ביותר של האזור, בשוט הזה."""
    d = DETAIL_M.get(region)
    if d is None:
        return 0.0
    fh = frame_height_m(shot, height)
    if fh <= 0:
        return 0.0
    return d / fh * img_h


def visibility(shot: Shot, region: str, height: float = 1.70,
               img_h: int = IMG_H) -> float:
    """0..1 — כמה האזור קריא בשוט.

    שני גורמים, ושניהם גאומטריים:
    1. גודל הפרט בפיקסלים (המדרון ``PX_FLOOR``..``PX_FULL``).
    2. האם האזור בכלל **בתוך** הפריים. בתקריב קיצוני אין כתפיים
       בפריים, ולכן העברת משקל אינה נראית שם גם אם היא ענקית —
       וזו בדיוק הטעות שמנהל צילום רע עושה.
    """
    px = detail_px(shot, region, height, img_h)
    size = _ramp(px, PX_FLOOR, PX_FULL)
    if size <= 0.0:
        return 0.0
    # **האם האזור עצמו בתוך הפריים — ולא האם הראש כולו בתוכו.**
    # זה היה הבאג הראשון כאן, והוא נתפס במבחן הקבלה ולא בקריאת
    # הקוד: בתקריב קיצוני הראש *כן* חתוך, אבל העיניים נמצאות
    # בדיוק במרכז הפריים ולכן נראות מצוין. מי שמתנה פרט פנים
    # בכך שהראש שלם פוסל את השוט שנועד להראות אותו.
    fh = frame_height_m(shot, height)
    f = shot.frame(0.5, height)
    y_reg = REGION_Y.get(region, 0.72) * height
    offset = abs(y_reg - float(f["ty"]))
    half = fh / 2.0
    # בקצה הפריים הפרט נחתך בהדרגה; 0.80 מחצי הפריים הוא עוד
    # פנים, ומעבר לחצי הוא בחוץ.
    inside = 1.0 - _ramp(offset, half * 0.80, half * 1.02)
    # זווית חדה מסתירה חצי פנים; זה לא פוסל אבל כן מוריד קריאות.
    k = KINDS[shot.kind]
    ang = 1.0 - 0.35 * min(1.0, abs(k.yaw) / 90.0) \
        - 0.20 * min(1.0, abs(k.pitch) / 45.0)
    return round(max(0.0, size * inside * ang), 4)


# ------------------------------------------- מאיזה אזור ערוץ בקרה בא

_BODY_HINTS = (
    ("hand", "hands"), ("finger", "hands"), ("curl_", "hands"),
    ("spread", "hands"), ("wrist", "hands"), ("elbow", "hands"),
    ("shoulder", "torso"), ("spine", "torso"), ("chest", "torso"),
    ("clav", "torso"), ("hips", "stance"), ("weight", "stance"),
    ("knee", "stance"), ("foot", "stance"), ("ankle", "stance"),
    ("head", "head"), ("neck", "head"),
)


def region_of_channel(key: str) -> str:
    """לאיזה אזור נראות שייך ערוץ בקרה.

    קודם נשאל ``acting.region_of`` — הוא המקור לאמת על אזורי פנים
    ומתעדכן לבד כשמוסיפים בקרה. רק מה שהוא לא מכיר נופל לרמזים
    של הגוף. רשימה ידנית של ערוצי פנים הייתה מתיישנת ביום.
    """
    from . import acting                                 # noqa: PLC0415
    base = key[:-2] if key.endswith(("_L", "_R")) else key
    for cand in (key, base):
        try:
            return acting.region_of(cand)
        except KeyError:
            pass
    if key.startswith("eye_aim"):
        return "gaze"
    low = key.lower()
    for frag, reg in _BODY_HINTS:
        if frag in low:
            return reg
    return "torso"


# ------------------------------------------------------ כיסוי אסטרטגיה

@dataclass
class Strategy:
    """רצף שוטים לסצנה אחת."""

    key: str
    label: str
    shots: list[Shot]
    note: str = ""

    def shot_at(self, t: float) -> Shot | None:
        for s in self.shots:
            if s.t0 <= t < s.t1:
                return s
        return self.shots[-1] if self.shots and t >= self.shots[-1].t1 else None

    def covers(self, length: float, tol: float = 0.05) -> bool:
        """האם השוטים מכסים את הסצנה בלי חור ובלי חפיפה."""
        if not self.shots:
            return False
        ss = sorted(self.shots, key=lambda s: s.t0)
        if abs(ss[0].t0) > tol or abs(ss[-1].t1 - length) > tol:
            return False
        return all(abs(b.t0 - a.t1) <= tol for a, b in zip(ss, ss[1:]))


@dataclass
class Coverage:
    """תוצאת המדידה של אסטרטגיה אחת מול מסלול אמיתי."""

    strategy: str
    delivered: float          # שיעור המידע הרגשי שהגיע לצופה
    per_region: dict
    cuts: int
    continuity_cost: float
    shot_mix: dict
    score: float
    detail: dict = field(default_factory=dict)


def _motion(track, keys: list[str]) -> np.ndarray:
    """|Δ| לכל ערוץ בכל פריים — 'מה זז עכשיו'."""
    M = np.array([[abs(float(f.get(k, 0.0))) for k in keys]
                  for f in track.frames])
    d = np.abs(np.diff(M, axis=0, prepend=M[:1]))
    return d


def coverage(strat: Strategy, track, height: float = 1.70,
             img_h: int = IMG_H) -> Coverage:
    """שיעור המידע הרגשי שהאסטרטגיה הזו באמת מעבירה.

    ``delivered`` = Σ(שינוי בערוץ · נראות האזור בשוט שמוצג אז)
    חלקי Σ(שינוי בערוץ). אין בזה שום פרמטר שאפשר לכוון עד
    שהבדיקה תעבור: השינוי נמדד במסלול, והנראות מחושבת בגאומטריה.
    """
    from . import cinema                                 # noqa: PLC0415
    keys = sorted({k for f in track.frames for k in f
                   if not cinema.is_audio_driven(k)})
    if not keys:
        raise ValueError("אין ערוצים ויזואליים במסלול")
    regs = [region_of_channel(k) for k in keys]
    d = _motion(track, keys)
    ts = track.times

    # נראות לכל (שוט, אזור) מחושבת פעם אחת - לא פר פריים.
    vis_cache: dict[tuple[str, str], float] = {}
    for s in strat.shots:
        for r in set(regs):
            vis_cache[(id(s).__str__(), r)] = visibility(s, r, height, img_h)

    tot = np.zeros(len(keys))
    got = np.zeros(len(keys))
    for i, t in enumerate(ts):
        s = strat.shot_at(float(t))
        if s is None:
            tot += d[i]
            continue
        row = d[i]
        tot += row
        vs = np.array([vis_cache[(id(s).__str__(), r)] for r in regs])
        got += row * vs

    per_region: dict[str, dict] = {}
    for r in sorted(set(regs)):
        sel = [j for j, rr in enumerate(regs) if rr == r]
        tr, gr = float(tot[sel].sum()), float(got[sel].sum())
        if tr <= 1e-9:
            continue
        per_region[r] = {"moved": round(tr, 4), "seen": round(gr, 4),
                         "share": round(gr / tr, 4)}

    delivered = float(got.sum() / tot.sum()) if tot.sum() > 1e-9 else 0.0

    # עלות רציפות: קפיצת זווית ומרחק בין שוטים עוקבים. **עלות ולא
    # ווטו** - שבירת רציפות היא לפעמים בחירה נכונה.
    ss = sorted(strat.shots, key=lambda s: s.t0)
    cost = 0.0
    for a, b in zip(ss, ss[1:]):
        ka, kb = KINDS[a.kind], KINDS[b.kind]
        dy = abs(ka.yaw - kb.yaw) / 180.0
        dp = abs(ka.pitch - kb.pitch) / 90.0
        dd = abs(ka.dist_f - kb.dist_f) / 2.0
        cost += 0.5 * dy + 0.7 * dp + 0.25 * dd
    cost = round(cost / max(1, len(ss) - 1), 4) if len(ss) > 1 else 0.0

    # שוט קצר מדי אינו נקרא. מתחת לשנייה הצופה לא מספיק להבין
    # מה הוא רואה, וזו הדרך הנפוצה לזייף "בימוי עשיר".
    short = [s.kind for s in ss if s.secs < 1.0]
    mix = {}
    for s in ss:
        mix[s.kind] = round(mix.get(s.kind, 0.0) + s.secs, 2)

    # הציון: המידע שהועבר, פחות עלות הרציפות, פחות עונש על שוטים
    # קצרים מדי, פחות עונש על חדגוניות (סוג שוט אחד לכל הסצנה).
    variety = _ramp(len(mix), 1.0, 3.0)
    penalty = 0.18 * cost + 0.10 * len(short)
    score = max(0.0, min(1.0, delivered * (0.80 + 0.20 * variety) - penalty))

    return Coverage(strategy=strat.key, delivered=round(delivered, 4),
                    per_region=per_region, cuts=max(0, len(ss) - 1),
                    continuity_cost=cost, shot_mix=mix,
                    score=round(score, 4),
                    detail={"short_shots": short, "variety": round(variety, 3),
                            "channels": len(keys)})


# ---------------------------------------------------- מטרה ואסטרטגיות

@dataclass(frozen=True)
class Intent:
    """המטרה הרגשית של הסצנה — מה הצופה חייב לקרוא, ומתי."""

    key: str
    label: str
    #: אזור -> חלון זמן שבו הוא קריטי. זה ה"למה" של כל שוט.
    needs: dict
    note: str = ""


def strategies(length: float, a_speech: tuple[float, float],
               b_speech: tuple[float, float]) -> dict[str, Strategy]:
    """שלוש אסטרטגיות אמיתיות לאותה סצנה, ושלוש ביקורת.

    שלוש האמיתיות אינן גרסאות של אותו רעיון — כל אחת בוחרת אחרת
    *מה חשוב*: הראשונה את ההבעה, השנייה את היחס בין השתיים,
    השלישית את הגוף. זו הנקודה של המבחן: שלוש בחירות סבירות,
    ומדידה שמכריעה ביניהן.
    """
    a0, a1 = a_speech
    b0, b1 = b_speech
    mid = (a1 + b0) / 2.0
    out: dict[str, Strategy] = {}

    # א. בימוי הבעה: רחב לפתיחה, תקריב לכל זמן הקליטה והתגובה,
    #    תקריב קיצוני על ההיסוס עצמו.
    out["expression_led"] = Strategy(
        "expression_led", "בימוי הבעה", [
            Shot("wide", 0.0, a1 * 0.62, "static", "AB",
                 why="לקבוע מי נמצא איפה לפני שמתקרבים"),
            Shot("close_up", a1 * 0.62, mid, "dolly_in", "B",
                 why="המשפט נקלט - ההבעה היא כל המידע"),
            Shot("extreme_close_up", mid, b0, "static", "B",
                 why="ההיסוס קורה בעיניים, ואין לו גודל אחר"),
            Shot("close_up", b0, b1 + 0.6, "static", "B",
                 why="התגובה נאמרת, והפנים ממשיכות לדבר"),
            Shot("medium", b1 + 0.6, length, "dolly_out", "B",
                 why="הרגש נשאר, והגוף מראה שהוא נשאר"),
        ], note="מניח שהמידע הרגשי יושב בפנים")

    # ב. בימוי יחס: מעל הכתף לשני הכיוונים, בינוני בפתיחה ובסיום.
    out["relationship_led"] = Strategy(
        "relationship_led", "בימוי יחס", [
            Shot("medium", 0.0, a1 * 0.70, "static", "AB",
                 why="שתיהן בפריים, כדי שהיחס יהיה הנושא"),
            Shot("over_shoulder", a1 * 0.70, mid, "static", "B",
                 why="אנחנו איתה מול מי שדיבר"),
            Shot("over_shoulder", mid, b1, "pan", "A",
                 why="הצד השני של אותו יחס"),
            Shot("medium", b1, length, "static", "AB",
                 why="היחס אחרי שהשתנה"),
        ], note="מניח שהמידע יושב ביחס בין השתיים")

    # ג. בימוי גוף: בינוני וזוויות גובה, בלי תקריב בכלל.
    out["body_led"] = Strategy(
        "body_led", "בימוי גוף", [
            Shot("wide", 0.0, a1, "static", "AB",
                 why="שפת גוף דורשת גוף שלם"),
            Shot("medium", a1, mid, "tracking", "B",
                 why="העברת המשקל והכתפיים"),
            Shot("high_angle", mid, b0, "static", "B",
                 why="מי נחשף ברגע הזה"),
            Shot("medium", b0, length, "dolly_in", "B",
                 why="התגובה, עם הגוף"),
        ], note="מניח שהמידע יושב בשפת הגוף")

    # --- אסטרטגיות ביקורת. **חייבות** לצאת נחותות.
    out["wide_only"] = Strategy(
        "wide_only", "ביקורת · רחב בלבד",
        [Shot("wide", 0.0, length, "static", "AB", why="ביקורת")],
        note="מסתיר כל פרט פנים - החדגוניות הנפוצה ביותר")
    out["static_single"] = Strategy(
        "static_single", "ביקורת · שוט אחד בינוני",
        [Shot("medium", 0.0, length, "static", "B", why="ביקורת")],
        note="פשרה: לא רואים עיניים, לא רואים יחס")
    # **ארבעה-עשר ולא עשרה.** עשרה שוטים על סצנה של עשר שניות הם
    # שוט של שנייה בדיוק, והעונש על "שוט קצר מדי" (מתחת לשנייה)
    # לא נדלק - כלומר גרסת הביקורת לא הדגימה את הפגם שלשמו נכתבה.
    # נתפס בבדיקה ולא בקריאת הקוד.
    n = 14
    step = length / n
    kinds = ["wide", "extreme_close_up", "high_angle", "over_shoulder",
             "low_angle", "close_up", "wide", "extreme_close_up",
             "medium", "high_angle", "close_up", "low_angle",
             "over_shoulder", "wide"]
    out["random_cuts"] = Strategy(
        "random_cuts", "ביקורת · חיתוכים מקוטעים",
        [Shot(kinds[i], i * step, (i + 1) * step, "static", "B",
              why="ביקורת") for i in range(n)],
        note="הרבה גיוון, שוטים קצרים מדי וקפיצות - בימוי שלא נקרא")
    return out


#: שלוש האמיתיות. השאר ביקורת, וההפרדה הזו היא מה שהופך את
#: הבחירה למבחן ולא לתצוגה.
REAL = ("expression_led", "relationship_led", "body_led")
CONTROL = ("wide_only", "static_single", "random_cuts")


def choose(track, length: float, a_speech: tuple[float, float],
           b_speech: tuple[float, float], height: float = 1.70) -> dict:
    """מודד את כל האסטרטגיות על אותו מסלול ובוחר.

    הבחירה היא ``argmax`` על ציון מדיד, ולא העדפה שכתובה בקוד.
    מוחזר גם ה"למה" של כל שוט באסטרטגיה שנבחרה — זו התשובה
    לשאלה שהדרישה מציבה.
    """
    strats = strategies(length, a_speech, b_speech)
    covs = {k: coverage(s, track, height) for k, s in strats.items()}
    real = {k: covs[k] for k in REAL}
    best = max(real, key=lambda k: real[k].score)
    chosen = strats[best]
    return {
        "chosen": best,
        "label": chosen.label,
        "score": real[best].score,
        "delivered": real[best].delivered,
        "why_shots": [{"kind": s.kind, "t": [round(s.t0, 2), round(s.t1, 2)],
                       "move": s.move, "subject": s.subject, "why": s.why}
                      for s in sorted(chosen.shots, key=lambda x: x.t0)],
        "ranking": sorted(((k, c.score, c.delivered) for k, c in covs.items()),
                          key=lambda r: -r[1]),
        "coverage": {k: {"score": c.score, "delivered": c.delivered,
                         "cuts": c.cuts, "continuity_cost": c.continuity_cost,
                         "mix": c.shot_mix, "per_region": c.per_region}
                     for k, c in covs.items()},
    }


# ------------------------------------------------------------- ביקורת

def audit(height: float = 1.70) -> dict:
    """מבחן הקבלה של שלב 9.

    אותה סצנה, שלוש אסטרטגיות אמיתיות ושלוש ביקורת, והמערכת
    בוחרת. ``checks`` הוא מה ש-``studio.baseline`` קורא.
    """
    from . import cinema                                 # noqa: PLC0415
    t0 = time.time()
    track = cinema.take("full", "b")
    res = choose(track, cinema.SCENE_LEN, cinema.A_SPEECH, cinema.B_SPEECH,
                 height)
    strats = strategies(cinema.SCENE_LEN, cinema.A_SPEECH, cinema.B_SPEECH)
    covs = {k: coverage(s, track, height) for k, s in strats.items()}

    best = covs[res["chosen"]]
    worst_ctrl = max(covs[k].score for k in CONTROL)
    # גיאומטריה: שלושת מבחני הנראות שמוכיחים שהחישוב אמיתי ולא
    # טבלה שמישהו מילא. תקריב קיצוני חייב להראות אישון; שוט רחב
    # חייב *לא* להראות אותו; תקריב קיצוני חייב לא להראות משקל.
    ecu = Shot("extreme_close_up", 0, 1)
    wide = Shot("wide", 0, 1)
    med = Shot("medium", 0, 1)
    v_gaze_ecu = visibility(ecu, "gaze", height)
    v_gaze_wide = visibility(wide, "gaze", height)
    v_stance_ecu = visibility(ecu, "stance", height)
    v_stance_med = visibility(med, "stance", height)

    checks = {
        "כל סוגי השוט מוגדרים": {
            "value": len(KINDS), "limit": ">=7", "pass": len(KINDS) >= 7},
        "כל תנועות המצלמה מוגדרות": {
            "value": len(MOVES), "limit": ">=7", "pass": len(MOVES) >= 7},
        "שלוש אסטרטגיות אמיתיות": {
            "value": len(REAL), "limit": ">=3", "pass": len(REAL) >= 3},
        "כל אסטרטגיה מכסה את הסצנה": {
            "value": sum(1 for s in strats.values()
                         if s.covers(cinema.SCENE_LEN)),
            "limit": f"=={len(strats)}",
            "pass": all(s.covers(cinema.SCENE_LEN) for s in strats.values())},
        "לכל שוט נבחר יש נימוק": {
            "value": sum(1 for s in res["why_shots"] if s["why"]),
            "limit": f"=={len(res['why_shots'])}",
            "pass": all(s["why"] for s in res["why_shots"])},
        "אישון נראה בתקריב קיצוני": {
            "value": v_gaze_ecu, "limit": ">=0.5", "pass": v_gaze_ecu >= 0.5},
        "אישון אינו נראה בשוט רחב": {
            "value": v_gaze_wide, "limit": "<=0.15",
            "pass": v_gaze_wide <= 0.15},
        "משקל אינו נראה בתקריב קיצוני": {
            "value": v_stance_ecu, "limit": "<=0.10",
            "pass": v_stance_ecu <= 0.10},
        "משקל נראה בשוט בינוני": {
            "value": v_stance_med, "limit": ">=0.4",
            "pass": v_stance_med >= 0.4},
        "הבחירה עולה על כל הביקורות": {
            "value": round(best.score - worst_ctrl, 4), "limit": ">0",
            "pass": best.score > worst_ctrl},
        "רחב-בלבד מפסיד מידע פנים": {
            "value": covs["wide_only"].delivered, "limit": "<0.55",
            "pass": covs["wide_only"].delivered < 0.55},
        "חיתוכים מקוטעים נענשים": {
            "value": covs["random_cuts"].score, "limit": "<הנבחרת",
            "pass": covs["random_cuts"].score < best.score},
        "הבחירה מעבירה רוב המידע": {
            "value": best.delivered, "limit": ">=0.60",
            "pass": best.delivered >= 0.60},
    }
    passed = all(v["pass"] for v in checks.values())
    return {"task": "שלב 9 - מנהל הצילום", "strategies": len(strats),
            "real": list(REAL), "control": list(CONTROL),
            "chosen": res["chosen"], "ranking": res["ranking"],
            "why_shots": res["why_shots"],
            "coverage": res["coverage"], "checks": checks,
            "passed": passed, "seconds": round(time.time() - t0, 2)}


def main(argv=None) -> int:
    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(description="שלב 9 · מנהל הצילום")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--height", type=float, default=1.70)
    a = ap.parse_args(argv)
    rep = audit(a.height)
    if a.json:
        print(json.dumps(rep, ensure_ascii=False, indent=1))
        return 0 if rep["passed"] else 1
    print(f"=== {rep['task']} ===")
    print("דירוג האסטרטגיות (ציון · מידע שהועבר):")
    for k, sc, dv in rep["ranking"]:
        tag = "אמיתית" if k in REAL else "ביקורת"
        mark = "★" if k == rep["chosen"] else " "
        print(f" {mark} {k:18s} {sc:6.3f} · {dv:6.3f}  [{tag}]")
    print(f"\nנבחרה: {rep['chosen']}")
    for s in rep["why_shots"]:
        print(f"   {s['t'][0]:5.2f}-{s['t'][1]:5.2f}  {s['kind']:18s}"
              f" {s['move']:10s} {s['why']}")
    print("\nמבחני הקבלה:")
    for k, v in rep["checks"].items():
        print(f"  {'✓' if v['pass'] else '✗'} {k}: {v['value']} "
              f"(גבול {v['limit']})")
    print(f"\n{'עבר' if rep['passed'] else 'נכשל'} · {rep['seconds']}ש")
    return 0 if rep["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
