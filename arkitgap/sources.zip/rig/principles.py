# -*- coding: utf-8 -*-
"""TASK 07 · שנים-עשר עקרונות האנימציה, כמנגנון ולא כהצהרה.

    Implement professional animation principles:
    Anticipation · Squash & Stretch (where stylistically appropriate) ·
    Timing · Spacing · Arcs · Follow-through · Overlap · Ease-in ·
    Ease-out · Secondary action · Staging · Appeal.
    Create automated tests for each principle.

=== למה המודול הזה בנוי משני חצאים ולא מאחד ===

אפשר היה לכתוב "עקרונות" כאוסף פונקציות החלקה, להכריז שהן מיישמות
את התריסר, ולסיים. זה בדיוק מה שלא נעשה כאן, כי המשפט האחרון בדרישה
("Create automated tests for each principle") אינו תוספת - הוא מה
שקובע את הארכיטקטורה. בדיקה אוטומטית לעיקרון מחייבת ש**לעיקרון יהיה
מספר**. ולכן יש כאן:

* **מנוע** (`Move`, `chain`, `secondary`, `arc_path`, `squash`) -
  שמייצר את התנועה.
* **מדידות** (`m_*`) - שמסתכלות על העקומה שיצאה בפועל, פריים-פריים,
  ומחזירות מספר ופסק דין. המדידה **אינה יודעת** איך העקומה נוצרה;
  היא מקבלת מערך ערכים בזמן. לכן אי אפשר "לרמות" אותה בכך שמכריזים
  על דגל - צריך שהתנועה באמת תיראה כך.

זה גם מה שהופך את זה לשימושי מעבר לסצנות שלנו: `m_arcs` תגיד את
האמת גם על תנועה שמישהו אחר כתב.

=== שלושה דברים שנמדדו כאן ונפלו, ולכן כתובים בקוד ===

1. **אנטיציפציה חייבת להיות *נגדית*, לא "התחלה איטית".** הגרסה
   הראשונה האטה את תחילת התנועה וקראה לזה הכנה. `m_anticipation`
   דרסה אותה: אין סימן הפוך, אין ניקוד. הכנה היא תנועה **אחורה**
   לפני תנועה קדימה.
2. **Follow-through בלי חזרה אינו follow-through.** חריגה מעבר
   ליעד שנשארת שם היא פשוט יעד אחר. המדידה דורשת גם חריגה וגם
   החלפת סימן אחריה, כלומר התיישבות.
3. **Squash & stretch על דמות ריאליסטית הוא מלכודת.** הדרישה אומרת
   "where stylistically appropriate", ולכן זה **שער** ולא פרמטר:
   `squash` זורק `StyleError` מעל תקרה, ומחוץ להקשרים שמותר בהם.
   דמות אנושית שנמעכת כמו כדור גומי היא פגם, לא עיקרון.
"""
from __future__ import annotations

import math
import sys
from dataclasses import dataclass, field

import numpy as np

# =============================================================== רישום

#: שם -> (תיאור, שם פונקציית המדידה). הרישום הזה הוא מה שבדיקת
#: `audit` רצה עליו, ולכן עיקרון בלי מדידה פשוט לא יכול להתקיים כאן.
PRINCIPLES: dict[str, tuple[str, str]] = {
    "anticipation":   ("תנועה נגדית קטנה לפני התנועה העיקרית",
                       "m_anticipation"),
    "squash_stretch": ("מעיכה ומתיחה בשימור נפח, רק במקום שמתאים לסגנון",
                       "m_squash_stretch"),
    "timing":         ("כמה זמן לוקחת הפעולה - ומשקל מאט אותה",
                       "m_timing"),
    "spacing":        ("איך הזמן הזה מחולק: המרחק בין פריימים אינו אחיד",
                       "m_spacing"),
    "arcs":           ("מסלול קשתי ולא קו ישר בין שתי נקודות",
                       "m_arcs"),
    "follow_through": ("חריגה מעבר ליעד והתיישבות אחריה",
                       "m_follow_through"),
    "overlap":        ("חלקי גוף שאינם מגיעים לשיא באותו רגע",
                       "m_overlap"),
    "ease_in":        ("יציאה מהמנוחה במהירות אפס",
                       "m_ease_in"),
    "ease_out":       ("כניסה למנוחה במהירות אפס",
                       "m_ease_out"),
    "secondary":      ("תנועה נגררת, קטנה ומאוחרת מהראשית",
                       "m_secondary"),
    "staging":        ("הנושא קריא בפריים: ממורכז, מופרד, ולא חסום",
                       "m_staging"),
    "appeal":         ("קו פעולה ברור, אסימטריה, ומגוון בין הפוזות",
                       "m_appeal"),
}


class StyleError(ValueError):
    """שימוש בעיקרון במקום שבו הוא פוגע בסגנון הדמות."""


@dataclass
class Verdict:
    """תוצאת מדידה אחת: מספר, פסק דין, ומה נמדד."""
    principle: str
    ok: bool
    score: float
    detail: str = ""

    def __bool__(self) -> bool:
        return bool(self.ok)

    def as_dict(self) -> dict:
        return {"principle": self.principle, "ok": bool(self.ok),
                "score": round(float(self.score), 4), "detail": self.detail}


# =============================================================== החלקות

def smoothstep(u: float) -> float:
    """S רגיל: מהירות אפס בשני הקצוות."""
    u = max(0.0, min(1.0, u))
    return u * u * (3.0 - 2.0 * u)


def hermite(u: float, ease_in: float = 0.5, ease_out: float = 0.5) -> float:
    """S **א-סימטרי**. זה מה שמאפשר "יוצא לאט ונכנס מהר" ולהפך.

    ease_in=0 -> יציאה חדה (בלי ease-in), ease_in=1 -> יציאה רכה
    מאוד. אותו דבר לקצה השני. Hermite ולא cubic-bezier כי כאן
    הפרמטרים הם משיקים ישירות, ואין צורך בפתרון נומרי להיפוך.
    """
    u = max(0.0, min(1.0, u))
    ti = 2.0 * (1.0 - max(0.0, min(1.0, ease_in)))     # משיק בכניסה
    to = 2.0 * (1.0 - max(0.0, min(1.0, ease_out)))    # משיק ביציאה
    u2, u3 = u * u, u * u * u
    h00 = 2 * u3 - 3 * u2 + 1
    h10 = u3 - 2 * u2 + u
    h01 = -2 * u3 + 3 * u2
    h11 = u3 - u2
    return h00 * 0.0 + h10 * ti + h01 * 1.0 + h11 * to


# =============================================================== תנועה

@dataclass
class Move:
    """תנועה אחת של ערוץ אחד, שכל העקרונות אפויים לתוך העקומה שלה.

    זו היחידה שהסצנות עובדות איתה. היא נראית כמו "מ-0 ל-1 בחצי
    שנייה", אבל מה שיוצא הוא: הכנה נגדית -> פעולה עם ריווח לא אחיד
    -> חריגה -> התיישבות.
    """
    control: str
    start: float = 0.0
    dur: float = 0.5
    frm: float = 0.0
    to: float = 1.0
    #: **משקל הדבר שזז.** 0 = נוצה, 1 = ברירת מחדל, 2 = כבד. זה
    #: הפרמטר של Timing, והוא מאריך גם את ההכנה וגם את ההתיישבות -
    #: בדיוק כמו במציאות.
    weight: float = 1.0
    anticipate: float = 0.14      # שבר מהמהלך, בכיוון ההפוך
    overshoot: float = 0.12       # שבר מהמהלך, מעבר ליעד
    ease_in: float = 0.55
    ease_out: float = 0.70
    lag: float = 0.0              # Overlap: כמה הערוץ הזה מאחר
    note: str = ""

    # ---- חלונות הזמן

    @property
    def span(self) -> float:
        """אורך הפעולה העיקרית אחרי שקלול המשקל (Timing)."""
        return max(0.02, self.dur * (0.70 + 0.60 * max(0.0, self.weight)))

    @property
    def lead(self) -> float:
        """אורך ההכנה הנגדית. 0 כשאין הכנה."""
        if self.anticipate <= 0.0:
            return 0.0
        return self.span * 0.42 * (0.55 + 0.45 * max(0.0, self.weight))

    @property
    def settle(self) -> float:
        if self.overshoot <= 0.0:
            return 0.0
        return self.span * 0.55 * (0.5 + 0.5 * max(0.0, self.weight))

    @property
    def t0(self) -> float:
        return self.start + self.lag - self.lead

    @property
    def t1(self) -> float:
        return self.start + self.lag + self.span + self.settle

    @property
    def delta(self) -> float:
        return self.to - self.frm

    # ---- הערך בזמן

    def value(self, t: float) -> float:
        d = self.delta
        tt = float(t) - self.start - self.lag
        if tt <= -self.lead:
            return self.frm
        if tt < 0.0:
            # --- הכנה: יוצאים **אחורה**. smoothstep ולא easeOut, כדי
            #     שהיציאה מהמנוחה תהיה במהירות אפס (ease-in אמיתי).
            u = (tt + self.lead) / max(1e-6, self.lead)
            return self.frm - d * self.anticipate * smoothstep(u)
        if tt < self.span:
            u = tt / self.span
            v0 = self.frm - d * self.anticipate
            v1 = self.to + d * self.overshoot
            return v0 + (v1 - v0) * hermite(u, self.ease_in, self.ease_out)
        if self.settle > 0.0 and tt < self.span + self.settle:
            # --- התיישבות: תנודה דועכת סביב היעד. זה ה-follow-through,
            #     והוא **חייב** לחצות את היעד ולא רק להתקרב אליו.
            u = (tt - self.span) / self.settle
            amp = d * self.overshoot * math.exp(-4.2 * u)
            return self.to + amp * math.cos(math.pi * 1.5 * u)
        return self.to

    def sample(self, fps: int = 60, pad: float = 0.12) -> tuple:
        """(זמנים, ערכים) על כל חלון התנועה. זה מה שהמדידות מקבלות."""
        a, b = self.t0 - pad, self.t1 + pad
        n = max(8, int(round((b - a) * fps)))
        ts = np.linspace(a, b, n)
        return ts, np.array([self.value(float(t)) for t in ts])


def chain(control_lags: list[tuple[str, float]], **kw) -> list[Move]:
    """שרשרת Overlap: אותה תנועה, איברים שמגיעים בזמנים שונים.

    זו ההגשמה של Overlapping Action: האגן מוביל, היד אחריו, כף היד
    אחריה, והאצבעות אחרונות. ההפרש הוא מה שהעין קוראת כ"גוף אחד",
    והיעדרו הוא מה שנקרא "כל העצמות קפצו יחד".
    """
    out = []
    for name, lag in control_lags:
        out.append(Move(control=name, lag=float(lag), **kw))
    return out


def secondary(primary: list[float], amount: float = 0.30,
              lag_frames: int = 4, damp: float = 0.55) -> np.ndarray:
    """ערוץ נגרר: עוקב אחרי הראשי, קטן ממנו, ומגיע אחריו.

    מימוש כמסנן מדרגה ראשונה על סדרה מושהית, ולא כהעתק מוקטן:
    העתק מוקטן מגיע **באותו רגע** ולכן אינו תנועה משנית אלא חיקוי.
    """
    x = np.asarray(primary, dtype=float)
    n = len(x)
    if n == 0:
        return x
    sh = np.concatenate([np.full(min(lag_frames, n), x[0]),
                         x[:max(0, n - lag_frames)]])
    y = np.zeros(n)
    a = max(0.01, min(0.99, 1.0 - damp))
    for i in range(1, n):
        y[i] = y[i - 1] + a * (sh[i] - y[i - 1])
    return y * float(amount)


def arc_path(p0, p1, bulge: float = 0.18, up=(0.0, 1.0, 0.0),
             n: int = 48) -> np.ndarray:
    """מסלול קשת בין שתי נקודות (Bézier ריבועי), ולא קו ישר.

    הקשת היא העיקרון: גפה אנושית מסתובבת סביב מפרק, ולכן קצה היד
    **לא יכול** לנוע בקו ישר בלי שהגוף יזוז. יד שנעה בקו ישר
    נקראת מיד כזרוע רובוטית.
    """
    a = np.asarray(p0, float)
    b = np.asarray(p1, float)
    u = np.asarray(up, float)
    nu = np.linalg.norm(u)
    u = u / nu if nu > 1e-9 else np.array([0.0, 1.0, 0.0])
    mid = 0.5 * (a + b) + u * float(bulge) * float(np.linalg.norm(b - a))
    ts = np.linspace(0.0, 1.0, int(n))[:, None]
    return ((1 - ts) ** 2) * a + 2 * (1 - ts) * ts * mid + (ts ** 2) * b


# ====================================================== מעיכה ומתיחה

#: ההקשרים היחידים שבהם מעיכה/מתיחה מתאימה לדמות אנושית מסוגננת.
SQUASH_OK: tuple[str, ...] = ("jaw", "accent", "impact", "landing", "blink")
#: התקרה. 0.12 הוא כ-12% שינוי צורה - נראה בעין, ועדיין לא קריקטורה.
SQUASH_MAX = 0.12


def squash(amount: float, context: str = "jaw") -> tuple[float, float]:
    """(קנה מידה אנכי, קנה מידה רוחבי) בשימור נפח.

    amount חיובי = מתיחה לגובה, שלילי = מעיכה. הנפח נשמר בדיוק:
    `sy * sx**2 == 1`. **זו כל הנקודה של העיקרון** - צורה שמשנה
    נפח נראית כמו באג ולא כמו גמישות.
    """
    if context not in SQUASH_OK:
        raise StyleError(
            f"מעיכה/מתיחה אינה מתאימה בהקשר {context!r}. מותר רק ב: "
            f"{', '.join(SQUASH_OK)} - דמות ריאליסטית שנמעכת היא פגם.")
    a = float(amount)
    if abs(a) > SQUASH_MAX:
        raise StyleError(
            f"מעיכה של {a:.2f} חורגת מהתקרה {SQUASH_MAX} לדמות אנושית.")
    sy = 1.0 + a
    sx = 1.0 / math.sqrt(sy)
    return sy, sx


#: **שכבת הסגנון (TASK 13, 06/10).** התקרה של 0.12 נכונה לדמות
#: ריאליסטית, והיא נכונה *מדי* לדמות קריקטורה: זיגי וגרומפ נבנו
#: בשפת צורות מוגזמת (כדור מול קובייה), ואנימציית דיסני קלאסית
#: מעלה שם את המעיכה לעשרות אחוזים. במקום להרפות את השער - שהיה
#: פותח את ההגזמה גם על לוקאס ומאיה - נוספת כאן **דרגה**.
#:
#: הדרגה אינה מרפה שום בדיקה קיימת: `squash` נשאר כפי שהיה,
#: `tier="human"` הוא ברירת המחדל בכל מקום, ושימור הנפח נדרש
#: בדיוק אותו דבר בכל הדרגות - הגזמה אינה היתר לשנות נפח.
STYLE_TIERS: dict[str, dict] = {
    # דמות אנושית ריאליסטית. זהה בדיוק למה שהיה.
    "human": {"max": SQUASH_MAX,
              "ok": SQUASH_OK},
    # דמות אנושית מסוגננת: מותר גם בצעד ובעצירה, ועד 26%.
    "stylized": {"max": 0.26,
                 "ok": SQUASH_OK + ("step", "stop", "sigh")},
    # קריקטורה. ההקשרים של תנועת מקום (קפיצה, זינוק, הכנה) נפתחים,
    # והתקרה היא 45% - מעבר לזה הצורה מתמוססת ולא נקראת כדמות.
    "cartoon": {"max": 0.45,
                "ok": SQUASH_OK + ("step", "stop", "sigh", "jump",
                                   "anticipation", "stretch", "dart",
                                   "recoil")},
}

#: איזו דרגה מגיעה לכל דמות. דמות שאינה ברשימה מקבלת `human` -
#: ברירת מחדל שמרנית בכוונה: שכחה כאן צריכה להיכשל לכיוון הבטוח.
CHAR_TIER: dict[str, str] = {
    "lucas": "human", "maya": "human",
    "zippy": "cartoon", "grump": "stylized", "nutsy": "cartoon",
}


def tier_of(who: str) -> str:
    """הדרגה הסגנונית של דמות. לא מוכרת -> `human`."""
    return CHAR_TIER.get(str(who).lower(), "human")


def squash_styled(amount: float, context: str = "jaw",
                  tier: str = "human") -> tuple[float, float]:
    """כמו `squash`, אבל עם תקרה לפי דרגת הסגנון של הדמות.

    **שימור הנפח זהה בכל הדרגות.** זו הנקודה שאסור להתפשר בה: מה
    שהופך מעיכה מוגזמת לאנימציה ולא לבאג הוא שהנפח נשמר גם ב-45%.
    צורה שגדלה כשהיא נמעכת נראית כמו שגיאת סקייל.
    """
    t = STYLE_TIERS.get(str(tier))
    if t is None:
        raise StyleError(
            f"דרגת סגנון לא מוכרת: {tier!r}. מותר: "
            f"{', '.join(sorted(STYLE_TIERS))}")
    if context not in t["ok"]:
        raise StyleError(
            f"מעיכה/מתיחה אינה מתאימה בהקשר {context!r} בדרגה {tier!r}. "
            f"מותר רק ב: {', '.join(t['ok'])}")
    a = float(amount)
    if abs(a) > t["max"]:
        raise StyleError(
            f"מעיכה של {a:.2f} חורגת מהתקרה {t['max']} בדרגה {tier!r}.")
    sy = 1.0 + a
    sx = 1.0 / math.sqrt(sy)
    return sy, sx


def face_squash(jaw_open: float) -> dict:
    """הביטוי של שימור הנפח **בריג סיבובי**.

    לריג הזה אין קנה מידה על עצמות - רק סיבובים - ולכן מעיכה
    אמיתית אי אפשר להחיל על העצם. אבל הפנים *כן* יכולות: לסת
    שנפתחת מותחת את הפנים לגובה, והלחיים חייבות להישאב פנימה
    באותו שיעור. בלי זה פה פתוח נראה כאילו הראש גדל.
    """
    a = max(0.0, min(1.0, float(jaw_open))) * SQUASH_MAX
    _sy, sx = squash(a, "jaw")
    hollow = round((1.0 - sx) * 4.0, 4)       # 0..~0.23
    return {"cheek_hollow_L": hollow, "cheek_hollow_R": hollow}


# =============================================================== מדידות
#
# כולן מקבלות מערכים ומחזירות `Verdict`. אף אחת מהן אינה מקבלת את
# ה-`Move` עצמו - זו ההפרדה שמונעת מדידה שמסתכלת על הכוונה במקום
# על התוצאה.


def _vel(ts, vs) -> np.ndarray:
    ts = np.asarray(ts, float)
    vs = np.asarray(vs, float)
    if len(ts) < 2:
        return np.zeros(len(ts))
    return np.gradient(vs, ts)


def m_anticipation(ts, vs, min_frac: float = 0.03) -> Verdict:
    """לפני המהלך העיקרי יש תנועה בכיוון ההפוך."""
    vs = np.asarray(vs, float)
    ts = np.asarray(ts, float)
    base = float(vs[0])
    net = float(vs[-1] - base)
    if abs(net) < 1e-9:
        return Verdict("anticipation", False, 0.0, "אין מהלך בכלל")
    sgn = 1.0 if net > 0 else -1.0
    # הרגע שבו המהלך העיקרי מגיע למחצית הדרך
    half = base + 0.5 * net
    idx = int(np.argmax((vs - half) * sgn >= 0.0))
    pre = (vs[:idx] - base) * sgn
    if len(pre) == 0:
        return Verdict("anticipation", False, 0.0, "המהלך מתחיל בפריים הראשון")
    back = float(-pre.min())                 # כמה נסוג אחורה
    frac = back / abs(net)
    j = int(np.argmin(pre))
    lead = float(ts[idx] - ts[j]) if idx > j else 0.0
    ok = frac >= min_frac and lead > 1e-3
    return Verdict("anticipation", ok, round(frac, 4),
                   f"נסיגה של {frac:.1%} מהמהלך, {lead:.3f}ש לפניו")


def m_squash_stretch(pairs) -> Verdict:
    """שימור נפח: לכל (אנכי, רוחבי) מתקיים sy*sx²=1."""
    err = 0.0
    for sy, sx in pairs:
        err = max(err, abs(sy * sx * sx - 1.0))
    ok = err <= 0.01 and len(list(pairs)) > 0
    return Verdict("squash_stretch", ok, round(err, 5),
                   f"סטיית נפח מרבית {err:.4f}")


def m_timing(durations: list[float], weights: list[float]) -> Verdict:
    """כבד יותר = איטי יותר, מונוטונית."""
    if len(durations) < 2 or len(durations) != len(weights):
        return Verdict("timing", False, 0.0, "צריך לפחות שתי מדידות")
    order = np.argsort(weights)
    d = np.asarray(durations, float)[order]
    ok = bool(np.all(np.diff(d) > 1e-6))
    ratio = float(d[-1] / max(1e-9, d[0]))
    return Verdict("timing", ok, round(ratio, 4),
                   f"המשקל הכבד איטי פי {ratio:.2f} מהקל")


def m_spacing(ts, vs, min_ratio: float = 1.5) -> Verdict:
    """הריווח אינו אחיד: מהירות השיא גדולה בהרבה מהממוצעת.

    עקומה ליניארית נותנת יחס 1.0 בדיוק, ולכן היא **נכשלת** - וזו
    בדיוק המטרה. אינטרפולציה ליניארית היא הסימן המובהק של אנימציה
    ממוכנת.
    """
    v = np.abs(_vel(ts, vs))
    mv = float(v.mean())
    if mv < 1e-12:
        return Verdict("spacing", False, 0.0, "אין תנועה")
    # רק בתוך אזור התנועה, אחרת ריפוד של מנוחה מנפח את היחס
    act = v[v > mv * 0.05]
    ratio = float(act.max() / max(1e-12, act.mean()))
    return Verdict("spacing", ratio >= min_ratio, round(ratio, 4),
                   f"מהירות שיא פי {ratio:.2f} מהממוצעת")


def m_arcs(points, min_bow: float = 0.02) -> Verdict:
    """המסלול סוטה מהמיתר, והסטייה בכיוון אחד (קשת ולא זיגזג)."""
    p = np.asarray(points, float)
    if p.ndim != 2 or len(p) < 3:
        return Verdict("arcs", False, 0.0, "מסלול קצר מדי")
    a, b = p[0], p[-1]
    ab = b - a
    L = float(np.linalg.norm(ab))
    if L < 1e-9:
        return Verdict("arcs", False, 0.0, "נקודת התחלה וסוף זהות")
    u = ab / L
    rel = p - a
    proj = np.outer(rel @ u, u)
    off = rel - proj
    dist = np.linalg.norm(off, axis=1)
    bow = float(dist.max() / L)
    # כיוון הסטייה: כל הנקודות באותו צד של המיתר
    nrm = off[int(np.argmax(dist))]
    nn = np.linalg.norm(nrm)
    side = off @ (nrm / nn) if nn > 1e-9 else np.zeros(len(off))
    one_side = bool(np.all(side >= -1e-6 * L))
    return Verdict("arcs", bow >= min_bow and one_side, round(bow, 4),
                   f"קמירות {bow:.1%} מאורך המיתר, "
                   f"{'צד אחד' if one_side else 'זיגזג'}")


def m_follow_through(ts, vs, min_over: float = 0.02) -> Verdict:
    """חריגה מעבר ליעד **ואחריה** חזרה אליו."""
    vs = np.asarray(vs, float)
    target = float(vs[-1])
    base = float(vs[0])
    net = target - base
    if abs(net) < 1e-9:
        return Verdict("follow_through", False, 0.0, "אין מהלך")
    sgn = 1.0 if net > 0 else -1.0
    beyond = (vs - target) * sgn
    over = float(beyond.max())
    frac = over / abs(net)
    k = int(np.argmax(beyond))
    came_back = bool(np.any(beyond[k:] < over * 0.3))
    ok = frac >= min_over and came_back
    return Verdict("follow_through", ok, round(frac, 4),
                   f"חריגה {frac:.1%} מעבר ליעד"
                   f"{' והתיישבות' if came_back else ' בלי חזרה'}")


def m_overlap(curves: dict, ts, min_spread: float = 0.03) -> Verdict:
    """איברים שונים אינם מגיעים לשיא באותו רגע."""
    ts = np.asarray(ts, float)
    peaks = {}
    for name, vs in curves.items():
        v = np.abs(np.asarray(vs, float) - float(np.asarray(vs)[0]))
        peaks[name] = float(ts[int(np.argmax(v))])
    if len(peaks) < 2:
        return Verdict("overlap", False, 0.0, "צריך לפחות שני ערוצים")
    spread = max(peaks.values()) - min(peaks.values())
    return Verdict("overlap", spread >= min_spread, round(spread, 4),
                   "שיאים: " + ", ".join(f"{k} {v:.2f}ש"
                                         for k, v in peaks.items()))


def _edge_speed(ts, vs, head: bool) -> tuple[float, float]:
    """המהירות **ברגע שבו התנועה מתחילה** (או נגמרת), ביחס לשיא.

    **למה לא "המהירות המרבית בקצה החלון"** - וזו הגרסה הראשונה
    שנפלה כאן: חלון של 4% מהעקומה בלע את כל פרק האנטיציפציה, והחזיר
    19% גם על עקומה שיוצאת מהמנוחה במהירות אפס מדויקת. המדידה מדדה
    את אורך החלון, לא את ההחלקה.

    ההגדרה הנכונה היא נקודתית: ברגע שבו התנועה *מתחילה* (הדגימה
    הראשונה שעוברת 1% ממהירות השיא), כמה מהר היא כבר נעה. מדרגה
    או רמפה ליניארית קופצות שם מיד למהירות המלאה ומקבלות ~100%;
    עקומה עם ease יוצאת קרוב לאפס. ריפוד של מנוחה בקצוות אינו
    משפיע, כי הוא נחתך בתנאי ה-1%.
    """
    v = np.abs(_vel(ts, vs))
    pk = float(v.max()) or 1.0
    live = np.flatnonzero(v > 0.01 * pk)
    if not len(live):
        return 1.0, pk
    i = int(live[0] if head else live[-1])
    return float(v[i]) / pk, pk


def m_ease_in(ts, vs, max_frac: float = 0.12) -> Verdict:
    """יציאה מהמנוחה: המהירות ההתחלתית זניחה מול מהירות השיא."""
    f, _pk = _edge_speed(ts, vs, True)
    return Verdict("ease_in", f <= max_frac, round(f, 4),
                   f"מהירות בהתחלה {f:.1%} ממהירות השיא")


def m_ease_out(ts, vs, max_frac: float = 0.12) -> Verdict:
    f, _pk = _edge_speed(ts, vs, False)
    return Verdict("ease_out", f <= max_frac, round(f, 4),
                   f"מהירות בסוף {f:.1%} ממהירות השיא")


def m_secondary(primary, second, max_amp: float = 0.60) -> Verdict:
    """המשנית קטנה מהראשית, ומגיעה **אחריה**."""
    a = np.asarray(primary, float)
    b = np.asarray(second, float)
    n = min(len(a), len(b))
    a, b = a[:n] - a[:n].mean(), b[:n] - b[:n].mean()
    ra = float(np.abs(a).max()) or 1e-9
    rb = float(np.abs(b).max())
    amp = rb / ra
    best, blag = -2.0, 0
    for lag in range(0, max(2, n // 4)):
        x = a[:n - lag] if lag else a
        y = b[lag:] if lag else b
        if len(x) < 4:
            break
        sx, sy = x.std(), y.std()
        if sx < 1e-12 or sy < 1e-12:
            continue
        c = float(np.corrcoef(x, y)[0, 1])
        if c > best:
            best, blag = c, lag
    ok = 0.0 < amp <= max_amp and blag > 0 and best > 0.5
    return Verdict("secondary", ok, round(amp, 4),
                   f"משרעת {amp:.0%} מהראשית, פיגור {blag} פריימים, "
                   f"מתאם {best:.2f}")


@dataclass
class Staging:
    """הקומפוזיציה של שוט אחד, כמספרים שאפשר למדוד."""
    subject_x: float                 # מיקום הנושא בציר X של העולם
    others_x: list[float] = field(default_factory=list)
    cam_tx: float = 0.0              # לאן המצלמה מכוונת
    subject_w: float = 0.42          # רוחב הדמות
    caption: str = ""
    gaze_into_frame: bool = True


def m_staging(st: Staging) -> Verdict:
    """הנושא קריא: קרוב למרכז יותר מכל אחר, ולא חופף לאיש."""
    d_sub = abs(st.subject_x - st.cam_tx)
    d_oth = [abs(x - st.cam_tx) for x in st.others_x]
    centered = all(d_sub < d for d in d_oth) if d_oth else d_sub < 0.35
    sep = min((abs(st.subject_x - x) for x in st.others_x), default=9.9)
    clear = sep >= st.subject_w
    ok = bool(centered and clear and st.caption.strip()
              and st.gaze_into_frame)
    return Verdict("staging", ok, round(sep, 4),
                   f"נושא במרחק {d_sub:.2f} מהמרכז, הפרדה {sep:.2f}, "
                   f"{'כתובית' if st.caption.strip() else 'בלי כתובית'}")


_PAIRED = ("smile", "brow_up", "brow_inner_up", "shoulder_up", "shoulder_fwd",
           "squint", "blink", "arm_down", "elbow", "foot_turn")


def m_appeal(poses: list[dict], min_asym: float = 0.01,
             min_line: float = 0.02, min_var: float = 0.03) -> Verdict:
    """שלושה תנאים: קו פעולה, אסימטריה, ומגוון בין הפוזות.

    "Appeal" נשמע כמו טעם, ולכן קל לוותר על מדידתו. אבל שלושת
    הדברים שהופכים פוזה לקריאה הם מדידים לחלוטין: קו פעולה אחד
    ברור (הגוף אינו ישר כמו מוט), אסימטריה (פוזה סימטרית היא
    פוזת בובה), ומגוון (שתי פוזות זהות הן פוזה אחת).
    """
    if not poses:
        return Verdict("appeal", False, 0.0, "אין פוזות")
    asym = []
    line = []
    for p in poses:
        a = [abs(p.get(f"{b}_L", 0.0) - p.get(f"{b}_R", 0.0))
             for b in _PAIRED]
        asym.append(max(a) if a else 0.0)
        line.append(abs(p.get("spine_side", 0.0))
                    + abs(p.get("spine_bend", 0.0))
                    + abs(p.get("head_roll", 0.0))
                    + abs(p.get("weight_shift", 0.0)))
    keys = sorted({k for p in poses for k in p})
    var = 9.9
    for i in range(len(poses)):
        for j in range(i + 1, len(poses)):
            d = max(abs(poses[i].get(k, 0.0) - poses[j].get(k, 0.0))
                    for k in keys) if keys else 0.0
            var = min(var, d)
    if len(poses) < 2:
        var = 9.9
    ok = (min(asym) >= min_asym and min(line) >= min_line
          and var >= min_var)
    return Verdict("appeal", ok, round(min(asym), 4),
                   f"אסימטריה מזערית {min(asym):.3f}, קו פעולה "
                   f"{min(line):.3f}, מרחק בין פוזות {var:.3f}")


# =============================================================== דוח

def reference_move(weight: float = 1.0) -> Move:
    """התנועה שכל המדידות נבדקות עליה. זו גם הדוגמה לשימוש."""
    return Move("head_yaw", start=0.40, dur=0.46, frm=0.0, to=0.55,
                weight=weight, note="פניית ראש אל הדובר")


def audit(fps: int = 120) -> dict:
    """מריץ את שתים-עשרה המדידות על תנועה אמיתית. זה לב TASK 07."""
    mv = reference_move()
    ts, vs = mv.sample(fps)

    # Overlap + Secondary: שרשרת אמיתית של ארבעה איברים
    ch = chain([("hips_yaw", 0.0), ("spine_twist", 0.05),
                ("neck_yaw", 0.10), ("head_yaw", 0.16)],
               start=0.40, dur=0.46, to=0.5)
    cts = np.linspace(0.0, 1.8, int(1.8 * fps))
    curves = {m.control: np.array([m.value(float(t)) for t in cts])
              for m in ch}
    sec = secondary(curves["head_yaw"], amount=0.28,
                    lag_frames=max(2, fps // 15))

    # Timing: אותה תנועה בשלושה משקלים
    durs, ws = [], [0.25, 1.0, 2.0]
    for w in ws:
        m = reference_move(w)
        durs.append(m.span + m.lead + m.settle)

    # Squash: שרשרת ערכים בשימור נפח
    pairs = [squash(a, "jaw") for a in (-0.10, -0.04, 0.0, 0.06, 0.12)]

    # Arcs: מסלול יד
    pts = arc_path((0.18, 0.92, 0.10), (0.34, 1.38, 0.30), bulge=0.22)

    # Staging + Appeal: מצב אמיתי מהסצנות
    stg = Staging(subject_x=0.53, others_x=[-0.53], cam_tx=0.53,
                  caption="מי מדבר נמצא במרכז, והשני מופרד ממנו")
    poses = [{"spine_side": -0.14, "spine_bend": 0.06, "head_roll": 0.05,
              "weight_shift": 0.42, "smile_L": 0.30, "smile_R": 0.18,
              "shoulder_up_L": 0.12, "shoulder_up_R": 0.26},
             {"spine_side": 0.11, "spine_bend": -0.09, "head_roll": -0.04,
              "weight_shift": -0.38, "smile_L": -0.10, "smile_R": 0.04,
              "shoulder_up_L": 0.31, "shoulder_up_R": 0.09}]

    res = [
        m_anticipation(ts, vs),
        m_squash_stretch(pairs),
        m_timing(durs, ws),
        m_spacing(ts, vs),
        m_arcs(pts),
        m_follow_through(ts, vs),
        m_overlap(curves, cts),
        m_ease_in(ts, vs),
        m_ease_out(ts, vs),
        m_secondary(curves["head_yaw"], sec),
        m_staging(stg),
        m_appeal(poses),
    ]
    got = {v.principle for v in res}
    missing = [p for p in PRINCIPLES if p not in got]
    return {"principles": len(PRINCIPLES), "measured": len(res),
            "missing": missing,
            "passed": sum(1 for v in res if v.ok),
            "results": [v.as_dict() for v in res]}


def main(argv=None) -> int:
    sys.stdout.reconfigure(encoding="utf-8")
    rep = audit()
    print("=== TASK 07 · עקרונות האנימציה ===")
    print(f"עקרונות ברישום: {rep['principles']} · נמדדו: {rep['measured']} · "
          f"עברו: {rep['passed']}")
    if rep["missing"]:
        print("חסרה מדידה ל:", ", ".join(rep["missing"]))
    for r in rep["results"]:
        mark = "✓" if r["ok"] else "✗"
        desc = PRINCIPLES[r["principle"]][0]
        print(f"  {mark} {r['principle']:15s} {r['score']:>8}  {desc}")
        print(f"      {r['detail']}")
    return 0 if rep["passed"] == rep["measured"] and not rep["missing"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
