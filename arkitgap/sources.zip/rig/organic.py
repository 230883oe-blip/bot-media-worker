# -*- coding: utf-8 -*-
"""משטחים אורגניים: Catmull-Clark אמיתי על הרשת הבנויה.

למה המודול הזה קיים, ומה הוא מחליף
-----------------------------------
עד 06/10 כל ה"ריכוך" של הדמויות היה **כיול פרמטרים**: עוד `_smoothstep`
על רדיוס, עוד מכפיל קמירות, עוד הנמכת מדף. זה עובר את המודדים המספריים
ולא משנה את הגאומטריה - קודקוד שיושב על קצה בן 131° נשאר שם, כי אף שלב
בצינור לא *מחליק* משטח. התיעוד ב-`basemesh` מצהיר במפורש שהטופולוגיה
היא quad מסודר "כדי שהחלקה ו-subdivision יעבדו אחר כך" - והשלב הזה
מעולם לא נכתב.

נמדד 06/10 על `zippy` לפני המודול הזה:
    ראש - חציון 0.94°, p99 **90.00°**, max 131.81°, 1.81% מהצלעות מעל 20°
    טורסו - חציון 1.06°, p99 60.44°, 4.47% מעל 20°
    464 פאות מנוונות (שטח אפס)
חציון חלק מול p99 של 90° הוא בדיוק החתימה של "גוש עם פינות": רוב
המשטח חלק, ואחוז אחד של קצוות חדים הוא כל מה שהעין רואה.

מה כן נעשה כאן
---------------
1. **שחזור ה-quads.** `MeshBuilder.quad(a,b,c,d)` פולט תמיד זוג משולשים
   עוקב `(a,b,c)` + `(a,c,d)`, ולכן הפוליגון המקורי משוחזר דטרמיניסטית
   מהאינדקסים. בלי זה היינו מחליקים רשת משולשים (Loop) שאין לה שום קשר
   לטופולוגיה שנבנתה, וקצה הפוליגון היה נמרח באלכסון.
2. **העמדה הגבולית של Catmull-Clark** (Halstead/Kass/DeRose 1993):

       V∞ = (n²·V + 4·ΣE + ΣF) / (n·(n+5))

   E = אמצעי הצלעות, F = מרכזי הפאות, n = דרגת הקודקוד. זו **אותה
   נקודה** שאליה מתכנסת חלוקת משטח אין-סופית, בלי להוסיף אף קודקוד.
   לכן אין כאן תשלום בזיכרון, ב-GLB או בזמן רינדור - והמשטח הוא
   משטח Catmull-Clark לכל דבר.
   זה **אינו** החלקה לפלסיאנית: לפלסיאן מכווץ נפח ומוריד את האף עד
   שהוא נעלם; הנוסחה הזו משמרת את הצורה ומסירה רק את הקצה.
3. **קצה מכוון נשמר כעקומה, לא כפינה.** קו השפתיים, הנחיר וקו השיער
   חייבים להישאר חדים - אחרת הפה נמרח, וזה בדיוק מה שהתיעוד של
   `_head` אוסר. לכן צלע שהיא גבול בין שתי תגיות היא `crease`, ועליה
   עובדת נוסחת ה-limit של B-spline מדרגה שלוש לאורך הקו:

       V∞ = (V_prev + 4·V + V_next) / 6

   כלומר הקצה נשאר קצה - אבל הוא הופך מקו שבור **לעקומה רציפה**,
   שזו בדיוק הדרישה "עקומות Bezier במקום חתכים ישרים".
4. **פינה אמיתית נשארת במקומה.** קודקוד עם שלוש צלעות crease ומעלה
   (צומת של שלושה אזורים) מוקפא. החלקה שלו הייתה פותחת חור בין
   השפה, הנחיר והעור.

ובנוסף `subdivide()` - חלוקת משטח אמיתית שמכפילה את הרשת, לשימוש
בתקריבים ובמדידה. היא **אינה** בצינור הייצור: 37 אלף קודקודים הופכים
ל-150 אלף, והמכונה כאן חנוקה בזיכרון.
"""
from __future__ import annotations

import math
from collections import defaultdict

import numpy as np

# תגיות שהגבול שלהן הוא קצה **מכוון**, ולכן אינו מוחלק. כל גבול בין
# שתי תגיות שונות הוא crease ממילא; הרשימה הזו היא למי שצריך קצה חד
# גם *בתוך* האזור של עצמו (חריץ, קו).
SHARP_TAGS = ("lip_line", "nostril", "lip_up", "lip_lo", "limbal",
              "iris", "catch", "lash")

# אזורים שאינם מוחלקים כלל: גוף קשיח שההחלקה רק מעגלת לו את הצורה
# המכוונת. גלגל העין הוא כדור מושלם מעצם הבנייה ואין בו מה להחליק,
# והמשקפיים הן אובייקט תעשייתי - עדשה מעוגלת אינה עדשה.
RIGID_GROUPS = ("eyeball", "glasses", "tongue")


# ---------------------------------------------------------------- טופולוגיה

def quads_from_tris(idx: np.ndarray) -> list[tuple[int, ...]]:
    """משחזר את הפוליגונים המקוריים מרשימת המשולשים.

    `MeshBuilder.quad` פולטת `(a,b,c)` ואחריו מיד `(a,c,d)`. זוג עוקב
    שמקיים את התבנית הזו הוא quad; מה שלא - נשאר משולש.

    למה לא לזהות quad לפי "שני משולשים שחולקים צלע": באזורי הכיפה
    (`cap`) יש משולשים אמיתיים שחולקים צלעות עם quad-ים, והזיהוי הזה
    היה מאחד אותם לפוליגונים מעוקמים שלא נבנו מעולם.
    """
    tri = np.asarray(idx, np.int64).reshape(-1, 3)
    out: list[tuple[int, ...]] = []
    i, n = 0, len(tri)
    while i < n:
        if i + 1 < n:
            a, b, c = tri[i]
            a2, c2, d = tri[i + 1]
            if a2 == a and c2 == c and d != b:
                out.append((int(a), int(b), int(c), int(d)))
                i += 2
                continue
        out.append(tuple(int(x) for x in tri[i]))
        i += 1
    return out


class Topo:
    """שכנות קודקוד/צלע/פאה על רשת פוליגונים."""

    def __init__(self, faces: list[tuple[int, ...]], n: int):
        self.faces = faces
        self.n = n
        self.vf: list[list[int]] = [[] for _ in range(n)]
        ef: dict[tuple[int, int], list[int]] = defaultdict(list)
        for fi, f in enumerate(faces):
            L = len(f)
            for j in range(L):
                a, b = f[j], f[(j + 1) % L]
                ef[(a, b) if a < b else (b, a)].append(fi)
                self.vf[a].append(fi)
        self.ef = ef
        self.ve: list[list[int]] = [[] for _ in range(n)]
        self.edges = list(ef)
        for ei, (a, b) in enumerate(self.edges):
            self.ve[a].append(ei)
            self.ve[b].append(ei)


# ------------------------------------------------------------------ creases

def crease_edges(topo: Topo, tag: np.ndarray | None,
                 rigid: np.ndarray | None = None) -> np.ndarray:
    """מחזיר דגל לכל צלע: האם היא קצה שאסור להחליק.

    שלוש סיבות להיות crease, וכל אחת מהן נמדדה כנחוצה:
    * **גבול** (פאה אחת בלבד) - החלקה חופשית שם מכווצת את השפה פנימה
      ופותחת פער בין חלקים שנבנו בנפרד (האוזן אל הראש, הכובע אל
      הגולגולת).
    * **גבול תגיות** - שם יושב קו השפתיים, הנחיר וקו השיער. זה הקצה
      שהתיעוד של `_head` דורש להשאיר חד ("קצה גאומטרי חד תמיד").
    * **מעבר אל אזור קשיח** - הגבול בין העור לגלגל העין.
    """
    E = len(topo.edges)
    cr = np.zeros(E, bool)
    for ei, (a, b) in enumerate(topo.edges):
        fs = topo.ef[(a, b)]
        if len(fs) != 2:
            cr[ei] = True
            continue
        if tag is not None and tag[a] != tag[b]:
            cr[ei] = True
            continue
        if tag is not None and tag[a] in SHARP_TAGS:
            cr[ei] = True
            continue
        if rigid is not None and rigid[a] != rigid[b]:
            cr[ei] = True
    return cr


def _is_boundary(topo: Topo, ei: int) -> bool:
    return len(topo.ef[topo.edges[ei]]) != 2


def vertex_kind(topo: Topo, cr: np.ndarray) -> np.ndarray:
    """0 = חלק, 1 = על קו crease, 2 = פינה (מוקפא).

    הספירה היא של **צלעות** crease ולא של שכנים: קודקוד שיושב באמצע
    קו השפתיים נוגע בשתי צלעות של הקו, ולכן הוא מוחלק *לאורך* הקו -
    וזה מה שהופך קו שבור לעקומה. קודקוד שבו נפגשים שלושה אזורים נוגע
    בשלוש, והוא היחיד שחייב להישאר במקומו בדיוק.
    """
    cnt = np.zeros(topo.n, np.int32)
    bnd = np.zeros(topo.n, np.int32)
    for ei, (a, b) in enumerate(topo.edges):
        if not cr[ei]:
            continue
        cnt[a] += 1
        cnt[b] += 1
        if _is_boundary(topo, ei):
            bnd[a] += 1
            bnd[b] += 1
    kind = np.zeros(topo.n, np.int8)
    kind[cnt == 2] = 1
    kind[cnt >= 3] = 2
    # **`cnt == 1` אינו קצה של קו, אלא אם הצלע היא גבול אמיתי.**
    # זה היה באג שנמדד ב-06/10: 256 קודקודי *עור* הוקפאו, וההחלקה
    # ייצרה מדרגות חדשות - ה-p99 של הראש עלה מ-10.24° ל-13.47°
    # במקום לרדת. התחקיר הראה שכולם קודקודי עור שנוגעים בנקודה
    # בודדת בגבול של אזור שכן (סומק 114, שיער 90, קו שפתיים 36,
    # נחיר 16), **וכל 256 הצלעות האלה הן פנימיות** (שתי פאות).
    # קודקוד כזה אינו קצה של שום קו - הוא קודקוד פנימי רגיל
    # שבמקרה שכנו מתויג אחרת, והקפאה שלו בזמן שכל סביבתו זזה היא
    # בדיוק מה שמייצר את המדרגה שההחלקה באה להסיר.
    # קצה של קו **פתוח** (צלע שיש לה פאה אחת) כן מוקפא: שם החלקה
    # חופשית מכווצת את השפה ופותחת פער בין חלקים שנבנו בנפרד.
    kind[(cnt == 1) & (bnd == 0)] = 0
    kind[(cnt == 1) & (bnd > 0)] = 2
    return kind


# -------------------------------------------- העמדה הגבולית של Catmull-Clark

def limit_positions(pos: np.ndarray, topo: Topo, cr: np.ndarray,
                    kind: np.ndarray) -> np.ndarray:
    """V∞ של משטח Catmull-Clark, בלי להוסיף קודקודים.

    לקודקוד חלק בדרגה n:   (n²V + 4ΣE + ΣF) / (n(n+5))
    לקודקוד על קו crease:  (V_prev + 4V + V_next) / 6
    לפינה:                 V
    """
    pos = np.asarray(pos, np.float64)
    out = pos.copy()
    cent = np.zeros((len(topo.faces), 3))
    for fi, f in enumerate(topo.faces):
        cent[fi] = pos[list(f)].mean(axis=0)

    for v in range(topo.n):
        if kind[v] == 2:
            continue
        if kind[v] == 1:
            nb = [(b if a == v else a) for ei in topo.ve[v]
                  if cr[ei] for a, b in (topo.edges[ei],)]
            if len(nb) != 2:
                continue
            out[v] = (pos[nb[0]] + 4.0 * pos[v] + pos[nb[1]]) / 6.0
            continue
        ev = topo.ve[v]
        n = len(ev)
        if n < 3:
            continue
        sE = np.zeros(3)
        for ei in ev:
            a, b = topo.edges[ei]
            sE += 0.5 * (pos[a] + pos[b])
        fs = set(topo.vf[v])
        sF = cent[list(fs)].sum(axis=0) if fs else np.zeros(3)
        # הנוסחה מניחה שדרגת הקודקוד שווה למספר הפאות שסביבו (רשת
        # סגורה). כשזה לא כך - מנרמלים את תרומת הפאות למספר הצלעות,
        # אחרת קודקוד עם פאה חסרה נמשך לכיוון שיש בו פאות.
        if fs and len(fs) != n:
            sF = sF * (n / len(fs))
        out[v] = (n * n * pos[v] + 4.0 * sE + sF) / (n * (n + 5.0))
    return out


def smooth(pos: np.ndarray, idx: np.ndarray,
           tag: np.ndarray | None = None,
           rigid: np.ndarray | None = None,
           passes: int = 1, strength: float = 1.0,
           topo: Topo | None = None) -> np.ndarray:
    """מחליק את הרשת למשטח Catmull-Clark הגבולי שלה.

    `strength` < 1 מערבב עם המקור. זה **לא** כיול של צורה אלא בלם
    בטיחות לאזור שבו נמדד שההחלקה המלאה מוציאה פרט מכוון; ברירת
    המחדל היא 1.0, כלומר המשטח האמיתי.
    """
    pos = np.asarray(pos, np.float64)
    faces = quads_from_tris(idx)
    topo = topo or Topo(faces, len(pos))
    cr = crease_edges(topo, tag, rigid)
    kind = vertex_kind(topo, cr)
    cur = pos
    for _ in range(max(0, passes)):
        lim = limit_positions(cur, topo, cr, kind)
        cur = lim if strength >= 1.0 else cur + (lim - cur) * strength
    if rigid is not None:
        cur = np.where(np.asarray(rigid, bool)[:, None], pos, cur)
    return cur


# -------------------------------------------------- חלוקת משטח אמיתית (כפלה)

def subdivide(pos: np.ndarray, idx: np.ndarray,
              tag: np.ndarray | None = None) -> tuple[np.ndarray, np.ndarray]:
    """שלב Catmull-Clark אמיתי: מחזיר רשת חדשה, צפופה פי ~4.

    לא בצינור הייצור (זיכרון), אלא לתקריב ולמדידה - היא ההוכחה
    שהמשטח שאליו `smooth` מצמידה הוא אכן המשטח הזה.
    """
    pos = np.asarray(pos, np.float64)
    faces = quads_from_tris(idx)
    topo = Topo(faces, len(pos))
    cr = crease_edges(topo, tag, None)
    kind = vertex_kind(topo, cr)

    fp = np.array([pos[list(f)].mean(axis=0) for f in faces]) \
        if faces else np.zeros((0, 3))
    f_off = len(pos)
    e_off = f_off + len(faces)

    ep = np.zeros((len(topo.edges), 3))
    eidx = {}
    for ei, (a, b) in enumerate(topo.edges):
        eidx[(a, b)] = ei
        fs = topo.ef[(a, b)]
        if cr[ei] or len(fs) != 2:
            ep[ei] = 0.5 * (pos[a] + pos[b])
        else:
            ep[ei] = (pos[a] + pos[b] + fp[fs[0]] + fp[fs[1]]) / 4.0

    # קודקוד מקורי מוזז לפי כלל ה-vertex של Catmull-Clark
    vp = pos.copy()
    for v in range(len(pos)):
        if kind[v] == 2:
            continue
        if kind[v] == 1:
            nb = [(b if a == v else a) for ei in topo.ve[v]
                  if cr[ei] for a, b in (topo.edges[ei],)]
            if len(nb) == 2:
                vp[v] = 0.75 * pos[v] + 0.125 * (pos[nb[0]] + pos[nb[1]])
            continue
        ev, fsv = topo.ve[v], sorted(set(topo.vf[v]))
        n = len(ev)
        if n < 3 or not fsv:
            continue
        Q = fp[fsv].mean(axis=0)
        Rm = np.mean([0.5 * (pos[a] + pos[b])
                      for a, b in (topo.edges[ei] for ei in ev)], axis=0)
        vp[v] = (Q + 2.0 * Rm + (n - 3.0) * pos[v]) / n

    new = np.concatenate([vp, fp, ep]) if len(faces) else vp
    tris: list[tuple[int, int, int]] = []
    for fi, f in enumerate(faces):
        L = len(f)
        c = f_off + fi
        for j in range(L):
            a, b, d = f[j], f[(j + 1) % L], f[(j - 1) % L]
            e1 = e_off + eidx[(a, b) if a < b else (b, a)]
            e2 = e_off + eidx[(d, a) if d < a else (a, d)]
            tris.append((a, e1, c))
            tris.append((a, c, e2))
    return new, np.asarray(tris, np.uint32).reshape(-1)


# ------------------------------------------------------------------- מודדים

def dihedral(pos: np.ndarray, idx: np.ndarray,
             vmask: np.ndarray | None = None,
             tag: np.ndarray | None = None) -> np.ndarray:
    """הזוויות הדיהדרליות (במעלות) על צלעות פנימיות.

    זה המודד שהיה חסר. `appeal.shape_language` מודד **צללית** - כמה
    הגוש עגול מבחוץ - ועובר בהצלחה גם על גוש עם פינות, כי פינה של
    מילימטר אינה מזיזה צללית. מה שהעין קוראת כ"מכני" הוא עקמומיות
    *מקומית*, והיא נמדדת רק כאן.
    """
    pos = np.asarray(pos, np.float64)
    tri = np.asarray(idx, np.int64).reshape(-1, 3)
    a, b, c = pos[tri[:, 0]], pos[tri[:, 1]], pos[tri[:, 2]]
    nrm = np.cross(b - a, c - a)
    L = np.linalg.norm(nrm, axis=1)
    live = L > 1e-14
    Ls = L.copy()
    Ls[~live] = 1.0
    nrm = nrm / Ls[:, None]
    ef = defaultdict(list)
    sel = np.nonzero(live)[0]
    if vmask is not None:
        vmask = np.asarray(vmask, bool)
        sel = sel[vmask[tri[sel]].all(axis=1)]
    for fi in sel:
        i, j, k = tri[fi]
        for e in ((i, j), (j, k), (k, i)):
            ef[(e[0], e[1]) if e[0] < e[1] else (e[1], e[0])].append(fi)
    out = []
    tag = None if tag is None else np.asarray(tag).astype(str)
    for (i, j), fs in ef.items():
        if len(fs) != 2:
            continue
        # קצה מכוון אינו פגם, ולכן אינו נמדד: גבול בין שתי תגיות,
        # או צלע בתוך אזור שכל כולו קו (שפה, נחיר, קשתית).
        if tag is not None and (tag[i] != tag[j] or tag[i] in SHARP_TAGS):
            continue
        d = float(np.clip(float(np.dot(nrm[fs[0]], nrm[fs[1]])), -1.0, 1.0))
        out.append(math.degrees(math.acos(d)))
    return np.asarray(out, float)


def degenerate_faces(pos: np.ndarray, idx: np.ndarray) -> int:
    """מספר הפאות בשטח אפס. כל אחת מהן היא נורמל אבוד, כלומר כתם."""
    pos = np.asarray(pos, np.float64)
    tri = np.asarray(idx, np.int64).reshape(-1, 3)
    n = np.cross(pos[tri[:, 1]] - pos[tri[:, 0]],
                 pos[tri[:, 2]] - pos[tri[:, 0]])
    return int((np.linalg.norm(n, axis=1) < 1e-14).sum())


def smoothness(pos: np.ndarray, idx: np.ndarray,
               vmask: np.ndarray | None = None,
               tag: np.ndarray | None = None) -> dict:
    """ציון החלקה אורגנית של משטח. גבוה = אורגני.

    `tag` מחריג את הקצוות ה**מכוונים** - קו השפתיים, הנחיר, גבול
    הקשתית. בלעדיו המודד סופר בדיוק את מה שהתיעוד של `_head` דורש
    לשמור ("קצה גאומטרי חד תמיד"): נמדד 06/10 ש-p99 של `zippy` נשאר
    131.81° דרך כל התיקונים, כי זה חריץ השפתיים - והציון יצא 0.0
    על דמות שהשתפרה פי עשרים. מודד שקונס על פרט מכוון דוחף לשטח
    את הפה, ואז "ציון גבוה" פירושו דמות בלי תווי פנים.
    """
    A = dihedral(pos, idx, vmask, tag)
    if len(A) == 0:
        return {"edges": 0, "median": 0.0, "p99": 0.0,
                "max": 0.0, "over20": 0.0, "score": 0.0}
    p99 = float(np.percentile(A, 99))
    over = float(np.mean(A > 20.0))
    # הציון נבנה מ-p99 ומהשיעור מעל 20° ולא מהחציון: חציון של 0.9°
    # הוא תכונה של רשת צפופה ולא של צורה, והוא היה 0.94° גם כשהאף
    # היה סכין. מה שהעין רואה הוא הזנב.
    return {"edges": len(A),
            "median": round(float(np.median(A)), 3),
            "p99": round(p99, 2),
            "max": round(float(A.max()), 2),
            "over20": round(100.0 * over, 3),
            "score": round(max(0.0, 1.0 - p99 / 90.0) * (1.0 - over), 4)}


# ------------------------------------------------------ עקומת צוואר רציפה

def hermite(p0, p1, m0, m1, t: float) -> np.ndarray:
    """קטע Hermite קובי. זהה ל-Bezier קובי עם נקודות בקרה
    `p0 + m0/3` ו-`p1 - m1/3`, ונוח יותר כאן כי מה שידוע לנו הוא
    **המשיקים** בקצוות (כיוון עמוד השדרה למטה, ציר הגולגולת למעלה)
    ולא נקודות בקרה שרירותיות.

    זה מה שמחליף את `P["neck"] + (P["head"] - P["neck"]) * (t-1) * 3.2` -
    קו **ישר** שעבר בין בסיס הגולגולת לחזה, ולכן בנקודת החיבור יש
    מדרגת משיק: הצוואר יצא צינור גלילי שנדחף לתוך כתפיים, במקום
    עקומת S רציפה.
    """
    p0 = np.asarray(p0, float)
    p1 = np.asarray(p1, float)
    m0 = np.asarray(m0, float)
    m1 = np.asarray(m1, float)
    t2, t3 = t * t, t * t * t
    return ((2 * t3 - 3 * t2 + 1) * p0 + (t3 - 2 * t2 + t) * m0
            + (-2 * t3 + 3 * t2) * p1 + (t3 - t2) * m1)


def polyline_break(pts) -> float:
    """השבר המשיק המרבי (מעלות) בקו שבור דו-ממדי.

    **זה אינו `tangent_break`, וזה לא פרט.** `tangent_break` מודד את
    שרשרת **מרכזי** הטבעות, כלומר את הציר שעליו הגוף בנוי. הקו
    שהעין רואה הוא קו ה**צללית** - חצי-הרוחב כפונקציה של גובה - והם
    שני דברים נפרדים לגמרי: נמדד 06/10 שהציר חלק ל-2.32° בעוד
    הצללית שבורה ב-58° באותה דמות עצמה, כי הרוחב צונח מ-169 מ"מ
    ל-78 מ"מ דרך טבעת ביניים אחת. שער שמודד רק את הציר עובר על
    "צוואר-צינור שנדחף לתוך חולצה" בלי להרגיש.

    הקואורדינטות חייבות להיות באותן יחידות (מטרים), ולכן `t` של
    הפרופיל אינו קביל כאן: הוא דחוס פי 3.2 מעל מפרק הצוואר, ומדידה
    עליו החזירה 38.9° במקום 51.0° על אותה צללית.
    """
    P = [np.asarray(p, float) for p in pts]
    worst = 0.0
    for i in range(1, len(P) - 1):
        a, b = P[i] - P[i - 1], P[i + 1] - P[i]
        na, nb = float(np.linalg.norm(a)), float(np.linalg.norm(b))
        if na < 1e-9 or nb < 1e-9:
            continue
        c = float(np.clip(float(np.dot(a, b)) / (na * nb), -1.0, 1.0))
        worst = max(worst, math.degrees(math.acos(c)))
    return worst


def catmull_rom(ctrl, u: float, alpha: float = 0.5) -> np.ndarray:
    """נקודה על ספליין Catmull-Rom צנטריפטלי העובר דרך **כל** נקודות
    הבקרה. `u` נמדד בקטעים הפנימיים: u=0 הוא `ctrl[1]`, u=1 הוא
    `ctrl[2]`, וכן הלאה עד u=len(ctrl)-3. אקסטרפולציה מעבר לקצה
    ממשיכה את הקטע האחרון, ולכן טבעת שחורגת מעל מפרק הראש אינה
    "נופלת מהעקומה".

    **למה זה, ולא `hermite`.** `hermite` דורש משיקים שמישהו צריך
    לנחש, ו-06/10 נמדד שניחוש כזה (המשך chest->neck למטה, ציר
    הגולגולת למעלה) **הוסיף** שבר: 8.44° מול 5.62° בקו הישר.
    Catmull-Rom גוזר את המשיק בכל נקודה מהשכנים שלה -
    `m_i = (p_{i+1} - p_{i-1}) / 2` בגרסה האחידה - ולכן רציפות C1
    בכל מפרק היא תכונה של הנוסחה ולא של כיול. זה מה שהופך את
    השבר בן ה-5.62° במפרק הצוואר (שם, ורק שם, הוא נמדד) לעקומת S.

    `alpha` הוא הפרמטריזציה: 0 אחידה, 0.5 צנטריפטלית, 1 אורך-מיתר.
    הצנטריפטלית היא ברירת המחדל כי היא **מוכחת** חסרת לופים
    וחסרת חדים עצמיים גם כשמרווחי המפרקים אינם שווים - וכאן הם
    אינם שווים (chest->neck הוא 152 מ"מ, neck->head הוא 87 מ"מ).
    """
    Q = np.asarray(ctrl, float)
    if len(Q) < 4:
        raise ValueError("Catmull-Rom דורש 4 נקודות בקרה לפחות")
    nseg = len(Q) - 3
    i = int(np.floor(u))
    i = max(0, min(nseg - 1, i))          # אקסטרפולציה: נשאר בקטע הקצה
    t = float(u) - i
    p0, p1, p2, p3 = Q[i], Q[i + 1], Q[i + 2], Q[i + 3]
    # מרווחי הפרמטר לפי alpha. 1e-9 מונע חלוקה באפס על נקודות כפולות.
    def _dt(a, b):
        d = float(np.linalg.norm(b - a))
        return max(d ** alpha, 1e-9)
    t0, t1, t2_ = _dt(p0, p1), _dt(p1, p2), _dt(p2, p3)
    # משיקים לא-אחידים (Barry-Goldman). ב-alpha=0 זה מצטמצם בדיוק
    # ל-(p2-p0)/2 ו-(p3-p1)/2, כלומר ל-Catmull-Rom הקלאסי.
    m1 = (p2 - p1) + t1 * ((p1 - p0) / t0 - (p2 - p0) / (t0 + t1))
    m2 = (p2 - p1) + t1 * ((p3 - p2) / t2_ - (p3 - p1) / (t1 + t2_))
    return hermite(p1, p2, m1, m2, t)


def catmull_rom_chain(ctrl, n: int, alpha: float = 0.5) -> np.ndarray:
    """`n` נקודות שוות-פרמטר על הספליין כולו. נוח למדידה ולבדיקה."""
    nseg = len(np.asarray(ctrl, float)) - 3
    return np.array([catmull_rom(ctrl, nseg * i / (n - 1), alpha)
                     for i in range(n)])


def smoothstep(t: float) -> float:
    """3t^2 - 2t^3 על [0,1], עם קיטום בקצוות.

    הנגזרת מתאפסת בשני הקצוות, ולכן מעבר רדיוס שנבנה עליו אינו
    מייצר קפיצה בהצללה בנקודת החיבור - וזה כל ההבדל בין "הצוואר
    מתחבר" ל"יש תפר סביב הצוואר".
    """
    t = max(0.0, min(1.0, float(t)))
    return t * t * (3.0 - 2.0 * t)


def step_uniformity(pts) -> float:
    """יחס המרווח הגדול לקטן על פוליגון (1.0 = אחיד לגמרי).

    זה המודד שתפס את הצוואר הקודם: שלוש טבעות במרווחים
    109.7 / 42.7 / 27.9 מ"מ הן לא "עקומה בצפיפות משתנה" אלא
    דגימה מקרית, והקפיצה בצפיפות נראית כרצועת הצללה.
    """
    P = np.asarray(pts, float)
    if len(P) < 3:
        return 1.0
    L = np.linalg.norm(np.diff(P, axis=0), axis=1)
    L = L[L > 1e-12]
    if len(L) == 0:
        return 1.0
    return float(L.max() / L.min())


def tangent_break(pts) -> float:
    """הזווית המקסימלית (מעלות) בין משיקים עוקבים על פוליגון.

    זה המודד שמבדיל "עקומה" מ"קו שבור". על קו ישר הוא 0, ועל חיבור
    של שני קווים ישרים בזווית - הוא הזווית הזו. כלומר צינור גלילי
    שנדחף לכתפיים נראה כאן, וקימור S רציף לא.
    """
    P = np.asarray(pts, float)
    if len(P) < 3:
        return 0.0
    d = np.diff(P, axis=0)
    L = np.linalg.norm(d, axis=1, keepdims=True)
    L[L < 1e-15] = 1.0
    d = d / L
    c = np.clip(np.einsum("ij,ij->i", d[:-1], d[1:]), -1.0, 1.0)
    return float(np.degrees(np.arccos(c)).max())
