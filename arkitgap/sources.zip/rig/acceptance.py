# -*- coding: utf-8 -*-
"""בדיקת הקבלה של TASK 01:

"רנדר את אותה דמות מלפחות 5 זוויות מצלמה ו-5 פוזות שונות, בלי סחיפת
זהות."

הבדיקה מריצה 25 רנדורים אמיתיים בדפדפן נסתר על ה-GLB המרוגג, ובודקת
ארבעה דברים - לא אחד:

1. **זהות גאומטרית** - אורכי עצמות ומדידות פנים חייבים להיות זהים בכל
   25 המצבים (נמדד בפייתון, לא בעין).
2. **שחזור פוזת מנוחה** - מכל פוזה אפשר לחלץ בחזרה את צורת המנוחה
   בשגיאה מתחת לחצי מילימטר. זו ההוכחה שהצורה לא "נצבעה מחדש".
3. **הפוזות באמת שונות** - אחרת "אפס סחיפה" הוא ניצחון על דמות
   מאובנת. נמדדת ההזזה הממוצעת בין כל זוג פוזות.
4. **הרנדור תקף** - בכל 25 התמונות יש דמות, היא לא גזורה בקצה הפריים,
   והפוזה שהוחלה היא זו שהתבקשה (הצופה מחזיר כמה עצמות קיבלו פוזה).

התוצאה נשמרת כ-JSON וכגיליון מגע אחד של 5x5 שאפשר להסתכל עליו.
"""
from __future__ import annotations

import argparse
import asyncio
import base64
import functools
import http.server
import io
import json
import shutil
import socketserver
import sys
import tempfile
import threading
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
STUDIO = HERE.parent
sys.path.insert(0, str(STUDIO))

from rig import controls, identity, pipeline          # noqa: E402
from rig.skeleton import Skeleton                     # noqa: E402

# חמש זוויות מצלמה: (שם, yaw, pitch)
CAMERAS = [
    ("front", 0, 2),
    ("three_quarter_L", 38, 6),
    ("profile_L", 86, 2),
    ("three_quarter_R", -42, 0),
    ("high_back_R", -150, 24),
]


def _serve(root: Path):
    h = functools.partial(http.server.SimpleHTTPRequestHandler,
                          directory=str(root))
    srv = socketserver.ThreadingTCPServer(("127.0.0.1", 0), h)
    srv.daemon_threads = True
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, srv.server_address[1]


def _stage(glb: Path) -> Path:
    """תיקיית הגשה זמנית: שלוש הפעמים הראשונות שזה נוסה נכשלו כי
    ES modules ו-fetch של GLB חסומים ב-file:// (origin null) - והכשל
    שקט לגמרי, בלי שום שגיאה בקונסולה."""
    d = Path(tempfile.mkdtemp(prefix="rigacc_"))
    shutil.copytree(STUDIO / "lib", d / "lib")
    # GLTFLoader.module.js מייבא ../utils/BufferGeometryUtils.js. בלי
    # הקובץ הזה המודול נכשל בטעינה **בשקט**: window.__ready לא נקבע
    # ואין שום שגיאה - בדיוק הכשל ששרף כאן ריצה שלמה.
    shutil.copytree(STUDIO / "utils", d / "utils")
    shutil.copy2(HERE / "viewer.html", d / "viewer.html")
    shutil.copy2(glb, d / "char.glb")
    return d


def _contact_sheet(cells, out_path, cols, labels_x, labels_y, cell=(320, 450)):
    from PIL import Image, ImageDraw
    cw, ch = cell
    pad, top, left = 6, 26, 86
    rows = len(cells) // cols
    W = left + cols * (cw + pad) + pad
    H = top + rows * (ch + pad) + pad
    sheet = Image.new("RGB", (W, H), (22, 25, 32))
    d = ImageDraw.Draw(sheet)
    for i, png in enumerate(cells):
        r, c = divmod(i, cols)
        im = Image.open(io.BytesIO(png)).convert("RGBA")
        im.thumbnail((cw, ch))
        bg = Image.new("RGBA", (cw, ch), (36, 40, 50, 255))
        bg.alpha_composite(im, ((cw - im.width) // 2, (ch - im.height) // 2))
        sheet.paste(bg.convert("RGB"),
                    (left + c * (cw + pad) + pad, top + r * (ch + pad) + pad))
    for c, name in enumerate(labels_x):
        d.text((left + c * (cw + pad) + pad + 4, 7), name, fill=(225, 232, 245))
    for r, name in enumerate(labels_y):
        d.text((6, top + r * (ch + pad) + pad + 4), name, fill=(225, 232, 245))
    sheet.save(out_path)
    return out_path


async def run(glb: Path, rig_json: Path, out_dir: Path, width=560, height=800,
              secondary=True):
    import engine                                     # noqa: PLC0415

    rig = json.loads(rig_json.read_text(encoding="utf-8"))
    skel = pipeline.skeleton_from_rig(rig)
    npz = np.load(str(rig_json.with_suffix("").with_suffix(".attrs.npz")))
    attrs = {k: npz[k] for k in ("position", "normal", "uv", "skinIndex",
                                 "skinWeight", "index")}

    lib = controls.pose_library(skel)
    pose_names = sorted(lib)
    poses = {}
    for pname in pose_names:
        ctl, ik = lib[pname]
        q = controls.evaluate(skel, ctl, ik)
        if secondary:
            # תנועה משנית: מריצים חצי שנייה של התייצבות כדי שהפיגור
            # ייראה בפוזה סטטית ולא רק בתנועה.
            sm = controls.SecondaryMotion(1.0)
            for _ in range(8):
                q = sm.apply(dict(q), 1 / 24)
        poses[pname] = q

    geo = identity.identity_report(skel, attrs, poses)

    out_dir.mkdir(parents=True, exist_ok=True)
    shots_dir = out_dir / "shots"
    shots_dir.mkdir(exist_ok=True)

    stage = _stage(glb)
    srv, port = _serve(stage)
    br = engine.Browser(width + 40, height + 60)
    t0 = time.time()
    renders, cells = {}, []
    info = {}
    try:
        await br.start()
        url = f"http://127.0.0.1:{port}/viewer.html?w={width}&h={height}&glb=char.glb"
        await br.cmd("Page.navigate", {"url": url})
        for _ in range(400):
            if await br.js("!!window.__ready"):
                break
            await asyncio.sleep(0.1)
        err = await br.js("window.__err ? window.__err() : 'הצופה לא נטען'")
        info = json.loads(await br.js("JSON.stringify(window.__info||null)")
                          or "null") or {}
        if err:
            raise RuntimeError(f"הצופה החזיר שגיאה: {err}")

        # מרחק המצלמה: בגובה פתיחה 1.95 נמדד שהדמות נגזרת בכל 30
        # הפריימים - פוזת "הושטת יד למעלה" מגיעה ל-1.95 מ' וזרועות
        # פרושות רחבות מהשדה האופקי. 2.75 נותן שוליים בכל הפוזות.
        dist = rig["height_m"] * 3.05
        cy = rig["height_m"] * 0.50
        for pname in pose_names:
            q = {k: [float(x) for x in v] for k, v in poses[pname].items()}
            applied = json.loads(await br.js(
                "window.__pose(" + json.dumps(json.dumps(q)) + ")"))
            for cname, yaw, pitch in CAMERAS:
                d = await br.js(f"window.__shot({yaw},{pitch},{dist},{cy},32)")
                if not isinstance(d, str) or not d.startswith("data:image"):
                    raise RuntimeError(f"רנדור נכשל: {pname}/{cname}")
                png = base64.b64decode(d.split(",", 1)[1])
                (shots_dir / f"{pname}__{cname}.png").write_bytes(png)
                sig = identity.image_signature(png)
                renders[f"{pname}|{cname}"] = {
                    "applied_bones": applied["applied"],
                    "unknown_bones": applied["unknown"],
                    **{k: sig[k] for k in ("coverage", "pixels", "cx", "cy",
                                           "bbox", "color", "size")},
                }
                cells.append(png)
        # דטרמיניזם: אותה פוזה ואותה מצלמה פעמיים -> אותה תמונה בדיוק
        q0 = {k: [float(x) for x in v] for k, v in poses[pose_names[0]].items()}
        await br.js("window.__pose(" + json.dumps(json.dumps(q0)) + ")")
        a = await br.js(f"window.__shot(0,2,{dist},{cy},32)")
        await br.js("window.__pose(" + json.dumps(json.dumps(q0)) + ")")
        b = await br.js(f"window.__shot(0,2,{dist},{cy},32)")
        deterministic = (a == b)
    finally:
        await br.close()
        srv.shutdown()
        shutil.rmtree(stage, ignore_errors=True)

    sheet = _contact_sheet(cells, out_dir / "acceptance_sheet.png",
                           cols=len(CAMERAS),
                           labels_x=[c[0] for c in CAMERAS],
                           labels_y=pose_names)

    # --- קריטריוני מעבר
    covs = np.array([r["coverage"] for r in renders.values()])
    bboxes = [r["bbox"] for r in renders.values()]
    cut = 0
    for r in renders.values():
        bb = r["bbox"]
        if bb is None:
            cut += 1
            continue
        iw, ih = r.get("size") or (width, height)
        x0, y0, x1, y1 = bb
        if x0 <= 1 or y0 <= 1 or x1 >= iw - 2 or y1 >= ih - 2:
            cut += 1
    unknown = sorted({n for r in renders.values() for n in r["unknown_bones"]})
    min_applied = min(r["applied_bones"] for r in renders.values())

    checks = {
        "renders_produced": (len(renders), len(CAMERAS) * len(pose_names),
                             len(renders) == len(CAMERAS) * len(pose_names)),
        "bone_length_drift_pct": (geo["bone_length_drift"]["max_rel"] * 100,
                                  1e-4,
                                  geo["bone_length_drift"]["max_rel"] < 1e-6),
        "face_measure_drift_pct": (geo["face_measure_drift"]["max_rel"] * 100,
                                   1e-4,
                                   geo["face_measure_drift"]["max_rel"] < 1e-6),
        "rest_recovery_mm": (geo["rest_recovery_worst_mm"], 0.5,
                             geo["rest_recovery_worst_mm"] < 0.5),
        "pose_separation_pct": (geo["pose_separation"]["min_mean_pct"], 0.5,
                                geo["pose_separation"]["min_mean_pct"] > 0.5),
        "character_visible": (float(covs.min()), 0.02, bool(covs.min() > 0.02)),
        "not_cropped": (cut, 0, cut == 0),
        "pose_applied_to_bones": (min_applied, 1, min_applied >= 1),
        "no_unknown_bones": (len(unknown), 0, not unknown),
        "render_deterministic": (deterministic, True, bool(deterministic)),
        "skinned_mesh_in_glb": (info.get("skinned", 0), 1,
                                info.get("skinned", 0) >= 1),
        "skeleton_bones_in_glb": (info.get("skeletonBones", 0),
                                  rig["mesh"]["bones"],
                                  info.get("skeletonBones", 0)
                                  == rig["mesh"]["bones"]),
        "has_skin_attributes": (info.get("hasSkinIndex", False), True,
                                bool(info.get("hasSkinIndex"))),
        "has_vertex_colors": (info.get("hasColor", False), True,
                              bool(info.get("hasColor"))),
    }
    report = {
        "task": "TASK 01 - צינור דמות תלת-ממדית להפקה",
        "character": rig["name"],
        "when": time.strftime("%Y-%m-%d %H:%M:%S"),
        "cameras": [c[0] for c in CAMERAS],
        "poses": pose_names,
        "viewer_info": info,
        "geometry": geo,
        "renders": renders,
        "checks": {k: {"value": v[0], "limit": v[1], "pass": bool(v[2])}
                   for k, v in checks.items()},
        "passed": all(v[2] for v in checks.values()),
        "sheet": str(sheet),
        "shots_dir": str(shots_dir),
        "seconds": round(time.time() - t0, 1),
    }
    (out_dir / "acceptance.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=1), encoding="utf-8")
    return report


def main(argv=None):
    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(description="בדיקת קבלה לדמות מרוגגת")
    ap.add_argument("name")
    ap.add_argument("--dir", default=r"D:\claude-bot\out\char3d\rigged")
    ap.add_argument("--build", action="store_true", help="לבנות קודם")
    ap.add_argument("--ref-glb", default=None)
    ap.add_argument("--ref-png", default=None)
    ap.add_argument("--quality", default="full")
    a = ap.parse_args(argv)
    d = Path(a.dir)
    if a.build:
        pipeline.build_character(a.name, d, ref_glb=a.ref_glb,
                                 ref_png=a.ref_png, quality=a.quality)
    rep = asyncio.run(run(d / f"{a.name}.glb", d / f"{a.name}.rig.json",
                          d / f"acceptance_{a.name}"))
    print(f"\n=== בדיקת קבלה · {rep['character']} ===")
    for k, v in rep["checks"].items():
        print(f"  {'✓' if v['pass'] else '✗'} {k}: {v['value']} "
              f"(גבול {v['limit']})")
    print(f"\n{'עבר' if rep['passed'] else 'נכשל'} | "
          f"{len(rep['renders'])} רנדורים | {rep['seconds']}ש")
    print(f"גיליון מגע: {rep['sheet']}")
    return 0 if rep["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
