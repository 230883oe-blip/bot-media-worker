# -*- coding: utf-8 -*-
"""TASK 14 (06/10) - תנועה במקום: עמידה, הליכה, ריצה והמעברים ביניהן.

עד כאן כל דמות בפרויקט **עמדה**. היו קפיצות (`ensemble`), העברות
משקל (`controls.weight_shift`) וצעד כבד אחד של גרומפ, אבל לא היה
מחזור הליכה ולא הייתה ריצה: הדמות לא עברה מטר אחד במרחב.

================================================================
ההכרעה הארכיטקטונית, ולמה דווקא היא
================================================================

שתי דרכים לאנימציית הליכה, והן הפוכות בכיוון הזרימה:

**א. עקומות FK.** כותבים זוויות לירך/ברך/קרסול כפונקציה של הפאזה,
ואת תנועת השורש *גוזרים* ממה שיצא (ממוצע תנועת כף הרגל בזמן
המדרך). החלקה אינה נמנעת שם - היא **מקווה**: כל שגיאת זווית קטנה
מצטברת, והרגל מחליקה או שהשורש נסחף.

**ב. מתכנן צעדים במרחב העולם + IK לשתי עצמות.** מניחים נקודות
דריכה **קבועות** בעולם, ובכל פריים ה-IK פותר את הרגל אל הנקודה.
החלקה אינה נמנעת כאן - היא **בלתי אפשרית**, כי היעד הוא קבוע
מתמטית. מה שנותר למדוד הוא רק "האם ה-IK באמת הגיע ליעד".

נבחרה (ב). את ההכרעה אישרו שני יועצים חיצוניים (Qwen 3.8 דרך Groq,
ו-Command A של Cohere, 06/10) באותו נימוק בדיוק: ב-FK אי אפשר
*לאסור* על הרגל לזוז, אפשר רק לקוות שהחשבון יתכנס.

ומכאן נובע **הדבר היחיד שבאמת יכול לשבור את השיטה**: יעד שה-IK אינו
מגיע אליו. `two_bone_ik` מהדק מטרה רחוקה ל-99.9% מהמותח המלא ואינו
מתלונן - כלומר רגל שאינה מגיעה נראית בדיוק כמו רגל שמחליקה, בלי שום
שגיאה. לכן **אורך הצעד אינו פרמטר אמנותי כאן, אלא נגזרת גאומטרית**:

    max_d = sqrt(L² - (hip_y - crouch + bob - ankle_y)²)
    stride = 2 · reach · max_d

כלומר אורך הצעד מחושב מאורך הרגל ומגובה האגן **של הדמות הזאת**,
עם מרווח ביטחון (`reach` < 1), ונמדד בגובה האגן הגבוה ביותר במחזור
(כי שם הרגל מתוחה ביותר). דמות נמוכה תצעד צעדים קצרים לא כי כך
הוחלט אלא כי כך רגלה. הניסיון הראשון כאן קבע `stride=1.05` לריצה
בקוד - וזה 0.95 מ' של מותח על רגל של 0.84 מ', כלומר הרגל נעצרה
15 ס"מ מהיעד בכל פריים של ריצה, והסתכמה בהחלקה מושלמת.

================================================================
מה נמדד, ולמה דווקא זה
================================================================

* **אין החלקה** - תזוזת הקרסול במישור האופקי בתוך מדרך אחד. נמדדת
  על **העולם**, כלומר `forward()` + היסט הקבוצה - ולא על היעד.
* **ה-IK מגיע** - מרחק בין הקרסול המרונדר ליעד שהוזמן.
* **מרחק אמיתי** - נסיעת השורש שווה לסכום הצעדים, ולא "בערך".
* **שלב טיסה בריצה** - קיים פריים שבו **שתי** כפות הרגליים באוויר.
  **ובהליכה אין אף פריים כזה** - זו ההגדרה שמפרידה בין השתיים, וזה
  ניגוד ולא סף: שתי הדמויות נמדדות באותו מודד.
* **סדר המגע** - בהליכה העקב ראשון (הבוהן מורמת במגע), בריצה כף
  הרגל ראשונה (הבוהן מונמכת). נמדד על הפיץ' **בעולם** אחרי ה-IK,
  ולא על הבקרה שהוזמנה: הכיוון של כף הרגל תלוי גם בשוק, שה-IK
  סובב אותו, ובקרה שהוזמנה אינה מה שנראה.
* **העברת משקל** - הנדנוד הרוחבי של האגן מגיע לשיא **מעל הרגל
  הדורכת**, ולא בזמן אחר. פאזה הפוכה נראית כצליעה.
* **המעבר רציף בנגזרת** - מהירות עמידה->הליכה->ריצה נבנית
  מ-smoothstep, שנגזרתו אפס בשני הקצוות, ולכן אין קפיצת תאוצה
  בתפר. נמדדת הנגזרת השנייה של המקום, לא העין.

הכול נבנה **פעם אחת** לכל אורך הקטע ומשם כל פריים הוא אינדקס
במערך - בדיוק מהסיבה של `ensemble.Take`: מדד שמסתכל על פריים בודד
לא היה מוצא אף אחת מהתקלות שלמעלה.
"""
from __future__ import annotations

import math
import sys
from dataclasses import dataclass, replace
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
if str(HERE.parent) not in sys.path:
    sys.path.insert(0, str(HERE.parent))

from rig import controls                                   # noqa: E402
from rig.skeleton import Skeleton                           # noqa: E402

D = math.pi / 180.0


def _ss(x: float) -> float:
    """smoothstep. נגזרת אפס בשני הקצוות - וזה כל הטעם."""
    x = 0.0 if x < 0.0 else (1.0 if x > 1.0 else float(x))
    return x * x * (3.0 - 2.0 * x)


# ------------------------------------------------------------- הילוכים


@dataclass(frozen=True)
class Gait:
    """הילוך אחד. **אין כאן `stride`** - הוא נגזר מהגאומטריה."""
    key: str
    cadence: float      # **מחזורים** בשנייה (מחזור = שני צעדים)
    stance: float       # חלק המחזור שבו הרגל דורכת (>0.5 = תמיכה כפולה)
    reach: float        # מרווח הביטחון של ה-IK, 0..1
    crouch: float       # שקיעת האגן, ביחידות אורך רגל
    bob: float          # משרעת הנדנוד האנכי, ביחידות אורך רגל
    bob_sign: float     # +1 אגן גבוה במדרך (הליכה), -1 גבוה בטיסה (ריצה)
    lift: float         # גובה הרמת הרגל בנדנוד, ביחידות אורך רגל
    sway: float         # נדנוד רוחבי של האגן, ביחידות אורך רגל
    arm: float          # משרעת נדנוד הזרוע, 0..1
    lean: float         # הטיית הגו קדימה, 0..1
    contact: float      # פיץ' כף הרגל במגע, ברדיאנים. + = עקב ראשון
    toe_off: float      # הרמת הקרסול בדחיפה, ביחידות אורך רגל


#: עמידה. `cadence=0` מקפיא את הפאזה, ולכן שתי הרגליים נשארות
#: נעוצות בנקודה שלהן - בלי שום טיפול מיוחד ב"מצב עמידה".
#: `stance=1.0` הוא מה שמבטיח שגם רגל שהפאזה שלה מחוץ לחלון
#: ההליכה תיחשב דורכת.
STAND = Gait("stand", cadence=0.0, stance=1.0, reach=0.80, crouch=0.060,
             bob=0.004, bob_sign=1.0, lift=0.0, sway=0.010, arm=0.03,
             lean=0.0, contact=0.0, toe_off=0.0)

WALK = Gait("walk", cadence=1.00, stance=0.62, reach=0.88, crouch=0.120,
            bob=0.024, bob_sign=1.0, lift=0.090, sway=0.034, arm=0.40,
            lean=0.05, contact=0.21, toe_off=0.035)

RUN = Gait("run", cadence=1.45, stance=0.38, reach=0.92, crouch=0.260,
           bob=0.062, bob_sign=-1.0, lift=0.200, sway=0.024, arm=0.95,
           lean=0.22, contact=-0.26, toe_off=0.080)

GAITS = {"stand": STAND, "walk": WALK, "run": RUN}

#: אורך הרמפה בין שני הילוכים, בשניות. הוא **לא** חופשי: רמפות
#: חופפות שוברות את החיבור הסדרתי של ה-smoothstep (ואז המהירות
#: בתפר אינה אף אחת מהשתיים), ולכן `Move` נכשל בבנייה על חפיפה.
RAMP = 0.55


def _ph_of(side: str) -> float:
    """הפרש הפאזה בין הרגליים. חצי מחזור, וזו כל ההגדרה של הליכה."""
    return 0.0 if side == "L" else 0.5


# ------------------------------------------------------- התנועה עצמה


class Move:
    """קטע תנועה אחד: רצף הילוכים, ועליו פוזה והיסט לכל פריים.

    plan = [("stand", 1.2), ("walk", 2.4), ("run", 4.0)]
    """

    def __init__(self, skel: Skeleton, plan, fps: int = 30,
                 lane: float = 0.0, phase0: float = 0.55,
                 gaits: dict | None = None, ramp: float = RAMP,
                 treadmill: bool = False):
        #: **מסילה.** דמות שרצה 4 מ'/ש' עוברת 80 מטר בעשרים שניות,
        #: והמצלמה כאן נעולה על הבמה. הפתרון הוא זה של אנימציה
        #: דו-ממדית מאז ומתמיד: הדמות נשארת בפריים ו**הקרקע זזה**.
        #:
        #: וזה לא "ריצה במקום": נקודות הדריכה ממשיכות לנוע אחורה
        #: בדיוק במהירות ההילוך, כלומר הרגל נעוצה ביחס ל**קרקע**,
        #: והרקע נסחף באותו קצב בדיוק (`pan_of`). מה שמשתנה הוא רק
        #: מערכת הייחוס שבה "אין החלקה" נמדדת - ולכן השערים ממשיכים
        #: להימדד על מערכת הנסיעה, והמסילה מקבלת שער משלה.
        self.treadmill = bool(treadmill)
        self.skel = skel
        self.fps = int(fps)
        self.lane = float(lane)
        self.ramp = float(ramp)
        self.phi0 = float(phase0)
        self.G = dict(GAITS if gaits is None else gaits)
        self.plan = [(str(k), float(d)) for k, d in plan]
        if not self.plan:
            raise ValueError("תוכנית תנועה ריקה")
        for k, _d in self.plan:
            if k not in self.G:
                raise KeyError(f"אין הילוך בשם {k!r}")

        # --- גאומטריית הרגל של **הדמות הזאת**
        B = skel.by_name
        self.hip_y = float(B["thigh_L"].rest[1])
        self.ankle_y = float(B["foot_L"].rest[1])
        th = np.asarray(B["thigh_L"].rest, float)
        sh = np.asarray(B["shin_L"].rest, float)
        ft = np.asarray(B["foot_L"].rest, float)
        self.leg = float(np.linalg.norm(sh - th) + np.linalg.norm(ft - sh))
        self.hip_half = abs(float(B["thigh_L"].rest[0]))
        self.k = skel.height / 1.70

        # --- לוח הזמנים
        self.secs = sum(d for _k, d in self.plan)
        self.n = int(round(self.secs * self.fps))
        if self.n < 2:
            raise ValueError("קטע תנועה קצר מפריים אחד")
        bounds = []
        acc = 0.0
        for i in range(len(self.plan) - 1):
            acc += self.plan[i][1]
            bounds.append((acc, self.plan[i + 1][0]))
        for a, b in zip(bounds, bounds[1:]):
            if b[0] - a[0] < self.ramp * 1.001:
                raise ValueError(
                    f"רמפות חופפות בין {a[0]:.2f} ל-{b[0]:.2f} "
                    f"(רמפה {self.ramp})")
        self.bounds = bounds

        self._build()

    # ------------------------------------------------- בניית העקומות

    def _at(self, t: float, attr: str) -> float:
        """ערך פרמטר ההילוך בזמן t, מחובר סדרתית ב-smoothstep."""
        v = float(getattr(self.G[self.plan[0][0]], attr))
        for b, key in self.bounds:
            w = _ss((t - (b - self.ramp * 0.5)) / self.ramp)
            v += (float(getattr(self.G[key], attr)) - v) * w
        return v

    def _cycle_of(self, gait: Gait) -> float:
        """**המרחק שהגוף עובר במחזור אחד**, הנגזר מגאומטריית הרגל.

        הגזירה היא דרך האילוץ היחיד שבאמת קיים: כף רגל נעוצה נשארת
        במקומה כל זמן המדרך, ולכן מרחק הנסיעה *בזמן המדרך* הוא בדיוק
        הטווח האופקי שהרגל צריכה לכסות. אם הוא עובר את ההישג -
        ה-IK אינו מגיע, ורגל שאינה מגיעה היא רגל שמחליקה.

            stance · cycle = 2 · reach · max_d

        האגן הגבוה ביותר הוא המקום שבו הרגל מתוחה ביותר, ולכן הוא
        שקובע את `max_d`. מדידה בגובה הממוצע הייתה נותנת מחזור שעובר
        את המותח רק בשיא הנדנוד - כלומר החלקה בשליש מהפריימים.

        **ובכך גם סדר הגודל של ההילוך נגזר ולא מוצהר**: מדרך ארוך
        (הליכה, 0.62) מחייב מחזור קצר, ומדרך קצר (ריצה, 0.38) מרשה
        מחזור ארוך פי שלושה על אותה רגל בדיוק.
        """
        hip_hi = (self.hip_y - (gait.crouch - gait.bob) * self.leg)
        vert = hip_hi - self.ankle_y
        room = self.leg * self.leg - vert * vert
        if room <= 1e-9 or gait.stance <= 1e-9:
            return 0.0
        return 2.0 * gait.reach * math.sqrt(room) / gait.stance

    def _build(self) -> None:
        n, fps = self.n, self.fps
        self.t = np.arange(n + 1, dtype=np.float64) / fps
        self.cad = np.array([self._at(tt, "cadence") for tt in self.t])
        self.stanc = np.array([self._at(tt, "stance") for tt in self.t])
        #: מרחק למחזור, ו-`step` = אורך צעד בודד (חצי מחזור). שניהם
        #: נגזרים, ולכן הם מערכים ולא קבועים: בתוך רמפה הם משתנים.
        self.cyc = np.array([self._cycle_of(
            replace(self.G[self.plan[0][0]],
                    crouch=self._at(tt, "crouch"),
                    bob=self._at(tt, "bob"),
                    reach=self._at(tt, "reach"),
                    stance=self._at(tt, "stance")))
            for tt in self.t])
        self.step = self.cyc * 0.5
        self.lift = np.array([self._at(tt, "lift") for tt in self.t])
        self.bobA = np.array([self._at(tt, "bob") for tt in self.t])
        self.bobS = np.array([self._at(tt, "bob_sign") for tt in self.t])
        self.swayA = np.array([self._at(tt, "sway") for tt in self.t])
        self.armA = np.array([self._at(tt, "arm") for tt in self.t])
        self.leanA = np.array([self._at(tt, "lean") for tt in self.t])
        self.crouchA = np.array([self._at(tt, "crouch") for tt in self.t])
        self.contA = np.array([self._at(tt, "contact") for tt in self.t])
        self.toeoffA = np.array([self._at(tt, "toe_off") for tt in self.t])

        dt = 1.0 / fps
        self.vel = self.cad * self.cyc             # מ'/ש'
        # אינטגרל טרפז. סכום מצטבר של מלבנים היה נותן שגיאת מרחק
        # שגדלה לינארית, ובדיוק המדד "נסיעה = סכום הצעדים" היה תופס
        # אותה - אבל רק אחרי שהיא כבר נראית בעין.
        # פאזת ההתחלה 0.55 אינה שרירותית: בחלון הזה **שתי** הרגליים
        # בתוך חלון המדרך של הליכה (0.55<0.62 ו-0.05<0.62), כלומר
        # הקטע מתחיל בתמימה כפולה - וזו הדרך היחידה להתחיל ללכת
        # מעמידה בלי שרגל אחת תקפוץ לאוויר בפריים הראשון.
        self.phi = self.phi0 + np.concatenate(
            [[0.0], np.cumsum((self.cad[:-1] + self.cad[1:]) * 0.5 * dt)])
        self.z = np.concatenate(
            [[0.0], np.cumsum((self.vel[:-1] + self.vel[1:]) * 0.5 * dt)])

        # --- מסכות מדרך, נקודות דריכה, יעדי IK
        self.stance_mask: dict[str, np.ndarray] = {}
        self.plants: dict[str, list] = {}
        self.target: dict[str, np.ndarray] = {}
        self.air: dict[str, np.ndarray] = {}
        for side in ("L", "R"):
            self._build_leg(side)

        # --- היסט הקבוצה
        self.ox = np.zeros(n + 1)
        self.oy = np.zeros(n + 1)
        self.oz = self.z.copy()
        for i in range(n + 1):
            p = self.phi[i]
            self.ox[i] = self.lane + self.swayA[i] * self.leg * math.sin(
                2 * math.pi * p)
            mid = self.stanc[i] * 0.5
            self.oy[i] = (-self.crouchA[i] * self.leg
                          + self.bobS[i] * self.bobA[i] * self.leg
                          * math.cos(4 * math.pi * (p - mid)))

    def _build_leg(self, side: str) -> None:
        n = self.n
        ph = _ph_of(side)
        sgn = 1.0 if side == "L" else -1.0
        p = np.mod(self.phi + ph, 1.0)
        st = p < self.stanc
        self.stance_mask[side] = st

        # רצפי מדרך רצופים -> נקודת דריכה אחת לכל רצף
        runs = []
        i = 0
        while i <= n:
            if st[i]:
                j = i
                while j + 1 <= n and st[j + 1]:
                    j += 1
                runs.append((i, j))
                i = j + 1
            else:
                i += 1
        plants = []
        for (i0, _i1) in runs:
            frac = p[i0] / max(self.stanc[i0], 1e-6)
            # הטווח שהרגל מכסה במדרך הוא `stance·cycle`, והיא ממורכזת
            # סביב האגן: +חצי טווח במגע, -חצי טווח בדחיפה.
            span = self.cyc[i0] * self.stanc[i0]
            pz = self.z[i0] + span * (0.5 - frac)
            px = self.lane + sgn * self.hip_half
            plants.append(np.array([px, self.ankle_y, pz]))
        self.plants[side] = [{"at": r, "pos": q}
                             for r, q in zip(runs, plants)]

        tgt = np.zeros((n + 1, 3))
        air = np.zeros(n + 1, dtype=bool)
        if not self.plants[side]:
            tgt[:] = np.array([self.lane + sgn * self.hip_half,
                               self.ankle_y, 0.0])
            self.target[side] = tgt
            self.air[side] = air
            return

        # --- מדרך: היעד הוא הנקודה, קבוע. רק הקרסול עולה בדחיפה.
        for item in self.plants[side]:
            (i0, i1) = item["at"]
            for i in range(i0, i1 + 1):
                frac = min(1.0, max(0.0, p[i] / max(self.stanc[i], 1e-6)))
                rise = self.toeoffA[i] * self.leg * _ss((frac - 0.72) / 0.28)
                tgt[i] = item["pos"] + np.array([0.0, rise, 0.0])

        # --- נדנוד: בין נקודת הדריכה שלפני לזו שאחרי, **ו-u נגזר
        #     מהפאזה ולא ממספר הפריימים בפער**. הגרסה הראשונה כאן
        #     גזרה את u מאינדקס הפריים בתוך הפער, וזה נכון רק לפער
        #     שלם: בפער הפתוח שבתחילת הקטע (רגל שהתחילה באוויר) זה
        #     נתן u=0 בפריים הראשון, כלומר יעד במקום הדריכה **הבא**
        #     - 83 ס"מ מהגוף, שאליהם שום רגל אינה מגיעה. ה-IK הידק
        #     בשקט, והריצה נראתה כהחלקה מושלמת.
        gaps = []
        first_i0 = self.plants[side][0]["at"][0]
        if first_i0 > 0:
            p0 = self.plants[side][0]["pos"]
            gaps.append((0, first_i0 - 1,
                         p0 - np.array([0.0, 0.0, self.cyc[0]]), p0))
        for a, b in zip(self.plants[side], self.plants[side][1:]):
            if b["at"][0] > a["at"][1] + 1:
                gaps.append((a["at"][1] + 1, b["at"][0] - 1,
                             a["pos"], b["pos"]))
        last_i1 = self.plants[side][-1]["at"][1]
        if last_i1 < n:
            pl = self.plants[side][-1]["pos"]
            gaps.append((last_i1 + 1, n, pl,
                         pl + np.array([0.0, 0.0, self.cyc[last_i1]])))

        for (j0, j1, prev, nxt) in gaps:
            for i in range(j0, j1 + 1):
                den = max(1.0 - self.stanc[i], 1e-6)
                u = min(1.0, max(0.0, (p[i] - self.stanc[i]) / den))
                pos = prev + (nxt - prev) * _ss(u)
                pos[1] = self.ankle_y + self.lift[i] * self.leg * math.sin(
                    math.pi * u)
                tgt[i] = pos
                air[i] = True
        self.target[side] = tgt
        self.air[side] = air

    # ------------------------------------------------------- דגימה

    def _i(self, t: float) -> int:
        return int(min(self.n, max(0, round(float(t) * self.fps))))

    def offset(self, t: float) -> dict:
        """ההיסט שנשלח לבמה. במסילה הנסיעה נשארת ב-IK ואינה בגוף."""
        i = self._i(t)
        return {"ox": round(float(self.ox[i] if not self.treadmill
                                  else self.lane), 5),
                "oy": round(float(self.oy[i]), 5),
                "oz": round(float(0.0 if self.treadmill else self.oz[i]), 5)}

    def pan_of(self, t: float, scale: float = 0.055) -> float:
        """סחיפת הרקע שמתאימה לנסיעה. `scale` = יחידות pan למטר.

        הרקע הצרוב שטוח, ולכן כל מה שהוא יכול לעשות הוא להיסחף
        אופקית (`park`/`_env_of`). הקצב כאן נגזר מ-`oz` ולא נכתב
        בנפרד - רקע שנסחף בקצב אחר מהרגליים הוא בדיוק מה שמסגיר
        "ריצה במקום".
        """
        i = self._i(t)
        return round(-float(self.oz[i]) * float(scale), 5)

    def controls_at(self, t: float) -> dict:
        """הבקרות שאינן רגליים: זרועות, גו, ראש. הרגליים ב-IK."""
        i = self._i(t)
        p = self.phi[i]
        c = 2 * math.pi * p
        arm = float(self.armA[i])
        lean = float(self.leanA[i])
        ctl = {
            # הזרוע הנגדית לרגל. ברגע שרגל שמאל נעוצה מלפנים
            # (p=0) יד שמאל אחורה - זו הנגדיות, והיא מה שמונע
            # "הליכת בובה" שבה היד והרגל זזות יחד.
            "arm_fwd_L": -arm * math.cos(c),
            "arm_fwd_R": arm * math.cos(c),
            "elbow_L": 0.18 + arm * 0.55 * (0.5 - 0.5 * math.cos(c)),
            "elbow_R": 0.18 + arm * 0.55 * (0.5 + 0.5 * math.cos(c)),
            # **1.00 ולא 0.86.** נמדד ברנדור בדיקה שעל שפוד - שזרועו
            # ארוכה ב-7% וכתפו רחבה ב-16% - 0.86 משאיר את הזרוע
            # ב-30 מעלות מהגוף, וזרוע ארוכה בזווית כזו נקראת כזרוע
            # תקועה ולא כזרוע שמתנדנדת. ההורדה המלאה מצמידה אותה,
            # והנדנוד (`arm_fwd`) הוא מה שמוציא אותה משם.
            "arm_down_L": 1.00 - arm * 0.10,
            "arm_down_R": 1.00 - arm * 0.10,
            "shoulder_fwd_L": -arm * 0.22 * math.cos(c),
            "shoulder_fwd_R": arm * 0.22 * math.cos(c),
            # הגו: הטיה קדימה לפי המהירות, וסיבוב נגדי לאגן.
            "weight_fwd": lean,
            "spine_bend": lean * 0.55,
            "spine_twist": -arm * 0.26 * math.cos(c),
            "hips_yaw": arm * 0.20 * math.cos(c),
            # הראש מתייצב: הוא מקזז את הטיית הגו ואת הנדנוד.
            "neck_pitch": -lean * 0.75,
            "head_pitch": -lean * 0.35,
            "head_roll": -float(self.swayA[i]) * 6.0 * math.sin(c),
            "breath": 0.25 + 0.55 * float(self.leanA[i]),
        }
        return ctl

    def ik_at(self, t: float) -> dict:
        i = self._i(t)
        off = np.array([self.ox[i], self.oy[i], self.oz[i]])
        out = {}
        for side in ("L", "R"):
            out[f"foot_{side}"] = {"target": (self.target[side][i]
                                              - off).tolist()}
        return out

    def actor(self, t: float, extra: dict | None = None,
              extra_ik: dict | None = None) -> tuple[dict, dict]:
        """(בקרות, IK) לפריים, בחוזה של `showreel.Shot.a`. שני מעברים.

        הפיץ' של כף הרגל נמדד **בעולם**, והכיוון שלה תלוי גם בשוק -
        ואת השוק ה-IK סובב. לכן המעבר הראשון פותר את הרגל עם קרסול
        מאופס, מודד מה יצא, והמעבר השני מזמין את ההפרש בדיוק. בקרה
        שהוזמנה בלי המעבר הזה אינה מה שנראה על המסך: נמדד שהפרש
        הפיץ' בין "מה שהוזמן" ל"מה שיצא" מגיע ל-0.30 רדיאן, כלומר
        גדול מכל עוצמת המגע שיש כאן.
        """
        i = self._i(t)
        ctl = self.controls_at(t)
        if extra:
            # **התנועה גוברת על המשחק, לא להפך.** `extra` הוא פלט
            # של `showreel._emotion_actor` - פנים, מבט, נשימה - והוא
            # מגיע עם ערוצי גוף משלו (`weight_shift`, `leg_fwd_*`,
            # `knee_*`). דמות שרצה ומקבלת גם העברת משקל של עמידה
            # נראית כמי שמנסה לעמוד בזמן ריצה. לכן ערוצי התנועה
            # נכתבים **אחרי**, ומנצחים.
            merged = dict(extra)
            merged.update(ctl)
            ctl = merged
        ik = self.ik_at(t)
        if extra_ik:
            tmp = dict(extra_ik)
            tmp.update(ik)      # ה-IK של הרגליים גובר גם הוא
            ik = tmp
        q1 = controls.evaluate(self.skel, ctl, ik)
        W = self.skel.forward(q1)
        want = float(self.contA[i])
        for side in ("L", "R"):
            # רק רגל שנוגעת / עומדת לגעת מקבלת את פיץ' המגע.
            p = (self.phi[i] + _ph_of(side)) % 1.0
            stn = float(self.stanc[i])
            if p < stn:
                frac = p / max(stn, 1e-6)
                # עקב ראשון -> שטוח -> דחיפה על הבוהן
                w = (1.0 - _ss(frac / 0.28)) - _ss((frac - 0.72) / 0.28)
            else:
                u = (p - stn) / max(1.0 - stn, 1e-6)
                # באוויר: מתכוננת למגע לקראת הסוף
                w = -(1.0 - _ss(u / 0.35)) + _ss((u - 0.60) / 0.40)
            goal = want * w
            cur = _pitch(self.skel, W, side)
            ctl[f"ankle_{side}"] = float(
                np.clip(-(goal - cur) / (28.0 * D), -1.0, 1.0))
        return ctl, ik

    def pose(self, t: float, extra: dict | None = None,
             extra_ik: dict | None = None) -> tuple[dict, dict]:
        """(בקרות, סיבובי עצמות). זה מה שהמדידה בפייתון עובדת עליו."""
        ctl, ik = self.actor(t, extra, extra_ik)
        return ctl, controls.evaluate(self.skel, ctl, ik)

    def drive(self, base):
        """עוטף שחקן קיים (`showreel._emotion_actor`) בתנועת מקום.

        מחזיר פונקציה בחוזה `Shot.a`: `(u, t) -> (בקרות, IK)`. ה-`t`
        הוא **מתחילת השוט**, בדיוק כמו של `ens_of`.
        """
        # **ה-tuple שהשחקן מחזיר אינו תמיד באורך 2.** `_emotion_actor`
        # מחזיר (בקרות, IK) בשוט רגיל ו-(בקרות, IK, צורות-פנים) כשיש
        # מורפים, ופריקה ל-2 נפלה על `too many values to unpack` רק
        # בפריים הראשון של הרנדור - כלומר אחרי בניית הסביבה כולה.
        # מה שמעבר לשניים עובר **כמו שהוא**: זה לא שלנו.
        def wrapped(u, t, _b=base):
            res = _b(u, t)
            ctl, ik = res[0], (res[1] if len(res) > 1 else {})
            new_ctl, new_ik = self.actor(t, extra=ctl, extra_ik=ik)
            return (new_ctl, new_ik) + tuple(res[2:])
        return wrapped

    # --------------------------------------------------------- מדידה

    def world_foot(self, t: float, side: str, q: dict | None = None):
        """מקום הקרסול **בעולם**: היסט הקבוצה + FK. זה מה שרואים."""
        i = self._i(t)
        if q is None:
            _ctl, q = self.pose(t)
        W = self.skel.forward(q)
        idx = self.skel.by_name[f"foot_{side}"].index
        return (np.array([self.ox[i], self.oy[i], self.oz[i]])
                + W[idx][:3, 3])

    def world_toe(self, t: float, side: str, q: dict):
        i = self._i(t)
        W = self.skel.forward(q)
        idx = self.skel.by_name[f"toe_tip_{side}"].index
        return (np.array([self.ox[i], self.oy[i], self.oz[i]])
                + W[idx][:3, 3])

    def sample(self, step: int = 1) -> dict:
        """מריץ את כל הקטע פעם אחת ושומר את כל מה שנמדד ממנו."""
        idx = list(range(0, self.n + 1, max(1, int(step))))
        rec = {"i": idx, "t": [i / self.fps for i in idx],
               "foot": {"L": [], "R": []}, "toe": {"L": [], "R": []},
               "err": {"L": [], "R": []}, "pitch": {"L": [], "R": []},
               "hip": []}
        for i in idx:
            t = i / self.fps
            _ctl, q = self.pose(t)
            W = self.skel.forward(q)
            off = np.array([self.ox[i], self.oy[i], self.oz[i]])
            for side in ("L", "R"):
                fi = self.skel.by_name[f"foot_{side}"].index
                ti = self.skel.by_name[f"toe_tip_{side}"].index
                fw = off + W[fi][:3, 3]
                tw = off + W[ti][:3, 3]
                rec["foot"][side].append(fw)
                rec["toe"][side].append(tw)
                rec["err"][side].append(
                    float(np.linalg.norm(fw - self.target[side][i])))
                rec["pitch"][side].append(_pitch(self.skel, W, side))
            hi = self.skel.by_name["hips"].index
            rec["hip"].append(off + W[hi][:3, 3])
        for side in ("L", "R"):
            rec["foot"][side] = np.array(rec["foot"][side])
            rec["toe"][side] = np.array(rec["toe"][side])
        rec["hip"] = np.array(rec["hip"])
        return rec


def _pitch(skel: Skeleton, W: np.ndarray, side: str) -> float:
    """הפיץ' של כף הרגל בעולם, ברדיאנים. חיובי = הבוהן מורמת.

    נמדד על הווקטור קרסול->קצה הבוהן, ומנורמל כך שבפוזת המנוחה
    התוצאה היא אפס בדיוק - אחרת "אפס" היה תלוי בזווית הבנייה של
    כף הרגל, שהיא שונה בין דמויות בגובה שונה.
    """
    fi = skel.by_name[f"foot_{side}"].index
    ti = skel.by_name[f"toe_tip_{side}"].index
    v = W[ti][:3, 3] - W[fi][:3, 3]
    r = (np.asarray(skel.by_name[f"toe_tip_{side}"].rest, float)
         - np.asarray(skel.by_name[f"foot_{side}"].rest, float))
    a = math.atan2(v[1], math.hypot(v[0], v[2]))
    a0 = math.atan2(r[1], math.hypot(r[0], r[2]))
    return a - a0


# ------------------------------------------------------------- שערים


def audit(mv_walk: Move, mv_run: Move, mv_mix: Move,
          step: int = 1) -> dict:
    """שערי הקבלה של התנועה. כולם נמדדים, אף אחד אינו מוצהר."""
    out: dict = {}

    def chk(name, ok, detail):
        out[name] = {"pass": bool(ok), "detail": str(detail)}

    for mv, nm in ((mv_walk, "הליכה"), (mv_run, "ריצה")):
        rec = mv.sample(step)
        ti = {v: k for k, v in enumerate(rec["i"])}

        # 1 · אין החלקה בתוך מדרך
        worst = 0.0
        where = ""
        for side in ("L", "R"):
            for item in mv.plants[side]:
                i0, i1 = item["at"]
                sel = [ti[i] for i in range(i0, i1 + 1) if i in ti]
                if len(sel) < 2:
                    continue
                xz = rec["foot"][side][sel][:, [0, 2]]
                d = float(np.abs(xz - xz[0]).max())
                if d > worst:
                    worst, where = d, f"{side}@{i0}-{i1}"
        chk(f"{nm}: אין החלקה בתוך מדרך", worst < 0.004,
            f"{worst * 1000:.2f} מ\"מ ({where})")

        # 2 · ה-IK מגיע ליעד
        err = max(max(rec["err"]["L"]), max(rec["err"]["R"]))
        chk(f"{nm}: ה-IK מגיע ליעד", err < 0.006,
            f"{err * 1000:.2f} מ\"מ מרחק מרבי")

        # 3 · מרחק אמיתי: הנסיעה = מספר המחזורים כפול המחזור, ומרווח
        #     נקודות הדריכה של אותה רגל = המחזור. שתי הבדיקות יחד
        #     הן מה שמוכיח שהגוף והרגליים מודדים את אותו מרחק: אחת
        #     לבדה עוברת גם כששתי המערכות סחופות זו מזו.
        travel = float(mv.oz[-1] - mv.oz[0])
        cycles = float(mv.phi[-1] - mv.phi[0])
        cyc = float(mv.cyc[-1])
        ds = []
        for side in ("L", "R"):
            ps = [it["pos"][2] for it in mv.plants[side]]
            ds += [b - a for a, b in zip(ps, ps[1:])]
        med = float(np.median(ds)) if ds else 0.0
        chk(f"{nm}: הנסיעה שווה למחזורים כפול המחזור",
            cycles > 1.0 and abs(travel - cycles * cyc) < 0.03 * travel,
            f"נסיעה {travel:.3f} מ' · {cycles:.2f} מחזורים × "
            f"{cyc:.3f} מ' = {cycles * cyc:.3f}")
        chk(f"{nm}: ומרווח הדריכות של אותה רגל הוא המחזור",
            len(ds) >= 2 and abs(med - cyc) < 0.03 * cyc,
            f"{med:.3f} מ' מול {cyc:.3f} · צעד {mv.step[-1]:.3f} מ'")

        # 4 · גובה כף הרגל: לא חודרת לקרקע
        lo = min(float(rec["foot"]["L"][:, 1].min()),
                 float(rec["foot"]["R"][:, 1].min()))
        chk(f"{nm}: אף רגל אינה חודרת לקרקע", lo > mv.ankle_y - 0.004,
            f"{(lo - mv.ankle_y) * 1000:.2f} מ\"מ מתחת לקרסול המנוחה")

        # 5 · שלב טיסה - קיים בריצה ואינו קיים בהליכה
        thr = mv.ankle_y + 0.02 * mv.k
        both = ((rec["foot"]["L"][:, 1] > thr)
                & (rec["foot"]["R"][:, 1] > thr))
        nfly = int(both.sum())
        if mv is mv_run:
            chk("ריצה: יש שלב טיסה (שתי הרגליים באוויר)", nfly >= 6,
                f"{nfly} פריימים מתוך {len(rec['i'])}")
        else:
            chk("הליכה: אין אף פריים ששתי הרגליים באוויר", nfly == 0,
                f"{nfly} פריימים")

        # 6 · העברת משקל בפאזה של הרגל הדורכת
        corr = []
        for side, sg in (("L", 1.0), ("R", -1.0)):
            m = mv.stance_mask[side][rec["i"]]
            sway = np.array([mv.ox[i] - mv.lane for i in rec["i"]])
            if m.sum() and (~m).sum():
                corr.append(sg * (float(sway[m].mean())
                                  - float(sway[~m].mean())))
        ok = len(corr) == 2 and min(corr) > 0.002
        chk(f"{nm}: האגן נע אל הרגל הדורכת",
            ok, f"{[round(c * 1000, 2) for c in corr]} מ\"מ")

        # 7 · סדר המגע
        # **הפריים הקרוב ביותר בתוך המדרך, ולא הפריים המדויק.**
        # הגרסה הראשונה דרשה `i0 in ti`, כלומר שפריים הנגיעה עצמו
        # ייפול על רשת הדגימה. ב-`step=3` הוא פשוט לא נפל, הרשימה
        # יצאה ריקה, והחציון של רשימה ריקה הוא 0.0 - כלומר **השער
        # דיווח "הבוהן לא מורמת" על ריג תקין לגמרי**. רשימה ריקה
        # היא "לא נמדד", והיא כשל מפורש ולא אפס.
        pit = []
        for side in ("L", "R"):
            for item in mv.plants[side][1:]:
                i0, i1 = item["at"]
                near = [i for i in rec["i"] if i0 <= i <= i1]
                if near:
                    pit.append(rec["pitch"][side][ti[min(near)]])
        md = float(np.median(pit)) if pit else 0.0
        chk(f"{nm}: נמדדו רגעי מגע בפועל", len(pit) >= 3, f"{len(pit)}")
        if mv is mv_run:
            chk("ריצה: כף הרגל ראשונה במגע (הבוהן מונמכת)", md < -0.06,
                f"פיץ' חציוני במגע {md:+.3f} רדיאן")
        else:
            chk("הליכה: העקב ראשון במגע (הבוהן מורמת)", md > 0.06,
                f"פיץ' חציוני במגע {md:+.3f} רדיאן")

        # 8 · ההילוכים אינם אותו דבר
        out[f"_{nm}_cad"] = {"pass": True, "detail": f"{mv.cad[-1]:.2f}"}

    # 9 · ניגוד בין ההילוכים: הריצה מהירה יותר וצעדה ארוך יותר
    chk("הריצה מהירה מההליכה, וצעדה ארוך יותר",
        mv_run.vel[-1] > mv_walk.vel[-1] * 1.8
        and mv_run.step[-1] > mv_walk.step[-1] * 1.25,
        f"{mv_walk.vel[-1]:.2f}->{mv_run.vel[-1]:.2f} מ'/ש' · "
        f"צעד {mv_walk.step[-1]:.3f}->{mv_run.step[-1]:.3f} מ'")

    # 10 · המעבר: רציף בנגזרת, ובלי קפיצת תאוצה
    v = np.gradient(mv_mix.oz, 1.0 / mv_mix.fps)
    a = np.gradient(v, 1.0 / mv_mix.fps)
    j = float(np.abs(np.diff(a)).max())
    chk("המעבר עמידה->הליכה->ריצה רציף בנגזרת",
        j < 6.0 and float(np.abs(np.diff(v)).max()) < 0.35,
        f"קפיצת תאוצה מרבית {j:.2f} מ'/ש\"² לפריים")
    chk("ובתחילתו הדמות באמת עומדת במקום",
        abs(float(mv_mix.oz[2] - mv_mix.oz[0])) < 1e-9,
        f"{abs(float(mv_mix.oz[2] - mv_mix.oz[0])) * 1000:.4f} מ\"מ")
    chk("ובסופו היא באמת רצה",
        float(mv_mix.vel[-1]) > 2.0, f"{float(mv_mix.vel[-1]):.2f} מ'/ש'")

    # 10ב · המסילה: הגוף אינו נוסע, הרגל כן, והרקע בקצב שלה
    tm = Move(mv_run.skel, [("run", 2.0)], fps=mv_run.fps, treadmill=True)
    offs = [tm.offset(i / tm.fps) for i in range(0, tm.n + 1, 3)]
    chk("במסילה הגוף נשאר בפריים",
        max(abs(o["oz"]) for o in offs) == 0.0
        and max(abs(o["ox"] - tm.lane) for o in offs) == 0.0,
        "oz=0 ו-ox=lane בכל הפריימים")
    # **הנסיגה נמדדת בתוך מדרך אחד ולא על הקטע כולו.** הניסיון
    # הראשון כאן השווה את הפריים הראשון לאחרון וקיבל 0.12 מ' מול
    # 7.04 - ובצדק: על מסילה הרגל *אינה* נסחפת אחורה בהצטברות, היא
    # חוזרת קדימה בנדנוד. מה שנסחף אחורה הוא **הרגל הדורכת, בזמן
    # שהיא דורכת**, ובדיוק במרחק שהגוף עבר באותו זמן.
    run = max(tm.plants["L"], key=lambda it: it["at"][1] - it["at"][0])
    i0, i1 = run["at"]
    rel0 = tm.target["L"][i0][2] - tm.oz[i0]
    rel1 = tm.target["L"][i1][2] - tm.oz[i1]
    went = float(tm.oz[i1] - tm.oz[i0])
    chk("ובכל זאת הרגל הדורכת נסחפת אחורה במהירות ההילוך",
        went > 0.1 and abs((rel0 - rel1) - went) < 1e-9,
        f"{rel0 - rel1:.4f} מ' אחורה מול {went:.4f} מ' נסיעה "
        f"במדרך של {i1 - i0 + 1} פריימים")
    pans = [tm.pan_of(i / tm.fps) for i in range(0, tm.n + 1, 3)]
    chk("והרקע נסחף באותו קצב בדיוק",
        pans[0] == 0.0 and pans[-1] < 0
        and abs(pans[-1] / -0.055 - tm.oz[-1]) < 1e-3,
        f"{pans[0]:.3f} -> {pans[-1]:.3f}")

    # 11 · אורך הצעד נגזר מהרגל ולא מקודד
    # הגובה של ההשוואה הוא **70% מהנמדד** ולא 1.30 מ' קבוע. הגרסה
    # הראשונה כאן קיבעה 1.30, והיא נפלה בצדק על כופתה (1.12 מ'):
    # "דמות נמוכה צועדת קצר" נבדק מול דמות **גבוהה** מהנמדדת,
    # כלומר המדד בדק את הכיוון ההפוך בלי להודיע.
    h_lo = mv_run.skel.height * 0.70
    low = Move(Skeleton(height=h_lo), [("run", 2.0)], fps=mv_run.fps)
    chk("אורך הצעד נגזר מגאומטריית הרגל (דמות נמוכה - צעד קצר)",
        low.step[-1] < mv_run.step[-1] * 0.92,
        f"{h_lo:.2f} מ' -> {low.step[-1]:.3f} · "
        f"{mv_run.skel.height:.2f} מ' -> {mv_run.step[-1]:.3f}")

    # 12 · רמפות חופפות נדחות בבנייה
    bad = False
    try:
        Move(mv_walk.skel, [("stand", 0.2), ("walk", 0.2), ("run", 1.0)],
             fps=mv_walk.fps)
    except ValueError:
        bad = True
    chk("רמפות חופפות נדחות בבנייה", bad, "ValueError" if bad else "עברה")

    return {k: v for k, v in out.items() if not k.startswith("_")}


def default_audit(height: float = 1.70, step: int = 2) -> dict:
    skel = Skeleton(height=height)
    return audit(Move(skel, [("walk", 4.0)], fps=30),
                 Move(skel, [("run", 4.0)], fps=30),
                 Move(skel, [("stand", 1.2), ("walk", 2.6), ("run", 4.2)],
                      fps=30),
                 step=step)


def passed(height: float = 1.70, step: int = 2) -> bool:
    return all(v["pass"] for v in default_audit(height, step).values())


def main(argv=None) -> int:
    sys.stdout.reconfigure(encoding="utf-8")
    rep = default_audit()
    bad = 0
    for k, v in rep.items():
        print(("✅" if v["pass"] else "❌"), k, "-", v["detail"])
        bad += 0 if v["pass"] else 1
    print(f"\n{len(rep) - bad}/{len(rep)} עברו")
    return 0 if bad == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
