# -*- coding: utf-8 -*-
"""מדידת זהות: האם זו אותה דמות אחרי שהיא זזה ואחרי שהמצלמה זזה.

למה לא השוואת היסטוגרמות צבע, כמו שתכננתי בהתחלה: שלושה יועצים
חיצוניים פסלו את זה מאותה סיבה, ובצדק - היסטוגרמה משתנה מהתאורה
ומזווית המצלמה גם כשהדמות זהה לחלוטין, ולכן היא מודדת רנדור ולא זהות.

מה שנמדד כאן במקום הוא **גאומטריה**: אוסף מדידות שחייבות להיות
חסינות לפוזה, כי הן יושבות בתוך אזור קשיח אחד או בין שתי עצמות
שהמרחק ביניהן קבוע מעצם הבנייה (סיבוב לא משנה אורך).

אם המשקולות דולפות - למשל גלגל העין מקבל טיפת משקולת לסת - המרחק בין
העיניים *כן* ישתנה כשהפה נפתח, והמדד יתפוס את זה. זה בדיוק מה שהמדד
אמור למצוא.
"""
from __future__ import annotations

import numpy as np

from .skeleton import Skeleton


def skin(skel: Skeleton, attrs: dict, local_q: dict | None = None) -> np.ndarray:
    """Linear Blend Skinning בפייתון. מחזיר עמדות אחרי הפוזה."""
    W = skel.forward(local_q or {})
    M = skel.skin_matrices(W)                     # (B,4,4)
    pos = attrs["position"].astype(np.float64)
    si = attrs["skinIndex"].astype(np.int32)
    sw = attrs["skinWeight"].astype(np.float64)
    out = np.zeros_like(pos)
    ph = np.concatenate([pos, np.ones((pos.shape[0], 1))], axis=1)
    for k in range(si.shape[1]):
        mats = M[si[:, k]]                        # (N,4,4)
        p = np.einsum("nij,nj->ni", mats, ph)[:, :3]
        out += p * sw[:, k:k + 1]
    return out


# ------------------------------------------------------------ נקודות ציון


def landmarks(skel: Skeleton, attrs: dict) -> dict[str, int]:
    """הקודקוד הקרוב ביותר לכל עצם-ציון. זה הופך מדידות שלד למדידות
    על **העור** - וזה מה שבודק את העור ולא רק את השלד."""
    pos = attrs["position"].astype(np.float64)
    want = ["eye_L", "eye_R", "head_tip", "jaw_tip", "chest",
            "clavicle_L", "clavicle_R", "hand_L", "hand_R",
            "foot_L", "foot_R", "hips",
            "index_tip_L", "pinky_tip_L", "thumb_tip_L"]
    out = {}
    for name in want:
        b = skel.by_name.get(name)
        if b is None:
            continue
        d = np.linalg.norm(pos - np.asarray(b.rest), axis=1)
        out[name] = int(np.argmin(d))
    return out


# מדידות זהות שחייבות להיות **חסינות לפוזה**. נמדדות על מקורות
# העצמות ולא על קודקודים: קודקוד על פני גלגל העין זז כשהעין מביטה
# לצד, וזו תנועה נכונה - לא סחיפת זהות. המדידה הראשונה שכתבתי כאן
# מדדה בטעות מרחק בין קצות אצבעות, שמשתנה לגיטימית באגרוף, והחזירה
# "21% סחיפה" על דמות תקינה לחלוטין. המדד היה שבור, לא הדמות.
FACE_MEASURES = [
    ("interocular", "eye_L", "eye_R"),
    ("eye_to_crown_L", "eye_L", "head_tip"),
    ("eye_to_crown_R", "eye_R", "head_tip"),
    ("brow_span", "brow_out_L", "brow_out_R"),
    ("cheek_span", "cheek_L", "cheek_R"),
    ("shoulder_width", "clavicle_L", "clavicle_R"),
    ("hip_width", "thigh_L", "thigh_R"),
]


def bone_world(skel: Skeleton, local_q: dict | None = None) -> dict[str, np.ndarray]:
    W = skel.forward(local_q or {})
    return {b.name: W[b.index][:3, 3] for b in skel.bones}


def face_measures(skel: Skeleton, local_q: dict | None = None) -> dict[str, float]:
    bw = bone_world(skel, local_q)
    out = {}
    for name, a, b in FACE_MEASURES:
        if a in bw and b in bw:
            out[name] = float(np.linalg.norm(bw[a] - bw[b]))
    return out


def bone_lengths(skel: Skeleton, local_q: dict | None = None) -> dict[str, float]:
    """אורך כל פרק עצם. סיבוב לא משנה אורך, ולכן כל סטייה כאן היא
    שגיאה אמיתית בריג (מתיחה, קריסה, nan)."""
    bw = bone_world(skel, local_q)
    out = {}
    for b in skel.bones:
        if b.parent is None:
            continue
        out[f"{b.parent}->{b.name}"] = float(
            np.linalg.norm(bw[b.name] - bw[b.parent]))
    return out


def rigid_vertices(attrs: dict, min_weight: float = 0.995):
    """קודקודים ששייכים כמעט לגמרי לעצם אחת. עליהם אפשר לשחזר את פוזת
    המנוחה בדיוק, ולכן הם הוכחת הזהות: אם השחזור מדויק, הצורה לא זזה -
    רק הסיבובים."""
    sw = attrs["skinWeight"].astype(np.float64)
    si = attrs["skinIndex"].astype(np.int64)
    k = np.argmax(sw, axis=1)
    w = sw[np.arange(sw.shape[0]), k]
    bone = si[np.arange(si.shape[0]), k]
    sel = np.nonzero(w >= min_weight)[0]
    return sel, bone[sel]


def rest_recovery_error(skel: Skeleton, attrs: dict, local_q: dict | None,
                        sel=None, bones=None) -> dict:
    """מחזיר את פוזת המנוחה מתוך הפוזה, דרך היפוך מטריצת העור של העצם
    השולטת, ומשווה למקור. שגיאה גדולה = הזהות נמחקה בפוזה."""
    if sel is None:
        sel, bones = rigid_vertices(attrs)
    if len(sel) == 0:
        return {"max_mm": float("inf"), "mean_mm": float("inf"), "verts": 0}
    W = skel.forward(local_q or {})
    M = skel.skin_matrices(W)
    pos = attrs["position"].astype(np.float64)
    posed = skin(skel, attrs, local_q)
    err = np.zeros(len(sel))
    for b in np.unique(bones):
        idx = sel[bones == b]
        inv = np.linalg.inv(M[b])
        p = posed[idx]
        ph = np.concatenate([p, np.ones((p.shape[0], 1))], axis=1)
        rec = (inv @ ph.T).T[:, :3]
        err[bones == b] = np.linalg.norm(rec - pos[idx], axis=1)
    return {"max_mm": float(err.max() * 1000), "mean_mm": float(err.mean() * 1000),
            "verts": int(len(sel))}


def drift(samples: list[dict[str, float]]) -> dict:
    """סחיפה = הסטייה היחסית המרבית של כל מדידה בין כל הדגימות."""
    if not samples:
        return {"max_rel": 1.0, "per_measure": {}}
    keys = [k for k in samples[0] if all(k in s for s in samples)]
    per = {}
    for k in keys:
        vals = np.array([s[k] for s in samples], dtype=np.float64)
        base = float(np.median(vals))
        if base < 1e-9:
            continue
        per[k] = float(np.max(np.abs(vals - base)) / base)
    worst = max(per, key=per.get) if per else None
    return {"max_rel": max(per.values()) if per else 1.0,
            "worst": worst, "per_measure": per}


def pose_separation(skel: Skeleton, attrs: dict,
                    poses: dict[str, dict]) -> dict:
    """כמה הפוזות באמת שונות זו מזו, כאחוז מגובה הדמות.

    בלי המדד הזה "אפס סחיפת זהות" הוא חסר ערך: גם דמות שלא זזה בכלל
    תעבור. זה החלק שמונע מהבדיקה לרמות את עצמה.
    """
    keys = sorted(poses)
    pts = {k: skin(skel, attrs, poses[k]) for k in keys}
    pairs = {}
    for i, a in enumerate(keys):
        for b in keys[i + 1:]:
            d = np.linalg.norm(pts[a] - pts[b], axis=1)
            pairs[f"{a}|{b}"] = {
                "mean_pct": float(d.mean() / skel.height * 100),
                "max_pct": float(d.max() / skel.height * 100)}
    means = [v["mean_pct"] for v in pairs.values()]
    return {"min_mean_pct": float(min(means)) if means else 0.0,
            "max_max_pct": float(max(v["max_pct"] for v in pairs.values()))
            if pairs else 0.0,
            "pairs": pairs}


def identity_report(skel: Skeleton, attrs: dict,
                    poses: dict[str, dict]) -> dict:
    """הדוח המלא: שלד, עור, פנים, והפרדה בין הפוזות."""
    keys = sorted(poses)
    sel, bones = rigid_vertices(attrs)
    bl = [bone_lengths(skel, poses[k]) for k in keys]
    fm = [face_measures(skel, poses[k]) for k in keys]
    rec = {k: rest_recovery_error(skel, attrs, poses[k], sel, bones)
           for k in keys}
    bl_d = drift(bl)
    fm_d = drift(fm)
    worst_rec = max(v["max_mm"] for v in rec.values())
    sep = pose_separation(skel, attrs, poses)
    return {
        "bone_length_drift": bl_d,
        "face_measure_drift": fm_d,
        "rest_recovery": rec,
        "rest_recovery_worst_mm": worst_rec,
        "rigid_verts": int(len(sel)),
        "pose_separation": sep,
        "max_rel_drift": max(bl_d["max_rel"], fm_d["max_rel"]),
        # סף שחזור המנוחה: 0.5 מ"מ על דמות בגובה 1.70 מטר, כלומר 0.03%.
        # הנתונים נשמרים ב-float32 (כך דורש glTF), ולכן רעש של ~0.07
        # מ"מ הוא הדיוק של הייצוג עצמו ולא שגיאת ריג. סף של 0.01 מ"מ
        # נוסה כאן ונפל על דיוק מכונה בלבד, על דמות תקינה לחלוטין.
        "rest_recovery_limit_mm": 0.5,
        "pose_separation_limit_pct": 0.5,
        "passes": bool(bl_d["max_rel"] < 1e-6 and fm_d["max_rel"] < 1e-6
                       and worst_rec < 0.5 and sep["min_mean_pct"] > 0.5),
    }


# ------------------------------------------------------------ בדיקות עור


def weight_health(attrs: dict, skel: Skeleton) -> dict:
    """בריאות המשקולות - מה ששובר דמויות בפועל."""
    sw = attrs["skinWeight"].astype(np.float64)
    si = attrs["skinIndex"].astype(np.int64)
    sums = sw.sum(axis=1)
    name_of = {b.index: b.name for b in skel.bones}
    helper = {b.index for b in skel.bones if b.kind == "helper"}
    on_helper = float(np.mean(np.any(np.isin(si, list(helper)) & (sw > 0.02),
                                     axis=1))) if helper else 0.0
    used = set(np.unique(si[sw > 0.001]).tolist())
    unused = sorted(name_of[i] for i in range(len(skel.bones))
                    if i not in used and skel.bones[i].kind != "helper")
    return {
        "sum_min": float(sums.min()),
        "sum_max": float(sums.max()),
        "sum_ok": bool(np.allclose(sums, 1.0, atol=1e-4)),
        "negative": int(np.sum(sw < -1e-6)),
        "max_influences": int(sw.shape[1]),
        "verts_on_helper_bones": on_helper,
        "bones_without_weights": unused,
        "bones_used": len(used),
    }


# ------------------------------------------------------------ מדד תמונה


def image_signature(png_bytes: bytes) -> dict:
    """חתימה של רנדור: שיעור הכיסוי, מרכז המסה, וצבע חציוני של הדמות.

    משמש לשני דברים בלבד, ולא למדידת זהות:
    (1) לאמת שבאמת יש דמות בפריים ושהיא לא גזורה או ריקה,
    (2) לאמת שרנדור חוזר של אותה פוזה ואותה מצלמה יוצא זהה.
    """
    import io

    from PIL import Image
    im = Image.open(io.BytesIO(png_bytes)).convert("RGBA")
    a = np.asarray(im).astype(np.float64)
    alpha = a[:, :, 3] / 255.0
    mask = alpha > 0.35
    n = int(mask.sum())
    h, w = mask.shape
    if n == 0:
        return {"coverage": 0.0, "pixels": 0, "cx": 0.0, "cy": 0.0,
                "color": [0, 0, 0], "bbox": None}
    ys, xs = np.nonzero(mask)
    rgb = a[:, :, :3][mask]
    return {
        "coverage": n / float(h * w),
        "pixels": n,
        "cx": float(xs.mean() / w),
        "cy": float(ys.mean() / h),
        "color": [float(v) for v in np.median(rgb, axis=0)],
        "bbox": [int(xs.min()), int(ys.min()), int(xs.max()), int(ys.max())],
        "size": [w, h],
    }
