# -*- coding: utf-8 -*-
"""שלד הומנואידי לייצור + מנגנון הערכת פוזה (FK, IK, תנועה משנית).

למה שלד תבנית ולא "זיהוי עצמות בתוך רשת שרירותית":
נוסה כאן על הפלט של Hunyuan3D (רשת של 128 אלף קודקודים בלי טקסטורה, בלי
חלוקה לאיברים). מיקום עצמות לפי מרכזי מסה של פרוסות נתן מרפקים בתוך
הצלעות, כי שיער שיורד לכתפיים ובגד רחב מזיזים את מרכז המסה. שלושה
יועצים חיצוניים (Qwen3.8, Command A, Codestral) אמרו את אותו דבר:
להתאים שלד ייחוס לרשת, לא להמציא שלד מהרשת.

כאן הולכים צעד אחד רחוק יותר: **הגאומטריה נבנית סביב השלד**
(basemesh.py), ולכן המשקולות אינן ניחוש אלא נגזרות מהבנייה. זה מה
שמבטיח אפס סחיפת זהות - הצורה קבועה, והפוזה היא רק סיבוב עצמות.

מערכת צירים: Y מעלה, Z קדימה, X שמאלה (side=+1 = שמאל הדמות).
יחידות: מטרים. גובה ברירת מחדל 1.70.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np

# ---------------------------------------------------------------- כלי מתמטיקה


def quat_from_euler(rx: float, ry: float, rz: float) -> np.ndarray:
    """סדר XYZ פנימי (כמו THREE.Euler ברירת המחדל). רדיאנים."""
    cx, sx = math.cos(rx / 2), math.sin(rx / 2)
    cy, sy = math.cos(ry / 2), math.sin(ry / 2)
    cz, sz = math.cos(rz / 2), math.sin(rz / 2)
    return np.array([
        sx * cy * cz + cx * sy * sz,
        cx * sy * cz - sx * cy * sz,
        cx * cy * sz + sx * sy * cz,
        cx * cy * cz - sx * sy * sz,
    ], dtype=np.float64)


def quat_from_axis_angle(axis, angle: float) -> np.ndarray:
    a = np.asarray(axis, dtype=np.float64)
    n = np.linalg.norm(a)
    if n < 1e-12:
        return np.array([0.0, 0.0, 0.0, 1.0])
    a = a / n
    s = math.sin(angle / 2)
    return np.array([a[0] * s, a[1] * s, a[2] * s, math.cos(angle / 2)])


def quat_mul(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    ax, ay, az, aw = a
    bx, by, bz, bw = b
    return np.array([
        aw * bx + ax * bw + ay * bz - az * by,
        aw * by - ax * bz + ay * bw + az * bx,
        aw * bz + ax * by - ay * bx + az * bw,
        aw * bw - ax * bx - ay * by - az * bz,
    ], dtype=np.float64)


def quat_to_mat(q: np.ndarray) -> np.ndarray:
    x, y, z, w = q
    return np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
        [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
        [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
    ], dtype=np.float64)


def compose(t: np.ndarray, q: np.ndarray, s: np.ndarray | None = None) -> np.ndarray:
    m = np.eye(4)
    r = quat_to_mat(q)
    if s is not None:
        r = r * np.asarray(s, dtype=np.float64)[None, :]
    m[:3, :3] = r
    m[:3, 3] = t
    return m


def quat_slerp(a: np.ndarray, b: np.ndarray, t: float) -> np.ndarray:
    d = float(np.dot(a, b))
    if d < 0:
        b, d = -b, -d
    if d > 0.9995:
        q = a + t * (b - a)
        return q / np.linalg.norm(q)
    th = math.acos(max(-1.0, min(1.0, d)))
    s = math.sin(th)
    return (math.sin((1 - t) * th) / s) * a + (math.sin(t * th) / s) * b


# ---------------------------------------------------------------- מבנה השלד


@dataclass
class Bone:
    name: str
    parent: str | None
    rest: tuple            # מקום המפרק במרחב העולם בפוזת המנוחה
    kind: str = "body"     # body | face | finger | helper
    springy: float = 0.0   # 0 = קשיח. >0 = משתתף בתנועה משנית
    index: int = -1
    children: list = field(default_factory=list)


H = 1.70  # גובה ייחוס


def _mirror(name: str, pos, kind, springy=0.0):
    """מחזיר שתי רשומות, שמאל וימין, מסימטריה ב-X."""
    x, y, z = pos
    return [(f"{name}_L", (x, y, z), kind, springy),
            (f"{name}_R", (-x, y, z), kind, springy)]


def _spec(accessories: tuple = ()):
    """טבלת העצמות: (שם, הורה, מקום-מנוחה, סוג, קפיציות)."""
    S = []

    def add(name, parent, pos, kind="body", springy=0.0):
        S.append((name, parent, tuple(float(v) for v in pos), kind, springy))

    # --- עמוד שדרה
    add("root", None, (0, 0, 0))
    add("hips", "root", (0, 0.950, 0))
    add("spine_01", "hips", (0, 1.055, 0))
    add("spine_02", "spine_01", (0, 1.160, 0))
    add("chest", "spine_02", (0, 1.300, 0), "body", 0.35)
    add("neck", "chest", (0, 1.440, 0.005))
    add("head", "neck", (0, 1.520, 0.0))
    add("head_tip", "head", (0, 1.700, 0.0), "helper")

    # --- ריג פנים (כולם בני head, חוץ מהלשון שהיא בת הלסת)
    add("jaw", "head", (0, 1.556, 0.018), "face")
    add("jaw_tip", "jaw", (0, 1.512, 0.082), "helper")
    add("tongue_01", "jaw", (0, 1.552, 0.030), "face")
    add("tongue_02", "tongue_01", (0, 1.552, 0.062), "face")
    for nm, p, k, sp in _mirror("eye", (0.0315, 1.5950, 0.0640), "face"):
        add(nm, "head", p, k, sp)
    for nm, p, k, sp in _mirror("eyelid_up", (0.0315, 1.5985, 0.0660), "face"):
        add(nm, "head", p, k, sp)
    for nm, p, k, sp in _mirror("eyelid_lo", (0.0315, 1.5905, 0.0660), "face"):
        add(nm, "head", p, k, sp)
    for nm, p, k, sp in _mirror("brow_in", (0.0150, 1.6180, 0.0720), "face"):
        add(nm, "head", p, k, sp)
    for nm, p, k, sp in _mirror("brow_out", (0.0480, 1.6160, 0.0610), "face"):
        add(nm, "head", p, k, sp)
    for nm, p, k, sp in _mirror("cheek", (0.0430, 1.5680, 0.0580), "face"):
        add(nm, "head", p, k, sp)

    # --- זרועות וידיים
    FING = [
        # (שם, מקום בסיס ביחס לשורש כף היד, אורך הפרק, פיזור)
        ("thumb",  (0.030, -0.012, 0.028), 0.030, 0.55),
        ("index",  (0.098, 0.004, 0.022), 0.029, 0.16),
        ("middle", (0.102, 0.004, 0.002), 0.032, 0.02),
        ("ring",   (0.098, 0.002, -0.018), 0.029, -0.13),
        ("pinky",  (0.090, 0.000, -0.036), 0.024, -0.28),
    ]
    for side, s in (("L", 1.0), ("R", -1.0)):
        add(f"clavicle_{side}", "chest", (s * 0.038, 1.412, 0.016))
        add(f"upperarm_{side}", f"clavicle_{side}", (s * 0.172, 1.398, 0.0))
        add(f"forearm_{side}", f"upperarm_{side}", (s * 0.447, 1.398, -0.004))
        add(f"hand_{side}", f"forearm_{side}", (s * 0.690, 1.398, 0.0))
        for fname, base, seglen, spread in FING:
            bx, by, bz = base
            px, py, pz = s * (0.690 + bx), 1.398 + by, bz
            parent = f"hand_{side}"
            for j in range(1, 4):
                nm = f"{fname}_{j:02d}_{side}"
                add(nm, parent, (px, py, pz), "finger")
                parent = nm
                px += s * seglen
                pz += spread * seglen * 0.35
            add(f"{fname}_tip_{side}", parent, (px, py, pz), "helper")

    # --- רגליים
    for side, s in (("L", 1.0), ("R", -1.0)):
        add(f"thigh_{side}", "hips", (s * 0.092, 0.920, 0.0))
        add(f"shin_{side}", f"thigh_{side}", (s * 0.095, 0.505, 0.006))
        add(f"foot_{side}", f"shin_{side}", (s * 0.098, 0.082, -0.012))
        add(f"toe_{side}", f"foot_{side}", (s * 0.098, 0.028, 0.098))
        add(f"toe_tip_{side}", f"toe_{side}", (s * 0.098, 0.022, 0.158), "helper")

    # --- עצמות רכות (TASK 08, תנועה משנית).
    #
    # הן **לא** עצמות גוף: הן לא זזות בפוזה ולא נוגעות בזהות, והן
    # קיימות רק כדי שהתנועה המשנית תהיה *גאומטרית* ולא פילטר על
    # הראש כולו. בלעדיהן השיער משוקלל ל-head בלבד, וכל "תנועת שיער"
    # היא בפועל תנועת ראש - וזה בדיוק מה שהמשימה אוסרת.
    #
    # קפיציות (springy) היא הקשיחות היחסית: קווצת צד דקה מתנדנדת
    # יותר מכל מסת העורף, ולכן הערכים אינם שווים.
    add("hair_front", "head", (0, 1.620, 0.072), "soft", 0.85)
    add("hair_side_L", "head", (0.080, 1.575, 0.0), "soft", 1.0)
    add("hair_side_R", "head", (-0.080, 1.575, 0.0), "soft", 1.0)
    add("hair_back", "head", (0, 1.570, -0.075), "soft", 0.9)
    for side, s in (("L", 1.0), ("R", -1.0)):
        add(f"sleeve_{side}", f"upperarm_{side}",
            (s * 0.400, 1.398, -0.004), "soft", 0.9)
        add(f"coat_{side}", "hips", (s * 0.075, 0.900, 0.0), "soft", 0.95)
    # אביזר: קיים רק בדמות שנבנתה איתו. עצם בלי גאומטריה היא עצם
    # בלי משקולות, ובדיקת בריאות המשקולות תופסת את זה מיד.
    if "glasses" in accessories:
        add("glasses", "head", (0, 1.595, 0.070), "soft", 0.4)

    return S


class Skeleton:
    """שלד תבנית, מוקטן/מותאם לגובה ולרוחב של דמות מסוימת."""

    def __init__(self, height: float = H, shoulder_scale: float = 1.0,
                 head_scale: float = 1.0, accessories: tuple = (),
                 asym: dict | None = None, arm_clear: float = 0.0):
        self.height = float(height)
        self.accessories = tuple(accessories)
        #: **TASK 15 · מרווח הזרוע.** ראה `dimorph.Dimorph.arm_clear`.
        #: הוא יושב כאן ולא בפוזה מפני ש-`controls.evaluate` מקבלת
        #: את השלד בכל אחד מ-20 אתרי הקריאה שלה, ואת הפוזה לא תמיד:
        #: הליכה, ריצה, מחוות דיבור, ספריית הפוזות והסרטון כולם
        #: בונים `arm_down` בעצמם. מגן שיושב בפוזה היה צריך להיזכר
        #: בעשרים מקומות, ומי שישכח יקבל זרוע חודרת בלי שום שגיאה.
        self.arm_clear = max(0.0, min(1.0, float(arm_clear or 0.0)))
        #: **TASK 14 · אי-סימטריה.** עד כאן כל דמות בפרויקט הייתה
        #: סימטרית לחלוטין: `_mirror` בונה כל עצם פעמיים, ו-
        #: `_set_shoulder` נקראה לשני הצדדים עם אותו מספר. דמות
        #: "א-סימטרית" הייתה בלתי אפשרית לבנות, ולא רק לא מכוילת.
        #:
        #: ברירת המחדל `None` אינה "אי-סימטריה אפס" אלא **דילוג על
        #: הקוד כולו**, וזה מכוון: `1.0 * x` אינו x בנקודה צפה בכל
        #: מקרה, אבל `(1-a)+a*k` כן שובר ספרות - ושלוש הדמויות
        #: הקיימות נשענות על השלד הזה בכל 28 שערי הסגנון שלהן.
        self.asym = dict(asym or {})
        k = self.height / H
        self.bones: list[Bone] = []
        self.by_name: dict[str, Bone] = {}
        for name, parent, pos, kind, springy in _spec(self.accessories):
            x, y, z = pos
            x *= k
            y *= k
            z *= k
            b = Bone(name, parent, (x, y, z), kind, springy,
                     index=len(self.bones))
            self.bones.append(b)
            self.by_name[name] = b
        # רוחב כתפיים וגודל ראש הם פרמטרי זהות - מותחים רק את מה שצריך
        if abs(shoulder_scale - 1.0) > 1e-6:
            self._set_shoulder("L", shoulder_scale)
            self._set_shoulder("R", shoulder_scale)
        if abs(head_scale - 1.0) > 1e-6:
            self._scale_about("head", head_scale)
        if self.asym:
            self._apply_asym(k)
        for b in self.bones:
            if b.parent is not None:
                self.by_name[b.parent].children.append(b.name)
        self._order = [b.name for b in self.bones]  # ההורה תמיד לפני הבן
        self.rest_world = self._compute_rest_world()
        self.inverse_bind = np.linalg.inv(self.rest_world)

    # -- התאמות זהות
    def _subtree(self, root: str):
        out, stack = [], [root]
        while stack:
            n = stack.pop()
            out.append(n)
            stack.extend(c.name for c in self.bones if c.parent == n)
        return out

    def _scale_x_subtree(self, root: str, k: float):
        px = self.by_name[root].rest[0]
        for n in self._subtree(root):
            b = self.by_name[n]
            x, y, z = b.rest
            b.rest = (px + (x - px) * k, y, z)

    def _set_shoulder(self, side: str, k: float):
        """רוחב כתפיים: מזיז את מפרק הכתף פנימה/חוצה, ו**מסיע את
        הזרוע כולה איתו** בלי לשנות את אורכה.

        נמדד 05/10 ב-TASK 09: `_scale_x_subtree("clavicle_L", 0.88)`
        קנה את רוחב הכתפיים במחיר של 12% מאורך הזרוע. עצם הבריח עצמה
        היא נקודת הקיבוע של אותה סקאלה ולכן לא זזה כלל, בעוד כל
        עצמות הזרוע נמשכו אליה - כלומר הפרמטר "רוחב כתפיים" היה
        בפועל "זרוע קצרה". מנהל הקסם תפס את זה כ-`arm_fraction` 0.268
        במקום 0.305.
        """
        cl, ua = f"clavicle_{side}", f"upperarm_{side}"
        if cl not in self.by_name or ua not in self.by_name:
            return
        cx = self.by_name[cl].rest[0]
        ux = self.by_name[ua].rest[0]
        dx = (ux - cx) * (k - 1.0)         # הזזה קשיחה של כל הזרוע
        for n in self._subtree(ua):
            b = self.by_name[n]
            x, y, z = b.rest
            b.rest = (x + dx, y, z)

    def _apply_asym(self, k: float) -> None:
        """אי-סימטריה: צד אחד אינו תמונת מראה של האחר.

        הסדר חשוב. רוחב הכתף הוא **הזזה קשיחה** של הזרוע (ראה
        `_set_shoulder`), ואורך הזרוע הוא **סקאלה סביב המפרק**. אם
        מריצים את הסקאלה קודם, ההזזה שאחריה נראית נכונה אבל
        הגובה שהוזז נמתח איתה - כלומר כתף מורמת שגם התארכה.
        לכן: רוחב, אחר כך גובה (הזזה), ורק בסוף אורך.
        """
        sw = self.asym.get("shoulder")
        if sw:
            for side, mul in zip(("L", "R"), sw):
                if abs(float(mul) - 1.0) > 1e-9:
                    self._set_shoulder(side, float(mul))
        dy = float(self.asym.get("shoulder_y", 0.0)) * k
        if abs(dy) > 1e-12:
            for side, sg in (("L", 1.0), ("R", -1.0)):
                cl = f"clavicle_{side}"
                if cl not in self.by_name:
                    continue
                for n in self._subtree(cl):
                    b = self.by_name[n]
                    x, y, z = b.rest
                    b.rest = (x, y + sg * dy, z)
        arm = self.asym.get("arm")
        if arm:
            for side, mul in zip(("L", "R"), arm):
                if abs(float(mul) - 1.0) > 1e-9:
                    self._scale_about(f"upperarm_{side}", float(mul))
        leg = self.asym.get("leg")
        if leg:
            for side, mul in zip(("L", "R"), leg):
                if abs(float(mul) - 1.0) > 1e-9:
                    self._scale_about(f"thigh_{side}", float(mul))

    def _scale_about(self, root: str, k: float):
        o = np.array(self.by_name[root].rest)
        for n in self._subtree(root):
            b = self.by_name[n]
            p = o + (np.array(b.rest) - o) * k
            b.rest = tuple(p)

    # -- מטריצות
    def _compute_rest_world(self) -> np.ndarray:
        """מטריצת עולם לכל עצם בפוזת המנוחה. בלי סיבובי מנוחה: צירי העצם
        הם צירי העולם, וזה מה שהופך את הבקרות לקריאות (jaw.rotation.x
        פותח את הפה, תמיד)."""
        m = np.zeros((len(self.bones), 4, 4))
        for i, b in enumerate(self.bones):
            mm = np.eye(4)
            mm[:3, 3] = b.rest
            m[i] = mm
        return m

    def local_rest(self, i: int) -> np.ndarray:
        b = self.bones[i]
        t = np.array(b.rest, dtype=np.float64)
        if b.parent is not None:
            t = t - np.array(self.by_name[b.parent].rest, dtype=np.float64)
        return t

    @property
    def names(self) -> list[str]:
        return [b.name for b in self.bones]

    def counts(self) -> dict:
        c = {"total": len(self.bones)}
        for b in self.bones:
            c[b.kind] = c.get(b.kind, 0) + 1
        return c

    # -- FK
    def forward(self, local_q: dict[str, np.ndarray] | None = None,
                local_t: dict[str, np.ndarray] | None = None) -> np.ndarray:
        """מחשב מטריצות עולם מסיבובים מקומיים. מחזיר (N,4,4)."""
        local_q = local_q or {}
        local_t = local_t or {}
        W = np.zeros((len(self.bones), 4, 4))
        for i, b in enumerate(self.bones):
            q = local_q.get(b.name)
            q = np.array([0.0, 0.0, 0.0, 1.0]) if q is None else np.asarray(q, float)
            t = self.local_rest(i) + np.asarray(
                local_t.get(b.name, (0.0, 0.0, 0.0)), dtype=np.float64)
            L = compose(t, q)
            if b.parent is None:
                W[i] = L
            else:
                W[i] = W[self.by_name[b.parent].index] @ L
        return W

    def skin_matrices(self, W: np.ndarray) -> np.ndarray:
        return W @ self.inverse_bind


# ---------------------------------------------------------------- IK


def two_bone_ik(root: np.ndarray, mid: np.ndarray, end: np.ndarray,
                target: np.ndarray, pole: np.ndarray):
    """IK אנליטי לשתי עצמות (חוק הקוסינוסים). מחזיר (mid_new, end_new).

    מלכודת שנמדדה: כשהמטרה רחוקה מסכום האורכים, acos מקבל ארגומנט >1
    ומחזיר nan - ואז הזרוע נעלמת מהפריים בלי שום שגיאה. לכן מהדקים
    את המרחק ל-99.9% מהמותח המלא ולא ל-100%.
    """
    root = np.asarray(root, float)
    mid = np.asarray(mid, float)
    end = np.asarray(end, float)
    target = np.asarray(target, float)
    l1 = np.linalg.norm(mid - root)
    l2 = np.linalg.norm(end - mid)
    d = target - root
    dist = float(np.linalg.norm(d))
    if dist < 1e-9:
        return mid.copy(), end.copy()
    reach = (l1 + l2) * 0.999
    dist = min(dist, reach)
    dist = max(dist, abs(l1 - l2) * 1.001 + 1e-6)
    u = d / np.linalg.norm(d)
    cos_a = (l1 * l1 + dist * dist - l2 * l2) / (2 * l1 * dist)
    cos_a = max(-1.0, min(1.0, cos_a))
    a = math.acos(cos_a)
    # ציר הכיפוף: אנכי גם ל-u וגם לווקטור הקוטב
    pole = np.asarray(pole, float)
    n = np.cross(u, pole - root)
    if np.linalg.norm(n) < 1e-7:
        n = np.cross(u, np.array([0.0, 0.0, 1.0]))
    if np.linalg.norm(n) < 1e-7:
        n = np.cross(u, np.array([0.0, 1.0, 0.0]))
    n /= np.linalg.norm(n)
    q = quat_from_axis_angle(n, a)
    mid_new = root + quat_to_mat(q) @ (u * l1)
    end_new = root + u * dist
    return mid_new, end_new


def chain_rotations(rest_a, rest_b, new_a, new_b):
    """הסיבוב שמביא את הווקטור rest_a->rest_b אל new_a->new_b."""
    v0 = np.asarray(rest_b, float) - np.asarray(rest_a, float)
    v1 = np.asarray(new_b, float) - np.asarray(new_a, float)
    n0, n1 = np.linalg.norm(v0), np.linalg.norm(v1)
    if n0 < 1e-9 or n1 < 1e-9:
        return np.array([0.0, 0.0, 0.0, 1.0])
    v0 /= n0
    v1 /= n1
    c = float(np.dot(v0, v1))
    if c > 1 - 1e-9:
        return np.array([0.0, 0.0, 0.0, 1.0])
    if c < -1 + 1e-9:
        ax = np.cross(v0, np.array([1.0, 0.0, 0.0]))
        if np.linalg.norm(ax) < 1e-7:
            ax = np.cross(v0, np.array([0.0, 1.0, 0.0]))
        return quat_from_axis_angle(ax, math.pi)
    ax = np.cross(v0, v1)
    return quat_from_axis_angle(ax, math.acos(max(-1.0, min(1.0, c))))


# ---------------------------------------------------------------- תנועה משנית


class Spring:
    """קפיץ מרוסן קריטית לכל ציר. משמש לתנועה משנית: החזה, השיער
    והזרועות ממשיכים לזוז אחרי שהגוף עצר.

    מלכודת: אינטגרציה מפורשת בצעד זמן גדול מתפוצצת. לכן תת-צעדים
    קבועים של 1/120 שנייה, בלי קשר לקצב הפריימים שהתבקש.
    """

    def __init__(self, stiffness: float = 110.0, damping_ratio: float = 0.85,
                 dim: int = 3):
        self.k = float(stiffness)
        self.zeta = float(damping_ratio)
        self.x = np.zeros(dim)
        self.v = np.zeros(dim)
        self.started = False

    def step(self, target, dt: float):
        target = np.asarray(target, dtype=np.float64)
        if not self.started:
            self.x = target.copy()
            self.started = True
            return self.x.copy()
        c = 2.0 * self.zeta * math.sqrt(self.k)
        n = max(1, int(math.ceil(dt * 120.0)))
        h = dt / n
        for _ in range(n):
            a = self.k * (target - self.x) - c * self.v
            self.v += a * h
            self.x += self.v * h
        return self.x.copy()
