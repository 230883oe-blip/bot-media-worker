# -*- coding: utf-8 -*-
"""TASK 08 - תנועה משנית פיזיקלית: שיער, בגד, שרוול, מכפלת, אביזר,
משקפיים, ידיים וראש.

**הדרישה המרכזית של המשימה**, וגם מה שמפריד בין "מתנדנד" לבין "חי":
   Secondary motion must respond to primary motion rather than
   move independently.

לכן כאן אין שום מתנד שמנגן לבד. כל אלמנט רך הוא מסה שתלויה על קפיץ,
והקפיץ **נמשך אל המקום שהתנועה הראשית קובעת**. מזה נגזרות שלוש
תוצאות שנמדדות בבדיקות:

* גוף שעומד -> המסה יושבת בדיוק על המטרה, כלומר **אפס** תנועה משנית.
  מתנד עצמאי (sin(t) כפול עוצמה) היה ממשיך לזוז שם, וזה בדיוק מה
  שהמשימה אוסרת.
* תנועה ראשית חדה -> המסה נשארת מאחור, והשיא שלה מגיע **אחרי** שיא
  הראשית. זה הפיגור, והוא נמדד בפריימים.
* הראשית נעצרת -> האנרגיה דועכת לאפס. אין "זכרון" שממשיך לנצח.

למה מיקום ולא זווית: הקפיץ עובד על **מקום הקצה במרחב** ולא על זווית
מקומית. סיבוב של אבא מזיז את מקום הקצה, ולכן הקפיץ מרגיש אותו גם
כשהזווית המקומית של העצם הרכה לא השתנתה בכלל. ניסיון קודם (קפיץ על
הזווית המקומית) לא הגיב לסיבוב הראשון וייצר תנועה רק בדור השני.

הפלט הוא סיבובים מקומיים לעצמות הרכות, ולכן זה נכנס לאותו `q` שהבמה
מקבלת ואין צורך לגעת ברנדור.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from .skeleton import (Skeleton, Spring, quat_from_axis_angle, quat_mul,
                       quat_to_mat)

# ---------------------------------------------------------------- טבלת האלמנטים


@dataclass(frozen=True)
class Part:
    """אלמנט רך אחד.

    bone     - העצם שמסתובבת (רכה, או קיימת במקרה `lag`)
    axis     - כיוון המסה בתוך מערכת הצירים של העצם, בפוזת מנוחה
    length   - מרחק המסה מהמפרק (מטרים, בגובה 1.70)
    k, zeta  - קשיחות וריסון הקפיץ
    max_deg  - תקרת זווית. בלי תקרה קפיץ בתנועה חדה מסתובב 90 מעלות
               והשיער נכנס לתוך הראש.
    amount   - כמה מהפיגור מיושם בפועל (0..1)
    group    - שם הקבוצה בדוח: hair / clothing / coat / accessory / body
    chain    - האלמנט שקודם לו בשרשרת. הפלט שלו הוא הקלט של זה,
               וכך נוצר follow-through אמיתי לאורך הקווצה.
    """
    bone: str
    axis: tuple
    length: float
    k: float = 48.0
    zeta: float = 0.55
    max_deg: float = 16.0
    amount: float = 1.0
    group: str = "hair"
    kind: str = "spring"      # spring = עצם רכה | lag = פיגור על עצם קיימת
    chain: str | None = None


#: השיער: פוני קדמי, שתי קווצות צד ומסת העורף. הקשיחות עולה עם
#: העובי - קווצת צד דקה מתנדנדת יותר מכל מסת העורף, וזה מה שנראה.
HAIR = (
    Part("hair_front", (0.0, 0.18, 0.98), 0.075, k=62.0, zeta=0.52,
         max_deg=11.0, amount=0.85, group="hair"),
    Part("hair_side_L", (0.22, -0.97, 0.0), 0.150, k=34.0, zeta=0.46,
         max_deg=19.0, amount=1.0, group="hair"),
    Part("hair_side_R", (-0.22, -0.97, 0.0), 0.150, k=34.0, zeta=0.46,
         max_deg=19.0, amount=1.0, group="hair"),
    Part("hair_back", (0.0, -0.72, -0.69), 0.130, k=44.0, zeta=0.58,
         max_deg=14.0, amount=0.9, group="hair"),
)

#: בגד: השרוול יושב על הזרוע ומכפלת החולצה על האגן. בד קל יותר
#: מהשיער ולכן הריסון נמוך, אבל התקרה קטנה - בד שמסתובב 20 מעלות
#: נראה כמו דגל ולא כמו שרוול.
CLOTH = (
    Part("sleeve_L", (1.0, -0.12, 0.0), 0.085, k=56.0, zeta=0.50,
         max_deg=12.0, amount=0.9, group="clothing"),
    Part("sleeve_R", (-1.0, -0.12, 0.0), 0.085, k=56.0, zeta=0.50,
         max_deg=12.0, amount=0.9, group="clothing"),
    Part("coat_L", (0.18, -0.98, 0.0), 0.140, k=40.0, zeta=0.54,
         max_deg=13.0, amount=0.95, group="coat"),
    Part("coat_R", (-0.18, -0.98, 0.0), 0.140, k=40.0, zeta=0.54,
         max_deg=13.0, amount=0.95, group="coat"),
)

#: אביזר: משקפיים. הם **קשיחים** ויושבים על האף, ולכן התקרה קטנה
#: מאוד - משקפיים שזזים 10 מעלות נופלים מהפנים. מה שכן צריך להיראות
#: זה הרעד הקטן בתנועת ראש חדה.
ACC = (
    Part("glasses", (0.0, -0.10, 1.0), 0.045, k=150.0, zeta=0.42,
         max_deg=3.5, amount=0.8, group="accessory"),
)

#: ידיים וראש: כאן אין עצם רכה חדשה - הפיגור מיושם על העצם הקיימת.
#: כף יד שמגיעה בדיוק עם האמה נראית כמו בובת עץ; האיחור הזה הוא מה
#: שהופך מחווה לתנועה של בשר.
#: ערכי החזה/הצוואר/הראש זהים ל-`controls.SecondaryMotion.LAG`
#: שהיה כאן לפני המשימה - הם נמדדו ברנדור ועבדו, ואין סיבה להזיז
#: אותם. מה שנוסף הוא כפות הידיים, שעד עכשיו הגיעו *בדיוק* עם
#: האמה.
BODY = (
    Part("hand_L", (1.0, 0.0, 0.0), 0.0, k=90.0, zeta=0.62,
         max_deg=0.0, amount=0.42, group="hands", kind="lag"),
    Part("hand_R", (-1.0, 0.0, 0.0), 0.0, k=90.0, zeta=0.62,
         max_deg=0.0, amount=0.42, group="hands", kind="lag"),
    Part("chest", (0.0, 1.0, 0.0), 0.0, k=70.0, zeta=0.80,
         max_deg=0.0, amount=0.55, group="torso", kind="lag"),
    Part("spine_02", (0.0, 1.0, 0.0), 0.0, k=85.0, zeta=0.85,
         max_deg=0.0, amount=0.35, group="torso", kind="lag"),
    Part("neck", (0.0, 1.0, 0.0), 0.0, k=95.0, zeta=0.78,
         max_deg=0.0, amount=0.45, group="head", kind="lag"),
    Part("head", (0.0, 1.0, 0.0), 0.0, k=120.0, zeta=0.75,
         max_deg=0.0, amount=0.35, group="head", kind="lag"),
)

PARTS: tuple = HAIR + CLOTH + ACC + BODY

#: שמות העצמות הרכות שהשלד צריך להכיל כדי שהמערכת תעבוד.
SOFT_BONES = tuple(p.bone for p in PARTS if p.kind == "spring")

GROUPS = ("hair", "clothing", "coat", "accessory", "hands", "head", "torso")


def parts_for(skel: Skeleton) -> tuple:
    """רק האלמנטים שיש להם עצם בשלד הזה. משקפיים למשל קיימים רק
    בדמות שנבנתה איתם, ואלמנט בלי עצם פשוט לא משתתף."""
    return tuple(p for p in PARTS if p.bone in skel.by_name)


# ---------------------------------------------------------------- הפותר


def _unit(v) -> np.ndarray:
    v = np.asarray(v, dtype=np.float64)
    n = float(np.linalg.norm(v))
    return v / n if n > 1e-12 else np.array([0.0, 1.0, 0.0])


def _rot_between(a, b) -> np.ndarray:
    """הקוורטניון שמסובב את a אל b (שניהם מנורמלים)."""
    a, b = _unit(a), _unit(b)
    c = float(np.clip(np.dot(a, b), -1.0, 1.0))
    if c > 1 - 1e-12:
        return np.array([0.0, 0.0, 0.0, 1.0])
    if c < -1 + 1e-9:
        ax = np.cross(a, np.array([1.0, 0.0, 0.0]))
        if np.linalg.norm(ax) < 1e-7:
            ax = np.cross(a, np.array([0.0, 1.0, 0.0]))
        return quat_from_axis_angle(ax, math.pi)
    return quat_from_axis_angle(np.cross(a, b), math.acos(c))


def _clamp_q(q: np.ndarray, max_rad: float) -> np.ndarray:
    """מגביל את זווית הסיבוב בלי לשנות את הציר."""
    if max_rad <= 0:
        return np.array([0.0, 0.0, 0.0, 1.0])
    w = float(np.clip(q[3], -1.0, 1.0))
    ang = 2.0 * math.acos(abs(w))
    if ang <= max_rad or ang < 1e-9:
        return q
    s = float(np.linalg.norm(q[:3]))
    axis = q[:3] / s if s > 1e-12 else np.array([0.0, 1.0, 0.0])
    if w < 0:
        axis = -axis
    return quat_from_axis_angle(axis, max_rad)


class SoftRig:
    """מערכת התנועה המשנית של דמות אחת.

    שימוש: `q = rig.solve(skel, q, dt)` אחרי שהפוזה הראשית חושבה.
    האובייקט שומר מצב בין פריימים (זה *כל* העניין בתנועה משנית),
    ולכן צריך אחד לכל דמות ולכל סצנה.
    """

    def __init__(self, skel: Skeleton, strength: float = 1.0,
                 parts: tuple | None = None):
        self.skel = skel
        self.strength = float(strength)
        self.parts = tuple(parts if parts is not None else parts_for(skel))
        self.k = skel.height / 1.70
        self.springs: dict[str, Spring] = {}
        self.lags: dict[str, Spring] = {}
        for p in self.parts:
            if p.kind == "spring":
                self.springs[p.bone] = Spring(p.k, p.zeta, 3)
            else:
                self.lags[p.bone] = Spring(p.k, p.zeta, 4)
        self.last: dict[str, float] = {}      # זווית בפועל, במעלות
        self.frames = 0

    # -- כלי עזר
    def _axis_world(self, W: np.ndarray, bone: str) -> np.ndarray:
        return W[self.skel.by_name[bone].index][:3, :3]

    def reset(self):
        for s in list(self.springs.values()) + list(self.lags.values()):
            s.started = False
            s.v[:] = 0.0
        self.last.clear()
        self.frames = 0

    # -- הפתרון
    def solve(self, q: dict, dt: float) -> dict:
        """מקבל את הפוזה הראשית ומחזיר אותה **עם** התנועה המשנית.

        הסדר חשוב: קודם FK על הפוזה הראשית (זה הקלט הפיזיקלי), ואז
        כל אלמנט נפתר לפי מקום המפרק שלו *בפוזה הזאת*. אלמנט בשרשרת
        מקבל FK מעודכן, ולכן הקצה של הקווצה מפגר אחרי האמצע שלה -
        וזה ה-overlap שהמשימה מבקשת.
        """
        q = dict(q)
        dt = max(1e-4, float(dt))
        W = self.skel.forward(q)
        for p in self.parts:
            if p.kind == "lag":
                self._solve_lag(q, p, dt)
            else:
                self._solve_spring(q, W, p, dt)
                # FK מחודש רק למי שיש לו ממשיך בשרשרת - חישוב מלא
                # לכל אלמנט היה מכפיל את זמן הרנדור בלי צורך.
                if any(o.chain == p.bone for o in self.parts):
                    W = self.skel.forward(q)
        self.frames += 1
        return q

    def _solve_spring(self, q: dict, W: np.ndarray, p: Part, dt: float):
        b = self.skel.by_name[p.bone]
        Wp = W[self.skel.by_name[b.parent].index] if b.parent else np.eye(4)
        o = np.asarray(b.rest, dtype=np.float64)
        # מקום המפרק בפוזה הנוכחית: FK של האב כפול מקום המנוחה המקומי
        loc = self.skel.local_rest(b.index)
        origin = Wp[:3, :3] @ loc + Wp[:3, 3]
        Rp = Wp[:3, :3]
        ax = _unit(p.axis)
        L = p.length * self.k
        tip = origin + Rp @ (ax * L)
        x = self.springs[p.bone].step(tip, dt)
        u = x - origin
        if float(np.linalg.norm(u)) < 1e-9:
            self.last[p.bone] = 0.0
            return
        d_local = Rp.T @ _unit(u)
        qr = _rot_between(ax, d_local)
        qr = _clamp_q(qr, math.radians(p.max_deg))
        amt = float(np.clip(p.amount * self.strength, 0.0, 1.0))
        if amt < 1.0:
            qr = _clamp_q(qr, 2.0 * math.acos(
                float(np.clip(abs(qr[3]), -1.0, 1.0))) * amt)
        self.last[p.bone] = math.degrees(
            2.0 * math.acos(float(np.clip(abs(qr[3]), -1.0, 1.0))))
        base = q.get(p.bone)
        q[p.bone] = qr if base is None else quat_mul(np.asarray(base), qr)
        del o

    def _solve_lag(self, q: dict, p: Part, dt: float):
        """פיגור על עצם קיימת: מערבב את הזווית עם גרסה מאוחרת שלה.

        על אוילר ולא על slerp של קוורטניון - slerp של קפיץ התהפך סימן
        באמצע תנועה וייצר קפיצה של 180 מעלות (נמדד, 05/10).
        """
        cur = np.asarray(q.get(p.bone, np.array([0.0, 0.0, 0.0, 1.0])),
                         dtype=np.float64)
        lag = self.lags[p.bone].step(cur, dt)
        n = float(np.linalg.norm(lag))
        if n < 1e-9:
            return
        lag = lag / n
        if float(np.dot(lag, cur)) < 0:
            lag = -lag
        a = float(np.clip(p.amount * self.strength, 0.0, 1.0))
        mixed = cur * (1 - a) + lag * a
        mn = float(np.linalg.norm(mixed))
        if mn > 1e-9:
            q[p.bone] = mixed / mn
            self.last[p.bone] = math.degrees(
                2.0 * math.acos(float(np.clip(abs(float(np.dot(
                    mixed / mn, cur))), -1.0, 1.0))))

    # -- מדידה
    def energy(self) -> float:
        """סך המהירויות של כל הקפיצים. 0 = הכול נח."""
        tot = 0.0
        for s in self.springs.values():
            tot += float(np.linalg.norm(s.v))
        for s in self.lags.values():
            tot += float(np.linalg.norm(s.v))
        return tot

    def report(self) -> dict:
        per: dict[str, list] = {}
        for p in self.parts:
            per.setdefault(p.group, []).append(p.bone)
        return {"parts": len(self.parts), "groups": per,
                "angles_deg": {k: round(v, 3) for k, v in self.last.items()},
                "energy": round(self.energy(), 6), "frames": self.frames}


# ---------------------------------------------------------------- קשירת משקולות


#: כמה מהמשקולת של קודקוד עובר לעצם הרכה. 0.55 נבחר אחרי מדידה:
#: מתחת ל-0.3 התנועה לא נראית בכלל ברנדור, ומעל 0.7 השיער מתנתק
#: מהגולגולת כשהראש מסתובב חזק.
HAIR_SHARE = 0.55
CLOTH_SHARE = 0.38
ACC_SHARE = 0.95


def _soft_targets(skel: Skeleton) -> list[tuple[str, np.ndarray, float]]:
    """(שם עצם רכה, מקום מנוחה, רדיוס השפעה) לכל עצמות השיער."""
    k = skel.height / 1.70
    out = []
    for p in HAIR:
        if p.bone not in skel.by_name:
            continue
        out.append((p.bone,
                    np.asarray(skel.by_name[p.bone].rest, dtype=np.float64),
                    (0.055 + p.length * 0.9) * k))
    return out


def bind(mb, skel: Skeleton, hair_follow: float = 1.0) -> dict:
    """מעביר חלק מהמשקולת של הקודקודים הרכים אל העצמות הרכות.

    זה הצעד שבלעדיו כל המערכת בלתי נראית: אם השיער משוקלל רק ל-head,
    סיבוב של עצם השיער לא מזיז אף קודקוד. ההעברה **הדרגתית** -
    אפס בשורש ומקסימום בקצה - ולכן השיער מתעקם ולא מתנתק.

    מחזיר דוח ספירה, שהוא גם מה שהבדיקות מודדות.
    """
    targets = _soft_targets(skel)
    kk = skel.height / 1.70
    cnt = {"hair": 0, "clothing": 0, "coat": 0, "accessory": 0}
    hips_y = float(skel.by_name["hips"].rest[1])

    def give(i: int, bone: str, share: float):
        share = float(np.clip(share, 0.0, 0.95))
        if share < 0.02 or bone not in skel.by_name:
            return False
        w = {kx: v * (1.0 - share) for kx, v in mb.w[i].items()}
        w[bone] = w.get(bone, 0.0) + share
        s = sum(w.values())
        mb.w[i] = {kx: v / s for kx, v in w.items() if v > 1e-6}
        return True

    for i, tag in enumerate(mb.tag):
        p = np.asarray(mb.v[i], dtype=np.float64)
        if tag == "glasses":
            if give(i, "glasses", ACC_SHARE):
                cnt["accessory"] += 1
            continue
        if tag == "hair" and targets:
            # הקרוב ביותר, ומשקל שדועך עם המרחק ממנו
            bone, pos, rad = min(
                targets, key=lambda t: float(np.linalg.norm(p - t[1])))
            d = float(np.linalg.norm(p - pos))
            # TASK 11: מכפיל שפת הצורות. 1.0 הוא ההתנהגות שהייתה.
            share = HAIR_SHARE * hair_follow * \
                math.exp(-(d / max(1e-6, rad)) ** 2)
            if give(i, bone, share):
                cnt["hair"] += 1
            continue
        w = mb.w[i]
        # --- שרוול: הבד שיושב על החלק התחתון של הזרוע
        for side in ("L", "R"):
            arm = w.get(f"upperarm_{side}", 0.0) + w.get(f"forearm_{side}", 0.0)
            if arm < 0.5 or f"sleeve_{side}" not in skel.by_name:
                continue
            elb = np.asarray(skel.by_name[f"forearm_{side}"].rest,
                             dtype=np.float64)
            sh = np.asarray(skel.by_name[f"upperarm_{side}"].rest,
                            dtype=np.float64)
            t = abs(p[0] - sh[0]) / max(1e-6, abs(elb[0] - sh[0]))
            if 0.55 <= t <= 1.15:
                sm = math.sin(min(1.0, (t - 0.55) / 0.45) * math.pi * 0.5)
                if give(i, f"sleeve_{side}", CLOTH_SHARE * sm):
                    cnt["clothing"] += 1
            break
        # --- מכפלת: החולצה סביב האגן, מתחת למותן
        if w.get("hips", 0.0) > 0.45 and abs(p[1] - hips_y) < 0.085 * kk:
            side = "L" if p[0] >= 0 else "R"
            if f"coat_{side}" in skel.by_name:
                u = 1.0 - abs(p[1] - (hips_y - 0.05 * kk)) / (0.09 * kk)
                if give(i, f"coat_{side}", CLOTH_SHARE * max(0.0, u)):
                    cnt["coat"] += 1
    return {"bound": cnt, "soft_bones": [b for b, _, _ in targets]}


# ---------------------------------------------------------------- דוח


def audit(height: float = 1.70, dt: float = 1 / 30) -> dict:
    """מודד את ההתנהגות הפיזיקלית בלי גאומטריה ובלי רנדור.

    שלוש המדידות הן בדיוק שלוש הדרישות של TASK 08.
    """
    skel = Skeleton(height=height, accessories=("glasses",))
    rig = SoftRig(skel)
    import numpy as _np
    from . import controls as _c

    # 1. גוף קפוא -> אפס תנועה משנית
    still = _c.evaluate(skel, {})
    for _ in range(40):
        rig.solve(still, dt)
    still_max = max([abs(v) for v in rig.last.values()] or [0.0])
    still_energy = rig.energy()

    # 2. תנועה ראשית חלקה -> פיגור בפאזה.
    #
    # גל ולא מדרגה: במדרגה כל האלמנטים נחתכים בתקרת הזווית ואז
    # הפיגור בלתי מדיד (כולם מגיעים לשיא באותו פריים). גל סינוס
    # של 0.55Hz הוא קצב תנועת ראש אנושית, ובו הפיגור הוא **הפרש
    # הפאזה** - וזה מספר אמיתי.
    rig.reset()
    prim: list[float] = []
    per: dict[str, list] = {p.bone: [] for p in rig.parts}
    for i in range(150):
        t = i * dt
        s_ = math.sin(2 * math.pi * 0.55 * t)
        yaw = 0.42 * s_
        # הנעה שנוגעת בכל האלמנטים: ראש, עמוד שדרה, אגן (מכפלת),
        # זרוע (שרוול) וכף יד. אלמנט שלא הונע בכלל היה מחזיר אפס
        # ואז "אפס תנועה משנית" היה מספר חסר משמעות.
        qq = _c.evaluate(skel, {
            "head_yaw": yaw, "spine_twist": yaw * 0.55,
            "neck_yaw": yaw * 0.45, "neck_pitch": 0.10 * s_,
            "hips_yaw": yaw * 0.35, "hips_pitch": 0.05 * s_,
            "arm_fwd_L": 0.30 * (1 + s_) / 2,
            "arm_fwd_R": 0.30 * (1 - s_) / 2,
            "wrist_pitch_L": 0.40 * s_, "wrist_pitch_R": -0.40 * s_,
        })
        rig.solve(qq, dt)
        prim.append(yaw)
        for b, v in rig.last.items():
            per.setdefault(b, []).append(abs(v))
    # המדד הנכון הוא מול **מהירות** הראשית ולא מול הזווית שלה:
    # תגובה אינרציאלית נולדת מתאוצה, ולכן משרעת הפיגור עולה כשהגוף
    # *נע מהר*, לא כשהוא *רחוק*. מול הזווית היה יוצא פיגור של רבע
    # מחזור (13 פריימים) שהוא פאזה ולא איחור.
    spd = _np.abs(_np.diff(_np.asarray(prim)))[29:]
    pa = spd - spd.mean()
    lags: dict[str, int] = {}
    peaks: dict[str, float] = {}
    corr: dict[str, float] = {}
    for b, vals in per.items():
        va = _np.asarray(vals[30:], dtype=float)
        peaks[b] = round(float(va.max()), 3)
        va = va - va.mean()
        n = min(len(va), len(pa))
        if float(_np.std(va)) < 1e-9 or n < 40:
            lags[b], corr[b] = 0, 0.0
            continue
        # מתאם צולב: בכמה פריימים המשנית מאחרת אחרי מהירות הראשית.
        cc = []
        for s in range(0, 16):
            x, y = pa[:n - s], va[s:n]
            den = float(_np.linalg.norm(x) * _np.linalg.norm(y)) or 1.0
            cc.append(float(_np.dot(x, y)) / den)
        lags[b] = int(_np.argmax(cc))
        corr[b] = round(float(max(cc)), 3)

    # 3. עצירה -> דעיכה
    for _ in range(120):
        rig.solve(_c.evaluate(skel, {}), dt)
    rest_max = max([abs(v) for v in rig.last.values()] or [0.0])
    limits = {p.bone: p.max_deg for p in rig.parts if p.kind == "spring"}
    over = {b: peaks[b] for b, m in limits.items()
            if peaks.get(b, 0.0) > m + 1e-6}
    return {
        "parts": rig.report()["parts"],
        "groups": sorted(rig.report()["groups"]),
        "still_max_deg": round(still_max, 6),
        "still_energy": round(still_energy, 6),
        "peak_deg": {k: v for k, v in sorted(peaks.items())},
        "lag_frames": {k: v for k, v in sorted(lags.items())},
        "corr_to_primary": {k: v for k, v in sorted(corr.items())},
        "over_limit": over,
        "settled_energy": round(rig.energy(), 6),
        "settled_max_deg": round(rest_max, 6),
    }


def main(argv=None) -> int:
    import sys
    sys.stdout.reconfigure(encoding="utf-8")
    a = audit()
    print("=== תנועה משנית (TASK 08) ===")
    print(f"  אלמנטים: {a['parts']} בקבוצות {', '.join(a['groups'])}")
    print(f"  גוף קפוא: תנועה {a['still_max_deg']}°, "
          f"אנרגיה {a['still_energy']}")
    print(f"  תנועה חדה: שיא {a['peak_deg']}°, "
          f"פיגור {a['lag_frames']} פריימים")
    print(f"  אחרי עצירה: אנרגיה {a['settled_energy']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
