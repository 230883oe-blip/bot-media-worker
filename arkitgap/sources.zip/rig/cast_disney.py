# -*- coding: utf-8 -*-
"""TASK 18 (06/10) - ההרכב של "הפארק הדינמי": ארבע דמויות דיסני.

ההוראה שהתקבלה דרשה **ארבע** דמויות מובחנות לחלוטין בגבהים
1.85 / 1.65 / 1.20 / 1.70, בשפת צורות אורגנית, ובאיסור מוחלט על
גיאומטריה קופסתית, עיניים בולטות וצוואר-צינור.

================================================================
שלוש הכרעות, וכל אחת מהן נגד אלטרנטיבה שנשקלה ונפסלה
================================================================

**1. ההרכב הוא ארבע רשומות *חדשות* ב-`pipeline.CAST`, ולא עדכון
של `boaz`/`tamar` הקיימות.** שתי הדמויות ההן נבנו ב-TASK 15 בדיוק
בגבהים 1.85 ו-1.65, והיה מפתה לשנות אותן במקום. זה נפסל: 1260
הבדיקות הקיימות מודדות אותן בספרה, ו-28 שערי שפת הצורות נשענים
על המספרים שלהן. שינוי של ספרה אחת ב-`boaz` שובר שער שאינו קשור
למשימה הזו בכלל. לכן `dn_ariel` ו-`dn_shir` **יורשות** את פרופיל
הגוף של boaz/tamar (`dimorph: male/female`) ודורסות מעליו רק את
שפת דיסני - עיניים גדולות, כתף מעוגלת, ארובה שקועה.

**2. העיגול נעשה ב*קופסתיות החתך* ולא בהקטנת מידות.** הדרישה
"כתפיים רחבות אך עגולות" היא סתירה אם עובדים במידות: כתף רחבה עם
`shoulder_square` של 1.15 (לוקאס) היא קופסה רחבה. אפס שם משאיר את
הרוחב (`shoulder_w`) ומחליף את **הצורה**.

והניסיון הראשון כאן טעה בכיוון, ונמדד: הנחתי ש-1.0 הוא "אליפסה
מדויקת" וכתבתי 0.97 בכוונה לעגל. המדידה הראתה ש-`shoulder_square`
הוא **תוספת קופסתיות מעל אליפסה**: קלט 0.0 מודד 1.000 במדד
`_squareness` (מאיה, כופתה, בועז, תמר), קלט 1.15 מודד 1.131, וקלט
3.2 מודד 1.286. כלומר 0.97 הוסיף 11% קופסתיות לארבע הדמויות
במקום להוריד - וארבע הצלליות נפסלו בשער עד שהקלט שונה ל-0.0. שדה
שמשמעותו הופכת למה שסביר להניח הוא בדיוק המקום שבו צריך למדוד
ולא להניח.

**3. ראש הילד גדל ב-`head_width`, לא ב-`height`.** פרופורציות
ילד/Chibi הן יחס ראש:גוף, ו-`head_to_body` ב-`CAST` הוא שדה
**נמדד** ולא שדה קלט (pipeline:134) - כתיבה שלו לא עושה דבר.
הקלט האמיתי הוא `head_width · head_appeal`, שנכנס ל-
`Skeleton(head_scale=...)`. מי שכותב `head_to_body: 0.88` ומצפה
לראש גדול מקבל ראש רגיל ושער שעובר - כלומר שקר שקט.

================================================================
מה נמדד כאן
================================================================

`audit()` בודק את מה שאפשר להפריך:

* **מובחנות זוגית** - כל אחד מששת הזוגות חייב 8 מתוך 14 מדדים
  חסרי יחידה רחוקים ב-20% ומעלה (אותה מכונה של `cast14`, ובכוונה:
  שתי ספירות מובחנות שונות היו שתי הגדרות ל"דמות אחרת").
* **סולם הגבהים** - ארבעה גבהים נבדלים, ויחס של 1.54 בין הגבוה
  לנמוך. זה השער שמונע "ארבע דמויות באותו גוף".
* **אפס קופסתיות** - `_squareness` של הכתף חייב להיות 1.000
  (אליפסה מדויקת), ו-`skull_box` אפס, בכל ארבע.
* **ההרכב הקיים לא זז** - כל שמונה הדמויות הקודמות נבנות באותו
  פרופיל גוף ובאותה שפת פנים. זה השער שמגן על 1260 הבדיקות.
"""
from __future__ import annotations

import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
if str(HERE.parent) not in sys.path:
    sys.path.insert(0, str(HERE.parent))

from rig import cast14 as C14                            # noqa: E402
from rig import pipeline as PL                           # noqa: E402

#: ארבעת המזהים. התחילית `dn_` ("disney") קיימת כדי שחיפוש גלובלי
#: יראה מיד איזו דמות שייכת למשימה הזו ואיזו קודמת לה.
CAST4 = ("dn_ariel", "dn_shir", "dn_noam", "dn_gidon")

#: TASK 22 · ההרכב המלא, שמונה דמויות. **`CAST4` נשאר כפי שהוא**
#: ולא הפך לכינוי של `CAST8`: עשרות בדיקות קיימות קוראות ממנו
#: ומצהירות "ארבע", ושינוי שלו היה הופך אותן לבדיקות שמודדות
#: שמונה בשם של ארבע - כלומר שקר שקט ולא כיסוי רחב יותר.
CAST8 = CAST4 + ("dn_tamir", "dn_libi", "dn_omer", "dn_dafna")

#: שמות התפקיד בעברית, לכתוביות ולדוחות.
ROLE = {
    "dn_ariel": "אריאל · הנער האתלטי",
    "dn_shir": "שיר · הנערה האנרגטית",
    "dn_noam": "נעם · הילד הסקרן",
    "dn_gidon": "גדעון · הסבא החביב",
    "dn_tamir": "תמיר · החבר הגבוה",
    "dn_libi": "ליבי · החברה עם השיער הארוך",
    "dn_omer": "עומר · הנער בסווטשירט",
    "dn_dafna": "דפנה · הילדה עם הקוקיות",
}

#: הקולות. `avri` גברי, `hila` נשי - שני המודלים שקיימים בפרויקט.
VOICES = {"dn_ariel": "avri", "dn_shir": "hila",
          "dn_noam": "hila", "dn_gidon": "avri",
          "dn_tamir": "avri", "dn_libi": "hila",
          "dn_omer": "avri", "dn_dafna": "hila"}


# ============================================================ ההגדרות

#: דמות 1 · הנער האתלטי, 1.85 מ'.
#: כתפיים רחבות (`shoulder_w` של `male`) אך **עגולות**
#: (`shoulder_square` 0.0 במקום 1.15), גו V רך, גפיים ארוכות ודקות.
_ARIEL = {
    "height": 1.85,
    "ref_png": "lucas_ref.png",
    "accessories": [],
    "shape_override": {
        "girth": 0.94,
        "shoulder_scale": 1.12,
        "head_appeal": 1.30,
        "dimorph": {
            "preset": "male",
            # העיגול: אקספוננט, לא מידה. ראה הכרעה 2 למעלה.
            # **0.0 ולא 0.97.** נמדד כאן ש-`_squareness` מחזיר 1.000
            # בדיוק כשהקלט 0, ו-1.131 כשהקלט 1.15 (לוקאס): כלומר
            # הקלט הוא *תוספת* קופסתיות מעל אליפסה, ולא אקספוננט.
            # 0.97 היה מוסיף 11% קופסתיות ולא מוריד אותה.
            "shoulder_square": 0.0,
            "chest_square": 0.0,
            # חידוד ה-V נשאר, אבל בלסת רכה - "חיוך רחב ונגיש"
            # אינו מתיישב עם לסת של 1.85.
            # **TASK 22 · פיסול בובת אופנה (Ken).** גולגולת
            # פרבולואידית, עצם לחי מוגדרת, לסת מצטרת ורכה,
            # עפעף שקדי וקשת קופידון. ראה `rig/doll.py`.
            "doll_cranium": 0.90,
            "doll_cheek": 1.05,
            "doll_jaw": 0.95,
            "doll_lid": 1.00,
            "doll_lip": 0.85,
            "jaw_sharp": 1.05,
            "chin_sharp": 0.88,
            # גפיים ארוכות ודקות: בסיס זרוע צר והתכנסות מהירה.
            "arm_base": 0.056,
            "biceps": 0.17,
            "arm_taper": 1.10,
            "leg_taper": 1.06,
            # עקומת ה-S לכתפיים: טרפז מורם וצוואר שמתרחב למטה.
            "trap_rise": 0.26,
            "neck_flare": 0.30,
            # **אגן צר (TASK 19).** נער מתבגר הוא צללית V: כתפיים
            # 0.190 מול אגן 0.088, יחס 2.16. הערך הקודם (0.102, מתוך
            # הפריסט) נתן 1.86 - וב-`cast14` נמדד שזה **אותו** יחס
            # שיוצא לילד בן השש, כלומר הפער בין נער לילד נשען שם על
            # תנודת הצללית ולא על המידות. ברגע שהצללית הוחלקה הפער
            # הזה נעלם, ושער המובחנות ירד ל-7/14. אגן צר מחזיר אותו
            # ל-9/14 בזוג הזה - מהמידה, ולכן הוא יציב להחלקות הבאות.
            "hip_w": 0.088,
            # TASK 19: המעבר אל הצוואר כעקומה אחת + משפך בבסיסו.
            "sho_curve": 1.0,
            "neck_funnel": 0.22,
            # **TASK 20 · המיזוג האורגני אל הירכיים.** האגן מתרחב
            # כלפי מטה אל הטרוכנטר, תחתיתו כיפה ולא דיסקה, והירך
            # מקבלת שוקת שעולה מעל המפרק. נמדד 06/10 שבלעדיו השבר
            # בקו הצללית אגן->ירך הוא 65°-119° בארבע הדמויות.
            "hip_blend": 1.0,
        },
        "face": {
            "preset": "male",
            # עיניים ענקיות הבעתיות, בארובה **שקועה**.
            "eye": 1.52,
            "socket": 1.34,
            "socket_r": 1.22,
            "socket_merge": 0.62,
            "lid_cover": 1.18,
            # **הערך שמונע "עין בוהה".** `eye_out` חיובי דוחף את
            # הגלגל קדימה; שלילי שוקע אותו בארובה. נמדד ש-eye=1.52
            # בלי ההיסט הזה מוציא את הקרנית 20.5 מ"מ, כלומר 0.992
            # מרדיוס הגלגל - עין שמונחת על העור ולא בתוכו.
            "eye_out": -0.0099,
            # גבות דינמיות: נתיב רחב וזווית.
            "brow_lane": 1.14,
            "brow_slant": 0.16,
            "brow_thick": 1.06,
            # חיוך רחב ונגיש.
            "mouth_w": 1.22,
            "smile": 1.34,
            "mouth_arc": 1.18,
            # ראש אליפטי רך: אפס קופסתיות, אפס קודקוד שטוח.
            "skull_square": 0.0,
            "skull_box": 0.0,
            "crown_flat": 0.0,
            "cheek": 1.08,
            "hair": "flattop",
            "hair_len_mul": 0.74,
            "cloth": "soft",
            "limb_square": 0.0,
        },
        "shirt_desat": 0.34,
        "palette": {
            "shirt": [0.17, 0.33, 0.56],
            "pants": [0.16, 0.18, 0.24],
            "hair": [0.21, 0.14, 0.1],
            "shoe": [0.1, 0.1, 0.13],
        },
    },
}

#: דמות 2 · הנערה האנרגטית, 1.65 מ'.
#: מותן מוגדרת, צוואר עדין וזורם, עיניים גדולות ב-50% עם הברקה,
#: שיער בנפחים פיסוליים (`hair_clump`).
_SHIR = {
    "height": 1.65,
    "ref_png": "maya_ref.png",
    "accessories": [],
    "shape_override": {
        "girth": 0.86,
        "shoulder_scale": 0.84,
        "head_appeal": 1.22,
        "head_width": 1.04,
        "dimorph": {
            "preset": "female",
            "shoulder_square": 0.0,
            "chest_square": 0.0,
            # מותן מוגדרת: היא מוגדרת ב**יחס** ולא ברוחב מוחלט,
            # אחרת דמות נמוכה מקבלת מותן של בובה.
            "waist_w": 0.079,
            "waist_d": 0.068,
            "waist_t": 0.34,
            # צוואר עדין וזורם אל הכתף.
            "neck_w": 0.052,
            "neck_d": 0.050,
            "trap_rise": 0.34,
            "neck_flare": 0.44,
            # TASK 19: המעבר אל הצוואר כעקומה אחת + משפך בבסיסו.
            "sho_curve": 1.0,
            "neck_funnel": 0.38,
            # **TASK 20 · המיזוג האורגני אל הירכיים.** האגן מתרחב
            # כלפי מטה אל הטרוכנטר, תחתיתו כיפה ולא דיסקה, והירך
            # מקבלת שוקת שעולה מעל המפרק. נמדד 06/10 שבלעדיו השבר
            # בקו הצללית אגן->ירך הוא 65°-119° בארבע הדמויות.
            "hip_blend": 1.0,
            # **TASK 20 · קונטור החזה הדו-אוני.** `bust` לבדו מזיז
            # את מרכז הטבעת, ולכן נמדד Z מרבי בדיוק ב-x=0 - בליטה
            # מרכזית אחת. שתי אונות דורשות פונקציה של X ושל הזווית.
            "bust_lobe": 0.019,
            # **TASK 22 · פיסול בובת אופנה (Barbie).** העוצמה
            # הגבוהה בהרכב: היא הדמות שההוראה מתארת במפורש
            # ("fashion-doll proportions"). ראה `rig/doll.py`.
            "doll_cranium": 1.00,
            "doll_cheek": 1.15,
            "doll_jaw": 1.00,
            "doll_lid": 1.10,
            "doll_lip": 1.15,
            "jaw_sharp": 0.52,
            "chin_sharp": 0.62,
            "arm_base": 0.049,
            "arm_taper": 1.08,
        },
        "face": {
            "preset": "female",
            # "גדולות ב-50%": זה היחס מול `plain` (eye=1.0), והוא
            # נמדד ב-`facestyle.measure` ולא מוצהר.
            "eye": 1.58,
            "socket": 1.30,
            "socket_r": 1.26,
            "socket_merge": 0.68,
            "lid_cover": 1.22,
            "eye_out": -0.0013,
            # אף קומפקטי עדין.
            "nose_len": 0.78,
            "nose_w": 0.80,
            "nose_tip": 0.86,
            "nose_up": 0.14,
            "brow_lane": 1.08,
            "brow_slant": 0.22,
            "mouth_w": 1.10,
            "smile": 1.30,
            # שיער זורם בנפחים פיסוליים.
            "hair": "fringe",
            "hair_len_mul": 1.46,
            "hair_clump": 0.38,
            "hair_thick": 1.22,
            "hair_follow": 1.26,
            "skull_square": 0.0,
            "skull_box": 0.0,
            "crown_flat": 0.0,
            "cheek": 1.14,
            "cloth": "soft",
            "limb_square": 0.0,
        },
        "shirt_desat": 0.58,
        "hair_desat": 0.46,
        "palette": {
            "shirt": [0.78, 0.33, 0.42],
            "pants": [0.28, 0.24, 0.34],
            "hair": [0.42, 0.26, 0.14],
            "shoe": [0.3, 0.16, 0.18],
        },
    },
}

#: דמות 3 · הילד הקטן והסקרן, 1.20 מ'.
#: פרופורציות Chibi: הראש גדול **ביחס לגוף**, ולכן `head_width`
#: הוא מה שגדל (ראה הכרעה 3). בטן עגולה, גפיים קצרות.
_NOAM = {
    "height": 1.20,
    "ref_png": "maya_ref.png",
    "accessories": [],
    "shape_override": {
        "girth": 1.18,
        "shoulder_scale": 0.82,
        "head_appeal": 1.30,
        # 1.26 ולא 0.88 ב-head_to_body: זה הקלט, וזה מה שבאמת
        # מגדיל את הראש. ראה ההכרעה השלישית למעלה.
        "head_width": 1.26,
        "dimorph": {
            "preset": "round",
            "shoulder_square": 0.0,
            "chest_square": 0.0,
            # בטן מעט עגולה: החזה והמותן מתקרבים ברוחב, והמותן
            # יוצאת קדימה בעומק.
            "waist_w": 0.090,
            "waist_d": 0.086,
            "waist_t": 0.44,
            "chest_w": 0.098,
            "chest_d": 0.090,
            "hip_w": 0.082,
            # גפיים קצרות ועבות-קצה: בסיס רחב והתכנסות איטית.
            "arm_base": 0.052,
            "biceps": 0.34,
            "arm_taper": 0.92,
            "leg_taper": 0.90,
            "neck_w": 0.044,
            "neck_d": 0.043,
            "trap_rise": 0.40,
            "neck_flare": 0.52,
            # TASK 19: המעבר אל הצוואר כעקומה אחת + משפך בבסיסו.
            "sho_curve": 1.0,
            "neck_funnel": 0.72,
            # **TASK 20 · המיזוג האורגני אל הירכיים.** האגן מתרחב
            # כלפי מטה אל הטרוכנטר, תחתיתו כיפה ולא דיסקה, והירך
            # מקבלת שוקת שעולה מעל המפרק. נמדד 06/10 שבלעדיו השבר
            # בקו הצללית אגן->ירך הוא 65°-119° בארבע הדמויות.
            "hip_blend": 1.0,
            # **TASK 22 · פיסול בובת אופנה, בעוצמה מופחתת.** ילד
            # עם לסת מצטרת בעוצמה מלאה נקרא כמבוגר קטן, ולכן
            # הלסת והלחי כאן חלשות והגולגולת מלאה.
            "doll_cranium": 0.55,
            # 0.95 ולא 0.45: בעוצמה שהוקטנה (0.0035 במקום 0.0115)
            # 0.45 נמדד כ-0.9 מ"מ בלבד, כלומר לחי שטוחה.
            "doll_cheek": 0.88,
            "doll_jaw": 0.40,
            "doll_lid": 0.95,
            "doll_lip": 0.90,
            "jaw_sharp": 0.34,
            "chin_sharp": 0.40,
        },
        "face": {
            "preset": "joy",
            "eye": 1.72,
            "socket": 1.26,
            "socket_r": 1.34,
            "socket_merge": 0.74,
            "lid_cover": 1.14,
            # לחיים נפוחות ורכות - זה מה שקורא "ילד" יותר מכל מדד.
            "cheek": 1.52,
            "cheek_hollow": 0.42,
            "nose_len": 0.62,
            "nose_w": 0.92,
            "nose_up": 0.30,
            "nose_tip": 1.14,
            "brow_lane": 0.94,
            "brow_thick": 0.82,
            "mouth_w": 0.78,
            "smile": 1.40,
            "lip_thick": 1.18,
            # ראש עגול וגדול: אפס שיטוח בכל שלושת הערוצים.
            "skull": (1.02, 1.02, 1.0),
            "skull_square": 0.0,
            "skull_box": 0.0,
            "crown_flat": 0.0,
            "taper_top": 0.0,
            "narrow_amt": 0.12,
            "hair": "curls",
            "hair_len_mul": 0.56,
            "hair_clump": 0.52,
            "cloth": "soft",
            "limb_square": 0.0,
        },
        "palette": {
            "shirt": [0.94, 0.72, 0.24],
            "pants": [0.22, 0.34, 0.3],
            "hair": [0.3, 0.19, 0.11],
            "shoe": [0.18, 0.16, 0.14],
        },
    },
}

#: דמות 4 · הסבא החביב, 1.70 מ'.
#: מבנה פנים **אגסי** (רחב למטה), משקפיים עגולות, גבות עבות ורכות,
#: גב מעט כפוף. הכפיפה עצמה היא פוזה ולא מידה, והיא יושבת ב-
#: `disney_story.STOOP` - כאן רק המורפולוגיה.
_GIDON = {
    "height": 1.70,
    "ref_png": "lucas_ref.png",
    "accessories": ["glasses"],
    "shape_override": {
        "girth": 1.12,
        "shoulder_scale": 0.94,
        "head_appeal": 1.18,
        "dimorph": {
            "preset": "neutral",
            "shoulder_square": 0.0,
            "chest_square": 0.0,
            # גוף מבוגר: החזה צר מהמותן, וזו ההיפוך של צללית ה-V.
            "chest_w": 0.122,
            "chest_d": 0.100,
            "waist_w": 0.118,
            "waist_d": 0.108,
            "waist_t": 0.26,
            # אגן רחב מהחזה: זו ההיפוך של צללית ה-V, וזה מה
            # שמוריד את `shoulder_hip` ואת `upper_volume_share`
            # אל מתחת לאלה של הילד.
            "hip_w": 0.126,
            "hip_d": 0.104,
            "seat_lo": 1.04,
            "seat_mid": 1.02,
            "arm_base": 0.058,
            "biceps": 0.14,
            "arm_taper": 0.96,
            "leg_taper": 0.94,
            "neck_w": 0.062,
            "neck_d": 0.060,
            "trap_rise": 0.18,
            "neck_flare": 0.36,
            # TASK 19: המעבר אל הצוואר כעקומה אחת + משפך בבסיסו.
            "sho_curve": 1.0,
            "neck_funnel": 0.55,
            # **TASK 20 · המיזוג האורגני אל הירכיים.** האגן מתרחב
            # כלפי מטה אל הטרוכנטר, תחתיתו כיפה ולא דיסקה, והירך
            # מקבלת שוקת שעולה מעל המפרק. נמדד 06/10 שבלעדיו השבר
            # בקו הצללית אגן->ירך הוא 65°-119° בארבע הדמויות.
            "hip_blend": 1.0,
            # **TASK 22 · פיסול בובת אופנה, בעוצמה מופחתת.** סבא
            # הוא הדמות היחידה שבה ליטוש מלא היה מוחק את הגיל,
            # ולכן הלחי והשפה נמוכות והגולגולת מלאה.
            "doll_cranium": 0.70,
            "doll_cheek": 0.70,
            "doll_jaw": 0.55,
            "doll_lid": 1.00,
            "doll_lip": 0.55,
            "jaw_sharp": 0.44,
            "chin_sharp": 0.50,
        },
        "face": {
            "preset": "plain",
            # עיניים קטנות יותר מהצעירים אך עדיין בארובה שקועה -
            # "לא בוהות" הוא דרישה על הארובה, לא על הגודל.
            "eye": 1.18,
            "socket": 1.40,
            "socket_r": 1.16,
            "socket_merge": 0.58,
            "lid_cover": 1.30,
            "eye_out": -0.0052,
            # מבנה אגסי: תחתית הראש רחבה והקודקוד צר.
            # ראש **אגס**: צר ברוחב, ארוך בגובה, ועם קודקוד
            # שמתכנס. הילד הוא ההיפוך המדויק (1.02, 1.02).
            "skull": (0.80, 1.16, 1.0),
            "narrow_amt": 0.04,
            "narrow_knee": 0.70,
            "taper_top": 0.58,
            "jaw_under": 1.22,
            "cheek": 1.22,
            "cheek_hollow": 1.34,
            # גבות עבות ורכות.
            "brow_thick": 1.58,
            "brow_ridge": 1.22,
            "brow_lane": 1.02,
            "brow_slant": -0.08,
            "nose_len": 1.22,
            "nose_w": 1.16,
            "nose_tip": 1.20,
            "mouth_w": 1.26,
            "smile": 1.16,
            "lip_thick": 0.78,
            "brow_lower": 0.22,
            "skull_square": 0.0,
            "skull_box": 0.0,
            "crown_flat": 0.0,
            # שיער דליל וקצר.
            "hair": "fringe",
            "hair_len_mul": 0.52,
            "hair_n_mul": 0.58,
            "cloth": "soft",
            "limb_square": 0.0,
        },
        "hair_desat": 0.78,
        "palette": {
            "shirt": [0.46, 0.5, 0.44],
            "pants": [0.34, 0.3, 0.26],
            "hair": [0.72, 0.7, 0.68],
            "shoe": [0.2, 0.17, 0.15],
        },
    },
}



# ========================================= TASK 22 · ארבע דמויות נוספות
#
# ההוראה דרשה הרכב של 6-8 דמויות בגבהים ובסגנונות לבוש מובחנים.
# ההחלטה כאן: **ארבע רשומות חדשות שמרחיבות את הסולם מבפנים** ולא
# ארבעה שכפולים של הקיימות. סולם הגבהים הקיים הוא
# 1.20 / 1.65 / 1.70 / 1.85, והארבע החדשות ממלאות 1.33 / 1.52 /
# 1.58 / 1.78 - כלומר שמונה גבהים נבדלים בלי שתי דמויות קרובות
# מדי, וזה בדיוק מה שמונע "המון של אותה דמות בשמונה צבעים".
#
# כולן נושאות את חמשת שדות TASK 22, כי ההוראה מחייבת את ליטוש
# הפנים על **כל** ההרכב ולא רק על הזוג הראשי.

#: דמות 5 · תמיר, 1.78 מ'. אתלטי, שיער קצר, קו כתף ישר.
_TAMIR = {
    "height": 1.78,
    "ref_png": "lucas_ref.png",
    "accessories": [],
    "shape_override": {
        "girth": 0.99,
        "shoulder_scale": 1.06,
        "head_appeal": 1.24,
        "head_width": 0.99,
        "dimorph": {
            "preset": "male",
            "shoulder_square": 0.0,
            "chest_square": 0.0,
            "hip_blend": 1.0,
            "doll_cranium": 0.95,
            "doll_cheek": 1.00,
            "doll_jaw": 0.90,
            "doll_lid": 1.00,
            "doll_lip": 0.80,
            "jaw_sharp": 0.96,
            "chin_sharp": 0.82,
            "arm_base": 0.059,
            "biceps": 0.21,
            "arm_taper": 1.06,
            "leg_taper": 1.03,
            "trap_rise": 0.22,
            "neck_flare": 0.27,
            "sho_curve": 1.0,
            "neck_funnel": 0.34,
        },
        "face": {
            "preset": "male",
            "eye": 1.42, "socket": 1.18, "socket_r": 1.18,
            "socket_merge": 0.52, "lid_cover": 1.08,
            "nose_len": 0.92, "nose_w": 0.94, "nose_tip": 0.95,
            "nose_up": 0.06, "brow_lane": 0.96, "brow_slant": 0.10,
            "mouth_w": 1.02, "smile": 1.08,
            "hair": "flattop", "hair_len_mul": 0.62, "hair_clump": 0.52,
            "hair_thick": 1.06, "hair_follow": 0.92,
            "skull_square": 0.0, "skull_box": 0.0, "crown_flat": 0.0,
            "cheek": 1.04, "cloth": "crisp", "limb_square": 0.0,
        },
        "shirt_desat": 0.40,
        "hair_desat": 0.72,
        "palette": {
            "shirt": [0.2, 0.48, 0.38],
            "pants": [0.2, 0.2, 0.23],
            "hair": [0.14, 0.11, 0.09],
            "shoe": [0.12, 0.13, 0.15],
        },
    },
}

#: דמות 6 · ליבי, 1.58 מ'. שיער ארוך, קו גוף זורם.
_LIBI = {
    "height": 1.58,
    "ref_png": "maya_ref.png",
    "accessories": [],
    "shape_override": {
        "girth": 0.83,
        "shoulder_scale": 0.81,
        "head_appeal": 1.26,
        "head_width": 1.07,
        "dimorph": {
            "preset": "female",
            "shoulder_square": 0.0,
            "chest_square": 0.0,
            "waist_w": 0.075, "waist_d": 0.065, "waist_t": 0.36,
            "neck_w": 0.050, "neck_d": 0.048,
            "trap_rise": 0.36, "neck_flare": 0.46,
            "sho_curve": 1.0, "neck_funnel": 0.40,
            "hip_blend": 1.0,
            "bust_lobe": 0.016,
            "doll_cranium": 1.00,
            "doll_cheek": 1.10,
            "doll_jaw": 1.00,
            "doll_lid": 1.05,
            "doll_lip": 1.10,
            "jaw_sharp": 0.48,
            "chin_sharp": 0.58,
            "arm_base": 0.046,
            "arm_taper": 1.10,
        },
        "face": {
            "preset": "female",
            "eye": 1.64, "socket": 1.32, "socket_r": 1.28,
            "socket_merge": 0.72, "lid_cover": 1.26, "eye_out": -0.0013,
            "nose_len": 0.74, "nose_w": 0.76, "nose_tip": 0.82,
            "nose_up": 0.17, "brow_lane": 1.12, "brow_slant": 0.26,
            "mouth_w": 1.12, "smile": 1.34,
            "hair": "fringe", "hair_len_mul": 1.86, "hair_clump": 0.32,
            "hair_thick": 1.28, "hair_follow": 1.34,
            "skull_square": 0.0, "skull_box": 0.0, "crown_flat": 0.0,
            "cheek": 1.18, "cloth": "soft", "limb_square": 0.0,
        },
        "shirt_desat": 0.52,
        "hair_desat": 0.38,
        "palette": {
            "shirt": [0.62, 0.42, 0.74],
            "pants": [0.24, 0.22, 0.3],
            "hair": [0.14, 0.1, 0.08],
            "shoe": [0.26, 0.2, 0.28],
        },
    },
}

#: דמות 7 · עומר, 1.52 מ'. נער צעיר, סווטשירט רחב, שיער מתולתל.
_OMER = {
    "height": 1.52,
    "ref_png": "lucas_ref.png",
    "accessories": [],
    "shape_override": {
        "girth": 0.91,
        "shoulder_scale": 0.93,
        "head_appeal": 1.32,
        "head_width": 1.05,
        "dimorph": {
            "preset": "male",
            "shoulder_square": 0.0,
            "chest_square": 0.0,
            "hip_blend": 1.0,
            "doll_cranium": 0.75,
            "doll_cheek": 1.00,
            "doll_jaw": 0.60,
            "doll_lid": 1.00,
            "doll_lip": 0.95,
            "jaw_sharp": 0.40,
            "chin_sharp": 0.46,
            "arm_base": 0.050,
            "arm_taper": 1.04,
            "trap_rise": 0.30,
            "neck_flare": 0.38,
            "sho_curve": 1.0,
            "neck_funnel": 0.36,
        },
        "face": {
            "preset": "male",
            "eye": 1.70, "socket": 1.24, "socket_r": 1.30,
            "socket_merge": 0.74, "lid_cover": 1.16,
            "nose_len": 0.70, "nose_w": 0.78, "nose_tip": 0.80,
            "nose_up": 0.19, "brow_lane": 1.06, "brow_slant": 0.14,
            "mouth_w": 1.06, "smile": 1.22,
            "hair": "curls", "hair_len_mul": 0.94, "hair_clump": 0.26,
            "hair_thick": 1.34, "hair_follow": 1.12,
            "skull_square": 0.0, "skull_box": 0.0, "crown_flat": 0.0,
            "cheek": 1.22, "cloth": "soft", "limb_square": 0.0,
        },
        "shirt_desat": 0.66,
        "hair_desat": 0.58,
        "palette": {
            "shirt": [0.92, 0.46, 0.22],
            "pants": [0.24, 0.26, 0.32],
            "hair": [0.24, 0.16, 0.1],
            "shoe": [0.16, 0.16, 0.18],
        },
    },
}

#: דמות 8 · דפנה, 1.33 מ'. ילדה, שמלה וקוקיות.
_DAFNA = {
    "height": 1.33,
    "ref_png": "maya_ref.png",
    "accessories": [],
    "shape_override": {
        "girth": 0.88,
        "shoulder_scale": 0.78,
        "head_appeal": 1.40,
        "head_width": 1.16,
        "dimorph": {
            "preset": "female",
            "shoulder_square": 0.0,
            "chest_square": 0.0,
            "waist_w": 0.072, "waist_d": 0.066, "waist_t": 0.32,
            "neck_w": 0.047, "neck_d": 0.046,
            "trap_rise": 0.32, "neck_flare": 0.42,
            "sho_curve": 1.0, "neck_funnel": 0.34,
            "hip_blend": 1.0,
            # **0.85 ולא 0.55, ונמדד.** ראשה של דפנה הוא הרחב
            # בהרכב (head_width 1.16), ולכן אותה עוצמה שמספיקה
            # לנעם השאירה אצלה סטייה של 0.0546 מהפרבולואיד - מעל
            # הסף. ראש רחב דורש יותר הצטרות, לא פחות.
            "doll_cranium": 0.85,
            "doll_cheek": 0.90,
            "doll_jaw": 0.35,
            "doll_lid": 0.95,
            "doll_lip": 0.95,
            "jaw_sharp": 0.30,
            "chin_sharp": 0.36,
            "arm_base": 0.044,
            "arm_taper": 1.02,
        },
        "face": {
            "preset": "female",
            "eye": 1.82, "socket": 1.28, "socket_r": 1.34,
            "socket_merge": 0.80, "lid_cover": 1.30, "eye_out": -0.0013,
            "nose_len": 0.62, "nose_w": 0.70, "nose_tip": 0.72,
            "nose_up": 0.24, "brow_lane": 1.16, "brow_slant": 0.30,
            "mouth_w": 1.00, "smile": 1.40,
            "hair": "curls", "hair_len_mul": 1.18, "hair_clump": 0.30,
            "hair_thick": 1.16, "hair_follow": 1.40,
            "skull_square": 0.0, "skull_box": 0.0, "crown_flat": 0.0,
            "cheek": 1.30, "cloth": "soft", "limb_square": 0.0,
        },
        "shirt_desat": 0.50,
        "hair_desat": 0.34,
        "palette": {
            "shirt": [0.36, 0.72, 0.68],
            "pants": [0.3, 0.44, 0.44],
            "hair": [0.55, 0.36, 0.18],
            "shoe": [0.22, 0.24, 0.26],
        },
    },
}


SPEC = {"dn_ariel": _ARIEL, "dn_shir": _SHIR,
        "dn_noam": _NOAM, "dn_gidon": _GIDON,
        "dn_tamir": _TAMIR, "dn_libi": _LIBI,
        "dn_omer": _OMER, "dn_dafna": _DAFNA}


def register() -> tuple:
    """מכניס את ארבע הדמויות ל-`pipeline.CAST`.

    **אידמפוטנטי ולא דורס.** רשומה שכבר קיימת אינה נכתבת שוב, כי
    `CAST` הוא מצב גלובלי ששמונה מודולים קוראים ממנו - וכתיבה
    חוזרת תוך כדי בנייה היא בדיוק סוג הבאג שאי אפשר לשחזר.
    """
    for name, spec in SPEC.items():
        PL.CAST.setdefault(name, {
            "height": float(spec["height"]),
            "ref_png": spec["ref_png"],
            "accessories": list(spec["accessories"]),
            "shape_override": dict(spec["shape_override"]),
        })
    return CAST4


register()


# ============================================================== שערים

#: היחס שנדרש בין הדמות הגבוהה לנמוכה. 1.85/1.20 = 1.5417.
NEED_H_RATIO = 1.50

#: ההרכב שקדם למשימה הזו, והפרופילים שהוא חייב להמשיך לשאת.
PRIOR = {"lucas": ("masc", "plain"), "maya": ("fem", "plain"),
         "zippy": ("round", "joy"), "grump": ("block", "grim"),
         "shafud": ("spire", "edge"), "kufta": ("fluid", "drop"),
         "boaz": ("male", "male"), "tamar": ("female", "female")}


def build_all(quality: str = "fast") -> dict:
    """בונה את ארבעתן ומודד. עובר דרך `cast14.build_one`, כלומר
    דרך `CAST` - ולכן מודד את מה שבאמת ייבנה לסרטון."""
    return {nm: C14.build_one(nm, quality) for nm in CAST4}


def pairs() -> list[tuple[str, str]]:
    return [(CAST4[i], CAST4[j])
            for i in range(len(CAST4)) for j in range(i + 1, len(CAST4))]


def audit(quality: str = "fast") -> dict:
    out: dict = {}
    built = build_all(quality)

    def chk(name, ok, detail):
        out[name] = {"pass": bool(ok), "detail": str(detail)}

    # 1 · מובחנות: כל אחד מששת הזוגות
    worst_n, worst_pair = 99, ()
    for a, b in pairs():
        r = C14.distinct(built[a], built[b])
        if r["n_far"] < worst_n:
            worst_n, worst_pair = r["n_far"], (a, b)
    chk("כל ששת הזוגות מובחנים בצללית",
        worst_n >= C14.NEED_N,
        f"{worst_n}/{len(C14.MEASURES)} מדדים רחוקים ב-"
        f"{C14.NEED_GAP:.0%} במקרה הגרוע "
        f"({worst_pair[0]} מול {worst_pair[1]})")

    # 2 · סולם הגבהים
    hs = {nm: built[nm]["height"] for nm in CAST4}
    ratio = max(hs.values()) / min(hs.values())
    chk("ארבעה גבהים נבדלים", len(set(round(v, 3) for v in hs.values())) == 4,
        " · ".join(f"{nm.split('_')[1]} {hs[nm]:.2f}" for nm in CAST4))
    chk(f"ויחס הגובה לפחות {NEED_H_RATIO}", ratio >= NEED_H_RATIO,
        f"{ratio:.3f}")

    # 3 · אפס קופסתיות. 1.0 הוא אליפסה מדויקת; מעליו זו קופסה.
    # 1.000 הוא אליפסה מדויקת. 1.01 הוא סובלנות לרעש הדגימה
    # (בועז מודד 1.002 על קלט אפס), ולא חלון לקופסה.
    sq = {nm: built[nm]["d"]["shoulder_squareness"] for nm in CAST4}
    bad = [nm for nm, v in sq.items() if v > 1.01]
    chk("אף כתף אינה קופסתית (אליפסה = 1.000)", not bad,
        bad or " · ".join(f"{nm.split('_')[1]} {sq[nm]:.3f}"
                          for nm in CAST4))
    bx = {nm: PL.CAST[nm]["shape_override"]["face"].get("skull_box", 0.0)
          for nm in CAST4}
    chk("ואף גולגולת אינה קופסה", all(v == 0.0 for v in bx.values()),
        bx)

    # 4 · הארובה שקועה והעפעף עוטף - האיסור על "עיניים בוהות".
    #    נמדד על **הבקשה שנכנסה ל-CAST**, כי זה הערוץ שמייצר את
    #    הגאומטריה; המדידה על הרשת עצמה היא ב-`disney_mesh`.
    soc = {nm: PL.CAST[nm]["shape_override"]["face"] for nm in CAST4}
    bad = [nm for nm, f in soc.items()
           if f.get("socket", 1.0) <= 1.05 or f.get("lid_cover", 1.0) <= 1.05
           or f.get("socket_merge", 0.0) < 0.5]
    chk("ארובה שקועה ועפעף עוטף בכל הארבע", not bad,
        bad or " · ".join(
            f"{nm.split('_')[1]} ארובה {soc[nm]['socket']:.2f} "
            f"עפעף {soc[nm]['lid_cover']:.2f}" for nm in CAST4))

    # 5 · הצוואר נכנס לטרפז בעקומה ולא כצינור: `trap_rise` חייב
    #    להיות חיובי בכולן, ו-`neck_flare` חייב להתרחב כלפי מטה.
    nk = {nm: PL.CAST[nm]["shape_override"]["dimorph"] for nm in CAST4}
    bad = [nm for nm, d in nk.items()
           if float(d.get("trap_rise", 0.0)) <= 0.0
           or float(d.get("neck_flare", 0.0)) <= 0.0]
    chk("אין צוואר-צינור: טרפז מורם והתרחבות למטה", not bad,
        bad or " · ".join(
            f"{nm.split('_')[1]} טרפז {nk[nm]['trap_rise']:.2f} "
            f"פתיחה {nk[nm]['neck_flare']:.2f}" for nm in CAST4))

    # 6 · ההרכב שקדם למשימה לא זז באף ספרה. זה השער שמגן על 1260
    #     הבדיקות הקיימות מפני הוספת ארבע רשומות ל-CAST.
    from rig import dimorph as DM                         # noqa: PLC0415
    from rig import facestyle as FS                       # noqa: PLC0415
    bad = []
    for nm, (dk, fk) in PRIOR.items():
        sh = PL.CAST[nm]["shape_override"]
        if DM.get(sh.get("dimorph")).key != dk:
            bad.append(f"{nm}/גוף")
        if FS.get(sh.get("face")).key != fk:
            bad.append(f"{nm}/פנים")
    chk("שמונה הדמויות הקודמות על אותו פרופיל בדיוק", not bad,
        bad or f"כל {len(PRIOR)}")

    # 7 · הילד הוא Chibi באמת: הראש שלו גדול **ביחס לגוף** יותר
    #     מאצל כל אחד מהשלושה. זה המדד שתופס את מלכודת
    #     `head_to_body` - שדה שנכתב ולא נקרא.
    hb = {}
    for nm in CAST4:
        sh = PL.CAST[nm]["shape_override"]
        hb[nm] = (float(sh.get("head_width", 1.0))
                  * float(sh.get("head_appeal", 1.0))) / float(hs[nm])
    chk("ראש הילד הגדול ביחס לגוף מכולם",
        hb["dn_noam"] == max(hb.values())
        and hb["dn_noam"] > max(v for k, v in hb.items() if k != "dn_noam")
        * 1.25,
        " · ".join(f"{nm.split('_')[1]} {hb[nm]:.3f}" for nm in CAST4))

    out["_built"] = {nm: {"height": built[nm]["height"],
                          "role": ROLE[nm],
                          "vec": C14.vector(built[nm])} for nm in CAST4}
    return out


def passed(quality: str = "fast") -> bool:
    return all(v["pass"] for k, v in audit(quality).items()
               if not k.startswith("_"))


def main(argv=None) -> int:
    import argparse                                      # noqa: PLC0415
    import json                                          # noqa: PLC0415
    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(description="ההרכב של הפארק (TASK 18)")
    ap.add_argument("--quality", default="fast", choices=["fast", "full"])
    ap.add_argument("--json", default="")
    ap.add_argument("--build", action="store_true",
                    help="לבנות את ארבעת ה-GLB")
    ap.add_argument("--out", default=r"D:\claude-bot\out\char3d\rigged")
    a = ap.parse_args(argv)

    if a.build:
        rep = PL.build_cast(a.out, quality="full", names=list(CAST4))
        for nm, r in rep.items():
            print(f"✅ {ROLE[nm]} · {r.get('glb')}")
        return 0

    rep = audit(a.quality)
    bad = 0
    for k, v in rep.items():
        if k.startswith("_"):
            continue
        print(("✅" if v["pass"] else "❌"), k, "-", v["detail"])
        bad += 0 if v["pass"] else 1
    n = sum(1 for k in rep if not k.startswith("_"))
    print(f"\n{n - bad}/{n} עברו")
    if a.json:
        Path(a.json).write_text(
            json.dumps(rep, ensure_ascii=False, indent=1), encoding="utf-8")
    return 0 if bad == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
