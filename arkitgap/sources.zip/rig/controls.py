# -*- coding: utf-8 -*-
"""ריג הבקרות: שמות קריאים לאנימטור -> סיבובי עצמות.

העיקרון: אנימטור לא מסובב עצמות. הוא אומר "פתח פה 0.6", "מצמץ שמאל",
"הרם גבה", "סגור אגרוף", "שים את היד כאן". התרגום לעצמות הוא תפקיד
הריג, והוא נמצא כאן - בפייתון, כך שהוא **נבדק ביחידות** ולא מתגלה
כשבור רק בתוך הדפדפן.

כל בקרה היא (תחום, ברירת מחדל). ערך מחוץ לתחום נחתך, ולא זורק - פוזה
שבורה שמחזירה nan מעלימה את הדמות מהפריים בלי שום שגיאה, וזה בדיוק מה
שקרה כאן קודם.
"""
from __future__ import annotations

import math

import numpy as np

from .skeleton import (Skeleton, Spring, chain_rotations, quat_from_euler,
                       quat_mul, quat_to_mat, two_bone_ik)

D = math.pi / 180.0


def _conj(q):
    return np.array([-q[0], -q[1], -q[2], q[3]])


# ----------------------------------------------------------- טבלת הבקרות

CONTROLS: dict[str, tuple] = {}


def _reg(name, lo, hi, default=0.0, group="misc"):
    CONTROLS[name] = (lo, hi, default, group)


# פנים
_reg("jaw_open", 0.0, 1.0, 0.0, "face")
_reg("jaw_side", -1.0, 1.0, 0.0, "face")
_reg("jaw_fwd", -1.0, 1.0, 0.0, "face")
_reg("tongue_up", -1.0, 1.0, 0.0, "face")
_reg("tongue_out", 0.0, 1.0, 0.0, "face")
_reg("eye_aim_x", -1.0, 1.0, 0.0, "face")
_reg("eye_aim_y", -1.0, 1.0, 0.0, "face")
_reg("eye_converge", 0.0, 1.0, 0.0, "face")
for s in ("L", "R"):
    _reg(f"blink_{s}", 0.0, 1.0, 0.0, "face")
    _reg(f"squint_{s}", 0.0, 1.0, 0.0, "face")
    _reg(f"brow_up_{s}", -1.0, 1.0, 0.0, "face")
    # **הגבה הפנימית והחיצונית הן שתי בקרות נפרדות.** עד TASK 02
    # הייתה כאן רק `brow_up`, שמרימה את שתי עצמות הגבה יחד - ולכן
    # "inner brow raise", שהוא הסימן המובהק של עצב (AU1 ב-FACS)
    # ולא היה אפשר לבטא אותו בכלל: הרמה אחידה של הגבה נקראת
    # כהפתעה, לא כצער. `brow_up` נשאר כקיצור לשתיהן.
    _reg(f"brow_inner_up_{s}", -1.0, 1.0, 0.0, "face")
    _reg(f"brow_outer_up_{s}", -1.0, 1.0, 0.0, "face")
    _reg(f"brow_furrow_{s}", 0.0, 1.0, 0.0, "face")
    _reg(f"cheek_puff_{s}", 0.0, 1.0, 0.0, "face")
    _reg(f"smile_{s}", -1.0, 1.0, 0.0, "face")
# ראש וגוף
for n in ("head_yaw", "head_pitch", "head_roll",
          "neck_yaw", "neck_pitch", "neck_roll",
          "spine_bend", "spine_side", "spine_twist",
          "hips_yaw", "hips_pitch", "hips_roll"):
    _reg(n, -1.0, 1.0, 0.0, "body")
_reg("breath", -1.0, 1.0, 0.0, "body")
# אצבעות
for s in ("L", "R"):
    for f in ("thumb", "index", "middle", "ring", "pinky"):
        _reg(f"curl_{f}_{s}", -0.3, 1.0, 0.0, "hand")
    _reg(f"spread_{s}", -1.0, 1.0, 0.0, "hand")
    _reg(f"fist_{s}", 0.0, 1.0, 0.0, "hand")
    _reg(f"wrist_pitch_{s}", -1.0, 1.0, 0.0, "hand")
    _reg(f"wrist_yaw_{s}", -1.0, 1.0, 0.0, "hand")
# זרועות ורגליים ב-FK (כשלא משתמשים ב-IK)
for s in ("L", "R"):
    for n in ("arm_fwd", "arm_twist", "elbow",
              "leg_fwd", "leg_out", "knee", "ankle"):
        _reg(f"{n}_{s}", -1.0, 1.0, 0.0, "limb")
    # ברירת המחדל של הזרועות אינה 0. פוזת המנוחה של **השלד** היא צלב
    # (T-pose), כי זו פוזת הכריכה הנכונה למשקולות - אבל פוזת המנוחה של
    # ה**דמות** היא זרועות מורדות. בלי ההפרדה הזו כל פוזה שלא נגעה
    # בזרועות יצאה עם ידיים פרושות לצדדים, וזה נראה כמו מחסום ולא כמו
    # אדם. נמדד על 30 הרנדורים הראשונים.
    _reg(f"arm_down_{s}", -1.0, 1.0, 0.78, "limb")

# --------------------------------------------------- TASK 06: גוף מלא
#
# עד כאן לגוף היו שלוש בקרות עמוד שדרה, שלוש אגן ונשימה - וזה הכול.
# כלומר לא הייתה שום דרך לבטא **חלוקת משקל**, **כתפיים** או **כפות
# רגליים**, שלושת הדברים שהופכים עמידה לעמידה של אדם. דמות שמשקלה
# מחולק שווה בין שתי רגליים, עם כתפיים סימטריות וכפות רגליים
# מקבילות, נראית כמו בובת ראווה - וזה בדיוק מה שנראה ברנדורים עד
# TASK 05. שלוש משפחות הבקרות האלה נוספות כאן.

# **משקל.** הציר המרכזי של כל עמידה. -1 = כל המשקל על רגל שמאל,
# +1 = על ימין, 0 = מחולק שווה (וזו דווקא העמידה הכי *פחות* טבעית
# לאורך זמן - אדם עובר מרגל לרגל).
_reg("weight_shift", -1.0, 1.0, 0.0, "body")
# הגובה והקדמיות של מרכז הכובד: כריעה קלה, הישענות קדימה/אחורה.
_reg("weight_drop", -1.0, 1.0, 0.0, "body")
_reg("weight_fwd", -1.0, 1.0, 0.0, "body")
# הזזה צידית של האגן בלי סיבוב (hip hike) - מה שקורה בפועל כשנשענים
# על רגל אחת. `hips_roll` לבדו מטה את האגן אבל לא מזיז אותו.
_reg("hips_shift", -1.0, 1.0, 0.0, "body")

for s in ("L", "R"):
    # **כתפיים.** שלוש דרגות חופש נפרדות, כי הן אומרות דברים שונים:
    # הרמה (מתח/הגנה), קידום (התכנסות/הסתגרות), ונסיגה (פתיחת חזה,
    # ביטחון). בקרה אחת "shoulder" הייתה מערבבת בין פחד לגאווה.
    _reg(f"shoulder_up_{s}", -1.0, 1.0, 0.0, "body")
    _reg(f"shoulder_fwd_{s}", -1.0, 1.0, 0.0, "body")
    # **כפות רגליים.** זווית הפנייה החוצה והגלגול על הקצה - שתיהן
    # נגזרות של חלוקת המשקל, ובלעדיהן רגל "חופשית" נשארת שטוחה על
    # הרצפה ומסגירה שהמשקל לא עבר באמת.
    _reg(f"foot_turn_{s}", -1.0, 1.0, 0.0, "limb")
    _reg(f"foot_roll_{s}", -1.0, 1.0, 0.0, "limb")
    # כיוון המרפק במרחב (pole). זה מה שמבדיל בין אותה יד שמגיעה
    # לאותה נקודה "פתוח" לבין "צמוד לגוף" - שתי משמעויות שונות
    # לגמרי באותה גאומטריה.
    _reg(f"elbow_out_{s}", -1.0, 1.0, 0.0, "limb")

GROUPS = sorted({v[3] for v in CONTROLS.values()})


def defaults() -> dict:
    return {k: v[2] for k, v in CONTROLS.items()}


def clamp(name, value):
    lo, hi, _d, _g = CONTROLS[name]
    v = float(value)
    if v != v:          # nan
        return 0.0
    return max(lo, min(hi, v))


def normalize(ctl: dict | None) -> dict:
    out = defaults()
    for k, v in (ctl or {}).items():
        if k not in CONTROLS:
            raise KeyError(f"אין בקרה בשם {k!r}")
        out[k] = clamp(k, v)
    return out


# ----------------------------------------------------------- הערכת הריג

ARM_IK = {}   # ממולא מבחוץ: {"L": (target, pole)}


def evaluate(skel: Skeleton, ctl: dict | None = None,
             ik: dict | None = None) -> dict[str, np.ndarray]:
    """מחזיר סיבוב מקומי לכל עצם שמשתנה. ik = {"hand_L": {"target":..,
    "pole":..}, "foot_R": {...}}"""
    c = normalize(ctl)
    # **TASK 15 · מרווח הזרוע (06/10).** `arm_down=1.0` מסובב את עצם
    # הזרוע ב-70 מעלות פנימה ומצמיד אותה לקו הכתף. אצל דמות שהאגן
    # שלה רחב מהכתף הקו שמתחת לכתף רחב יותר, ולכן אותה זווית חודרת
    # אל הירך - זה מה שדווח 06/10 כ"זרועות שנבלעות בגוף בשוטים
    # בינוניים". התקרה יושבת **כאן** ולא בכל פוזה בנפרד: הליכה,
    # ריצה, מחוות דיבור וספריית הפוזות כולן עוברות דרך הפונקציה הזו.
    #
    # הגנה **חד-צדדית**: `min` חוסם רק הצמדה. הרמת היד היא `arm_down`
    # שלילי והיא ממשיכה לעבוד במלואה - אחרת "להרים יד" היה נחסם
    # בדיוק אצל הדמות שהמרווח נועד לעזור לה.
    _ac = float(getattr(skel, "arm_clear", 0.0) or 0.0)
    if _ac > 1e-9:
        _cap = max(0.0, 1.0 - _ac)
        for _s in ("L", "R"):
            _k = f"arm_down_{_s}"
            if c[_k] > _cap:
                c[_k] = _cap
    q: dict[str, np.ndarray] = {}

    def rot(bone, rx=0.0, ry=0.0, rz=0.0):
        nq = quat_from_euler(rx, ry, rz)
        q[bone] = quat_mul(q[bone], nq) if bone in q else nq

    # --- גוף
    #
    # **TASK 06.** חלוקת המשקל אינה בקרה שיושבת לצד האחרות - היא
    # מזינה אותן. אדם שמעביר משקל על רגל ימין מטה את האגן, והעמוד
    # מתקזז בכיוון ההפוך כדי שהראש יישאר מעל מרכז התמיכה. זה
    # ה-contrapposto, וזה ההבדל בין עמידה לבובת ראווה. הקיזוז נעשה
    # **כאן**, בשכבה הגאומטרית, ולא בשכבת המשחק - אחרת כל קורא
    # שישתמש ב-`weight_shift` יצטרך לזכור לקזז בעצמו, ומי שישכח
    # יקבל דמות שנוטה הצידה ונופלת.
    w = c["weight_shift"]
    hips_roll = c["hips_roll"] + w * 0.45
    spine_side = c["spine_side"] - w * 0.30      # קיזוז ראשון
    head_roll = c["head_roll"] - w * 0.07        # הראש נשאר ישר

    rot("hips", c["hips_pitch"] * 12 * D + c["weight_fwd"] * 6 * D,
        c["hips_yaw"] * 25 * D, hips_roll * 12 * D)
    rot("spine_01", c["spine_bend"] * 14 * D, c["spine_twist"] * 10 * D,
        spine_side * 10 * D)
    rot("spine_02", c["spine_bend"] * 12 * D, c["spine_twist"] * 12 * D,
        spine_side * 9 * D)
    rot("chest", c["spine_bend"] * 9 * D + c["breath"] * 3 * D,
        c["spine_twist"] * 14 * D, spine_side * 7 * D)
    rot("neck", c["neck_pitch"] * 20 * D, c["neck_yaw"] * 28 * D,
        c["neck_roll"] * 18 * D)
    rot("head", c["head_pitch"] * 24 * D, c["head_yaw"] * 42 * D,
        head_roll * 26 * D)

    # --- פנים
    rot("jaw", c["jaw_open"] * 21 * D, c["jaw_side"] * 7 * D, 0.0)
    rot("tongue_01", -c["tongue_up"] * 22 * D + c["tongue_out"] * 10 * D, 0, 0)
    rot("tongue_02", -c["tongue_up"] * 18 * D + c["tongue_out"] * 14 * D, 0, 0)
    conv = c["eye_converge"] * 9 * D
    for s, sg in (("L", 1.0), ("R", -1.0)):
        rot(f"eye_{s}", -c["eye_aim_y"] * 24 * D,
            c["eye_aim_x"] * 32 * D - sg * conv, 0.0)
        lid = c[f"blink_{s}"]
        rot(f"eyelid_up_{s}", lid * 38 * D + c[f"squint_{s}"] * 9 * D, 0, 0)
        rot(f"eyelid_lo_{s}", -(lid * 12 * D + c[f"squint_{s}"] * 10 * D), 0, 0)
        up = c[f"brow_up_{s}"]
        fur = c[f"brow_furrow_{s}"]
        # הקיצור `brow_up` מרים את שתי עצמות הגבה; `brow_inner_up`
        # ו-`brow_outer_up` מוסיפות עליו בנפרד. הן **מתחברות** ולא
        # דורסות, כך שאפשר גם "גבה אחידה" וגם "רק הפנימית" (AU1).
        ui = up + c[f"brow_inner_up_{s}"]
        uo = up + c[f"brow_outer_up_{s}"]
        rot(f"brow_in_{s}", -ui * 15 * D, 0.0, sg * fur * 14 * D)
        rot(f"brow_out_{s}", -uo * 12 * D, 0.0, -sg * uo * 5 * D)
        sm = c[f"smile_{s}"]
        rot(f"cheek_{s}", -(sm * 12 * D + c[f"squint_{s}"] * 6 * D),
            0.0, sg * (sm * 10 * D + c[f"cheek_puff_{s}"] * 4 * D))

    # --- גפיים ב-FK
    for s, sg in (("L", 1.0), ("R", -1.0)):
        # **TASK 06 - כתפיים.** עד כאן ה-clavicle זזה רק כנגזרת של
        # הורדת הזרוע, כלומר לא הייתה דרך להרים כתף בלי להזיז את
        # היד. הרמה היא סיבוב סביב Z, קידום הוא סביב Y - שתי תנועות
        # אנטומיות שונות שהתערבבו לאחת.
        rot(f"clavicle_{s}", 0.0,
            -sg * c[f"shoulder_fwd_{s}"] * 16 * D,
            sg * (c[f"arm_down_{s}"] * -5 * D
                  + c[f"shoulder_up_{s}"] * 14 * D))
        rot(f"upperarm_{s}", sg * c[f"arm_fwd_{s}"] * -55 * D,
            c[f"arm_twist_{s}"] * 30 * D,
            sg * c[f"arm_down_{s}"] * -70 * D
            + sg * c[f"elbow_out_{s}"] * -18 * D)
        rot(f"forearm_{s}", 0.0, sg * c[f"elbow_out_{s}"] * 12 * D,
            sg * -abs(c[f"elbow_{s}"]) * 110 * D)
        # סימן מינוס: סיבוב חיובי סביב X שולח את הירך **אחורה**, כי
        # הנקודה נמצאת מתחת לציר. בלי המינוס "להרים ברך" כיפף את הרגל
        # לכיוון הלא נכון - נראה בבירור בגיליון המגע הראשון.
        # **TASK 06 - הרגליים נושאות את המשקל.** רגל שהמשקל עליה
        # נשארת ישרה; הרגל החופשית מתכופפת קלות בברך ומגלגלת את
        # כף הרגל פנימה. בלי זה שתי הרגליים זהות, והעין קוראת את
        # זה מיד כ"עומדת על שתי רגליים שוות" - כלומר כבובה.
        side = 1.0 if s == "R" else -1.0
        load = max(0.0, w * side)              # 0..1 - עומס על הרגל הזו
        free = max(0.0, -w * side)             # 0..1 - כמה היא חופשית
        rot(f"thigh_{s}", -c[f"leg_fwd_{s}"] * 45 * D, 0.0,
            sg * c[f"leg_out_{s}"] * 22 * D)
        rot(f"shin_{s}", (abs(c[f"knee_{s}"]) + free * 0.16
                          + c["weight_drop"] * 0.22) * 80 * D, 0.0, 0.0)
        rot(f"foot_{s}", c[f"ankle_{s}"] * 28 * D - free * 5 * D,
            sg * c[f"foot_turn_{s}"] * 20 * D,
            sg * (c[f"foot_roll_{s}"] + free * 0.25 - load * 0.08) * 14 * D)
        rot(f"hand_{s}", 0.0, sg * c[f"wrist_yaw_{s}"] * 22 * D,
            sg * c[f"wrist_pitch_{s}"] * -40 * D)
        # אצבעות
        for i, f in enumerate(("thumb", "index", "middle", "ring", "pinky")):
            curl = max(c[f"curl_{f}_{s}"], c[f"fist_{s}"])
            base = (28, 34, 36, 34, 30)[i]
            for j, mul in ((1, 1.0), (2, 1.05), (3, 0.85)):
                rot(f"{f}_{j:02d}_{s}", 0.0, 0.0, -sg * curl * base * mul * D)
            sp = c[f"spread_{s}"] * (0.9, 0.5, 0.0, -0.5, -0.9)[i]
            rot(f"{f}_01_{s}", 0.0, sp * 11 * D, 0.0)

    if ik:
        _apply_ik(skel, q, ik)
    return q


def _apply_ik(skel: Skeleton, q: dict, ik: dict):
    """IK לשתי עצמות לידיים ולרגליים. פועל **אחרי** ה-FK, ודורס את
    שתי העצמות של השרשרת בלבד - כך שסיבוב הגב והאגן נשמרים."""
    CH = {"hand_L": ("upperarm_L", "forearm_L", "hand_L"),
          "hand_R": ("upperarm_R", "forearm_R", "hand_R"),
          "foot_L": ("thigh_L", "shin_L", "foot_L"),
          "foot_R": ("thigh_R", "shin_R", "foot_R")}
    for key, spec in ik.items():
        if key not in CH:
            raise KeyError(f"אין שרשרת IK בשם {key!r}")
        a, b, e = CH[key]
        W = skel.forward(q)
        ia, ib, ie = (skel.by_name[n].index for n in (a, b, e))
        root = W[ia][:3, 3]
        mid = W[ib][:3, 3]
        end = W[ie][:3, 3]
        target = np.asarray(spec["target"], float)
        pole = np.asarray(spec.get("pole", root + np.array([0, 0, 1.0])), float)
        nmid, nend = two_bone_ik(root, mid, end, target, pole)
        if not np.all(np.isfinite(nmid)) or not np.all(np.isfinite(nend)):
            continue
        # chain_rotations מחזיר את ה**הפרש** בין הכיוון הנוכחי לכיוון
        # המבוקש, ולא את הסיבוב המוחלט של העצם. הגרסה הראשונה כאן
        # התייחסה אליו כאל מוחלט, והיד עצרה 46 ס"מ מהמטרה בלי שום
        # שגיאה - הסוג הכי מסוכן של באג ריג.
        parent = skel.by_name[a].parent
        qpw = _world_q(skel, q, parent)
        qa_old = _world_q(skel, q, a)
        qb_old = _world_q(skel, q, b)
        qa_w = quat_mul(chain_rotations(root, mid, root, nmid), qa_old)
        q[a] = quat_mul(_conj(qpw), qa_w)
        qb_w = quat_mul(chain_rotations(mid, end, nmid, nend), qb_old)
        q[b] = quat_mul(_conj(qa_w), qb_w)


def _world_q(skel: Skeleton, q: dict, name: str | None):
    out = np.array([0.0, 0.0, 0.0, 1.0])
    chain = []
    while name is not None:
        chain.append(name)
        name = skel.by_name[name].parent
    for n in reversed(chain):
        if n in q:
            out = quat_mul(out, q[n])
    return out


# ----------------------------------------------------------- תנועה משנית


class SecondaryMotion:
    """פיגור קפיצי על עצמות "רכות". זה מה שהופך תנועה נכונה לתנועה
    שנראית חיה: החזה ממשיך רגע אחרי שהאגן עצר, והראש מגיע באיחור.

    מיושם על זוויות אוילר מקומיות ולא על קוורטניון - slerp של קפיץ על
    קוורטניון התהפך סימן באמצע תנועה וייצר קפיצה של 180 מעלות.
    """

    LAG = {"chest": (70.0, 0.80, 0.55),     # (קשיחות, ריסון, עוצמה)
           "neck": (95.0, 0.78, 0.45),
           "head": (120.0, 0.75, 0.35),
           "spine_02": (85.0, 0.85, 0.35)}

    def __init__(self, strength: float = 1.0):
        self.strength = float(strength)
        self.sp = {n: Spring(k, z, 4) for n, (k, z, _a) in self.LAG.items()}

    def apply(self, q: dict[str, np.ndarray], dt: float):
        for n, (_k, _z, amt) in self.LAG.items():
            cur = q.get(n, np.array([0.0, 0.0, 0.0, 1.0]))
            lag = self.sp[n].step(cur, dt)
            ln = np.linalg.norm(lag)
            if ln < 1e-9:
                continue
            lag = lag / ln
            if np.dot(lag, cur) < 0:
                lag = -lag
            a = amt * self.strength
            mixed = cur * (1 - a) + lag * a
            mn = np.linalg.norm(mixed)
            if mn > 1e-9:
                q[n] = mixed / mn
        return q


# ----------------------------------------------------------- פוזות מוכנות


def pose_library(skel: Skeleton) -> dict:
    """חמש פוזות שונות מהותית - זה מה שבדיקת הקבלה מריצה."""
    h = skel.height
    P = {b.name: np.asarray(b.rest) for b in skel.bones}
    lib = {}

    lib["rest"] = ({}, {})

    lib["wave"] = ({
        "spine_twist": -0.25, "head_yaw": 0.22, "head_pitch": -0.1,
        "smile_L": 0.7, "smile_R": 0.7, "squint_L": 0.3, "squint_R": 0.3,
        "arm_down_R": 0.92,
        "brow_up_L": 0.4, "brow_up_R": 0.4, "jaw_open": 0.25,
        "spread_L": 0.6, "wrist_pitch_L": 0.3,
    }, {"hand_L": {"target": (0.34 * h / 1.7, 1.62 * h / 1.7, 0.16 * h / 1.7),
                   "pole": (0.55 * h / 1.7, 1.05 * h / 1.7, -0.3 * h / 1.7)}})

    lib["point"] = ({
        "spine_bend": 0.15, "spine_twist": 0.3, "head_yaw": -0.35,
        "eye_aim_x": -0.6, "brow_furrow_L": 0.5, "brow_furrow_R": 0.5,
        "jaw_open": 0.45, "curl_middle_R": 1.0, "curl_ring_R": 1.0,
        "curl_pinky_R": 1.0, "curl_thumb_R": 0.5, "arm_down_L": 0.9,
        "leg_fwd_L": 0.2, "knee_L": 0.25,
    }, {"hand_R": {"target": (-0.30 * h / 1.7, 1.42 * h / 1.7, 0.42 * h / 1.7),
                   "pole": (-0.50 * h / 1.7, 1.0 * h / 1.7, -0.2 * h / 1.7)}})

    lib["crouch"] = ({
        "hips_pitch": 0.35, "spine_bend": 0.6, "neck_pitch": -0.4,
        "head_pitch": -0.3, "leg_fwd_L": 0.9, "leg_fwd_R": 0.9,
        "knee_L": 1.0, "knee_R": 1.0, "ankle_L": -0.6, "ankle_R": -0.6,
        "fist_L": 0.8, "fist_R": 0.8, "arm_fwd_L": 0.5, "arm_fwd_R": 0.5,
        "arm_down_L": 0.95, "arm_down_R": 0.95,
        "blink_L": 0.45, "blink_R": 0.45, "jaw_open": 0.15,
    }, {})

    lib["reach_up"] = ({
        "spine_bend": -0.3, "neck_pitch": 0.5, "head_pitch": 0.45,
        "eye_aim_y": 0.7, "brow_up_L": 0.9, "brow_up_R": 0.9,
        "jaw_open": 0.6, "tongue_up": 0.3,
        "spread_L": 0.8, "spread_R": 0.8, "arm_down_L": 0.0, "arm_down_R": 0.0,
        "leg_out_L": 0.2, "leg_out_R": 0.2,
    }, {"hand_L": {"target": (0.26 * h / 1.7, 1.95 * h / 1.7, 0.08 * h / 1.7),
                   "pole": (0.60 * h / 1.7, 1.2 * h / 1.7, -0.35 * h / 1.7)},
        "hand_R": {"target": (-0.26 * h / 1.7, 1.95 * h / 1.7, 0.08 * h / 1.7),
                   "pole": (-0.60 * h / 1.7, 1.2 * h / 1.7, -0.35 * h / 1.7)}})

    lib["talk_closeup"] = ({
        "head_yaw": 0.12, "head_roll": -0.1, "neck_pitch": -0.1,
        "jaw_open": 0.75, "jaw_side": 0.2, "tongue_out": 0.25,
        "eye_aim_x": 0.25, "eye_aim_y": -0.15, "blink_L": 0.2,
        "blink_R": 0.2, "brow_up_L": 0.55, "brow_up_R": 0.3,
        "smile_L": 0.45, "smile_R": 0.45, "cheek_puff_L": 0.2,
        "fist_L": 0.3, "curl_index_L": 0.0,
        "arm_down_L": 0.86, "arm_down_R": 0.80, "arm_fwd_L": 0.18,
    }, {})
    return lib
