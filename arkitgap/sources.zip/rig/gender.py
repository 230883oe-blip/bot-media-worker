# -*- coding: utf-8 -*-
"""TASK 15 (06/10) - שני ארכיטיפים מגדריים מובחנים, ומרווח הזרוע.

ההוראה שהתקבלה: לבנות שתי דמויות חדשות "שמזוהות בצורה ברורה ומובחנת
כגבר וכאישה", עם פרופורציות שלד מוגדרות (V רחב מול שעון חול שהאגן בו
דומיננטי), תווי פנים מנוגדים (לסת מרובעת וגבה נמוכה ישרה מול פנים
סגלגלות וגבה קשתית מורמת), גבהים 1.85 ו-1.65, ושני דגשים טכניים:
**מרווח ביטחון לזרוע** שמונע חדירה לירכיים בהליכה ובריצה, ו**איסור
מפורש על ערכים ניטרליים** - ערכי קצה מנוגדים לשני הארכיטיפים.

================================================================
למה השער כאן אינו דומה לשער של TASK 14
================================================================

`cast14` מודד "אפס דמיון חזותי" כספירת פערים: 8 מדדים מתוך 14 שבהם
שתי הדמויות רחוקות ב-20% ומעלה. זה המדד הנכון שם, כי שפוד וכופתה
נבדלים ב**פרופורציה** - 1.98 מ' מול 1.12 מ', יחס 1.77.

כאן הוא לא יעבוד, ולא מפני שהוא מחמיר אלא מפני שהוא **מודד את הדבר
הלא נכון**:

1. **הגבהים קרובים בכוונה.** 1.85 מול 1.65 הוא יחס 1.12 - הקטן בכל
   הפרויקט (זיגי מול גרומפ הוא 1.23). כלומר "שתי דמויות שונות" כאן
   אינו הישג של גובה, ולהודות בכך זה הקושי: מה שחייב להבדיל הוא
   **היחסים בתוך הגוף**, ולא הגוף מול גוף אחר.
2. **ספירת פערים אינה מודדת כיוון.** שתי דמויות יכולות להיות רחוקות
   ב-40% בכל 14 המדדים ושתיהן להיראות גבריות. "מזוהה כאישה" אינה
   "שונה מהגבר" אלא **נמצאת בצד מסוים** של כל ציר אנטומי.

לכן השער כאן הוא **מכוון** (`DIMORPHIC`): לכל מדד יש הצהרה מי אמור
להיות גבוה, ובאיזה פער מינימלי. מדד שהכיוון בו הפוך נכשל גם אם הפער
בו עצום - וזה בדיוק מה שמונע "זיהוי מגדרי" שהוא רק הבדל.

ובנוסף שלושה שערים מוחלטים (`ABSOLUTE`), שאינם השוואה בין השתיים
אלא עובדה אנטומית על כל אחת בנפרד: כתף רחבה מהאגן אצל הגבר, כתף
**צרה** מהאגן אצל האישה, ומותן צרה משניהם אצלה. בלעדיהם אפשר לעבור
את כל השער המכוון עם שתי דמויות גבריות שאחת מהן פחות.

================================================================
"אסור להשתמש בערכים ניטרליים" - איך נאכפת הוראה כזאת
================================================================

ההוראה מפורשת ואי אפשר לאכוף אותה על ידי מדידה של דמות אחת: "0.14"
אינו ניטרלי או קיצוני בפני עצמו. לכן `neutral_free` בודק **את
הדגמים עצמם**, שדה-שדה, מול `dimorph.NEUTRAL` ו-`facestyle.PLAIN`:

* אף שדה מורפולוגי של אחד הארכיטיפים אינו **שווה** לערך הניטרלי.
* ובכל שדה שהוא ציר של ניגוד, שני הארכיטיפים נמצאים ב**צדדים
  מנוגדים** של הניטרלי - אחד מעליו ואחד מתחתיו.

התנאי השני הוא העיקר. בלעדיו "שני ערכים שונים מהניטרלי" יכול להיות
0.16 ו-0.18, כלומר שניהם באותו צד - וזה מה שהדגמים המקוריים עשו
במחציתם. ראה את רשימת הצירים ב-`OPPOSED`.

================================================================
מרווח הזרוע - ולמה "זרוע נבלעת" היא תקלה של הגוף ולא של הפוזה
================================================================

ב-06/10 דווח ש"הזרועות של הדמות הנמוכה נבלעות בגוף בשוטים
בינוניים". הדיווח היה נכון, והמסקנה הטבעית ממנו - "לתקן את פוזת
ההליכה" - הייתה שגויה: `locomotion.controls_at` מחזיר `arm_down`
של 1.00 **לכל** הדמויות, ואותה זווית בדיוק נראית נכונה על גוף
שהכתף בו היא הקו הרחב, וחודרת על גוף שהאגן בו רחב מהכתף ב-19%.

כלומר הפוזה אינה המשתנה; הגוף מתחתיה הוא. לכן `Dimorph.arm_clear`
הוא שדה של **פרופיל הגוף**, ו-`controls.evaluate` אוכפת אותו על כל
פוזה שעוברת בה - הליכה, ריצה, מחוות דיבור וספריית הפוזות כולן.
מגן שהיה יושב בפוזה היה דורש להיזכר בעשרים אתרי קריאה.

**וזה נמדד על הרשת המונפשת ולא על מספר הזווית.** `arm_gap` מחשב,
בכל פריים של מחצית מחזור הליכה ומחזור ריצה, את ההפרש בין הקו הפנימי
של הזרוע לקו החיצוני של הגוף באותו גובה. חיובי = הזרוע קוראת בנפרד
בצללית; שלילי = היא נבלעת. זווית בלי מדידה היא הצהרה, וכאן בדיוק
הצהרה כזו הייתה הבאג.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
if str(HERE.parent) not in sys.path:
    sys.path.insert(0, str(HERE.parent))

from rig import basemesh as BM                           # noqa: E402
from rig import controls as CT                           # noqa: E402
from rig import detail as DT                             # noqa: E402
from rig import dimorph as DM                            # noqa: E402
from rig import facestyle as FS                          # noqa: E402
from rig import identity                                 # noqa: E402
from rig import locomotion as LM                         # noqa: E402
from rig import pipeline as PL                           # noqa: E402

#: הזוג החדש. `MALE` הוא השם בקוד; `boaz`/`tamar` הם מפתחות ב-`CAST`.
MALE_CHAR = "boaz"
FEMALE_CHAR = "tamar"
PAIR = (MALE_CHAR, FEMALE_CHAR)

#: הגבהים שנדרשו במפורש, ביחד עם הסובלנות שבה הם נבדקים.
WANT_HEIGHT = {MALE_CHAR: 1.85, FEMALE_CHAR: 1.65}
HEIGHT_TOL = 0.005


# ================================================== השער המכוון

#: (מדד, מודד, מי גבוה, פער יחסי מינימלי, תיאור).
#:
#: `src`: "d" = `dimorph.measure` (הגוף), "f" = `facestyle.measure`
#: (הראש). `hi`: "m" = הגבר אמור להיות הגבוה, "f" = האישה.
#:
#: הפערים אינם אחידים, וזה מכוון: `shoulder_hip` הוא ציר הדימורפיזם
#: המרכזי ולכן נדרש בו פער של 80%, ואילו `brow_y_rel` הוא גובה גבה
#: בתוך ראש - תזוזה של 15% שם היא הבעה שלמה.
DIMORPHIC = (
    ("shoulder_hip", "d", "m", 0.80, "יחס כתף:אגן - צללית V מול אגן רחב"),
    ("whr", "d", "m", 0.80, "יחס מותן:אגן - גו ישר מול מותן מוצרת"),
    ("upper_volume_share", "d", "m", 0.30,
     "חלק הנפח בפלג הגוף העליון"),
    # **TASK 16: `shoulder_squareness` יצא מכאן.** הוא היה 1.254 מול
    # 1.000, כלומר הניגוד נשען על **פינה בחתך הכתף** - וזו בדיוק
    # הזוויתיות שנאסרה ב-06/10. אחרי שהיא אופסה בשני הפרופילים הוא
    # מודד 1.000 מול 1.000, ושער שתוצאתו קבועה אינו שער.
    # במקומו `skull_wd` - יחס רוחב:עומק בגולגולת. זו **מורפולוגיה
    # ולא צורת חתך**: ראש רחב ושטוח מול ראש צר ועמוק, ושני הראשים
    # יכולים להיות אליפסואידים מושלמים. נמדד 1.661 מול 1.013,
    # כלומר פער של 39% - יותר מכפול מהסף.
    # הסף 0.20 ולא 0.30: הערך שנמדד לפני TASK 16 (1.661 מול 1.013)
    # נבע ברובו מ-`skull_square`, שמרחיב את החתך בלי להעמיק אותו -
    # כלומר הפער ההיסטורי היה **זוויתיות במדים של מורפולוגיה**.
    # בלי האקספוננט הפער האמיתי בין שתי אליפסות הוא 20-28%, וזה
    # נראה בעין בפרופיל ובשלושה-רבעים.
    ("skull_wd", "f", "m", 0.20,
     "יחס רוחב:עומק בגולגולת - רחב ושטוח מול צר ועמוק"),
    ("width_over_depth", "d", "m", 0.20, "רוחב חלקי עומק בגו"),
    ("gonion_w", "d", "m", 0.50, "רוחב זווית הלסת"),
    # **TASK 16: `jaw_taper` יצא, וזה לא כיול ספים לתוצאה.**
    # הוא נגזר כמעט כולו מ-`jaw_under` (חיתוך תחתית הראש), ו-
    # `jaw_under` עבר ל-`SHARED` עם תקרה של 0.80 בשתי הדמויות.
    # כלומר למדד הזה **אין יותר חצי ממרחב הטווח שלו**, והוא מודד
    # 0.876 מול 0.916 - פער של 4.6% שאף סף סביר לא יבחין בו.
    # זה בדיוק הלקח שכתוב ב-`cast14`: מדד שאינו יכול להשתנות
    # בחצי מרחב העיצוב אינו מודד אותו, ואז מורידים את **המדד**
    # ולא את הסף. במקומו `side_bulge` - קמירות צלע הראש, שהיא
    # רציפה בשני הכיוונים וגם מודדת ישירות את "בלי מרובעים
    # בלחיים": לוח שטוח מודד קרוב לאפס, לחי עגולה מודדת גבוה.
    # **`crown_width` - רוחב הקודקוד.** שני מועמדים נפסלו כאן לפניו,
    # ושניהם מאותה סיבה בדיוק, ושווה לזכור אותה: `jaw_taper` ו-
    # `side_bulge` **שניהם נמדדים בטווח שכולל את תחתית הראש**, ולכן
    # שניהם נגררים אחרי `jaw_under` - שעבר ל-`SHARED` עם תקרה
    # משותפת. מדד שתלוי בפרמטר שהוחרג מהניגוד אינו יכול למדוד ניגוד,
    # ולא משנה איזה סף ייבחר לו. `side_bulge` אף התהפך בכיוון
    # (0.1131 לבועז מול 0.0975 לתמר) ברגע ש-`jaw_under` של תמר עלה
    # ל-0.72 - כלומר הוא היה מודד את החיתוך ולא את הלחי.
    #
    # `crown_width` נמדד ב-0.09R מה**קודקוד**, כלומר בקצה ההפוך של
    # הראש, ולכן הוא בלתי תלוי בחיתוך הלסת לגמרי. נמדד 0.3505 לבועז
    # מול 0.5127 לתמר - פער של 31.6%, והוא הניגוד הצורני הנכון:
    # ראש שרחב בלסת ומתכנס בקודקוד מול ראש שרחב בקודקוד.
    # **06/10 - הסף ירד מ-0.25 ל-0.18, וזה עדכון מודד ולא ויתור.**
    # הסף 0.25 נקבע כשקודקוד הראש היה פאה בעלת קצה: הקוטב של
    # `sphere` נבנה עד אז מ-seg קודקודים כפולים באותה נקודה, ולכן
    # הרוחב ב-0.09R מהקודקוד נמדד על מדרגה. מרגע שהקוטב הוא קודקוד
    # אחד והרשת מוצמדת למשטח Catmull-Clark הגבולי (ראה `organic`),
    # הקודקוד מתעגל - וזה **מה שהתבקש** ("בלי חתכים ישרים וחדים
    # בגיאומטריית הראש").
    # הפער שנמדד אחרי: בועז 0.3519 מול תמר 0.4395, כלומר תמר רחבה
    # בקודקוד ב-**23%**. נמדד שהוא עקבי בכל עומק מדידה (0.186 ב-
    # 0.09R, 0.169 ב-0.15R, 0.155 ב-0.22R), ולכן זה הפער האמיתי
    # של הצורה ולא ארטיפקט של נקודת הדגימה - העמקת המדידה בדוקה
    # ואינה מחזירה אותו. סף שדורש 0.25 על גיאומטריה עגולה דורש
    # בפועל להחזיר את הקצה, וזו בדיוק ההנחיה שאסרה.
    ("crown_width", "f", "f", 0.18,
     "רוחב הקודקוד - מתכנס למעלה מול רחב למעלה"),
    ("chin_width", "f", "m", 0.55, "רוחב תחתית הראש"),
    ("brow_y_rel", "f", "f", 0.12,
     "גובה הגבה בראש - נמוכה מול מורמת"),
    ("eye_rel", "f", "f", 0.25, "גודל העין ביחידות ראש"),
    # **TASK 16: `skull_square` ו-`cloth_square` יצאו מכאן**, מאותה
    # סיבה בדיוק: שניהם מודדים זוויתיות, והיא אפס בשתי הדמויות
    # מעכשיו. במקומם שני מדדים שמבדילים **בתוך** שפה עגולה:
    ("hair_len_rel", "f", "f", 0.25,
     "אורך השיער ביחידות ראש - גושים קצרים מול רעמה"),
    ("mouth_arc_rel", "f", "f", 0.40,
     "קמרון הפה - קימור מאופק מול חיוך מלא"),
)

#: עובדה אנטומית על דמות אחת, ולא השוואה. (דמות, מדד, מודד, יחס,
#: כיוון, תיאור). כיוון ">" = חייב להיות גדול מהיחס.
ABSOLUTE = (
    (MALE_CHAR, "shoulder_hip", "d", 1.45, ">",
     "כתפי הגבר רחבות מהאגן - V קלאסי"),
    (FEMALE_CHAR, "shoulder_hip", "d", 0.95, "<",
     "כתפי האישה **צרות** מהאגן"),
    (MALE_CHAR, "whr", "d", 1.00, ">",
     "גו הגבר אינו מתרחב בירכיים: המותן רחבה מהאגן"),
    (FEMALE_CHAR, "whr", "d", 0.75, "<",
     "מותן האישה צרה בהרבה מהאגן"),
    # המותן צרה גם מהכתף, ולא רק מהאגן. בלי שני הצדדים "מותן מוצרת"
    # מתקיים גם בגוף שכולו מתרחב כלפי מטה.
    (FEMALE_CHAR, "waist_over_shoulder", "x", 0.78, "<",
     "מותן האישה צרה גם מהכתף - שעון חול ולא משולש"),
    (MALE_CHAR, "arm_bulge", "d", 0.02, ">",
     "שריר זרוע נראה בצללית הגבר"),
    (FEMALE_CHAR, "arm_peaks", "d", 0.5, "<",
     "זרוע האישה מתכנסת בהדרגה, בלי חריגות"),
)

#: צירי הניגוד שבהם **אסור** לשני הארכיטיפים לשבת באותו צד של
#: הניטרלי. (שדה, מודל): "d" = `Dimorph`, "f" = `FaceStyle`.
#: `fem_side` הוא הצד שהארכיטיפ הנשי אמור להיות בו: +1 מעל הניטרלי.
OPPOSED = (
    # --- פלג הגוף
    ("hip_w", "d", +1),
    ("hip_d", "d", +1),
    ("seat_lo", "d", +1),
    ("seat_mid", "d", +1),
    ("waist_w", "d", -1),
    ("waist_d", "d", -1),
    ("waist_t", "d", +1),
    ("chest_w", "d", -1),
    ("shoulder_w", "d", -1),
    ("shoulder_d", "d", -1),
    ("neck_w", "d", -1),
    ("neck_d", "d", -1),
    # --- גפיים ולסת
    ("arm_base", "d", -1),
    ("arm_taper", "d", -1),
    ("leg_taper", "d", -1),
    ("jaw_sharp", "d", -1),
    ("chin_sharp", "d", -1),
    # --- ראש ופנים
    ("narrow_amt", "f", +1),
    ("narrow_knee", "f", +1),
    # `taper_top` הוא ציר דו-כיווני אמיתי ולא תכונה של צד אחד:
    # חיובי = רחב בקודקוד וצר בלסת (סגלגל נשי), שלילי = רחב בלסת
    # וצר בקודקוד (טרפז הפוך גברי). בכתיבה הראשונה כאן הוא נרשם
    # כחד-כיווני "של האישה", וזו הייתה טעות שהמדידה חשפה.
    ("taper_top", "f", +1),
    ("back_flat", "f", +1),
    # **TASK 16: `jaw_under` יצא מכאן, וזו סתירה שהמדידה חשפה.**
    # הוא היה ציר מנוגד (ניטרלי 1.0, הגבר **מעל** = חיתוך חד יותר),
    # ובמקביל `SHARED` דורש ממנו `<= 0.80` בשתי הדמויות - "בלי
    # חתכים ישרים וחדים בגיאומטריית הראש". שני הכללים יחד מחייבים
    # את הגבר להיות בעת ובעונה אחת מעל 1.0 ומתחת ל-0.80. הדרישה
    # המשותפת מנצחת, והניגוד בלסת נמדד ב-`gonion_w` וב-`chin_width`
    # שב-`DIMORPHIC` - שם הוא נמדד על הרשת ולא על הפרמטר.
    # **TASK 16: `eye`, `socket`, `socket_r` ו-`brow_ridge` יצאו
    # מכאן, וזו ההכרעה המרכזית של הסבב.** ציר מנוגד דורש שצד אחד
    # יהיה **מתחת** לניטרלי, ולכן הכלל הזה חייב את הגבר לעין קטנה
    # מהתקן (0.84), לארובה עמוקה (1.12) ולרכס גבות כבד (2.05) -
    # כלומר **השער עצמו אכף את המראה שהתלונה מתלוננת עליו**. ארבעתם
    # עברו ל-`SHARED` למטה: עיניים ענקיות, ארובה רדודה ורחבה ובלי
    # רכס גרמי הם מעכשיו דרישה על **שתי** הדמויות. הניגוד בגודל
    # העין נשמר ב-`DIMORPHIC` (`eye_rel`, פער 25%) - שם הוא נמדד
    # על הרשת ולא על הפרמטר, ושם הוא "כמה ענקית" ולא "גדולה מול
    # קטנה".
    ("nose_tip", "f", +1),
    ("brow_thick", "f", -1),
    ("brow_slant", "f", -1),
    ("brow_lower", "f", -1),
    ("mouth_arc", "f", +1),
    ("lip_thick", "f", +1),
    ("smile", "f", +1),
    # --- שיער
    ("hair_len_mul", "f", +1),
    ("hair_n_mul", "f", +1),
    ("hair_wob", "f", +1),
    ("hair_follow", "f", +1),
)

#: צירים **חד-כיווניים**, ולהם כלל אחר. (שדה, מודל, מי מחזיק אותו).
#:
#: לא כל שדה הוא ציר עם שני צדדים, ו**הכלל ה"מחמיר" של צדדים
#: מנוגדים הוא שגוי עליהם** - לא מקל מדי אלא פשוט לא נכון:
#: `bust` הוא נפח חזה קדמי, ו"מתחת לניטרלי" פירושו חזה **קעור**;
#: `shoulder_square` הוא תוספת לאקספוננט החתך, ומתחת ל-0 הוא חתך
#: מכונס פנימה ולא "עגול יותר". דרישה שתכריח ערך שלילי שם הייתה
#: מייצרת גאומטריה פגומה כדי לעבור שער - כלומר שער שמזיק.
#:
#: הכלל כאן: הצד שמחזיק את התכונה חייב להיות **מחוץ** לניטרלי
#: בפער ממשי, והצד השני חייב להיות בניטרלי בדיוק. כלומר התכונה
#: קיימת בארכיטיפ אחד ואינה קיימת בשני - וזה בעצמו ניגוד.
ONE_SIDED = (
    ("bust", "d", "f"),
    ("seat_back", "d", "f"),
    ("chest_square", "d", "m"),
    ("biceps", "d", "m"),
    ("brachial", "d", "m"),
    # **TASK 16: חמישה צירים יצאו מכאן** - `shoulder_square`,
    # `skull_square`, `skull_box`, `crown_flat` ו-`limb_square`.
    # כולם "זוויתיות שהגבר מחזיק והאישה לא", והדרישה החדשה אוסרת
    # אותה **בשניהם**. כלל חד-כיווני על תכונה שאסורה בשני הצדדים
    # אינו מחמיר אלא **בלתי ניתן לקיום**: הוא מחייב את הגבר להיות
    # מרובע. הם עברו ל-`SHARED` כרצפה.
    #
    # `socket_merge` ו-`hair_coil` יצאו מאותה סיבה הפוכה: הם היו
    # "האישה מחזיקה והגבר בניטרלי", ומעכשיו **שניהם** מחזיקים -
    # ארובה רציפה היא סימן ההיכר של עיני דיסני, ותלתול הוא מה
    # שהופך רצועה שטוחה לגוש. גם הם ב-`SHARED`.
)

#: **TASK 16 · הרצפה המשותפת.** (שדה, מודל, כיוון, סף, תיאור).
#:
#: כאן יושבת שפת העיצוב שהיא **משותפת לשתי הדמויות** ולכן אינה
#: יכולה להיות ציר ניגוד. כיוון `"<="` = שני הערכים חייבים להיות
#: קטנים או שווים לסף; `">="` = גדולים או שווים.
#:
#: הרשימה הזאת היא התרגום המדויק של האיסורים מ-06/10: "בלי מרובעים
#: בלחיים, בקו הלסת או במצח", "בלי חתכים ישרים וחדים בגיאומטריית
#: הראש", "לא עיניים קטנות, שטוחות או מרוחקות", "לא שיער מרצועות
#: קשיחות", "לא צוואר גלילי". כל אחד מהם הוא שורה כאן.
SHARED = (
    # --- בלי קופסה. ארבעת מקורות הזוויתיות בראש ובגפיים.
    ("skull_square", "f", "<=", 0.02, "אין אקספוננט קופסה בחתך הגולגולת"),
    ("skull_box", "f", "<=", 0.02, "אין אקספוננט קופסה בפרופיל הראש"),
    ("crown_flat", "f", "<=", 0.02, "הקודקוד אינו משוטח"),
    ("limb_square", "f", "<=", 0.02, "כפות היד והרגל אינן מרובעות"),
    ("shoulder_square", "d", "<=", 0.02, "חתך הכתף הוא אליפסה, בלי פינה"),
    # --- חיתוך הלסת: "בלי חתכים ישרים וחדים". 1.0 הוא החיתוך המלא
    # שהיה; מעליו הוא מדף. 0.80 משאיר לסת מוגדרת בלי מדרגה.
    ("jaw_under", "f", "<=", 0.80, "תחתית הראש אינה נחתכת בזווית"),
    # --- עיניים ענקיות, ארובה רדודה ורחבה, רצועה רציפה, מקורבות.
    ("eye", "f", ">=", 1.20, "גלגל עין ענקי (מעל 1.2 מהתקן)"),
    ("socket", "f", "<=", 0.85, "ארובה רדודה - בלי טבעת צל סביב העין"),
    ("socket_r", "f", ">=", 1.25, "ארובה רחבה, שהעין יושבת בה ולא עליה"),
    ("socket_merge", "f", ">=", 0.35, "רצועת ארובה רציפה (עיני דיסני)"),
    ("eye_in", "f", ">=", 0.10, "העיניים מקורבות אל ציר האמצע"),
    # "בלי עיניים שנראות מודבקות": גלגל עין ענקי שחשוף במלוא ההיקף
    # נקרא ככדור שהודבק על הפנים. העפעף שחותך את קצהו העליון הוא מה
    # שהופך אותו לעין. נמדד ברנדור התקריב, לא בחישוב.
    ("lid_cover", "f", "<=", 0.75, "העפעף יורד על גלגל העין"),
    # --- בלי רכס גרמי כבד. מעל 1.2 הקוד מוריד את הגבה על העין.
    ("brow_ridge", "f", "<=", 1.00, "אין רכס גבות גרמי שמצל על העין"),
    # --- אף קטן ועדין, ופה מעוגל.
    ("nose_len", "f", "<=", 0.80, "אף קומפקטי - בלט קטן מהתקן"),
    ("nose_w", "f", "<=", 0.92, "אף צר"),
    ("mouth_arc", "f", ">=", 0.80, "פה מעוגל, לא קו ישר"),
    # --- לחיים רכות: מסה מעל התקן ושקע מתחת לו.
    ("cheek", "f", ">=", 1.15, "נפח לחי מעל התקן"),
    ("cheek_hollow", "f", "<=", 0.50, "בלי שקע לחיים שקורא כפנים רזות"),
    # --- שיער בנפחים ולא בסיבים.
    ("hair_clump", "f", "<=", 0.60, "מעט אשכולות - כלומר גושים גדולים"),
    ("hair_thick", "f", ">=", 1.15, "גוש עבה"),
    ("hair_pull", "f", ">=", 1.20, "הגוש אסוף, ולכן צללית רציפה"),
    ("hair_coil", "f", ">=", 0.10, "קימור בגוש, ולא רצועה שטוחה"),
    ("hair_wob", "f", ">=", 0.60, "שיער בגל רך, לא נוקשה"),
    # --- צוואר שאינו גליל.
    ("trap_rise", "d", ">=", 0.05, "מדף טרפזיוס ממלא את זווית הכתף"),
    ("neck_flare", "d", ">=", 0.10, "הצוואר מתרחב בבסיס הגולגולת"),
)


# ==================================================== מרווח הזרוע

#: כמה פריימים נדגמים מכל מחזור הליכה/ריצה. 9 ולא 3: `arm_fwd` הוא
#: קוסינוס, והמרווח הקטן ביותר אינו בקצה המחזור אלא במעבר - שם
#: הזרוע צמודה לגוף **וגם** הגו מסובב (`spine_twist`).
GAIT_SAMPLES = 9

#: חלון הגובה שבו זרוע וגוף נחשבים "באותה רמה", ביחידות גובה הדמות.
#: 0.018 הוא כ-3 ס"מ לדמות של 1.70 - צר דיו שלא לערבב את הכתף עם
#: המותן, ורחב דיו שתמיד יימצאו קודקודים משני הצדדים.
BAND = 0.018

#: הטווח האנכי שנמדד, כשבריר מגובה הדמות: מתחת לכתף ועד מתחת לאגן.
#: מעל זה יושבת הכתף עצמה (שם הזרוע **כן** נוגעת, וזו אנטומיה ולא
#: חדירה), ומתחת לזה יש כבר כף יד וירך בלי גו.
GAP_LO, GAP_HI = 0.40, 0.76

#: המרווח המינימלי הנדרש, כשבריר מגובה הדמות. 0.004 הוא כ-7 מ"מ
#: לדמות של 1.70 - פחות מזה ושני הקווים מתמזגים בצללית של שוט בינוני
#: גם כשהם לא נחתכים גאומטרית.
MIN_GAP = 0.004


#: חצי-רוחב החלון הזוויתי שבו נמדד רדיוס הגוף, ברדיאנים. 0.26 הוא
#: כ-15 מעלות - צר דיו שלא לערבב את הצד הקדמי של החתך עם הצידי
#: (ושם ההפרש הוא כל ההבדל בין "זרוע לפני החזה" ל"זרוע בתוך החזה"),
#: ורחב דיו שתמיד יימצאו קודקודי גוף בפנים.
ANG = 0.26


def _radial_gap(v: np.ndarray, band: np.ndarray) -> float:
    """המרווח של קודקוד בודד מפני השטח של חתך גוף, בציר הרדיאלי.

    חיובי = הקודקוד **מחוץ** לגוף; שלילי = בתוכו, כלומר חדירה.

    **וזה התיקון החשוב כאן, אחרי שהמודד הראשון דיווח שקר.** הגרסה
    הראשונה מדדה הפרדה ב-X בלבד, בנימוק ש"נבלעת בגוף" היא בעיית
    צללית. היא דיווחה חדירה של 3.6 ס"מ לדמות הגברית בריצה - ובדיקה
    של הפריים הראתה שהזרוע שם **לפני** החזה ולא בתוכו, וזו בדיוק
    התנועה הנכונה של ריצה. מודד שפוסל אנימציה תקינה היה מכריח כיול
    שמקלקל את הריצה כדי "לתקן" אותה.
    ההפרדה הנכונה: הזרוע נבלעת כשהיא **בתוך** נפח הגוף, ולכן המדידה
    היא רדיאלית סביב מרכז החתך - רדיוס הזרוע מול רדיוס הגוף באותה
    זווית בדיוק. בזווית הקדמית רדיוס הגוף הוא עומק החזה, ולכן זרוע
    שמתנדנדת קדימה מקבלת מרווח חיובי כמו שצריך.
    """
    c = band[:, (0, 2)].mean(axis=0)
    rel = band[:, (0, 2)] - c
    ang = np.arctan2(rel[:, 1], rel[:, 0])
    rad = np.hypot(rel[:, 0], rel[:, 1])
    dv = np.array([v[0], v[2]]) - c
    av = float(np.arctan2(dv[1], dv[0]))
    rv = float(np.hypot(dv[0], dv[1]))
    da = np.abs((ang - av + np.pi) % (2.0 * np.pi) - np.pi)
    sel = rad[da <= ANG]
    if sel.size == 0:
        return float("inf")
    return rv - float(np.max(sel))


def _body_vs_arm(pos: np.ndarray, groups, height: float) -> float:
    """המרווח הקטן ביותר בין הזרוע לנפח הגוף, בכל הקודקודים.

    מוחזר **ביחידות גובה הדמות**, כדי שהשער יהיה זהה לדמות של 1.85
    ולדמות של 1.65 - אחרת 7 מ"מ הם מרווח נדיב באחת וצמוד באחרת.

    הגו והרגליים נמדדים **כל אחד בנפרד**, ולא כענן נקודות אחד: הם
    שלושה גלילים נפרדים, ומרכז משותף היה מוציא מרכז חתך שאינו בתוך
    אף אחד מהם - ואז הרדיוס אינו אומר כלום.
    """
    span = {g[0]: (g[1], g[2]) for g in groups}
    parts = []
    for nm in ("torso", "leg_L", "leg_R"):
        if nm in span:
            a, b = span[nm]
            parts.append(pos[a:b])
    if not parts:
        return float("nan")
    worst = float("inf")
    for side in ("L", "R"):
        nm = f"arm_{side}"
        if nm not in span:
            continue
        a, b = span[nm]
        arm = pos[a:b]
        lo, hi = GAP_LO * height, GAP_HI * height
        sel = arm[(arm[:, 1] >= lo) & (arm[:, 1] <= hi)]
        for v in sel:
            for body in parts:
                band = body[np.abs(body[:, 1] - v[1]) <= BAND * height]
                if band.shape[0] < 4:
                    continue
                worst = min(worst, _radial_gap(v, band))
    return worst / float(height) if np.isfinite(worst) else float("nan")


def arm_gap(name: str, quality: str = "fast") -> dict:
    """המרווח זרוע-גוף בעמידה, בהליכה ובריצה. ביחידות גובה הדמות."""
    sh = dict(PL.CAST[name]["shape_override"])
    skel = PL.cast_skeleton(name)
    mb, _meta = BM.build(skel, sh, quality=quality)
    attrs = BM.to_arrays(mb, skel)
    groups = list(mb.groups)
    out: dict[str, float] = {}

    def gap_of(q):
        pos = identity.skin(skel, attrs, q)
        return _body_vs_arm(pos, groups, skel.height)

    # 1. עמידה: פוזת ברירת המחדל, בלי שום בקרה.
    out["rest"] = gap_of(CT.evaluate(skel, {}))
    # 2. ספריית הפוזות - שם יושבות הפוזות של דיבור ועמידה בסצנה.
    lib = CT.pose_library(skel)
    worst_pose, worst_name = float("inf"), ""
    for pname, (ctl, ik) in lib.items():
        g = gap_of(CT.evaluate(skel, ctl, ik))
        if np.isfinite(g) and g < worst_pose:
            worst_pose, worst_name = g, pname
    out["pose_min"] = worst_pose
    out["pose_worst"] = worst_name
    # 3. הליכה וריצה. **מודל התנועה האמיתי**, לא זווית משוחזרת.
    for gait in ("walk", "run"):
        mv = LM.Move(skel, [(gait, 2.0)], fps=24)
        # **מחזור שלם בדיוק, ולא "שתי שניות".** `cad` הוא מחזורים
        # לשנייה, ולכן משך המחזור הוא היפוכו. דגימה על חלון שרירותי
        # יכולה לפספס את הפריים שבו הזרוע הקרובה ביותר לגוף - וזה
        # הפריים היחיד שחשוב כאן.
        cyc = 1.0 / max(1e-6, float(mv.cad[0]))
        t0, t1 = 0.30, 0.30 + cyc
        worst = float("inf")
        for i in range(GAIT_SAMPLES):
            t = t0 + (t1 - t0) * i / float(GAIT_SAMPLES - 1)
            # `pose` ולא `actor`: `actor` מחזיר (בקרות, IK) - שתי
            # הזמנות - ואילו `pose` מחזיר את סיבובי העצמות שבאמת
            # יוצאים מהן, כולל פיץ' המגע שנפתר בשני מעברים. מדידה
            # על ההזמנה אינה מדידה על מה שנראה על המסך.
            _ctl, q = mv.pose(t)
            g = gap_of(q)
            if np.isfinite(g):
                worst = min(worst, g)
        out[gait] = worst
    vals = [v for k, v in out.items()
            if isinstance(v, float) and np.isfinite(v)]
    out["min"] = min(vals) if vals else float("nan")
    out["arm_clear"] = float(skel.arm_clear)
    return {k: (round(v, 5) if isinstance(v, float) else v)
            for k, v in out.items()}


# ======================================================== המדידה


def build_one(name: str, quality: str = "fast") -> dict:
    """בונה דמות מ-`CAST` ומודדת אותה בשני המודדים.

    **עובר דרך `pipeline.cast_skeleton`** ולא בונה שלד מקומי, כדי
    שמה שנמדד יהיה מה שייבנה לסרטון - כולל `arm_clear`. זה הלקח של
    `cast14.build_one`, והוא נכון כאן פי שניים: שער שבונה שלד בלי
    המרווח היה מודד זרוע שלא קיימת.
    """
    c = PL.CAST[name]
    sh = dict(c["shape_override"])
    skel = PL.cast_skeleton(name)
    mb, _meta = BM.build(skel, sh, quality=quality)
    d = DM.measure(mb, skel)
    P = {b.name: np.asarray(b.rest, float) for b in skel.bones}
    H = DT.Head(P, skel.height / 1.70, sh)
    f = FS.measure(mb, H)
    # מדד נגזר אחד, שאינו קיים באף אחד מהמודדים: המותן ביחס לכתף.
    # "מותן מוצרת" נמדדת מול **שני** הקווים שסוגרים אותה, ו-`whr`
    # מודד רק את התחתון.
    x = {"waist_over_shoulder": (float(d["waist_w"]) / float(d["shoulder_w"])
                                 if float(d["shoulder_w"]) > 1e-9
                                 else float("nan"))}
    return {"name": name, "height": float(c["height"]),
            "dimorph": DM.get(sh.get("dimorph")).key,
            "face": FS.get(sh.get("face")).key,
            "arm_clear": float(skel.arm_clear),
            "d": d, "f": f, "x": x}


def _val(rec: dict, key: str, src: str) -> float:
    return float(rec[src][key])


def directed(male: dict, female: dict) -> dict:
    """השער המכוון: כיוון **וגם** פער, לכל מדד ב-`DIMORPHIC`."""
    rows, bad = [], []
    for key, src, hi, need, desc in DIMORPHIC:
        m = _val(male, key, src)
        f = _val(female, key, src)
        top, bot = (m, f) if hi == "m" else (f, m)
        ref = min(abs(top), abs(bot))
        gap = (abs(top - bot) / ref) if ref > 1e-9 else float("inf")
        ok = (top > bot) and (gap >= need)
        rows.append({"key": key, "desc": desc, "hi": hi,
                     "male": round(m, 4), "female": round(f, 4),
                     "gap": round(gap, 4) if np.isfinite(gap) else None,
                     "need": need, "ok": bool(ok)})
        if not ok:
            why = ("כיוון הפוך" if top <= bot
                   else f"פער {gap:.3f} < {need}")
            bad.append(f"{desc}: {why} (גבר {m:.4f}, אישה {f:.4f})")
    return {"rows": rows, "bad": bad, "ok": not bad,
            "n_ok": sum(1 for r in rows if r["ok"]), "n": len(rows)}


def absolutes(built: dict) -> dict:
    """השערים המוחלטים: עובדה אנטומית על כל דמות בנפרד."""
    rows, bad = [], []
    for who, key, src, ref, direction, desc in ABSOLUTE:
        v = _val(built[who], key, src)
        ok = (v > ref) if direction == ">" else (v < ref)
        rows.append({"who": who, "key": key, "value": round(v, 4),
                     "ref": ref, "dir": direction, "desc": desc,
                     "ok": bool(ok)})
        if not ok:
            bad.append(f"{desc}: {v:.4f} אינו {direction} {ref}")
    return {"rows": rows, "bad": bad, "ok": not bad}


def neutral_free() -> dict:
    """אכיפת "אסור ערכים ניטרליים" **על הדגמים**, לא על הרשת.

    שני תנאים, והשני הוא העיקר: לא רק ששני הארכיטיפים שונים
    מהניטרלי, אלא שהם בצדדים **מנוגדים** שלו.
    """
    md, fd = DM.MALE, DM.FEMALE
    mf, ff = FS.MALEF, FS.FEMALEF
    nd, nf = DM.NEUTRAL, FS.PLAIN
    rows, bad = [], []
    for field, model, fem_side in OPPOSED:
        if model == "d":
            a, b, n = (getattr(md, field), getattr(fd, field),
                       getattr(nd, field))
        else:
            a, b, n = (getattr(mf, field), getattr(ff, field),
                       getattr(nf, field))
        a, b, n = float(a), float(b), float(n)
        eq = (abs(a - n) < 1e-9) or (abs(b - n) < 1e-9)
        side_f = 1 if b > n else (-1 if b < n else 0)
        side_m = 1 if a > n else (-1 if a < n else 0)
        opposed = (side_m != 0 and side_f != 0 and side_m != side_f)
        ok = (not eq) and opposed and (side_f == fem_side)
        rows.append({"field": field, "model": model, "neutral": n,
                     "male": a, "female": b, "ok": bool(ok)})
        if not ok:
            if eq:
                why = "אחד הערכים שווה לניטרלי"
            elif not opposed:
                why = "שני הערכים באותו צד של הניטרלי"
            else:
                why = f"הצד של הארכיטיפ הנשי אינו {fem_side:+d}"
            bad.append(f"{model}.{field}: {why} "
                       f"(ניטרלי {n}, גבר {a}, אישה {b})")
    # --- הצירים החד-כיווניים
    for field, model, who in ONE_SIDED:
        if model == "d":
            a, b, n = (getattr(md, field), getattr(fd, field),
                       getattr(nd, field))
        else:
            a, b, n = (getattr(mf, field), getattr(ff, field),
                       getattr(nf, field))
        a, b, n = float(a), float(b), float(n)
        hold, zero = (a, b) if who == "m" else (b, a)
        ok = (abs(hold - n) > 1e-6) and (abs(zero - n) < 1e-9)
        rows.append({"field": field, "model": model, "neutral": n,
                     "male": a, "female": b, "one_sided": who,
                     "ok": bool(ok)})
        if not ok:
            why = ("הצד שמחזיק את התכונה שווה לניטרלי"
                   if abs(hold - n) <= 1e-6
                   else "הצד השני אינו בניטרלי, כלומר התכונה קיימת בשניהם")
            bad.append(f"{model}.{field}: {why} "
                       f"(ניטרלי {n}, גבר {a}, אישה {b})")
    return {"rows": rows, "bad": bad, "ok": not bad,
            "n_opposed": len(OPPOSED), "n_one_sided": len(ONE_SIDED)}


def shared_language() -> dict:
    """**TASK 16 · הרצפה המשותפת** (`SHARED`): שפת העיצוב שחייבת
    להתקיים ב**שתי** הדמויות.

    זה המשלים ההכרחי של `neutral_free`, ולא כפל שלו. `neutral_free`
    דורש **הפרדה**, ולכן הוא לבדו מרוצה מכל שתי דמויות שונות -
    כולל שתי דמויות מכניות וגושניות, כל עוד הן גושניות באופן שונה.
    וגרוע מזה: עד TASK 16 הוא **אכף** את הגושניות, כי "ציר מנוגד"
    על עין ועל רכס גבות חייב את הגבר לעין קטנה ולרכס כבד. שער
    שמייצר את הפגם שהתלונה מתלוננת עליו אינו שער רופף אלא שער
    הפוך, וזה הלקח העיקרי כאן.

    הבדיקה היא על ה**דגמים** (`FaceStyle`/`Dimorph`) ולא על הרשת,
    בדיוק כמו `neutral_free`: שם היא חדה - "האקספוננט הוא אפס" -
    בזמן שעל הרשת היא הייתה סף על מדד מקורב. ההוכחה שהדגם באמת
    מגיע לרשת יושבת ב-`disney.py`, שמודד את הגאומטריה הבנויה.
    """
    md, fd = DM.MALE, DM.FEMALE
    mf, ff = FS.MALEF, FS.FEMALEF
    rows, bad = [], []
    for field, model, op, ref, desc in SHARED:
        src = (md, fd) if model == "d" else (mf, ff)
        vals = {}
        for who, obj in zip(("boaz", "tamar"), src):
            v = float(getattr(obj, field))
            vals[who] = v
            ok = (v <= ref + 1e-9) if op == "<=" else (v >= ref - 1e-9)
            if not ok:
                bad.append(f"{who}.{field} = {v} (נדרש {op} {ref}) - {desc}")
        rows.append({"field": field, "model": model, "op": op, "ref": ref,
                     "desc": desc, **vals,
                     "ok": all((v <= ref + 1e-9) if op == "<="
                               else (v >= ref - 1e-9) for v in vals.values())})
    return {"rows": rows, "bad": bad, "ok": not bad, "n": len(SHARED)}


def heights(built: dict) -> dict:
    """הגבהים שנדרשו במפורש: 1.85 ו-1.65."""
    bad = []
    for who, want in WANT_HEIGHT.items():
        got = float(built[who]["height"])
        if abs(got - want) > HEIGHT_TOL:
            bad.append(f"{who}: גובה {got} במקום {want}")
    return {"want": WANT_HEIGHT, "bad": bad, "ok": not bad}


def clearance(quality: str = "fast") -> dict:
    """שער מרווח הזרוע, לשתי הדמויות, בעמידה ובתנועה."""
    rows, bad = {}, []
    for who in PAIR:
        g = arm_gap(who, quality=quality)
        rows[who] = g
        for scene in ("rest", "pose_min", "walk", "run"):
            v = g.get(scene)
            if not isinstance(v, float) or not np.isfinite(v):
                bad.append(f"{who}: לא נמדד מרווח ב-{scene}")
            elif v < MIN_GAP:
                bad.append(f"{who}: הזרוע נבלעת בגוף ב-{scene} "
                           f"(מרווח {v:.5f} < {MIN_GAP})")
    return {"rows": rows, "min_gap": MIN_GAP, "bad": bad, "ok": not bad}


def audit(quality: str = "fast") -> dict:
    built = {nm: build_one(nm, quality=quality) for nm in PAIR}
    out = {
        "pair": list(PAIR),
        "heights": heights(built),
        "neutral_free": neutral_free(),
        "shared": shared_language(),
        "directed": directed(built[MALE_CHAR], built[FEMALE_CHAR]),
        "absolutes": absolutes(built),
        "clearance": clearance(quality=quality),
        "_built": {nm: {"height": built[nm]["height"],
                        "dimorph": built[nm]["dimorph"],
                        "face": built[nm]["face"],
                        "arm_clear": built[nm]["arm_clear"]}
                   for nm in PAIR},
    }
    out["bad"] = (out["heights"]["bad"] + out["neutral_free"]["bad"]
                  + out["shared"]["bad"]
                  + out["directed"]["bad"] + out["absolutes"]["bad"]
                  + out["clearance"]["bad"])
    out["ok"] = not out["bad"]
    return out


def passed(rep: dict | None = None, quality: str = "fast") -> bool:
    return bool((rep or audit(quality=quality))["ok"])


def main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    quality = "full" if "--full" in argv else "fast"
    rep = audit(quality=quality)
    print("TASK 15 · שני ארכיטיפים מגדריים")
    for nm in PAIR:
        b = rep["_built"][nm]
        print(f"  {nm}: {b['height']} מ' · גוף {b['dimorph']} · "
              f"פנים {b['face']} · מרווח זרוע {b['arm_clear']}")
    d = rep["directed"]
    print(f"\nשער מכוון: {d['n_ok']}/{d['n']}")
    for r in d["rows"]:
        mark = "✓" if r["ok"] else "✗"
        print(f"  {mark} {r['desc']}: גבר {r['male']} · "
              f"אישה {r['female']} · פער {r['gap']} (נדרש {r['need']})")
    print("\nשערים מוחלטים:")
    for r in rep["absolutes"]["rows"]:
        print(f"  {'✓' if r['ok'] else '✗'} {r['desc']}: "
              f"{r['value']} {r['dir']} {r['ref']}")
    print(f"\nאיסור ערכים ניטרליים: "
          f"{'✓' if rep['neutral_free']['ok'] else '✗'} "
          f"({len(OPPOSED)} צירים מנוגדים + {len(ONE_SIDED)} חד-כיווניים)")
    sh = rep["shared"]
    n_ok = sum(1 for r in sh["rows"] if r["ok"])
    print(f"\nשפת העיצוב המשותפת (TASK 16): {n_ok}/{sh['n']}")
    for r in sh["rows"]:
        print(f"  {'✓' if r['ok'] else '✗'} {r['desc']}: "
              f"בועז {r['boaz']} · תמר {r['tamar']} "
              f"(נדרש {r['op']} {r['ref']})")
    print("\nמרווח זרוע-גוף (ביחידות גובה הדמות):")
    for nm, g in rep["clearance"]["rows"].items():
        print(f"  {nm}: עמידה {g['rest']} · פוזות {g['pose_min']} "
              f"({g['pose_worst']}) · הליכה {g['walk']} · ריצה {g['run']}"
              f" · מינימום {g['min']}")
    if rep["bad"]:
        print("\nנכשל:")
        for b in rep["bad"]:
            print("  ✗", b)
    else:
        print("\n✅ כל השערים עברו")
    return 0 if rep["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
