# -*- coding: utf-8 -*-
"""קול אמיתי: הגאים שנמדדים מהשמע, לא מחלונות זמן.

=== מה היה שבור, ומה בדיוק מתוקן כאן ===

עד TASK 05 ההגאים של `rig.speech` הושתלו לתוך **חלונות זמן** שהסצנה
הצהירה עליהם (`speech=((0.80, 2.00),)`). כלומר המשפט פוצל לפונמות לפי
הטקסט, ואורך כל פונמה נגזר מטבלה קבועה (`PH_DUR`) ונמתח לרוחב החלון.
שתי תוצאות, ושתיהן נראות בעין:

1. **הפה לא מסונכרן לשום דבר** - אין שמע, ולכן אין למה להסתנכרן. אם
   הדמות אמרה "לא, הכול בסדר" ב-2.1 שניות והחלון היה 1.2, הפה פשוט
   רץ מהר יותר. זה לא "קצת לא מדויק" - זה סנכרון לאובייקט שלא קיים.
2. **התנועות היו ניחוש.** בעברית לא כתובה אין ניקוד, ולכן
   `speech.phonemize` השלים תנועות מרשימה מחזורית (`_FILL`). המילה
   "בסדר" קיבלה תנועות לפי התור ולא לפי ההגייה.

התיקון כאן אינו "טבלה טובה יותר". הוא היפוך כיוון:

    הקול הוא המקור. הטקסט הוא רק רמז.

יש עכשיו קובץ שמע אמיתי (edge-tts, `he-IL-AvriNeural` גברי ו-
`he-IL-HilaNeural` נשי - אותם קולות שהפיקו את הסרטונים הקודמים).
ממנו נמדדים, פריים-פריים:

* **מעטפת אנרגיה** -> כמה הפה פתוח ברגע זה, ומתי הוא נעצר.
* **פורמנטים F1/F2** (LPC + Levinson-Durbin) -> *איזו תנועה נהגתה
  בפועל*. F1 הוא גובה הלסת, F2 הוא קדמיות הלשון ועיגול השפתיים -
  אלה בדיוק שני הצירים שהפה צריך. ולכן אין יותר צורך בניקוד: התנועה
  **נשמעת**, ולא משוחזרת מכלל.
* **ZCR ומרכז כובד ספקטרלי** -> חיכוך (ס/שׁ/ז) מול קוליות.
* **פרץ אחרי שקט קצר** -> עיצור פוצץ (פ/ב/ת/ד/כ/ג), כלומר הרגע שבו
  השפתיים חייבות להיות סגורות **לפני** שנשמע משהו.

=== מה *לא* נעשה, בכוונה ===

לא הוכנס מודל הסקה (wav2vec / whisper-alignment). הוא היה נותן יישור
פונמות מדויק יותר, אבל המכונה חנוקה בזיכרון (7.5GB), המודול הזה נקרא
בתוך רנדור של אלפי פריימים, וכל התלות כאן היא numpy בלבד. פורמנטים
הם מדידה פיזיקלית של אותו אות - לא קירוב של מודל.
"""
from __future__ import annotations

import json
import math
import subprocess
import sys
import wave
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

RIG_DIR = Path(__file__).resolve().parent
AUDIO_DIR = RIG_DIR.parent / "production" / "audio"
TOOL = RIG_DIR / "tts_tool.py"
#: edge_tts ו-av יושבים בפייתון של המערכת, לא ב-venv של הבוט.
TOOL_PYTHON = Path(r"C:\Program Files\Python313\python.exe")

RATE = 16000
WIN = 0.025           # 25 מילישניות - חלון הניתוח הסטנדרטי לדיבור
HOP = 0.010           # 10 מילישניות - פריים אחד לכל 10ms
LPC_ORDER = 18        # 2 + rate/1000, הכלל המקובל ל-16kHz


# ===================================================================== שמע

def read_wav(path: str | Path) -> tuple[np.ndarray, int]:
    """PCM 16 ביט -> float32 ב-[-1,1]. בלי ספריות חיצוניות."""
    with wave.open(str(path), "rb") as wf:
        rate = wf.getframerate()
        n = wf.getnframes()
        raw = wf.readframes(n)
        ch = wf.getnchannels()
    y = np.frombuffer(raw, dtype="<i2").astype(np.float32) / 32768.0
    if ch > 1:
        y = y.reshape(-1, ch).mean(axis=1)
    return y, rate


def _frames(y: np.ndarray, rate: int) -> tuple[np.ndarray, int, int]:
    """חיתוך לחלונות חופפים. מחזיר (מטריצה, אורך חלון, קפיצה)."""
    w = int(round(WIN * rate))
    h = int(round(HOP * rate))
    if len(y) < w:
        y = np.pad(y, (0, w - len(y)))
    n = 1 + (len(y) - w) // h
    idx = np.arange(w)[None, :] + h * np.arange(n)[:, None]
    return y[idx], w, h


# ------------------------------------------------------------- פורמנטים

def _levinson(r: np.ndarray, order: int) -> np.ndarray:
    """Levinson-Durbin: אוטוקורלציה -> מקדמי LPC.

    מימוש ידני ולא `scipy.signal`: זו לולאה של 18 צעדים על וקטור קצר,
    והיא רצה פעם אחת לכל חלון של 10ms. תלות נוספת כאן אינה יכולת.
    """
    a = np.zeros(order + 1)
    a[0] = 1.0
    e = r[0]
    if e <= 0:
        return a
    for i in range(1, order + 1):
        acc = r[i] + float(np.dot(a[1:i], r[i - 1:0:-1])) if i > 1 else r[i]
        k = -acc / e
        a[1:i + 1] = a[1:i + 1] + k * a[i - 1::-1][:i]
        e *= (1.0 - k * k)
        if e <= 1e-12:
            break
    return a


def _formants(frame: np.ndarray, rate: int) -> tuple[float, float]:
    """(F1, F2) בהרץ מחלון אחד. (0,0) כשאין מבנה פורמנטי."""
    x = frame * np.hamming(len(frame))
    x = np.append(x[0], x[1:] - 0.97 * x[:-1])          # pre-emphasis
    if float(np.abs(x).max()) < 1e-6:
        return 0.0, 0.0
    r = np.correlate(x, x, mode="full")[len(x) - 1:][:LPC_ORDER + 1]
    if r[0] <= 0:
        return 0.0, 0.0
    a = _levinson(r, LPC_ORDER)
    try:
        roots = np.roots(a)
    except (np.linalg.LinAlgError, ValueError):
        return 0.0, 0.0
    roots = roots[np.imag(roots) > 0.01]
    if roots.size == 0:
        return 0.0, 0.0
    freq = np.arctan2(np.imag(roots), np.real(roots)) * rate / (2 * math.pi)
    mag = np.abs(roots)
    bw = -0.5 * (rate / (2 * math.pi)) * np.log(np.clip(mag, 1e-9, 0.999999))
    # סינון: פורמנט אמיתי צר (רוחב פס קטן) ויושב בטווח הדיבור.
    keep = (freq > 90) & (freq < 5000) & (bw < 500)
    f = np.sort(freq[keep])
    if f.size == 0:
        return 0.0, 0.0
    f1 = float(f[0])
    f2 = float(f[1]) if f.size > 1 else 0.0
    return f1, f2


# =============================================================== מסלול

@dataclass
class Track:
    """ניתוח מלא של קובץ שמע אחד. כל מערך הוא פריים לכל 10ms."""
    path: str = ""
    text: str = ""
    voice: str = ""
    seconds: float = 0.0
    hop: float = HOP
    rms: np.ndarray = field(default_factory=lambda: np.zeros(0))
    f1: np.ndarray = field(default_factory=lambda: np.zeros(0))
    f2: np.ndarray = field(default_factory=lambda: np.zeros(0))
    zcr: np.ndarray = field(default_factory=lambda: np.zeros(0))
    centroid: np.ndarray = field(default_factory=lambda: np.zeros(0))
    voiced: np.ndarray = field(default_factory=lambda: np.zeros(0, bool))
    #: מעטפת **סונוריות** - לא עוצמה. ראה `analyze`: אנרגיה בתחום
    #: התנועות בלבד, מדוכאת בפריימים רועשים. זה המדד שגרעיני
    #: ההברות נמדדים עליו.
    sonor: np.ndarray = field(default_factory=lambda: np.zeros(0))
    bounds: list[dict] = field(default_factory=list)
    visemes: list[tuple[float, float, str]] = field(default_factory=list)

    # ---- דגימה בזמן

    def _i(self, t: float) -> int:
        if not len(self.rms):
            return 0
        return int(max(0, min(len(self.rms) - 1, round(t / self.hop))))

    def energy(self, t: float) -> float:
        """0..1 - כמה קול יש ברגע זה. זו מעטפת פתיחת הפה."""
        if not len(self.rms):
            return 0.0
        return float(self.rms[self._i(t)])

    def speaking(self, t: float) -> bool:
        if not len(self.voiced):
            return False
        return bool(self.voiced[self._i(t)])

    def viseme_at(self, t: float) -> tuple[str, float]:
        """(שם ויזמה, 0..1 עוצמה) ברגע t, מתוך הפילוח שנמדד."""
        for a, b, v in self.visemes:
            if a <= t < b:
                return v, self.energy(t)
        return "sil", 0.0

    def as_dict(self) -> dict:
        return {"path": self.path, "text": self.text, "voice": self.voice,
                "seconds": self.seconds, "frames": int(len(self.rms)),
                "speech_ratio": round(float(self.voiced.mean()), 4)
                if len(self.voiced) else 0.0,
                "visemes": len(self.visemes),
                "vowels": vowel_string(self)}


def analyze(path: str | Path, text: str = "", voice: str = "",
            bounds: list[dict] | None = None) -> Track:
    """קובץ WAV -> Track עם כל המדידות וסדרת הויזמות."""
    y, rate = read_wav(path)
    fr, w, h = _frames(y, rate)
    n = len(fr)

    rms = np.sqrt((fr ** 2).mean(axis=1) + 1e-12)
    peak = float(rms.max()) or 1.0
    rms_n = np.clip(rms / peak, 0.0, 1.0)

    sign = np.signbit(fr)
    zcr = (sign[:, 1:] != sign[:, :-1]).mean(axis=1)

    win = np.hamming(w)
    spec = np.abs(np.fft.rfft(fr * win, axis=1))
    freqs = np.fft.rfftfreq(w, 1.0 / rate)
    tot = spec.sum(axis=1) + 1e-12
    centroid = (spec * freqs[None, :]).sum(axis=1) / tot

    f1 = np.zeros(n)
    f2 = np.zeros(n)
    # סף VAD אדפטיבי: רצפת הרעש היא האחוזון ה-10, והדיבור הוא מה
    # שמעליה פי ארבע. סף קבוע נשבר בין קול גברי לנשי, שנמדדו כאן
    # בעוצמות שונות.
    floor = float(np.percentile(rms_n, 10))
    thr = max(0.06, floor * 4.0)
    voiced = rms_n > thr
    for i in range(n):
        if voiced[i]:
            f1[i], f2[i] = _formants(fr[i], rate)

    # --- מעטפת סונוריות (ולא עוצמה) לספירת הברות.
    #
    # עוצמה גולמית סופרת גם חיכוך: ב"מה קרה **שם**?" ל-/ש/ יש
    # אנרגיה גבוהה כמו לתנועה, ולכן הוא נראה כפסגה וסופר כהברה
    # נוספת. סונוריות היא אנרגיה **בתחום התנועות בלבד** (100-3000
    # הרץ, שם יושבים F1 ו-F2), מוכפלת בגורם קוליות שמדכא פריימים
    # עם חציית אפס גבוהה. לתנועה יש שם כמעט את כל האנרגיה; לחיכוך
    # יש שם מעט מאוד, והוא גם רועש.
    band = (freqs >= 100.0) & (freqs <= 3000.0)
    bnd = spec[:, band].sum(axis=1)
    vfac = np.clip(1.0 - (zcr - 0.10) / 0.25, 0.12, 1.0)
    son = bnd * vfac
    sp = float(son.max()) or 1.0
    son = np.clip(son / sp, 0.0, 1.0)

    tr = Track(path=str(path), text=text, voice=voice,
               seconds=round(len(y) / rate, 4), hop=HOP,
               rms=rms_n, f1=f1, f2=f2, zcr=zcr, centroid=centroid,
               voiced=voiced, sonor=son, bounds=list(bounds or []))
    tr.visemes = segment(tr)
    return tr


# =========================================================== סיווג ויזמה
#
# הקואורדינטות הן ה"משולש התנועתי" הקלאסי: F1 הוא גובה הלסת (נמוך =
# פה סגור), F2 הוא קדמיות/עיגול (גבוה = לשון קדמית ושפתיים פרושות,
# נמוך = שפתיים מעוגלות). הערכים כאן הם מרכזי התנועות בעברית, והם
# מנורמלים לפי הקול עצמו - קול נשי יושב גבוה יותר בשני הצירים, וסף
# מוחלט היה מסווג כל /a/ נשי כ-/e/.

_VOWEL_HZ = {              # (F1, F2) טיפוסי, בקול גברי
    "a": (730, 1200),
    "e": (530, 1850),
    "i": (300, 2300),
    "o": (480, 900),
    "u": (330, 800),
}


def _vowel(f1: float, f2: float, scale: float) -> str:
    """התנועה הקרובה ביותר במישור הפורמנטים, אחרי נרמול לקול."""
    if f1 <= 0:
        return "a"
    best, bd = "a", 1e18
    lf1, lf2 = math.log(max(f1, 1.0)), math.log(max(f2, 1.0))
    for name, (c1, c2) in _VOWEL_HZ.items():
        d1 = lf1 - math.log(c1 * scale)
        d2 = lf2 - math.log(c2 * scale) if f2 > 0 else 0.0
        # F2 מקבל משקל גדול יותר: הוא מה שמבדיל עיגול שפתיים מפרישה,
        # וזה ההבדל שנראה בעין. F1 מבדיל רק את מידת הפתיחה, וממילא
        # פתיחת הלסת נלקחת מהאנרגיה.
        d = d1 * d1 + 1.6 * d2 * d2
        if d < bd:
            best, bd = name, d
    return best


def _voice_scale(tr: Track) -> float:
    """כמה הקול הזה גבוה ביחס לקול גברי ממוצע.

    זו הסיבה שאותו קוד עובד על אבري ועל הילה בלי שני ענפים: הקנה מידה
    נמדד מהחציון של F1 בקטעי הדיבור, ולא מוצהר לפי מין הדובר.
    """
    f = tr.f1[tr.voiced & (tr.f1 > 0)]
    if f.size < 5:
        return 1.0
    med = float(np.median(f))
    return float(np.clip(med / 520.0, 0.80, 1.45))


# סדר העדיפות בסיווג **אינו** שרירותי: מה שנמדד ישירות קודם למה
# שנגזר. שקט הוא עובדה, חיכוך הוא מדידה ספקטרלית, ורק מי שלא נפל
# לשניהם מסווג כתנועה לפי הפורמנטים.
_FRIC_ZCR = 0.22          # חציית אפס גבוהה = רעש רחב-פס
_FRIC_CENT = 3000.0       # מרכז כובד גבוה = אנרגיה בתדרים הגבוהים


def classify(tr: Track, i: int, scale: float) -> str:
    if not tr.voiced[i]:
        return "sil"
    if tr.zcr[i] > _FRIC_ZCR and tr.centroid[i] > _FRIC_CENT:
        # שורק (ס/צ/שׁ) מול חיכוך רך (פ'/ו/ה): מרכז כובד גבוה מאוד
        # הוא /s/, והוא דורש שיניים קרובות ושפתיים פרושות.
        return "s" if tr.centroid[i] > 4200 else "f"
    # עיצור אפי / סגירת שפתיים: אנרגיה שיושבת כמעט כולה בבס, בלי רעש.
    # **הסף כאן היה 0.14 והוא היה גבוה מדי** - נמדד: תנועה סופית של
    # מילה יורדת מתחת לזה באופן טבעי, ולכן כל סוף מילה סווג כסגירת
    # שפתיים ו"זה בסדר, אני רגילה" החזיר שלוש הברות במקום תשע. המדד
    # שמבדיל באמת הוא מרכז הכובד עם ZCR נמוך, לא העוצמה.
    if tr.centroid[i] < 700 and tr.zcr[i] < 0.10 and tr.rms[i] < 0.30:
        return "m"
    return _vowel(float(tr.f1[i]), float(tr.f2[i]), scale)


_MIN_RUN = 3              # 30ms - מתחת לזה זה ריצוד ולא הגה


def segment(tr: Track) -> list[tuple[float, float, str]]:
    """סדרת (התחלה, סוף, ויזמה) מהשמע, אחרי החלקה והסרת ריצוד.

    **ההחלקה היא חלק מהנכונות ולא קוסמטיקה.** סיווג פר-חלון מתחלף
    כמה פעמים ב-50 מילישניות, ופה שמתחלף שלוש פעמים ברבע השנייה
    נראה כמו רעד ולא כמו דיבור. חציון על חמישה חלונות, ואז מיזוג
    מקטעים קצרים מ-30ms לשכן.
    """
    n = len(tr.rms)
    if n == 0:
        return []
    scale = _voice_scale(tr)
    raw = [classify(tr, i, scale) for i in range(n)]

    # חציון מצבי (mode) על חלון 5 - החלקה שמתאימה לערכים קטגוריים.
    sm = list(raw)
    for i in range(n):
        lo, hi = max(0, i - 2), min(n, i + 3)
        seg = raw[lo:hi]
        sm[i] = max(set(seg), key=seg.count)

    runs: list[list] = []
    for i, v in enumerate(sm):
        if runs and runs[-1][2] == v:
            runs[-1][1] = i + 1
        else:
            runs.append([i, i + 1, v])

    # מקטע קצר מדי נבלע בשכן הארוך יותר. שקט קצר **אינו** נבלע אם
    # הוא פרץ לפני עיצור פוצץ - שם הסגירה היא מה שנראה בעין.
    out: list[list] = []
    for r in runs:
        if r[1] - r[0] < _MIN_RUN and out and r[2] != "sil":
            out[-1][1] = r[1]
        elif out and out[-1][2] == r[2]:
            out[-1][1] = r[1]
        else:
            out.append(r)

    return [(round(a * HOP, 4), round(b * HOP, 4), v) for a, b, v in out]


# ======================================================= גרעיני הברה
#
# **מה היה שבור כאן, ולמה זה היה שבור דווקא בקול הנשי.**
#
# הגרסה הקודמת ספרה הברות לפי **אשכולות ויזמות**: רצף של מקטעי
# תנועה שהופרד בעיצור נחשב הברה אחת. זה נשמע הגיוני ונכשל בשיטה,
# ובפער שגדל דווקא בקול גבוה:
#
# * עיצור קולי בתוך מילה (ל, מ, נ, ר, י, ו) אינו מסווג כעיצור
#   אלא כתנועה - יש לו מבנה פורמנטי - ולכן "אני רגילה" נשאר
#   **אשכול אחד רציף**, כלומר הברה אחת במקום חמש.
# * וההפך: הסף של סגירת שפתיים (`classify` -> "m") נחתך על אנרגיה,
#   והקול הנשי יושב בעוצמה נמוכה יותר ועם מרכז כובד גבוה יותר.
#   לכן בקול הנשי כל סוף מילה נבלע, ו"זה בסדר, אני רגילה" החזיר
#   **שלוש** הברות במקום תשע, מול חמש בקול הגברי. ההטיה הזו היא
#   מה שהמשתמש ראה כ"ספירה חלקית בקול הנשי".
#
# הפתרון אינו כיול מחדש של אותם ספים - הוא החלפת המדד. הברה
# **אינה** אשכול פונמות; היא פסגת סונוריות אחת. זו שיטת גרעיני
# ההברה המקובלת בפונטיקה (Mermelstein 1975, וביישום של
# De Jong & Wempe 2009 ב-Praat): פסגות במעטפת העוצמה, כששתי פסגות
# נחשבות לשתי הברות **רק אם יש ביניהן בקעה אמיתית**.
#
# ולמה זה עובד על שני הקולות באותו קוד: כל הספים כאן הם **יחסיים
# בדציבלים** - מתחת לשיא של אותה הקלטה, ועומק בקעה ביחס לפסגות
# עצמן. אין שום סף עוצמה מוחלט, ולכן אין מה להטות לפי מין הדובר.

_DIP_DB = 2.5          # עומק בקעה מינימלי בין שני גרעינים
_FLOOR_DB = 20.0       # כמה דציבלים מתחת לשיא עוד נחשב גרעין אפשרי
_MIN_SEP = 0.090       # שניות - הברה אנושית אינה קצרה מזה

# --- היאטוס: גבול הברה בתוך קטע מקולי רצוף
#
# 05/10, המשפט שנשאר שבור מ-TASK 07: "רגע... אז זה היה אתה?" נספר 6
# במקום 8, **באותו אופן בשני הקולות**. נמדד פריים-פריים (hf_probe)
# מה באמת קורה שם, ואלה העובדות:
#
#   2.00-2.16  תנועה רצופה עם *שתי* פסגות (2.06 ו-2.15), בקעה של
#              0.34dB בלבד ביניהן, 70ms זו מזו. זה הגבול "זֶה|הָ" -
#              ה"ה" העברית בין שתי תנועות אינה חוסמת את הזרימה,
#              ולכן אין בקעה. **זו ההברה שאבדה.**
#   2.38-2.47  סגירה, ו-2.48 פרץ חד (אנרגיה מעל 3500Hz עולה פי 4,
#              מרכז הכובד 2210Hz) - ה"ת" של "אתה".
#   2.24-2.37  תנועת /a/ אחת רצופה של 130ms, בלי שום בקעה. פונטית
#              אלה **שתי** הברות ("יָה" + "אַ" של "אתה"), אבל הן
#              התמזגו לתנועה ארוכה אחת. אין שום מדד בשמע שמפריד
#              שתי תנועות זהות שהתמזגו - לכן ההברה הזאת אינה
#              ניתנת לספירה מהשמע, וזה נמדד ומתועד ולא "מתוקן"
#              בניחוש מהטקסט.
#
# הכלל שנוסף מטפל במקרה הראשון: שתי פסגות **באותו גובה** שהתנועה
# ביניהן התחלפה הן שתי הברות, גם אם העוצמה לא ירדה. שלושת היועצים
# (Codestral, Command A, Qwen3.8) הצביעו על אותו כיוון - מדד שינוי
# ספקטרלי ולא כיול מחדש של סף העוצמה.
#
# ולמה *באותו גובה*: בלי התנאי הזה כתף על מדרון עלייה נספרת כהברה.
# נמדד: בקול הילה הפסגה ב-0.29 נמוכה ב-13.6dB מזו ב-0.43, היא רק
# שלב בעלייה - והכלל חייב לדחות אותה.
#
# הספים נקבעו **אחרי מדידה של כל זוג פסגות ממוזג בעשר ההקלטות**
# (לא בניחוש): נרשמו עבור כל זוג עומק הבקעה, המרווח, הפרש הגובה
# והמרחק הפורמנטי, ואז נבחר התחום שמפריד את שני הגבולות האבודים
# מכל הזוגות שחייבים להישאר ממוזגים. שתי מסקנות שלא היו צפויות:
#
# * **הפרש הגובה הוא המפריד החזק**, לא עומק הבקעה. זוג שחייב
#   להישאר ממוזג יושב בהפרש של 1.5-4.7dB, ושני הגבולות האמיתיים
#   בהפרש של 0.4-0.6dB. הסבר: שתי תנועות שכנות נהגות באותה
#   עוצמה; פסגה שנמוכה מחברתה היא שלב בתוך אותה הברה.
# * ויש **גם גבול עליון** למרחק הפורמנטי. מעבר של פי שלושה ב-F2
#   בתוך 80ms אינו שתי תנועות שכנות אלא מעבר דרך עיצור קולי
#   (ל/נ/י) *בתוך* הברה אחת. בלי הגבול העליון הזה "אני מקשיב"
#   ו"זה בסדר" נספרו הברה אחת יותר.
_DIP2_DB = 0.25        # בקעה מינימלית במקרה היאטוס (לעומת 2.5 הרגילים)
_SEP2 = 0.060          # שניות - הברה בדיבור מהיר
_DLOG2 = 0.10          # מרחק לוג-פורמנטי שמעיד שהתנועה התחלפה
_DLOG2_MAX = 0.90      # ומעליו זה מעבר דרך עיצור ולא תנועה שכנה
_LEVEL2_DB = 1.2       # הפרש גובה מותר בין שתי הפסגות


def _envelope_db(tr: Track) -> np.ndarray:
    """מעטפת העוצמה בדציבלים, מוחלקת על 30 מילישניות.

    ההחלקה חיונית: בלעדיה כל מחזור של מנעד הקול (אצל אישה כל 4-5
    מילישניות) נראה כפסגה, ואז יש עשרות "הברות" בשנייה.
    """
    e = np.asarray(tr.sonor if len(tr.sonor) else tr.rms, dtype=float)
    if not len(e):
        return e
    k = np.array([0.25, 0.50, 0.25])
    sm = np.convolve(e, k, mode="same")
    return 20.0 * np.log10(np.maximum(sm, 1e-6))


#: יחס F1 בבקעה מול הגרעין הפתוח שבשכנותה, שמעליו הבקעה היא בעצמה
#: הברה נשופה. ראה `breathy_nuclei` - הערך נבחר מתוך פער נמדד ולא בניחוש.
_BREATHY_F1 = 1.30
_BREATHY_SEP = 3            # פריימים לכל צד, כלומר 30 מילישניות


def breathy_nuclei(tr: Track, ns: list[int], db: np.ndarray) -> list[int]:
    """מוסיף הברות שהאנרגיה החמיצה כי העיצור הפותח שלהן הוא **נשוף**.

    הבעיה שנמדדה כאן (05/10): בקול הנשי, במשפט המהיר "רגע... אז זה
    היה אתה?", ההברה `הָ` של "היה" לא נספרה. היא לא "כמעט" פסגה - היא
    יושבת **בתוך בקעת האנרגיה** בין `זֶה` לגלישה של `יָה`, כי /ה/ הוא
    חיכוך גרוני בלי קוליות, והאוויר שיוצא בו מוריד את העוצמה בדיוק
    במקום שבו מתחילה הברה חדשה. שום כיול של ספי עוצמה לא יכול למצוא
    אותה: לפי העוצמה היא גבול, ולא גרעין.

    מה שכן מוצא אותה הוא **מידת פתיחת הלסת**, כלומר F1. בבקעה ההיא
    F1 הוא 914 הרץ, בעוד בשני הגרעינים שסביבה 570 ו-505 - כלומר הפה
    פתוח שם **יותר** מאשר בשתי ההברות שהוכרו. פה פתוח לרווחה הוא
    הגדרת גרעין הברה; עוצמה נמוכה היא רק סימן לנשיפה.

    לכן הכלל בודק **רק בקעות קיימות** ולא מוסיף גבולות חדשים, ולכן הוא
    גם לא יכול לפצל הברה תקינה לשתיים.

    הסף נבחר מתוך מדידה של **כל** 16 הבקעות בעשר ההקלטות, ולא בניחוש:
    בכל הבקעות שחייבות להישאר גבול היחס הוא 0.32-0.94, ובבקעה האמיתית
    1.60. 1.30 יושב באמצע פער שרחב פי שלושה מהרעש.

    נוסו ונפסלו שתי גישות לפני זו, ושתיהן נמדדו:

    * **הקלטה חוזרת בקצב איטי (-35%) כספירת פניה.** הדיבור האיטי
      מאריך תנועות, וכל תנועה ארוכה נשברה לשתי פסגות: הפניה החזירה
      7 במקום 6 ו-8 במקום 5, ובמשפט הבעייתי עצמו 6 במקום 8. פניה
      גרועה מהמקור אינה פניה.
    * **ספירת מטרות פורמנטיות יציבות בתוך הגרעין** (ההצעה של Command A
      ושל GPT-OSS). היא פיצלה 9 מתוך 10 המשפטים יתר על המידה -
      1/10 מדויק - כי מסלול הפורמנטים "נעצר" גם בתוך עיצורים קוליים
      ובתוך מקטעי שקט שמולאו באינטרפולציה.
    """
    if len(ns) < 2:
        return ns
    thr = float(db.max()) - _FLOOR_DB
    voiced = tr.voiced if len(tr.voiced) == len(db) else np.ones(len(db), bool)
    add: list[int] = []
    for k in range(len(ns) - 1):
        i, j = ns[k], ns[k + 1]
        m = i + int(np.argmin(db[i:j + 1]))
        if m - i < _BREATHY_SEP or j - m < _BREATHY_SEP:
            continue
        if not voiced[m] or db[m] < thr:
            continue
        a1, _ = _fmt_at(tr, i)
        b1, _ = _fmt_at(tr, j)
        m1, _ = _fmt_at(tr, m)
        if a1 <= 0 or b1 <= 0 or m1 <= 0:
            continue
        if m1 / max(a1, b1) >= _BREATHY_F1:
            add.append(m)
    return sorted(set(ns) | set(add))


def nuclei(tr: Track) -> list[int]:
    """אינדקסי הפריימים שבהם יושבים גרעיני ההברות."""
    db = _envelope_db(tr)
    n = len(db)
    if n < 3:
        return []
    thr = float(db.max()) - _FLOOR_DB
    voiced = tr.voiced if len(tr.voiced) == n else np.ones(n, bool)

    peaks: list[int] = []
    for i in range(1, n - 1):
        if db[i] < thr or not voiced[i]:
            continue
        if db[i] >= db[i - 1] and db[i] > db[i + 1]:
            peaks.append(i)

    # מיזוג פסגות שאינן מופרדות בבקעה. בלי זה רטט בתוך תנועה אחת
    # ("אַאַ") נספר כשתי הברות - וזה הכיוון ההפוך של אותה שגיאה.
    out: list[int] = []
    for i in peaks:
        if not out:
            out.append(i)
            continue
        j = out[-1]
        dip = min(float(db[j]), float(db[i])) - float(db[j:i + 1].min())
        sep = (i - j) * tr.hop
        if (dip >= _DIP_DB and sep >= _MIN_SEP) or hiatus(tr, db, j, i):
            out.append(i)
        elif db[i] > db[j]:
            out[-1] = i
    # ואחרי המיזוג - ההברות הנשופות, שהעוצמה מסתירה מעצם טיבה.
    return breathy_nuclei(tr, out, db)


def _fmt_at(tr: Track, i: int) -> tuple[float, float]:
    """(F1, F2) בפסגה, חציון על חמישה פריימים. חציון ולא ערך בודד:
    עקיבת LPC מדלגת פורמנט בפריים יחיד, וריצוד כזה היה מייצר
    "התחלפות תנועה" שלא קרתה."""
    lo, hi = max(0, i - 2), min(len(tr.f1), i + 3)
    f1, f2 = tr.f1[lo:hi], tr.f2[lo:hi]
    m = f1 > 0
    if not m.any():
        return 0.0, 0.0
    return float(np.median(f1[m])), float(np.median(f2[m]))


def hiatus(tr: Track, db: np.ndarray, j: int, i: int) -> bool:
    """האם בין שתי הפסגות יש גבול הברה **בלי** בקעת עוצמה.

    ארבעה תנאים, וכל אחד מהם מפיל מקרה אחר שנמדד בפועל:
      1. יש בקעה **כלשהי** (0.25dB) ומרווח של 60ms - אחרת זה רטט
         בתוך אותה תנועה.
      2. שתי הפסגות באותו גובה (1.2dB) - אחרת זו כתף על מדרון או
         שלב בתוך הברה.
      3. התנועה התחלפה: מרחק לוג-פורמנטי של 0.10 לפחות.
      4. ולא יותר מ-0.90 - מעבר גדול מזה הוא דרך עיצור קולי.
    """
    dip = min(float(db[j]), float(db[i])) - float(db[j:i + 1].min())
    if dip < _DIP2_DB or (i - j) * tr.hop < _SEP2:
        return False
    if abs(float(db[i]) - float(db[j])) > _LEVEL2_DB:
        return False
    a1, a2 = _fmt_at(tr, j)
    b1, b2 = _fmt_at(tr, i)
    if a1 <= 0 or b1 <= 0:
        return False
    d = math.hypot(math.log(b1 / a1),
                   math.log(max(b2, 1.0) / max(a2, 1.0)) if a2 > 0 and b2 > 0
                   else 0.0)
    return _DLOG2 <= d <= _DLOG2_MAX


def _vowel_at(tr: Track, i: int, scale: float) -> str:
    """תנועת הגרעין: הפורמנטים **בשיא** ולא בגבול המקטע.

    זה גם מה שמשפר את זהות התנועה: בגבולות ההגה הפורמנטים נעים
    בין שתי מטרות, ובפסגה הם היציבים ביותר.
    """
    lo, hi = max(0, i - 2), min(len(tr.f1), i + 3)
    f1 = tr.f1[lo:hi]
    f2 = tr.f2[lo:hi]
    m = f1 > 0
    if not m.any():
        return "a"
    return _vowel(float(np.median(f1[m])), float(np.median(f2[m])), scale)


def syllables(tr: Track) -> list[tuple[float, float, str]]:
    """הברות: (התחלה, סוף, תנועת הגרעין). אחת לכל פסגת סונוריות.

    הגבולות הם **הבקעות** בין פסגות שכנות - זו הגדרת ההברה, ולא
    חלוקה שווה בזמן.
    """
    ns = nuclei(tr)
    if not ns:
        return []
    db = _envelope_db(tr)
    n = len(db)
    out: list[tuple[float, float, str]] = []
    scale = _voice_scale(tr)
    for k, i in enumerate(ns):
        if k == 0:
            lo = i
            while lo > 0 and db[lo - 1] < db[lo]:
                lo -= 1
        else:
            j = ns[k - 1]
            lo = j + int(np.argmin(db[j:i + 1]))
        if k == len(ns) - 1:
            hi = i
            while hi < n - 1 and db[hi + 1] < db[hi]:
                hi += 1
        else:
            hi = i + int(np.argmin(db[i:ns[k + 1] + 1]))
        out.append((round(lo * tr.hop, 4), round(max(hi, lo + 1) * tr.hop, 4),
                    _vowel_at(tr, i, scale)))
    return out


def vowel_string(tr: Track) -> str:
    """רצף תנועות הגרעין שנשמעו בפועל. זה ה'ניקוד' שנמדד.

    למה זה כאן ולא בטקסט: בעברית לא מנוקדת אין מאיפה לדעת אם כתוב
    "בְּסֵדֶר" או "בַּסָּדָר". הפורמנטים יודעים, כי הם מודדים את מה
    שהקול באמת עשה.
    """
    return "".join(v for _, _, v in syllables(tr))


# ======================================================== ניקוד מההגייה

_HEB_CONS = "אבגדהוזחטיכךלמםנןסעפףצץקרשת"
_NIQQUD = {"a": "ַ", "e": "ֶ", "i": "ִ", "o": "ֹ", "u": "ֻ"}


def vocalize(text: str, tr: Track) -> str:
    """מחזיר את הטקסט כשהתנועות שנמדדו בשמע מוצמדות לאותיות.

    זו התשובה לפער שנשאר מ-TASK 05 ("אין ניקוד בטקסטים, ולכן תנועות
    משוחזרות לפי כלל קבוע"). כאן אין שחזור ואין כלל: התנועות נספרות
    מהקול ומוצמדות לפי הסדר. אם נשמעו פחות תנועות מעיצורים - האות
    נשארת בלי סימן, ולא מקבלת ניחוש. **עדיף חסר על מומצא**, כי תנועה
    מומצאת מזיזה את הפה לצורה שלא נהגתה.
    """
    vows = [v for _, _, v in syllables(tr)]
    out: list[str] = []
    k = 0
    for ch in text:
        out.append(ch)
        if ch in _HEB_CONS and k < len(vows):
            out.append(_NIQQUD[vows[k]])
            k += 1
    return "".join(out)


# ============================================================== הקראה

def synth(text: str, voice: str = "avri", stem: Path | None = None,
          force: bool = False) -> Track:
    """טקסט -> קול אמיתי -> Track מנותח. ממוטמע על הדיסק.

    הקריאה לרשת נעשית **פעם אחת לכל (טקסט, קול)**. רנדור של סרטון
    נוגע באותו משפט באלפי פריימים, ובקשת רשת שם הייתה הופכת את
    הרנדור לבלתי אפשרי.
    """
    import hashlib                                     # noqa: PLC0415
    if stem is None:
        key = hashlib.md5((text + voice).encode("utf-8")).hexdigest()[:10]
        stem = AUDIO_DIR / f"{voice}_{key}"
    wav, meta = stem.with_suffix(".wav"), stem.with_suffix(".json")
    if force or not (wav.exists() and meta.exists()):
        stem.parent.mkdir(parents=True, exist_ok=True)
        if not TOOL_PYTHON.exists():
            raise RuntimeError(f"אין פייתון עם edge_tts: {TOOL_PYTHON}")
        subprocess.run(
            [str(TOOL_PYTHON), "-X", "utf8", str(TOOL),
             "--text", text, "--voice", voice, "--stem", str(stem)],
            check=True, capture_output=True, timeout=300)
    m = json.loads(meta.read_text(encoding="utf-8"))
    return analyze(wav, text=m.get("text", text), voice=m.get("voice", voice),
                   bounds=m.get("bounds", []))


_CACHE: dict[tuple[str, str], Track] = {}


def load(text: str, voice: str = "avri") -> Track | None:
    """Track מהדיסק אם הוקלט כבר; None אם אין. **לא פונה לרשת.**

    זה מה שהרנדור קורא. פנייה לרשת מתוך לולאת פריימים היא בדיוק
    המלכודת של `need_credit` מ-23/09, ולכן היא לא קיימת כאן בכלל.
    """
    import hashlib                                     # noqa: PLC0415
    key = (text, voice)
    if key in _CACHE:
        return _CACHE[key]
    h = hashlib.md5((text + voice).encode("utf-8")).hexdigest()[:10]
    stem = AUDIO_DIR / f"{voice}_{h}"
    if not (stem.with_suffix(".wav").exists()
            and stem.with_suffix(".json").exists()):
        return None
    m = json.loads(stem.with_suffix(".json").read_text(encoding="utf-8"))
    tr = analyze(stem.with_suffix(".wav"), text=m.get("text", text),
                 voice=m.get("voice", voice), bounds=m.get("bounds", []))
    _CACHE[key] = tr
    return tr


# ======================================================= פס קול לסרטון

def mix(cues: list[tuple[float, Track]], seconds: float,
        gain: float = 0.92) -> np.ndarray:
    """(זמן בסרטון, Track) -> מערך PCM אחד באורך הסרטון.

    זה מה שהופך "יש קובצי קול" ל"יש פס קול בסרטון". קטע שחורג מסוף
    הסרטון **נחתך ולא מושמט**: סצנה שנגמרת באמצע מילה עדיפה על
    סצנה אילמת, והיא גם מסגירה מיד שהחלון קצר מדי.
    """
    n = int(round(max(0.0, seconds) * RATE)) + 1
    buf = np.zeros(n, dtype=np.float32)
    for at, tr in cues:
        if tr is None:
            continue
        y, rate = read_wav(tr.path)
        if rate != RATE:                              # לא אמור לקרות
            idx = np.linspace(0, len(y) - 1, int(len(y) * RATE / rate))
            y = np.interp(idx, np.arange(len(y)), y).astype(np.float32)
        i0 = int(round(max(0.0, at) * RATE))
        take = min(len(y), max(0, n - i0))
        if take <= 0:
            continue
        buf[i0:i0 + take] += y[:take] * gain
    # הגבלה רכה ולא חיתוך קשה: שני קולות שנופלים על אותה שנייה
    # מייצרים שיא מעל 1.0, וחיתוך שם נשמע כמו סדק.
    peak = float(np.abs(buf).max())
    if peak > 0.98:
        buf = np.tanh(buf / peak * 1.1) * 0.95
    return buf


def write_wav(data: np.ndarray, path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    pcm = np.clip(data, -1.0, 1.0)
    with wave.open(str(path), "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(RATE)
        wf.writeframes((pcm * 32767.0).astype("<i2").tobytes())
    return path


def mux(mp4: str | Path, wav: str | Path, out: str | Path) -> dict:
    """מכניס פס קול ל-mp4 **בלי לקודד מחדש את הווידאו**.

    PyAV ולא ffmpeg כתהליך (כלל הפרויקט). הווידאו עובר כ-packets
    גולמיים (`remux`), ולכן איכות התמונה אינה נוגעת והפעולה לוקחת
    שבריר שנייה גם לסרטון של דקה.
    """
    import av                                          # noqa: PLC0415
    mp4, wav, out = Path(mp4), Path(wav), Path(out)
    src = av.open(str(mp4))
    snd = av.open(str(wav))
    dst = av.open(str(out), mode="w")
    vin = next(s for s in src.streams if s.type == "video")
    ain = next(s for s in snd.streams if s.type == "audio")
    vout = dst.add_stream_from_template(vin)
    aout = dst.add_stream("aac", rate=RATE)
    aout.layout = "mono"
    rs = av.AudioResampler(format=aout.format, layout=aout.layout,
                           rate=aout.rate)
    for pkt in src.demux(vin):
        if pkt.dts is None:
            continue
        pkt.stream = vout
        dst.mux(pkt)
    for frame in snd.decode(ain):
        for f in rs.resample(frame):
            for pkt in aout.encode(f):
                dst.mux(pkt)
    for f in rs.resample(None):
        for pkt in aout.encode(f):
            dst.mux(pkt)
    for pkt in aout.encode(None):
        dst.mux(pkt)
    dst.close()
    src.close()
    snd.close()
    return {"mp4": str(out), "size_mb": round(out.stat().st_size / 1048576, 2)}


#: ספירת ההברות הנכונה של כל משפט שהוקלט, לפי ההגייה העברית.
#: זו **טבלת אמת ידנית**, והיא כאן בכוונה: בלעדיה "דיוק הספירה"
#: הוא הצהרה. איתה הוא מספר שנמדד, ושנשבר מיד אם הכיול יזוז.
EXPECTED_SYLLABLES: dict[str, int] = {
    "לא, הכול בסדר.": 6,            # לא · הַ-כּוֹל · בְּ-סֵ-דֶר
    "כן, אני מקשיב.": 5,            # כֵּן · אַ-נִי · מַק-שִׁיב
    "נו? מה קרה שם?": 5,            # נוּ · מָה · קָ-רָה · שָׁם
    "זה בסדר, אני רגילה.": 9,       # זֶה · בְּ-סֵ-דֶר · אַ-נִי · רְ-גִי-לָה
    "רגע... אז זה היה אתה?": 8,     # רֶ-גַע · אָז · זֶה · הָ-יָה · אַ-תָה
}


def syllable_audit() -> dict:
    """דיוק ספירת ההברות, **בנפרד לכל קול**.

    הפירוק לפי קול אינו קוסמטי: הפער שהמשתמש דיווח עליו היה הטיה
    מגדרית (הקול הנשי נספר חסר), ולכן הדבר שחייב להיות נמדד הוא
    *ההפרש בין הקולות* ולא רק הממוצע.
    """
    per: dict[str, dict] = {}
    rows = []
    for w in available():
        meta = w.with_suffix(".json")
        if not meta.exists():
            continue
        m = json.loads(meta.read_text(encoding="utf-8"))
        txt = m.get("text", "")
        if txt not in EXPECTED_SYLLABLES:
            continue
        tr = analyze(w, txt, m.get("voice", ""))
        got = len(syllables(tr))
        exp = EXPECTED_SYLLABLES[txt]
        key = "hila" if "Hila" in m.get("voice", "") else "avri"
        d = per.setdefault(key, {"n": 0, "err": 0, "exact": 0})
        d["n"] += 1
        d["err"] += abs(got - exp)
        d["exact"] += int(got == exp)
        rows.append({"voice": key, "text": txt, "got": got, "expected": exp,
                     "vowels": vowel_string(tr)})
    for d in per.values():
        d["mae"] = round(d["err"] / max(1, d["n"]), 3)
    maes = [d["mae"] for d in per.values()]
    return {"per_voice": per, "rows": rows,
            "mae": round(sum(r["err"] if False else abs(r["got"] - r["expected"])
                             for r in rows) / max(1, len(rows)), 3),
            "exact": sum(r["got"] == r["expected"] for r in rows),
            "n": len(rows),
            "voice_gap": round(max(maes) - min(maes), 3) if maes else 0.0}


def available() -> list[Path]:
    if not AUDIO_DIR.exists():
        return []
    return sorted(p for p in AUDIO_DIR.glob("*.wav"))


# =============================================================== דוח

def audit() -> dict:
    """מה נמדד בכל קובץ שמע שקיים. רץ בלי רשת."""
    rows = []
    for w in available():
        meta = w.with_suffix(".json")
        if not meta.exists():
            continue
        m = json.loads(meta.read_text(encoding="utf-8"))
        tr = analyze(w, m.get("text", ""), m.get("voice", ""),
                     m.get("bounds", []))
        rows.append(tr.as_dict())
    return {"files": len(rows), "tracks": rows}


def main(argv=None) -> int:
    sys.stdout.reconfigure(encoding="utf-8")
    rep = audit()
    print(f"=== קבצי קול: {rep['files']} ===")
    for r in rep["tracks"]:
        print(f"  {Path(r['path']).name}  {r['seconds']:5.2f}ש  "
              f"דיבור {r['speech_ratio']:.0%}  "
              f"{r['visemes']:3d} ויזמות  תנועות: {r['vowels']}")
        print(f"      «{r['text']}»")
    acc = syllable_audit()
    print(f"\n=== דיוק ספירת הברות: {acc['exact']}/{acc['n']} מדויק · "
          f"שגיאה ממוצעת {acc['mae']} · פער בין הקולות "
          f"{acc['voice_gap']} ===")
    for v, d in sorted(acc["per_voice"].items()):
        print(f"  {v}: {d['exact']}/{d['n']} מדויק, שגיאה ממוצעת {d['mae']}")
    for r in acc["rows"]:
        if r["got"] != r["expected"]:
            print(f"  ✗ [{r['voice']}] «{r['text']}» {r['got']} "
                  f"במקום {r['expected']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
