# -*- coding: utf-8 -*-
"""צינור דמויות תלת־ממד להפקה: שלד, עור, ריג פנים, אצבעות, IK ותנועה
משנית - ובדיקת קבלה שמוכיחה אפס סחיפת זהות בין פוזות וזוויות."""
from . import arkit, basemesh, controls, glbio, identity, pipeline  # noqa: F401
from .skeleton import Skeleton  # noqa: F401

__all__ = ["Skeleton", "arkit", "basemesh", "controls", "glbio", "identity",
           "pipeline"]
