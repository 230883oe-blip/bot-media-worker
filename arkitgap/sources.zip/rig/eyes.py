# -*- coding: utf-8 -*-
r"""
מערכת משחק עיניים — TASK 04. מערכת מדרגה ראשונה, לא תוספת.

מה הכוונה ב"מדרגה ראשונה": העיניים אינן נגזרת של ההבעה ואינן נגזרת
של הדיבור. יש להן **תוכנית משלהן** — רצף נקודות מבט עם זמני שהייה,
ומכל שינוי בתוכנית נגזרים הסקאדה, ההקדמה שלפניה, המצמוץ, שינוי
המיקוד, כיוון האישון, ופיגור הראש. ההבעה והדיבור הם הקשר, לא מקור.

אחת-עשרה היכולות שנדרשו, ואיפה כל אחת יושבת:

  1. מעקב מטרה            `TARGETS` + `Fix.pos`   — לכל מטרה מקום ומרחק
  2. הסטות מבט            `script()`              — תוכנית, לא רעש
  3. הקדמה לפני הסטה      `_base_aim` (ant)       — תזוזה נגדית + עפעף
  4. ריצוד (darting)      `_dart`                 — מיקרו-סקאדות בתוך קיבוע
  5. שינוי מיקוד          `_verge`                — התכנסות עם פיגור
  6. תזמון מצמוץ          `_blinks()`             — מצמוץ נגרר-הסטה
  7. עפעפיים אסימטריים    `asym`                  — משרעת **וזמן** שונים
  8. כיוון האישון         `pupil`/`eye_aim`       — האישון הולך עם המבט
  9. פקיחה רגשית          `_openness`             — מ-valence/arousal/control
 10. תגובת עיניים מושהית  `react()`               — השהיה לפי שליטה
 11. לפעמים מסיטה לפני    `_pre_speech`           — מבט עוזב **לפני** הדיבור
     שהיא מדברת

--------------------------------------------------------------------------
העיקרון שהופך את זה למערכת ולא לרעש: הסקאדה היא החלטה, ולה יש "לפני"
--------------------------------------------------------------------------
בעין אמיתית הסטת מבט אינה מתחילה בעיניים. קודם משתנה **הקיבוע**
(העין נרגעת מהנעיצה), העפעף נע מעט, האישון מתחיל להתרחב — ורק אז
קורית הסקאדה, שאורכה נגזר מהמשרעת שלה (main sequence) ולא קבוע.
הראש מגיע **אחרי** העיניים, ולא איתן; זה ההבדל הגדול ביותר בין
דמות שמסתכלת לדמות שהראש והעיניים שלה מודבקים.

וזה גם מה שהמערכת מודדת על עצמה ב-`audit()`: אם תזוזת העיניים
תתחיל יחד עם הראש, או אם המבט ייפול על קצב הדיבור, המדידה תיפול.

--------------------------------------------------------------------------
"אל תסנכרן כל תנועת עין לדיבור" — זה נאכף במדידה, לא בהצהרה
--------------------------------------------------------------------------
לדיבור יש כאן **שימוש אחד בלבד**: לפני שהדמות מתחילה לדבר היא
מסיטה מבט (זה מה שאדם עושה כשהוא מנסח), וחוזרת אחרי שהתחילה. מלבד
זה שעון המבט רץ בקצב משלו, שאינו כפולה של קצב הדיבור, ולכן
הקורלציה בין מהירות העין לעוצמת הדיבור נמוכה — ו-`audit()` מודד
אותה בפועל.

הרצה:
    python -m rig.eyes --audit
    python -m rig.eyes --trace 4.0
"""

from __future__ import annotations

import argparse
import json
import math
from dataclasses import dataclass, field

from . import acting

TAU = math.pi * 2.0


# ------------------------------------------------------------------ מטרות
#
# מטרה היא **מקום ומרחק**, לא שם. המרחק הוא זה שמייצר את שינוי
# המיקוד: מבט "פנימה" (לחשוב) הוא קרוב, מבט "הלאה" הוא רחוק, ואי
# אפשר לשחק שינוי מיקוד בלי שלמטרות יהיה עומק.

@dataclass(frozen=True)
class Target:
    key: str
    x: float          # ביחידות eye_aim (1.0 ≈ 28 מעלות)
    y: float
    dist: float       # 0 = צמוד לפנים (התכנסות מלאה), 1 = אופק


#: המרחקים כוילו מול הרנדור. הערכים הראשונים (partner=0.42, כלומר
#: התכנסות 0.58) הפכו את שתי הדמויות לפוזלות בתקריב: אדם שמסתכל על
#: אדם אחר במרחק שיחה כמעט אינו מכנס עיניים, וההתכנסות האמיתית
#: מתחילה רק בטווח של פחות מחצי מטר. מי שמביט "פנימה" הוא היחיד
#: שמכנס באמת, וגם אצלו זה מרוסן ב-`_VERGE_GAIN`.
TARGETS: dict[str, Target] = {
    "partner":  Target("partner", 0.00, 0.03, 0.72),
    "audience": Target("audience", 0.00, 0.00, 0.80),
    "away":     Target("away", 0.72, 0.10, 0.98),
    "away2":    Target("away2", -0.66, 0.06, 0.98),
    "down":     Target("down", 0.12, -0.46, 0.55),
    "object":   Target("object", 0.40, -0.26, 0.42),
    "inward":   Target("inward", 0.22, 0.34, 0.20),   # "לחשוב" - מבט קרוב
    "hands":    Target("hands", 0.05, -0.70, 0.38),
    "mouth":    Target("mouth", 0.00, -0.18, 0.70),   # מסתכלת על הפה, לא בעין
}

#: מהמרחק אל זווית ההתכנסות בפועל. `eye_converge=1` מסובב את שני
#: גלגלי העין פנימה במלוא התחום, וזה מתאים לנקודה צמודה לאף בלבד.
_VERGE_GAIN = 0.62


def target(key: str) -> Target:
    return TARGETS.get(key) or TARGETS["partner"]


# ------------------------------------------------------------------ קיבוע

@dataclass
class Fix:
    """נקודת מבט אחת בתוכנית: לאן, ממתי, ולמה."""
    at: float
    key: str
    reason: str = "scan"
    hold: float = 0.6

    @property
    def tgt(self) -> Target:
        return target(self.key)


#: הסיבות. הן לא קישוט: `reason` הוא מה שקובע אם יהיה מצמוץ בהסטה,
#: כמה היא ארוכה, ואם האישון מתרחב.
REASONS = {
    "hold":       "מחזיקה קשר עין",
    "think":      "מסיטה כדי לנסח",
    "pre_speech": "מסיטה לפני שהיא מדברת",
    "discomfort": "שוברת קשר עין מאי-נוחות",
    "conceal":    "מורידה מבט כדי לא להיקרא",
    "check":      "מציצה לבדוק אם קנו לה את זה",
    "search":     "מחפשת מידע",
    "react":      "מגיבה לגירוי - באיחור",
    "scan":       "סורקת",
}


def _frac(x: float) -> float:
    """רעש דטרמיניסטי ב-[0,1). אין random: אותו שוט חייב לצאת זהה
    בכל רנדור, אחרת אי אפשר לבדוק אותו ואי אפשר לצלם אותו שוב."""
    s = math.sin(x * 127.1 + 311.7) * 43758.5453123
    return s - math.floor(s)


def _ss(e0: float, e1: float, x: float) -> float:
    if e1 == e0:
        return 0.0 if x < e0 else 1.0
    u = (x - e0) / (e1 - e0)
    u = max(0.0, min(1.0, u))
    return u * u * (3.0 - 2.0 * u)


def _smoother(u: float) -> float:
    """עקומת סקאדה: האצה והאטה חדות באמצע. smoothstep רגיל איטי מדי
    באמצע, והסקאדה יצאה נראית כמו תנועת מצלמה."""
    u = max(0.0, min(1.0, u))
    return u * u * u * (u * (6.0 * u - 15.0) + 10.0)


def saccade_dur(amp: float) -> float:
    """ה-main sequence: אורך הסקאדה נגזר ממשרעתה.

    זה לא עידון. סקאדה באורך קבוע היא הדבר שהופך מבט לאנימציה: קפיצה
    של 3 מעלות וקפיצה של 40 מעלות אורכות אותו זמן, ולכן הקטנה נראית
    איטית מדי והגדולה נראית חטופה. במציאות: ~2.2 מילישניות לכל מעלה,
    מעל בסיס של ~28 מילישניות.
    """
    deg = abs(amp) * 28.0
    return min(0.115, 0.028 + 0.0022 * deg)


# ------------------------------------------------------------- המערכת

class EyeActing:
    """
    משחק עיניים לשוט אחד. בונים אותה פעם אחת, ואז `solve(t)` לכל פריים.

    הפרמטרים הרגשיים (`valence/arousal/control`) נכנסים כמספרים ולא
    כשם רגש בכוונה: כך המודול הזה **אינו** תלוי במנוע הרגש, ומנוע
    הרגש יכול לייבא אותו בלי ייבוא מעגלי.
    """

    def __init__(self, *, seed: float = 0.0, shot_len: float = 4.0,
                 valence: float = 0.0, arousal: float = 0.5,
                 control: float = 0.6,
                 directness: float = 0.80, hold: float = 1.6,
                 conceal: bool = False, knows_more: float = 0.0,
                 home: str = "partner", away: str = "",
                 speech: tuple = (), reacts: tuple = (),
                 openness: float = 0.0, latency: float = 0.0,
                 micro: bool = True):
        self.seed = float(seed)
        self.shot_len = max(0.4, float(shot_len))
        self.valence = max(-1.0, min(1.0, float(valence)))
        self.arousal = max(0.0, min(1.0, float(arousal)))
        self.control = max(0.0, min(1.0, float(control)))
        self.directness = max(0.0, min(1.0, float(directness)))
        self.hold = max(0.18, float(hold))
        self.conceal = bool(conceal)
        self.knows_more = max(-1.0, min(1.0, float(knows_more)))
        self.home = home if home in TARGETS else "partner"
        self.away = away if away in TARGETS else self._away_default()
        self.speech = tuple((float(a), float(b)) for a, b in speech)
        self.openness = float(openness)
        self.micro_on = bool(micro)
        #: השהיית התגובה הבסיסית. מנוע הרגש מעביר לכאן את ה-delay שלו,
        #: ולכן "הסתרה מעכבת" מגיעה גם לעיניים ולא רק לפנים.
        self.latency = max(0.0, float(latency))
        #: אסימטריה קבועה לדמות: עפעף אחד נח מעט יותר נמוך, ומצמוץ
        #: אחד מקדים את השני בכמה מילישניות. פנים שבהן שני העפעפיים
        #: זהים לחלוטין נקראות כבובה, וזה נראה דווקא בתקריב.
        self.asym = (_frac(self.seed * 3.7 + 1.3) - 0.5) * 2.0
        self.reacts = tuple((float(a), float(b)) for a, b in reacts)
        self.fixes: list[Fix] = self.script()
        self._bl = self._blinks()

    # ------------------------------------------------------------ תוכנית

    def _away_default(self) -> str:
        """לאן מסיטים, כשלא נאמר. זו החלטה דרמטית ולא ברירת מחדל
        טכנית: מי שמסתיר מוריד מבט, מי שמחפש מסתכל על עצם, ומי
        שמנסח מסתכל "פנימה"."""
        if self.conceal:
            return "down"
        if self.knows_more < -0.4:
            return "object"
        if self.valence < -0.25 and self.control < 0.45:
            return "down"
        return "inward" if self.arousal < 0.5 else "away"

    def _pre_speech(self) -> list[tuple[float, float]]:
        """לכל התחלת דיבור — חלון של "מסיטה לפני שמדברת".

        ההקדמה גדלה כשהשליטה קטנה: מי שבטוח בעצמו מתחיל לדבר ואז
        חושב, מי שלא — מנסח קודם. זה השימוש **היחיד** של הדיבור
        במערכת הזאת.
        """
        out = []
        for a, b in self.speech:
            lead = 0.20 + 0.34 * (1.0 - self.control)
            if a - lead <= 0.05:
                continue
            back = a + 0.16 + 0.30 * (1.0 - self.arousal)
            out.append((a - lead, min(back, b if b > a else a + 0.5)))
        return out

    def script(self) -> list[Fix]:
        """
        רצף נקודות המבט לשוט. **זו התוכנית**, והיא נבנית לפני כל
        חישוב גאומטרי.

        שלושת הדברים שהדרישה ביקשה במפורש נמצאים כאן, וכולם נגזרים:
        לפעמים היא מחזיקה קשר עין (`hold` ארוך כשהישירות גבוהה),
        לפעמים מסיטה לפני שהיא מדברת (`_pre_speech`), ולפעמים שוברת
        קשר עין מאי-נוחות (`discomfort` כשה-valence שלילי וה-control
        נמוך). אין כאן טבלה של "תזוזה בשנייה 1.2".
        """
        start = self.home if self.directness >= 0.45 else self.away
        fixes = [Fix(0.0, start, self._reason_for(start), self.hold)]
        pre = self._pre_speech()
        t = 0.0
        i = 0
        # שעון המבט: אינו כפולה של קצב הדיבור, ולכן תנועות העין לא
        # נופלות על ההגייה. המכפיל אי-רציונלי בכוונה.
        clock = 0.61803398875
        while t < self.shot_len + 0.5 and len(fixes) < 64:
            i += 1
            cur = fixes[-1]
            on_home = cur.key == self.home
            if on_home:
                dwell = self.hold * (0.70 + 0.60 * _frac(i * clock + self.seed))
                # מי שמחזיק מבט מחזיק אותו **באמת** פעם אחת בשוט.
                # קיבוע ארוך אחד הוא מה שנקרא כ"היא לא מורידה ממנו
                # עיניים"; שלושה קיבועים בינוניים נקראים כריצוד.
                if self.directness > 0.70 and i == 2:
                    dwell *= 2.1
            else:
                dwell = (0.30 + 0.55 * (1.0 - self.control)) * \
                    (0.70 + 0.70 * _frac(i * clock * 2.3 + self.seed + 4.0))
                if cur.reason in ("conceal", "discomfort"):
                    dwell *= 1.45      # מבט שנשבר מאי-נוחות לא חוזר מיד
            t = cur.at + max(0.14, dwell)
            if t > self.shot_len + 0.4:
                break
            key = self.away if on_home else self.home
            why = self._reason_for(key, returning=not on_home)
            fixes.append(Fix(round(t, 4), key, why,
                             self.hold if key == self.home else 0.45))
        # --- קיבועים כפויים: הם **לא** חלק משעון השהייה.
        # הניסיון הראשון חיפש אם מועד ההסטה הטבעית נופל בתוך חלון
        # "לפני דיבור", ואם לא - לא הייתה הסטה בכלל. התוצאה שנמדדה:
        # בשלושה מתוך שמונה תרחישים עם דיבור לא נוצרה שום הסטה לפני
        # הדיבור, כלומר היכולת הייתה קיימת בקוד ולא בפלט.
        for a, b in pre:
            key = self.away if self.away not in ("partner", "audience") \
                else "inward"
            fixes.append(Fix(round(a, 4), key, "pre_speech", 0.4))
            fixes.append(Fix(round(b, 4), self.home,
                             self._reason_for(self.home, True), self.hold))
        # הסטות שנגרמו מגירוי חיצוני — מושהות, וזו היכולת ה-10.
        # היעד הוא **מקור הגירוי** (בן השיח) ולא הבית: אדם שמביט מטה
        # ושומע משהו מרים את העיניים אליו, ולא ממשיך להביט מטה.
        for at, _amt in self.reacts:
            lat = self.reaction_latency()
            fixes.append(Fix(round(at + lat, 4), "partner", "react", 0.7))
        fixes.sort(key=lambda f: f.at)
        # שתי הסטות באותו רגע הן סקאדה בת אפס אורך — ומחלקים בה.
        # ושני קיבועים עוקבים לאותה מטרה הם "הסטה" בלי תזוזה: הם
        # מייצרים מצמוץ נגרר-הסטה בלי שהמבט זז, וזה נראה כמו טיק.
        out = [fixes[0]]
        for f in fixes[1:]:
            if f.at - out[-1].at < 0.07:
                out[-1] = f
            elif f.key == out[-1].key and f.reason == out[-1].reason:
                continue
            else:
                out.append(f)
        return out

    def _reason_for(self, key: str, returning: bool = False) -> str:
        """למה היא מסתכלת לשם. הסיבה נגזרת מ**המטרה ומהמצב**, ולא
        מתפקידה בתוכנית: דמות שמביטה מטה כל השוט ומציצה למעלה היא
        אותו דבר בדיוק כמו דמות שמביטה בבן השיח ומורידה מבט, רק
        הפוך — ולכן אסור שהסיבה תיגזר מ"בית" מול "חוץ"."""
        if key in ("partner", "audience"):
            return "check" if (self.conceal or returning) and \
                self.directness < 0.92 else "hold"
        if self.conceal:
            return "conceal"
        if self.valence < -0.25 and self.control < 0.50:
            return "discomfort"
        if self.knows_more < -0.4:
            return "search"
        if self.speech:
            return "think"
        return "scan"

    def reaction_latency(self) -> float:
        """כמה זמן עובר מהגירוי עד שהעין מגיבה.

        לא אפס, וגם לא קבוע: ככל שהשליטה נמוכה התגובה איטית יותר
        (עיבוד), והסתרה מוסיפה עוד — כי קודם צריך להחליט מה **לא**
        להראות. זה בדיוק ה-delayed reaction שנדרש.
        """
        lat = 0.12 + 0.26 * (1.0 - self.control) + 0.55 * self.latency
        if self.conceal:
            return lat + 0.14
        return lat

    # ------------------------------------------------------------ המבט

    def _idx(self, t: float) -> int:
        i = 0
        for j, f in enumerate(self.fixes):
            if f.at <= t + 1e-9:
                i = j
            else:
                break
        return i

    def anticipation(self) -> float:
        """אורך חלון ההקדמה שלפני הסטה."""
        return 0.09 + 0.07 * (1.0 - self.control)

    def _base_aim(self, t: float) -> tuple[float, float]:
        """המבט המתוכנן בזמן t — בלי ריצוד.

        פונקציה נפרדת בכוונה: הראש עוקב אחרי **התוכנית** ולא אחרי
        המיקרו-תנועות. ראש שעוקב אחרי מיקרו-סקאדות רועד.
        """
        i = self._idx(t)
        cur = self.fixes[i]
        prev = self.fixes[i - 1] if i > 0 else cur
        px, py = prev.tgt.x, prev.tgt.y
        cx, cy = cur.tgt.x, cur.tgt.y
        amp = math.hypot(cx - px, cy - py)
        d = saccade_dur(amp)
        if amp > 1e-6 and t < cur.at + d:
            k = _smoother((t - cur.at) / d)
            x, y = px + (cx - px) * k, py + (cy - py) * k
        else:
            x, y = cx, cy
        # --- הקדמה: תזוזה נגדית קטנה לפני הסקאדה הבאה.
        # ההיגיון: לפני תנועה גדולה המערכת "משתחררת" מהנעיצה, והעין
        # נסחפת רגע **אל הצד ההפוך**. זה קטן (כ-1.5 מעלות) אבל הוא
        # מה שהופך הסטה מקפיצה לאירוע שיש לו "לפני".
        if i + 1 < len(self.fixes):
            nxt = self.fixes[i + 1]
            ant = self.anticipation()
            if nxt.at - ant <= t < nxt.at:
                dx, dy = nxt.tgt.x - cx, nxt.tgt.y - cy
                nn = math.hypot(dx, dy)
                if nn > 1e-6:
                    r = _ss(0.0, 1.0, (t - (nxt.at - ant)) / ant)
                    g = 0.055 * r
                    x -= dx / nn * g
                    y -= dy / nn * g
        return x, y

    def _dart(self, t: float) -> tuple[float, float]:
        """ריצוד בתוך קיבוע: מיקרו-סקאדות + סחיפה איטית.

        עין נעוצה אינה דוממת. בלי זה המבט "ננעל" בין ההסטות ונראה
        כמו עיניים מזכוכית — וזה נראה דווקא בתקריב, שם כל השאר כבר
        בסדר.
        """
        if not self.micro_on:
            return 0.0, 0.0
        rate = 1.3 + 2.4 * self.arousal
        per = 1.0 / rate
        k = math.floor(t / per)
        u = (t - k * per) / per
        ax = (_frac(k * 17.3 + self.seed) - 0.5) * 2.0
        ay = (_frac(k * 31.7 + self.seed + 2.0) - 0.5) * 2.0
        bx = (_frac((k + 1) * 17.3 + self.seed) - 0.5) * 2.0
        by = (_frac((k + 1) * 31.7 + self.seed + 2.0) - 0.5) * 2.0
        j = _smoother(min(1.0, u / 0.10))           # הקפיצה עצמה מהירה
        amp = 0.016 + 0.030 * self.arousal
        # סחיפה: תנועה איטית ורציפה בין הקפיצות
        dr = 0.006 * math.sin(TAU * t * 0.37 + self.seed)
        return ((ax + (bx - ax) * j) * amp + dr,
                (ay + (by - ay) * j) * amp * 0.62)

    def aim(self, t: float) -> tuple[float, float]:
        bx, by = self._base_aim(t)
        dx, dy = self._dart(t)
        return (max(-1.0, min(1.0, bx + dx)),
                max(-1.0, min(1.0, by + dy)))

    def sacc_speed(self, t: float, dt: float = 1 / 120) -> float:
        """מהירות התוכנית (בלי ריצוד) — זה המדד שבודקים מול הדיבור."""
        x0, y0 = self._base_aim(max(0.0, t - dt))
        x1, y1 = self._base_aim(t + dt)
        return math.hypot(x1 - x0, y1 - y0) / (2 * dt)

    # --------------------------------------------------------- מיקוד

    #: מיקוד אינו רק מרחק המטרה. "להסתכל דרך" מישהו — המבט הריק של
    #: מי שחושב, מסתיר או מתבייש — הוא **אי-מיקוד** על אותה מטרה
    #: בדיוק. בלי השכבה הזאת "שינוי מיקוד" היה אותו דבר כמו הסטת מבט,
    #: ונמדד כאן שהטווח נשאר 0.12 בלבד, כלומר היכולת לא הייתה קיימת.
    _FOCUS = {"think": (0.45, 0.0), "conceal": (0.45, 0.0),
              "discomfort": (0.50, 0.0), "pre_speech": (0.40, 0.0),
              "check": (1.0, 0.22), "react": (1.0, 0.26),
              "search": (1.0, 0.18), "hold": (1.0, 0.0),
              "scan": (0.80, 0.0)}

    def _focus_of(self, f: Fix) -> float:
        g, add = self._FOCUS.get(f.reason, (1.0, 0.0))
        return max(0.0, min(1.0, (1.0 - f.tgt.dist) * g + add))

    def _verge(self, t: float) -> float:
        """התכנסות העיניים = מיקוד. היא **לא** קורית יחד עם הסקאדה:
        העין מגיעה לכיוון החדש ואז מתמקדת, וזה פיגור של כ-0.2 שנייה.
        בלי הפיגור "שינוי מיקוד" הוא בדיוק אותו דבר כמו הסטת מבט.
        """
        lag = 0.07
        span = 0.20 + 0.14 * (1.0 - self.arousal)
        i = self._idx(t)
        cur = self.fixes[i]
        prev = self.fixes[i - 1] if i > 0 else cur
        v_prev = self._focus_of(prev)
        v_cur = self._focus_of(cur)
        k = _ss(cur.at + lag, cur.at + lag + span, t)
        return max(0.0, min(1.0, v_prev + (v_cur - v_prev) * k))

    # --------------------------------------------------------- מצמוץ

    def blink_rate(self) -> float:
        """שניות בין מצמוצים. ריכוז מדכא מצמוץ, עוררות מגבירה."""
        per = 3.2 / (0.55 + 0.95 * self.arousal)
        if self.directness > 0.75:
            per *= 1.45          # נעיצה מדכאת מצמוץ. זו תופעה נמדדת.
        if self.conceal:
            per *= 0.78          # מי שמסתיר ממצמץ יותר
        return max(0.9, min(6.5, per))

    def _blinks(self) -> list[tuple[float, float]]:
        """רשימת (זמן, משרעת). שני מקורות, וזה כל העניין:

        * **נגרר-הסטה**: רוב ההסטות הגדולות נושאות איתן מצמוץ שמתחיל
          רגע *לפני* הסקאדה. זו התופעה שהופכת מצמוץ מ"טיימר" לחלק
          מהמשחק — העין נעצמת כי המבט עובר, לא כי הגיע הזמן.
        * **אנדוגני**: שעון מג'וטר, שאינו מחזורי ואינו נופל על הדיבור.
        """
        out: list[tuple[float, float]] = []
        for j, f in enumerate(self.fixes[1:], start=1):
            prev = self.fixes[j - 1]
            amp = math.hypot(f.tgt.x - prev.tgt.x, f.tgt.y - prev.tgt.y)
            if amp < 0.22:
                continue
            if _frac(j * 5.9 + self.seed + 7.0) > 0.68:
                continue
            out.append((f.at - 0.035, min(1.0, 0.62 + 0.45 * amp)))
        per = self.blink_rate()
        n = int(self.shot_len / per) + 2
        for k in range(n):
            tc = (k + 0.3 + 0.55 * _frac(k * 7.3 + self.seed)) * per
            if tc > self.shot_len + 0.2:
                break
            if any(abs(tc - b) < 0.28 for b, _ in out):
                continue       # לא ממצמצים פעמיים באותו רגע
            out.append((tc, 0.80 + 0.20 * _frac(k * 3.1 + self.seed + 1.0)))
        for at, amt in self.reacts:
            # גירוי חזק מייצר מצמוץ רפלקסיבי, והוא **מקדים** את
            # ההסטה המושהית: הרפלקס מהיר, ההחלטה אינה.
            out.append((at + 0.09, min(1.0, 0.55 + 0.45 * abs(amt))))
        out.sort()
        return out

    def _lid(self, t: float) -> tuple[float, float]:
        """(שמאל, ימין) של סגירת עפעף. **לא אותו ערך ולא אותו זמן.**"""
        dt = 0.014 + 0.026 * abs(self.asym)
        gl = 1.0
        gr = 1.0 - 0.09 * abs(self.asym)
        if self.asym < 0:
            gl, gr = gr, gl
            dt = -dt
        return (self._lid_one(t, gl), self._lid_one(t - dt, gr))

    def _lid_one(self, t: float, gain: float) -> float:
        v = 0.0
        for tc, amt in self._bl:
            dur = 0.072 + 0.040 * amt
            d = t - tc
            if d < -0.01 or d > dur * 2.7:
                continue
            u = max(0.0, min(1.0, d / (dur * 2.7)))
            # סגירה מהירה, פקיחה איטית. בעין אמיתית היחס הוא כ-1:2.
            v = max(v, amt * math.sin(math.pi * (u ** 0.55)) ** 1.4)
        return min(1.0, v * gain)

    # ---------------------------------------------------- פקיחה רגשית

    def _openness(self) -> tuple[float, float, float]:
        """(פקיחה, כיווץ עפעף תחתון, כבדות) מהרגש — לא משם הרגש.

        `control` הוא מה שמפריד כאן בין פחד לכעס: אותו valence שלילי
        ואותו arousal גבוה, אבל חסר-שליטה פוקח עיניים ובעל-שליטה
        מצמצם אותן. זה אותו עיקרון של מנוע הרגש, במערכת של העיניים.
        """
        neg = 0.5 - 0.5 * self.valence           # 0..1
        hot = _ss(0.42, 0.95, self.arousal)
        wide = hot * (1.0 - self.control) * neg * 1.15
        tight = hot * self.control * neg * 0.95
        heavy = (1.0 - _ss(0.08, 0.46, self.arousal)) * neg * 0.75
        o = self.openness
        wide = max(0.0, wide + max(0.0, o) * 0.8)
        heavy = max(0.0, heavy + max(0.0, -o) * 0.8)
        return (min(1.0, wide), min(1.0, tight), min(1.0, heavy))

    # ------------------------------------------------------------ פלט

    def raw(self, t: float) -> dict:
        """{"ctl":…, "mph":…} — לפני איחוד. זה מה שמנוע הרגש ממזג."""
        t = float(t)
        ax, ay = self.aim(t)
        bl, br = self._lid(t)
        wide, tight, heavy = self._openness()
        i = self._idx(t)
        cur = self.fixes[i]
        verge = self._verge(t)

        # --- אישון: כיוון **וקוטר**. הכיוון הוא eye_aim (הגלגל
        # מסתובב, ולכן האישון מצביע לשם); הקוטר הוא עוררות פחות
        # התכנסות — שלישיית הקירוב מכווצת אישון, וזו עובדה פיזיולוגית
        # שגם מונעת "אישון שתמיד מורחב" שנראה מסומם.
        pup = 0.14 + 0.52 * self.arousal - 0.34 * verge
        # הקדמה לפני הסטה: האישון מתרחב כבר שם.
        if i + 1 < len(self.fixes):
            nxt = self.fixes[i + 1]
            ant = self.anticipation()
            if nxt.at - ant <= t < nxt.at:
                pup += 0.18 * _ss(0.0, 1.0, (t - (nxt.at - ant)) / ant)
        for at, amt in self.reacts:
            # תגובת אישון לגירוי: מהירה, ולא מחכה להחלטה.
            pup += 0.42 * abs(amt) * _ss(at + 0.05, at + 0.30, t) * \
                (1.0 - _ss(at + 0.55, at + 1.35, t))
        pup = max(-0.6, min(1.0, pup))

        # --- פקיחה: המצמוץ **מדכא** אותה, אחרת העפעף מקבל שתי הוראות
        # מנוגדות ובמדידה יצא מצמוץ חצי. זו בדיוק המלכודת שנתפסה
        # ב-TASK 02 עם eye_wide מול blink.
        sup_l = 1.0 - min(1.0, bl)
        sup_r = 1.0 - min(1.0, br)
        # אסימטריה קבועה: עין אחת מעט יותר פקוחה מהשנייה, תמיד.
        aw = 0.06 * self.asym

        # --- העפעף הולך עם המבט האנכי (lid follow / lid lag).
        # **זה נתפס ברנדור בתקריב**: כשהמבט ירד, הקשתית ירדה אבל
        # העפעף העליון נשאר במקומו, ונפתח חצי סנטימטר של לובן מעל
        # הקשתית. התוצאה נראתה כמו עיני בובה מודבקות. בעין אמיתית
        # העפעף העליון יורד עם המבט כמעט אחד-לאחד, ועולה איתו כשהמבט
        # עולה - וזו לא קוסמטיקה אלא אותו שריר.
        follow_dn = max(0.0, -ay) * 0.42
        follow_up = max(0.0, ay) * 0.30

        ctl = {
            "eye_aim_x": ax,
            "eye_aim_y": ay,
            "eye_converge": verge * _VERGE_GAIN,
            "blink_L": bl + heavy * 0.30 + follow_dn,
            "blink_R": br + heavy * 0.30 + follow_dn,
            "squint_L": tight * 0.42 + max(0.0, aw),
            "squint_R": tight * 0.42 + max(0.0, -aw),
        }
        # --- הראש מגיע **אחרי** העיניים. זה ההבדל הגדול ביותר בין
        # דמות שמסתכלת לדמות שהראש והעיניים שלה מחוברים בבורג.
        lag = 0.11 + 0.13 * (1.0 - self.arousal)
        hx, hy = self._base_aim(max(0.0, t - lag))
        ctl["head_yaw"] = hx * 0.34
        ctl["head_pitch"] = hy * 0.22
        ctl["neck_yaw"] = hx * 0.12
        if cur.reason in ("conceal", "discomfort"):
            ctl["head_pitch"] -= 0.10      # מבט שנשבר מוריד גם את הראש

        mph = {
            "eye_wide_L": (wide + follow_up + max(0.0, aw) * 0.5) * sup_l,
            "eye_wide_R": (wide + follow_up + max(0.0, -aw) * 0.5) * sup_r,
            "lid_tighten_L": tight * (0.55 - 0.10 * self.asym),
            "lid_tighten_R": tight * (0.55 + 0.10 * self.asym),
            "pupil_dilate_L": pup,
            "pupil_dilate_R": pup * (1.0 - 0.04 * abs(self.asym)),
        }
        return {"ctl": ctl, "mph": mph}

    def solve(self, t: float) -> tuple[dict, dict]:
        r = self.raw(t)
        return acting.finalize(r["ctl"], r["mph"])

    # ------------------------------------------------------------ דיווח

    def describe(self) -> dict:
        return {
            "fixations": [{"at": f.at, "to": f.key, "why": f.reason,
                           "note": REASONS.get(f.reason, "")}
                          for f in self.fixes],
            "blinks": [round(b, 3) for b, _ in self._bl],
            "blink_period": round(self.blink_rate(), 3),
            "anticipation": round(self.anticipation(), 3),
            "reaction_latency": round(self.reaction_latency(), 3),
            "asymmetry": round(self.asym, 3),
            "openness": [round(x, 3) for x in self._openness()],
        }


# -------------------------------------------------------------- מדידות
#
# אלה אינן "דוגמאות". כל מדידה כאן מפילה **דרישה אחת** מהמשימה אם
# המימוש יחזור להיות קוסמטי.

def features(shot_len: float = 6.0, fps: int = 120) -> dict:
    """מודד את אחת-עשרה היכולות על שוט אמיתי, ומחזיר מספרים."""
    sp = ((1.30, 2.60), (3.80, 5.00))
    e = EyeActing(seed=1.0, shot_len=shot_len, valence=-0.5, arousal=0.55,
                  control=0.35, directness=0.72, hold=1.5, conceal=True,
                  speech=sp, reacts=((2.90, 1.0),), latency=0.25)
    n = int(shot_len * fps)
    ts = [i / fps for i in range(n)]
    aim = [e._base_aim(t) for t in ts]
    head = [e.raw(t)["ctl"]["head_yaw"] for t in ts]

    # 1/2. מעקב והסטות: כמה קיבועים, וכמה מטרות שונות
    keys = [f.key for f in e.fixes]
    # 3. הקדמה: האם יש תזוזה נגדית לפני הסקאדה
    ant = 0.0
    for j in range(1, len(e.fixes)):
        f = e.fixes[j]
        cur = e.fixes[j - 1].tgt
        dx = f.tgt.x - cur.x
        dy = f.tgt.y - cur.y
        nn = math.hypot(dx, dy)
        if nn < 1e-6:
            continue
        t0 = f.at - e.anticipation() * 0.08
        x0, y0 = e._base_aim(max(0.0, t0))
        # היטל התזוזה על כיוון הסקאדה הבאה — שלילי = הקדמה נגדית
        proj = ((x0 - cur.x) * dx + (y0 - cur.y) * dy) / nn
        ant = min(ant, proj)
    # 4. ריצוד: תזוזה בתוך קיבוע
    mid = []
    for j in range(1, len(e.fixes)):
        a0 = e.fixes[j - 1].at + 0.25
        a1 = e.fixes[j].at - 0.25
        if a1 - a0 > 0.25:
            mid += [t for t in ts if a0 < t < a1]
    dart = 0.0
    if len(mid) > 4:
        dx = [e.aim(t)[0] - e._base_aim(t)[0] for t in mid]
        dart = max(dx) - min(dx)
    # 5. מיקוד: טווח ההתכנסות, והפיגור אחרי הסקאדה
    vg = [e._verge(t) for t in ts]
    # 6/7. מצמוץ: אי-מחזוריות ואסימטריה
    bt = [b for b, _ in e._bl]
    gaps = [b - a for a, b in zip(bt, bt[1:])]
    lid = [e._lid(t) for t in ts]
    asym_t = max(abs(a - b) for a, b in lid)
    # 8. אישון: טווח
    pup = [e.raw(t)["mph"]["pupil_dilate_L"] for t in ts]
    # 10. תגובה מושהית
    lat = e.reaction_latency()
    # 11. הסטה לפני דיבור: הקיבוע שלפני 1.30 אינו הבית
    pre = [f for f in e.fixes if f.reason == "pre_speech"]
    # דיבור מול מבט: קורלציה בין מהירות העין לעוצמת הדיבור
    env = [1.0 if any(a <= t <= b for a, b in sp) else 0.0 for t in ts]
    spd = [e.sacc_speed(t) for t in ts]
    corr = _corr(env, spd)
    # העיניים לפני הראש: השהיית הצלב-קורלציה המיטבית
    lag_best, best = 0.0, -2.0
    for k in range(0, int(0.40 * fps)):
        c = _corr([a[0] for a in aim[:n - k]], head[k:])
        if c > best:
            best, lag_best = c, k / fps
    return {
        "fixations": len(e.fixes),
        "targets": len(set(keys)),
        "reasons": sorted({f.reason for f in e.fixes}),
        "anticipation_proj": round(ant, 5),
        "dart_range": round(dart, 5),
        "verge_range": round(max(vg) - min(vg), 4),
        "blinks": len(bt),
        "blink_gap_cv": round(_cv(gaps), 4) if len(gaps) > 2 else 0.0,
        "lid_asymmetry": round(asym_t, 5),
        "pupil_range": round(max(pup) - min(pup), 4),
        "reaction_latency": round(lat, 4),
        "pre_speech_shifts": len(pre),
        "speech_gaze_corr": round(corr, 4),
        "head_lag_sec": round(lag_best, 4),
    }


def _corr(a: list, b: list) -> float:
    n = min(len(a), len(b))
    if n < 3:
        return 0.0
    ma = sum(a[:n]) / n
    mb = sum(b[:n]) / n
    sa = math.sqrt(sum((x - ma) ** 2 for x in a[:n]))
    sb = math.sqrt(sum((x - mb) ** 2 for x in b[:n]))
    if sa < 1e-12 or sb < 1e-12:
        return 0.0
    return sum((a[i] - ma) * (b[i] - mb) for i in range(n)) / (sa * sb)


def _cv(xs: list) -> float:
    if not xs:
        return 0.0
    m = sum(xs) / len(xs)
    if abs(m) < 1e-12:
        return 0.0
    v = sum((x - m) ** 2 for x in xs) / len(xs)
    return math.sqrt(v) / abs(m)


REQUIREMENTS = [
    ("מעקב מטרה", lambda f: f["targets"] >= 2),
    ("הסטות מבט", lambda f: f["fixations"] >= 4),
    ("הקדמה לפני הסטה", lambda f: f["anticipation_proj"] < -0.004),
    ("ריצוד עיניים", lambda f: f["dart_range"] > 0.010),
    ("שינוי מיקוד", lambda f: f["verge_range"] > 0.20),
    ("תזמון מצמוץ לא-מחזורי", lambda f: f["blinks"] >= 3 and
     f["blink_gap_cv"] > 0.12),
    ("עפעפיים אסימטריים", lambda f: f["lid_asymmetry"] > 0.004),
    ("כיוון אישון וקוטר", lambda f: f["pupil_range"] > 0.20),
    ("תגובה מושהית", lambda f: f["reaction_latency"] > 0.15),
    ("מסיטה מבט לפני דיבור", lambda f: f["pre_speech_shifts"] >= 1),
    ("המבט אינו מסונכרן לדיבור", lambda f: abs(f["speech_gaze_corr"]) < 0.25),
    ("העיניים מובילות והראש מאחר", lambda f: f["head_lag_sec"] > 0.05),
]


def audit() -> dict:
    f = features()
    bad = [name for name, ok in REQUIREMENTS if not ok(f)]
    # ועוד שתיים שאינן "יכולת" אלא תקינות: הפלט חייב להיות בקרות
    # וצורות קיימות, אחרת המערכת תיפול רק ברנדור.
    e = EyeActing(seed=2.0, shot_len=3.0, speech=((0.9, 2.0),))
    try:
        for i in range(60):
            e.solve(i / 20.0)
    except Exception as exc:                        # noqa: BLE001
        bad.append(f"הפלט אינו תקף: {type(exc).__name__}: {exc}")
    # דטרמיניזם: אותו seed חייב להחזיר אותו דבר בדיוק
    c1 = EyeActing(seed=3.0, shot_len=3.0).solve(1.234)[0]
    c2 = EyeActing(seed=3.0, shot_len=3.0).solve(1.234)[0]
    if any(abs(c1[k] - c2[k]) > 1e-12 for k in c1):
        bad.append("אותו seed מחזיר פלט שונה")
    c3 = EyeActing(seed=9.0, shot_len=3.0).solve(1.234)[0]
    if all(abs(c1[k] - c3.get(k, 0.0)) < 1e-9 for k in c1):
        bad.append("seed שונה אינו משנה כלום")
    return {"ok": not bad, "problems": bad, "features": f,
            "requirements": len(REQUIREMENTS)}


def main(argv=None) -> int:
    import sys
    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(description="מערכת משחק עיניים")
    ap.add_argument("--audit", action="store_true")
    ap.add_argument("--trace", type=float, default=0.0)
    a = ap.parse_args(argv)
    if a.trace > 0:
        e = EyeActing(seed=1.0, shot_len=a.trace, valence=-0.4,
                      arousal=0.5, control=0.4, conceal=True,
                      speech=((1.2, 2.4),), reacts=((2.8, 1.0),))
        print(json.dumps(e.describe(), ensure_ascii=False, indent=1))
        return 0
    r = audit()
    print(json.dumps(r, ensure_ascii=False, indent=1))
    for name, ok in REQUIREMENTS:
        print(("  ✓ " if ok(r["features"]) else "  ✗ ") + name)
    return 0 if r["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
