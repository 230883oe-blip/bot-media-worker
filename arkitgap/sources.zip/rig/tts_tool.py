# -*- coding: utf-8 -*-
"""כלי הקראה - רץ בפייתון של הכלים (יש בו edge_tts ו-av), לא ב-venv של הבוט.

למה תהליך נפרד: `edge_tts` ו-`av` מותקנים ב-C:\\Program Files\\Python313,
ולא ב-venv שהבוט רץ בו. התקנה כפולה היא חצי ג'יגה על כונן C שכמעט מלא,
וזו בדיוק הסיבה ש-`recipes/eng_package.py` מעביר את עצמו ל-venv אחר.
כאן הכיוון הפוך: המודול `rig.voice` מריץ **את הקובץ הזה** בתהליך בן.

הפלט לכל משפט:
  <שם>.wav   - PCM 16 ביט, 16kHz, מונו. זה הפורמט שניתוח ההגאים עובד בו,
               וההמרה נעשית כאן פעם אחת כדי שה-venv לא יצטרך מפענח.
  <שם>.json  - {"text", "voice", "seconds", "bounds": [{start,end,text,kind}]}

**הגבולות הם העוגן האמיתי.** בעברית המנוע מחזיר `SentenceBoundary` ולא
`WordBoundary` (נמדד ותועד ב-speak.py), ולכן מי שהקשיב רק ל-WordBoundary
קיבל רשימה ריקה. שתי הצורות נאספות, והקורא מחליט.
"""
from __future__ import annotations

import argparse
import asyncio
import json
import sys
from pathlib import Path

VOICES = {
    "avri": "he-IL-AvriNeural",        # גברי
    "hila": "he-IL-HilaNeural",        # נשי
    "גבר": "he-IL-AvriNeural",
    "אישה": "he-IL-HilaNeural",
}

TARGET_RATE = 16000


def voice_of(name: str) -> str:
    n = (name or "").strip()
    return VOICES.get(n, n if "-" in n else VOICES["avri"])


async def _synth(text: str, voice: str, mp3: Path,
                 rate: str = "+0%", pitch: str = "+0Hz") -> list[dict]:
    import edge_tts                                   # noqa: PLC0415
    comm = edge_tts.Communicate(text, voice, rate=rate, pitch=pitch)
    bounds: list[dict] = []
    with mp3.open("wb") as fh:
        async for chunk in comm.stream():
            kind = chunk["type"]
            if kind == "audio":
                fh.write(chunk["data"])
            elif kind in ("WordBoundary", "SentenceBoundary"):
                st = chunk["offset"] / 1e7            # יחידות של 100ns
                du = chunk["duration"] / 1e7
                bounds.append({"start": round(st, 4),
                               "end": round(st + du, 4),
                               "text": chunk.get("text", ""),
                               "kind": "sentence" if kind == "SentenceBoundary"
                                       else "word"})
    return bounds


def _to_wav(mp3: Path, wav: Path) -> float:
    """ממיר ל-PCM מונו 16kHz ומחזיר אורך בשניות. PyAV, לא ffmpeg כתהליך."""
    import av                                          # noqa: PLC0415
    import numpy as np                                 # noqa: PLC0415

    cont = av.open(str(mp3))
    stream = next(s for s in cont.streams if s.type == "audio")
    rs = av.AudioResampler(format="s16", layout="mono", rate=TARGET_RATE)
    parts: list = []
    for frame in cont.decode(stream):
        for out in rs.resample(frame):
            parts.append(out.to_ndarray().reshape(-1))
    for out in rs.resample(None):                      # ניקוז המשאב
        parts.append(out.to_ndarray().reshape(-1))
    cont.close()
    data = (np.concatenate(parts) if parts
            else np.zeros(0, dtype="int16")).astype("int16")

    import wave                                        # noqa: PLC0415
    with wave.open(str(wav), "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(TARGET_RATE)
        wf.writeframes(data.tobytes())
    return round(len(data) / TARGET_RATE, 4)


def render(text: str, voice: str, stem: Path,
           rate: str = "+0%", pitch: str = "+0Hz") -> dict:
    stem.parent.mkdir(parents=True, exist_ok=True)
    mp3 = stem.with_suffix(".mp3")
    wav = stem.with_suffix(".wav")
    bounds = asyncio.run(_synth(text, voice_of(voice), mp3, rate, pitch))
    seconds = _to_wav(mp3, wav)
    mp3.unlink(missing_ok=True)                        # ה-wav הוא המקור מכאן
    meta = {"text": text, "voice": voice_of(voice), "seconds": seconds,
            "rate": TARGET_RATE, "bounds": bounds}
    stem.with_suffix(".json").write_text(
        json.dumps(meta, ensure_ascii=False, indent=1), encoding="utf-8")
    return meta


def main(argv=None) -> int:
    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(description="הקראה עברית -> wav + גבולות")
    ap.add_argument("--jobs", help="קובץ JSON: [{text, voice, stem}]")
    ap.add_argument("--text", default="")
    ap.add_argument("--voice", default="avri")
    ap.add_argument("--stem", default="")
    ap.add_argument("--rate", default="+0%")
    ap.add_argument("--pitch", default="+0Hz")
    a = ap.parse_args(argv)

    jobs = []
    if a.jobs:
        jobs = json.loads(Path(a.jobs).read_text(encoding="utf-8"))
    elif a.text and a.stem:
        jobs = [{"text": a.text, "voice": a.voice, "stem": a.stem}]
    else:
        ap.error("חסר --jobs או --text+--stem")

    done = []
    for j in jobs:
        stem = Path(j["stem"])
        if stem.with_suffix(".wav").exists() and \
                stem.with_suffix(".json").exists() and not j.get("force"):
            print(f"  קיים: {stem.name}")
            done.append(str(stem))
            continue
        m = render(j["text"], j.get("voice", "avri"), stem,
                   j.get("rate", a.rate), j.get("pitch", a.pitch))
        print(f"  {stem.name}: {m['seconds']}ש · {len(m['bounds'])} גבולות")
        done.append(str(stem))
    print(f"סה\"כ {len(done)} קבצים")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
