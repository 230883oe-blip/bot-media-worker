# -*- coding: utf-8 -*-
"""ממשק ARKit-52 תקני אל ריג הפנים הקיים.

למה זה נכתב. הריג כאן כבר מחזיק 40 יחידות תנועה עם קודי FACS אמיתיים
(`acting.AUS`), 27 blendshapes אנליטיים (`face`) ו-85 בקרות
(`controls.CONTROLS`) - אבל כולם בשמות **פרטיים** של הפרויקט
(`nose_sneer_L`, `lip_pucker`, `brow_inner_up_L`). כלי לכידת פנים
בתעשייה - ARKit של אפל, MediaPipe, MetaHuman, Live Link Face - כולם
מדברים שפה אחת: **52 השמות של `ARFaceAnchor.BlendShapeLocation`**.
`studio.baseline._p_face` מדד את הפער הזה במפורש וקרא לו "פער אמיתי".

מה המודול הזה עושה, ומה הוא **לא** עושה:

* **הוא לא מסנתז גאומטריה.** אין כאן אף דלתא חדשה ואף נוסחת עיוות.
  כל 52 המשבצות מצביעות אל יחידות שכבר קיימות ונמדדו, או מוצהרות
  נעדרות. זו הייתה המלצתם הנפרדת של שני יועצים (Command A, Qwen 3.8),
  ומאותו נימוק בדיוק: **משבצת שקיימת ואינה מזיזה דבר גרועה ממשבצת
  נעדרת**, כי כלי לכידה יניע אותה, לא יקבל שגיאה, ויניח שהתנועה קרתה.
* **הוא לא מחליף את סינכרון השפתיים.** `speech`/`voice` גוזרים ויזמות
  מפורמנטים אמיתיים של עברית (דיוק הברות נמדד 10/10). Rhubarb הוא
  פונמות אנגלית בלבד, כלומר נסיגה כאן ולא שדרוג.

## שלושה מצבים, ולא שניים

`exact`  - למשבצת יש מקבילה ישירה ונפרדת לאותו צד.
`shared` - היא **כן מזיזה** את הפנים, אבל היעד אינו מופרד לצדדים
           (`mouth_dimple` הוא צורה אחת, `eye_aim_y` הוא בקרה אחת
           לשתי העיניים). כלומר שמאל וימין אינם יכולים להיות שונים.
           זו מגבלה אמיתית ולכן היא מוצהרת, ולא מוסתרת מתחת ל-exact.
`absent` - שום דבר בריג אינו מניע אותה. היא **אינה** נפלטת כמטרת
           morph, כדי שהצד הצורך יראה חוסר ולא ישקר לעצמו.

## הכלל המתמטי שמחזיק את `shared`

שתי משבצות ARKit שחולקות יעד אחד מקבלות מקדם **0.5 כל אחת**, ולכן
שתיהן על 1.0 נותנות בדיוק 1.0 ביעד - ולא 2.0 שהיה נחתך בהידוק
ושובר כל עקומה שמעליו. `audit` נועל את זה: סכום המקדמים על יעד
משותף חייב להיות 1.0.

משבצות **נגדיות** (jawLeft מול jawRight, eyeLookUp מול eyeLookDown)
הן מקרה אחר: הן יושבות על בקרה דו-כיוונית ולכן מקדמיהן ±, והסכום
האלגברי שלהן הוא אפס. זו התנהגות נכונה - לכידה שמדווחת שמאל וימין
יחד מתארת לסת במרכז.

## eyeLookIn - למה הוא לא `approx`

התכנסות מבט אינה סיבוב אופקי של שתי העיניים לאותו כיוון, ולכן מיפוי
ל-`eye_aim_x` לבדו היה שגוי. `eyeLookInLeft` מקבל `eye_aim_x=-0.5`
**וגם** `eye_converge=+0.5`, ו-`eyeLookInRight` את ההופכי ב-x ואת
אותו converge. שתיהן על 1.0: המבט האופקי מתאפס וההתכנסות מגיעה
ל-1.0 - שזה בדיוק פזילה פנימה. הבקרה `eye_converge` כבר הייתה כאן.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from . import controls, face

# --------------------------------------------------------------- התקן
#
# 52 השמות של `ARFaceAnchor.BlendShapeLocation`, בסדר ובאיות של אפל.
# זו **רשימת התקן עצמה** ואין בה שום בחירה שלי - היא קיימת כאן כדי
# ש-`audit` יוכל לנעול שאף שם לא הומצא ואף שם לא נשמט.
ARKIT_52: tuple[str, ...] = (
    # עיניים (14)
    "eyeBlinkLeft", "eyeLookDownLeft", "eyeLookInLeft", "eyeLookOutLeft",
    "eyeLookUpLeft", "eyeSquintLeft", "eyeWideLeft",
    "eyeBlinkRight", "eyeLookDownRight", "eyeLookInRight", "eyeLookOutRight",
    "eyeLookUpRight", "eyeSquintRight", "eyeWideRight",
    # לסת (4)
    "jawForward", "jawLeft", "jawRight", "jawOpen",
    # פה ושפתיים (23)
    "mouthClose", "mouthFunnel", "mouthPucker", "mouthLeft", "mouthRight",
    "mouthSmileLeft", "mouthSmileRight", "mouthFrownLeft", "mouthFrownRight",
    "mouthDimpleLeft", "mouthDimpleRight",
    "mouthStretchLeft", "mouthStretchRight",
    "mouthRollLower", "mouthRollUpper",
    "mouthShrugLower", "mouthShrugUpper",
    "mouthPressLeft", "mouthPressRight",
    "mouthLowerDownLeft", "mouthLowerDownRight",
    "mouthUpperUpLeft", "mouthUpperUpRight",
    # גבות (5)
    "browDownLeft", "browDownRight", "browInnerUp",
    "browOuterUpLeft", "browOuterUpRight",
    # לחיים (3)
    "cheekPuff", "cheekSquintLeft", "cheekSquintRight",
    # אף (2)
    "noseSneerLeft", "noseSneerRight",
    # לשון (1)
    "tongueOut",
)

#: הקבוצות של התקן, לדיווח בלבד.
GROUPS: dict[str, str] = {}
for _n in ARKIT_52:
    GROUPS[_n] = ("eye" if _n.startswith("eye") else
                  "jaw" if _n.startswith("jaw") else
                  "mouth" if _n.startswith("mouth") else
                  "brow" if _n.startswith("brow") else
                  "cheek" if _n.startswith("cheek") else
                  "nose" if _n.startswith("nose") else "tongue")


# --------------------------------------------------------------- המשבצת


@dataclass(frozen=True)
class Slot:
    """משבצת ARKit אחת והיעדים שהיא מניעה בריג הזה."""

    arkit: str
    kind: str                                    # exact / shared / absent
    ctl: dict[str, float] = field(default_factory=dict)
    mph: dict[str, float] = field(default_factory=dict)
    note: str = ""

    @property
    def group(self) -> str:
        return GROUPS[self.arkit]

    @property
    def driven(self) -> bool:
        return self.kind != "absent"


SLOTS: dict[str, Slot] = {}


def _slot(arkit: str, kind: str, ctl=None, mph=None, note=""):
    SLOTS[arkit] = Slot(arkit, kind, dict(ctl or {}), dict(mph or {}), note)


# ---- עיניים
# עצימה והצרה הן בקרות עצם נפרדות לכל עין, ולכן exact.
for _s, _ak in (("L", "Left"), ("R", "Right")):
    _slot(f"eyeBlink{_ak}", "exact", ctl={f"blink_{_s}": 1.0})
    _slot(f"eyeSquint{_ak}", "exact", ctl={f"squint_{_s}": 1.0})
    # פקיחה רחבה היא צורה (AU5) ויש לה שתי גרסאות צד.
    _slot(f"eyeWide{_ak}", "exact", mph={f"eye_wide_{_s}": 1.0})

# כיוון המבט: בקרה אחת לשתי העיניים, ולכן shared ובמקדם חצי.
_LOOK_NOTE = "המבט הוא בקרה אחת לשתי העיניים; צד אחד אינו זז לבד"
_slot("eyeLookUpLeft", "shared", ctl={"eye_aim_y": 0.5}, note=_LOOK_NOTE)
_slot("eyeLookUpRight", "shared", ctl={"eye_aim_y": 0.5}, note=_LOOK_NOTE)
_slot("eyeLookDownLeft", "shared", ctl={"eye_aim_y": -0.5}, note=_LOOK_NOTE)
_slot("eyeLookDownRight", "shared", ctl={"eye_aim_y": -0.5}, note=_LOOK_NOTE)
# פנימה = אל האף, ולכן גם התכנסות. `eye_aim_x` חיובי = מבט שמאלה.
_IN_NOTE = "פנימה = אל האף: חצי סיבוב אופקי וחצי התכנסות"
_slot("eyeLookInLeft", "shared",
      ctl={"eye_aim_x": -0.5, "eye_converge": 0.5}, note=_IN_NOTE)
_slot("eyeLookInRight", "shared",
      ctl={"eye_aim_x": 0.5, "eye_converge": 0.5}, note=_IN_NOTE)
_slot("eyeLookOutLeft", "shared", ctl={"eye_aim_x": 0.5}, note=_LOOK_NOTE)
_slot("eyeLookOutRight", "shared", ctl={"eye_aim_x": -0.5}, note=_LOOK_NOTE)

# ---- לסת
# `jaw_fwd` נרשמה ב-TASK 01 ומעולם לא הזיזה דבר (דחיפה אינה סיבוב);
# מה שמזיז בפועל הוא הצורה `jaw_thrust`. לכן היא היעד.
_slot("jawForward", "exact", mph={"jaw_thrust": 1.0})
_slot("jawOpen", "exact", ctl={"jaw_open": 1.0})
_slot("jawLeft", "exact", ctl={"jaw_side": 1.0})
_slot("jawRight", "exact", ctl={"jaw_side": -1.0})

# ---- פה ושפתיים
_slot("mouthFunnel", "exact", mph={"lip_funnel": 1.0})
_slot("mouthPucker", "exact", mph={"lip_pucker": 1.0})
for _s, _ak in (("L", "Left"), ("R", "Right")):
    _slot(f"mouthSmile{_ak}", "exact",
          ctl={f"smile_{_s}": 1.0}, mph={f"mouth_corner_up_{_s}": 1.0})
    _slot(f"mouthFrown{_ak}", "exact", mph={f"mouth_corner_down_{_s}": 1.0})
    _slot(f"mouthUpperUp{_ak}", "exact", mph={f"lip_up_raise_{_s}": 1.0})
_UNSIDED = "הצורה בריג אינה מופרדת לצדדים; שמאל וימין נעים יחד"
_slot("mouthDimpleLeft", "shared", mph={"mouth_dimple": 0.5}, note=_UNSIDED)
_slot("mouthDimpleRight", "shared", mph={"mouth_dimple": 0.5}, note=_UNSIDED)
_slot("mouthStretchLeft", "shared", mph={"mouth_stretch": 0.5}, note=_UNSIDED)
_slot("mouthStretchRight", "shared", mph={"mouth_stretch": 0.5}, note=_UNSIDED)
_slot("mouthPressLeft", "shared", mph={"lip_press": 0.5}, note=_UNSIDED)
_slot("mouthPressRight", "shared", mph={"lip_press": 0.5}, note=_UNSIDED)
_slot("mouthLowerDownLeft", "shared",
      mph={"lip_lo_depress": 0.5}, note=_UNSIDED)
_slot("mouthLowerDownRight", "shared",
      mph={"lip_lo_depress": 0.5}, note=_UNSIDED)

# 08/10 - שבע המשבצות שהיו `absent`. הפער לא היה במיפוי אלא
# ב**גאומטריה**: לא הייתה בריג שום צורה שעושה את מה שהן מתארות. שבע
# הצורות נבנו ב-`face.py` (בסוף `_SHAPES`, כדי לא להזיז אינדקס קיים
# ב-GLB), וכאן הן רק מחוברות. כולן `exact`: לכל משבצת יעד משלה, ואין
# כאן שום יעד משותף - ולכן גם סכומי ה-`shared` בשער לא נוגעו.
_slot("mouthClose", "exact", mph={"mouth_close": 1.0})
# הזזת הפה לרוחב היא **לא** `jaw_side` (זו הלסת, והפה נסחב איתה).
# שני יעדים נפרדים ולא אחד עם סימן: `drive` מהדק morph ל-[0,1], ומקדם
# שלילי היה נחתך לאפס - כלומר משבצת מתה בשקט. ראה `face._mouth_shift`.
_slot("mouthLeft", "exact", mph={"mouth_shift_L": 1.0})
_slot("mouthRight", "exact", mph={"mouth_shift_R": 1.0})
_slot("mouthRollLower", "exact", mph={"lip_roll_lo": 1.0})
_slot("mouthRollUpper", "exact", mph={"lip_roll_up": 1.0})
_slot("mouthShrugLower", "exact", mph={"lip_shrug_lo": 1.0})
_slot("mouthShrugUpper", "exact", mph={"lip_shrug_up": 1.0})

# ---- גבות
for _s, _ak in (("L", "Left"), ("R", "Right")):
    _slot(f"browDown{_ak}", "exact", ctl={f"brow_furrow_{_s}": 1.0})
    _slot(f"browOuterUp{_ak}", "exact", ctl={f"brow_outer_up_{_s}": 1.0})
# browInnerUp הוא משבצת **אחת** בתקן, ולכן הוא מניע את שני הצדדים
# במלוא המשקל. זה לא `shared`: אין משבצת שנייה שחולקת את היעד.
_slot("browInnerUp", "exact",
      ctl={"brow_inner_up_L": 1.0, "brow_inner_up_R": 1.0})

# ---- לחיים
_slot("cheekPuff", "exact",
      ctl={"cheek_puff_L": 1.0, "cheek_puff_R": 1.0})
# cheekSquint של ARKit הוא AU6 - מרים הלחיים, והוא קיים כצורת צד.
for _s, _ak in (("L", "Left"), ("R", "Right")):
    _slot(f"cheekSquint{_ak}", "exact", mph={f"cheek_raise_{_s}": 1.0})
    _slot(f"noseSneer{_ak}", "exact", mph={f"nose_sneer_{_s}": 1.0})

# ---- לשון
_slot("tongueOut", "exact", ctl={"tongue_out": 1.0})


# --------------------------------------------------------------- שאילתות


def supported() -> list[str]:
    """המשבצות שמניעות משהו בפועל, בסדר התקן."""
    return [n for n in ARKIT_52 if SLOTS[n].driven]


def absent() -> list[str]:
    """המשבצות שאין להן מנוע. הצד הצורך חייב לראות אותן כחסרות."""
    return [n for n in ARKIT_52 if not SLOTS[n].driven]


def of_kind(kind: str) -> list[str]:
    return [n for n in ARKIT_52 if SLOTS[n].kind == kind]


def coverage() -> dict:
    """כמה מהתקן מכוסה, לפי מצב ולפי קבוצה."""
    per: dict[str, dict[str, int]] = {}
    for n in ARKIT_52:
        g = per.setdefault(GROUPS[n], {"exact": 0, "shared": 0, "absent": 0})
        g[SLOTS[n].kind] += 1
    drv = len(supported())
    return {"standard": len(ARKIT_52),
            "driven": drv,
            "exact": len(of_kind("exact")),
            "shared": len(of_kind("shared")),
            "absent": len(of_kind("absent")),
            "ratio": round(drv / len(ARKIT_52), 4),
            "per_group": per}


# --------------------------------------------------------------- ההנעה


def _clamp_ctl(name: str, v: float) -> float:
    spec = controls.CONTROLS.get(name)
    if not spec:
        return v
    lo, hi = float(spec[0]), float(spec[1])
    return lo if v < lo else hi if v > hi else v


def drive(weights: dict[str, float], *,
          strict: bool = False) -> tuple[dict[str, float], dict[str, float]]:
    """משקולות ARKit (0..1) -> (בקרות, צורות פנים) של הריג הזה.

    זו כל נקודת הכניסה: המתקשר מעביר ערכים בשמות התקן, בלי לדעת דבר
    על השמות הפרטיים כאן ובלי לגעת בשום גאומטריה.

    ``strict=True`` זורק על שם שאינו בתקן. ברירת המחדל מדלגת, כי
    ספקי לכידה מוסיפים שדות משלהם (``headPitch``, ``_neutral``) ולא
    נכון להפיל פריים שלם בגלל שדה נוסף שאינו מזיק.
    """
    ctl: dict[str, float] = {}
    mph: dict[str, float] = {}
    for name, w in (weights or {}).items():
        slot = SLOTS.get(name)
        if slot is None:
            if strict:
                raise KeyError(f"{name!r} אינו שם ARKit תקני")
            continue
        try:
            w = float(w)
        except (TypeError, ValueError):
            if strict:
                raise ValueError(f"משקולת לא מספרית ל-{name!r}: {w!r}")
            continue
        # משקולת ARKit היא 0..1 מעצם הגדרתה. מספר שלילי אינו "כיוון
        # הפוך" - הוא קלט פגום, והכיוון מיוצג במשבצת הנגדית.
        if w <= 0.0:
            continue
        w = min(w, 1.0)
        for k, c in slot.ctl.items():
            ctl[k] = ctl.get(k, 0.0) + c * w
        for k, c in slot.mph.items():
            mph[k] = mph.get(k, 0.0) + c * w
    ctl = {k: _clamp_ctl(k, v) for k, v in ctl.items()}
    mph = {k: (0.0 if v < 0.0 else 1.0 if v > 1.0 else v)
           for k, v in mph.items()}
    return ctl, mph


def targets() -> list[str]:
    """שמות מטרות ה-morph שראוי לפלוט ל-GLB תחת שמות התקן.

    רק משבצות שבאמת מזיזות גאומטריה. משבצת שכל יעדיה בקרות עצם
    (עצימה, לסת, מבט) אינה מטרת morph, ומשבצת נעדרת אינה נפלטת
    בכלל - זה כל העניין.
    """
    return [n for n in ARKIT_52 if SLOTS[n].mph]


# --------------------------------------------------------------- השער


def audit() -> dict:
    """נועל שלא הומצא כאן שום דבר. כל כשל הוא שורה ב-``problems``."""
    problems: list[str] = []

    # 1 · התקן שלם, בלי כפילות ובלי שם שנשמט.
    if len(ARKIT_52) != 52:
        problems.append(f"התקן הוא 52 שמות, יש כאן {len(ARKIT_52)}")
    if len(set(ARKIT_52)) != len(ARKIT_52):
        problems.append("יש שם כפול ברשימת התקן")
    missing = [n for n in ARKIT_52 if n not in SLOTS]
    if missing:
        problems.append(f"שמות תקן בלי משבצת: {missing}")
    extra = [n for n in SLOTS if n not in ARKIT_52]
    if extra:
        problems.append(f"משבצות שאינן בתקן: {extra}")

    # 2 · אף יעד אינו מומצא. זה הסעיף שבגללו הקובץ הזה קיים.
    bad_ctl = sorted({k for s in SLOTS.values() for k in s.ctl
                      if k not in controls.CONTROLS})
    bad_mph = sorted({k for s in SLOTS.values() for k in s.mph
                      if k not in face.NAMES})
    if bad_ctl:
        problems.append(f"בקרות שאינן קיימות: {bad_ctl}")
    if bad_mph:
        problems.append(f"צורות שאינן קיימות: {bad_mph}")

    # 3 · מצב חוקי, ואין משבצת "קיימת אך מתה".
    for n, s in SLOTS.items():
        if s.kind not in ("exact", "shared", "absent"):
            problems.append(f"{n}: מצב לא חוקי {s.kind!r}")
        if s.driven and not (s.ctl or s.mph):
            problems.append(f"{n}: מוצהר {s.kind} ואינו מניע דבר")
        if not s.driven and (s.ctl or s.mph):
            problems.append(f"{n}: מוצהר נעדר אך יש לו יעד")
        if not s.driven and not s.note:
            problems.append(f"{n}: נעדר בלי הסבר")

    # 4 · יעד משותף: סכום המקדמים בדיוק 1.0, אחרת שתי משבצות על
    #     1.0 נותנות 2.0 ונחתכות בהידוק.
    shares: dict[str, list[float]] = {}
    for s in SLOTS.values():
        if s.kind != "shared":
            continue
        for k, c in list(s.ctl.items()) + list(s.mph.items()):
            shares.setdefault(k, []).append(c)
    for k, cs in shares.items():
        tot = sum(cs)
        # נגדיות מתאפסות (±0.5), משותפות־באותו־כיוון מצטברות ל-1.0.
        if len(cs) > 1 and not (abs(tot - 1.0) < 1e-9 or abs(tot) < 1e-9):
            problems.append(f"יעד משותף {k}: סכום מקדמים {tot}")

    # 5 · הנעה מלאה אינה חורגת מהטווח הרשום של אף בקרה.
    full = {n: 1.0 for n in supported()}
    ctl, mph = drive(full)
    for k, v in ctl.items():
        spec = controls.CONTROLS.get(k)
        # בקרה שאינה קיימת כבר נרשמה בסעיף 2. **לגשת אליה כאן
        # במפתח ישיר היה זורק `KeyError` במקום להחזיר דוח** -
        # כלומר שער שקורס בדיוק במקרה שהוא נבנה לתפוס, והמתקשר
        # רואה חריגה ולא "בעיה". נתפס ב-`test_rig.t_arkit`.
        if spec is None:
            continue
        lo, hi = float(spec[0]), float(spec[1])
        if v < lo - 1e-9 or v > hi + 1e-9:
            problems.append(f"{k}={v} מחוץ לטווח [{lo},{hi}]")
    for k, v in mph.items():
        if v < 0.0 - 1e-9 or v > 1.0 + 1e-9:
            problems.append(f"צורה {k}={v} מחוץ ל-[0,1]")

    cov = coverage()
    return {"problems": problems, "ok": not problems,
            "coverage": cov,
            "ctl_touched": len(ctl), "mph_touched": len(mph),
            "morph_targets": len(targets()),
            "absent": absent()}


def describe() -> str:
    cov = coverage()
    out = [f"ARKit-52: {cov['driven']}/52 מונעים "
           f"({cov['exact']} מדויקים, {cov['shared']} משותפי־צד, "
           f"{cov['absent']} נעדרים)"]
    for g, d in cov["per_group"].items():
        out.append(f"  {g:7s} מדויק={d['exact']:2d} משותף={d['shared']:2d} "
                   f"נעדר={d['absent']:2d}")
    if absent():
        out.append("  נעדרים: " + ", ".join(absent()))
    return "\n".join(out)


def main():
    import json
    print(describe())
    a = audit()
    print()
    print("שער:", "עבר" if a["ok"] else "נפל")
    for p in a["problems"]:
        print("  ✗", p)
    print(json.dumps({k: v for k, v in a.items() if k != "coverage"},
                     ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
