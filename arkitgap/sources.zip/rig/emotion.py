# -*- coding: utf-8 -*-
r"""
מנוע רגש — TASK 03.

מה הוא עושה, במשפט אחד: **לפני** שנבנית אנימציה, מחושב מה הדמות יודעת,
רוצה, מרגישה, מסתירה, במי היא מסתכלת ומה השתנה אצלה בשוט — ומכל אלה
נגזרת ההופעה. הדמות לא מבצעת את הדיאלוג; היא מבצעת את המשמעות שמתחתיו.

הצינור, בדיוק כפי שנדרש:

    Situation (knows/wants/feels/hides/looks_at/change)
        -> emotion     (הרגש האמיתי, בשם ובעוצמה)
        -> intention   (מה היא *עושה* לבן השיח: מתגוננת? בודקת? מפייסת?)
        -> gaze        (לאן, כמה ישר, וכמה היא מחזיקה מבט)
        -> face        (רשימת Expression של acting.py, לא ערך אחד)
        -> body        (עמוד שדרה, כתפיים, נשימה)
        -> gesture     (ידיים — ואין תנועה בלי כוונה שמייצרת אותה)
        -> timing      (מהירות, השהיית תגובה, אסימטריה)

--------------------------------------------------------------------------
העיקרון שהופך את זה למנוע ולא לטבלה: הסתרה היא שתי שכבות, לא אחת
--------------------------------------------------------------------------
אדם שמנסה להסתיר רגש **לא מראה פנים ניטרליות** — הוא מראה *מסכה*
(הבעה אחרת, שנבחרה ברצון) שמתוכה **נוזל** הרגש האמיתי. הנזילה אינה
אקראית: לשריר הפה יש שליטה רצונית (אפשר לחייך בהזמנה), ולשלושה
אזורים אין כמעט שליטה כזו —

  * הגבה הפנימית (AU1, frontalis מדיאלי) — הסימן המובהק של צער,
    וכמעט אי אפשר להרים אותה בכוונה.
  * כיווץ העפעף (AU7) והיעדר חיוך-דושן (AU6) — חיוך מנומס מזיז את
    הפה בלבד; חיוך אמיתי מכווץ את העין.
  * האישון והמיקרו-תנועות — מערכת אוטונומית לגמרי.

לכן `hides` כאן אינו דגל שמנמיך עוצמה. הוא **מפצל** את ההבעה:
`mask` בעוצמה מלאה על אזורי השליטה, ו-`leak` בעוצמה נמוכה על אזורי
חוסר-השליטה. בלי הפיצול הזה "הסתרה" הייתה נראית בדיוק כמו "רגש חלש",
וזו הייתה הופכת את כל המשימה לשינוי מספר.

ושלוש תוצאות נוספות שנגזרות ולא נכתבות ביד:
  * **מה שמוסתר מעכב.** הסתרה דורשת עיבוד, ולכן `timing.delay` גדל.
    זו בדיוק ה"delayed reaction" שנדרשה בחשד.
  * **מה שמוסתר אינו סימטרי.** שליטה רצונית חלקית נופלת על צד אחד,
    ולכן `timing.bias` גדל (חיוך מזויף הוא אסימטרי — זה נמדד בבני אדם).
  * **מה שמוסתר לא מחזיק מבט.** `gaze.hold` קטן: אדם שמסתיר בודק
    אם קנו לו את זה, ואז מסיט.

--------------------------------------------------------------------------
`knows` אינו קישוט — הוא מחליף את הכוונה
--------------------------------------------------------------------------
אותו רגש בדיוק, עם פער ידע הפוך, הוא הופעה אחרת:

  * יודעת **יותר** מבן השיח -> הכוונה היא `withhold`/`test`: מבט ישר
    וארוך, פחות תנועה, מהירות נמוכה. שקט הוא כוח.
  * יודעת **פחות** -> `seek`: מבט מחפש, ראש נע, גבות מורמות, מהירות
    גבוהה. חיפוש מידע נראה כתנועה.

זה מה שהופך את `knows` לשדה פעיל ולא למטא-דאטה.

הרצה:
    python -m rig.emotion                 הדגמה של כל התרחישים
    python -m rig.emotion --audit         בדיקת שלמות המנוע
"""

from __future__ import annotations

import argparse
import json
import math
from dataclasses import dataclass, field, replace

from . import acting

# ------------------------------------------------------------------ רגשות
#
# הרגש אינו "שם של הבעה". הוא נקודה בשלושה מדדים שנמדדים בפסיכולוגיה
# של רגש, ומהם נגזרת ההתנהגות:
#   valence  (-1..1)  נעים / לא נעים
#   arousal  ( 0..1)  כמה אנרגיה יש בגוף
#   control  ( 0..1)  כמה הדמות מרגישה שהמצב בידה
#
# `control` הוא זה שמבדיל בין כעס לפחד באותם valence/arousal בדיוק:
# כעס הוא שלילי+ער+**בשליטה**, פחד הוא שלילי+ער+**בלי שליטה**. בלי
# המדד הזה שניהם היו מקבלים אותה שפת גוף, וזו טעות שנראית מיד.

@dataclass(frozen=True)
class Emotion:
    name: str
    valence: float
    arousal: float
    control: float
    face: tuple[str, ...]        # הבעות מ-acting.EXPRESSIONS
    note: str = ""


def _em(name, valence, arousal, control, face, note=""):
    EMOTIONS[name] = Emotion(name, valence, arousal, control, tuple(face), note)
    return EMOTIONS[name]


EMOTIONS: dict[str, Emotion] = {}

_em("surprise", 0.05, 0.92, 0.30, ("surprise",),
    "לא נעים ולא נעים - הפתעה היא ער מאוד ובלי שליטה")
_em("fear", -0.70, 0.88, 0.12, ("flinch", "surprise"),
    "אותו arousal כמו כעס, אבל control נמוך - וזה כל ההבדל")
_em("anger", -0.62, 0.84, 0.80, ("contempt", "concentration"),
    "שלילי, ער, **ובשליטה** - ולכן הגוף נפתח ולא מתכנס")
_em("sadness", -0.72, 0.22, 0.25, ("sadness",),
    "arousal נמוך הוא מה שהופך אותו לאיטי, ולא הוראת מהירות")
_em("shame", -0.65, 0.40, 0.18, ("sadness", "discomfort"), "")
_em("guilt", -0.58, 0.45, 0.30, ("sadness", "doubt"), "")
_em("contempt", -0.35, 0.40, 0.85, ("contempt",), "")
_em("suspicion", -0.25, 0.55, 0.70, ("suspicion",), "")
_em("doubt", -0.12, 0.45, 0.40, ("doubt",), "")
_em("curiosity", 0.30, 0.60, 0.55, ("interest",), "")
_em("interest", 0.35, 0.52, 0.60, ("interest",), "")
_em("amusement", 0.72, 0.62, 0.72, ("amusement",), "")
_em("joy", 0.85, 0.70, 0.75, ("amusement",), "")
_em("affection", 0.70, 0.35, 0.65, ("polite_smile", "amusement"), "")
_em("relief", 0.55, 0.28, 0.60, ("relief",), "")
_em("pride", 0.62, 0.48, 0.88, ("polite_smile", "concentration"), "")
_em("discomfort", -0.40, 0.48, 0.35, ("discomfort",), "")
_em("fatigue", -0.20, 0.12, 0.40, ("fatigue",), "")
_em("realization", 0.10, 0.62, 0.50, ("realization",), "")
_em("neutral", 0.0, 0.25, 0.60, (), "אין הבעה - וזה לגיטימי")


# ------------------------------------------------------------- מה מסתירים
#
# המסכה היא מה ש**אנשים באמת עושים** כשהם מסתירים רגש, ולא ההיפוך
# המתמטי שלו. מי שמסתיר עצב לא מראה שמחה - הוא מראה חיוך מנומס
# ו/או ריכוז ("אני בסדר, אני עסוק"). ההיפוך נראה כשחקן גרוע.

MASK_FOR = {
    "sadness":    ("polite_smile", "concentration"),
    "shame":      ("polite_smile", "concentration"),
    "guilt":      ("concentration", "polite_smile"),
    "fear":       ("concentration", "polite_smile"),
    "anger":      ("polite_smile", "concentration"),
    "contempt":   ("polite_smile",),
    "suspicion":  ("interest",),
    "doubt":      ("interest", "polite_smile"),
    "discomfort": ("polite_smile",),
    "fatigue":    ("interest", "concentration"),
    "amusement":  ("lip_press_mask",),     # לעצור צחוק = ללחוץ שפתיים
    "joy":        ("lip_press_mask",),
    "affection":  ("polite_smile",),
    "relief":     ("concentration",),
    "pride":      ("polite_smile",),
    "curiosity":  ("polite_smile",),
    "interest":   ("polite_smile",),
    "surprise":   ("concentration",),
    "realization": ("concentration",),
}

# "לעצור צחוק" אינה הבעה קיימת ב-acting, והיא שונה מהותית מחיוך
# מנומס: החיוך *מוסיף* תנועה, והעצירה *עוצרת* אותה. לכן היא נבנית
# כאן מאותן יחידות תנועה, ולא מועתקת מהבעה אחרת.
if "lip_press_mask" not in acting.EXPRESSIONS:
    acting.EXPRESSIONS["lip_press_mask"] = acting.Expression(
        "lip_press_mask",
        [acting.Beat("lip_press", 0.80, 0.00, 0.00, 0.13, 0.80, 0.35),
         acting.Beat("dimple", 0.35, 0.22, 0.05, 0.16, 0.70, 0.40),
         acting.Beat("cheek_raise", 0.28, 0.18, 0.08, 0.20, 0.70, 0.45),
         acting.Beat("lid_tighten", 0.22, 0.00, 0.10, 0.22, 0.60, 0.45)],
        0.95, "עצירת צחוק: שפתיים נלחצות, והלחיים בכל זאת עולות")

# אזורי הנזילה: מה שאדם **לא** מצליח לדכא. הערך הוא כמה מהרגש
# האמיתי עובר שם בכל זאת.
LEAK_REGIONS = {"brows": 0.42, "eyelids": 0.34, "gaze": 0.30,
                "nose": 0.22, "cheeks": 0.18}
# ומה שכן מצליחים לדכא: הפה, הלסת, הלשון, הראש. הם נשלטים.
CONTROLLED_REGIONS = {"mouth", "lips", "jaw", "tongue", "head"}


# ------------------------------------------------------------- המצב בשוט

@dataclass
class Situation:
    """ששת השדות שנשאלים **לפני** שנבנית אנימציה."""
    knows: str = ""                # מה היא יודעת
    wants: str = ""                # מה היא רוצה
    feels: str = "neutral"         # מה היא מרגישה באמת (שם רגש)
    hides: str = ""                # מה היא מנסה להסתיר (שם רגש, או "")
    looks_at: str = "partner"      # partner | away | down | object | inward | audience
    change: str = ""               # מה השתנה רגשית: "<מרגש>-><לרגש>" או שם רגש
    # פער הידע מול בן השיח: 1 = היא יודעת יותר, -1 = פחות, 0 = שווה.
    knows_more: float = 0.0
    # עד כמה היא רוצה את מה שהיא רוצה. זה מה שהופך wants למשפיע.
    want_strength: float = 0.6
    intensity: float = 1.0         # עוצמת הרגש הכוללת
    shot_len: float = 3.0          # אורך השוט בשניות
    line: str = ""                 # הדיאלוג, אם יש. לא מבוצע - רק הקשר.

    def feel(self) -> Emotion:
        return EMOTIONS.get(self.feels) or EMOTIONS["neutral"]

    def hidden(self) -> Emotion | None:
        return EMOTIONS.get(self.hides) if self.hides else None


# ------------------------------------------------------------ שכבות הפלט

@dataclass
class Gaze:
    target: str          # לאן
    directness: float    # 0 = מסיטה לגמרי, 1 = ישר בעיניים
    hold: float          # שניות עד הסטה/הצצה
    aim_x: float = 0.0   # לאן בפועל, ביחידות eye_aim
    aim_y: float = 0.0


@dataclass
class Timing:
    speed: float = 1.0       # כפל על מהירות ההבעה
    delay: float = 0.0       # השהיית תגובה, שניות
    bias: float = 0.0        # אסימטריה (-1..1)
    settle: float = 0.0      # כמה זמן לוקח לה "להתיישב" אחרי השינוי


@dataclass
class Body:
    spine_bend: float = 0.0     # קדימה חיובי = התכנסות/עניין
    spine_side: float = 0.0
    spine_twist: float = 0.0
    breath: float = 0.0         # עומק הנשימה
    head_extra: float = 0.0     # הטיה נוספת מעל ההבעה


@dataclass
class Gesture:
    name: str = "rest"
    hand: str = "R"
    amount: float = 0.0
    at: float = 0.0


@dataclass
class Plan:
    """התוכנית המלאה לשוט. זה מה שנכנס לבנייה."""
    situation: Situation
    emotion: Emotion
    intention: str
    gaze: Gaze
    face: list[tuple[str, float]]   # (שם הבעה, עוצמה)
    leak: list[tuple[str, float]]
    body: Body
    gesture: list[Gesture]
    timing: Timing
    subtext: str = ""               # המשמעות שמתחת למשפט, במילים
    notes: list[str] = field(default_factory=list)

    def as_dict(self) -> dict:
        return {
            "emotion": self.emotion.name,
            "intention": self.intention,
            "gaze": {"target": self.gaze.target,
                     "directness": round(self.gaze.directness, 3),
                     "hold": round(self.gaze.hold, 3),
                     "aim": [round(self.gaze.aim_x, 3), round(self.gaze.aim_y, 3)]},
            "face": [[n, round(a, 3)] for n, a in self.face],
            "leak": [[n, round(a, 3)] for n, a in self.leak],
            "body": {k: round(v, 3) for k, v in vars(self.body).items()},
            "gesture": [{"name": g.name, "hand": g.hand,
                         "amount": round(g.amount, 3), "at": round(g.at, 3)}
                        for g in self.gesture],
            "timing": {k: round(v, 3) for k, v in vars(self.timing).items()},
            "subtext": self.subtext,
            "notes": list(self.notes),
        }


# ------------------------------------------------------------- כוונות
#
# הכוונה אינה הרגש. היא מה שהדמות **עושה** לבן השיח, והיא נגזרת
# משלושה דברים יחד: הרגש, פער הידע, וההסתרה. זה הצומת שבו
# "feels=sadness" הופך פעם ל"מבקשת קרבה" ופעם ל"דוחה מגע".

INTENTIONS = {
    "withhold":  "מחזיקה מידע. שקט, מבט ישר, מעט תנועה.",
    "test":      "בודקת את בן השיח. מבט ממוקד, תגובה מושהית.",
    "seek":      "מחפשת מידע. מבט נע, גבות מורמות, מהירה.",
    "defend":    "מתגוננת. מתכנסת, מבט מוסט, גוף סגור.",
    "appease":   "מפייסת. חיוך, ראש מוטה, גוף קטן.",
    "assert":    "קובעת עובדה. גוף פתוח, מבט ישר, תנועה חדה.",
    "connect":   "מתקרבת. רכה, איטית, מבט מוחזק.",
    "withdraw":  "מתרחקת. מבט למטה, גוף אחורה, איטית.",
    "conceal":   "מסתירה. מסכה מלמעלה ונזילה מלמטה.",
    "observe":   "מתבוננת. דוממת, מבט מוחזק, נשימה רדודה.",
}


def choose_intention(s: Situation) -> tuple[str, list[str]]:
    """הכוונה נגזרת, ולא נכתבת ביד בכל תרחיש."""
    e = s.feel()
    notes: list[str] = []

    # הסתרה גוברת על הכול: היא **הפעולה** של השוט.
    if s.hides:
        notes.append("יש הסתרה - הכוונה היא ההסתרה עצמה, "
                     "והרגש האמיתי נוזל באזורים שאין בהם שליטה")
        return "conceal", notes

    # פער ידע הוא השדה השני בחשיבות, והוא **הופך** את הכוונה.
    if s.knows_more > 0.45:
        notes.append("היא יודעת יותר - שקט הוא כוח, ולכן פחות תנועה ולא יותר")
        return ("test" if e.control > 0.55 else "withhold"), notes
    if s.knows_more < -0.45:
        notes.append("היא יודעת פחות - חיפוש מידע נראה כתנועה")
        return "seek", notes

    # control נמוך = מתגוננת או נסוגה. control גבוה = קובעת.
    if e.valence < -0.3 and e.control < 0.35:
        return ("withdraw" if e.arousal < 0.35 else "defend"), notes
    if e.valence < -0.3 and e.control >= 0.65:
        return "assert", notes
    if e.valence > 0.4:
        return ("connect" if e.arousal < 0.5 else "assert"), notes
    if e.arousal < 0.3:
        return "observe", notes
    if s.want_strength > 0.7 and e.valence <= 0:
        return "appease", notes
    return "observe", notes


# ------------------------------------------------------------------- מבט
#
# המבט אינו "לאן העיניים מצביעות". הוא **כמה היא מוכנה להיות נראית**,
# וזו הסיבה שהוא נגזר מהכוונה ומההסתרה ולא מ-looks_at לבדו.

_GAZE_AIM = {
    "partner":  (0.00, 0.02),
    "audience": (0.00, 0.00),
    "away":     (0.62, 0.08),
    "down":     (0.10, -0.55),
    "object":   (0.35, -0.22),
    "inward":   (0.18, 0.30),     # מבט "פנימה" - קצת למעלה ולצד, מטושטש
}

_DIRECTNESS = {"withhold": 0.92, "test": 0.88, "assert": 0.86,
               "observe": 0.78, "connect": 0.82, "seek": 0.55,
               "appease": 0.58, "conceal": 0.52, "defend": 0.38,
               "withdraw": 0.22}


def build_gaze(s: Situation, intention: str) -> Gaze:
    ax, ay = _GAZE_AIM.get(s.looks_at, _GAZE_AIM["partner"])
    direct = _DIRECTNESS.get(intention, 0.7)
    e = s.feel()

    # ככל שפחות שליטה - פחות מבט ישר. זה רצף, לא מתג.
    direct *= 0.62 + 0.38 * e.control
    # הסתרה מקצרת את ההחזקה: היא בודקת אם קנו לה את זה, ומסיטה.
    hold = 1.9 * (0.45 + 0.55 * e.control)
    if s.hides:
        hold *= 0.45
        direct *= 0.86
    if intention in ("withhold", "test", "observe"):
        hold *= 1.8          # שקט מחזיק מבט. זה מה שעושה אותו מאיים.
    if s.knows_more < -0.45:
        hold *= 0.5          # מי שמחפש לא מחזיק מבט
    hold = max(0.25, min(hold, max(0.4, s.shot_len)))

    # המבט לא "מצביע" לגמרי לכיוון שנקבע - הוא נמשך לבן השיח
    # בפרופורציה לישירות. בלי זה מבט מוסט נראה כמו תנועת עיניים
    # מלאכותית במקום כמו אדם שמתקשה להסתכל.
    ax *= 1.0 - 0.55 * direct
    ay *= 1.0 - 0.35 * direct
    return Gaze(s.looks_at, round(min(1.0, direct), 4), round(hold, 4),
                round(ax, 4), round(ay, 4))


# -------------------------------------------------------------- תזמון

def build_timing(s: Situation, intention: str) -> Timing:
    e = s.feel()
    # arousal הוא מה שקובע מהירות. "sadness = slower" אינו כתוב
    # בשום מקום בקוד - הוא יוצא מ-arousal=0.22 של sadness.
    speed = 0.62 + 0.78 * e.arousal
    delay = 0.0
    bias = 0.0
    settle = 0.25 + 0.55 * (1.0 - e.arousal)

    if s.hides:
        # הסתרה דורשת עיבוד. זו ה"delayed reaction".
        delay += 0.20 + 0.22 * (1.0 - e.control)
        # שליטה רצונית חלקית נופלת על צד אחד. חיוך מזויף אסימטרי.
        bias += 0.26
        speed *= 0.92
    if intention in ("withhold", "test", "observe"):
        speed *= 0.82          # שקט הוא איטי
        delay += 0.14
    if intention == "seek":
        speed *= 1.18
    if intention == "defend":
        speed *= 1.12
        delay += 0.06
    if s.knows_more > 0.45:
        delay += 0.12          # מי שיודע לא ממהר לענות
    if s.knows_more < -0.45:
        delay = max(0.0, delay - 0.08)

    # שינוי רגשי בתוך השוט דורש זמן התיישבות אמיתי.
    if "->" in s.change:
        settle += 0.35
    return Timing(round(max(0.35, min(2.2, speed)), 4),
                  round(min(delay, 0.6 * max(0.5, s.shot_len)), 4),
                  round(max(-1.0, min(1.0, bias)), 4), round(settle, 4))


# -------------------------------------------------------------- שפת גוף
#
# שפת הגוף נגזרת מ-valence ומ-control, לא משם הרגש. לכן כעס ופחד -
# שניהם שליליים וערים - יוצאים הפוכים לגמרי: הכועס נפתח, המפוחד
# מתכנס. אם זה היה נגזר מהשם, היה צריך לכתוב כל מקרה ביד.

def build_body(s: Situation, intention: str) -> Body:
    e = s.feel()
    b = Body()
    closed = (1.0 - e.control) * (0.5 - 0.5 * e.valence)   # 0..1
    b.spine_bend = round(0.30 * closed - 0.10 * e.control, 4)
    b.breath = round(-0.35 + 0.70 * e.arousal, 4)
    if intention in ("defend", "withdraw"):
        b.spine_bend += 0.16
        b.spine_twist -= 0.10          # פונה חלקית הצידה - גוף סגור
        b.breath -= 0.12
    if intention in ("assert", "withhold", "test"):
        b.spine_bend -= 0.12           # נפתח, לא מתכנס
        b.breath += 0.08
    if intention == "appease":
        b.head_extra += 0.22           # ראש מוטה - סימן פיוס
        b.spine_bend += 0.08
    if intention == "connect":
        b.spine_bend += 0.10           # נוטה קדימה - קרבה, לא התכנסות
        b.head_extra += 0.12
    if intention == "seek":
        b.spine_bend += 0.07
        b.spine_twist += 0.08
    if s.hides:
        # גוף דומם מדי הוא עצמו סימן להסתרה: הדמות "מחזיקה" את עצמה.
        b.breath -= 0.14
        b.spine_side += 0.05
    for k in ("spine_bend", "spine_side", "spine_twist", "breath", "head_extra"):
        setattr(b, k, round(max(-1.0, min(1.0, getattr(b, k))), 4))
    return b


# -------------------------------------------------------------- מחווה
#
# הכלל: **אין מחווה בלי כוונה שמייצרת אותה.** מחווה שמתווספת "כדי
# שתהיה תנועה" היא בדיוק מה שמייצר את התחושה של דמות שמנפנפת ידיים
# בלי סיבה. לכן הטבלה היא מכוונה למחווה, ולא מרגש למחווה.

_GESTURE = {
    "seek":     ("open_palm", 0.55),
    "assert":   ("point_soft", 0.60),
    "appease":  ("open_palm", 0.42),
    "defend":   ("guard", 0.50),
    "connect":  ("reach", 0.38),
    "withdraw": ("self_touch", 0.30),
    "conceal":  ("self_touch", 0.34),
    "test":     ("rest", 0.0),
    "withhold": ("rest", 0.0),
    "observe":  ("rest", 0.0),
}


def build_gesture(s: Situation, intention: str, timing: Timing) -> list[Gesture]:
    name, amt = _GESTURE.get(intention, ("rest", 0.0))
    if amt <= 0.0:
        return []
    amt *= 0.55 + 0.45 * s.want_strength      # רצון חלש = מחווה קטנה
    amt *= 0.6 + 0.4 * s.feel().arousal
    # המחווה מגיעה **אחרי** תחילת ההבעה. יד שזזה לפני הפנים נראית
    # כמו אנימציה שהודבקה, כי במציאות הפנים מגיבות ראשונות.
    at = timing.delay + 0.12 + 0.18 * (1.0 - s.feel().arousal)
    out = [Gesture(name, "R", round(min(1.0, amt), 4), round(at, 4))]
    if intention in ("seek", "appease") and amt > 0.5:
        out.append(Gesture(name, "L", round(min(1.0, amt * 0.72), 4),
                           round(at + 0.09, 4)))      # יד שנייה מאחרת
    return out


# ----------------------------------------------------------------- פנים

def build_face(s: Situation) -> tuple[list[tuple[str, float]],
                                      list[tuple[str, float]], list[str]]:
    """מחזיר (הבעות גלויות, נזילה, הערות). כאן יושב פיצול ההסתרה."""
    e = s.feel()
    notes: list[str] = []
    inten = max(0.0, min(1.4, s.intensity))

    if not s.hides:
        face = [(n, round(inten * (1.0 if i == 0 else 0.55), 4))
                for i, n in enumerate(e.face)]
        return face, [], notes

    # יש הסתרה. המסכה היא מה שמוצג; הרגש האמיתי נוזל.
    masked = EMOTIONS.get(s.hides) or e
    mask_names = MASK_FOR.get(masked.name, ("polite_smile",))
    # עוצמת המסכה עולה עם ה-control: מי ששולט בעצמו מצליח להחזיק
    # מסכה חזקה יותר. מי שלא - המסכה דקה והנזילה בולטת.
    m = 0.55 + 0.40 * masked.control
    face = [(n, round(inten * m * (1.0 if i == 0 else 0.5), 4))
            for i, n in enumerate(mask_names)]

    # ואם הרגש הגלוי (feels) שונה מהמוסתר - הוא **גם** מוצג, כי
    # הדמות מרגישה שניים בבת אחת (למשל: מרגישה עניין, מסתירה עצב).
    if masked.name != e.name and e.face:
        face.append((e.face[0], round(inten * 0.45, 4)))

    leak_amt = (1.0 - masked.control) * 0.75 + 0.25
    leak = [(n, round(inten * leak_amt * 0.55 * (1.0 if i == 0 else 0.6), 4))
            for i, n in enumerate(masked.face)]
    notes.append(f"מסכה: {', '.join(mask_names)} · נוזל: "
                 f"{', '.join(n for n, _ in leak)}")
    return face, leak, notes


# ------------------------------------------------------------------ תכנון

def plan(s: Situation) -> Plan:
    """ששת המשתנים -> תוכנית הופעה מלאה. זו הפונקציה המרכזית."""
    e = s.feel()
    intention, notes = choose_intention(s)
    timing = build_timing(s, intention)
    gaze = build_gaze(s, intention)
    face, leak, fnotes = build_face(s)
    body = build_body(s, intention)
    gest = build_gesture(s, intention, timing)
    notes += fnotes
    return Plan(s, e, intention, gaze, face, leak, body, gest, timing,
                subtext(s, intention), notes)


def subtext(s: Situation, intention: str) -> str:
    """המשמעות שמתחת למשפט, במילים. זה מה שהדמות מבצעת."""
    e = s.feel()
    parts = []
    if s.hides:
        parts.append(f"מרגישה {_he(s.hides)} ולא מראה את זה")
    else:
        parts.append(f"מרגישה {_he(e.name)}")
    if s.wants:
        parts.append(f"רוצה {s.wants}")
    if s.knows_more > 0.45:
        parts.append("ויודעת משהו שהשני לא יודע")
    elif s.knows_more < -0.45:
        parts.append("ולא מבינה מה קורה")
    parts.append(INTENTIONS[intention].split(".")[0].strip())
    return " · ".join(parts)


_HE = {"surprise": "הפתעה", "fear": "פחד", "anger": "כעס",
       "sadness": "עצב", "shame": "בושה", "guilt": "אשמה",
       "contempt": "בוז", "suspicion": "חשד", "doubt": "ספק",
       "curiosity": "סקרנות", "interest": "עניין", "amusement": "שעשוע",
       "joy": "שמחה", "affection": "חיבה", "relief": "הקלה",
       "pride": "גאווה", "discomfort": "אי-נוחות", "fatigue": "עייפות",
       "realization": "הבנה", "neutral": "שקט"}


def _he(name: str) -> str:
    return _HE.get(name, name)


# -------------------------------------------------- שינוי רגשי בתוך השוט

@dataclass
class Arc:
    """מה השתנה רגשית בשוט. שני מצבים ונקודת מפנה ביניהם."""
    before: Plan
    after: Plan
    turn: float            # שנייה שבה המפנה קורה
    blend: float           # כמה זמן לוקח המעבר

    def at(self, t: float) -> Plan:
        """התוכנית התקפה בזמן t. לפני המפנה - before, אחרי - after."""
        return self.before if t < self.turn + self.blend * 0.5 else self.after

    def weight(self, t: float) -> float:
        """0 לפני, 1 אחרי, ומעבר רך באמצע."""
        if self.blend <= 1e-6:
            return 0.0 if t < self.turn else 1.0
        u = (t - self.turn) / self.blend
        u = max(0.0, min(1.0, u))
        return u * u * (3.0 - 2.0 * u)

    def as_dict(self) -> dict:
        return {"turn": round(self.turn, 3), "blend": round(self.blend, 3),
                "before": self.before.as_dict(), "after": self.after.as_dict()}


def arc(s: Situation, turn: float | None = None) -> Arc | None:
    """
    `change` בצורת "<מרגש>-><לרגש>" -> שתי תוכניות ונקודת מפנה.

    נקודת המפנה אינה באמצע השוט: שינוי רגשי קורה כשמשהו נאמר, וזה
    קורה לפני סופו - והדמות צריכה זמן להגיב. שני שלישים הוא הטווח
    שמשאיר זמן לתגובה בלי לדחוס אותה לסוף.
    """
    if "->" not in s.change:
        return None
    a, b = [x.strip() for x in s.change.split("->", 1)]
    if a not in EMOTIONS or b not in EMOTIONS:
        return None
    before = plan(replace(s, feels=a, change=""))
    after = plan(replace(s, feels=b, change=""))
    tp = 0.62 * s.shot_len if turn is None else float(turn)
    # זמן המעבר נגזר מהפער באנרגיה: מעבר לרגש ער יותר הוא חד,
    # ומעבר לרגש שקט יותר הוא דועך לאט. אותו מעבר בכיוון ההפוך
    # אינו באורך זהה, וזה מה שהופך אותו לאנושי.
    d = EMOTIONS[b].arousal - EMOTIONS[a].arousal
    blend = 0.52 - 0.30 * d + 0.25 * after.timing.settle
    return Arc(before, after, round(tp, 4), round(max(0.12, blend), 4))


# ------------------------------------------- מהתוכנית אל מערכת המשחק

def performance(s: Situation, seed: float = 0.0,
                eyes_own: bool = False) -> acting.Performance:
    """
    התוכנית -> `acting.Performance` שאפשר לפתור בכל זמן.

    זה החיבור שהופך את המנוע לדבר שמזיז פנים ולא למסמך: כל הבעה
    נכנסת עם העוצמה, המהירות, ההשהיה והאסימטריה שחושבו - ולא
    בערכי ברירת המחדל שלה.

    `eyes_own=True` מעביר את הבעלות על המצמוץ ועל כיוון המבט למערכת
    משחק העיניים (TASK 04). בלי זה שתי מערכות כותבות לאותן בקרות.
    """
    p = plan(s)
    perf = acting.Performance(seed=seed, micro=True, eyes_own=eyes_own)
    _stage(perf, p, 0.0)
    a = arc(s)
    if a is not None:
        # המפנה: ההבעה השנייה נכנסת בנקודת המפנה, לא בתחילת השוט.
        perf = acting.Performance(seed=seed, micro=True, eyes_own=eyes_own)
        _stage(perf, a.before, 0.0)
        _stage(perf, a.after, a.turn)
    return perf


# ------------------------------------------- המבט: מערכת בפני עצמה (TASK 04)
#
# עד כאן המבט היה שני מספרים שנגזרו מהכוונה, ועוד "הצצה" מחזורית.
# זה הספיק כדי לומר *לאן* היא מסתכלת, ולא הספיק כדי לשחק את זה:
# אין שם סקאדה שאורכה נגזר ממשרעתה, אין הקדמה לפני הסטה, אין מצמוץ
# שנגרר מההסטה, ואין ראש שמאחר אחרי העיניים. `rig.eyes` היא המערכת
# שעושה את זה, והפונקציה הזאת היא התרגום מ-Situation אליה.

def eye_actor(s: Situation, seed: float = 0.0, speech: tuple = (),
              reacts: tuple = ()):
    """`Situation` -> `eyes.EyeActing` מכוונן לאותו מצב בדיוק.

    שימו לב מה עובר לשם: לא "looks_at" לבדו אלא גם הישירות שחושבה,
    זמן ההחזקה, ההשהיה שההסתרה יצרה ופער הידע. כלומר המבט ממשיך
    להיגזר מהמשמעות, והמערכת החדשה רק **מבצעת** אותו כמו שצריך.
    """
    from . import eyes as _eyes                       # noqa: PLC0415
    p = plan(s)
    e = p.emotion
    home = s.looks_at if s.looks_at in _eyes.TARGETS else "partner"
    # כשהמבט העיקרי אינו בבן השיח, ההסטה היא **אליו**: דמות שמביטה
    # מטה ומציצה למעלה היא מה שנראה כאדם שמתקשה להסתכל.
    away = "partner" if home not in ("partner", "audience") else ""
    return _eyes.EyeActing(
        seed=seed, shot_len=s.shot_len,
        valence=e.valence, arousal=e.arousal, control=e.control,
        directness=p.gaze.directness, hold=p.gaze.hold,
        conceal=bool(s.hides), knows_more=s.knows_more,
        home=home, away=away, speech=tuple(speech), reacts=tuple(reacts),
        latency=p.timing.delay)


def _stage(perf: acting.Performance, p: Plan, t0: float) -> None:
    for name, amt in p.face + p.leak:
        if name not in acting.EXPRESSIONS or amt <= 1e-4:
            continue
        perf.add(acting.EXPRESSIONS[name], at=t0 + p.timing.delay,
                 intensity=amt, speed=p.timing.speed, bias=p.timing.bias)


def solve(s: Situation, t: float, seed: float = 0.0,
          eye=None) -> tuple[dict, dict]:
    """(ctl, mph) בזמן t — כולל המבט ושפת הגוף, לא רק הפנים.

    `eye` הוא `eyes.EyeActing` (מ-`eye_actor`). כשהוא ניתן, **הוא**
    בעל המבט, המצמוץ, העפעפיים והאישונים, והמנוע לא נוגע בהם;
    כשאינו ניתן נשארת ההתנהגות הוותיקה, כדי שקוד קיים לא ישתנה.
    """
    p = plan(s)
    a = arc(s)
    cur = p if a is None else a.at(t)
    ctl, mph = performance(s, seed, eyes_own=eye is not None).solve(t)

    if eye is not None:
        r = eye.raw(t)
        for k, v in r["ctl"].items():
            ctl[k] = ctl.get(k, 0.0) + v
        for k, v in r["mph"].items():
            mph[k] = mph.get(k, 0.0) + v
    else:
        # המבט: מוסיפים אותו **אחרי** ההבעות, כי הוא החלטה של המנוע
        # ולא תוצר של ההבעה. הצצה חזרה אחרי ההחזקה היא מה שהופך מבט
        # מוסט מ"עיניים בכיוון" ל"אדם שמתקשה להסתכל".
        g = cur.gaze
        peek = 1.0
        if g.hold > 1e-6 and t > g.hold:
            ph = ((t - g.hold) / max(0.45, g.hold * 0.8)) % 2.0
            peek = 0.35 if ph < 1.0 else 1.0
        ctl["eye_aim_x"] = ctl.get("eye_aim_x", 0.0) + g.aim_x * peek
        ctl["eye_aim_y"] = ctl.get("eye_aim_y", 0.0) + g.aim_y * peek

    b = cur.body
    for k, v in (("spine_bend", b.spine_bend), ("spine_side", b.spine_side),
                 ("spine_twist", b.spine_twist), ("breath", b.breath)):
        ctl[k] = ctl.get(k, 0.0) + v
    if abs(b.head_extra) > 1e-6:
        ctl["head_roll"] = ctl.get("head_roll", 0.0) + b.head_extra * 0.35
        ctl["neck_roll"] = ctl.get("neck_roll", 0.0) + b.head_extra * 0.15
    for ge in cur.gesture:
        if t < ge.at or ge.amount <= 1e-4:
            continue
        for k, v in _gesture_ctl(ge).items():
            ctl[k] = ctl.get(k, 0.0) + v
    return acting.finalize(ctl, mph)


_GESTURE_SHAPE = {
    "open_palm": {"arm_down": -0.30, "arm_fwd": 0.26, "elbow": 0.34,
                  "spread": 0.45, "wrist_pitch": 0.30},
    "point_soft": {"arm_down": -0.34, "arm_fwd": 0.34, "elbow": 0.30,
                   "curl_middle": 0.70, "curl_ring": 0.80, "curl_pinky": 0.85},
    "guard": {"arm_down": -0.22, "arm_fwd": 0.40, "elbow": 0.62,
              "fist": 0.25, "spread": -0.20},
    "reach": {"arm_down": -0.26, "arm_fwd": 0.46, "elbow": 0.20,
              "spread": 0.22, "wrist_pitch": 0.18},
    "self_touch": {"arm_down": -0.18, "arm_fwd": 0.30, "elbow": 0.78,
                   "curl_index": 0.40, "curl_middle": 0.40},
}


def _gesture_ctl(g: Gesture) -> dict:
    shape = _GESTURE_SHAPE.get(g.name)
    if not shape:
        return {}
    return {f"{k}_{g.hand}": v * g.amount for k, v in shape.items()}


# ------------------------------------------------------------- תרחישים
#
# אלה אינם "דוגמאות". כל אחד מהם מוכיח שאותו משתנה **משנה את הפלט**:
# אותו רגש עם knows הפוך, אותו רגש עם ועם בלי hides, ואותו שינוי
# בשני הכיוונים.

SCENES: dict[str, Situation] = {
    "מודה-ולא-אומרת": Situation(
        knows="שהיא זו ששכחה", wants="שלא ישאלו עוד", feels="interest",
        hides="guilt", looks_at="partner", knows_more=0.8,
        want_strength=0.8, line="לא, הכול בסדר.",
    ),
    "יודעת-יותר": Situation(
        knows="שהתשובה אצלה", wants="שהוא יגיד את זה בעצמו",
        feels="suspicion", looks_at="partner", knows_more=0.9,
        want_strength=0.7, line="נו? מה קרה שם?",
    ),
    "לא-מבינה": Situation(
        knows="כמעט כלום", wants="להבין מה קורה", feels="curiosity",
        looks_at="object", knows_more=-0.9, want_strength=0.8,
        line="נו? מה קרה שם?",
    ),
    "עצב-גלוי": Situation(
        knows="שזה נגמר", wants="שיהיה מי שיבין", feels="sadness",
        looks_at="down", want_strength=0.5, line="זה בסדר, אני רגילה.",
    ),
    "עצב-מוסתר": Situation(
        knows="שזה נגמר", wants="שלא יראו", feels="neutral",
        hides="sadness", looks_at="partner", want_strength=0.9,
        line="זה בסדר, אני רגילה.",
    ),
    "הפתעה-להבנה": Situation(
        knows="שמשהו לא מסתדר", wants="לדעת", feels="surprise",
        change="surprise->realization", looks_at="partner",
        shot_len=4.0, line="רגע... אז זה היה אתה?",
    ),
    "הבנה-לכעס": Situation(
        knows="עכשיו הכול", wants="שיודה", feels="realization",
        change="realization->anger", looks_at="partner", knows_more=0.5,
        shot_len=4.5, line="רגע... אז זה היה אתה?",
    ),
    "צחוק-שנעצר": Situation(
        knows="שזה לא הזמן", wants="לא להתפרץ", feels="neutral",
        hides="amusement", looks_at="away", want_strength=0.95,
        line="כן, אני מקשיב.",
    ),
}


# -------------------------------------------------------------- בדיקות

def audit() -> dict:
    """שלמות המנוע: שכל רגש מצביע להבעה קיימת, ושכל מסכה קיימת."""
    bad: list[str] = []
    for name, e in EMOTIONS.items():
        for f in e.face:
            if f not in acting.EXPRESSIONS:
                bad.append(f"רגש {name}: אין הבעה {f}")
        for v, lo, hi in ((e.valence, -1, 1), (e.arousal, 0, 1),
                          (e.control, 0, 1)):
            if not lo <= v <= hi:
                bad.append(f"רגש {name}: ערך {v} מחוץ לטווח")
    for em, masks in MASK_FOR.items():
        if em not in EMOTIONS:
            bad.append(f"מסכה לרגש שאינו קיים: {em}")
        for m in masks:
            if m not in acting.EXPRESSIONS:
                bad.append(f"מסכה {m} של {em} אינה הבעה קיימת")
    for em in EMOTIONS:
        if em != "neutral" and em not in MASK_FOR:
            bad.append(f"לרגש {em} אין מסכה - הסתרה שלו תיפול לברירת מחדל")
    for r in LEAK_REGIONS:
        if r not in acting.REGIONS:
            bad.append(f"אזור נזילה {r} אינו אזור פנים מוכר")
    if CONTROLLED_REGIONS & set(LEAK_REGIONS):
        bad.append("אזור מופיע גם כנשלט וגם כנוזל")
    missing_regions = set(acting.REGIONS) - CONTROLLED_REGIONS - set(LEAK_REGIONS)
    if missing_regions:
        bad.append(f"אזורים שלא סווגו: {sorted(missing_regions)}")
    for n, s in SCENES.items():
        try:
            plan(s)
        except Exception as exc:                 # noqa: BLE001
            bad.append(f"תרחיש {n} נכשל: {type(exc).__name__}: {exc}")
    return {"ok": not bad, "problems": bad,
            "emotions": len(EMOTIONS), "intentions": len(INTENTIONS),
            "scenes": len(SCENES)}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="מנוע רגש")
    ap.add_argument("--audit", action="store_true")
    ap.add_argument("--scene", default="")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args(argv)
    if a.audit:
        r = audit()
        print(json.dumps(r, ensure_ascii=False, indent=1))
        return 0 if r["ok"] else 1
    names = [a.scene] if a.scene else list(SCENES)
    out = {}
    for n in names:
        p = plan(SCENES[n])
        out[n] = p.as_dict()
        ar = arc(SCENES[n])
        if ar:
            out[n]["arc"] = {"turn": ar.turn, "blend": ar.blend,
                             "from": ar.before.emotion.name,
                             "to": ar.after.emotion.name}
        if not a.json:
            print(f"\n── {n}   «{SCENES[n].line}»")
            print(f"   משמעות:  {p.subtext}")
            print(f"   כוונה:    {p.intention} — {INTENTIONS[p.intention]}")
            print(f"   מבט:      {p.gaze.target} · ישירות {p.gaze.directness} "
                  f"· מחזיקה {p.gaze.hold}ש")
            print(f"   פנים:     {', '.join(f'{k}×{v}' for k, v in p.face) or '—'}")
            if p.leak:
                print(f"   נוזל:     {', '.join(f'{k}×{v}' for k, v in p.leak)}")
            print(f"   גוף:      כיפוף {p.body.spine_bend} · נשימה {p.body.breath}")
            print(f"   מחווה:    {', '.join(g.name for g in p.gesture) or '—'}")
            print(f"   תזמון:    מהירות {p.timing.speed} · השהיה "
                  f"{p.timing.delay}ש · אסימטריה {p.timing.bias}")
            if ar:
                print(f"   מפנה:     {ar.before.emotion.name} → "
                      f"{ar.after.emotion.name} בשנייה {ar.turn} "
                      f"(מעבר {ar.blend}ש)")
    if a.json:
        print(json.dumps(out, ensure_ascii=False, indent=1))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
