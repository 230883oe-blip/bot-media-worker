# -*- coding: utf-8 -*-
"""מרנדר את כל הסצנות ומאחד לסרטון אחד."""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import engine  # noqa: E402

ROOT = Path(__file__).resolve().parent
SCENES = ROOT / "scenes"
OUT = ROOT / "out"

ORDER = [
    "s1_intro", "s2_vector", "s3_avatar",
    "s4_terminal", "s5_dashboard", "s6_physical",
    "s7_motion",          # 04/10 — שכבת התנועה, לפי דירוג המועצה
]


def main(only: list[str] | None = None, fps: int = 30) -> int:
    sys.stdout.reconfigure(encoding="utf-8")
    OUT.mkdir(parents=True, exist_ok=True)
    names = only or ORDER
    parts, report = [], []
    t0 = time.time()
    for name in names:
        html = SCENES / f"{name}.html"
        if not html.exists():
            print(f"✗ אין סצנה {name}")
            return 2
        mp4 = OUT / f"{name}.mp4"
        print(f"→ מרנדר {name} ...", flush=True)
        info = engine.render(html, mp4, fps=fps)
        print(f"  {info['seconds']}ש · {info['frames']} פריימים · "
              f"{info['render_sec']}ש רינדור · {info['size_mb']}MB", flush=True)
        parts.append(mp4)
        report.append({"scene": name, **info})

    if len(parts) > 1:
        final = OUT / "showreel.mp4"
        print("→ מאחד ...", flush=True)
        info = engine.concat(parts, final, fps=fps)
        report.append({"scene": "FINAL", **info})
        print(f"✓ {final}  ·  {info['seconds']}ש  ·  {info['size_mb']}MB")

    print(f"\nסך הכול {round(time.time() - t0, 1)} שניות")
    (OUT / "build_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=1), encoding="utf-8")
    return 0


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("-")]
    raise SystemExit(main(args or None))
