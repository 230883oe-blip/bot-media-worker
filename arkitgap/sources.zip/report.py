# -*- coding: utf-8 -*-
"""
מפיק את **סרטון דוח המצב** מנתונים אמיתיים.

הרעיון: אותו מנוע רינדור של ה-showreel, אבל הסצנות קוראות את
המספרים מ-`scenes/_data.js` שנכתב מחדש לפני כל הפקה. כלומר הסרטון
אינו הדגמה — הוא התמונה של המחשב הזה באותו בוקר.

הרצה:
    python report.py <נתיב ל-JSON> [נתיב פלט ל-mp4]
    python report.py --demo                 מפיק מברירת המחדל שבקובץ הנתונים

מבנה ה-JSON — ראה `scenes/_data.js`. שדה חסר אינו שגיאה: הסצנה
מדלגת עליו, כי דוח חלקי עדיף על דוח שלא נשלח.

**שתי הפקות במקביל אסורות**, ולא בגלל מעבד: `_data.js` הוא קובץ אחד
משותף לכל הסצנות, והשנייה הייתה דורסת את הנתונים של הראשונה באמצע
הרינדור — כלומר סרטון אחד עם מספרים משני ימים, בלי שום שגיאה.
"""
from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import engine  # noqa: E402

ROOT = Path(__file__).resolve().parent
SCENES = ROOT / "scenes"
OUT = ROOT / "out"
DATA = SCENES / "_data.js"
LOCK = ROOT / ".report.lock"

ORDER = ["r1_cover", "r2_bots", "r3_metrics", "r4_actions"]
STALE = 25 * 60          # מנעול של ריצה שמתה משוחרר אחרי רבע שעה ויותר


def take_lock() -> bool:
    """נועל, אלא אם הפקה אחרת חיה באמת. מנעול יתום משוחרר לבד."""
    try:
        if LOCK.exists():
            age = time.time() - LOCK.stat().st_mtime
            if age < STALE:
                return False
        LOCK.write_text(str(os.getpid()), encoding="utf-8")
        return True
    except OSError:
        return True          # כישלון פותח: עדיף סרטון מסיכון תיאורטי


def free_lock() -> None:
    try:
        LOCK.unlink()
    except OSError:
        pass


def write_data(payload: dict) -> None:
    """כותב את הנתונים כקובץ JS שהסצנות טוענות.

    `window.REPORT = {...}` ולא `||=`: ברירת המחדל שבקובץ המקורי
    נועדה לפיתוח, ואם היא תנצח בהפקה אמיתית הסרטון יציג מספרי דמה
    בביטחון מלא. זו בדיוק התקלה שאי אפשר לזהות מהצפייה.
    """
    blob = json.dumps(payload, ensure_ascii=False, indent=1)
    DATA.write_text(
        "/* נכתב אוטומטית על ידי report.py — אל תערוך ביד. */\n"
        "window.REPORT = " + blob + ";\n",
        encoding="utf-8",
    )


def build(payload: dict, out: Path | None = None, fps: int = 30,
          quiet: bool = False) -> dict:
    """מרנדר את ארבע הסצנות ומאחד. מחזיר את פרטי הסרטון."""
    out = Path(out) if out else (OUT / "report.mp4")
    OUT.mkdir(parents=True, exist_ok=True)
    if not take_lock():
        raise RuntimeError("הפקת דוח אחרת רצה ברגע זה")
    try:
        write_data(payload)
        parts, scenes = [], []
        t0 = time.time()
        for name in ORDER:
            html = SCENES / f"{name}.html"
            if not html.exists():
                raise RuntimeError(f"אין סצנה {name}")
            mp4 = OUT / f"rep_{name}.mp4"
            if not quiet:
                print(f"→ {name} ...", flush=True)
            info = engine.render(html, mp4, fps=fps)
            if not quiet:
                print(f"  {info['seconds']}ש · {info['frames']} פריימים", flush=True)
            parts.append(mp4)
            scenes.append({"scene": name, **info})
        final = engine.concat(parts, out, fps=fps)
        final["scenes"] = scenes
        final["build_sec"] = round(time.time() - t0, 1)
        (OUT / "report_build.json").write_text(
            json.dumps(final, ensure_ascii=False, indent=1), encoding="utf-8")
        return final
    finally:
        free_lock()


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8")
    args = [a for a in sys.argv[1:] if a != "--demo"]
    if "--demo" in sys.argv or not args:
        payload = {}          # ברירת המחדל שבקובץ תישאר, לבדיקה ידנית
        DATA_BACKUP = DATA.read_text(encoding="utf-8") if DATA.exists() else ""
        try:
            info = build_demo()
        finally:
            if DATA_BACKUP:
                DATA.write_text(DATA_BACKUP, encoding="utf-8")
        print(json.dumps(info, ensure_ascii=False, indent=1))
        return 0
    payload = json.loads(Path(args[0]).read_text(encoding="utf-8"))
    out = Path(args[1]) if len(args) > 1 else None
    info = build(payload, out)
    print(json.dumps({k: v for k, v in info.items() if k != "scenes"},
                     ensure_ascii=False, indent=1))
    return 0


def build_demo() -> dict:
    """מפיק מהנתונים שבקובץ כמות שהם, בלי לדרוס אותם."""
    OUT.mkdir(parents=True, exist_ok=True)
    parts = []
    for name in ORDER:
        mp4 = OUT / f"rep_{name}.mp4"
        parts.append(mp4)
        engine.render(SCENES / f"{name}.html", mp4, fps=30)
    return engine.concat(parts, OUT / "report_demo.mp4")


if __name__ == "__main__":
    raise SystemExit(main())
