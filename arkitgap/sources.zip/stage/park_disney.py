# -*- coding: utf-8 -*-
"""TASK 18 (06/10) - "הפארק הדינמי": הסביבה וארבעת האובייקטים.

ההוראה דרשה שהפארק **לא** יהיה רקע אלא סביבה שמגיבה: מזרקה
פועלת, אופניים מורכבים שמתגלגלים, עלווה שמגיבה לריצה, וספסל
ופנס מעוצבים.

================================================================
ההכרעה המרכזית: מה נצרב ומה דינמי, ולמה דווקא כך
================================================================

`rig.park` צורב את הסביבה ל-PNG פעם אחת, ועלות הרקע פר פריים היא
אפס. המודול הזה **לא מחליף** אותו אלא מוסיף שכבה: הוא קורא ל-
`park.bake` ואז מצייר את ארבעת האובייקטים אל תוך שכבת הקרקע.

החלוקה אינה שרירותית אלא נגזרת משאלה אחת - **האם האובייקט זז
במהלך 60 השניות**:

* **ספסל ופנס אינם זזים**, ולכן הם נצרבים. ציור שלהם ב-three.js
  היה מוסיף עשרות משולשים ומפת צל פר פריים, ובתמורה לאפס מידע.
* **המזרקה זזה בלופ קבוע** (מים שיוצאים ונופלים), ולכן היא
  מחולקת: האגן והעמוד נצרבים, וסילוני המים הם ענן נקודות דינמי.
  זו אותה הכרעה שהתקבלה ב-`ensemble` לעלים, ומאותו נימוק: buffer
  אחד וקריאת ציור אחת במקום גוף פר טיפה.
* **האופניים זזים בנתיב שאינו לופ** (מתגלגלים מהילד אל המזרקה
  ונעצרים אצל הסבא), ולכן הם **חייבים** להיות דינמיים לגמרי.
  צריבה שלהם במקום אחד ואנימציה במקום אחר הייתה אופניים כפולים,
  בדיוק המלכודת שתועדה ב-`park.PROPS["leaves"]`.

ולכן גם המקום של כל אובייקט נגזר **פעם אחת** מ-`LAYOUT` ומשמש
את שני הצדדים: הציור הצרוב קורא ממנו, והשכבה הדינמית קוראת ממנו.
שני מקורות אמת למקום של אותו גוף הם אובייקט שקופץ בפריים הראשון.

================================================================
תגובת העלווה - למה היא *סיבתית* ולא סינוס חזק יותר
================================================================

"עלווה שמגיבה כשדמות רצה לידה" אפשר לממש כהגדלת עוצמת הרוח
בשוט הריצה, וזה היה עובר בעין. זה נפסל: הגדלה כזו מתחילה **עם
השוט** ולא עם הדמות, כלומר העץ מתנדנד לפני שמישהו הגיע אליו.
`gust_at` מחזיר משב שהשיא שלו מגיע `REACT_LAG` שניות **אחרי**
שהרץ עובר את קו העץ, והוא דועך. `validate` מודד את הפיגור הזה
בשניות - תגובה שמקדימה את הסיבה היא עץ שקורא מחשבות.
"""
from __future__ import annotations

import json
import math
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
STUDIO = HERE.parent
if str(STUDIO) not in sys.path:
    sys.path.insert(0, str(STUDIO))

from rig import park                                     # noqa: E402

#: אורך הסרט. 60.0 מתחלק ב-`park.LOOP_SEC` (10.0) בדיוק שש פעמים,
#: ולכן התפר של הרוח והעננים מתלכד. ראה `park.bake`.
TOTAL_SECONDS = 60.0

#: מחזור המזרקה בשניות. 2.0 מתחלק ב-60 וגם ב-10, ולכן גם המים
#: מתלכדים בתפר הלופ וגם אינם מתנגשים במחזור הרוח.
FOUNTAIN_LOOP = 2.0

#: מקומות ארבעת האובייקטים, ביחידות פריים מנורמלות (0..1 על
#: רוחב השכבה הרחבה, 0..1 על הגובה). **מקור אמת אחד** - ראה למעלה.
LAYOUT = {
    # מזרקה: מרכז האגן, רדיוסי האגן, גובה העמוד וגובה הסילון.
    "fountain": {"at": (0.615, 0.790), "rx": 0.082, "ry": 0.026,
                 "post_h": 0.062, "jet_h": 0.085, "jets": 18},
    # ספסל עץ מעוגל: המושב, המשענת והרגליים.
    "bench": {"at": (0.228, 0.812), "w": 0.112, "seat_h": 0.028,
              "back_h": 0.050, "slats": 4},
    # פנס רחוב. `park.PROPS["lamp"]` כבר מגדיר אותו, ולכן המקום
    # **נקרא משם** ולא נכתב שוב: שני מקומות לאותו עמוד הם פנס
    # שהילה שלו אינה על הזכוכית שלו.
    "lamp": None,
    # אופניים: נקודת המנוחה (נשענים על העץ), ורדיוס הגלגל.
    "bike": {"rest": (0.392, 0.828), "wheel_r": 0.030,
             "frame": 0.064, "stop": (0.760, 0.834)},
    # קו העץ שהעלווה שלו מגיבה לריצה. ביחידות פריים.
    "react_tree": {"x": 0.345},
}

#: פיגור התגובה של העלווה אחרי שהרץ עובר, ודעיכתה. ראה למעלה.
REACT_LAG = 0.38
REACT_DECAY = 1.9

#: צבעים. גוונים חמים ורכים - פארק ולא אולפן.
WOOD = (122, 84, 52)
WOOD_LIT = (168, 122, 78)
METAL = (96, 104, 112)
METAL_LIT = (158, 168, 178)
WATER = (168, 214, 236)
WATER_DEEP = (96, 158, 196)
STONE = (176, 172, 158)
STONE_LIT = (214, 210, 196)


# ============================================================= הציור

def _shadow_of(shadow: tuple, w: int, h: int, x: float, y: float,
               height_frac: float) -> tuple[float, float]:
    """קצה הצל של גוף שגובהו `height_frac` מהפריים, בפיקסלים.

    משתמש **באותו** וקטור צל שה-`park.bake` חישב מזווית השמש. צל
    שמחושב כאן מזווית אחרת הוא ספסל שמואר משמאל וצלו נופל ימינה.
    """
    dx, dy = shadow
    return (x * w + dx * height_frac * h, y * h + dy * height_frac * h * 0.18)


def _bench(d, w: int, h: int, shadow: tuple) -> None:
    """ספסל עץ קלאסי מעוגל. כל קו הוא `rounded_rectangle` כדי
    שהצללית תהיה רכה - פינה חדה כאן נקראת מיד כקופסה."""
    s = LAYOUT["bench"]
    cx, cy = s["at"]
    bw = s["w"] * w
    x0, y0 = cx * w - bw / 2, cy * h
    seat_h = s["seat_h"] * h
    back_h = s["back_h"] * h
    r = seat_h * 0.42

    # צל על הדשא, בכיוון השמש
    sx, sy = _shadow_of(shadow, w, h, cx, cy, s["seat_h"] + s["back_h"])
    d.ellipse([sx - bw * 0.62, sy - seat_h * 0.5,
               sx + bw * 0.62, sy + seat_h * 0.55],
              fill=(34, 48, 30, 96))

    # רגליים
    for fx in (x0 + bw * 0.10, x0 + bw * 0.86):
        d.rounded_rectangle([fx, y0, fx + bw * 0.045, y0 + seat_h * 1.5],
                            radius=bw * 0.020, fill=METAL)
    # משענת: קרשים אופקיים, העליון מואר
    for i in range(s["slats"]):
        u = i / max(1, s["slats"] - 1)
        yy = y0 - back_h * (0.30 + 0.62 * u)
        col = tuple(int(WOOD[j] + (WOOD_LIT[j] - WOOD[j]) * u)
                    for j in range(3))
        d.rounded_rectangle([x0, yy, x0 + bw, yy + back_h * 0.17],
                            radius=r * 0.6, fill=col)
    # מושב
    d.rounded_rectangle([x0 - bw * 0.02, y0 - seat_h * 0.5,
                         x0 + bw * 1.02, y0 + seat_h * 0.5],
                        radius=r, fill=WOOD_LIT)


def _fountain(d, w: int, h: int, shadow: tuple) -> None:
    """אגן ועמוד המזרקה. **המים אינם כאן** - הם השכבה הדינמית."""
    s = LAYOUT["fountain"]
    cx, cy = s["at"]
    rx, ry = s["rx"] * w, s["ry"] * h
    X, Y = cx * w, cy * h

    sx, sy = _shadow_of(shadow, w, h, cx, cy, s["post_h"])
    d.ellipse([sx - rx * 1.15, sy - ry * 0.9, sx + rx * 1.15, sy + ry * 1.0],
              fill=(34, 48, 30, 104))

    # אגן תחתון: אליפסה כפולה (דופן + פנים)
    d.ellipse([X - rx, Y - ry, X + rx, Y + ry], fill=STONE)
    d.ellipse([X - rx * 0.86, Y - ry * 0.78,
               X + rx * 0.86, Y + ry * 0.82], fill=WATER_DEEP)
    d.ellipse([X - rx * 0.70, Y - ry * 0.56,
               X + rx * 0.70, Y + ry * 0.50], fill=WATER)
    # עמוד מרכזי מעוגל
    ph = s["post_h"] * h
    d.rounded_rectangle([X - rx * 0.13, Y - ph, X + rx * 0.13, Y + ry * 0.2],
                        radius=rx * 0.13, fill=STONE_LIT)
    # קערה עליונה
    d.ellipse([X - rx * 0.40, Y - ph - ry * 0.55,
               X + rx * 0.40, Y - ph + ry * 0.45], fill=STONE)
    d.ellipse([X - rx * 0.30, Y - ph - ry * 0.34,
               X + rx * 0.30, Y - ph + ry * 0.26], fill=WATER)


def _bike_shadow(d, w: int, h: int, shadow: tuple) -> None:
    """רק הצל של האופניים במקום המנוחה. הגוף עצמו דינמי - ראה
    ההערה ב-`bake` על שני זוגות האופניים."""
    s = LAYOUT["bike"]
    cx, cy = s["rest"]
    R = s["wheel_r"] * h
    sx, sy = _shadow_of(shadow, w, h, cx, cy, s["wheel_r"] * 2)
    d.ellipse([sx - R * 1.6, sy - R * 0.32, sx + R * 1.6, sy + R * 0.38],
              fill=(34, 48, 30, 92))


def _bike_body(d, X: float, Y: float, R: float, lean: float = 0.0,
               spin: float = 0.0) -> None:
    """גוף האופניים: שני גלגלים עם חישורים, שלדה, כידון, שרשרת
    ודוושות. אותה פונקציה משרתת את הציור הצרוב ואת הדינמי."""
    dxw = R * 1.45                      # מרחק בין הצירים
    cs, sn = math.cos(lean), math.sin(lean)

    def pt(ox, oy):
        return (X + ox * cs - oy * sn, Y + ox * sn + oy * cs)

    back, front = pt(-dxw * 0.5, 0.0), pt(dxw * 0.5, 0.0)
    for (wx, wy) in (back, front):
        d.ellipse([wx - R, wy - R, wx + R, wy + R],
                  outline=METAL, width=max(2, int(R * 0.16)))
        for i in range(8):
            a = spin + i * math.pi / 4
            d.line([wx, wy, wx + math.cos(a) * R * 0.88,
                    wy + math.sin(a) * R * 0.88],
                   fill=METAL_LIT, width=max(1, int(R * 0.07)))
    # שלדה: משולש + מזלג
    crank = pt(-dxw * 0.04, R * 0.10)
    seat = pt(-dxw * 0.34, -R * 0.92)
    bar = pt(dxw * 0.30, -R * 0.96)
    lw = max(2, int(R * 0.13))
    for a, b in ((back, crank), (crank, seat), (seat, back),
                 (crank, bar), (seat, bar), (bar, front)):
        d.line([a[0], a[1], b[0], b[1]], fill=(196, 72, 64), width=lw)
    # כידון
    d.line([bar[0] - R * 0.34, bar[1] - R * 0.10,
            bar[0] + R * 0.34, bar[1] - R * 0.18],
           fill=METAL_LIT, width=lw)
    # אוכף
    d.ellipse([seat[0] - R * 0.24, seat[1] - R * 0.14,
               seat[0] + R * 0.24, seat[1] + R * 0.08], fill=(46, 44, 48))
    # שרשרת: קו דק בין הקראנק לציר האחורי
    d.line([crank[0], crank[1], back[0], back[1]],
           fill=(72, 76, 82), width=max(1, int(R * 0.06)))
    # דוושות
    for sgn in (1, -1):
        a = spin * 1.6
        d.line([crank[0], crank[1],
                crank[0] + math.cos(a) * R * 0.30 * sgn,
                crank[1] + math.sin(a) * R * 0.30 * sgn],
               fill=METAL, width=max(1, int(R * 0.09)))


def bake(out_dir, location: dict, width: int = 1920,
         height: int = 1080, seed: int = 7) -> dict:
    """צורב את הפארק **ומוסיף** עליו את ארבעת האובייקטים.

    מחזיר את המניפסט של `park` עם מפתח `disney` נוסף. המניפסט
    הוא מה שעובר לדפדפן, ולכן המקומות שבו הם המקומות שהשכבה
    הדינמית תשתמש בהם - ולא העתק שלהם.
    """
    from PIL import Image, ImageDraw                     # noqa: PLC0415

    loc = dict(location)
    loc["total_seconds"] = float(loc.get("total_seconds", TOTAL_SECONDS))
    man = park.bake(out_dir, loc, width=width, height=height, seed=seed)

    out = Path(out_dir)
    gpath = out / man["layers"]["ground"]
    gnd = Image.open(gpath).convert("RGBA")
    w, h = gnd.size
    over = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(over)
    shadow = (man["shadow"]["dx"], man["shadow"]["dy"])

    # הסדר הוא סדר העומק: ספסל ואופניים לפני המזרקה, שרחוקה יותר.
    _fountain(d, w, h, shadow)
    _bench(d, w, h, shadow)
    # **האופניים אינם נצרבים.** הניסיון הראשון צרב אותם במקום
    # המנוחה וצייר אותם דינמית בנסיעה, והתוצאה נראתה בתמונת
    # בדיקה: **שני זוגות אופניים בפריים** - הצרוב נשאר ליד הנערה
    # אחרי שהדינמי כבר הגיע לסבא. תמונה צרובה אי אפשר למחוק
    # בזמן ריצה, ולכן גוף שזז אפילו פעם אחת חייב להיות דינמי
    # **לכל אורך הסרט**, כולל בשניות שבהן הוא עומד.
    # רק הצל של מקום המנוחה נשאר צרוב, כי הוא חלק מהדשא.
    _bike_shadow(d, w, h, shadow)
    Image.alpha_composite(gnd, over).convert("RGBA").save(gpath)

    man["disney"] = {
        "total_sec": loc["total_seconds"],
        "fountain_loop": FOUNTAIN_LOOP,
        "layout": {k: (dict(v) if isinstance(v, dict) else v)
                   for k, v in LAYOUT.items()},
        "lamp": dict(park.PROPS["lamp"]),
        "react": {"lag": REACT_LAG, "decay": REACT_DECAY,
                  "tree_x": LAYOUT["react_tree"]["x"]},
        "objects": ["fountain", "bike", "bench", "lamp"],
    }
    (out / "env.json").write_text(
        json.dumps(man, ensure_ascii=False, indent=1), encoding="utf-8")
    return man


# ====================================================== השכבה הדינמית

def jets_at(t: float) -> list[dict]:
    """סילוני המזרקה בזמן t. רשימת טיפות ביחידות פריים מנורמלות.

    כל טיפה היא בליסטיקה פשוטה עם **פאזה משלה** שנגזרת מהאינדקס,
    ולכן הן אינן יוצאות יחד - סילון שכל טיפותיו יוצאות באותו רגע
    נקרא כקפיץ ולא כמים. המחזור הוא `FOUNTAIN_LOOP`, שמתחלק
    באורך הסרט, ולכן התפר מתלכד.
    """
    s = LAYOUT["fountain"]
    cx, cy = s["at"]
    top = cy - s["post_h"]
    n = int(s["jets"])
    out = []
    for i in range(n):
        ph = (i / n)
        u = ((t / FOUNTAIN_LOOP) + ph) % 1.0
        # קשת: עולה, נעצרת, נופלת. 4u(1-u) הוא שיא ב-u=0.5.
        rise = 4.0 * u * (1.0 - u)
        ang = (i / max(1, n - 1) - 0.5) * 2.0
        out.append({
            "x": round(cx + ang * s["rx"] * 0.74 * u, 5),
            "y": round(top - s["jet_h"] * rise, 5),
            "r": round(0.0035 * (1.0 - 0.45 * u), 5),
            "a": round(0.92 * (1.0 - u * u), 4),
        })
    return out


def bike_at(t: float, roll_t0: float, roll_t1: float) -> dict:
    """האופניים בזמן t: מקום, סיבוב גלגל, הטיה, והאם הצרוב מוצג.

    הסיבוב נגזר מהמקום (`spin = מרחק/רדיוס`) ולא נכתב בנפרד.
    גלגל שמסתובב בקצב שאינו קצב הנסיעה הוא "החלקת גלגל", והיא
    נראית בדיוק כמו החלקת רגליים.
    """
    s = LAYOUT["bike"]
    x0, y0 = s["rest"]
    x1, y1 = s["stop"]
    if t <= roll_t0:
        # `baked` נשאר False גם במנוחה: אין עותק צרוב למחוק.
        return {"x": x0, "y": y0, "spin": 0.0, "lean": -0.22,
                "baked": False}
    u = min(1.0, (t - roll_t0) / max(1e-6, roll_t1 - roll_t0))
    # האטה אל העצירה: 1-(1-u)^2 מגיע ליעד עם מהירות אפס.
    e = 1.0 - (1.0 - u) ** 2
    x = x0 + (x1 - x0) * e
    y = y0 + (y1 - y0) * e
    # הסיבוב מצטבר לפי המרחק שנעבר, ביחידות רדיוס.
    dist = abs(x - x0)
    spin = dist / max(1e-6, s["wheel_r"]) * 2.0
    # ההטיה מתיישרת תוך כדי הנסיעה ואז נוטה לצד השני בעצירה.
    lean = -0.22 * (1.0 - e) + 0.16 * e * (1.0 - u) * 4.0
    return {"x": round(x, 5), "y": round(y, 5), "spin": round(spin, 4),
            "lean": round(lean, 4), "baked": False}


def gust_at(t: float, pass_t: float) -> float:
    """עוצמת המשב בעלווה בזמן t, כשהרץ עובר את קו העץ ב-`pass_t`.

    אפס לפני המעבר, שיא ב-`pass_t + REACT_LAG`, ודעיכה
    אקספוננציאלית. ראה למה זה סיבתי ולא סינוס, בראש הקובץ.
    """
    dt = t - pass_t
    if dt <= 0.0:
        return 0.0
    # עקומה עם שיא מדויק ב-REACT_LAG: dt/lag · exp(1-dt/lag)
    k = dt / REACT_LAG
    return float(k * math.exp(1.0 - k) * math.exp(-REACT_DECAY * 0.0)
                 * math.exp(-max(0.0, dt - REACT_LAG) * REACT_DECAY))


def stage_spec(roll_t0: float, roll_t1: float) -> dict:
    """המפרט שעובר לדפדפן פעם אחת, לפני הפריים הראשון."""
    return {
        "fountain": dict(LAYOUT["fountain"]),
        "bike": dict(LAYOUT["bike"]),
        "roll": [roll_t0, roll_t1],
        "loop": FOUNTAIN_LOOP,
        "lamp": dict(park.PROPS["lamp"]),
    }


# ============================================================== חוזה

def validate(man: dict, out_dir, roll_t0: float = 14.0,
             roll_t1: float = 33.0) -> dict:
    """חוזה הסביבה. מוסיף על `park.validate` ולא מחליף אותו."""
    out = dict(park.validate(man, out_dir))

    def chk(name, ok, detail):
        out[name] = {"pass": bool(ok), "detail": str(detail)}

    dz = man.get("disney") or {}
    chk("ארבעת האובייקטים רשומים במניפסט",
        sorted(dz.get("objects") or []) == ["bench", "bike", "fountain",
                                            "lamp"],
        dz.get("objects"))

    # הלופים מתחלקים באורך הסרט. אחרת התפר קופץ, וזה נראה בדיוק
    # כמו פריים שאבד.
    tot = float(dz.get("total_sec", 0.0))
    chk("אורך הסרט מתחלק במחזור הרוח",
        tot > 0 and abs(tot / park.LOOP_SEC
                        - round(tot / park.LOOP_SEC)) < 1e-9,
        f"{tot} / {park.LOOP_SEC}")
    chk("ומתחלק גם במחזור המזרקה",
        tot > 0 and abs(tot / FOUNTAIN_LOOP
                        - round(tot / FOUNTAIN_LOOP)) < 1e-9,
        f"{tot} / {FOUNTAIN_LOOP}")

    # המים יוצאים מהקערה העליונה ולא מהאוויר, ונופלים בחזרה לאגן.
    s = LAYOUT["fountain"]
    top = s["at"][1] - s["post_h"]
    js = [jets_at(t) for t in (0.0, FOUNTAIN_LOOP * 0.37,
                               FOUNTAIN_LOOP * 0.73)]
    ys = [p["y"] for fr in js for p in fr]
    chk("סילוני המזרקה בין הקערה העליונה לשיא הסילון",
        min(ys) >= top - s["jet_h"] - 1e-9 and max(ys) <= top + 1e-9,
        f"{min(ys):.4f}..{max(ys):.4f} (קערה {top:.4f})")
    chk("ומחזור המים נסגר על עצמו",
        all(abs(a["x"] - b["x"]) < 1e-9 and abs(a["y"] - b["y"]) < 1e-9
            for a, b in zip(jets_at(0.0), jets_at(FOUNTAIN_LOOP))),
        "פריים 0 = פריים הלופ")

    # האופניים: נעים, מסתובבים בקצב הנסיעה, ונעצרים ביעד.
    b0 = bike_at(roll_t0 - 0.1, roll_t0, roll_t1)
    bm = bike_at((roll_t0 + roll_t1) * 0.5, roll_t0, roll_t1)
    b1 = bike_at(roll_t1, roll_t0, roll_t1)
    chk("האופניים במנוחה עד רגע הפגיעה",
        b0["spin"] == 0.0 and abs(b0["x"] - LAYOUT["bike"]["rest"][0]) < 1e-9,
        f"x={b0['x']}")
    # אין עותק צרוב, ולכן לעולם אין שני זוגות אופניים בפריים.
    chk("ואין עותק צרוב שלהם בשכבת הקרקע",
        not any(bike_at(t, roll_t0, roll_t1)["baked"]
                for t in (0.0, roll_t0, (roll_t0 + roll_t1) / 2, roll_t1)),
        "האופניים דינמיים לכל אורך הסרט")
    chk("ומתגלגלים אל נקודת העצירה",
        abs(b1["x"] - LAYOUT["bike"]["stop"][0]) < 1e-6
        and b1["x"] > bm["x"] > b0["x"],
        f"{b0['x']} -> {bm['x']} -> {b1['x']}")
    # קצב הגלגל נגזר מהמרחק: אם הוא לא, יש החלקת גלגל.
    want = abs(bm["x"] - b0["x"]) / LAYOUT["bike"]["wheel_r"] * 2.0
    chk("וסיבוב הגלגל נגזר מהמרחק (אין החלקת גלגל)",
        abs(bm["spin"] - want) < 1e-3, f"{bm['spin']:.3f} מול {want:.3f}")
    chk("ושלושתם בתוך הפריים",
        all(0.0 < v["x"] < 1.0 and 0.0 < v["y"] < 1.0
            for v in (b0, bm, b1)), "בפנים")

    # תגובת העלווה היא סיבתית: אפס לפני, שיא אחרי, ודעיכה.
    pt = 18.0
    chk("העלווה אינה מגיבה לפני שהרץ הגיע",
        gust_at(pt - 0.01, pt) == 0.0 and gust_at(0.0, pt) == 0.0,
        "0.000")
    peak_t = max((pt + i * 0.01 for i in range(0, 300)),
                 key=lambda tt: gust_at(tt, pt))
    chk(f"והשיא מגיע {REACT_LAG}ש אחרי המעבר",
        abs((peak_t - pt) - REACT_LAG) < 0.02,
        f"{peak_t - pt:.3f}ש")
    chk("והמשב דועך",
        gust_at(pt + 3.0, pt) < gust_at(peak_t, pt) * 0.2,
        f"{gust_at(pt + 3.0, pt):.4f} מול שיא "
        f"{gust_at(peak_t, pt):.4f}")

    # הפנס נקרא מ-`park.PROPS` ולא נכתב שוב.
    chk("מקום הפנס זהה למקום שב-park", dz.get("lamp") == park.PROPS["lamp"],
        dz.get("lamp"))
    return out


def passed(man: dict, out_dir, **kw) -> bool:
    return all(v["pass"] for v in validate(man, out_dir, **kw).values())


def main(argv=None) -> int:
    import argparse                                      # noqa: PLC0415
    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(description="הפארק הדינמי (TASK 18)")
    ap.add_argument("--out",
                    default=r"D:\claude-bot\out\char3d\env\park_disney")
    ap.add_argument("--width", type=int, default=1920)
    ap.add_argument("--height", type=int, default=1080)
    ap.add_argument("--contract", action="store_true",
                    help="רק החוזה, על מניפסט קיים")
    a = ap.parse_args(argv)

    from production.script import sunbeam50 as SB        # noqa: PLC0415
    loc = dict(SB.LOCATION)
    loc["total_seconds"] = TOTAL_SECONDS

    if a.contract:
        man = json.loads((Path(a.out) / "env.json").read_text("utf-8"))
    else:
        man = bake(a.out, loc, width=a.width, height=a.height)

    rep = validate(man, a.out)
    bad = 0
    for k, v in rep.items():
        print(("✅" if v["pass"] else "❌"), k, "-", v["detail"])
        bad += 0 if v["pass"] else 1
    print(f"\n{len(rep) - bad}/{len(rep)} עברו")
    return 0 if bad == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
