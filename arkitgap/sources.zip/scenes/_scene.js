/* מנוע הסצנה המשותף.
 *
 * הלב של העניין: האנימציה *לא רצה*. היא ציר זמן קפוא, ומי שמרנדר
 * קורא __seek(t) ומקבל את התמונה המדויקת של שנייה t. לכן אותו דף
 * מפיק בדיוק אותו סרטון בכל מחשב ובכל עומס, וזה בדיוק ההבדל בין
 * רינדור לבין הקלטת מסך.
 *
 * כל ציור שאינו GSAP (קנבס, חלקיקים, ASCII) נרשם ב-SCENE.draw
 * ומקבל את אותו t — אחרת שכבה אחת מתקדמת בזמן אמת והשאר קפואה.
 */
(function () {
  "use strict";

  // עוצרים את השעון של GSAP. בלי זה ציר הזמן אמנם מושהה, אבל
  // כל tween שנוצר עם delay מתעורר לבד בין פריים לפריים.
  if (window.gsap) {
    gsap.ticker.sleep();
    gsap.ticker.lagSmoothing(0);
  }

  const draws = [];
  const tl = gsap.timeline({ paused: true });

  const SCENE = {
    tl: tl,
    /** רושם ציור ידני שתלוי בזמן (קנבס / טקסט מתגלגל) */
    draw: function (fn) { draws.push(fn); return SCENE; },
    /** אורך מינימלי של הסצנה, גם אם ציר הזמן קצר יותר */
    minDuration: 0,
    /** עוזר: בחירה */
    q: (sel) => document.querySelector(sel),
    qa: (sel) => Array.from(document.querySelectorAll(sel)),
  };
  window.SCENE = SCENE;

  /** מונה מספרים — נפוץ מאוד, ולכן יושב כאן ולא בכל סצנה */
  SCENE.countTo = function (el, to, opts) {
    opts = opts || {};
    const o = { v: opts.from === undefined ? 0 : opts.from };
    const fmt = opts.format || ((v) => Math.round(v).toLocaleString("he-IL"));
    return gsap.to(o, {
      v: to, duration: opts.duration || 1.4,
      ease: opts.ease || "power2.out",
      onUpdate: () => { el.textContent = fmt(o.v); },
    });
  };

  /** חשיפת ציטוט מילה-מילה */
  SCENE.revealWords = function (el, text, opts) {
    opts = opts || {};
    el.textContent = "";
    const words = text.split(" ");
    words.forEach((w, i) => {
      const s = document.createElement("span");
      s.textContent = w + (i < words.length - 1 ? " " : "");
      s.style.opacity = "0";
      s.style.display = "inline-block";
      el.appendChild(s);
    });
    return gsap.to(el.children, {
      opacity: 1, y: 0, duration: 0.42,
      stagger: opts.stagger || 0.1, ease: "power2.out",
      startAt: { y: 16 },
    });
  };

  /* ======================================================================
   *  ספריית התנועה (04/10) — נוספה לפי דירוג המועצה
   *  (Qwen 3.8 · Command A · Codestral) לשאלה "מה משפר את האיכות
   *  הנתפסת בלי לעלות זמן רינדור בארכיטקטורה הזאת דווקא".
   *
   *  הכלל שמסנן את כולן: בלי GPU (--disable-gpu) כל פיקסל מחושב
   *  על המעבד, ולכן מה שעולה *לפי פיקסל* מתורגם ישירות לזמן
   *  רינדור. מה שעולה *לפי צורה* הוא בחינם.
   *
   *  נפסלו בכוונה, ושתיהן בהמלצה מפורשת של המועצה:
   *    · backdrop-filter — טשטוש של כל מה שמתחת לאלמנט, פעמיים
   *      בכל פריים, על המעבד. עד פי עשרה האטה.
   *    · feTurbulence / feDisplacementMap — רעש פרלין לכל פיקסל.
   *      נראה מרהיב ושורף את הרינדור.
   *  ו-filter: blur() נמצא בשימוש רק על צורות קטנות, לא על מסך מלא;
   *  drop-shadow מחושב לפי מסלול הצורה ולכן הוא הזול מכולם.
   * ====================================================================== */

  /** מצלמה וירטואלית (Ken Burns): זום ופאן איטיים על כל הסצנה.
   *
   *  למה זה הראשון בדירוג: פריים סטטי נראה כמו מצגת, ואותו פריים
   *  בדיוק עם תנועת מצלמה של 4% נראה כמו צילום. העלות היא טרנספורם
   *  אחד על שכבה אחת — הדפדפן מחשב אותו בשלב ההרכבה, לא בציור.
   *
   *  חובה מעטפת: הטרנספורם יושב על `#camera` ולא על `#stage`,
   *  אחרת הוא מתנגש עם כל טרנספורם שסצנה עושה על ילדיה.
   */
  SCENE.camera = function (opts) {
    opts = opts || {};
    const cam = SCENE.q("#camera") || SCENE.q("#stage");
    if (!cam) return null;
    const from = opts.from || {};
    const to = opts.to || {};
    gsap.set(cam, {
      transformOrigin: opts.origin || "50% 50%",
      scale: from.scale === undefined ? 1 : from.scale,
      x: from.x || 0, y: from.y || 0,
    });
    return tl.to(cam, {
      scale: to.scale === undefined ? 1.06 : to.scale,
      x: to.x || 0, y: to.y || 0,
      duration: opts.duration || 8,
      ease: opts.ease || "none",
    }, opts.at || 0);
  };

  /** קו/נתיב SVG ש"נכתב" מעצמו.
   *
   *  stroke-dasharray נמדד מהנתיב עצמו (getTotalLength), ולכן זה
   *  עובד על כל צורה בלי להזין מספר ביד — וזו בדיוק הטעות שהייתה
   *  בסצנות הקיימות, שבהן האורך (239, 70) הוקלד ידנית ולכן שינוי
   *  ברדיוס היה שובר את האנימציה בשקט.
   */
  SCENE.drawStroke = function (sel, opts) {
    opts = opts || {};
    const els = gsap.utils.toArray(sel);
    const tweens = [];
    els.forEach((el, i) => {
      let len = 100;
      try { len = el.getTotalLength(); } catch (e) { /* לא נתיב */ }
      len = Math.ceil(len) + 1;
      gsap.set(el, { strokeDasharray: len, strokeDashoffset: opts.reverse ? -len : len });
      tweens.push(tl.to(el, {
        strokeDashoffset: 0,
        duration: opts.duration || 1.1,
        ease: opts.ease || "power2.inOut",
      }, (opts.at || 0) + i * (opts.stagger || 0)));
    });
    return tweens;
  };

  /** חשיפה גיאומטרית ב-clip-path — "מגב" שמגלה תוכן.
   *
   *  למה דווקא זה ב-RTL: fade פשוט מגלה את כל השורה יחד, ומגב
   *  מימין לשמאל מגלה אותה בכיוון הקריאה. clip-path הוא צורה,
   *  לא פיקסלים, ולכן הוא בחינם.
   */
  SCENE.wipe = function (sel, opts) {
    opts = opts || {};
    const dir = opts.dir || "rtl";
    const hidden = {
      rtl: "inset(0% 0% 0% 100%)",
      ltr: "inset(0% 100% 0% 0%)",
      up: "inset(100% 0% 0% 0%)",
      down: "inset(0% 0% 100% 0%)",
      circle: "circle(0% at 50% 50%)",
    }[dir] || "inset(0% 0% 0% 100%)";
    const shown = dir === "circle" ? "circle(75% at 50% 50%)" : "inset(0% 0% 0% 0%)";
    const els = gsap.utils.toArray(sel);
    gsap.set(els, { clipPath: hidden, webkitClipPath: hidden });
    return tl.to(els, {
      clipPath: shown, webkitClipPath: shown,
      duration: opts.duration || 0.9,
      stagger: opts.stagger || 0,
      ease: opts.ease || "power3.inOut",
    }, opts.at || 0);
  };

  /** מורפינג בין שני נתיבי SVG, בלי MorphSVG (תוסף בתשלום).
   *
   *  האינטרפולציה היא על המספרים שבתוך ה-`d` עצמו. התנאי —
   *  ושומרים עליו בבדיקה מפורשת — הוא שני נתיבים עם **אותו מבנה
   *  פקודות ואותו מספר נקודות**. בלי הבדיקה הזו הצורה מתפוצצת
   *  לצורה מקרית ונראית כמו באג גרפי, בלי שום שגיאה בקונסולה.
   */
  SCENE.morph = function (sel, toPath, opts) {
    opts = opts || {};
    const el = typeof sel === "string" ? SCENE.q(sel) : sel;
    if (!el) return null;
    const num = /-?\d*\.?\d+(?:e[-+]?\d+)?/gi;
    const fromD = el.getAttribute("d");
    const a = fromD.match(num) || [];
    const b = toPath.match(num) || [];
    if (a.length !== b.length ||
        fromD.replace(num, "#") !== toPath.replace(num, "#")) {
      // מבנה שונה — מורפינג מספרי יהרוס את הצורה. מתחלפים בשקיפות.
      console.warn("SCENE.morph: מבנה הנתיבים שונה, נסיגה למעבר שקיפות");
      return tl.to(el, { opacity: 0, duration: (opts.duration || 1) / 2,
                         onComplete: () => el.setAttribute("d", toPath) },
                   opts.at || 0)
               .to(el, { opacity: 1, duration: (opts.duration || 1) / 2 });
    }
    const tmpl = fromD.split(num);
    const p = { v: 0 };
    const from = a.map(Number), to = b.map(Number);

    /* **מלכודת שנתפסה בעין ב-04/10, ולא על ידי שום שגיאה.**
       אם הנתיב צויר קודם ב-drawStroke, יושב עליו stroke-dasharray
       שנמדד מהצורה *הישנה*. הצורה החדשה ארוכה ממנה, וההפרש פשוט
       לא מצויר: הקטע האחרון של הקו נעלם, הקו "לא מגיע" לנקודה
       שבקצה — ואין על זה שום הודעה בקונסולה. נמדד כאן: 268 מול
       362 יחידות, כלומר הסגמנט הרביעי כולו היה חסר.
       לכן, כשהנתיב מצויר במלואו (offset אפס), האורך נמדד מחדש
       בכל פריים של המורפינג.

       והבדיקה חייבת לרוץ **בתוך** onUpdate, ובכל פריים מחדש:
       · בזמן הבנייה ה-offset עדיין שווה לאורך המלא (הקו טרם
         נכתב), ולכן בדיקה מוקדמת הייתה מחזירה "אין כאן dash"
         ומחמיצה בדיוק את המקרה שהיא באה לתפוס.
       · ומטמון אינו אפשרי כאן, כי דגימת ציר זמן יכולה לרנדר את
         המורפינג גם לפני שהציור הושלם וגם אחריו, והתשובה שונה
         בשני המקרים. זו קריאת תכונה אחת — זולה מכל מטמון. */
    const checkDash = function () {
      const da = el.style.strokeDasharray ||
                 el.getAttribute("stroke-dasharray") || "";
      if (!da) return false;
      const off = parseFloat(el.style.strokeDashoffset ||
                             el.getAttribute("stroke-dashoffset") || "0");
      return Math.abs(off) < 0.5;   // הקו כבר מצויר במלואו
    };

    return tl.to(p, {
      v: 1, duration: opts.duration || 1.2,
      ease: opts.ease || "power2.inOut",
      onUpdate: function () {
        let d = "";
        for (let i = 0; i < from.length; i++) {
          d += tmpl[i] + (from[i] + (to[i] - from[i]) * p.v).toFixed(2);
        }
        el.setAttribute("d", d + tmpl[tmpl.length - 1]);
        if (checkDash()) {
          try {
            el.style.strokeDasharray = Math.ceil(el.getTotalLength()) + 1;
            el.style.strokeDashoffset = 0;
          } catch (e) { /* לא נתיב מדיד */ }
        }
      },
    }, opts.at || 0);
  };

  /** פעימת זוהר ב-drop-shadow (ולא ב-blur).
   *
   *  ההבדל אינו קוסמטי: blur מחשב גרעין על **כל פיקסל** באזור,
   *  ו-drop-shadow נגזר ממסלול הצורה. על טקסט וקווים התוצאה
   *  נראית זהה והמחיר שונה בסדר גודל.
   */
  SCENE.glow = function (sel, opts) {
    opts = opts || {};
    const c = opts.color || "rgba(56,225,255,.75)";
    const r = opts.radius || 26;
    return tl.fromTo(sel,
      { filter: `drop-shadow(0 0 2px ${c})` },
      { filter: `drop-shadow(0 0 ${r}px ${c})`,
        duration: opts.duration || 1.3, ease: "sine.inOut",
        yoyo: true, repeat: opts.repeat === undefined ? 1 : opts.repeat,
        stagger: opts.stagger || 0 },
      opts.at || 0);
  };

  /** כרטיס בתלת-ממד: perspective + rotateY/rotateX.
   *  עולה טרנספורם אחד לשכבה, ונותן עומק שצל לבדו לא נותן.
   */
  SCENE.tilt = function (sel, opts) {
    opts = opts || {};
    const els = gsap.utils.toArray(sel);
    els.forEach((el) => {
      if (el.parentElement) el.parentElement.style.perspective = (opts.perspective || 1400) + "px";
    });
    gsap.set(els, {
      transformStyle: "preserve-3d",
      rotateY: opts.fromY === undefined ? -28 : opts.fromY,
      rotateX: opts.fromX || 0,
      opacity: 0,
    });
    return tl.to(els, {
      rotateY: opts.toY || 0, rotateX: opts.toX || 0, opacity: 1,
      duration: opts.duration || 1.0,
      stagger: opts.stagger || 0.12,
      ease: opts.ease || "power3.out",
    }, opts.at || 0);
  };

  /** הקלדה שנגזרת מהזמן.
   *
   *  **זו המלכודת המרכזית של רינדור דטרמיניסטי**, ולכן היא יושבת
   *  כאן ולא מועתקת לכל סצנה: מונה מצטבר (`i++` בכל פריים) נשבר
   *  ברגע שדוגמים ציר זמן — דילוג אחורה מראה טקסט ארוך מדי,
   *  והרצה חוזרת של אותו פריים מכפילה תווים. החישוב חייב להיות
   *  פונקציה טהורה של t.
   */
  SCENE.typeOn = function (el, text, opts) {
    opts = opts || {};
    const start = opts.at || 0;
    const cps = opts.cps || 34;              // תווים לשנייה
    const caret = opts.caret === false ? "" : "▌";
    SCENE.draw(function (t) {
      const n = Math.max(0, Math.min(text.length,
                Math.floor((t - start) * cps)));
      const blink = (Math.floor(t * 2) % 2 === 0) && n < text.length ? caret : "";
      el.textContent = text.slice(0, n) + blink;
    });
    if (start + text.length / cps > SCENE.minDuration) {
      SCENE.minDuration = start + text.length / cps + 0.4;
    }
    return SCENE;
  };

  /* "נשימה" עדינה — שום פריים לא עומד במקום יותר מכמה שניות.
     היא יושבת ב-timeline *נפרד* בכוונה: לופ עם repeat על ציר הזמן
     הראשי מאריך את אורך הסצנה למאה שניות ויותר, וזה נמדד כאן —
     סצנה של 7 שניות יצאה 132. ציר רקע אינו קובע אורך. */
  const amb = gsap.timeline({ paused: true, repeat: -1 });
  SCENE.ambient = amb;

  SCENE.breathe = function (sel, amount) {
    const a = amount || 1.015;
    gsap.utils.toArray(sel).forEach((el, i) => {
      amb.to(el, {
        scale: a, duration: 3.2, ease: "sine.inOut", yoyo: true, repeat: 1,
      }, i * 0.4);
    });
  };

  /* האורך המוצהר (minDuration) הוא הקובע כשהוא קיים: ציר הזמן
     עצמו עלול להיות קצר (הסצנה נשארת על המסך) או ארוך בגלל לופ. */
  window.__duration = function () {
    return SCENE.minDuration > 0 ? SCENE.minDuration : tl.duration();
  };

  /* הדגימה חייבת להיות עם suppressEvents=false (הארגומנט השני).
     עם true — ברירת המחדל האינטואיטיבית ל"קפיצה שקטה בציר" — GSAP
     מדכא את **כל** ה-callbacks, ובכללם onUpdate. כלומר כל אנימציה
     שמציירת דרך onUpdate (מונה מספרים, טקסט נבנה) מתקדמת פנימית
     ולא כותבת כלום למסך. נמדד כאן 04/10: ארבעת המונים בלוח הבקרה
     נשארו "0" לאורך כל הסצנה, בלי שום שגיאה ובלי שום סימן בקוד.
     אנחנו תמיד דוגמים קדימה, ולכן הרצה חוזרת של callback אינה סיכון. */
  window.__seek = function (t) {
    tl.time(Math.min(t, tl.duration()), false);
    const ad = amb.duration();
    if (ad > 0) amb.time(t % ad, false);
    for (let i = 0; i < draws.length; i++) draws[i](t);
    return true;
  };

  /* מסמן מוכנות רק אחרי שהגופנים נטענו — אחרת הפריימים הראשונים
     מרונדרים בגופן נסיגה והטקסט מקפץ באמצע הסרטון. */
  function finish() {
    if (typeof window.buildScene === "function") window.buildScene();
    window.__seek(0);
    window.__ready = true;
  }
  if (document.fonts && document.fonts.ready) {
    document.fonts.ready.then(() => setTimeout(finish, 30));
  } else {
    setTimeout(finish, 120);
  }
})();
