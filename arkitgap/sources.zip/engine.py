# -*- coding: utf-8 -*-
"""
מנוע רינדור אנימציה: דף HTML מונפש (GSAP) -> פריימים -> MP4.

העקרון: הדף לא מריץ את האנימציה בזמן אמת. הוא חושף פונקציה
`__seek(t)` שמקפיאה את ציר הזמן בשנייה t בדיוק, ולכן כל פריים
נדגם דטרמיניסטית - אותו קלט נותן בדיוק אותו סרטון, בלי קשר
למהירות המחשב. זה מה שמבדיל רינדור מהקלטת מסך.

התקשורת עם הדפדפן היא Chrome DevTools Protocol מעל aiohttp,
בלי playwright ובלי node (אין אותם על המכונה הזו).
"""
from __future__ import annotations

import asyncio
import base64
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Callable, Optional

import aiohttp

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "out"

CHROME_CANDIDATES = [
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
]


def find_chrome() -> str:
    for p in CHROME_CANDIDATES:
        if os.path.exists(p):
            return p
    raise RuntimeError("לא נמצא דפדפן מבוסס Chromium על המכונה")


# ----------------------------------------------- מעבד גרפי: דגלים שנמדדו
#
# 07/10/2026. עד היום היה כאן `--disable-gpu` קבוע, והוא הכריח את Chrome
# לראסטריזציה בתוכנה (SwiftShader). נמדד על המכונה הזו, אותו שיידר כבד,
# 1280x720, 60 פריימים עם readPixels שחוסם עד שה-GPU סיים:
#
#     --use-angle=gl        239.8 fps   Intel(R) Graphics, OpenGL 4.5
#     --use-angle=vulkan    147.4 fps   Intel Vulkan 1.4
#     ברירת מחדל / d3d11    114.7 fps   Intel D3D11
#     swiftshader (תוכנה)    10.1 fps   <-- מה שהיה כאן עד היום
#     desktop gl / egl / d3d9 5.5 fps   Microsoft Basic Render Driver (!)
#
# כלומר המסלול שהיה כאן היה פי 23.7 איטי מהחומרה שכבר יש במחשב.
# שלוש הערות שכל אחת מהן עלתה מדידה:
#   * `--use-gl=desktop`, `--use-gl=egl` ו-`--use-angle=d3d9` **גרועים
#     מהתוכנה**: הם נופלים ל-Microsoft Basic Render Driver, שהוא מתאם
#     תוכנה של ווינדוס. אל תנסה אותם כ"אולי יעזור".
#   * בלי `--enable-unsafe-swiftshader` ועם `--no-sandbox`, headless=new
#     החזיר "no webgl context" ולא נפילה לתוכנה. לכן יש כאן בדיקה אמיתית
#     של שם המנוע ולא הנחה שהדגל עבד.
#   * לכן הסדר הוא רשימה, והמסלול התוכנה נשאר אחרון כרשת ביטחון - על
#     רנר בענן בלי GPU הוא היחיד שיעבוד.
# יציבות מול מהירות (07/10, אחרי נפילה אמיתית): `--use-angle=gl` היה
# המהיר ביותר במדידה המבודדת (239.8 fps), אבל על הבמה האמיתית - שמונה
# דמויות עם שלד של 90 עצמות, צללים וסופר-סמפלינג כפול - תהליך ה-GPU
# נתקע אחרי 67 שניות וחיבור ה-CDP נפל ב-TimeoutError. מסלול התוכנה סיים
# את אותה ריצה בשלמותה. המועצה (Command A, Qwen@Groq) אמרה את אותו דבר:
# ה-OpenGL של אינטל על ווינדוס הוא שכבת תרגום ל-D3D11 ולא יציב תחת עומס
# ממושך. לכן **D3D11 ראשון** - 114.7 fps, עדיין פי 11 מהתוכנה, והוא
# המסלול המקורי של ווינדוס. `gl` נשאר בסולם אבל אחרון מבין החומרות.
# `--ignore-gpu-blocklist` הוסר: הוא מכריח דרייברים שגוגל חסמה מסיבה.
_STABLE = ["--disable-gpu-watchdog", "--disable-gpu-process-crash-limit"]

GPU_LADDER: list[list[str]] = [
    ["--use-gl=angle", "--use-angle=d3d11", *_STABLE],
    ["--use-gl=angle", "--use-angle=vulkan", "--enable-features=Vulkan",
     *_STABLE],
    [*_STABLE],
    ["--use-gl=angle", "--use-angle=gl", *_STABLE],
    ["--use-gl=angle", "--use-angle=swiftshader", "--enable-unsafe-swiftshader"],
]

SOFT_ARGS = GPU_LADDER[-1]

# בדיקת עומס לפני ההפקה. ציור של כמה מאות קריאות על יעד גדול עם
# readPixels שחוסם - אם הדרייבר מתמוטט, שייתמוטט כאן ולא בדקה העשירית
# של רינדור. 400 קריאות על 1536x864 נמשכות פחות משנייה על חומרה תקינה,
# ועל דרייבר תקוע הן לא חוזרות - ואז הסולם ממשיך לשלב הבא.
_STRESS_JS = """(function(){try{
var c=document.createElement('canvas');c.width=1536;c.height=864;
var g=c.getContext('webgl2')||c.getContext('webgl');if(!g)return 'no-ctx';
var vs='attribute vec2 p;varying vec2 v;void main(){v=p;gl_Position=vec4(p,0.,1.);}';
var fs='precision highp float;varying vec2 v;uniform float t;void main(){vec3 s=vec3(0.);'
 +'for(int i=0;i<90;i++){float f=float(i);s+=vec3(sin(v.x*f+t),cos(v.y*f-t),sin(v.x*f*v.y));}'
 +'gl_FragColor=vec4(abs(s)/90.,1.);}';
function mk(k,x){var s=g.createShader(k);g.shaderSource(s,x);g.compileShader(s);
 if(!g.getShaderParameter(s,g.COMPILE_STATUS))throw g.getShaderInfoLog(s);return s;}
var p=g.createProgram();g.attachShader(p,mk(g.VERTEX_SHADER,vs));
g.attachShader(p,mk(g.FRAGMENT_SHADER,fs));g.linkProgram(p);g.useProgram(p);
var b=g.createBuffer();g.bindBuffer(g.ARRAY_BUFFER,b);
g.bufferData(g.ARRAY_BUFFER,new Float32Array([-1,-1,3,-1,-1,3]),g.STATIC_DRAW);
var l=g.getAttribLocation(p,'p');g.enableVertexAttribArray(l);
g.vertexAttribPointer(l,2,g.FLOAT,false,0,0);
var tl=g.getUniformLocation(p,'t'),px=new Uint8Array(4),t0=performance.now();
for(var i=0;i<400;i++){g.uniform1f(tl,i*0.01);g.drawArrays(g.TRIANGLES,0,3);
 if(i%50===0)g.readPixels(0,0,1,1,g.RGBA,g.UNSIGNED_BYTE,px);}
g.readPixels(0,0,1,1,g.RGBA,g.UNSIGNED_BYTE,px);
return 'ok:'+Math.round(performance.now()-t0);
}catch(e){return 'err:'+e;}})()"""

# שמות מנוע שמשמעותם "אין חומרה" - גם אם Chrome דיווח על הקשר תקין.
_SOFTWARE_NAMES = ("swiftshader", "basic render", "software",
                   "llvmpipe", "softpipe")

# שם המנוע שנבחר נזכר בין ריצות, כדי לא לשלם על טיפוס הסולם כל פעם.
_LADDER_CACHE = ROOT / ".gpu_choice.json"


def _is_software(renderer: str | None) -> bool:
    low = (renderer or "").lower()
    return (not low) or any(w in low for w in _SOFTWARE_NAMES)


def _ladder_state() -> dict:
    try:
        d = json.loads(_LADDER_CACHE.read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except Exception:                          # noqa: BLE001 - אין מטמון
        return {}


def blocked_rungs() -> list[int]:
    """דרגות שהודחו אחרי כשל **בהפקה אמיתית**, לא במבחן העומס."""
    raw = _ladder_state().get("blocked") or []
    return [int(i) for i in raw if isinstance(i, (int, float))]


def demote(reason: str, args: list[str] | None = None,
           index: int | None = None) -> int | None:
    """מדיח את דרגת ה-GPU שבה קרה הכשל, ומוחק את הבחירה השמורה.

    **למה זה חייב להיות קובץ ולא משתנה.** 07/10: `--use-angle=vulkan`
    עבר את מבחן העומס (שיידר אחד על קנבס קטן) ואיבד את ההקשר על
    הבמה האמיתית - שמונה דמויות, 715 אלף משולשים, צללים ו-SSS.
    הכשל נראה רק בהפקה, וההפקה הבאה הייתה חוזרת לאותה דרגה בדיוק
    כי היא נשמרה במטמון. דרגה שהודחה נשארת מודחת עד שמוחקים את
    הקובץ ביד.
    """
    if index is None and args is not None:
        try:
            index = GPU_LADDER.index(list(args))
        except ValueError:
            index = None
    if index is None:
        index = _ladder_state().get("index")
    if not isinstance(index, int) or not (0 <= index < len(GPU_LADDER)):
        return None
    st = _ladder_state()
    blocked = sorted(set(blocked_rungs()) | {index})
    # **הדרגה האחרונה (תוכנה) לעולם אינה מודחת.** היא רשת הביטחון,
    # ובלעדיה הסולם מתרוקן והרינדור מפסיק לעבוד לגמרי.
    blocked = [i for i in blocked if i != len(GPU_LADDER) - 1]
    st.update({"blocked": blocked, "last_failure": reason})
    st.pop("index", None)
    st.pop("renderer", None)
    try:
        _LADDER_CACHE.write_text(json.dumps(st, ensure_ascii=False),
                                 encoding="utf-8")
    except Exception:                          # noqa: BLE001
        pass
    return index


class Browser:
    """דפדפן נסתר שמנוהל דרך CDP. חלון אמיתי אינו נפתח."""

    def __init__(self, width: int, height: int, scale: int = 1, port: int = 0):
        self.width, self.height, self.scale = width, height, scale
        self.port = port or (9500 + (os.getpid() % 400))
        self.proc: Optional[subprocess.Popen] = None
        self.profile = Path(tempfile.mkdtemp(prefix="animprof_"))
        self.session: Optional[aiohttp.ClientSession] = None
        self.ws: Optional[aiohttp.ClientWebSocketResponse] = None
        self._msg_id = 0
        self.renderer: Optional[str] = None     # שם מנוע ה-WebGL בפועל
        self.gpu_args: list[str] = []

    def _args(self, extra: list[str]) -> list[str]:
        return [
            find_chrome(),
            "--headless=new",
            f"--remote-debugging-port={self.port}",
            f"--user-data-dir={self.profile}",
            f"--window-size={self.width},{self.height}",
            "--force-device-scale-factor=%d" % self.scale,
            "--hide-scrollbars",
            "--no-first-run",
            "--no-default-browser-check",
            "--disable-extensions",
            "--disable-dev-shm-usage",
            "--disable-background-timer-throttling",
            "--disable-renderer-backgrounding",
            "--mute-audio",
            "--allow-file-access-from-files",
            *extra,
            "about:blank",
        ]

    async def _spawn(self, extra: list[str]) -> None:
        """מרים דפדפן עם קבוצת דגלים אחת ומתחבר אליו ב-CDP."""
        self.profile = Path(tempfile.mkdtemp(prefix="animprof_"))
        flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
        self.proc = subprocess.Popen(
            self._args(extra), stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL, creationflags=flags,
        )
        self.session = aiohttp.ClientSession()
        ws_url = await self._wait_for_target()
        self.ws = await self.session.ws_connect(
            ws_url, max_msg_size=200 * 1024 * 1024)
        await self.cmd("Page.enable")
        await self.cmd("Runtime.enable")
        await self.cmd("Emulation.setDeviceMetricsOverride", {
            "width": self.width, "height": self.height,
            "deviceScaleFactor": self.scale, "mobile": False,
        })

    async def probe_renderer(self) -> str | None:
        """שם מנוע ה-WebGL בפועל. None = לא נוצר הקשר כלל.

        חובה לבדוק בפועל ולא להסתמך על הדגל: נמדד 07/10 שדגל יכול להתקבל
        ובכל זאת ליפול ל-Microsoft Basic Render Driver, שאיטי מהתוכנה.
        """
        try:
            return await self.js(
                "(function(){var c=document.createElement('canvas');"
                "var g=c.getContext('webgl2')||c.getContext('webgl');"
                "if(!g)return null;"
                "var d=g.getExtension('WEBGL_debug_renderer_info');"
                "return d?g.getParameter(d.UNMASKED_RENDERER_WEBGL)"
                ":g.getParameter(g.RENDERER);})()")
        except Exception:                      # noqa: BLE001 - אין הקשר
            return None

    async def stress_ok(self, timeout: float = 45.0) -> bool:
        """האם הדרייבר שורד עומס ציור קצר. מפיל דרייבר רע כאן ולא בהפקה."""
        try:
            res = await self.cmd("Runtime.evaluate", {
                "expression": _STRESS_JS, "returnByValue": True},
                timeout=timeout)
            val = res.get("result", {}).get("value")
            return isinstance(val, str) and val.startswith("ok:")
        except Exception:                      # noqa: BLE001 - נתקע או מת
            return False

    async def _teardown(self) -> None:
        for closer in (lambda: self.ws and self.ws.close(),
                       lambda: self.session and self.session.close()):
            try:
                c = closer()
                if c is not None:
                    await c
            except Exception:                  # noqa: BLE001
                pass
        self.ws = self.session = None
        if self.proc:
            try:
                self.proc.terminate()
                self.proc.wait(timeout=8)
            except Exception:                  # noqa: BLE001
                try:
                    self.proc.kill()
                except Exception:              # noqa: BLE001
                    pass
            self.proc = None
        shutil.rmtree(self.profile, ignore_errors=True)

    async def start(self) -> None:
        """מרים דפדפן על **חומרה** אם יש, ונופל לתוכנה רק אם אין.

        עד 07/10/2026 היה כאן `--disable-gpu` קבוע, כלומר תמיד תוכנה.
        """
        if os.environ.get("ANIM_FORCE_SOFTWARE") == "1":
            await self._spawn(SOFT_ARGS)
            self.renderer = await self.probe_renderer()
            return

        # דרגה שהודחה אחרי כשל בהפקה אמיתית אינה נוסה שוב: היא
        # עוברת את מבחן העומס ונופלת רק על הבמה המלאה.
        bad = set(blocked_rungs())
        ladder = [a for i, a in enumerate(GPU_LADDER) if i not in bad]
        # אם כבר נמדד כאן מה עובד - מתחילים ממנו, ולא מטפסים מחדש.
        saved = _ladder_state()
        idx = saved.get("index", -1)
        if isinstance(idx, int) and 0 <= idx < len(GPU_LADDER) \
                and idx not in bad:
            want = GPU_LADDER[idx]
            ladder = [want] + [a for a in ladder if a != want]

        last = None
        for extra in ladder:
            await self._spawn(extra)
            name = await self.probe_renderer()
            last = name
            if not _is_software(name) and await self.stress_ok():
                self.renderer = name
                self.gpu_args = extra
                try:
                    # **מיזוג ולא דריסה.** 07/10: ריצה מוצלחת כתבה
                    # `{index, renderer}` בלבד ומחקה את `blocked`,
                    # ולכן הדרגה שהודחה חזרה לסולם בריצה הבאה -
                    # והפילה שוב הפקה שלמה. רשימת ההדחה שורדת רק
                    # אם כל כותב מכבד את מה שכבר בקובץ.
                    st = _ladder_state()
                    st.update({"index": GPU_LADDER.index(extra),
                               "renderer": name})
                    _LADDER_CACHE.write_text(
                        json.dumps(st, ensure_ascii=False),
                        encoding="utf-8")
                except Exception:              # noqa: BLE001
                    pass
                return
            await self._teardown()

        # אין חומרה בכלל (למשל רנר בענן) - תוכנה היא התשובה הנכונה.
        await self._spawn(SOFT_ARGS)
        self.renderer = await self.probe_renderer() or last
        self.gpu_args = SOFT_ARGS

    async def _wait_for_target(self, timeout: float = 25.0) -> str:
        """ממתין שהדפדפן יפתח את הפורט. לולאה קצרה עם תקרה - לא המתנה פתוחה."""
        deadline = time.time() + timeout
        last = ""
        while time.time() < deadline:
            try:
                async with self.session.get(
                    f"http://127.0.0.1:{self.port}/json/list",
                    timeout=aiohttp.ClientTimeout(total=3),
                ) as r:
                    data = await r.json()
                for t in data:
                    if t.get("type") == "page" and t.get("webSocketDebuggerUrl"):
                        return t["webSocketDebuggerUrl"]
            except Exception as e:  # הפורט עוד לא פתוח - תקין בשניות הראשונות
                last = repr(e)
            await asyncio.sleep(0.25)
        raise RuntimeError(f"הדפדפן לא נפתח בזמן ({last})")

    async def cmd(self, method: str, params: dict | None = None, timeout: float = 60.0):
        self._msg_id += 1
        mid = self._msg_id
        await self.ws.send_json({"id": mid, "method": method, "params": params or {}})
        deadline = time.time() + timeout
        while time.time() < deadline:
            msg = await self.ws.receive(timeout=max(1.0, deadline - time.time()))
            if msg.type is not aiohttp.WSMsgType.TEXT:
                continue
            data = json.loads(msg.data)
            if data.get("id") == mid:
                if "error" in data:
                    raise RuntimeError(f"{method}: {data['error']}")
                return data.get("result", {})
        raise TimeoutError(method)

    async def js(self, expr: str, await_promise: bool = False):
        res = await self.cmd("Runtime.evaluate", {
            "expression": expr, "returnByValue": True,
            "awaitPromise": await_promise,
        })
        if res.get("exceptionDetails"):
            desc = res["exceptionDetails"].get("exception", {}).get("description")
            raise RuntimeError(f"שגיאת JS: {desc or res['exceptionDetails']}")
        return res.get("result", {}).get("value")

    async def open_file(self, path: Path) -> None:
        url = Path(path).resolve().as_uri()
        await self.cmd("Page.navigate", {"url": url})
        # ממתין לדף שמסמן שהוא מוכן. לולאה קצרה, לא המתנה פתוחה.
        for _ in range(120):
            try:
                if await self.js("!!window.__ready"):
                    return
            except Exception:
                pass
            await asyncio.sleep(0.1)
        raise RuntimeError(f"הדף לא הכריז על עצמו כמוכן: {path}")

    async def shot(self, tries: int = 3) -> bytes:
        """פריים בודד, עם ניסיונות חוזרים.

        **למה יש כאן ניסיון חוזר ולא רק קריאה אחת.** 06/10: רינדור של
        1500 פריימים נפל בפריים 90 על `TimeoutError: Page.captureScreenshot`
        אחרי 12 דקות עבודה, כי *צילום אחד* לא חזר בזמן. המכונה חנוקה
        בזיכרון, ותחת עומס רגעי (משימה כבדה אחרת, או איסוף זבל של
        הדפדפן) צילום יכול לאחר הרבה מעבר לזמן הרגיל שלו - ואז לחזור
        בסדר גמור. פריים אחד שמאחר אינו סיבה לזרוק סרט שלם.

        ההמתנה בין הניסיונות גדלה, והיא **לא** רק השהיה: היא נותנת
        לדפדפן לסיים את מה שחנק אותו. ניסיון חוזר מיידי היה נופל שוב
        מאותה סיבה בדיוק.
        """
        last: Exception | None = None
        for i in range(max(1, tries)):
            try:
                res = await self.cmd(
                    "Page.captureScreenshot",
                    {"format": "jpeg", "quality": 95,
                     "captureBeyondViewport": False},
                    timeout=60.0 * (i + 1))
                return base64.b64decode(res["data"])
            except (TimeoutError, asyncio.TimeoutError) as e:
                last = e
                await asyncio.sleep(1.0 + 2.0 * i)
        raise TimeoutError(
            f"Page.captureScreenshot נכשל ב-{tries} ניסיונות ({last!r})")

    async def close(self) -> None:
        await self._teardown()


# ----------------------------------------------------------------- קידוד

class Encoder:
    """כותב פריימים ל-MP4 דרך PyAV. לא מריץ ffmpeg כתהליך נפרד.

    **הקידוד רץ בחוט נפרד, ובכוונה.** 04/10 נמדד שהלולאה הייתה
    טורית לחלוטין: הדפדפן מצלם, ואז פייתון מפענח JPEG ומקודד
    ב-libx264 בזמן שהדפדפן **יושב בטל**, ואז מבקשים את הפריים
    הבא. שני הצדדים חיכו זה לזה לחלופין. המועצה (Qwen 3.8,
    Command A) הצביעה על כך שהצוואר הוא מחזור השליחה-המתנה
    ולא הצילום עצמו.

    התור חסום (`maxsize`) בכוונה: בלי תקרה, דפדפן מהיר בסצנה
    קלה היה דוחף אלפי פריימי JPEG לזיכרון לפני שהמקודד מדביק,
    והמכונה הזאת חנוקה בזיכרון. ארבעה פריימים מכסים את ההמתנה
    ולא יותר.

    הדטרמיניזם אינו נפגע: התור שומר על הסדר (FIFO), ולכן
    הפריימים נכנסים למקודד בדיוק באותו סדר שבו צולמו.
    """

    def __init__(self, path: Path, width: int, height: int, fps: int, crf: int = 18):
        import queue
        import threading

        import av  # ייבוא מקומי: כבד, ולא תמיד נדרש
        self.av = av
        path.parent.mkdir(parents=True, exist_ok=True)
        self.container = av.open(str(path), mode="w")
        self.stream = self.container.add_stream("libx264", rate=fps)
        self.stream.width, self.stream.height = width, height
        self.stream.pix_fmt = "yuv420p"
        self.stream.options = {
            "crf": str(crf), "preset": "medium", "profile": "high",
            "movflags": "+faststart",
        }
        self.n = 0
        self._q: "queue.Queue" = queue.Queue(maxsize=4)
        self._err: BaseException | None = None
        self._worker = threading.Thread(target=self._drain, daemon=True)
        self._worker.start()

    # ----------------------------------------------------- הצד של החוט
    def _encode_jpeg(self, blob: bytes) -> None:
        import io

        from PIL import Image
        img = Image.open(io.BytesIO(blob))
        if img.mode != "RGB":
            img = img.convert("RGB")
        if img.size != (self.stream.width, self.stream.height):
            img = img.resize((self.stream.width, self.stream.height), Image.LANCZOS)
        self._mux(self.av.VideoFrame.from_image(img))

    def _mux(self, frame) -> None:
        for packet in self.stream.encode(frame):
            self.container.mux(packet)
        self.n += 1

    def _drain(self) -> None:
        """מקודד עד שמגיע הסימן לסיום. שגיאה נשמרת ומורמת בחוט הראשי."""
        while True:
            blob = self._q.get()
            try:
                if blob is None:
                    return
                if self._err is None:
                    self._encode_jpeg(blob)
            except BaseException as exc:      # noqa: BLE001 - מועבר הלאה
                self._err = exc
            finally:
                self._q.task_done()

    # ---------------------------------------------------- הצד של הקורא
    def _check(self) -> None:
        if self._err is not None:
            raise self._err

    def add_jpeg(self, blob: bytes) -> None:
        self._check()
        self._q.put(blob)           # חוסם אם המקודד מפגר - וזו ההגנה על הזיכרון

    def add_frame(self, frame) -> None:
        """הזנת פריים מוכן. ממתינה לתור כדי לא להפוך את הסדר."""
        self._check()
        self._q.join()
        self._check()
        self._mux(frame)

    def close(self) -> None:
        self._q.put(None)
        self._worker.join(timeout=900)
        try:
            self._check()
        finally:
            for packet in self.stream.encode():
                self.container.mux(packet)
            self.container.close()


# ----------------------------------------------------------------- רינדור

async def render_scene(
    html: Path,
    mp4: Path,
    seconds: float,
    fps: int = 30,
    width: int = 1920,
    height: int = 1080,
    scale: int = 1,
    on_progress: Optional[Callable[[int, int], None]] = None,
) -> dict:
    total = int(round(seconds * fps))
    br = Browser(width, height, scale)
    t0 = time.time()
    try:
        await br.start()
        await br.open_file(html)
        dur = await br.js("window.__duration ? window.__duration() : 0")
        if dur and dur > 0.2:
            total = int(round(float(dur) * fps))
        enc = Encoder(mp4, width, height, fps)
        try:
            for i in range(total):
                await br.js(f"window.__seek({i / fps:.6f})")
                enc.add_jpeg(await br.shot())
                if on_progress and (i % max(1, fps) == 0):
                    on_progress(i, total)
        finally:
            enc.close()
    finally:
        await br.close()
    return {
        "mp4": str(mp4), "frames": total, "fps": fps,
        "seconds": round(total / fps, 2),
        "render_sec": round(time.time() - t0, 1),
        "size_mb": round(mp4.stat().st_size / 1048576, 2) if mp4.exists() else 0,
    }


def render(html, mp4, seconds=10.0, **kw) -> dict:
    return asyncio.run(render_scene(Path(html), Path(mp4), seconds, **kw))


def concat(parts: list[Path], out: Path, fps: int = 30) -> dict:
    """מאחד קטעים לסרטון אחד בשרשור פאקטים, בלי לפענח ובלי לקודד מחדש.

    **אל תחזיר את זה לפענוח+קידוד.** נמדד כאן פעמיים (04/10): הזנת
    פריימים ממוחזרים למקודד מפילה את התהליך **בשקט**, קריסה ברמת C
    בלי traceback ובלי קוד שגיאה, אחרי כמה מאות פריימים - ומשאירה
    קובץ בלי moov atom שנראה כמו "ההרצה נקטעה". זה בדיוק מה שהסתיר
    את התקלה: שני קבצים באותו גודל מדויק נראו כמו שינה של המחשב.

    ומעבר לכך קידוד מחדש מאבד איכות בחינם: כל הסצנות יוצאות מאותו
    מקודד באותן מידות ובאותו קצב, ולכן הפאקטים תואמים כמות שהם.
    נמדד: 1476 פריימים ב-0.9 שניות במקום דקות.
    """
    import av
    tmp = Path(out).with_name("_concat_tmp.mp4")
    oc = av.open(str(tmp), mode="w", options={"movflags": "+faststart"})
    ost = None
    offset = 0          # ביחידות ה-time_base של הזרם, לא בשניות
    total = 0
    w = h = 0
    try:
        for p in parts:
            ic = av.open(str(p))
            ist = ic.streams.video[0]
            if ost is None:
                ost = oc.add_stream_from_template(ist)
                w = ist.codec_context.width
                h = ist.codec_context.height
            # משך פריים ביחידות time_base, למקרה שהדמוקסר לא נותן duration
            step = int(round(1 / (float(ist.average_rate) * float(ist.time_base))))
            end = 0
            for packet in ic.demux(ist):
                if packet.dts is None:      # פאקט ריקון בסוף הדמוקס
                    continue
                packet.stream = ost
                packet.pts = (packet.pts or 0) + offset
                packet.dts = (packet.dts or 0) + offset
                if not packet.duration:
                    packet.duration = step
                end = max(end, packet.pts + packet.duration)
                oc.mux(packet)
                total += 1
            ic.close()
            offset = end
    finally:
        oc.close()
    tmp.replace(out)
    return {"mp4": str(out), "frames": total, "width": w, "height": h,
            "seconds": round(total / fps, 2),
            "size_mb": round(Path(out).stat().st_size / 1048576, 2)}


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    html = Path(sys.argv[1])
    mp4 = Path(sys.argv[2]) if len(sys.argv) > 2 else OUT / (html.stem + ".mp4")
    secs = float(sys.argv[3]) if len(sys.argv) > 3 else 10.0

    def prog(i, t):
        print(f"  פריים {i}/{t}", flush=True)

    info = render(html, mp4, secs, on_progress=prog)
    print(json.dumps(info, ensure_ascii=False, indent=1))
