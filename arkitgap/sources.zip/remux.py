# -*- coding: utf-8 -*-
"""מאחד את הסצנות הקיימות לסרטון אחד, בלי לרנדר מחדש (שנייה אחת)."""
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.stdout.reconfigure(encoding="utf-8")
import engine
from build import ORDER, OUT

parts = [OUT / f"{n}.mp4" for n in ORDER]
miss = [p.name for p in parts if not p.exists()]
if miss:
    print("חסרות סצנות:", miss); raise SystemExit(2)
info = engine.concat(parts, OUT / "showreel.mp4")
print(json.dumps(info, ensure_ascii=False, indent=1))
