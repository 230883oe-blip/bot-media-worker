# -*- coding: utf-8 -*-
"""שערי הגשר `park90_render`. בלי דפדפן ובלי רינדור.

כל שער כאן מפריך **באג שקרה בפועל** בבניית הגשר, ולא מתאר את
הקוד. שלושה מהם נתפסו בתמונת בדיקה אחרי שהקוד כבר "נראה נכון":

* `window.P90` - ה-script של `stage.html` הוא `type="module"`,
  ולכן `const` בו אינו נראה מבחוץ. בלי החשיפה המפורשת בדיקת
  "העגלה נבנתה" החזירה שקר על במה תקינה, והרינדור נעצר.
* סימן ה-`pitch` - `crane_at` מחזיר שיפוע בקונבנציה הקולנועית
  (שלילי = מביט למטה), והבמה מציבה את המצלמה ב-
  `ty + sin(pitch)*dist`. העברה כמות שהוא הפכה את מצלמת הקרן
  לצילום מהרצפה.
* נשימת המרחק - המסגור חושב מהפרישה **בזמן הפריים**, והלהקה
  נסוגה החוצה בדיוק בשוט ההתכנסות. המרחק יצא 9.4 -> 11.5 -> 7.2,
  כלומר המצלמה נסוגה ואז זינקה.
"""
from __future__ import annotations

import math
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
STUDIO = HERE.parent
if str(STUDIO) not in sys.path:
    sys.path.insert(0, str(STUDIO))

from showreel import park90 as P90                       # noqa: E402
from showreel import park90_render as R                  # noqa: E402

#: גבהים מייצגים. הערכים האמיתיים נקראים מה-GLB, וטעינתם כאן
#: הייתה הופכת בדיקה של שנייה לבדיקה של דקה.
HEIGHTS = {k: 1.52 + 0.047 * i for i, k in enumerate(R.SLOTS)}


def _crane_samples(n: int = 481):
    t0, t1 = 74.0, 90.0
    out = []
    for i in range(n):
        t = t0 + (t1 - t0) * i / (n - 1)
        c = R._cam("crane", i / (n - 1), HEIGHTS, min(t, t1 - 1e-3))
        cam_y = c["ty"] + math.sin(math.radians(c["pitch"])) * c["dist"]
        out.append((t, c, cam_y))
    return out


def audit() -> dict:
    g: dict = {}

    def gate(key, ok, detail):
        g[key] = {"pass": bool(ok), "detail": detail}

    # ------------------------------------------------- הבמה
    html = R.stage_html()
    gate("הבמה נבנית משמונה המקומות של disney_story",
         html.count("const SLOTS = ") >= 1 and "SRC[k]" in html,
         f"{len(html)} תווים")
    gate("ונוסף בה נתיב שמשתנה בזמן (lx)",
         "m.lx" in html and "const bx = " in html,
         f"{html.count('m.lx')} שימושים ב-lx")
    gate("ושני האובייקטים התלת-ממדיים נבנים",
         "P90.cart" in html and "P90.pet" in html and "p90Frame" in html,
         f"עגלה {html.count('P90.cart')} · חיה {html.count('P90.pet')}")
    # זה השער שתפס את הבאג האמיתי: בלי החשיפה ל-window,
    # `Runtime.evaluate` לא רואה את P90 וההפקה נעצרת.
    gate("ושניהם חשופים ל-window (ה-script הוא module)",
         "window.P90 = P90;" in html and
         "window.p90Frame = p90Frame;" in html,
         "window.P90 + window.p90Frame")
    gate("והקריאה אליהם יושבת בתוך __frame",
         "if (f.p90) p90Frame(f.p90);" in html,
         "נקראת פעם אחת לפריים")

    # ------------------------------------------------ השוטים
    shots = R.build_shots(HEIGHTS, R.FPS)
    total = sum(s.secs for s in shots)
    gate("ששת השוטים מסתכמים ב-90 שניות",
         abs(total - 90.0) < 1e-9, f"{total:.3f} שניות ב-{len(shots)} שוטים")
    full = all(len(s.actors) == 8 and len(s.moves) == 8 for s in shots)
    gate("ובכל שוט שמונה שחקנים ושמונה תנועות",
         full, f"{min(len(s.actors) for s in shots)}-"
               f"{max(len(s.actors) for s in shots)} שחקנים לשוט")
    seeds = set(R.SEEDS.values())
    near = min(abs(a - b) for a in seeds for b in seeds if a != b)
    gate("ולכל דמות זרע נבדל (שמונה בבואות אינן הרכב)",
         len(seeds) == 8 and near >= 0.09,
         f"{len(seeds)} זרעים · הקרובים ביותר {near:.2f}")

    # ------------------------------------------------ המצלמה
    sm = _crane_samples()
    worst = max(abs(cy - P90.crane_at(t)["y"]) for t, _c, cy in sm)
    gate("גובה מצלמת הקרן בפועל הוא זה שהשער מודד",
         worst < 0.02, f"סטייה מרבית {worst * 100:.1f} ס\"מ")
    rises = all(b[2] >= a[2] - 1e-6 for a, b in zip(sm, sm[1:]))
    gate("והוא עולה מונוטונית לאורך השוט",
         rises, f"{sm[0][2]:.2f} -> {sm[-1][2]:.2f} מ'")
    # סימן ה-pitch: שלילי פירושו מצלמה מתחת למטרה, כלומר
    # צילום מהרצפה במקום קרן.
    gate("והשיפוע חיובי לכל אורכו (מבט מלמעלה ולא מהרצפה)",
         all(c["pitch"] >= 0.0 for _t, c, _y in sm),
         f"{sm[0][1]['pitch']:.1f}° -> {sm[-1][1]['pitch']:.1f}°")
    jump = max(abs(b[1]["dist"] - a[1]["dist"])
               for a, b in zip(sm, sm[1:])) * 30.0
    gate("והמרחק אינו נושם פנימה והחוצה",
         jump < 1.8, f"מהירות נסיגה מרבית {jump:.2f} מ'/ש'")
    wide = R._cam("wide", 0.5, HEIGHTS, 10.0)
    gate("השוט הרחב ממסגר את החזה ולא את המותניים",
         wide["ty"] > 1.2, f"נקודת מבט בגובה {wide['ty']:.2f} מ'")
    # הפרישה בשוט ההתחמקות היא הרחבה ביותר, ושם המצלמה חייבת
    # לכסות אותה - אחרת שתי תת-הקבוצות נחתכות בקצוות.
    spread = R._span_at(52.0)
    need = (spread * 0.5 * 1.08) / math.tan(math.radians(18.0))
    gate("והמרחק מכסה את הפרישה הרחבה ביותר",
         R._cam("wide", 0.5, HEIGHTS, 52.0)["dist"] >= need - 1e-6,
         f"פרישה {spread:.2f} מ' · מרחק נדרש {need:.2f} מ'")

    # ------------------------------------------------ העגלה
    cf = [R.cart_frame(t) for t in
          [P90.CART_ROLL[0] + 0.1 * i for i in range(260)]]
    gate("העגלה מתגלגלת קדימה בלבד",
         all(b["x"] >= a["x"] - 1e-9 for a, b in zip(cf, cf[1:])),
         f"{cf[0]['x']:.2f} -> {cf[-1]['x']:.2f} מ'")
    gate("והגלגל נגזר מהמרחק (אין החלקת גלגל)",
         all(abs(c["wheel"] * P90.CART_WHEEL_R
                 - (c["x"] - P90.CART_X0)) < 1e-3 for c in cf),
         f"סטייה מרבית {max(abs(c['wheel'] * P90.CART_WHEEL_R - (c['x'] - P90.CART_X0)) for c in cf):.1e} מ'")
    # נטיית הבלימה: גוף נוטה קדימה כשהוא מאט, ולא כשהוא מאיץ.
    gate("והיא נוטה קדימה רק כשהיא בולמת",
         all(c["tilt"] <= 0.0 for c in cf)
         and min(c["tilt"] for c in cf) < -0.005,
         f"נטייה מרבית {min(c['tilt'] for c in cf):.3f} רדיאן")
    gate("והיא עומדת לפני המערכה השלישית",
         R.cart_frame(60.0)["v"] == 0.0,
         f"מהירות בשנייה 60: {R.cart_frame(60.0)['v']}")

    # ------------------------------------------------- החיה
    inside = [R.pet_frame(t) for t in
              [P90.PET_DART[0] + 0.05,
               sum(P90.PET_DART) / 2, P90.PET_DART[1] - 0.05]]
    outside = [R.pet_frame(t) for t in (0.0, 30.0, 70.0, 90.0)]
    gate("החיה קיימת רק בחלון החצייה",
         all(p["active"] for p in inside)
         and not any(p["active"] for p in outside),
         f"{len(inside)} בפנים · {len(outside)} בחוץ")
    gate("והיא מביטה לכיוון שבו היא רצה",
         all(abs(p["yaw"]) > 0.3 for p in inside),
         f"זווית באמצע {inside[1]['yaw']:.2f} רדיאן")
    gate("והניתור לעולם אינו שוקע מתחת לרצפה",
         all(R.pet_frame(P90.PET_DART[0] + 0.02 * i).get("hop", 0.0) >= 0.0
             for i in range(500)), "hop >= 0 בכל הפריימים")

    # ------------------------------ הנתיב שנשלח לבמה בפועל
    # זה החיבור עצמו: `lx` חייב להיות **מוחלט** ולהגיע לכל
    # דמות בכל פריים. `lx` חסר פירושו שההתפצלות וההתכנסות
    # לא קורות, והווידאו יוצא עם שמונה דמויות שצועדות ישר.
    # **הערך הצפוי נבנה מהעלילה, והנמדד מהקוד שהרינדור מריץ**
    # (`R.mv_frame`). גרסה ראשונה של השער הזה חישבה את שניהם
    # מאותה שורה - היא עברה תמיד והוכיחה אפס.
    bad, miss, n = [], 0, 0
    for sh in shots:
        for t in (0.0, sh.secs * 0.5, sh.secs - 1.0 / R.FPS):
            t = max(0.0, t)
            tf = sh.t_abs + t
            for k in R.SLOTS:
                n += 1
                got = R.mv_frame(sh, k, t, tf)
                if "lx" not in got:
                    miss += 1
                    continue
                if abs(got["lx"] - P90.lane_at(k, tf)) > 5e-5:
                    bad.append((sh.key, k, round(tf, 2)))
    gate("הנתיב המוחלט נגזר מ-park90 בכל פריים ולכל דמות",
         not bad and miss == 0,
         f"{n} דגימות · {len(bad)} סטיות · {miss} בלי lx")
    # ושצעדי ההליכה **לא נמחקו** בדרך: `lx` שמחליף את המילון
    # כולו היה מקפיא את הרגליים ומחליק את הדמות על הדשא.
    keeps = all(set(R.mv_frame(sh, k, 1.0, sh.t_abs + 1.0))
                >= {"ox", "oy", "oz", "lx"}
                for sh in shots for k in R.SLOTS)
    gate("ובלי למחוק את צעדי ההליכה",
         keeps, "ox/oy/oz נשמרים לצד lx")
    moved = abs(P90.lane_at("A", 89.9) - P90.lane_at("A", 0.0))
    gate("והוא באמת זז (אחרת ההתפצלות לא קרתה)",
         moved > 1.0, f"המוביל זז {moved:.2f} מ' לאורך הרצף")

    # ------------------------------ TASK 25: הזווית, החיבוק והקול
    #
    # שלוש החוליות החדשות נבדקות **בנקודת החיבור לגשר** ולא רק
    # ב-`park90`: שם הן מספרים נכונים, וכאן השאלה היא אם הם
    # באמת מגיעים לבמה. חוליה שמחושבת נכון ולא נשלחת היא בדיוק
    # הכשל שאי אפשר לראות בתמונת בדיקה.
    sh6 = shots[-1]
    t_end = 15.9
    mv = R.mv_frame(sh6, P90.LEAD_M, t_end, sh6.t_abs + t_end)
    gate("הזווית הדינמית נשלחת לבמה בכל פריים",
         "ry" in mv and all("ry" in R.mv_frame(s, k, 1.0, s.t_abs + 1.0)
                            for s in shots for k in R.SLOTS),
         f"ry={mv.get('ry')}° בשנייה {sh6.t_abs + t_end:.0f}")
    gate("ובחיבוק השניים מסובבים זה אל זה",
         (R.mv_frame(sh6, P90.LEAD_M, t_end, sh6.t_abs + t_end)["ry"]
          > 30.0
          and R.mv_frame(sh6, P90.LEAD_F, t_end, sh6.t_abs + t_end)["ry"]
          < -30.0),
         f"{P90.LEAD_M}: "
         f"{R.mv_frame(sh6, P90.LEAD_M, t_end, sh6.t_abs + t_end)['ry']}° · "
         f"{P90.LEAD_F}: "
         f"{R.mv_frame(sh6, P90.LEAD_F, t_end, sh6.t_abs + t_end)['ry']}°")

    from rig import controls as _C                      # noqa: PLC0415
    over_end = R.body_over(P90.LEAD_M, 89.9)
    bad_names = [k for k in over_end if k not in _C.CONTROLS]
    gate("ובקרות החיבוק כולן שמות מוכרים למערכת השליטה",
         not bad_names and bool(over_end),
         f"{len(over_end)} בקרות" + (f" · לא מוכרות: {bad_names}"
                                     if bad_names else ""))
    gate("והן ריקות כשאין חיבוק (ניצב, ותחילת הרצף)",
         not R.body_over("C", 89.9) and not R.body_over(P90.LEAD_M, 5.0),
         "ניצב: {} · פתיחה: {}")

    from rig import vcast as _VC                        # noqa: PLC0415
    vs = [R.voice_of(k) for k in R.SLOTS]
    gate("ולכל מקום פרופיל קול נפרד שקיים בפועל",
         len(set(vs)) == len(R.SLOTS) and all(v in _VC.BY_KEY for v in vs),
         f"{len(set(vs))} קולות · "
         + " ".join(f"{_VC.BY_KEY[v].f0_hz:.0f}" for v in vs) + " הרץ")

    return g


def passed() -> bool:
    return all(v["pass"] for v in audit().values())


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8")
    g = audit()
    bad = 0
    for k, v in g.items():
        print(("  ✓ " if v["pass"] else "  ✗ ") + k + " — " + v["detail"])
        bad += 0 if v["pass"] else 1
    print(f"\n{len(g) - bad}/{len(g)} שערים עברו")
    return 0 if bad == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
