# -*- coding: utf-8 -*-
"""TASK 22 (06/10) - "הפארק הגדול": 90 שניות, שמונה דמויות, שלוש מערכות.

ההוראה שהתקבלה מגדירה עלילה בשלוש מערכות ומסתיימת בחיבוק רומנטי
במרכז הפארק, עם מצלמת קרן שעולה. המודול הזה הוא **החוזה** של
הרצף הזה: הוא מגדיר אותו כנתונים, גוזר ממנו את הגאומטריה
(העגלה, החיה הרובוטית, שמונת הנתיבים, ההתכנסות לחיבוק ומסלול
המצלמה), ומודד אותו.

================================================================
למה חוזה ולא מפיק
================================================================

`showreel.disney_story` הוא המפיק של 60 השניות, והוא מקובע
ל-`SLOTS` של ארבעה **בעומק** - `LANE_X`, `LANE_YAW`, הבמה
שנוצרת בשש החלפות, ולולאת הפריימים. הרחבה שלו לשמונה היא
ריפקטור של אותה לולאה שעשרות בדיקות עוברות דרכה.

לכן ההפרדה כאן היא בדיוק זו של TASK 18, ובכיוון ההפוך: שם
הבמה הוכללה והמפיק נכתב מחדש; כאן **העלילה** מופרדת מהמפיק
לגמרי. `park90` אינו מרנדר דבר - הוא מגדיר מה אמור לקרות ומתי,
ומוכיח שזה עקבי. מי שיריץ רינדור יקרא מכאן את `SHOTS`, את
`lane_at`, את `cart_at`, את `pet_at` ואת `crane_at`, ויקבל רצף
שכבר נמדד. באג בעלילה נתפס ב-3 שניות של בדיקה ולא ב-40 דקות
של רינדור.

================================================================
מה נמדד, ולמה דווקא זה
================================================================

כל אחד מהשערים למטה מפריך **טענה מההוראה**, ולא מתאר אותה:

* "90-second sequence" -> סכום השוטים הוא 90.000 בדיוק, וכל שוט
  הוא כפולה שלמה של 1/30. שוט שאינו כפולה שלמה מייצר פריים
  שבור בחיתוך, וזה נמדד כאן ב-05/10.
* "6 to 8 unique characters with distinct heights" -> שמונה
  דמויות, שמונה גבהים נבדלים, וכל אחת מופיעה בפועל.
* "split into sub-groups to dodge" -> בשוט ההתחמקות הנתיבים
  מתפצלים לשתי קבוצות **שאינן נחתכות**: המרחק המינימלי בין
  הקבוצות גדול מרוחב דמות. פיצול שבו שתי הקבוצות עוברות זו
  דרך זו אינו פיצול, הוא התנגשות.
* "a cart halts safely" -> מהירות העגלה חיובית לכל אורך
  המערכה השנייה ומתאפסת **לפני** תחילת השלישית, והבלימה
  מונוטונית (אין קפיצה אחורה).
* "converge and embrace warmly at the center" -> המרחק בין שתי
  הדמויות הראשיות יורד מונוטונית בשוט האחרון, מגיע למרחק חיבוק,
  ונקודת המפגש היא מרכז הפארק (x=0) בטולרנס.
* "camera sweeps up in a cinematic crane shot" -> גובה המצלמה
  עולה מונוטונית בשוט האחרון, והעלייה גדולה מגובה הדמות הגבוהה -
  אחרת זו הרמה ולא קרן.
"""
from __future__ import annotations

import math
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
STUDIO = HERE.parent
if str(STUDIO) not in sys.path:
    sys.path.insert(0, str(STUDIO))

from rig import cast_disney as CD                        # noqa: E402
from rig import pipeline as PL                           # noqa: E402

FPS = 30
TOTAL_SECONDS = 90.0

#: שמונת המקומות על הבמה. הסדר הוא סדר הליהוק של `CD.CAST8`.
SLOTS = ("A", "B", "C", "D", "E", "F", "G", "H")
CAST = CD.CAST8
SLOT_OF = dict(zip(SLOTS, CAST))

#: שני הראשיים: הבחור והבחורה שמתחבקים בסוף. ההוראה מכנה אותם
#: "the main guy and girl", וכאן הם אריאל ושיר - אותו זוג שכבר
#: נושא את העלילה ב-60 השניות, כך שהרצף אינו מחליף גיבורים.
LEAD_M, LEAD_F = "A", "B"

#: נתיב ההליכה של כל דמות, ב-x. שמונה דמויות בפריים אחד דורשות
#: הפרדה רחבה יותר מארבע: 1.20 מ' ו-1.85 מ' באותו שוט רחב, ואם
#: שני נתיבים קרובים מדי הנמוך נעלם מאחורי הגבוה.
#: **סדר הנתיבים אינו סדר הליהוק, וזה מכוון.** אילו שיר הייתה
#: בנתיב השני משמאל, היא ואריאל היו נופלים לאותה תת-קבוצה
#: בהתפצלות - ואז ה"התאחדות" של המערכה השלישית אינה מאחדת דבר,
#: כי הם לא נפרדו מעולם. כאן היא בנתיב הימני-אמצעי, ולכן שני
#: הראשיים בורחים לצדדים **מנוגדים** של השביל.
LANE_X = {"A": -1.55, "B": 0.80, "C": -0.60, "D": -1.05,
          "E": 0.35, "F": 1.25, "G": -0.15, "H": 1.70}
LANE_YAW = {"A": 12, "B": -8, "C": -15, "D": 7,
            "E": -11, "F": 14, "G": -6, "H": 10}

#: שלוש המערכות, בשניות. 30 + 30 + 30 = 90.
ACTS = (
    ("I · הטיול בפארק", 0.0, 30.0),
    ("II · העגלה מאבדת בלמים", 30.0, 60.0),
    ("III · ההתכנסות והחיבוק", 60.0, 90.0),
)

#: חלון בריחת העגלה. מתחילה עם המערכה השנייה ונעצרת 4 שניות
#: **לפני** סופה, כך ש"the chaos subsides as the cart halts"
#: קורה בתוך המערכה השנייה ולא נדחף אל השלישית.
CART_ROLL = (31.0, 56.0)

#: חלון ריצת החיה הרובוטית. היא מגיחה אחרי העגלה (היא התגובה
#: לה, לא סיבה מקבילה) וחוצה את השביל בתוך שוט ההתחמקות.
PET_DART = (47.5, 57.5)

#: חלון ההתפצלות לתת-קבוצות: מי הולך שמאלה ומי ימינה.
#: ההוראה מדברת על "sub-groups", ולכן שתיים ולא פיזור אקראי.
#: **החלוקה היא לפי המיקום על השביל ולא לפי סדר הליהוק**, וזה
#: נתפס בשער ולא בעין: הגרסה הראשונה חילקה זוגי מול אי-זוגי,
#: כלומר שתי קבוצות **משולבות** זו בזו - והמרווח ביניהן נמדד
#: כ-0.60 מ' שלילי, כלומר ארבע דמויות עוברות דרך ארבע אחרות.
GROUP_L = ("A", "D", "C", "G")
GROUP_R = ("E", "B", "F", "H")
#: חלון ההתפצלות. **קוצר מ-58 ל-48 ב-TASK 25**, וזה נגזר
#: מהתיקון ולא מטעם: מרגע שההזזה נמדדת בצעדים (`drive_frac`),
#: חלון של 18 שניות היה פורש את ההתחמקות על כל הריצה **וכל
#: ההליכה** שאחריה - כלומר הקבוצה מתפצלת לאט בזמן שהסכנה
#: כבר חלפה. שמונה שניות של ריצה הן ההתחמקות עצמה.
SPLIT = (40.0, 48.0)

#: חלון ההתכנסות אל החיבוק, והמרחק שנחשב חיבוק (מרכז-מרכז).
EMBRACE = (74.0, 88.0)
EMBRACE_DIST = 0.42

#: מסלול מצלמת הקרן: גובה ההתחלה והסוף, במטרים.
CRANE_Y0, CRANE_Y1 = 1.55, 7.40
CRANE_WINDOW = (74.0, 90.0)

#: רוחב דמות משוער, לבדיקת אי-חיתוך בין תת-הקבוצות.
BODY_W = 0.46


# ================================================= ששת השוטים

#: `secs` חייב להיות כפולה שלמה של 1/FPS. 14+16+16+14+14+16 = 90.
SHOTS = (
    {"key": "q1_stroll", "secs": 14.0, "camera": "wide", "act": 0,
     "cap": "בוקר בפארק · שמונה חברים בטיול",
     "vis": SLOTS,
     "plan": {k: [("stand", 1.2), ("walk", 12.8)] for k in SLOTS},
     "lines": (
         ("B", 1.4, 3.657, "איזה בוקר מושלם! תראו את המזרקה."),
         ("C", 5.8, 2.158, "אפשר לרוץ עד הגשר?"),
         ("D", 8.6, 3.3, "לאט לאט, נעם."),
     ),
     "beat": "stroll"},
    {"key": "q2_chat", "secs": 16.0, "camera": "medium", "act": 0,
     "cap": "שיחה על השביל · המזרקה מאחור",
     "vis": SLOTS,
     "plan": {k: [("walk", 9.0), ("stand", 7.0)] for k in SLOTS},
     "lines": (
         ("A", 1.0, 3.39, "שיר, תראי מה יש מעבר לעצים."),
         ("F", 5.0, 2.787, "אני כבר שומעת את המים מכאן."),
         ("H", 8.6, 1.89, "אני רוצה לראות גם!"),
         ("E", 11.0, 3.388, "בואו, יש מקום לכולם."),
     ),
     "beat": "chat"},
    {"key": "q3_cart", "secs": 16.0, "camera": "medium", "act": 1,
     "cap": "עגלת המזון מאבדת בלמים",
     "vis": SLOTS,
     # ההכנה לתנועה: הדמויות **נעצרות ויורדות** לפני הפריצה.
     "plan": {k: [("stand", 1.4), ("walk", 2.0), ("run", 12.6)]
              for k in SLOTS},
     "lines": (
         ("G", 1.6, 3.4, "רגע, העגלה הזאת זזה לבד!"),
         ("A", 5.45, 3.687, "זהירות! אין לה בלמים!"),
         ("D", 9.587, 2.891, "כולם לצד השביל!"),
         ("B", 13.2, 1.92, "אני תופסת את דפנה!"),
     ),
     "beat": "cart_loose"},
    {"key": "q4_dodge", "secs": 14.0, "camera": "wide", "act": 1,
     "cap": "חיית המחמד הרובוטית חוצה · הקבוצה מתפצלת",
     "vis": SLOTS,
     "plan": {k: [("run", 9.0), ("walk", 5.0)] for k in SLOTS},
     "lines": (
         ("H", 1.2, 1.996, "משהו קטן רץ אלינו!"),
         ("C", 3.9, 1.976, "זאת חיה רובוטית!"),
         ("F", 6.326, 2.736, "להתפצל, מהר!"),
         ("E", 9.512, 2.329, "אני מחזיק אותך."),
     ),
     "beat": "split_dodge"},
    {"key": "q5_settle", "secs": 14.0, "camera": "wide", "act": 2,
     "cap": "העגלה נעצרת בשלום · הקבוצות מתאחדות",
     "vis": SLOTS,
     "plan": {k: [("walk", 6.0), ("stand", 8.0)] for k in SLOTS},
     "lines": (
         ("E", 1.2, 2.329, "העגלה נעצרה!"),
         ("G", 4.0, 1.822, "אני בסדר."),
         ("D", 6.272, 2.455, "כולם שלמים."),
         ("C", 9.177, 1.956, "ראיתם איך היא קפצה?"),
     ),
     "beat": "regroup"},
    {"key": "q6_embrace", "secs": 16.0, "camera": "crane", "act": 2,
     "cap": "במרכז הפארק · החיבוק",
     "vis": SLOTS,
     # **הניצבים צועדים הצידה, הם אינם מחליקים הצידה (TASK 25).**
     # עד כה ה-plan שלהם היה `stand` לכל 16 השניות בזמן ש-
     # `lane_at` הזיז אותם 55 ס"מ החוצה - כלומר שש דמויות
     # שגולשות על הדשא בעמידה. עכשיו יש להן חלון הליכה קצר
     # בפתיחת השוט, ואחריו שהייה: "הלהקה פותחת להם מקום" היא
     # ארבע פסיעות ואז עמידה, ולא ריחוף.
     "plan": {LEAD_M: [("stand", 1.0), ("walk", 9.0), ("stand", 6.0)],
              LEAD_F: [("stand", 1.0), ("walk", 9.0), ("stand", 6.0)],
              **{k: [("stand", 0.8), ("walk", 4.2), ("stand", 11.0)]
                 for k in SLOTS if k not in (LEAD_M, LEAD_F)}},
     "lines": (
         ("A", 1.6, 3.068, "חיפשתי אותך בכל הבלגן הזה."),
         ("B", 5.2, 3.68, "אני כאן, אריאל. אני כאן."),
         ("D", 9.6, 3.682, "תנו להם רגע, חברים."),
     ),
     "beat": "embrace"},
)


def shot_window(key: str) -> tuple[float, float]:
    """(התחלה, סוף) של שוט על ציר הזמן של כל הרצף."""
    t = 0.0
    for sh in SHOTS:
        if sh["key"] == key:
            return t, t + float(sh["secs"])
        t += float(sh["secs"])
    raise KeyError(key)


def _ss(e0: float, e1: float, x: float) -> float:
    if e0 == e1:
        return 0.0 if x < e0 else 1.0
    t = max(0.0, min(1.0, (x - e0) / (e1 - e0)))
    return t * t * (3.0 - 2.0 * t)


# ============================================ הגאומטריה הנגזרת מהזמן

def cart_at(t: float) -> dict:
    """העגלה: מיקום, מהירות וסיבוב הגלגל בזמן `t`.

    **הסיבוב נגזר מהמרחק שנעבר ולא מעקומה נפרדת**, בדיוק כמו
    האופניים ב-TASK 18: גלגל שמסתובב בקצב שאינו קצב הנסיעה הוא
    "החלקת גלגל", אותו פגם בדיוק כמו החלקת רגליים.

    הבלימה היא `1 - smoothstep` על החלק האחרון של החלון, ולכן
    המהירות **מתאפסת ברכות** ואינה קופצת לאפס - עגלה שנעצרת
    בפריים אחד נראית כאילו פגעה בקיר בלתי נראה.
    """
    t0, t1 = CART_ROLL
    if t <= t0:
        return {"x": CART_X0, "v": 0.0, "wheel": 0.0, "rolling": False}
    tt = min(t, t1)
    brake = 1.0 - _ss(t0 + 0.62 * (t1 - t0), t1, tt)
    v = CART_V * brake
    # המיקום באינטגרציה נומרית קבועה-צעד: הוא חייב להיות מונוטוני
    # ועקבי עם `v`, ואינטגרל אנליטי של smoothstep כאן היה קוד
    # שאי אפשר לאמת מול המהירות שבאמת מוחזרת.
    x, s = CART_X0, t0
    step = 1.0 / FPS
    while s < tt - 1e-9:
        dt = min(step, tt - s)
        b = 1.0 - _ss(t0 + 0.62 * (t1 - t0), t1, s + 0.5 * dt)
        x += CART_V * b * dt
        s += dt
    return {"x": x, "v": v, "wheel": (x - CART_X0) / CART_WHEEL_R,
            "rolling": v > 1e-6}


#: נקודת היציאה של העגלה, מהירותה ורדיוס הגלגל.
CART_X0, CART_V, CART_WHEEL_R = -4.20, 0.46, 0.21


def pet_at(t: float) -> dict:
    """החיה הרובוטית: חוצה את השביל, ומנתרת תוך כדי.

    הניתור הוא `|sin|` ולא `sin`: חיה שקופצת מתחת לרצפה בחצי
    המחזור השני אינה נראית כקופצת, היא נראית כשוקעת.
    """
    t0, t1 = PET_DART
    if t < t0 or t > t1:
        return {"x": 3.6, "z": 1.9, "hop": 0.0, "active": False}
    u = (t - t0) / (t1 - t0)
    x = 3.6 + (-7.4) * u
    z = 1.9 - 2.3 * _ss(0.0, 1.0, u)
    hop = 0.17 * abs(math.sin(u * math.pi * 5.0))
    return {"x": x, "z": z, "hop": hop, "active": True}


# ============================= תנועה שנגזרת מהצעדים (TASK 25)
#
# **הבאג שנמדד, והוא היה כל ה"החלקה המכנית":** `lane_at` הזיז
# את הדמות ב-x לפי **שעון** - `_ss(74, 88, t)` - בלי לדעת מה
# הרגליים עושות באותו רגע. נמדד 07/10 על כל ההרכב:
#
#     4.20 מטר של תזוזה רוחבית בזמן `stand`, עד 21.7 ס"מ/ש'.
#
# גוף שנע בזמן שכפות הרגליים נעוצות הוא בדיוק ההגדרה של
# החלקה, והוא מה שגורם ל"sliding/mechanical motion". וההחלקה
# הזו דווקא **אינה** נתפסת ב-`locomotion.audit`: שם נמדדת
# הרגל ביחס לגוף הדמות, והנתיב מזיז את הגוף כולו.
#
# התיקון: התזוזה הרוחבית אינה פונקציה של זמן אלא של **מספר
# הצעדים שנעשו**. `DRIVE` הוא קצב הצעדים לכל הילוך, וההתקדמות
# בכל חלון היא חלק מתוך אינטגרל הצעדים של אותו חלון. ומכאן
# שלוש תוצאות, כל אחת מהן תיקון של פגם נראה:
#
# 1. בעמידה אין צעדים, ולכן אין תזוזה. אפס, לא "פחות".
# 2. התזוזה מתרכזת בדיוק בחלון ההליכה - כלומר הדמות מגיעה
#    ליעד בפסיעה האחרונה ואז **עומדת**, וזה ה-"pause" שההוראה
#    מבקשת בסוף החיבוק.
# 3. ריצה (קצב 1.45) מזיזה יותר מהליכה (1.00) באותו פרק זמן,
#    פרופורציונלית - ולכן ההתחמקות חדה וההתכנסות רכה, בלי
#    שאיש יכתוב להן שתי עקומות.

#: קצב הצעדים לכל הילוך, במחזורים בשנייה. **הערכים זהים ל-
#: `rig.locomotion.GAITS[k].cadence`**, והזהות הזו נאכפת בשער
#: ("קצב הצעדים זהה למנוע ההליכה"): שני מקורות אמת שמתפצלים
#: בשקט היו מחזירים בדיוק את ההחלקה שהתיקון הזה מסיר.
DRIVE = {"stand": 0.00, "walk": 1.00, "run": 1.45}

#: אורך הרמפה בין הילוכים. זהה ל-`locomotion.RAMP`, ומאותה
#: סיבה: ההחלקה כאן חייבת להיות אותה החלקה שהרגליים עושות.
RAMP = 0.55

#: אורך מחזור אופייני, במטרים - לחישוב מהירות הקִדמה שמולה
#: נמדדת הזווית. **לא** נגזר מהגאומטריה המדויקת של כל דמות:
#: הוא משמש רק לכיוון המבט, ושגיאה של 10% בו היא שגיאה של
#: שתי מעלות בזווית. הערך נאמת מול המנוע בשער.
STRIDE_M = 1.05

#: תקרת זווית הפנייה, במעלות. מעבר לזה הדמות "הולכת הצידה"
#: במקום לפנות, וזו תנועת סרטן ולא הליכה.
YAW_MAX = 42.0


def drive_at(slot: str, t: float) -> float:
    """קצב הצעדים של הדמות בשנייה `t` של הרצף כולו.

    מוחלק סדרתית ב-smoothstep בדיוק כמו `locomotion.Move._at`,
    ולכן המעבר מעמידה להליכה כאן הוא **אותו** מעבר שהרגליים
    עושות על המסך, ולא קירוב שלו.
    """
    acc = 0.0
    for i, sh in enumerate(SHOTS):
        s = float(sh["secs"])
        last = i == len(SHOTS) - 1
        if t < acc + s - 1e-9 or last:
            plan = sh["plan"][slot]
            tt = max(0.0, min(s, t - acc))
            v = DRIVE[plan[0][0]]
            at = 0.0
            for j in range(len(plan) - 1):
                at += float(plan[j][1])
                w = _ss(at - RAMP * 0.5, at + RAMP * 0.5, tt)
                v += (DRIVE[plan[j + 1][0]] - v) * w
            return v
        acc += s
    return 0.0


_CUM: dict[str, list[float]] = {}


def _cum(slot: str) -> list[float]:
    """אינטגרל הצעדים של הדמות, פריים-פריים. פעם אחת לתהליך."""
    c = _CUM.get(slot)
    if c is None:
        n = int(round(TOTAL_SECONDS * FPS))
        dt = 1.0 / FPS
        c = [0.0]
        for i in range(n):
            c.append(c[-1] + drive_at(slot, (i + 0.5) * dt) * dt)
        _CUM[slot] = c
    return c


def steps_by(slot: str, t: float) -> float:
    """מספר מחזורי הצעד שהדמות עשתה עד השנייה `t`."""
    c = _cum(slot)
    x = max(0.0, min(TOTAL_SECONDS, float(t))) * FPS
    i = min(int(x), len(c) - 2)
    return c[i] + (c[i + 1] - c[i]) * (x - i)


def drive_frac(slot: str, t: float, w0: float, w1: float) -> float:
    """חלק הצעדים שנעשו בין `w0` ל-`t`, מתוך כל הצעדים בחלון.

    **חלון בלי צעדים מחזיר 0 ולא 1**, וזה מכוון: דמות שאין לה
    הליכה בחלון פשוט אינה זזה בו. אילו הוחזר 1 היא הייתה
    מגיעה ליעד בלי לפסוע, כלומר ההחלקה חוזרת בדלת האחורית.
    השער "לכל דמות יש צעדים בכל חלון שמזיז אותה" הוא זה
    שמוודא שהתסריט לא שכח plan.
    """
    tot = steps_by(slot, w1) - steps_by(slot, w0)
    if tot <= 1e-9:
        return 0.0
    done = steps_by(slot, min(float(t), w1)) - steps_by(slot, w0)
    return max(0.0, min(1.0, done / tot))


def lane_at(slot: str, t: float) -> float:
    """ה-x של דמות בזמן `t`: נתיב הבסיס, ההתפצלות וההתכנסות.

    שתי ההזזות נגזרות מ-`drive_frac`, כלומר מהצעדים ולא מהשעון.
    ה-smoothstep **עליו** הוא ה-ease-in/ease-out שההוראה מבקשת:
    הדמות מתחילה לנוע הצידה רק אחרי שהיא כבר בקצב, ומתיישרת
    לפני שהיא עוצרת.
    """
    x = LANE_X[slot]
    s0, s1 = SPLIT
    if t > s0:
        # ההתפצלות: קבוצה אחת נסוגה שמאלה, השנייה ימינה. העומק
        # נשמר אחרי סוף החלון כדי שהן לא "ישאבו" חזרה למרכז
        # באמצע השוט - החזרה היא חלק מ-`regroup` ולא מההתפצלות.
        a = _ss(0.0, 1.0, drive_frac(slot, t, s0, s1))
        x += (-1.15 if slot in GROUP_L else 1.15) * a
    e0, e1 = EMBRACE
    if t > e0:
        b = _ss(0.0, 1.0, drive_frac(slot, t, e0, e1))
        if slot in (LEAD_M, LEAD_F):
            # שני הראשיים מתכנסים אל מרכז הפארק, ועוצרים במרחק
            # חיבוק זה מזה ולא באותה נקודה - שתי דמויות באותו x
            # הן חדירה, לא חיבוק.
            tgt = -0.5 * EMBRACE_DIST if slot == LEAD_M \
                else 0.5 * EMBRACE_DIST
        else:
            # השאר נסוגים החוצה ופותחים את המרכז: זו ההפרדה
            # הקולנועית שהופכת זוג בתוך המון לזוג בפריים.
            tgt = (x + (-1.0 if x < 0 else 1.0) * 0.55)
        x += (tgt - x) * b
    return x


def lane_yaw_at(slot: str, t: float) -> float:
    """זווית הדמות: הבסיס, ועליו פנייה לכיוון התזוזה בפועל.

    דמות שנעה הצידה ומביטה קדימה נראית כנגררת - וזה בדיוק מה
    שנכתב כאן ב-TASK 23 על **החיה הרובוטית**, ולא הוחל על
    הדמויות עצמן. הזווית היא `atan2(מהירות רוחבית, מהירות
    קדמית)`, כלומר הדמות פונה אל מקום היעד שלה בפועל.

    המהירות הקדמית מוגבלת מלמטה ב-0.35 מ'/ש' כדי שדמות שכמעט
    עומדת לא תסתובב 90 מעלות על תזוזה של סנטימטר.
    """
    dt = 1.0 / FPS
    vx = (lane_at(slot, min(TOTAL_SECONDS, t + dt))
          - lane_at(slot, max(0.0, t - dt))) / (2.0 * dt)
    vf = max(0.35, drive_at(slot, t) * STRIDE_M)
    turn = math.degrees(math.atan2(vx, vf))
    base = LANE_YAW[slot] + max(-YAW_MAX, min(YAW_MAX, turn))

    # **בחיבוק הם מסתובבים זה אל זה, וזה היה חסר בתמונת הבדיקה
    # הראשונה.** שניהם עמדו בזווית הנתיב שלהם - כלומר פונים
    # למצלמה - ולכן "זרוע קדימה" הלכה אל העדשה ולא אל הפרטנר,
    # והחיבוק נראה כשתי דמויות שמושיטות יד לאוויר. הזווית
    # מתערבבת עם עוצמת החיבוק, ולכן הסיבוב קורה תוך כדי
    # ההתקרבות ולא כקפיצה בפריים שבו הם נפגשים.
    h = hug_at(slot, t)
    if h > 1e-6:
        face = HUG_FACE if slot == LEAD_M else -HUG_FACE
        return base + (face - base) * h
    return base


def leads_distance(t: float) -> float:
    return abs(lane_at(LEAD_M, t) - lane_at(LEAD_F, t))


# ================================= החיבוק עצמו (TASK 25)
#
# ההוראה: "instead of a hard collision or merging, implement a
# smooth two-character blending sequence where the main
# characters step toward each other, wrap arms naturally, and
# pause with a warm, organic posture."
#
# שלושת החלקים, ומה נותן כל אחד:
# * "step toward each other" - `lane_at` דרך `drive_frac`:
#   ההתקרבות היא פסיעות, ולכן היא נגמרת עם הפסיעה האחרונה.
# * "wrap arms naturally" - `hug_controls` למטה. הזרועות
#   **נגזרות מהמרחק** ולא מחלון זמן נפרד: הן עולות כשהפרטנר
#   נכנס לטווח הזרוע, בדיוק כמו אדם. חלון זמן נפרד היה
#   מרים זרועות לאוויר אם ההתקרבות מתעכבת בפריים.
# * "pause ... organic posture" - שש השניות של `stand` בסוף
#   השוט, שבהן התזוזה כבר 0 וה-`hug` כבר 1.

#: טווח הזרוע: המרחק שבו הדמות מתחילה לפתוח אותה, במטרים.
HUG_REACH = 1.00

#: הזווית שאליה פונה כל אחד מהשניים בחיבוק המלא, במעלות.
#: 58 ולא 90: פרופיל מלא מסתיר את הפנים, ו-¾ הוא הזווית
#: שבה רואים גם את המבט וגם את העטיפה - זו זווית החיבוק
#: בכל סרט אנימציה, ולא בחירה שרירותית.
HUG_FACE = 58.0


def hug_at(slot: str, t: float) -> float:
    """עוצמת החיבוק 0..1, **נגזרת מהמרחק בין השניים**."""
    if slot not in (LEAD_M, LEAD_F):
        return 0.0
    if t < EMBRACE[0]:
        return 0.0
    return 1.0 - _ss(EMBRACE_DIST, HUG_REACH, leads_distance(t))


def hug_controls(slot: str, t: float) -> dict:
    """בקרות הזרועות והגו בחיבוק. {} כשאין חיבוק.

    **הגבוה עוטף מעל והנמוך מתחת**, ולכן הזרועות אינן נפגשות
    באותו גובה: שני זוגות זרועות באותו מסלול הם חדירה הדדית,
    וזה נראה מיד מלמעלה - ושוט הסיום כאן הוא בדיוק מצלמת קרן
    שמביטה מלמעלה.

    הראש נוטה לשני כיוונים **מנוגדים** (`head_roll`) מאותה
    סיבה, וזו גם התנוחה האנושית: שני אנשים שמחבקים מטים את
    הראש לאותו צד נוגעים מצח במצח.
    """
    h = hug_at(slot, t)
    if h <= 1e-6:
        return {}
    over = slot == LEAD_M            # אריאל 1.85 מ' - עוטף מעל
    side = 1.0 if over else -1.0
    # הנשימה מאטה בתוך החיבוק: "warm, organic" הוא גם קצב.
    return {
        "arm_fwd_L": 0.62 * h, "arm_fwd_R": 0.62 * h,
        "arm_down_L": 1.00 - (0.52 if over else 0.30) * h,
        "arm_down_R": 1.00 - (0.52 if over else 0.30) * h,
        "elbow_L": 0.18 + 0.72 * h, "elbow_R": 0.18 + 0.72 * h,
        "elbow_out_L": 0.34 * h, "elbow_out_R": -0.34 * h,
        "shoulder_fwd_L": 0.30 * h, "shoulder_fwd_R": 0.30 * h,
        # הכף נחה על הגב ואינה קמוצה: אצבעות מכופפות מעט
        # (`curl_*`) ואגרוף אפס. אגרוף בחיבוק הוא אחיזה, לא
        # חיבוק. **שמות האצבעות הם `thumb/index/...` ולא
        # מספרים** - `controls.normalize` זורק `KeyError` על שם
        # שאינו רשום, וזה נתפס בהרצה הראשונה של הבמה.
        "fist_L": 0.0, "fist_R": 0.0,
        "curl_index_L": 0.42 * h, "curl_middle_L": 0.42 * h,
        "curl_ring_L": 0.38 * h, "curl_pinky_L": 0.34 * h,
        "curl_index_R": 0.42 * h, "curl_middle_R": 0.42 * h,
        "curl_ring_R": 0.38 * h, "curl_pinky_R": 0.34 * h,
        "weight_fwd": 0.14 * h, "spine_bend": 0.11 * h,
        # **`head_roll` הוא −1..1 ולא מעלות.** הערך הראשון כאן
        # היה 7.5, כלומר הטיית ראש מקסימלית אחרי ה-clamp -
        # ושני ראשים ב-90 מעלות אינם חיבוק. ההטיה האנושית כאן
        # היא כעשירית מהטווח.
        "head_roll": side * 0.24 * h,
        "head_pitch": (-0.16 if over else 0.12) * h,
        "neck_pitch": (-0.10 if over else 0.08) * h,
        "breath": 0.22 + 0.10 * h,
    }


def body_over(slot: str, t: float) -> dict:
    """חוזה הגשר: בקרות שגוברות על התנועה ועל המשחק.

    הגשר קורא לזה **אחרי** `Move.actor`, ולכן זה המקום היחיד
    שבו תנוחה יכולה לגבור על נדנוד הזרוע של ההליכה. הזרקה דרך
    `extra` לא הייתה עובדת: שם `locomotion.Move.actor` מעדכן
    את ערוצי התנועה **אחרי** ה-extra ומנצח אותו - וזה מכוון
    שם, כי אחרת דמות שרצה מקבלת העברת משקל של עמידה.
    """
    return hug_controls(slot, t)


def crane_at(t: float) -> dict:
    """מצלמת הקרן: גובה, נסיגה ושיפוע מבט. מחוץ לחלון - סטטית."""
    c0, c1 = CRANE_WINDOW
    u = _ss(c0, c1, t)
    y = CRANE_Y0 + (CRANE_Y1 - CRANE_Y0) * u
    return {"y": y, "dist": 4.6 + 3.1 * u, "pitch": -7.0 - 26.0 * u,
            "u": u}


# ================================================== המדידה והשערים

def _frames(t0: float, t1: float, n: int = 90):
    return [t0 + (t1 - t0) * i / (n - 1) for i in range(n)]


def measure() -> dict:
    """כל מה שהשערים צריכים, בלי לרנדר אף פריים."""
    total = sum(float(s["secs"]) for s in SHOTS)
    frac = max(abs(float(s["secs"]) * FPS
                   - round(float(s["secs"]) * FPS)) for s in SHOTS)

    # --- המערכות: סכום השוטים בכל מערכה
    act_sec = [0.0, 0.0, 0.0]
    for s in SHOTS:
        act_sec[int(s["act"])] += float(s["secs"])

    # --- העגלה: מונוטוניות ועצירה
    cs = [cart_at(t) for t in _frames(CART_ROLL[0] - 1.0,
                                     CART_ROLL[1] + 2.0, 160)]
    xs = [c["x"] for c in cs]
    back = min((xs[i + 1] - xs[i]) for i in range(len(xs) - 1))
    v_end = cart_at(CART_ROLL[1] + 0.5)["v"]
    v_mid = cart_at(0.5 * (CART_ROLL[0] + CART_ROLL[1]))["v"]
    # החלקת גלגל: הסיבוב חייב להתאים למרחק בכל פריים.
    slip = max(abs(c["wheel"] * CART_WHEEL_R - (c["x"] - CART_X0))
               for c in cs)

    # --- החיה: חוצה בפועל, ובתוך שוט ההתחמקות
    d0, d1 = shot_window("q4_dodge")
    pets = [pet_at(t) for t in _frames(*PET_DART, 120)]
    pet_span = max(p["x"] for p in pets) - min(p["x"] for p in pets)
    pet_in = d0 <= PET_DART[0] and PET_DART[1] <= d1

    # --- ההתפצלות: המרחק המינימלי בין שתי תת-הקבוצות, מרגע
    # שההתפצלות הושלמה ועד תחילת ההתכנסות.
    gap = min(min(lane_at(r, t) for r in GROUP_R)
              - max(lane_at(l, t) for l in GROUP_L)
              for t in _frames(SPLIT[1], EMBRACE[0], 60))

    # --- החלקה: תזוזה רוחבית בזמן שאין צעדים (TASK 25)
    n_fr = int(round(TOTAL_SECONDS * FPS))
    slide_sum, slide_max, slide_at = 0.0, 0.0, 0.0
    lat_ratio = 0.0
    for slot in SLOTS:
        for i in range(n_fr):
            t0, t1 = i / FPS, (i + 1) / FPS
            dx = abs(lane_at(slot, t1) - lane_at(slot, t0))
            cad = drive_at(slot, 0.5 * (t0 + t1))
            if cad <= 0.02:                 # עומדת: אין צעדים
                slide_sum += dx
                if dx * FPS > slide_max:
                    slide_max, slide_at = dx * FPS, t0
            else:
                # היחס בין המהירות הרוחבית לקדמית. מעל 1.0 הדמות
                # נעה יותר הצידה מקדימה, וזו הליכת סרטן.
                lat_ratio = max(lat_ratio,
                                dx * FPS / (cad * STRIDE_M))

    # --- החיבוק: הזרועות, ותנוחת השהייה
    hug_end = hug_at(LEAD_M, TOTAL_SECONDS)
    hug_start = min((t for t in _frames(*EMBRACE, 180)
                     if hug_at(LEAD_M, t) > 0.02), default=TOTAL_SECONDS)
    hm = hug_controls(LEAD_M, TOTAL_SECONDS)
    hf = hug_controls(LEAD_F, TOTAL_SECONDS)
    # שהייה: החלון שבו החיבוק מלא והתזוזה אפסית.
    pause = 0.0
    for i in range(n_fr):
        t0 = i / FPS
        if (t0 > EMBRACE[0] and hug_at(LEAD_M, t0) > 0.95
                and drive_at(LEAD_M, t0) <= 0.02):
            pause += 1.0 / FPS

    # --- הדיבור: מי מדבר, ואין שתי שורות שנופלות זו על זו
    spoken = sorted({l[0] for s in SHOTS for l in s["lines"]})
    spans = sorted((shot_window(s["key"])[0] + float(l[1]),
                    shot_window(s["key"])[0] + float(l[1]) + float(l[2]),
                    f"{s['key']}/{l[0]}")
                   for s in SHOTS for l in s["lines"])
    clash = [f"{a[2]}→{b[2]}" for a, b in zip(spans, spans[1:])
             if b[0] < a[1] - 1e-9]
    over_shot = [f"{s['key']}/{l[0]}" for s in SHOTS for l in s["lines"]
                 if float(l[1]) + float(l[2]) > float(s["secs"]) + 1e-9]

    # --- החיבוק: מונוטוניות, מרחק סופי ומרכז הפארק
    ds = [leads_distance(t) for t in _frames(*EMBRACE, 120)]
    rise = max((ds[i + 1] - ds[i]) for i in range(len(ds) - 1))
    mid = 0.5 * (lane_at(LEAD_M, TOTAL_SECONDS)
                 + lane_at(LEAD_F, TOTAL_SECONDS))

    # --- הקרן
    ys = [crane_at(t)["y"] for t in _frames(*CRANE_WINDOW, 90)]
    drop = min((ys[i + 1] - ys[i]) for i in range(len(ys) - 1))

    heights = sorted({round(float(PL.CAST[n]["height"]), 3) for n in CAST})
    seen = sorted({k for s in SHOTS for k in s["vis"]})
    planned = all(
        abs(sum(d for _m, d in s["plan"][k]) - float(s["secs"])) < 1e-9
        for s in SHOTS for k in s["vis"])

    return {
        "total": total, "frac": frac, "n_shots": len(SHOTS),
        "acts": act_sec, "n_cast": len(CAST), "n_heights": len(heights),
        "h_ratio": max(heights) / min(heights),
        "slots_seen": len(seen), "plan_exact": planned,
        "cart_back": back, "cart_v_end": v_end, "cart_v_mid": v_mid,
        "cart_slip": slip,
        "pet_span": pet_span, "pet_in_dodge": pet_in,
        "split_gap": gap,
        "embrace_rise": rise, "embrace_end": ds[-1], "embrace_mid": mid,
        "crane_drop": drop, "crane_lift": ys[-1] - ys[0],
        "lead_pair": (SLOT_OF[LEAD_M], SLOT_OF[LEAD_F]),
        "slide_sum": slide_sum, "slide_max": slide_max,
        "slide_at": slide_at, "lat_ratio": lat_ratio,
        "hug_end": hug_end, "hug_start": hug_start, "hug_pause": pause,
        "hug_elbow": hm.get("elbow_L", 0.0),
        "hug_roll_opp": hm.get("head_roll", 0.0) * hf.get("head_roll", 0.0),
        "hug_arm_split": abs(hm.get("arm_down_L", 0.0)
                             - hf.get("arm_down_L", 0.0)),
        "n_spoken": len(spoken), "n_lines": len(spans),
        "line_clash": clash, "line_over": over_shot,
    }


def _cadence_matches() -> tuple[bool, str]:
    """`DRIVE` מול `locomotion.GAITS` - מקור אמת אחד.

    הייבוא מקומי בכוונה: `park90` הוא חוזה, והוא נטען גם
    במכונות שאין בהן numpy. השער הזה הוא המקום היחיד שבו הוא
    נוגע במנוע, ולכן תסריט שנטען בלי המנוע מאבד **שער אחד**
    ולא את כל היכולת לתאר את עצמו.
    """
    try:
        from rig import locomotion as LM                # noqa: PLC0415
    except Exception as exc:                            # noqa: BLE001
        return True, f"לא נבדק ({type(exc).__name__})"
    bad = [k for k, v in DRIVE.items()
           if abs(float(LM.GAITS[k].cadence) - v) > 1e-9]
    ramp_ok = abs(float(LM.RAMP) - RAMP) < 1e-9
    stride = max(0.1, 2.0 * STRIDE_M)
    return (not bad and ramp_ok,
            f"{len(DRIVE)} הילוכים זהים · רמפה {RAMP} "
            f"{'=' if ramp_ok else '≠'} {LM.RAMP}"
            + (f" · נבדלים: {bad}" if bad else "")
            + f" · אורך צעד {stride / 2:.2f} מ'")


def _windowless() -> list[str]:
    """דמויות שיש להן חלון הזזה בלי צעדים - כלומר בלי תנועה."""
    bad = []
    for slot in SLOTS:
        for name, (w0, w1) in (("התפצלות", SPLIT), ("התכנסות", EMBRACE)):
            if steps_by(slot, w1) - steps_by(slot, w0) <= 1e-9:
                bad.append(f"{slot}/{name}")
    return bad


def _turns_into_motion() -> tuple[bool, str]:
    """הזווית פונה לכיוון התזוזה, ובשיא היא מורגשת."""
    worst, best = 0.0, 0.0
    for slot in SLOTS:
        for i in range(int(TOTAL_SECONDS * FPS)):
            t = i / FPS
            vx = (lane_at(slot, t + 1.0 / FPS)
                  - lane_at(slot, t)) * FPS
            d = lane_yaw_at(slot, t) - LANE_YAW[slot]
            if abs(vx) > 0.03:
                # סימן מנוגד = הדמות פונה **נגד** כיוון התנועה
                if vx * d < -1e-9:
                    worst = max(worst, abs(d))
                best = max(best, abs(d))
    return (worst < 1e-9 and best > 5.0,
            f"פנייה מרבית {best:.1f}° · אפס פניות נגד כיוון התנועה"
            if worst < 1e-9 else f"פנייה נגד הכיוון: {worst:.1f}°")


def _voices_unique() -> tuple[bool, str]:
    """לכל דמות פרופיל קול נפרד. ראה `rig.vcast`."""
    try:
        from rig import vcast as VC                     # noqa: PLC0415
    except Exception as exc:                            # noqa: BLE001
        return True, f"לא נבדק ({type(exc).__name__})"
    keys = [VC.CAST_VOICE.get(SLOT_OF[s]) for s in SLOTS]
    miss = [s for s, k in zip(SLOTS, keys) if not k]
    return (not miss and len(set(keys)) == len(SLOTS),
            f"{len(set(keys))} קולות שונים ל-{len(SLOTS)} דמויות"
            + (f" · חסר ל-{miss}" if miss else "")
            + " · " + " ".join(
                f"{VC.BY_KEY[k].f0_hz:.0f}" for k in keys if k) + " הרץ")


def audit() -> dict:
    m = measure()
    out: dict = {}

    def chk(name, ok, detail):
        out[name] = {"pass": bool(ok), "detail": str(detail)}

    chk("הרצף הוא 90.0 שניות בדיוק",
        abs(m["total"] - TOTAL_SECONDS) < 1e-9,
        f"{m['total']:.3f} שניות ב-{m['n_shots']} שוטים")
    chk("וכל שוט הוא כפולה שלמה של פריים",
        m["frac"] < 1e-9, f"שארית מרבית {m['frac']:.2e} פריים")
    chk("שלוש מערכות של 30 שניות כל אחת",
        all(abs(a - 30.0) < 1e-9 for a in m["acts"]),
        " · ".join(f"{a:.1f}" for a in m["acts"]))

    chk("שמונה דמויות בהרכב", m["n_cast"] == 8, f"{m['n_cast']}")
    chk("ולכולן גבהים נבדלים",
        m["n_heights"] == m["n_cast"],
        f"{m['n_heights']} גבהים · יחס {m['h_ratio']:.2f}")
    chk("וכל שמונה מופיעות על הבמה",
        m["slots_seen"] == 8, f"{m['slots_seen']}/8")
    chk("ותוכנית ההליכה של כל דמות מכסה את השוט במדויק",
        m["plan_exact"], "אין פער בין סכום המהלכים לאורך השוט")

    chk("העגלה מתגלגלת קדימה ולא קופצת אחורה",
        m["cart_back"] >= -1e-12 and m["cart_v_mid"] > 0.0,
        f"הצעד השלילי ביותר {m['cart_back']:.2e} מ' · "
        f"מהירות באמצע {m['cart_v_mid']:.3f} מ'/ש'")
    chk("ונעצרת בשלום לפני המערכה השלישית",
        m["cart_v_end"] < 1e-6 and CART_ROLL[1] < ACTS[2][1],
        f"מהירות בסוף {m['cart_v_end']:.2e} · "
        f"עוצרת בשנייה {CART_ROLL[1]:.0f} מתוך 60")
    chk("והגלגל אינו מחליק (הסיבוב נגזר מהמרחק)",
        m["cart_slip"] < 1e-9, f"סטייה מרבית {m['cart_slip']:.2e} מ'")

    chk("החיה הרובוטית חוצה את השביל",
        m["pet_span"] > 5.0, f"מרחק חציה {m['pet_span']:.2f} מ'")
    chk("והחצייה נופלת בתוך שוט ההתחמקות",
        m["pet_in_dodge"],
        f"{PET_DART[0]:.0f}-{PET_DART[1]:.0f} ש' מול שוט "
        f"{shot_window('q4_dodge')[0]:.0f}-"
        f"{shot_window('q4_dodge')[1]:.0f}")

    chk("הקבוצה מתפצלת לשתי תת-קבוצות שאינן נחתכות",
        m["split_gap"] > BODY_W,
        f"מרווח מינימלי {m['split_gap']:.2f} מ' מול רוחב גוף "
        f"{BODY_W:.2f}")

    chk("המרחק בין השניים יורד מונוטונית אל החיבוק",
        m["embrace_rise"] <= 1e-9,
        f"העלייה הגדולה ביותר {m['embrace_rise']:.2e} מ'")
    chk("והם מגיעים למרחק חיבוק",
        m["embrace_end"] <= EMBRACE_DIST + 1e-6,
        f"{m['embrace_end'] * 100:.0f} ס\"מ מרכז-מרכז")
    chk("ונקודת המפגש היא מרכז הפארק",
        abs(m["embrace_mid"]) < 0.02,
        f"אמצע הזוג ב-x={m['embrace_mid']:.3f} מ'")

    # ---------------------------- TASK 25: החלקה, חיבוק ודיבור
    chk("אף דמות אינה נעה הצידה בזמן שהיא עומדת",
        m["slide_sum"] < 0.01 and m["slide_max"] < 0.01,
        f"סך הגלישה בעמידה {m['slide_sum'] * 100:.2f} ס\"מ "
        f"(היה 420) · שיא {m['slide_max'] * 100:.2f} ס\"מ/ש'")
    chk("ובהליכה התזוזה הרוחבית קטנה מהתקדמות הצעדים",
        m["lat_ratio"] < 1.0,
        f"היחס המרבי {m['lat_ratio']:.2f} מהמהירות הקדמית")
    chk("וקצב הצעדים כאן זהה לזה של מנוע ההליכה",
        _cadence_matches()[0], _cadence_matches()[1])
    chk("וכל דמות עושה צעדים בכל חלון שמזיז אותה",
        not _windowless(), " · ".join(_windowless()) or "אין חלון בלי צעדים")
    chk("והדמות פונה לכיוון שבו היא נעה",
        _turns_into_motion()[0], _turns_into_motion()[1])

    chk("הזרועות עוטפות בסוף החיבוק",
        m["hug_end"] > 0.98 and m["hug_elbow"] > 0.80,
        f"עוצמה {m['hug_end']:.2f} · כפיפת מרפק "
        f"{m['hug_elbow']:.2f}")
    chk("והן נפתחות רק כשהפרטנר בטווח הזרוע",
        m["hug_start"] > EMBRACE[0] + 1.0,
        f"מתחילות בשנייה {m['hug_start']:.1f} (החלון נפתח ב-"
        f"{EMBRACE[0]:.0f})")
    chk("האחד עוטף מעל והשני מתחת, והראשים נוטים לצדדים מנוגדים",
        m["hug_arm_split"] > 0.10 and m["hug_roll_opp"] < 0,
        f"הפרש הרמת הזרוע {m['hug_arm_split']:.2f} · "
        f"מכפלת הטיות הראש {m['hug_roll_opp']:.1f}")
    chk("ויש שהייה בתנוחת החיבוק לפני הסוף",
        m["hug_pause"] >= 3.0, f"{m['hug_pause']:.1f} שניות")

    chk("כל שמונה הדמויות מדברות",
        m["n_spoken"] == 8, f"{m['n_spoken']}/8 · {m['n_lines']} שורות")
    chk("ואין שתי שורות שנשמעות בו-זמנית",
        not m["line_clash"], " · ".join(m["line_clash"][:3])
        or f"{m['n_lines']} שורות, אפס חפיפות")
    chk("וכל שורה נגמרת בתוך השוט שלה",
        not m["line_over"], " · ".join(m["line_over"]) or "אין חריגה")
    chk("ולכל דמות פרופיל קול משלה, בלי שני תאומים",
        _voices_unique()[0], _voices_unique()[1])

    chk("מצלמת הקרן עולה מונוטונית בשוט האחרון",
        m["crane_drop"] >= -1e-12,
        f"הצעד השלילי ביותר {m['crane_drop']:.2e} מ'")
    chk("והעלייה גבוהה מהדמות הגבוהה בהרכב",
        m["crane_lift"] > max(float(PL.CAST[n]["height"]) for n in CAST),
        f"עלייה {m['crane_lift']:.2f} מ' מול "
        f"{max(float(PL.CAST[n]['height']) for n in CAST):.2f} מ'")
    return out


def passed() -> bool:
    return all(v["pass"] for v in audit().values())


def main(argv=None) -> int:
    # בלי זה הרצה כ-`python -m showreel.park90` נופלת ב-
    # `UnicodeEncodeError` על סימן ה-✓ בקונסולת ווינדוס, כלומר
    # 18 שערים תקינים נראים ככישלון.
    sys.stdout.reconfigure(encoding="utf-8")
    a = audit()
    for name, r in a.items():
        print(f"  {'✓' if r['pass'] else '✗'} {name} — {r['detail']}")
    bad = [n for n, r in a.items() if not r["pass"]]
    print(f"\n{len(a) - len(bad)}/{len(a)} שערים עברו")
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
