# -*- coding: utf-8 -*-
"""שערי הגשר הדינמי (TASK 24). בלי דפדפן, בלי רינדור, בלי GLB.

שני דברים נמדדים כאן, והם לא אותו דבר:

1. **אפס נסיגה.** הגשר הידני של `park90` (TASK 23) הוחלף
   בהאצלה לגשר הגנרי. הערכים שהוא החזיר **לפני** ההחלפה הוקפאו
   ב-`fixtures/park90_golden.json` (ראה `out/dump_golden.py`),
   והשערים כאן משווים אליהם: תזמון השוטים, כל פרמטר מצלמה, הנתיב
   המוחלט של כל דמות, **חתימת הפוזה של כל שחקן**, העגלה, החיה
   וה-sha256 של הבמה. בלי הקפאה מוקדמת אין מול מה להשוות -
   אחרי הרפקטור שתי הגרסאות הן אותו קוד, והשוואה כזו עוברת
   תמיד ומוכיחה אפס.

2. **גנריות.** שלושה תסריטים שונים נטענים ומנורמלים דרך אותו
   קוד: 8 דמויות/90 שניות, 4 דמויות/60 שניות, ו-10 דמויות/120
   שניות שהוא **נתונים בלבד**. ועוד אחד שנוצר בזמן הבדיקה
   בתיקייה זמנית, עם 12 דמויות - כי "עובד על הקבצים שבמאגר"
   אינו "עובד על תסריט חדש".
"""
from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
STUDIO = HERE.parent
if str(STUDIO) not in sys.path:
    sys.path.insert(0, str(STUDIO))

from showreel import bridge as BR                         # noqa: E402
from showreel import park90 as P90                        # noqa: E402
from showreel import park90_render as R                   # noqa: E402

GOLDEN = HERE / "fixtures" / "park90_golden.json"

#: אותם גבהים מייצגים שבתמונת הזהב - דטרמיניסטיים, בלי GLB.
HEIGHTS = {k: 1.52 + 0.047 * i for i, k in enumerate(R.SLOTS)}

#: תסריט שנכתב בזמן הבדיקה: 12 דמויות, 2 שוטים, **אפס קוד**.
#: שמות הדמויות מההרכב שנבנה בפועל, כי שם שאינו בהרכב נדחה.
TMP_SCRIPT = '''# -*- coding: utf-8 -*-
"""תסריט שנוצר בבדיקה. נתונים בלבד."""
CAST12 = ("dn_ariel", "dn_shir", "dn_noam", "dn_gidon", "dn_tamir",
          "dn_libi", "dn_omer", "dn_dafna", "boaz", "tamar",
          "lucas", "maya")
SHOTS = (
    {"key": "t1", "secs": 9.0, "camera": "wide", "cap": "פתיחה",
     "beat": "stroll"},
    {"key": "t2", "secs": 11.0, "camera": "crane", "cap": "סיום",
     "beat": "embrace"},
)
'''


def _close(a, b, eps=1e-6) -> bool:
    if isinstance(a, dict) and isinstance(b, dict):
        return (set(a) == set(b)
                and all(_close(a[k], b[k], eps) for k in a))
    if isinstance(a, (list, tuple)) and isinstance(b, (list, tuple)):
        return len(a) == len(b) and all(_close(x, y, eps)
                                        for x, y in zip(a, b))
    if isinstance(a, (int, float)) and isinstance(b, (int, float)):
        return abs(float(a) - float(b)) <= eps
    return a == b


def _worst(a, b) -> float:
    """הסטייה המספרית הגדולה ביותר בין שני מבנים זהי-צורה."""
    if isinstance(a, dict) and isinstance(b, dict):
        return max([_worst(a[k], b[k]) for k in a if k in b] or [0.0])
    if isinstance(a, (list, tuple)) and isinstance(b, (list, tuple)):
        return max([_worst(x, y) for x, y in zip(a, b)] or [0.0])
    if isinstance(a, (int, float)) and isinstance(b, (int, float)):
        return abs(float(a) - float(b))
    return 0.0 if a == b else 1e9


def _mktmp() -> tuple[str, Path]:
    d = Path(tempfile.mkdtemp(prefix="bridge_script_"))
    p = d / "tmp_cast12.py"
    p.write_text(TMP_SCRIPT, encoding="utf-8")
    return str(p), d


def audit() -> dict:
    g: dict = {}

    def gate(key, ok, detail):
        g[key] = {"pass": bool(ok), "detail": str(detail)}

    # ============================================= 1 · אפס נסיגה
    gld = json.loads(GOLDEN.read_text(encoding="utf-8"))
    sc = BR.load("park90")
    # **`smooth=0.0` מקובע כאן בכוונה.** חלון ההחלקה הוא כוונון
    # גלובלי שיורד לדיסק (`studio/tuning.json`), ומנוע התיקון
    # האוטונומי (`showreel/deliver.py`) מזיז אותו בכל ריצה. בלי
    # הקיבוע הזה השער הזה היה נופל אחרי כל סבב תיקון ומדווח
    # "נסיגה מול הגשר הידני" על שינוי מכוון ומתועד - כלומר
    # אזהרת שווא שהורגת את הערך של השער. השער מודד את **הגשר**.
    shots = BR.build_shots(sc, HEIGHTS, sc.fps, smooth=0.0)

    got = [{"key": s.key, "secs": round(s.secs, 6),
            "t_abs": round(s.t_abs, 6), "cap": s.cap,
            "camera": s.camera, "vis": list(s.vis),
            "n_actors": len(s.actors), "n_moves": len(s.moves)}
           for s in shots]
    gate("תזמון השוטים זהה לגשר הידני שלפני ההכללה",
         _close(got, gld["shots"]),
         f"{len(got)} שוטים · {sum(s['secs'] for s in got):.3f} שניות")

    cam_bad, cam_worst = [], 0.0
    for s in shots:
        for i, u in enumerate((0.0, 0.5, 1.0)):
            t = s.t_abs + u * (s.secs - 1.0 / sc.fps)
            c = BR.camera(sc, s.camera, u, HEIGHTS, t)
            ref = gld["cam"][s.key][i]
            cam_worst = max(cam_worst, _worst(c, ref))
            if not _close(c, ref):
                cam_bad.append((s.key, u))
    gate("וכל פרמטר מצלמה זהה (כולל מצלמת הקרן)",
         not cam_bad, f"{len(shots) * 3} דגימות · סטייה מרבית "
                      f"{cam_worst:.2e}")

    lx_bad, act_bad, n = [], [], 0
    for s in shots:
        for k in sc.slots:
            for i, u in enumerate((0.0, 0.5, 1.0)):
                t = max(0.0, u * (s.secs - 1.0 / sc.fps))
                mv = BR.mv_frame(sc, s, k, t, s.t_abs + t)
                ref = gld["lx"][s.key][k][i]
                n += 1
                if not _close({kk: mv[kk] for kk in ref}, ref, 5e-5):
                    lx_bad.append((s.key, k, u))
    gate("והנתיב המוחלט וההיסטים זהים לכל דמות ובכל שוט",
         not lx_bad, f"{n} דגימות · {len(lx_bad)} סטיות")

    # חתימת הפוזה של השחקן: זה השער שמוכיח שהמשחק לא זז.
    # הגשר בונה את `Situation` בעצמו, ולכן טעות בגילוי `_sit`
    # הייתה מחליפה את כל משחק הפנים בלי לשנות אף מספר אחר.
    import hashlib
    for s in shots:
        for k in sc.slots:
            for i, u in enumerate((0.0, 0.5, 1.0)):
                t = max(0.0, u * (s.secs - 1.0 / sc.fps))
                r = s.actors[k](u, t)

                def rr(x, nd=4):
                    if isinstance(x, float):
                        return round(x, nd)
                    if isinstance(x, dict):
                        return {kk: rr(v, nd) for kk, v in x.items()}
                    if isinstance(x, (list, tuple)):
                        return [rr(v, nd) for v in x]
                    return x
                blob = json.dumps(rr([r[0], r[1],
                                      r[2] if len(r) > 2 else {}]),
                                  sort_keys=True, ensure_ascii=False)
                h = hashlib.sha256(blob.encode("utf-8")).hexdigest()[:16]
                if h != gld["actor"][s.key][k][i]:
                    act_bad.append((s.key, k, u))
    gate("ומשחק הפנים והגוף של כל שחקן זהה בחתימה",
         not act_bad,
         f"{len(shots) * len(sc.slots) * 3} חתימות · "
         f"{len(act_bad)} שונות")

    cart = [R.cart_frame(i * 0.5) for i in range(181)]
    pet = [R.pet_frame(i * 0.5) for i in range(181)]
    gate("העגלה והחיה מחזירות בדיוק את אותם ערכים",
         _close(cart, gld["cart"]) and _close(pet, gld["pet"]),
         f"{len(cart)} דגימות עגלה · {len(pet)} חיה")

    html = BR.stage_html(sc)
    import hashlib as _h
    sha = _h.sha256(html.encode("utf-8")).hexdigest()
    gate("והבמה שנבנית זהה לבמה הקודמת בייט אחר בייט",
         sha == gld["stage"]["sha256"] and len(html) == gld["stage"]["len"],
         f"{len(html)} תווים · sha {sha[:12]}")

    # ======================================== 2 · גנריות התסריטים
    gate("הגשר מזהה לבד את תסריט שמונה הדמויות",
         len(sc.cast) == 8 and abs(sc.total - 90.0) < 1e-9
         and sc.slots == P90.SLOTS,
         f"{len(sc.cast)} דמויות · {sc.total:g} שניות · "
         f"{len(sc.shots)} שוטים")
    gate("ומתעד מאיפה הגיע כל שדה",
         "התסריט.CAST" in sc.source.get("cast", "")
         and "SEEDS" in sc.source.get("seeds", "")
         and sc.source.get("situation", "") == "נגזר"
         or callable(sc._sit),
         f"cast ← {sc.source.get('cast')} · "
         f"seeds ← {sc.source.get('seeds')} · "
         f"סביבה ← {sc.source.get('env_dir')}")
    gate("ומוצא את העיטורים התלת-ממדיים בגשר הצמוד",
         bool(sc.stage_js) and sc.extra_key == "p90"
         and isinstance(sc.frame_extra(45.0), dict),
         f"מפתח {sc.extra_key!r} · "
         f"{len(sc.stage_js or '')} תווי JS")

    ds = BR.load("disney_story")
    gate("אותו גשר טוען גם את תסריט ארבע הדמויות של 60 השניות",
         len(ds.cast) == 4 and abs(ds.total - 60.0) < 1e-9
         and len(ds.shots) == 4,
         f"{len(ds.cast)} דמויות · {ds.total:g} שניות · "
         f"{len(ds.shots)} שוטים")
    gate("ושומר את חמש שורות הדיבור שלו",
         sum(len(s["lines"]) for s in ds.shots) == 5,
         f"{sum(len(s['lines']) for s in ds.shots)} שורות דיבור")
    gate("ולתסריט בלי אובייקטים משלו הבמה נבנית בלי שכבה מיותרת",
         "xtrFrame" not in BR.stage_html(ds)
         and "const bx = " in BR.stage_html(ds),
         "נתיב משתנה כן · שכבת אובייקטים לא")

    # --- עשר דמויות ו-120 שניות, מתסריט שהוא נתונים בלבד
    md = BR.load("meadow120")
    gate("תסריט חדש של עשר דמויות ו-120 שניות נטען בלי שורת קוד",
         len(md.cast) == 10 and abs(md.total - 120.0) < 1e-9
         and len(md.shots) == 7,
         f"{len(md.cast)} דמויות · {md.total:g} שניות · "
         f"{len(md.shots)} שוטים")
    gate("והמקומות, הנתיבים, הזרעים והפאזות נגזרו לבד",
         md.slots == tuple("ABCDEFGHIJ")
         and "נגזר" in md.source["lane_x"]
         and "נגזר" in md.source["seeds"]
         and "נגזר" in md.source["slots"],
         f"{md.slots[0]}..{md.slots[-1]} · נתיבים "
         f"{min(md.lane_x.values()):.2f}..{max(md.lane_x.values()):.2f} מ'")
    gate("ושוט בלי תוכנית הליכה קיבל הליכה לאורך השוט",
         md.shots[5]["plan"]["A"] == [("walk", 16.0)],
         f"{md.shots[5]['key']}: {md.shots[5]['plan']['A']}")
    mg = BR.audit(md)
    bad = [k for k, v in mg.items() if not v["pass"]]
    gate("וכל שערי הגשר שלו נסגרים",
         not bad, f"{len(mg) - len(bad)}/{len(mg)} שערים" +
                  (f" · נפל: {bad}" if bad else ""))
    msh = BR.build_shots(md, {k: 1.6 + 0.03 * i
                              for i, k in enumerate(md.slots)})
    gate("ועשרה שחקנים ועשר תנועות נבנים בכל שוט",
         all(len(s.actors) == 10 and len(s.moves) == 10 for s in msh)
         and all("lx" in BR.mv_frame(md, s, k, 0.5, s.t_abs + 0.5)
                 for s in msh for k in md.slots),
         f"{len(msh)} שוטים · "
         f"{min(len(s.actors) for s in msh)}-"
         f"{max(len(s.actors) for s in msh)} שחקנים")

    # --- תסריט שנוצר עכשיו, מחוץ למאגר
    path, _d = _mktmp()
    tm = BR.load(path)
    tbad = [k for k, v in BR.audit(tm).items() if not v["pass"]]
    gate("ותסריט בן 12 דמויות שנוצר בזמן הבדיקה נטען מנתיב קובץ",
         len(tm.cast) == 12 and abs(tm.total - 20.0) < 1e-9
         and not tbad,
         f"{len(tm.cast)} דמויות · {tm.total:g} שניות · "
         f"{len(BR.audit(tm)) - len(tbad)} שערים עברו")

    # ======================================= 3 · תכונות ומלכודות
    worst_n, worst_gap, worst_pair = 0, 9.9, 9.9
    ok_spread = True
    for nn in range(2, 25):
        for cj in (1, 2):
            v = BR.spread_unit(nn, 0.17 * cj, cj)
            gp = BR.min_gap(v)
            if len(set(v)) != nn or gp < 0.9 / nn:
                ok_spread = False
            if gp / (1.0 / nn) < worst_gap:
                worst_gap, worst_n = gp / (1.0 / nn), nn
        # ושני הערוצים אינם אותו ערוץ: דמות שמקבלת את אותו **זוג**
        # (זרע, פאזה) כמו שכנתה היא שתי בבואות בעלות אחד.
        s1 = BR.spread_unit(nn, 0.17, 1)
        s2 = BR.spread_unit(nn, 0.0, 2)
        if nn > 2:
            d = [round((a - b) % 1.0, 4) for a, b in zip(s1, s2)]
            worst_pair = min(worst_pair, len(set(d)) / nn)
            if len(set(d)) < 2:
                ok_spread = False
    gate("הזרעים נבדלים ומרווחים לכל מספר דמויות (2..24)",
         ok_spread,
         f"היחס הגרוע ביותר למרווח האידאלי {worst_gap:.2f} "
         f"(ב-{worst_n} דמויות) · הערוצים אינם תלויים")
    gate("ושמות המקומות ייחודיים גם ל-30 דמויות",
         len(set(BR.letters(30))) == 30 and BR.letters(3) == ("A", "B", "C"),
         f"{BR.letters(30)[-1]} הוא האחרון")

    # --- הפרת חוזה נתפסת **בטעינה**
    import types
    def _mod(**kw):
        m = types.ModuleType("bad_script")
        for k, v in kw.items():
            setattr(m, k, v)
        return m

    def _fails(**kw) -> bool:
        try:
            BR.Script("bad", _mod(**kw))
        except ValueError:
            return True
        except Exception:                                  # noqa: BLE001
            return False
        return False

    ok_cast = ("dn_ariel", "dn_shir")
    cases = {
        "בלי דמויות": _fails(SHOTS=({"key": "a", "secs": 1.0},)),
        "דמות שלא נבנתה": _fails(CAST=("אין_כזו",),
                                 SHOTS=({"key": "a", "secs": 1.0},)),
        "בלי שוטים": _fails(CAST=ok_cast),
        "שוט שאינו כפולה של פריים": _fails(
            CAST=ok_cast, SHOTS=({"key": "a", "secs": 1.017},)),
        "תוכנית שאינה מכסה את השוט": _fails(
            CAST=ok_cast, SHOTS=({"key": "a", "secs": 2.0,
                                  "plan": {"A": [("walk", 1.0)]}},)),
        "אורך מוצהר שאינו סכום השוטים": _fails(
            CAST=ok_cast, TOTAL_SECONDS=99.0,
            SHOTS=({"key": "a", "secs": 2.0},)),
        "מקום שאינו בהרכב": _fails(
            CAST=ok_cast, SHOTS=({"key": "a", "secs": 2.0,
                                  "vis": ("A", "Z")},)),
    }
    gate("הפרת חוזה נתפסת בטעינה ולא בפריים 2000",
         all(cases.values()),
         " · ".join(f"{k}: {'✓' if v else '✗'}"
                    for k, v in cases.items()))

    # מלכודת 1: פונקציית מצב בחתימה לא מתאימה נדחית.
    gate("ופונקציית מצב בחתימה לא מתאימה נדחית ולא נקראת",
         not BR.Script._sit_ok(lambda a, b, c, d: None)
         and not BR.Script._sit_ok(lambda a: None)
         and BR.Script._sit_ok(lambda a, b, c: None)
         and ds._sit is None and R._sit is not None and sc._sit is R._sit,
         "disney_story._sit (4 ארגומנטים) נדחה · "
         "park90_render._sit (3) אומץ")

    names = BR.discover()
    gate("וגילוי התסריטים מוצא את שלושתם",
         sum(1 for x in names if x.startswith(("park90:", "disney_story:",
                                               "meadow120:"))) == 3,
         " | ".join(names))
    return g


def passed() -> bool:
    return all(v["pass"] for v in audit().values())


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8")
    g = audit()
    bad = 0
    for k, v in g.items():
        print(("  ✓ " if v["pass"] else "  ✗ ") + k + " — " + v["detail"])
        bad += 0 if v["pass"] else 1
    print(f"\n{len(g) - bad}/{len(g)} שערים עברו")
    return 0 if bad == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
