# -*- coding: utf-8 -*-
r"""אצווה כבדה ברקע על רנר אפל חינמי של GitHub, בלי לחסום את העבודה כאן.

**מה זה כן, ומה זה בכוונה לא.** ב-07/10 נמדד כאן שוב ושוב שאין כרטיס
מסך חינמי שמריץ את *רינדור הדפדפן* שלנו: לרנרי ``ubuntu``/``windows``
של גיטהאב אין GPU בכלל, ו-``macos-15`` הוא Apple Silicon עם Metal חשוף
אבל **בלי מושב גרפי** — Chrome שם נתקע ולא החזיר DOM. לכן:

* רינדור הפריימים נשאר **מקומי**, על הכרטיס של המכונה (פי 3.56 מהתוכנה).
* מה שעובר לענן הוא **החישוב הכבד שאינו דפדפן**: מסלול הפוזות, שיפוט
  המבקרים, וסריקות פרמטרים. זה בדיוק מה ש-``deliver.review`` עושה, והוא
  מתפצל לשוטים בלי שום תלות ביניהם.

**ולמה אסינכרוני, ולא "להמתין לענן".** זמן התור של רנר אפל נמדד כאן
12-13 דקות לפני שהוא בכלל מתחיל. כלומר המתנה סינכרונית לענן הייתה
*מאיטה* כל עבודה אינטראקטיבית פי כמה, גם כשהחישוב עצמו שם מהיר פי 6.
לכן החוזה של הקובץ הזה הוא **שלא חוסם לעולם**:

1. ``submit`` דוחף, מפעיל, שומר כרטיס לדיסק וחוזר. בלי שום ``sleep``.
2. ``poll`` הוא מעבר אחד: אם הריצה עוד לא התחילה — חוזר מיד.
3. חלף ``QUEUE_GRACE`` והריצה עוד בתור — הכרטיס מסומן ``fallback`` והעבודה
   נעשית **מקומית**. התוצאה המקומית מנצחת מכאן ואילך, גם אם הענן יענה
   אחר כך: שתי אמיתות לאותה עבודה הן באג, לא גיבוי.

הכרטיס נשמר לדיסק ולא בזיכרון, מאותה סיבה שחוזרת כאן כל הזמן: התהליך
הזה עולה מחדש כמה פעמים ביום, ומצב שחי בזיכרון נמחק בשקט — כלומר אצווה
שהוגשה לענן הייתה נשכחת ודקות הענן נשרפות לחינם.

    python -m showreel.cloudbatch submit --script park90 --sweep smooth
    python -m showreel.cloudbatch poll            # מעבר אחד על כל הכרטיסים
    python -m showreel.cloudbatch show <id>
"""
from __future__ import annotations

import hashlib
import json
import os
import sys
import time
import zipfile
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterable, Optional, Sequence

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

#: איפה יושבים הכרטיסים. בתוך הפרויקט, כדי שייכנסו למאגר הגרסאות
#: ושאפשר יהיה לראות מה הוגש לענן ומתי בלי לשאול את גיטהאב.
TICKETS = ROOT / "production" / "cloudbatch"

#: **רק** ``macos-15``. נמדד 07/10: ``macos-14`` נפל ב-
#: ``MPS backend out of memory`` גם על מטריצה של 1024, ו-``ubuntu``
#: הוא Azure בלי GPU. רשימה "ליתר ביטחון" כאן הייתה שורפת דקות ענן
#: על רנר שידוע שנופל.
RUNNER = "macos-15"

#: שם התהליך בצד גיטהאב.
WORKFLOW = "animbatch.yml"

#: כמה רנרים במקביל. מאגר ציבורי מקבל יותר, אבל 6 הוא מה שנמדד כאן
#: בפועל (``bench/fanout``) ומעליו התור עצמו מתארך.
MAX_SHARDS = 6

#: כמה זמן מחכים שהריצה תתחיל לפני שעוברים למקומי, בשניות.
#: 13 דקות - זמן התור שנמדד (12-13) ועוד נשימה. קצר מזה היה מוותר
#: על הענן בדיוק כשהוא עומד להתחיל; ארוך מזה הוא המתנה לחינם.
QUEUE_GRACE = 13 * 60

#: תקרה לריצה כולה. מעליה הכרטיס פג ועוברים למקומי.
RUN_LIMIT = 40 * 60

#: כמה זמן כרטיס פתוח לאותה אצווה נחשב "אותה בקשה". הגשה שנייה של
#: אותו מטען בתוך החלון הזה **אינה** מדליקה אצווה שנייה: זה היה
#: מכפיל את דקות הענן בלי שום תוצאה נוספת.
REUSE_WINDOW = 45 * 60

#: מה נשלח לרנר. רשימת-היתר ולא רשימת-חסימה: קובץ חדש שלא חשבנו
#: עליו לא ידלוף לענן בטעות. ``.env``, יומנים, מדיה ופלט בחוץ.
#:
#: **``stage`` ו-``production/script`` נוספו אחרי ריצה אמיתית ולא
#: מקריאת קוד.** ההגשה הראשונה הצליחה בכל השרשרת — שש מכונות,
#: 37 שניות תור, שישה artifacts — וכל שש העבודות חזרו עם
#: ``ModuleNotFoundError: No module named 'stage'``: ``disney_story``
#: מייבא ``stage.park_disney`` ברמת המודול, ושרשרת ייבוא אינה נראית
#: ברשימת תיקיות שנכתבה ביד. הדרך לדעת מה חסר היא להריץ, ולא לנחש —
#: וזו גם הסיבה שעבודה שנפלה מחזירה ``error`` עם traceback ולא
#: נמחקת בשקט: שקט כאן היה נקרא "הענן לא ענה".
SOURCE_DIRS: tuple[str, ...] = ("rig", "studio", "showreel", "stage",
                                "scenes", "production/script")
SOURCE_FILES: tuple[str, ...] = ("engine.py", "report.py")

STATES = ("queued", "running", "done", "failed", "timeout", "fallback")


# ================================================== אריזת המקורות

def source_paths(root: Path = ROOT) -> list[Path]:
    """קובצי הפייתון שהרנר צריך, ממוינים (כדי שהאריזה תהיה יציבה)."""
    out: list[Path] = []
    for d in SOURCE_DIRS:
        p = root / d
        if p.is_dir():
            out += [q for q in p.rglob("*.py") if "__pycache__" not in q.parts]
    out += [root / f for f in SOURCE_FILES if (root / f).is_file()]
    return sorted(out)


def pack_sources(dest: Path, root: Path = ROOT,
                 paths: Optional[Sequence[Path]] = None) -> Path:
    """אורז את המקורות ל-zip **דטרמיניסטי**.

    חותמת זמן קבועה ומיון שמות, ולכן אותו תוכן מייצר אותם בייטים
    בדיוק - וזה מה שמאפשר ל-``put_file`` לזהות "זהה" ולא לדחוף
    600KB בכל הגשה. zip עם mtime אמיתי היה שונה בכל פעם.
    """
    paths = source_paths(root) if paths is None else list(paths)
    dest.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as z:
        for p in paths:
            zi = zipfile.ZipInfo(p.relative_to(root).as_posix(),
                                 date_time=(1980, 1, 1, 0, 0, 0))
            zi.compress_type = zipfile.ZIP_DEFLATED
            zi.external_attr = 0o644 << 16
            z.writestr(zi, p.read_bytes())
    return dest


# ========================================================= המטען

def job_key(job: dict) -> str:
    """מפתח קריא ויציב לעבודה אחת."""
    if job.get("key"):
        return str(job["key"])
    bits = [str(job.get("task", "measure")), str(job.get("script", ""))]
    tun = job.get("tuning") or {}
    bits += [f"{k}={tun[k]}" for k in sorted(tun)]
    return "|".join(b for b in bits if b)


def plan_shards(jobs: Sequence[dict],
                max_shards: int = MAX_SHARDS) -> list[list[dict]]:
    """מחלק עבודות לרנרים. **אין פיצול של עבודה בודדת.**

    עבודה אחת היא היחידה הקטנה ביותר, ולכן מספר הרנרים הוא
    ``min(len(jobs), max_shards)``. הפיזור הוא סבב (round-robin)
    ולא חתיכות רצופות: סריקת פרמטרים ממוינת שמחולקת לחתיכות
    מרכזת את העבודות הכבדות ברנר אחד, וזמן הקיר הוא של האיטי.
    """
    jobs = [j for j in jobs if j]
    if not jobs:
        return []
    n = max(1, min(len(jobs), int(max_shards)))
    out: list[list[dict]] = [[] for _ in range(n)]
    for i, j in enumerate(jobs):
        out[i % n].append(j)
    return out


def payload_of(jobs: Sequence[dict], shards: Sequence[Sequence[dict]]) -> dict:
    return {"version": 1,
            "created": round(time.time(), 1),
            "jobs": [dict(j) for j in jobs],
            "shards": [[job_key(j) for j in sh] for sh in shards]}


def signature(jobs: Sequence[dict]) -> str:
    """חתימת אצווה. מפתחות העבודות בלבד, ממוינים.

    לא חותמת זמן ולא מספר רנרים: אחרת אותה אצווה בדיוק נראית חדשה
    בכל הגשה, ``REUSE_WINDOW`` לא נאכף לעולם, וכל קריאה מדליקה
    שש מכונות.
    """
    keys = sorted(job_key(j) for j in jobs)
    return hashlib.sha256("\n".join(keys).encode()).hexdigest()[:16]


# ======================================================== הכרטיס

@dataclass
class Ticket:
    """אצווה אחת שהוגשה לענן. ``state`` הוא המצב היחיד שקובע."""

    id: str = ""
    signature: str = ""
    workflow: str = WORKFLOW
    runner: str = RUNNER
    state: str = "queued"
    dispatched_at: float = 0.0
    run_id: int = 0
    started_at: float = 0.0
    finished_at: float = 0.0
    queue_seconds: float = 0.0
    shards: list = field(default_factory=list)
    jobs: list = field(default_factory=list)
    results: dict = field(default_factory=dict)
    missing: list = field(default_factory=list)
    source: str = ""                 #: "cloud" / "local"
    note: str = ""
    polls: int = 0

    # ---------------------------------------------------------- דיסק

    @property
    def path(self) -> Path:
        return TICKETS / f"{self.id}.json"

    def save(self) -> Path:
        """כתיבה אטומית. דריסה ישירה שנקטעת משאירה חצי JSON, וקורא
        סלחני היה קורא אותו כ"אין כרטיס" ומדליק אצווה שנייה."""
        TICKETS.mkdir(parents=True, exist_ok=True)
        blob = json.dumps(self.to_dict(), ensure_ascii=False, indent=1,
                          default=str)
        json.loads(blob)                    # הבייטים נפרסים לפני שהם נכתבים
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(blob, encoding="utf-8")
        os.replace(tmp, self.path)
        return self.path

    def to_dict(self) -> dict:
        return asdict(self)

    # --------------------------------------------------------- מצבים

    @property
    def open(self) -> bool:
        return self.state in ("queued", "running")

    @property
    def usable(self) -> bool:
        """יש תוצאה אחת לפחות שאינה שגיאה.

        **נמדד ולא שוער:** אצווה שכל שש העבודות שלה חזרו עם
        ``ModuleNotFoundError`` נרשמה ``done`` עם שש תוצאות, ולכן
        ``find_open`` החזיר אותה להגשה הבאה — כלומר תיקון של
        המקורות לא נבדק מעולם, והמשתמש קיבל פעמיים בדיוק את אותה
        שגיאה. "חזרה תשובה" אינו "חזרה תוצאה".
        """
        if self.state != "done" or not self.results:
            return False
        return any(not (isinstance(v, dict) and v.get("error"))
                   for v in self.results.values())

    def overdue(self, now: Optional[float] = None) -> bool:
        """התור ארוך מדי ועדיף לעבוד מקומית."""
        t = time.time() if now is None else now
        if self.state != "queued":
            return False
        return (t - self.dispatched_at) >= QUEUE_GRACE

    def expired(self, now: Optional[float] = None) -> bool:
        t = time.time() if now is None else now
        return self.open and (t - self.dispatched_at) >= RUN_LIMIT

    def text(self) -> str:
        age = int(time.time() - self.dispatched_at) if self.dispatched_at else 0
        L = [f"כרטיס {self.id} · {self.runner} · {self.state} · "
             f"{len(self.jobs)} עבודות ב-{len(self.shards)} רנרים · "
             f"גיל {age // 60}:{age % 60:02d}"]
        if self.queue_seconds:
            L.append(f"  המתנה בתור: {self.queue_seconds:.0f}ש")
        if self.results:
            L.append(f"  תוצאות: {len(self.results)}")
        if self.missing:
            L.append(f"  חסרות: {', '.join(map(str, self.missing))}")
        if self.note:
            L.append(f"  {self.note}")
        return "\n".join(L)


def load_ticket(path: Path) -> Optional[Ticket]:
    """קורא כרטיס. **"אין קובץ" אינו "קובץ שבור".**

    קובץ חסר מחזיר ``None`` בשקט (זה המצב התקין של הרצה ראשונה);
    קובץ פגום מוסג ל-``.corrupt-*`` ומדווח, כדי שלא ייקרא שוב
    ולא ייבלע כאילו לא היה.
    """
    if not path.is_file():
        return None
    try:
        d = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(d, dict) or not d.get("id"):
            raise ValueError("כרטיס בלי מזהה")
    except (OSError, ValueError):
        try:
            path.rename(path.with_suffix(f".corrupt-{int(time.time())}"))
        except OSError:
            pass
        return None
    keep = {f for f in Ticket().to_dict()}
    return Ticket(**{k: v for k, v in d.items() if k in keep})


def tickets() -> list[Ticket]:
    if not TICKETS.is_dir():
        return []
    out = [load_ticket(p) for p in sorted(TICKETS.glob("*.json"))]
    return [t for t in out if t is not None]


def find_open(sig: str, *, now: Optional[float] = None) -> Optional[Ticket]:
    """כרטיס פתוח (או גמור ושמיש) לאותה אצווה, בתוך חלון השימוש."""
    t = time.time() if now is None else now
    best = None
    for k in tickets():
        if k.signature != sig:
            continue
        if (t - k.dispatched_at) > REUSE_WINDOW:
            continue
        if k.open or k.usable:
            if best is None or k.dispatched_at > best.dispatched_at:
                best = k
    return best


# ======================================================== ההגשה

def _gh():
    from gpucloud import gh as GH                          # noqa: PLC0415
    return GH


def submit(jobs: Sequence[dict], *, api=None, runner: str = RUNNER,
           max_shards: int = MAX_SHARDS, root: Path = ROOT,
           reuse: bool = True, now: Optional[float] = None,
           log: Optional[Callable] = None) -> Ticket:
    """דוחף מקורות + מטען, מפעיל את התהליך, ומחזיר **מיד**.

    אין כאן שום המתנה לריצה. גם 404 של "התהליך עוד לא מאונדקס"
    אינו נסיון חוזר עם ``sleep`` (זה מה ש-``gh.dispatch`` עושה,
    והוא נכון לסקריפט מדידה) אלא כרטיס במצב ``queued`` עם הערה —
    ההגשה תיסגר במעבר ה-``poll`` הבא.
    """
    say = log or (lambda *_a, **_k: None)
    api = _gh() if api is None else api
    t = time.time() if now is None else now
    jobs = [dict(j) for j in jobs if j]
    if not jobs:
        raise ValueError("אצווה ריקה")

    sig = signature(jobs)
    if reuse:
        old = find_open(sig, now=t)
        if old is not None:
            old.note = "הוגשה כבר; לא הודלקה אצווה שנייה"
            say(f"  = אותה אצווה כבר בענן ({old.id}, {old.state})")
            return old

    shards = plan_shards(jobs, max_shards)
    pay = payload_of(jobs, shards)
    tid = f"{int(t)}-{sig[:8]}"

    work = TICKETS / "payload"
    work.mkdir(parents=True, exist_ok=True)
    zp = pack_sources(work / "sources.zip", root=root)
    pp = work / "payload.json"
    pp.write_text(json.dumps(pay, ensure_ascii=False, indent=1),
                  encoding="utf-8")

    say(f"  מקורות: {zp.stat().st_size} בייט · "
        f"{len(jobs)} עבודות ב-{len(shards)} רנרים")
    api.put_file("animbatch/sources.zip", zp)
    api.put_file("animbatch/payload.json", pp)

    k = Ticket(id=tid, signature=sig, runner=runner, state="queued",
               dispatched_at=t,
               shards=[[job_key(j) for j in sh] for sh in shards],
               jobs=[job_key(j) for j in jobs])
    try:
        api.dispatch(WORKFLOW, {"shards": str(len(shards)),
                                "runner": runner, "ticket": tid},
                     tries=1)
    except Exception as exc:                               # noqa: BLE001
        k.note = f"ההפעלה לא נתפסה עדיין: {exc}"
    k.save()
    say(f"  הוגש: {tid}")
    return k


# ======================================================== המעקב

def _find_run(api, after: float, *, workflow: str = WORKFLOW) -> dict | None:
    """ריצה אחת, בקשה אחת, בלי ``sleep``."""
    d = api.req(f"/repos/{api.REPO}/actions/workflows/{workflow}"
                f"/runs?per_page=5")
    for r in d.get("workflow_runs", []):
        try:
            when = api.utc(r["created_at"])
        except Exception:                                  # noqa: BLE001
            continue
        if when >= after - 180:
            return r
    return None


def poll(k: Ticket, *, api=None, now: Optional[float] = None,
         log: Optional[Callable] = None) -> Ticket:
    """מעבר אחד. **לא חוסם ולא ישן.** מעדכן את הכרטיס בדיסק."""
    say = log or (lambda *_a, **_k: None)
    api = _gh() if api is None else api
    t = time.time() if now is None else now
    if not k.open:
        return k
    k.polls += 1

    if k.overdue(t):
        k.state, k.source = "fallback", "local"
        k.note = (f"התור עבר {QUEUE_GRACE // 60} דקות — העבודה נעשית "
                  f"מקומית. הענן לא ייקרא יותר על האצווה הזו.")
        k.save()
        say("  ⏭ " + k.note)
        return k
    if k.expired(t):
        k.state, k.note = "timeout", "הריצה לא נסגרה בתקרת הזמן"
        k.save()
        return k

    try:
        if not k.run_id:
            r = _find_run(api, k.dispatched_at, workflow=k.workflow)
            if r is None:
                k.save()
                return k
            k.run_id = int(r["id"])
            k.note = ""
        r = api.req(f"/repos/{api.REPO}/actions/runs/{k.run_id}")
        if r.get("status") != "completed":
            k.state = "running" if r.get("status") == "in_progress" \
                else "queued"
            k.save()
            return k
        k.finished_at = t
        if r.get("conclusion") != "success":
            k.state = "failed"
            k.note = f"הריצה נגמרה ב-{r.get('conclusion')}"
            k.save()
            return k
        try:
            tim = api.job_timing(k.run_id)
            qs = [j["queue_seconds"] for j in tim
                  if j.get("queue_seconds") is not None]
            k.queue_seconds = round(max(qs), 1) if qs else 0.0
        except Exception:                                  # noqa: BLE001
            pass
        got = api.fetch_artifacts(k.run_id).get("results") or {}
        k.results, k.missing = merge_results(got, k.jobs)
        k.state = "done" if k.results else "failed"
        k.source = "cloud" if k.results else ""
        if not k.results:
            k.note = "הריצה עברה אבל לא חזרה שום תוצאה"
        k.save()
        say(f"  ✓ {k.id}: {len(k.results)} תוצאות מהענן")
    except Exception as exc:                               # noqa: BLE001
        k.note = f"מעקב נכשל: {exc}"
        k.save()
    return k


def merge_results(arts: dict, want: Sequence[str]) -> tuple[dict, list]:
    """מאחד את ה-artifacts לפי מפתח עבודה, ו**אומר מה חסר**.

    עבודה שלא חזרה אינה נמחקת בשקט: שם היא הופכת ל"ציון 0" או
    ל"עברה", ושני המצבים הם דיווח שקרי. היא נרשמת ב-``missing``.
    """
    out: dict[str, Any] = {}
    for blob in (arts or {}).values():
        rows = (blob or {}).get("results") if isinstance(blob, dict) else None
        if isinstance(rows, dict):
            out.update(rows)
        elif isinstance(blob, dict) and blob.get("key"):
            out[str(blob["key"])] = blob
    missing = [w for w in want if w not in out]
    return out, missing


# ============================================== מקומי כנפילה רכה

def run_local(jobs: Sequence[dict], worker: Callable[[dict], dict], *,
              log: Optional[Callable] = None) -> dict:
    """מריץ את אותן עבודות כאן. אותה חתימה, אותו פלט.

    עבודה שנפלה נרשמת עם ``error`` ואינה מפילה את האצווה: אצווה
    של שש שנופלת על אחת היא חמש תוצאות שנזרקו לפח.
    """
    say = log or (lambda *_a, **_k: None)
    out: dict[str, Any] = {}
    for j in jobs:
        kk = job_key(j)
        try:
            out[kk] = worker(j)
        except Exception as exc:                           # noqa: BLE001
            out[kk] = {"key": kk, "error": str(exc)}
            say(f"  ✗ {kk}: {exc}")
    return out


def ensure(jobs: Sequence[dict], *, worker: Optional[Callable] = None,
           api=None, now: Optional[float] = None, submit_new: bool = True,
           log: Optional[Callable] = None) -> dict:
    """הפעולה היחידה שקוראים לה מבחוץ, והיא **אינה חוסמת**.

    מחזירה ``{"ready": bool, "results": {...}, "ticket": Ticket|None,
    "source": "cloud"/"local"/""}``:

    * יש תוצאות ענן מוכנות → מחזיר אותן.
    * התור ארוך מדי (או שאין ענן) ויש ``worker`` → מריץ מקומית.
    * אחרת → מגיש/בודק וחוזר מיד עם ``ready=False``, והעבודה
      האינטראקטיבית ממשיכה בלי להמתין.
    """
    say = log or (lambda *_a, **_k: None)
    t = time.time() if now is None else now
    sig = signature(jobs)
    k = find_open(sig, now=t)

    if k is None and submit_new:
        try:
            k = submit(jobs, api=api, now=t, log=log)
        except Exception as exc:                           # noqa: BLE001
            say(f"  ענן לא זמין: {exc}")
            k = None
            if worker is not None:
                return {"ready": True, "source": "local", "ticket": None,
                        "results": run_local(jobs, worker, log=log)}
    if k is not None and k.open:
        k = poll(k, api=api, now=t, log=log)

    if k is not None and k.usable:
        return {"ready": True, "source": "cloud", "ticket": k,
                "results": dict(k.results)}
    dead = k is not None and (k.state in ("fallback", "failed", "timeout")
                              or (k.state == "done" and not k.usable))
    if dead and worker is not None:
        return {"ready": True, "source": "local", "ticket": k,
                "results": run_local(jobs, worker, log=log)}
    return {"ready": False, "source": "", "ticket": k, "results": {}}


# =========================================================== CLI

def _sweep_jobs(script: str, sweep: str, values: Sequence[float]) -> list[dict]:
    return [{"task": "measure", "script": script, "tuning": {sweep: v}}
            for v in values]


def main(argv=None) -> int:
    import argparse                                        # noqa: PLC0415
    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(
        description="אצווה כבדה ברקע על רנר אפל של גיטהאב")
    ap.add_argument("cmd", choices=["submit", "poll", "list", "show",
                                    "pack"])
    ap.add_argument("arg", nargs="?", default="")
    ap.add_argument("--script", default="park90")
    ap.add_argument("--sweep", default="smooth_win")
    ap.add_argument("--values", default="0.08,0.12,0.16,0.2,0.24,0.28")
    a = ap.parse_args(argv)

    def log(x):
        print(x, flush=True)

    if a.cmd == "pack":
        p = pack_sources(TICKETS / "payload" / "sources.zip")
        print(f"{p} · {p.stat().st_size} בייט · "
              f"{len(source_paths())} קבצים")
        return 0
    if a.cmd == "submit":
        vals = [float(x) for x in a.values.split(",") if x.strip()]
        k = submit(_sweep_jobs(a.script, a.sweep, vals), log=log)
        print(k.text())
        return 0
    if a.cmd == "poll":
        open_ = [k for k in tickets() if k.open]
        if not open_:
            print("אין כרטיס פתוח")
            return 0
        for k in open_:
            print(poll(k, log=log).text())
        return 0
    if a.cmd == "list":
        ks = tickets()
        print(f"{len(ks)} כרטיסים")
        for k in ks:
            print(k.text())
        return 0
    for k in tickets():
        if k.id == a.arg or k.id.startswith(a.arg):
            print(k.text())
            print(json.dumps(k.results, ensure_ascii=False, indent=1)[:4000])
            return 0
    print("לא נמצא כרטיס")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
