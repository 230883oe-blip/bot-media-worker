# -*- coding: utf-8 -*-
"""שערי שרשרת האספקה האוטונומית. בלי דפדפן, בלי רינדור, בשניות.

שלושה דברים נמדדים כאן, ואין ביניהם קשר:

1. **סדר השלבים, ומה שהוא חוסך.** השרשרת היא מסננת לפי מחיר:
   חוזה → מדידה → טיוטה → סופי. השערים כאן מאמתים ש**שלב שנפל
   עוצר את הבא אחריו בפועל** — כלומר שתסריט פגום אינו מגיע ל-26
   דקות הרינדור ולו פעם אחת. ``render`` ו-``inspect`` מוזרקים
   כרשמנים, ולכן השערים האלה מודדים סדר ולא אנימציה.
2. **לוגיקת הלולאה.** קיפאון, כשל בלי ידית מחוברת ותקרת סבבים.
   ``measure`` מוזרק עם ציונים מוכתבים, כי בדיקה שתלויה בציון
   אמיתי של תסריט אמיתי משתנה בכל נגיעה בריג ואז נמחקת.
3. **שההחלקה היא על התנועה ולא על המדידה.** זו הדרישה שהכי קל
   להתחזות אליה: פילטר במודד מוריד את ``anim.jitter`` בדיוק
   באותה מידה ואינו משנה פריים אחד בסרטון. השערים כאן מודדים
   שהעטיפה יושבת על אותה פונקציה שהרינדור קורא, **ושהיא אינה
   נוגעת ביעדי ה-IK** — רגל דורכת היא אילוץ ולא עקומה.
"""
from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
STUDIO = HERE.parent
if str(STUDIO) not in sys.path:
    sys.path.insert(0, str(STUDIO))

from showreel import bridge as BR                         # noqa: E402
from showreel import deliver as DL                        # noqa: E402
from studio import panel as P                             # noqa: E402
from studio import qa as QA                               # noqa: E402
from studio import tuning as TU                           # noqa: E402

#: תסריט מינימלי שנוצר בזמן הבדיקה: שתי דמויות, שני שוטים קצרים,
#: **נתונים בלבד**. קצר בכוונה — השערים כאן מודדים את השרשרת,
#: ולא את איכות האנימציה של תסריט כלשהו.
TMP_SCRIPT = '''# -*- coding: utf-8 -*-
"""תסריט שנוצר בבדיקת האספקה. נתונים בלבד."""
CAST2 = ("lucas", "maya")
SHOTS = (
    {"key": "d1", "secs": 5.0, "camera": "wide", "cap": "פתיחה",
     "beat": "stroll"},
    {"key": "d2", "secs": 5.0, "camera": "crane", "cap": "סיום",
     "beat": "embrace"},
)
'''


def _mktmp(body: str = TMP_SCRIPT, name: str = "tmp_deliver2.py") -> Path:
    d = Path(tempfile.mkdtemp(prefix="deliver_script_"))
    p = d / name
    p.write_text(body, encoding="utf-8")
    return p


# ------------------------------------------------------------- כפילים

def _pv(score: float, *, codes=("anim.jitter",), dim: str = "animation",
        shot_id: str = "s:A") -> P.PanelVerdict:
    """פסק פאנל מוכתב. מאפשר לבדוק את הלולאה בלי למדוד אנימציה."""
    ok = score >= P.PASS_FLOOR
    return P.PanelVerdict(
        shot_id=shot_id, scores={dim: score}, passed=ok,
        gate=("עבר" if ok else f"{dim} {score:.1f} מתחת לרצפה"),
        weakest=dim, weakest_score=score,
        diagnosis=[] if ok else [{"code": c, "label": c, "value": 1.0,
                                  "limit": "<=0.5", "repair": "smooth_curves"}
                                 for c in codes],
        mean=score, worst=score)


def _qa(passed: bool, *, name: str = "blank", blame: str = "engine.py",
        score: float = 100.0) -> QA.Report:
    """דוח ``qa`` אמיתי (לא כפיל טיפוס) עם בדיקה אחת מוכתבת."""
    chk = QA.Check(name=name, passed=passed, metric=0.0, threshold=0.0,
                   blame=blame, detail="מוכתב בבדיקה").to_dict()
    return QA.Report(path="x.mp4", passed=passed,
                     score=score if passed else 40.0, checks=[chk],
                     width=1920, height=1080, fps=30.0, frames=120,
                     seconds=4.0)


class Engine:
    """מנוע תיקון מוכתב, עם רשומת קריאות."""

    def __init__(self, *plans):
        self.plans = list(plans)
        self.calls: list[tuple] = []

    def plan(self, stage, focus, verdict):
        self.calls.append((stage, tuple(focus), verdict))
        if self.plans:
            return self.plans.pop(0)
        return {"repairs": [], "files": [], "manual": [], "note": ""}


class Recorder:
    """רשמן רינדור: מחזיר דוח, ולא פותח דפדפן."""

    def __init__(self, fail_at: str = ""):
        self.calls: list[tuple] = []
        self.fail_at = fail_at

    def __call__(self, sc, out, spec, on_progress=None):
        self.calls.append((spec.label, spec.width, spec.height, spec.fps,
                           str(out)))
        if self.fail_at == spec.label:
            return {"mp4": None}
        return {"mp4": str(out), "render_sec": 1.0, "size_mb": 1.0,
                "frames": 120, "seconds": 4.0}

    @property
    def labels(self) -> list[str]:
        return [c[0] for c in self.calls]


# ============================================================= השערים

def audit() -> dict:
    g: dict[str, dict] = {}

    def gate(key, ok, detail):
        g[key] = {"pass": bool(ok), "detail": str(detail)}

    # =================================== 1 · העטיפה: תנועה, לא מדידה
    path = _mktmp()
    sc = BR.load(str(path))

    s0 = BR.build_shots(sc, smooth=0.0)
    s8 = BR.build_shots(sc, smooth=0.12)
    a0 = s0[0].actors["A"]
    a8 = s8[0].actors["A"]
    c0 = a0(0.5, 1.0)[0]
    c8 = a8(0.5, 1.0)[0]
    moved = [k for k in c0 if k in c8 and abs(c0[k] - c8[k]) > 1e-6]
    gate("חלון ההחלקה משנה את מסלול הפוזות שהרינדור קורא",
         len(moved) >= 3,
         f"{len(moved)} ערוצים זזו מתוך {len(c0)}")

    raw = TU.smoothed(lambda u, t: ({"x": 1.0}, {}, {}), 2.0, 12, win=0.0)
    gate("ובכוונון 0 השחקן חוזר כמות שהוא, בלי שום עטיפה",
         getattr(raw, "smoothed", None) is None
         and not hasattr(raw, "__wrapped__"),
         "אותו אובייקט, אפס עלות")

    ik0 = a0(0.5, 1.0)[1]
    ik8 = a8(0.5, 1.0)[1]
    gate("וההחלקה אינה נוגעת ביעדי ה-IK (רגל דורכת היא אילוץ)",
         set(ik0) == set(ik8) and set(ik0) and ik0 == ik8,
         f"{sorted(ik0)} זהים")

    sp = a8(0.5, 1.0)[2]
    gate("וצורות הפנים כן מוחלקות יחד עם הבקרות",
         isinstance(sp, dict) and len(sp) > 0,
         f"{len(sp)} צורות עברו את העטיפה")

    gate("ותכונות השחקן (דיבור, קול) שורדות את העטיפה",
         all(hasattr(a8, at) == hasattr(a0, at)
             for at in ("speech", "track", "voice")),
         "אותן תכונות בשני המסלולים")

    # ========================================= 2 · מדידה בלי רינדור
    vs = DL.review(sc, sample_fps=8)
    gate("יש פסק לכל (שוט × דמות), בלי לפתוח דפדפן",
         len(vs) == 4 and all(isinstance(v, P.PanelVerdict)
                              for v in vs.values()),
         f"{len(vs)} פסקים · {sorted(vs)}")

    gate("וכל פסק נושא ציון אנימציה אמיתי ולא 'אין עדות'",
         all("animation" in v.scores and
             not any(d["code"].endswith("no_evidence")
                     for d in v.diagnosis) for v in vs.values()),
         f"ציונים {sorted(round(v.worst, 1) for v in vs.values())}")

    k, pv = DL.worst_of({"a": _pv(80.0), "b": _pv(40.0), "c": _pv(40.0)})
    gate("בחירת החלש היא מינימום, ותיקו מוכרע דטרמיניסטית",
         (k, pv.worst) == ("b", 40.0), f"{k} = {pv.worst}")

    dg = DL.as_diagnosis(_pv(42.0, codes=("anim.jitter", "anim.pops")))
    gate("והאבחון שעובר למנוע נושא את קודי הכשל ואת תת-המערכות",
         dg.failed_checks == ["anim.jitter", "anim.pops"]
         and dg.dim == "animation" and dg.subsystems,
         f"{dg.failed_checks} ← {dg.subsystems[:2]}")

    # ============================================= 3 · לולאת התיקון
    plan_ok = {"repairs": ["smooth_curves(smooth_win 0.0→0.04)"],
               "files": [], "manual": [], "note": ""}

    seq = [45.0, 60.0, 75.0]
    h = DL.autocorrect(sc, rounds=4, engine=Engine(plan_ok, plan_ok),
                       measure=lambda n: {"x": _pv(seq[n - 1])})
    gate("לולאה שמשתפרת נעצרת ברגע שהשער נסגר",
         len(h) == 3 and h[-1].passed and h[-1].stop == "השער נסגר",
         f"{[r.worst for r in h]} · {h[-1].stop}")

    flat = [40.0, 40.2]
    h = DL.autocorrect(sc, rounds=4, engine=Engine(plan_ok, plan_ok, plan_ok),
                       measure=lambda n: {"x": _pv(flat[n - 1])})
    gate("וקיפאון עוצר אותה בסבב השני, לא בתקרה",
         len(h) == 2 and not h[-1].passed
         and h[-1].stop.startswith("קיפאון"),
         f"{len(h)} סבבים · {h[-1].stop}")

    e = Engine({"repairs": [], "files": [],
                "manual": ["add_anticipation: אינו מחובר"], "note": ""})
    h = DL.autocorrect(sc, rounds=4, engine=e,
                       measure=lambda n: {"x": _pv(40.0)})
    gate("וכשל בלי ידית מחוברת נאמר במילים ולא מתורגם לתיקון מומצא",
         len(h) == 1 and not h[0].repairs and h[0].manual
         and "דרוש אדם" in h[0].stop,
         f"{h[0].stop} · {h[0].manual}")

    h = DL.autocorrect(sc, rounds=2, engine=Engine(plan_ok, plan_ok),
                       measure=lambda n: {"x": _pv(40.0 + 5.0 * n)})
    gate("ותקרת הסבבים היא רשת ביטחון ולא התנהגות רגילה",
         len(h) == 2 and h[-1].stop == "תקרת הסבבים",
         f"{len(h)} סבבים · {h[-1].stop}")

    # ========================================== 4 · סדר השלבים ומחירם
    ok_measure = lambda n: {"x": _pv(90.0)}                # noqa: E731

    r = Recorder()
    d = DL.deliver(sc, render=r, inspect=lambda *a, **k: _qa(True),
                   measure=ok_measure, save=False)
    gate("מסלול מוצלח: טיוטה, אחריה סופי, ורק אז נמסר",
         d.delivered and r.labels == ["טיוטה", "סופי"] and d.mp4,
         f"{r.labels} · נמסר={d.delivered}")

    gate("והטיוטה זולה מהסופי בשלושת הצירים",
         (r.calls[0][1] < r.calls[1][1] and r.calls[0][2] < r.calls[1][2]
          and r.calls[0][3] < r.calls[1][3]),
         f"טיוטה {r.calls[0][1]}x{r.calls[0][2]}@{r.calls[0][3]} מול "
         f"סופי {r.calls[1][1]}x{r.calls[1][2]}@{r.calls[1][3]}")

    gate("וקצב הטיוטה הוא מחלק של קצב התסריט ולא מספר שרירותי",
         int(sc.fps) % DL.draft_fps(sc) == 0 and DL.draft_fps(sc) <= 10,
         f"{DL.draft_fps(sc)} מחלק את {int(sc.fps)}")

    r = Recorder()
    d = DL.deliver(sc, render=r, inspect=lambda *a, **k: _qa(True),
                   measure=lambda n: {"x": _pv(40.0)},
                   engine=Engine(), save=False)
    gate("שער מדידה שנפל עוצר **לפני** שהדפדפן נפתח אפילו פעם אחת",
         not d.delivered and r.calls == []
         and "שער האיכות לפני הרינדור" in d.reason,
         f"{len(r.calls)} רינדורים · {d.reason[:60]}")

    r = Recorder()
    qas = iter([_qa(False, name="contrast", blame="rig/organic.py")])
    d = DL.deliver(sc, render=r, inspect=lambda *a, **k: next(qas),
                   measure=ok_measure, save=False)
    gate("טיוטה שנפלה בבדיקה הטכנית אינה מגיעה לרינדור הסופי",
         not d.delivered and r.labels == ["טיוטה"]
         and "contrast" in d.reason and "rig/organic.py" in d.reason,
         f"{r.labels} · {d.reason[:70]}")

    r = Recorder()
    qas = iter([_qa(True), _qa(False, name="frozen", blame="engine.py")])
    d = DL.deliver(sc, render=r, inspect=lambda *a, **k: next(qas),
                   measure=ok_measure, save=False)
    gate("וסרטון סופי שנפל בבדיקה אינו נמסר, גם אחרי שרונדר במלואו",
         not d.delivered and r.labels == ["טיוטה", "סופי"] and not d.mp4
         and "frozen" in d.reason,
         f"נמסר={d.delivered} · {d.reason[:60]}")

    r = Recorder(fail_at="סופי")
    d = DL.deliver(sc, render=r, inspect=lambda *a, **k: _qa(True),
                   measure=ok_measure, save=False)
    gate("ורינדור שלא הפיק קובץ בכלל מדווח כך ולא קורא לבדיקה",
         not d.delivered and "לא הפיק קובץ" in d.reason and not d.mp4,
         d.reason)

    r = Recorder()
    d = DL.deliver(sc, render=r, inspect=lambda *a, **k: _qa(True),
                   measure=ok_measure, skip_draft=True, save=False)
    gate("ו--no-draft מדלג על הטיוטה ולא על הבדיקה של הסופי",
         d.delivered and r.labels == ["סופי"],
         f"{r.labels}")

    r = Recorder()
    d = DL.deliver(sc, render=r, inspect=lambda *a, **k: _qa(True),
                   measure=ok_measure, review_only=True, save=False)
    gate("ו--review מודד ואינו מרנדר, וגם אינו מתחזה לאספקה",
         not d.delivered and r.calls == [] and d.stage == "מדידה בלבד",
         f"{len(r.calls)} רינדורים · שלב {d.stage}")

    # ====================================== 5 · חוזה, דוח, ואי-נסיגה
    # 5.01 שניות ב-30fps = 150.3 פריימים, כלומר שוט שאינו כפולה
    # שלמה של פריים. ``bridge.load`` זורק על זה בטעינה.
    broken = _mktmp(TMP_SCRIPT.replace('"secs": 5.0, "camera": "wide"',
                                       '"secs": 5.01, "camera": "wide"'),
                    "tmp_deliver_bad.py")
    r = Recorder()
    d = DL.deliver(str(broken), render=r,
                   inspect=lambda *a, **k: _qa(True),
                   measure=ok_measure, save=False)
    gate("תסריט שמפר חוזה נדחה בשלב הראשון, בלי מדידה, בלי רינדור "
         "ובלי traceback",
         not d.delivered and r.calls == [] and d.stage == "טעינה"
         and "לא נטען" in d.reason,
         d.reason[:90])

    gate("מחזורי הסביבה נשלפים מהמודולים ולא מועתקים כמספר",
         set(DL.env_loops()) == {"מחזור הרוח", "מחזור המזרקה"}
         and all(v > 0 for v in DL.env_loops().values()),
         str(DL.env_loops()))

    gate("ואורך שאינו מתחלק בהם נתפס בשלב הזול, לא ברינדור",
         DL.loop_misfits(4.0) and not DL.loop_misfits(10.0)
         and not DL.loop_misfits(90.0),
         f"4ש: {DL.loop_misfits(4.0)} · 10ש וגם 90ש: נקי")

    # 4 שניות הן פריימים שלמים אך אינן כפולה של מחזור הרוח (10ש),
    # ולכן התפר לא ייסגר — והצופה רואה את זה כפריים שאבד.
    short = _mktmp(TMP_SCRIPT.replace('"secs": 5.0', '"secs": 2.0'),
                   "tmp_deliver4.py")
    r = Recorder()
    d = DL.deliver(str(short), render=r, inspect=lambda *a, **k: _qa(True),
                   measure=ok_measure, save=False)
    gate("ותסריט כזה אינו מגיע לרינדור בכלל",
         not d.delivered and r.calls == []
         and "מחזורי הסביבה" in d.reason,
         d.reason[:95])

    r = Recorder()
    d = DL.deliver(sc, render=r, inspect=lambda *a, **k: _qa(True),
                   measure=ok_measure, save=True)
    rep = Path(d.report) if d.report else None
    blob = json.loads(rep.read_text(encoding="utf-8")) if rep else {}
    gate("דוח האספקה נשמר כ-JSON תקין ונושא את ההכרעה והשלבים",
         bool(rep and rep.exists()) and blob.get("delivered") is True
         and blob.get("final", {}).get("qa", {}).get("passed") is True,
         f"{rep.name if rep else '—'} · {len(blob.get('rounds', []))} סבבים")

    gate("והטקסט למשתמש אומר מה נמסר ובאיזה שלב",
         "נמסר" in d.text() and "סופי" in d.text(),
         d.text().splitlines()[0])

    # ההחלקה היא מצב גלובלי, ולכן השער הזה מאמת שהקריאה לכוונון
    # אינה משנה אותו: ``deliver`` עם מנוע מוכתב לא נוגע בדיסק.
    before = TU.get("smooth_win")
    DL.deliver(sc, render=Recorder(), inspect=lambda *a, **k: _qa(True),
               measure=ok_measure, save=False)
    gate("ומסלול שעבר את השער אינו מזיז את הכוונון בכלל",
         abs(TU.get("smooth_win") - before) < 1e-9,
         f"{before} → {TU.get('smooth_win')}")

    # ================================ 6 · המצב הטוב ביותר, לא האחרון
    class Tune:
        """כוונון מדומה בזיכרון, עם רשומת החלות."""

        def __init__(self, v=0.0):
            self.v = {"smooth_win": v}
            self.applied: list[dict] = []

        def all_values(self):
            return dict(self.v)

        def apply(self, values, why=""):
            self.applied.append(dict(values))
            self.v.update(values)
            return True

    class Stepper:
        """מנוע מוכתב שמזיז את הידית בפועל, כמו ``RepairEngine``.

        הידית **חייבת** לזוז בתוך ``plan`` ולא בתוך המדידה: זה
        הסדר האמיתי (תיקון בסוף סבב n → נמדד בסבב n+1), והכפיל
        שעשה את זה הפוך הפיל את השער ונתפס.
        """

        def __init__(self, tune, steps):
            self.t = tune
            self.steps = list(steps)

        def plan(self, stage, focus, verdict):
            if not self.steps:
                return {"repairs": [], "files": [], "manual": [], "note": ""}
            v = self.steps.pop(0)
            self.t.v["smooth_win"] = v
            return {"repairs": [f"smooth_curves(smooth_win→{v})"],
                    "files": [], "manual": [], "note": ""}

    t = Tune(0.0)
    # הסבב השני שיפר, השלישי החמיר — ולכן חוזרים לכוונון של השני.
    worse = {1: 40.0, 2: 55.0, 3: 48.0}
    h = DL.autocorrect(sc, rounds=3, engine=Stepper(t, [0.08, 0.20]),
                       measure=lambda n: {"x": _pv(worse[n])}, tune=t)
    gate("ידית שהצעד האחרון שלה החמיר מוחזרת למצב הטוב ביותר שנמדד",
         t.applied == [{"smooth_win": 0.08}]
         and abs(t.v["smooth_win"] - 0.08) < 1e-9,
         f"הוחל {t.applied} · סופי {t.v['smooth_win']}")

    gate("והחזרה נרשמת בדוח ולא נעשית בשקט",
         "סבב 2" in (h[-1].note or ""), (h[-1].note or "")[:90])

    t2 = Tune(0.0)
    up = {1: 40.0, 2: 55.0, 3: 70.0}
    h = DL.autocorrect(sc, rounds=3, engine=Stepper(t2, [0.08, 0.12]),
                       measure=lambda n: {"x": _pv(up[n])}, tune=t2)
    gate("ולולאה שהשתפרה עד הסוף אינה חוזרת אחורה בכלל",
         t2.applied == [] and h[-1].passed,
         f"הוחל {t2.applied} · {h[-1].stop}")

    # ============================ 7 · דילוג על השער: מוצהר, לא מוסתר
    r = Recorder()
    d = DL.deliver(sc, render=r, inspect=lambda *a, **k: _qa(True),
                   measure=lambda n: {"x": _pv(48.0)}, engine=Engine(),
                   pre_gate=False, save=False)
    gate("דילוג על השער מרנדר, אך מסמן במפורש שזה אינו תקן הפקה",
         d.delivered and d.gate_bypassed and not d.quality_gate
         and r.labels == ["טיוטה", "סופי"],
         f"{r.labels} · תקן={d.quality_gate} · דילוג={d.gate_bypassed}")

    gate("והטקסט אומר 'דילוג' ולא 'נמסר' בלבד",
         "דילוג" in d.text().splitlines()[0],
         d.text().splitlines()[0])

    r = Recorder()
    d = DL.deliver(sc, render=r, inspect=lambda *a, **k: _qa(True),
                   measure=lambda n: {"x": _pv(48.0)}, engine=Engine(),
                   pre_gate=False, save=False)
    gate("ודילוג אינו מבטל את הבדיקה הטכנית — שתיהן נשארות דרישות",
         d.delivered and d.final.get("qa", {}).get("passed") is True,
         f"בדיקה טכנית {d.final.get('qa', {}).get('passed')}")

    r = Recorder()
    d = DL.deliver(sc, render=r,
                   inspect=lambda *a, **k: _qa(False, name="blank"),
                   measure=lambda n: {"x": _pv(48.0)}, engine=Engine(),
                   pre_gate=False, save=False)
    gate("ובדילוג, סרטון ריק עדיין נדחה",
         not d.delivered and "blank" in d.reason, d.reason[:70])

    return g


def passed() -> bool:
    return all(v["pass"] for v in audit().values())


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8")
    g = audit()
    bad = 0
    for k, v in g.items():
        print(("  ✓ " if v["pass"] else "  ✗ ") + k + " — " + v["detail"])
        bad += 0 if v["pass"] else 1
    print(f"\n{len(g) - bad}/{len(g)} שערים עברו")
    return 0 if bad == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
