# -*- coding: utf-8 -*-
"""TASK 18 (06/10) - "הפארק הדינמי": 60 שניות, ארבע דמויות, עלילה.

זה הצרכן של שלושת המודולים שנבנו במשימה הזו: `rig.cast_disney`
(ארבע הדמויות), `rig.disney_mesh` (שפת הגיאומטריה) ו-
`stage.park_disney` (הסביבה וארבעת האובייקטים).

================================================================
ההכרעה הארכיטקטונית: במה מוכללת, ולא מפיק משוכפל
================================================================

`showreel.produce` מקובע לשתי דמויות **בעומק**: `skel_a`/`skel_b`,
`lib_q_a`/`lib_q_b`, `sm_a`/`sm_b`, ושדות `a=`/`b=` ב-`Shot`.
שתי דרכים נשקלו, ושאלתי גם יועץ חיצוני (GPT-OSS 120B, 06/10):

* **להכליל את `showreel.produce` ל-N.** היועץ המליץ על זה, בעיקר
  נגד שכפול קוד - וזה נימוק נכון. הוא נפסל כאן בגלל מה שהיועץ לא
  ידע: 1260 בדיקות עוברות דרך אותה פונקציה, וריפקטור של לולאת
  הרינדור הוא בדיוק הסוג של שינוי שמפיל בדיקה אחת בלי קשר
  לארבע הדמויות.
* **מפיק נפרד עם במה נפרדת.** נפסל גם הוא: שתי במות HTML היו
  שתי מערכות SSS, שתי מערכות סביבה ושני באגים לכל תיקון.

מה שנעשה בפועל הוא השלישי: **הבמה מוכללת ל-N מקומות, והמפיק
נפרד.** `stage_html()` נוצר **מ-`rig/stage.html` בזמן ריצה** בשש
החלפות מדויקות (`['A','B']` -> `SLOTS`), ולכן כל תיקון עתידי
בבמה המקורית מגיע לכאן לבד - אין עותק שמתיישן. והמפיק כאן נוגע
רק בלולאת הפריימים, שהיא הדבר היחיד שבאמת תלוי במספר הדמויות.

================================================================
האופניים הם שכבת-על דו-ממדית, וזו הכרעה מודעת
================================================================

`ensemble` פסל ספריט דו-ממדי לסנאי כי הסנאי **חייב לעבור מאחורי**
גרומפ. האופניים כאן אינם: הם מתגלגלים על השביל שלפני הדמויות
לאורך כל 19 השניות של הנסיעה, והדמויות רצות **אחריהם**. לכן
שכבת-על דו-ממדית אינה שוברת את העומק בשוט הזה, והיא חוסכת שלדה,
שני גלגלים וחישורים כגאומטריה תלת-ממדית עם מפת צל. אותו שיקול
חל על סילוני המזרקה, שנמצאים מאחורי כולם ומעולם לא לפני אף אחד.

**מה שכן נגזר ולא נכתב:** סיבוב הגלגל נגזר מהמרחק שנעבר
(`park_disney.bike_at`), ולא מעקומה נפרדת. גלגל שמסתובב בקצב
שאינו קצב הנסיעה הוא "החלקת גלגל" - אותו פגם בדיוק כמו החלקת
רגליים, ובמסגרת שבה אפס החלקת רגליים הוא שער, גלגל מחליק היה
חור בחוזה.
"""
from __future__ import annotations

import asyncio
import json
import math
import shutil
import sys
import tempfile
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
STUDIO = HERE.parent
if str(STUDIO) not in sys.path:
    sys.path.insert(0, str(STUDIO))

from rig import cast_disney as CD                        # noqa: E402
from rig import controls, secondary                      # noqa: E402
from rig import locomotion as LM                         # noqa: E402
from rig import showreel as SR                           # noqa: E402
from rig import voice as V                               # noqa: E402
from stage import park_disney as PD                      # noqa: E402

FPS = 30
TOTAL_SECONDS = 60.0

#: ארבעת המקומות על הבמה, ו-x של כל אחד. הסדר הוא סדר הליהוק.
SLOTS = ("A", "B", "C", "D")
CAST = CD.CAST4                     # ariel, shir, noam, gidon
#: 1.85 מ' ו-1.20 מ' באותו פריים: ההפרדה חייבת להיות רחבה, אחרת
#: הילד נעלם מאחורי הנער בשוט הרחב.
LANE_X = {"A": -1.15, "B": -0.45, "C": 0.35, "D": 1.15}
LANE_YAW = {"A": 13, "B": -9, "C": -16, "D": 9}

ENV_DIR = Path(r"D:\claude-bot\out\char3d\env\park_disney")
OUT_DIR = Path(r"D:\claude-bot\out\char3d\showreel")

#: סחיפת הרקע ליחידת מטר. אותו ערך של `chase`, ומאותו נימוק.
PAN_SCALE = 0.030

#: חלון נסיעת האופניים על ציר הזמן של הסרט כולו. מתחיל בשנייה
#: שבה הילד מגיח (14.0 = 12.0 + 2.0) ונגמר כשהסבא עוצר אותם.
BIKE_ROLL = (14.0, 33.0)

#: הרגע שבו הרץ עובר את קו העץ, לתגובת העלווה. ראה `park_disney`.
TREE_PASS = 17.4

#: ארבעת השוטים. 12 + 18 + 15 + 15 = 60.0 בדיוק.
#: `secs` חייב להיות כפולה שלמה של 1/FPS, אחרת סך הפריימים אינו
#: 1800 והלופ של הרוח אינו נסגר.
#:
#: `line` הוא (דמות, התחלה בשוט, אורך ההקלטה, טקסט). **אורך
#: ההקלטה ולא הערכה** - חמשת האורכים כאן נמדדו מקבצי ה-wav
#: שהוקלטו (5.160 / 5.040 / 3.768 / 5.352 / 3.984), וה-`validate`
#: מודד אותם שוב מול הדיסק. שורה שהוצהרה קצרה מההקלטה נחתכת
#: באמצע מילה בחיתוך, וזה נמדד ב-05/10.
SHOTS = (
    {"key": "p1_walk", "secs": 12.0, "camera": "wide",
     "cap": "בוקר בפארק · הנער והנערה בהליכה",
     "vis": ("A", "B"),
     "plan": {"A": [("stand", 1.2), ("walk", 10.8)],
              "B": [("stand", 1.4), ("walk", 10.6)]},
     "lines": (("B", 0.8, 5.160,
                "איזה יום יפה בפארק! תראה איך המזרקה עובדת."),
               ("A", 6.6, 5.040,
                "לגמרי. מתאים לי לשבת קצת ליד העץ.")),
     },
    {"key": "p2_chase", "secs": 18.0, "camera": "medium",
     "cap": "האופניים נמלטות · והמרדף מתחיל",
     "vis": ("A", "B", "C"),
     # ההכנה לתנועה (Anticipation) היא ה-`stand` באמצע: הדמות
     # **נעצרת ויורדת** לפני שהיא פורצת לריצה. `Move` בונה את
     # הכפיפה במעבר, ולכן אין צורך לכתוב אותה - וכתיבה שלה בנפרד
     # הייתה מתפצלת מהצעד הראשון.
     "plan": {"A": [("walk", 2.1), ("stand", 0.9), ("run", 15.0)],
              "B": [("walk", 2.3), ("stand", 0.9), ("run", 14.8)],
              "C": [("run", 18.0)]},
     "lines": (("C", 1.0, 3.768, "אוי לא! תפסו את האופניים!"),),
     },
    {"key": "p3_stop", "secs": 15.0, "camera": "wide",
     "cap": "הסבא עוצר את האופניים · והצעירים בולמים",
     "vis": ("A", "B", "C", "D"),
     "plan": {"A": [("run", 3.0), ("walk", 3.2), ("stand", 8.8)],
              "B": [("run", 3.4), ("walk", 3.0), ("stand", 8.6)],
              "C": [("run", 2.4), ("walk", 2.6), ("stand", 10.0)],
              "D": [("walk", 6.0), ("stand", 9.0)]},
     "lines": (("D", 5.6, 5.352, "לאט לאט, חברים! האופניים בטוחות אצלי."),),
     },
    {"key": "p4_wide", "secs": 15.0, "camera": "zoomout",
     "cap": "ארבעתם ליד הספסל והמזרקה",
     "vis": ("A", "B", "C", "D"),
     "plan": {k: [("stand", 15.0)] for k in SLOTS},
     "lines": (("A", 2.2, 3.984,
                "טוב, לפחות עשינו את אימון הריצה של היום!"),),
     },
)


# ========================================================= שחקני הפנים

def _sit(slot: str, line: str, shot_len: float, key: str):
    """מצב הדמות בשוט. `emotion.Situation` הוא מה שמייצר את משחק
    הפנים, והוא נבנה **לכל שוט בנפרד**: אותה דמות בשוט הפתיחה
    ובשוט המרדף היא אותה דמות במצב אחר."""
    from rig import emotion as E                         # noqa: PLC0415
    base = dict(shot_len=shot_len, line=line, hides="")
    if key == "p1_walk":
        if slot == "B":
            return E.Situation(knows="הבוקר יפה", wants="לשתף אותו",
                               feels="joy", looks_at="object",
                               change="הוא מסכים", knows_more=False,
                               want_strength=0.6, intensity=0.55, **base)
        return E.Situation(knows="הוא עייף מהבוקר", wants="לשבת בצל",
                           feels="joy", looks_at="partner",
                           change="היא מתלהבת", knows_more=False,
                           want_strength=0.5, intensity=0.45, **base)
    if key == "p2_chase":
        if slot == "C":
            return E.Situation(knows="הוא שחרר את האופניים",
                               wants="שמישהו יעצור אותן",
                               feels="fear", looks_at="object",
                               change="הן מתרחקות", knows_more=True,
                               want_strength=1.0, intensity=1.0, **base)
        return E.Situation(knows="משהו קורה מאחור", wants="להדביק אותן",
                           feels="surprise", looks_at="object",
                           change="הן מתרחקות", knows_more=False,
                           want_strength=1.0, intensity=0.92, **base)
    if key == "p3_stop":
        if slot == "D":
            return E.Situation(knows="הוא יעצור אותן ביד אחת",
                               wants="להרגיע את כולם",
                               feels="joy", looks_at="object",
                               change="הצעירים בולמים", knows_more=True,
                               want_strength=0.7, intensity=0.6, **base)
        return E.Situation(knows="מישהו עצר אותן", wants="לנשום",
                           feels="surprise", looks_at="partner",
                           change="הסבא תפס", knows_more=False,
                           want_strength=0.8, intensity=0.75, **base)
    return E.Situation(knows="הכול נגמר בטוב", wants="לצחוק על זה",
                       feels="joy", looks_at="partner",
                       change="כולם צוחקים", knows_more=False,
                       want_strength=0.5, intensity=0.5, **base)


#: זרע וקיזוז פאזה לכל מקום. ארבע דמויות עם אותו זרע הן ארבע
#: בבואות של אותה אנימציה - וזה נראה מיד.
SEEDS = {"A": 0.17, "B": 0.58, "C": 0.83, "D": 0.31}
PHASE = {"A": 0.0, "B": 0.37, "C": 0.69, "D": 0.14}


def _actor(slot: str, line, shot_len: float, key: str):
    win = () if line is None else ((round(line[1], 4),
                                    round(line[1] + line[2], 4)),)
    name = CAST[SLOTS.index(slot)]
    fn, _eye = SR._emotion_actor(
        _sit(slot, "" if line is None else line[3], shot_len, key),
        seed=SEEDS[slot], phase=PHASE[slot],
        speech=win, voice="" if line is None else CD.VOICES[name],
        body=True)
    return fn


def _wrap(fn, mv: LM.Move):
    """עוטף שחקן בתנועת מקום **ומעביר את תכונותיו**.

    ראה `chase._wrap`: עטיפה שמאבדת את `track` מפיקה סרטון שלם
    ואילם, ואף בדיקת פריים לא צועקת.
    """
    wrapped = mv.drive(fn)
    for attr in ("speech", "track", "voice", "eye", "sit"):
        if hasattr(fn, attr):
            setattr(wrapped, attr, getattr(fn, attr))
    return wrapped


# ============================================================== מצלמה

def _cam(camera: str, u: float, heights: dict) -> dict:
    """מצלמה לארבע דמויות.

    **המרחק נגזר מהרוחב שצריך לכסות ולא מהגובה**, וזה ההבדל מ-
    `chase._cam`: ארבע דמויות פרושות על 2.30 מטר ברוחב, והמצלמה
    שחושבה מהדמות הגבוהה בלבד חותכת את הדמויות שבקצוות.
    """
    tall = max(heights.values())
    mid = sum(heights.values()) / len(heights)
    span = max(LANE_X.values()) - min(LANE_X.values())
    # המרחק שמכסה את הפרישה בשדה ראייה נתון, ועוד שולי ביטחון.
    def fit(fov_deg: float, margin: float = 1.26) -> float:
        half = math.radians(fov_deg) * 0.5
        return (span * 0.5 * margin) / max(1e-6, math.tan(half))

    if camera == "wide":
        fov = 36.0
        return {"yaw": SR.lerp(-11, 8, u), "pitch": 4.0,
                "dist": max(tall * 2.6, fit(fov)), "tx": 0.0,
                "ty": mid * 0.60, "fov": fov}
    if camera == "medium":
        fov = 33.0
        return {"yaw": SR.lerp(20, 31, u), "pitch": 2.6,
                "dist": max(tall * 2.2, fit(fov, 1.10)), "tx": 0.0,
                "ty": mid * 0.66, "fov": fov}
    # zoomout: הפנורמה המסיימת. ה-fov נפתח וגם המרחק גדל, אחרת
    # פתיחת fov לבדה מעוותת פרספקטיבה במקום להרחיק.
    #
    # **הבסיס מחושב ב-fov ההתחלתי בשני הקצוות, ולא ב-fov של הפריים.**
    # הניסיון הראשון כתב `max(tall*2.4, fit(fov))`, וזו הייתה טעות
    # שנמדדה: כש-fov נפתח, `fit(fov)` **קטן**, ולכן ב-u=0 ניצח
    # האיבר `fit` (5.22) וב-u=1 ניצח `tall*2.4` (4.44) - והריחוק
    # בפועל היה פי 1.29 במקום פי 1.52 שהוזמן. מקסימום שמשתנה בין
    # שני קצות אותה תנועה אינו אותה תנועה.
    fov = SR.lerp(31.0, 44.0, SR.smooth(u))
    base = max(tall * 2.4, fit(31.0))
    return {"yaw": SR.lerp(6, -14, SR.smooth(u)), "pitch": 5.4,
            "dist": base * SR.lerp(1.0, 1.52, SR.smooth(u)),
            "tx": 0.0, "ty": mid * 0.62, "fov": fov}


# ============================================================== בימוי

class Shot4:
    """שוט של ארבע דמויות. מקביל ל-`showreel.Shot` אבל עם מילון
    שחקנים לפי מקום, ולא שני שדות `a`/`b`."""

    def __init__(self, key, secs, cap, camera, actors, moves, vis,
                 lines, t_abs):
        self.key = key
        self.secs = float(secs)
        self.cap = cap
        self.camera = camera
        self.actors = actors
        self.moves = moves
        self.vis = tuple(vis)
        self.lines = tuple(lines)
        self.t_abs = float(t_abs)

    def caption_at(self, t: float) -> str:
        """הכתובית בזמן t בשוט. שורת דיבור גוברת על כתובית הכותרת
        בחלון שלה ועוד רבע שנייה לכל צד, כדי שהעין תספיק."""
        for who, at, dur, txt in self.lines:
            if at - 0.15 <= t <= at + dur + 0.25:
                return txt
        return self.cap


def build_shots(heights: dict, fps: int = FPS) -> list[Shot4]:
    out: list[Shot4] = []
    t_abs = 0.0
    for s in SHOTS:
        secs = float(s["secs"])
        moves, actors = {}, {}
        for slot in SLOTS:
            if slot not in s["vis"]:
                continue
            name = CAST[SLOTS.index(slot)]
            sk = SR.pipeline.cast_skeleton(name)
            # `lane=0`: המקום הבסיסי נקבע ב-HTML (`LANE_X`), והבמה
            # **מוסיפה** אליו את ההיסט. ראה `chase.build_shots`.
            moves[slot] = LM.Move(sk, s["plan"][slot], fps=fps,
                                  treadmill=True, lane=0.0,
                                  phase0=PHASE[slot] + 0.55)
            ln = next((l for l in s["lines"] if l[0] == slot), None)
            actors[slot] = _wrap(_actor(slot, ln, secs, s["key"]),
                                 moves[slot])
        out.append(Shot4(s["key"], secs, s["cap"], s["camera"],
                         actors, moves, s["vis"], s["lines"], t_abs))
        t_abs += secs
    return out


# ============================================================= הבמה

#: שש ההחלפות שמכלילות את `rig/stage.html` ל-N מקומות. כל אחת
#: מאומתת ב-`stage_html` - החלפה שלא מצאה את המקור היא במה
#: שנשארה דו-דמותית בשקט, וזה בדיוק הכשל שאי אפשר לראות.
_PATCHES = (
    ("const SRC = {A: P.get('a') || 'a.glb', B: P.get('b') || 'b.glb'};",
     "const SLOTS = (P.get('slots') || 'A,B').split(',');\n"
     "const SRC = {};\n"
     "for (const k of SLOTS) SRC[k] = P.get('g' + k) || (k + '.glb');\n"
     "const XS = {}, YAWS = {};\n"
     "for (const k of SLOTS) {\n"
     "  XS[k] = +(P.get('x' + k) || 0);\n"
     "  YAWS[k] = +(P.get('r' + k) || 0);\n"
     "}"),
    ("for (const k of ['A', 'B'])", "for (const k of SLOTS)"),
    ("place('A', SRC.A, -0.52, 11);\nplace('B', SRC.B,  0.52, -11);",
     "for (const k of SLOTS) place(k, SRC[k], XS[k], YAWS[k]);"),
    ("if (++loaded === 2) ready();",
     "if (++loaded === SLOTS.length) ready();"),
    ("  const nA = pose(G.A, f.A || {});\n"
     "  const nB = pose(G.B, f.B || {});\n"
     "  const mA = morph(G.A, f.MA || {});\n"
     "  const mB = morph(G.B, f.MB || {});",
     "  const NP = {}, NM = {};\n"
     "  for (const k of SLOTS) {\n"
     "    NP[k] = pose(G[k], f[k] || {});\n"
     "    NM[k] = morph(G[k], f['M' + k] || {});\n"
     "  }\n"
     "  if (f.dn) dnFrame(f.dn);"),
    ("return JSON.stringify({A: nA, B: nB, MA: mA, MB: mB});",
     "return JSON.stringify({pose: NP, morph: NM});"),
)

#: שכבת-העל הדו-ממדית: סילוני המזרקה והאופניים המתגלגלים. ראה
#: ההכרעה בראש הקובץ - שניהם לעולם אינם מאחורי דמות בשוט שלהם.
_DN_JS = """
/* ---- TASK 18: שכבת האובייקטים הדינמיים (מזרקה + אופניים) ----
   קנבס דו-ממדי מעל ה-WebGL ומתחת לכתוביות. היחידות הן יחידות
   **פריים מנורמלות**, בדיוק אלה של `stage.park_disney.LAYOUT`,
   ולכן אין כאן המרת קואורדינטות שיכולה להתפצל מהציור הצרוב. */
const DNC = document.createElement('canvas');
DNC.id = 'dnLayer';
DNC.style.cssText = 'position:absolute;left:0;top:0;pointer-events:none;';
document.body.appendChild(DNC);
const DNX = DNC.getContext('2d');
function dnSize() {
  DNC.width = W; DNC.height = H;
  DNC.style.width = W + 'px'; DNC.style.height = H + 'px';
}
dnSize();

function dnWheel(x, y, r, spin) {
  DNX.strokeStyle = '#9aa4b0';
  DNX.lineWidth = Math.max(2, r * 0.17);
  DNX.beginPath(); DNX.arc(x, y, r, 0, 6.2832); DNX.stroke();
  DNX.strokeStyle = '#c0cad6';
  DNX.lineWidth = Math.max(1, r * 0.07);
  for (let i = 0; i < 8; i++) {
    const a = spin + i * Math.PI / 4;
    DNX.beginPath(); DNX.moveTo(x, y);
    DNX.lineTo(x + Math.cos(a) * r * 0.88, y + Math.sin(a) * r * 0.88);
    DNX.stroke();
  }
}

function dnFrame(d) {
  DNX.clearRect(0, 0, W, H);
  /* --- המים. ציור מהרחוק לקרוב, ולכן לפני האופניים. */
  for (const p of (d.jets || [])) {
    DNX.globalAlpha = p.a;
    DNX.fillStyle = '#d8f0fb';
    DNX.beginPath();
    DNX.arc(p.x * W, p.y * H, Math.max(1, p.r * H), 0, 6.2832);
    DNX.fill();
  }
  DNX.globalAlpha = 1;
  /* --- האופניים, רק כשהם בנסיעה. במנוחה הם הציור הצרוב
         שבשכבת הקרקע, וציור כפול היה שני זוגות אופניים. */
  const b = d.bike;
  if (b && !b.baked) {
    const R = b.r * H, X = b.x * W, Y = b.y * H - R;
    const cs = Math.cos(b.lean), sn = Math.sin(b.lean);
    const pt = (ox, oy) => [X + ox * cs - oy * sn, Y + ox * sn + oy * cs];
    const dxw = R * 1.45;
    const back = pt(-dxw * 0.5, 0), front = pt(dxw * 0.5, 0);
    dnWheel(back[0], back[1], R, b.spin);
    dnWheel(front[0], front[1], R, b.spin);
    const crank = pt(-dxw * 0.04, R * 0.10);
    const seat = pt(-dxw * 0.34, -R * 0.92);
    const bar = pt(dxw * 0.30, -R * 0.96);
    DNX.strokeStyle = '#c44840';
    DNX.lineWidth = Math.max(2, R * 0.14);
    for (const [p, q] of [[back, crank], [crank, seat], [seat, back],
                          [crank, bar], [seat, bar], [bar, front]]) {
      DNX.beginPath(); DNX.moveTo(p[0], p[1]); DNX.lineTo(q[0], q[1]);
      DNX.stroke();
    }
    DNX.strokeStyle = '#c0cad6';
    DNX.beginPath();
    DNX.moveTo(bar[0] - R * 0.34, bar[1] - R * 0.10);
    DNX.lineTo(bar[0] + R * 0.34, bar[1] - R * 0.18);
    DNX.stroke();
    DNX.fillStyle = '#2e2c30';
    DNX.beginPath();
    DNX.ellipse(seat[0], seat[1] - R * 0.03, R * 0.24, R * 0.11, 0, 0,
                6.2832);
    DNX.fill();
  }
}
window.__dnsize = dnSize;
"""


def stage_html() -> str:
    """במת N המקומות, **נוצרת מ-`rig/stage.html`** ולא עותק שלה.

    כל החלפה נבדקת שהיא מצאה את המקור. אם `stage.html` ישתנה
    והמקור ייעלם, זו עצירה רועשת כאן - ולא במה שנשארה
    דו-דמותית בלי שאף אחד שם לב.
    """
    src = (STUDIO / "rig" / "stage.html").read_text(encoding="utf-8")
    for old, new in _PATCHES:
        if old not in src:
            raise RuntimeError(
                "ההחלפה לא מצאה את המקור ב-stage.html; הבמה "
                f"תישאר דו-דמותית. חסר: {old[:60]!r}")
        src = src.replace(old, new)
    # שכבת האובייקטים נכנסת לפני סוף ה-script, אחרי שכל שאר
    # הפונקציות הוגדרו (`W`/`H` נדרשים לה).
    anchor = "window.__frame = (json) => {"
    if anchor not in src:
        raise RuntimeError("לא נמצאה נקודת העגינה של __frame")
    return src.replace(anchor, _DN_JS + "\n" + anchor, 1)


def _serve_dir(rig_dir: Path, env_dir: Path | None) -> Path:
    d = Path(tempfile.mkdtemp(prefix="disney_"))
    shutil.copytree(STUDIO / "lib", d / "lib")
    shutil.copytree(STUDIO / "utils", d / "utils")
    (d / "stage.html").write_text(stage_html(), encoding="utf-8")
    for slot, name in zip(SLOTS, CAST):
        shutil.copy2(rig_dir / f"{name}.glb", d / f"{slot}.glb")
    if env_dir and Path(env_dir).exists():
        shutil.copytree(Path(env_dir), d / "env")
    return d


# ============================================================== חוזה

def validate(shots: list[Shot4], fps: int = FPS) -> dict:
    """חוזה התזמון, התנועה והקול. נבדק **לפני** הרינדור."""
    out: dict = {}

    def chk(name, ok, detail):
        out[name] = {"pass": bool(ok), "detail": str(detail)}

    frames = [int(round(s.secs * fps)) for s in shots]
    want = int(round(TOTAL_SECONDS * fps))
    chk(f"סך הפריימים הוא בדיוק {want}", sum(frames) == want,
        f"{sum(frames)} ({frames})")
    chk(f"ולכן האורך {TOTAL_SECONDS:.1f} שניות",
        abs(sum(frames) / fps - TOTAL_SECONDS) < 1e-9,
        f"{sum(frames) / fps:.3f}")
    chk("מחזור הרוח מתחלק באורך הסרט",
        abs(TOTAL_SECONDS / PD.park.LOOP_SEC
            - round(TOTAL_SECONDS / PD.park.LOOP_SEC)) < 1e-9,
        f"{TOTAL_SECONDS} / {PD.park.LOOP_SEC}")

    # ארבע הדמויות מופיעות, וכולן יחד בשוט המסיים.
    seen = set()
    for s in shots:
        seen |= set(s.vis)
    chk("כל ארבע הדמויות מופיעות בסרט", seen == set(SLOTS),
        sorted(seen))
    chk("וארבעתן יחד בשוט המסיים",
        set(shots[-1].vis) == set(SLOTS), sorted(shots[-1].vis))

    # ההליכה והריצה: שתיהן קיימות, ולכל דמות נבנתה תנועת מקום.
    gaits = set()
    for s in SHOTS:
        for plan in s["plan"].values():
            gaits |= {g for g, _ in plan}
    chk("שלושת ההילוכים מופיעים (עמידה, הליכה, ריצה)",
        {"stand", "walk", "run"} <= gaits, sorted(gaits))
    miss = [f"{s.key}/{k}" for s in shots for k in s.vis
            if k not in s.moves]
    chk("לכל דמות נראית יש תנועת מקום", not miss, miss or "לכולן")

    # **אפס החלקת רגליים.** `Move` על מסילה נועץ את הרגל ביחס
    # לקרקע, והבדיקה היא ש-`oz` אפס מוחלט בכל נקודת דגימה: היסט
    # קדימה על מסילה פירושו שהדמות נסחפת מהפריים, וזה גם מה
    # שמסגיר שהרגליים מתנועעות בלי לנסוע.
    bad, slide = [], 0.0
    for s in shots:
        for k, mv in s.moves.items():
            for i in range(0, int(s.secs * fps), 7):
                o = mv.offset(i / fps)
                slide = max(slide, abs(o["oz"]))
                if abs(o["oz"]) > 1e-9:
                    bad.append(f"{s.key}/{k}@{i / fps:.2f}")
    chk("אפס החלקת רגליים (0.00 מ\"מ היסט על המסילה)", not bad,
        bad[:3] or f"היסט מרבי {slide * 1000:.2f} מ\"מ")

    # הרקע נסחף בכל שוט שבו יש הליכה או ריצה, ובכיוון אחד.
    pans = []
    for s, spec in zip(shots, SHOTS):
        mv = s.moves.get("A") or next(iter(s.moves.values()))
        pans.append(mv.pan_of(s.secs, PAN_SCALE) - mv.pan_of(0.0, PAN_SCALE))
    moving = [p for p, spec in zip(pans, SHOTS)
              if any(g in ("walk", "run")
                     for pl in spec["plan"].values() for g, _ in pl)]
    chk("הרקע נסחף בכל שוט שיש בו תנועה, ובכיוון אחד",
        all(p < -0.02 for p in moving),
        [round(p, 3) for p in pans])
    chk("ובשוט המרדף הסחיפה הגדולה ביותר",
        pans[1] == min(pans), [round(p, 3) for p in pans])

    # חמש שורות הדיאלוג: אורך ההקלטה האמיתי, ואין גלישה מהשוט.
    worst, spill, found = 0.0, [], 0
    for s in SHOTS:
        for who, at, dur, txt in s["lines"]:
            name = CAST[SLOTS.index(who)]
            tr = V.load(txt, CD.VOICES[name])
            if tr is None:
                continue
            found += 1
            worst = max(worst, abs(float(tr.seconds) - dur))
            if at + float(tr.seconds) > s["secs"] + 1e-6:
                spill.append(f"{who}@{s['key']}")
    chk("כל חמש שורות הדיאלוג הוקלטו", found == 5, f"{found}/5")
    chk("ואורך כל שורה הוא אורך ההקלטה בפועל", worst < 0.05,
        f"הפרש מרבי {worst:.3f}ש")
    chk("ואף שורה אינה גולשת מסוף השוט", not spill,
        spill or "הכול בפנים")

    # הקול שרד את עטיפת התנועה. ראה `_wrap`.
    tracks = sum(1 for s in shots for f in s.actors.values()
                 if getattr(f, "track", None) is not None)
    chk("וחמשת פסי הקול שרדו את עטיפת התנועה", tracks >= 5,
        f"{tracks} שחקנים נושאים הקלטה")

    # האופניים נוסעים בתוך השוט שבו הילד מגיח, ונעצרים אצל הסבא.
    t0, t1 = BIKE_ROLL
    chk("נסיעת האופניים מתחילה בשוט המרדף",
        shots[1].t_abs <= t0 < shots[1].t_abs + shots[1].secs,
        f"{t0}ש בשוט שמתחיל ב-{shots[1].t_abs}ש")
    chk("ונגמרת בשוט הבלימה",
        shots[2].t_abs <= t1 <= shots[2].t_abs + shots[2].secs,
        f"{t1}ש בשוט {shots[2].t_abs}-"
        f"{shots[2].t_abs + shots[2].secs}ש")
    # תגובת העלווה נופלת בתוך שוט המרדף ואחרי שהרץ יצא לדרך.
    chk("ותגובת העלווה בתוך שוט המרדף",
        shots[1].t_abs < TREE_PASS < shots[1].t_abs + shots[1].secs,
        f"{TREE_PASS}ש")

    # המצלמה: הפנורמה המסיימת **מתרחקת**.
    hs = {k: 1.85 for k in SLOTS}
    c0 = _cam("zoomout", 0.0, hs)
    c1 = _cam("zoomout", 1.0, hs)
    chk("הפנורמה המסיימת מתרחקת ופותחת שדה ראייה",
        c1["dist"] > c0["dist"] * 1.3 and c1["fov"] > c0["fov"] + 8,
        f"מרחק {c0['dist']:.2f}->{c1['dist']:.2f} · "
        f"שדה {c0['fov']:.1f}->{c1['fov']:.1f}°")
    # וכל ארבע הדמויות נכנסות לפריים בשוט הרחב.
    span = max(LANE_X.values()) - min(LANE_X.values())
    cw = _cam("wide", 0.5, hs)
    half = math.radians(cw["fov"]) * 0.5
    cover = 2.0 * cw["dist"] * math.tan(half)
    chk("השוט הרחב מכסה את פרישת ארבע הדמויות",
        cover > span * 1.1, f"כיסוי {cover:.2f} מ' מול פרישה "
                            f"{span:.2f} מ'")
    return out


def contract(fps: int = FPS) -> dict:
    hs = {k: float(SR.pipeline.CAST[CAST[i]]["height"])
          for i, k in enumerate(SLOTS)}
    return validate(build_shots(hs, fps), fps)


# ============================================================== הפקה

async def produce(out_mp4: Path, rig_dir: Path = SR.RIG_DIR,
                  fps: int = FPS, width: int = 1920, height: int = 1080,
                  ss: int = 2, on_progress=None,
                  env_dir: Path = ENV_DIR, probe: bool = False) -> dict:
    """מרנדר את 60 השניות. לולאת פריימים משלו, ראה ההכרעה למעלה."""
    import engine                                       # noqa: PLC0415
    from production.script import sunbeam50 as SB       # noqa: PLC0415

    # 1 · הסביבה. חוזה הסביבה נסגר **לפני** הדפדפן.
    loc = dict(SB.LOCATION)
    loc["total_seconds"] = TOTAL_SECONDS
    man = PD.bake(env_dir, loc, width=width, height=height)
    bad = [k for k, v in PD.validate(man, env_dir, *BIKE_ROLL).items()
           if not v["pass"]]
    if bad:
        raise RuntimeError(f"חוזה הסביבה לא נסגר: {bad}")

    # 2 · הדמויות וחוזה התסריט
    rigs, skels, libs = {}, {}, {}
    for slot, name in zip(SLOTS, CAST):
        rigs[slot], skels[slot], libs[slot] = SR.load_char(name, rig_dir)
    heights = {k: float(rigs[k]["height_m"]) for k in SLOTS}
    shots = build_shots(heights, fps)
    rep_v = validate(shots, fps)
    bad = [k for k, v in rep_v.items() if not v["pass"]]
    if bad:
        raise RuntimeError(f"חוזה התסריט לא נסגר: {bad}")

    floors = {k: SR.rest_floor(skels[k]) for k in SLOTS}

    # 3 · הבמה
    root = _serve_dir(rig_dir, env_dir)
    srv, port = SR._serve(root)
    br = engine.Browser(width, height)
    t0 = time.time()
    enc = None
    frames_done = 0
    info = {}
    try:
        await br.start()
        q = "&".join([f"w={width}", f"h={height}", f"ss={ss}",
                      "slots=" + ",".join(SLOTS)]
                     + [f"g{k}={k}.glb" for k in SLOTS]
                     + [f"x{k}={LANE_X[k]}" for k in SLOTS]
                     + [f"r{k}={LANE_YAW[k]}" for k in SLOTS])
        await br.cmd("Page.navigate",
                     {"url": f"http://127.0.0.1:{port}/stage.html?{q}"})
        for _ in range(600):
            if await br.js("!!window.__ready"):
                break
            await asyncio.sleep(0.1)
        err = await br.js("window.__err ? window.__err() : 'הבמה לא נטענה'")
        if err:
            raise RuntimeError(f"הבמה החזירה שגיאה: {err}")
        info = json.loads(await br.js("JSON.stringify(window.__info||null)")
                          or "null") or {}
        for k in SLOTS:
            if not info.get(k) or info[k].get("bones", 0) < 1:
                raise RuntimeError(f"מקום {k} נטען בלי עצמות: {info.get(k)}")
            # GLB עם morph targets בלי `extras.targetNames` נטען בלי
            # תלונה והפנים נשארות ניטרליות. ראה `showreel.produce`.
            if len(info[k].get("shapes") or []) < len(SR.face.NAMES):
                raise RuntimeError(
                    f"מקום {k}: {len(info[k].get('shapes') or [])} צורות "
                    f"פנים מתוך {len(SR.face.NAMES)}")

        spec = json.dumps(json.dumps(dict(man, base="env/")))
        env_on = await br.js(
            f"window.__env ? window.__env(JSON.parse({spec})) : -1")
        if not isinstance(env_on, (int, float)) or env_on < 1:
            raise RuntimeError(
                f"שכבות הסביבה לא נטענו (הוחזר {env_on!r}). סצנת חוץ "
                "בלי רקע היא אולפן שחור, ולכן זו עצירה.")

        if not probe:
            enc = engine.Encoder(out_mp4, width, height, fps, crf=19)

        total = sum(int(round(s.secs * fps)) for s in shots)
        probes: list[Path] = []
        for shot in shots:
            n = int(round(shot.secs * fps))
            # SoftRig אחת לכל דמות **ולכל שוט**: מצב קפיץ שנשאר בין
            # חיתוכי מצלמה הוא קפיצה בפריים הראשון של השוט הבא.
            soft = {k: secondary.SoftRig(skels[k], 1.05)
                    for k in shot.vis}
            idx = ([n // 2] if probe else list(range(n)))
            for i in idx:
                t = i / fps
                u = i / max(1, n - 1)
                t_film = shot.t_abs + t

                f: dict = {"light": "sun_hard_left",
                           "cam": _cam(shot.camera, u, heights),
                           "cap": shot.caption_at(t),
                           "tag": "",
                           "fade": SR._fade_at(t, shot.secs),
                           "cap_o": SR._cap_opacity(t, shot.secs),
                           "vis": {k: (k in shot.vis) for k in SLOTS},
                           "mv": {}}

                for k in SLOTS:
                    if k not in shot.vis:
                        f[k] = {}
                        continue
                    # חוזה השחקן הוא זה של `showreel.produce`:
                    # נקרא **(u, t)** בסדר הזה, ומחזיר
                    # (בקרות, IK) או (בקרות, IK, צורות פנים).
                    # קריאה ב-(t, u) מחזירה אנימציה שרצה בקצב
                    # אורך השוט - כלומר נכונה רק בשוט של שנייה.
                    r = shot.actors[k](u, t)
                    morphs = (r[2] or {}) if len(r) > 2 else {}
                    pose_q = controls.evaluate(skels[k], r[0], r[1])
                    pose_q = soft[k].solve(dict(pose_q), 1.0 / fps)
                    f[k] = SR._jsonable(pose_q)
                    f["M" + k] = {kk: round(float(vv), 4)
                                  for kk, vv in morphs.items()}
                    f["mv"][k] = shot.moves[k].offset(t)

                # שכבת האובייקטים הדינמיים + תגובת העלווה
                gust = PD.gust_at(t_film, TREE_PASS)
                f["env"] = {"pan": round(
                    shot.moves[next(iter(shot.moves))].pan_of(
                        t, PAN_SCALE), 4),
                    "dap": 0.16 if shot.camera == "medium" else 0.10,
                    "t": t_film, "gust": round(gust, 4)}
                bk = PD.bike_at(t_film, *BIKE_ROLL)
                bk["r"] = PD.LAYOUT["bike"]["wheel_r"]
                f["dn"] = {"jets": PD.jets_at(t_film), "bike": bk}

                res = await br.js(
                    "window.__frame(" + json.dumps(json.dumps(f)) + ")")
                if res == "err":
                    raise RuntimeError(
                        await br.js("window.__err()") or "פריים נכשל")
                # `br.shot()` מחזיר JPEG, ו-`Encoder.add_jpeg` הוא
                # הדרך שבה כל הסרטונים בפרויקט נכתבו. המרה ל-PNG
                # כאן הייתה קידוד כפול פר פריים, 1800 פעמים.
                blob = await br.shot()
                if probe:
                    p = out_mp4.with_name(
                        f"{out_mp4.stem}_{shot.key}.jpg")
                    p.write_bytes(blob)
                    probes.append(p)
                else:
                    enc.add_jpeg(blob)
                frames_done += 1
                if on_progress and frames_done % 30 == 0:
                    on_progress(frames_done, total)
    finally:
        await br.close()
        srv.shutdown()
        if enc:
            enc.close()
        shutil.rmtree(root, ignore_errors=True)

    rep = {"mp4": str(out_mp4) if not probe else None,
           "seconds": TOTAL_SECONDS if not probe else None,
           "frames": frames_done,
           "render_sec": round(time.time() - t0, 1),
           "size_mb": (round(out_mp4.stat().st_size / 1e6, 2)
                       if out_mp4.exists() and not probe else None),
           "info": info,
           "probes": [str(p) for p in probes] if probe else [],
           "story": {"total_seconds": TOTAL_SECONDS,
                     "cast": {k: CAST[i] for i, k in enumerate(SLOTS)},
                     "roles": {k: CD.ROLE[CAST[i]]
                               for i, k in enumerate(SLOTS)},
                     "shots": [s["key"] for s in SHOTS],
                     "validate": rep_v}}

    # פס הקול. חמש השורות ממוקמות על ציר הזמן של הסרט כולו.
    if not probe and out_mp4.exists():
        cues = []
        for s, shot in zip(SHOTS, shots):
            for who, at, _dur, txt in s["lines"]:
                name = CAST[SLOTS.index(who)]
                tr = V.load(txt, CD.VOICES[name])
                if tr is not None:
                    cues.append((shot.t_abs + at, tr))
        if cues:
            rep["audio"] = _mux(out_mp4, cues, TOTAL_SECONDS)
    return rep


def _mux(mp4: Path, cues: list, seconds: float) -> dict:
    """מרכיב את פס הקול ומחליף את הווידאו בגרסה עם קול.

    עובר דרך `voice.mix`, `voice.write_wav` ו-`voice.mux` - אותו
    מסלול בדיוק שכל הסרטונים הקודמים בפרויקט עברו בו.

    **סדר הארגומנטים נמדד ולא הונח:** `write_wav(data, path)`
    ולא `(path, data)`. הניסיון הראשון כאן כתב הפוך, הרינדור של
    1800 פריימים הסתיים בהצלחה, והשלב האחרון קרס - כלומר 15 דקות
    רנדור שהסתיימו בלי קול. לכן גם העטיפה למטה היא `try`: סרטון
    בלי קול עדיף על רנדור שאבד.
    """
    try:
        wav = mp4.with_suffix(".wav")
        V.write_wav(V.mix(cues, seconds), wav)
        tmp = mp4.with_name(mp4.stem + "_snd.mp4")
        V.mux(mp4, wav, tmp)
        tmp.replace(mp4)
        return {"wav": str(wav), "muxed": True, "lines": len(cues),
                "size_mb": round(mp4.stat().st_size / 1048576, 2)}
    except Exception as exc:                            # noqa: BLE001
        return {"muxed": False, "lines": len(cues),
                "why": f"{type(exc).__name__}: {exc}"}


def main(argv=None) -> int:
    import argparse                                      # noqa: PLC0415
    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(
        description="הפארק הדינמי - 60 שניות (TASK 18)")
    ap.add_argument("--out", default="")
    ap.add_argument("--fps", type=int, default=FPS)
    ap.add_argument("--width", type=int, default=1920)
    ap.add_argument("--height", type=int, default=1080)
    ap.add_argument("--ss", type=int, default=2)
    ap.add_argument("--probe", action="store_true")
    ap.add_argument("--contract", action="store_true")
    ap.add_argument("--stage", action="store_true",
                    help="רק לבדוק שהבמה מוכללת")
    a = ap.parse_args(argv)

    if a.stage:
        h = stage_html()
        print(f"✅ הבמה הוכללה · {len(h)} תווים · "
              f"{h.count('SLOTS')} שימושים ב-SLOTS")
        return 0

    if a.contract:
        rep = contract(a.fps)
        bad = 0
        for k, v in rep.items():
            print(("✅" if v["pass"] else "❌"), k, "-", v["detail"])
            bad += 0 if v["pass"] else 1
        print(f"\n{len(rep) - bad}/{len(rep)} עברו")
        return 0 if bad == 0 else 1

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    out = Path(a.out) if a.out else OUT_DIR / "park_disney60.mp4"

    def prog(i, t):
        print(f"  פריים {i}/{t}", flush=True)

    rep = asyncio.run(produce(out, fps=a.fps, width=a.width,
                              height=a.height, ss=a.ss,
                              on_progress=prog, probe=a.probe))
    out.with_suffix(".json").write_text(
        json.dumps(rep, ensure_ascii=False, indent=1, default=str),
        encoding="utf-8")
    for k, v in rep["story"]["validate"].items():
        print(("✅" if v["pass"] else "❌"), k, "-", v["detail"])
    if rep.get("mp4"):
        print(f"\n{rep['seconds']}ש · {rep['size_mb']}MB · "
              f"רנדור {rep['render_sec']}ש\n{rep['mp4']}")
    for p in rep.get("probes") or []:
        print("  תמונת בדיקה:", p)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
