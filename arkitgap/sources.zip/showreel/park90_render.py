# -*- coding: utf-8 -*-
"""TASK 23 (07/10) - הגשר של `park90`: העיטורים שלו, ולא לולאה משלו.

================================================================
מה הקובץ הזה היה, ומה הוא עכשיו (TASK 24)
================================================================

`showreel.park90` הוא **חוזה** של 90 שניות ושמונה דמויות, והוא
אומר את זה על עצמו במפורש: "`park90` אינו מרנדר דבר". המפיק
היחיד שהיה קיים הוא `showreel.disney_story`, והוא מקובע ל-60
שניות ולארבע דמויות. לכן נכתב כאן (TASK 23) גשר **ידני**: מיפוי
שמונת המקומות, מצלמה, תיקון הבמה ולולאת פריימים שלמה.

ב-TASK 24 כל מה שהיה גנרי בגשר הזה עבר ל-`showreel.bridge`, ומה
שנשאר כאן הוא **רק מה שייחודי לתסריט הזה**: מצב הדמות בכל
פעימה, עגלת המזון, החיה הרובוטית, והקבועים שלהן. הגשר הדינמי
מגלה את הקבצים האלה לבד (`park90` + `park90_render` כגשר צמוד),
ולכן אותו `bridge.produce` מרנדר גם את התסריט הזה וגם כל תסריט
חדש בלי שורת קוד נוספת.

**אין כאן גשר שני.** כל פונקציה למטה שאינה עיטור של התסריט היא
האצלה לגשר - וזה מכוון: שתי לולאות פריימים שמתפצלות בשקט הן
בדיוק הכשל שהתיקון הזה מונע. ההוכחה שההאצלה אינה משנה דבר היא
`showreel/fixtures/park90_golden.json`: הערכים שהגשר הידני
החזיר לפני ההכללה הוקפאו לקובץ, ו-`test_bridge` משווה אליהם.

================================================================
שלוש הכרעות שכל אחת הייתה באג בניסיון הראשון (TASK 23)
================================================================

1. **נתיב הדמות משתנה בזמן, והבמה הכירה רק נתיב קבוע.**
   ב-`stage.html` המקום הבסיסי נקבע פעם אחת ב-`place()`, וה-
   `mv` מוסיף לו היסט בצירי הדמות. אבל `park90.lane_at` מזיז את
   **הנתיב עצמו** (התפצלות לשתי תת-קבוצות, ואז התכנסות אל
   המרכז), וההיסט של `Move` הוא צעדי ההליכה - שני דברים שונים.
   דחיפת ההתפצלות לתוך `ox` הייתה מסובבת אותה ב-yaw של הדמות,
   כלומר קבוצה שנסוגה "שמאלה" הייתה נסוגה גם לאחור. לכן נוסף
   שדה `lx` (נתיב מוחלט) והחלפה שביעית ב-HTML - והיא יושבת
   עכשיו ב-`bridge.LANE_PATCH`, כי היא גנרית לכל תסריט.

2. **העגלה והחיה מצוירות בתלת-ממד ולא בשכבה הדו-ממדית.**
   `disney_story` מצייר את האופניים ב-canvas 2D ביחידות פריים
   מנורמלות, וזה נכון שם: המצלמה שלו כמעט נייחת. כאן השוט
   האחרון הוא **מצלמת קרן** שעולה 5.85 מ' ומטה 33 מעלות, ואובייקט
   דו-ממדי במסלול קבוע היה נשאר דבוק למסך בזמן שכל העולם זז
   מתחתיו. בתלת-ממד הפרספקטיבה, ההסתרה ההדדית והצל נכונים
   מעצמם.

3. **האופניים נשארות צרובות.** `PD.bake` צורב אופניים חונים
   בציור הקרקע, ו-`bike_at` מחליף אותן בציור חי רק בחלון
   הגלגול. ב-`park90` אין אופניים נמלטות, ולכן החלון נדחק
   מחוץ לרצף - והאופניים נשארות חונות בפארק, כפי שנצרבו.
"""
from __future__ import annotations

import asyncio
import json
import math
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
STUDIO = HERE.parent
if str(STUDIO) not in sys.path:
    sys.path.insert(0, str(STUDIO))

from rig import showreel as SR                            # noqa: E402
from showreel import bridge as BR                         # noqa: E402
from showreel import disney_story as DS                   # noqa: E402
from showreel import park90 as P90                        # noqa: E402

FPS = P90.FPS
TOTAL_SECONDS = P90.TOTAL_SECONDS
SLOTS = P90.SLOTS
CAST = P90.CAST

#: **שתי התכונות האלה נקראות על ידי הגשר, לא על ידי הקובץ הזה.**
#: `bridge.load("park90")` מאתר את המודול הזה כגשר צמוד וקורא
#: מכאן את הסביבה, את הפאן ואת שנייית הרוח - ולכן מספר שנכתב
#: כאן משפיע על הרינדור בפועל.
ENV_DIR = Path(r"D:\claude-bot\out\char3d\env\park90")
OUT_DIR = Path(r"D:\claude-bot\out\char3d\showreel")

#: סקאלת הפאן של הרקע ביחס להתקדמות הדמות. זהה ל-`disney_story`.
PAN_SCALE = 0.030

#: שנייה שבה הרוח עוברת בעץ התגובה. בתוך המערכה הראשונה, כך
#: שהעלווה מגיבה בשוט שבו רואים אותה.
TREE_PASS = 17.4

#: חלון גלגול האופניים - **מחוץ לרצף בכוונה**. ראה ההכרעה 3.
BIKE_PARKED = (1.0e6, 1.0e6 + 1.0)

#: העומק (z) של שני האובייקטים הדינמיים, במטרים. העגלה מאחורי
#: השביל כדי שהקבוצה תתחמק ממנה ולא תחדור אותה; החיה חוצה
#: מקדימה אל האחור, ולכן ה-z שלה מגיע מ-`pet_at`.
CART_Z = -1.08


# ================================================= הרכב של שמונה

#: זרע וקיזוז פאזה לכל מקום. שמונה דמויות עם אותו זרע הן שמונה
#: בבואות של אותה אנימציה, וזה נראה מיד בשוט רחב - שם כולן
#: בפריים בבת אחת. המספרים פרושים על [0,1) בלי שני ערכים
#: קרובים מ-0.09 זה לזה. (תסריט שאינו מצהיר אותם מקבל מהגשר
#: רצף יחס-זהב עם אותה תכונה בדיוק - ראה `bridge.spread_unit`.)
SEEDS = {"A": 0.17, "B": 0.58, "C": 0.83, "D": 0.31,
         "E": 0.46, "F": 0.72, "G": 0.05, "H": 0.94}
PHASE = {"A": 0.00, "B": 0.37, "C": 0.69, "D": 0.14,
         "E": 0.52, "F": 0.81, "G": 0.25, "H": 0.63}


def _sit(slot: str, beat: str, shot_len: float):
    """מצב הדמות בשוט, לפי הפעימה הדרמטית.

    `emotion.Situation` הוא מה שמייצר את משחק הפנים, והוא נבנה
    **לכל שוט בנפרד** - אותה דמות בטיול ובבריחת העגלה היא אותה
    דמות במצב אחר. שני הראשיים מקבלים מצב נפרד מהלהקה בכל
    פעימה שבה הם נושאי הסצנה, כי "believable character
    performance" פירושו שהגיבור אינו ניצב.

    **הגשר קורא לפונקציה הזו** (`bridge.Script.situation`), ולכן
    חתימתה היא חלק מחוזה: `(slot, beat, shot_len)` בדיוק. גשר
    שמצא פונקציה בחתימה אחרת דוחה אותה ונופל לגזירה לפי שם
    הפעימה - ראה מלכודת 1 שם.
    """
    from rig import emotion as E                         # noqa: PLC0415
    lead = slot in (P90.LEAD_M, P90.LEAD_F)
    base = dict(shot_len=shot_len, line="", hides="")

    if beat == "stroll":
        return E.Situation(
            knows="הבוקר בפארק נעים", wants="ליהנות מהטיול",
            feels="joy", looks_at="partner" if lead else "object",
            change="החברים צוחקים", knows_more=False,
            want_strength=0.55 if lead else 0.45,
            intensity=0.50 if lead else 0.40, **base)
    if beat == "chat":
        return E.Situation(
            knows="המזרקה עובדת מאחור", wants="לשתף את מי שלידו",
            feels="joy", looks_at="partner",
            change="כולם מאטים לדבר", knows_more=False,
            want_strength=0.60, intensity=0.55 if lead else 0.46,
            **base)
    if beat == "cart_loose":
        # הפעימה המפנה. **הראשיים יודעים יותר** (הם רואים את
        # העגלה קודם), והלהקה מופתעת - שתי דרגות ידיעה שונות
        # באותו רגע הן מה שהופך הפתעה קולקטיבית לסצנה.
        return E.Situation(
            knows="העגלה איבדה בלמים" if lead else "משהו קורה מאחור",
            wants="להזהיר את כולם" if lead else "להבין מה קרה",
            feels="surprise", looks_at="object",
            change="העגלה מתקרבת", knows_more=lead,
            want_strength=1.0, intensity=0.95 if lead else 0.86, **base)
    if beat == "split_dodge":
        return E.Situation(
            knows="החיה הרובוטית חוצה את השביל",
            wants="להתחמק ולא להתנגש",
            feels="fear", looks_at="object",
            change="הקבוצה נפרדת לשתיים", knows_more=False,
            want_strength=1.0, intensity=1.0 if not lead else 0.92,
            **base)
    if beat == "regroup":
        return E.Situation(
            knows="העגלה נעצרה בשלום", wants="לנשום ולמצוא את השאר",
            feels="surprise", looks_at="partner",
            change="כולם שלמים", knows_more=False,
            want_strength=0.70, intensity=0.62, **base)
    # embrace: שני הראשיים נושאים את הסיום, והלהקה פותחת להם מקום.
    if lead:
        return E.Situation(
            knows="הוא/היא בסדר", wants="להגיע אליו ולחבק",
            feels="joy", looks_at="partner",
            change="הם נפגשים במרכז", knows_more=True,
            want_strength=1.0, intensity=0.80, **base)
    return E.Situation(
        knows="השניים מתקרבים זה לזה", wants="לתת להם רגע",
        feels="joy", looks_at="partner",
        change="המרכז נפתח להם", knows_more=False,
        want_strength=0.40, intensity=0.38, **base)


# ================================== האובייקטים התלת-ממדיים (עיטור)

#: שני האובייקטים התלת-ממדיים. ראה ההכרעה 2. הגשר מזריק את
#: המקור הזה ל-`stage.html` (`STAGE_JS` למטה) ומזין אותו בכל
#: פריים מ-`frame_extra`.
_P90_JS = """
/* ---- TASK 23: עגלת המזון והחיה הרובוטית, בתלת-ממד ----
   נבנים פעם אחת לסצנה כולה (בנייה פר שוט הייתה מייצרת את אותה
   גאומטריה שש פעמים), ומוסתרים כשהם מחוץ לחלון שלהם. */
const P90 = {};
(function () {
  const cart = new THREE.Group();
  const wood = new THREE.MeshStandardMaterial(
    {color: 0x9a6a3c, roughness: 0.72, metalness: 0.04});
  const metal = new THREE.MeshStandardMaterial(
    {color: 0x6a7280, roughness: 0.42, metalness: 0.68});
  const cloth = new THREE.MeshStandardMaterial(
    {color: 0xc2453d, roughness: 0.86, metalness: 0.02});

  const body = new THREE.Mesh(new THREE.BoxGeometry(0.74, 0.44, 0.52), wood);
  body.position.y = 0.46; body.castShadow = true;
  cart.add(body);
  const lip = new THREE.Mesh(new THREE.BoxGeometry(0.80, 0.06, 0.58), wood);
  lip.position.y = 0.70; cart.add(lip);
  /* הסוכך: מישור משופע על שני תרנים. הוא מה שהופך קופסה
     לעגלת מזון, והוא גם מה שתופס אור מלמעלה בשוט הקרן. */
  const can = new THREE.Mesh(new THREE.BoxGeometry(0.92, 0.035, 0.66), cloth);
  can.position.set(0, 1.17, 0); can.rotation.z = 0.07;
  can.castShadow = true; cart.add(can);
  for (const sx of [-0.33, 0.33]) {
    const post = new THREE.Mesh(
      new THREE.CylinderGeometry(0.018, 0.018, 0.50, 8), metal);
    post.position.set(sx, 0.93, 0.26); cart.add(post);
  }
  /* הידית: שתי קורות אלכסוניות. בלעדיה אי אפשר לדעת שהעגלה
     נדחפת, ו"the cart halts" הופך לקופסה שעצרה. */
  for (const sz of [-0.20, 0.20]) {
    const h = new THREE.Mesh(
      new THREE.CylinderGeometry(0.016, 0.016, 0.46, 8), wood);
    h.position.set(-0.46, 0.60, sz); h.rotation.z = 1.05; cart.add(h);
  }
  const wheels = [];
  for (const sx of [-0.26, 0.26]) {
    for (const sz of [-0.27, 0.27]) {
      const w = new THREE.Mesh(
        new THREE.CylinderGeometry(0.105, 0.105, 0.05, 18), metal);
      w.rotation.x = Math.PI / 2;
      w.position.set(sx, 0.105, sz);
      w.castShadow = true;
      cart.add(w); wheels.push(w);
    }
  }
  cart.visible = false;
  scene.add(cart);

  /* --- החיה הרובוטית. גוף ביצה, שתי אוזני צלחת, עין אחת
         גדולה וזנב אנטנה. "stray robotic pet" - חמוד ולא מאיים,
         ולכן הפרופורציות הן של גור ולא של מכונה. */
  const pet = new THREE.Group();
  const shell = new THREE.MeshStandardMaterial(
    {color: 0xd8dde4, roughness: 0.34, metalness: 0.52});
  const accent = new THREE.MeshStandardMaterial(
    {color: 0x3fa9c8, roughness: 0.28, metalness: 0.30,
     emissive: 0x1d6f88, emissiveIntensity: 0.55});
  const torso = new THREE.Mesh(new THREE.SphereGeometry(0.135, 20, 14),
                               shell);
  torso.scale.set(1.0, 0.86, 1.22);
  torso.position.y = 0.155; torso.castShadow = true;
  pet.add(torso);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.098, 18, 14),
                              shell);
  head.position.set(0, 0.27, 0.10); head.castShadow = true;
  pet.add(head);
  const eye = new THREE.Mesh(new THREE.SphereGeometry(0.044, 14, 10),
                             accent);
  eye.position.set(0, 0.285, 0.185); pet.add(eye);
  for (const sx of [-0.062, 0.062]) {
    const ear = new THREE.Mesh(new THREE.ConeGeometry(0.040, 0.085, 12),
                               shell);
    ear.position.set(sx, 0.345, 0.075);
    ear.rotation.z = sx < 0 ? 0.26 : -0.26;
    pet.add(ear);
  }
  const tail = new THREE.Mesh(
    new THREE.CylinderGeometry(0.008, 0.013, 0.17, 8), shell);
  tail.position.set(0, 0.235, -0.135); tail.rotation.x = -0.72;
  pet.add(tail);
  const tip = new THREE.Mesh(new THREE.SphereGeometry(0.024, 12, 10),
                             accent);
  tip.position.set(0, 0.30, -0.20); pet.add(tip);
  for (const sx of [-0.075, 0.075]) {
    for (const sz of [-0.10, 0.10]) {
      const leg = new THREE.Mesh(
        new THREE.CylinderGeometry(0.019, 0.015, 0.11, 8), shell);
      leg.position.set(sx, 0.055, sz); pet.add(leg);
    }
  }
  pet.visible = false;
  scene.add(pet);

  P90.cart = cart; P90.wheels = wheels; P90.pet = pet;
  P90.petTail = tail; P90.petTip = tip;
})();

/* פריים אחד של שכבת האובייקטים. `d` מגיע מפייתון ביחידות
   **מטרים בעולם**, בדיוק אלה של `park90.cart_at` ו-`pet_at`,
   ולכן אין כאן המרת קואורדינטות שיכולה להתפצל מהשער. */
function p90Frame(d) {
  const c = d.cart;
  if (c) {
    P90.cart.visible = true;
    P90.cart.position.set(c.x, 0, c.z);
    /* הגלגלים מסתובבים לפי המרחק שנעבר. גלגל בקצב שאינו קצב
       הנסיעה הוא "החלקת גלגל", אותו פגם כמו החלקת רגליים. */
    for (const w of P90.wheels) w.rotation.y = c.wheel;
    /* נטייה קדימה בבלימה: `tilt` הוא התאוטה, והוא שלילי רק
       כשהעגלה בולמת. גוף שעוצר בלי להיטות עוצר כמו צילום. */
    P90.cart.rotation.z = c.tilt || 0;
  } else {
    P90.cart.visible = false;
  }
  const p = d.pet;
  if (p && p.active) {
    P90.pet.visible = true;
    P90.pet.position.set(p.x, p.hop, p.z);
    /* הפנייה: החיה מביטה לכיוון הריצה. חיה שנעה הצידה ומביטה
       קדימה נראית כנגררת. */
    P90.pet.rotation.y = p.yaw || 0;
    /* הזנב מתנופף - תנועה משנית (Overlapping Action), ולכן
       בפאזה מאחרת ביחס לניתור ולא בו-זמנית איתו. */
    P90.petTail.rotation.z = (p.wag || 0);
    P90.petTip.position.x = Math.sin(p.wag || 0) * 0.055;
  } else {
    P90.pet.visible = false;
  }
}

/* **החשיפה ל-`window` אינה נוחות - היא הכרח.** ה-script של
   `stage.html` הוא `type="module"`, ולכן כל `const` בו הוא
   module-scoped ואינו נראה מ-`Runtime.evaluate` של הדפדפן. בלי
   שתי השורות האלה בדיקת "העגלה נבנתה" הייתה מחזירה שקר על במה
   תקינה לגמרי - וזה בדיוק מה שקרה בניסיון הראשון. זו הסיבה
   שכל שאר נקודות הכניסה שם (`__frame`, `__info`, `__env`)
   נכתבות על `window` במפורש. */
window.P90 = P90;
window.p90Frame = p90Frame;
"""

#: --- חוזה העיטור כלפי הגשר. שלושת השמות האלה הם מה שהופך
#: את הקובץ הזה ל"גשר צמוד" במקום לגשר שלם: הגשר מזריק את
#: המקור, מאמת שהוא נבנה, ומזין אותו בכל פריים - והוא אינו
#: יודע דבר על עגלות ועל חיות.
STAGE_JS = _P90_JS
EXTRA_KEY = "p90"
EXTRA_READY_JS = (
    "(typeof window.p90Frame === 'function' && !!window.P90 "
    "&& !!window.P90.cart && !!window.P90.pet) ? 1 : 0")


# ================================================ האובייקטים בזמן

def cart_frame(t_film: float) -> dict:
    """מצב העגלה לבמה. נגזר כולו מ-`park90.cart_at`.

    `tilt` הוא **נטיית הבלימה**, והיא נמדדת מהפרש המהירות על
    פריים אחד ולא מעקומה נפרדת: גוף נוטה קדימה כשהוא מאט,
    ובדיוק בשיעור ההאטה.
    """
    c = P90.cart_at(t_film)
    nxt = P90.cart_at(t_film + 1.0 / FPS)
    accel = (nxt["v"] - c["v"]) * FPS
    return {"x": round(c["x"], 4), "z": CART_Z,
            "wheel": round(c["wheel"], 4),
            "tilt": round(max(-0.10, min(0.0, accel * 0.075)), 4),
            "v": round(c["v"], 4)}


def pet_frame(t_film: float) -> dict:
    """מצב החיה לבמה. נגזר כולו מ-`park90.pet_at`.

    `yaw` הוא כיוון הריצה בפועל (מהפרש המיקום), ולא זווית
    שנכתבה ביד - חיה שנעה הצידה ומביטה קדימה נראית כנגררת.
    """
    p = P90.pet_at(t_film)
    if not p["active"]:
        return {"active": False}
    nxt = P90.pet_at(t_film + 1.0 / FPS)
    dx, dz = nxt["x"] - p["x"], nxt["z"] - p["z"]
    yaw = math.atan2(dx, dz) if (abs(dx) + abs(dz)) > 1e-9 else 0.0
    return {"active": True, "x": round(p["x"], 4),
            "z": round(p["z"], 4), "hop": round(p["hop"], 4),
            "yaw": round(yaw, 4),
            # הנפנוף מאחר ב-0.11 שנייה ביחס לניתור: תנועה משנית
            # בפאזה מאחרת היא ההבדל בין חיה לבובה.
            "wag": round(0.55 * math.sin((t_film - 0.11) * 11.0), 4)}


def frame_extra(t_film: float) -> dict:
    """מטען שכבת האובייקטים בפריים אחד - מה שהגשר שולח לבמה."""
    return {"cart": cart_frame(t_film), "pet": pet_frame(t_film)}


# ======================================= הקול והתנוחה (TASK 25)

def voice_of(slot: str) -> str:
    """פרופיל הקול של המקום. **לא** `cast_disney.VOICES`.

    שם יש שני קולות עבריים בלבד לשמונה דמויות, כלומר ארבעה
    זוגות של תאומים זהים - הפגם היחיד כאן שאין שום תמונת
    בדיקה שיכולה לתפוס. `rig.vcast` פורש את שמונת הקולות על
    סולם של 84 עד 304 הרץ, והשער שם **מודד** את הגל ולא
    מסתפק בהצהרה.
    """
    from rig import vcast as VC                         # noqa: PLC0415
    return VC.CAST_VOICE.get(P90.SLOT_OF[slot], "")


def lane_yaw_at(slot: str, t_film: float) -> float:
    """זווית הדמות בזמן - פנייה לכיוון התזוזה בפועל."""
    return P90.lane_yaw_at(slot, t_film)


def body_over(slot: str, t_film: float) -> dict:
    """בקרות שגוברות על התנועה: תנוחת החיבוק."""
    return P90.body_over(slot, t_film)


# ================================== האצלה לגשר הדינמי (TASK 24)

_SC: BR.Script | None = None


def script() -> BR.Script:
    """התסריט המנורמל, פעם אחת לתהליך.

    הטעינה אינה בזמן הייבוא **בכוונה**: `bridge.load("park90")`
    מייבא את המודול הזה כגשר צמוד, וטעינה בזמן ייבוא הייתה
    ייבוא מחזורי.
    """
    global _SC
    if _SC is None:
        _SC = BR.load("park90")
    return _SC


def stage_html() -> str:
    """במת שמונה המקומות. ההרכבה עצמה ב-`bridge.stage_html`."""
    return BR.stage_html(script())


def build_shots(heights: dict, fps: int = FPS) -> list[DS.Shot4]:
    """ששת השוטים של `park90`, כאובייקטי שוט של המפיק."""
    return BR.build_shots(script(), heights, fps)


def mv_frame(shot, slot: str, t: float, t_film: float) -> dict:
    """היסט התנועה של דמות אחת בפריים, כולל הנתיב המוחלט."""
    return BR.mv_frame(script(), shot, slot, t, t_film)


def _span_at(t: float) -> float:
    """רוחב פרישת ההרכב ב-x בזמן `t`, במטרים."""
    return script().span_at(t)


def _cam(camera: str, u: float, heights: dict, t_film: float) -> dict:
    """מצלמה לשמונה דמויות, ושלושה סוגי שוט."""
    return BR.camera(script(), camera, u, heights, t_film)


async def produce(out_mp4: Path, rig_dir: Path = SR.RIG_DIR,
                  fps: int = FPS, width: int = 1920, height: int = 1080,
                  ss: int = 2, on_progress=None,
                  env_dir: Path = ENV_DIR, probe: bool = False,
                  probe_u: float = 0.5) -> dict:
    """מרנדר את 90 השניות עם שמונה הדמויות, דרך הגשר הדינמי.

    הדוח מועשר בשני שדות שהם **של התסריט הזה בלבד** - שמות
    המערכות ומרחק החיבוק - ולכן הם נוספים כאן ולא בגשר.
    """
    rep = await BR.produce(script(), out_mp4, rig_dir=rig_dir, fps=fps,
                           width=width, height=height, ss=ss,
                           on_progress=on_progress, env_dir=env_dir,
                           probe=probe, probe_u=probe_u)
    rep["story"]["acts"] = [a[0] for a in P90.ACTS]
    rep["story"]["embrace_cm"] = round(
        P90.leads_distance(P90.EMBRACE[1]) * 100, 1)
    return rep


def main(argv=None) -> int:
    import argparse                                      # noqa: PLC0415
    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(
        description="הפארק הגדול - 90 שניות, שמונה דמויות (TASK 23)")
    ap.add_argument("--out", default="")
    ap.add_argument("--fps", type=int, default=FPS)
    ap.add_argument("--width", type=int, default=1920)
    ap.add_argument("--height", type=int, default=1080)
    ap.add_argument("--ss", type=int, default=2)
    ap.add_argument("--probe", action="store_true")
    ap.add_argument("--probe-u", type=float, default=0.5,
                    help="איפה בתוך השוט לדגום בבדיקה (0..1)")
    ap.add_argument("--stage", action="store_true",
                    help="רק לבדוק שהבמה נבנתה (בלי דפדפן)")
    a = ap.parse_args(argv)

    if a.stage:
        h = stage_html()
        print(f"✅ הבמה נבנתה · {len(h)} תווים · "
              f"lx: {h.count('m.lx')} · p90Frame: {h.count('p90Frame')} · "
              f"עגלה: {h.count('P90.cart')} · חיה: {h.count('P90.pet')}")
        return 0

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    out = Path(a.out) if a.out else OUT_DIR / "park_disney90.mp4"

    def prog(i, t):
        print(f"  פריים {i}/{t}", flush=True)

    rep = asyncio.run(produce(out, fps=a.fps, width=a.width,
                              height=a.height, ss=a.ss,
                              on_progress=prog, probe=a.probe,
                              probe_u=a.probe_u))
    out.with_suffix(".json").write_text(
        json.dumps(rep, ensure_ascii=False, indent=1, default=str),
        encoding="utf-8")
    ok = sum(1 for v in rep["story"]["audit"].values() if v["pass"])
    print(f"\n{ok}/{len(rep['story']['audit'])} שערי עלילה עברו · "
          f"חיבוק {rep['story']['embrace_cm']} ס\"מ")
    if rep.get("mp4"):
        print(f"{rep['seconds']}ש · {rep['size_mb']}MB · "
              f"רנדור {rep['render_sec']}ש\n{rep['mp4']}")
    for p in rep.get("probes") or []:
        print("  תמונת בדיקה:", p)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
