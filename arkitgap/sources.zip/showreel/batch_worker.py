# -*- coding: utf-8 -*-
r"""העובד שרץ על רנר אפל של גיטהאב. **רק חישוב, בלי דפדפן.**

הוא נקרא מתוך ``animbatch.yml`` עם ``--shard i --total n`` וקורא את
``animbatch/payload.json``. כל עבודה היא ``{"task": ..., "script": ...,
"tuning": {...}}``, והוא מריץ אותה ומחזיר ציונים.

**למה בלי דפדפן.** נמדד 07/10 על הרנר עצמו: Chrome שם נתקע ולא החזיר
DOM, כי אין מושב גרפי ל-VM. לכן רינדור הפריימים לא יכול לרוץ שם, ומה
שכן - מסלול הפוזות ושיפוט המבקרים, שהם numpy טהור ומתפצלים לשוטים.

**ולמה ``--shard`` ולא תור.** אין כאן תהליך מתזמן: המטריצה של גיטהאב
היא המתזמן, וכל רנר לוקח את הרשימה שלו מתוך ``payload["shards"]``.
רנר שנופל אינו גורר את האחרים (``fail-fast: false``), ו-``cloudbatch``
אומר מה חסר ולא מניח שהחסר עבר.

הפלט: ``animbatch/result-shard<i>.json`` עם ``{"results": {מפתח: {...}}}``.
המבנה הזה הוא החוזה עם ``cloudbatch.merge_results``; אל תשטח אותו.
"""
from __future__ import annotations

import json
import os
import platform
import sys
import time
import traceback
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

PAYLOAD = ROOT / "animbatch" / "payload.json"


def hw() -> dict:
    """מה בעצם רץ כאן. נרשם בכל תוצאה, כי "הרנר ענה" אינו "הרנר האיץ"."""
    d = {"platform": platform.platform(), "machine": platform.machine(),
         "python": platform.python_version(),
         "runner": os.environ.get("RUNNER_OS", ""),
         "label": os.environ.get("BATCH_RUNNER", "")}
    try:
        import torch                                       # noqa: PLC0415
        d["torch"] = torch.__version__
        d["mps"] = bool(getattr(torch.backends, "mps", None)
                        and torch.backends.mps.is_available())
    except Exception as exc:                               # noqa: BLE001
        d["torch"] = f"אין: {exc}"
        d["mps"] = False
    return d


def measure_job(job: dict) -> dict:
    """מודד תסריט אחד תחת ידיות נתונות, בלי רינדור.

    הידיות מוחלות בתוך התהליך הזה בלבד (``tuning.apply``), והרנר
    הוא מכונה חד-פעמית - ולכן אין כאן דריסה של מצב של אף אחד.
    """
    from showreel import bridge as BR                      # noqa: PLC0415
    from showreel import cloudbatch as CB                  # noqa: PLC0415
    from showreel import deliver as DL                     # noqa: PLC0415
    from studio import tuning as TU                        # noqa: PLC0415

    key = CB.job_key(job)
    t0 = time.perf_counter()
    tun = dict(job.get("tuning") or {})
    if tun:
        TU.apply(tun, why=f"אצווה בענן: {key}")
    sc = BR.load(job["script"])
    v = DL.review(sc, sample_fps=int(job.get("sample_fps")
                                     or DL.SAMPLE_FPS))
    wk, wv = DL.worst_of(v)
    scores = {k: round(p.worst, 2) for k, p in v.items()}
    codes: dict[str, int] = {}
    for p in v.values():
        for dg in (p.diagnosis or []):
            c = dg.get("code") if isinstance(dg, dict) else getattr(
                dg, "code", "")
            if c:
                codes[c] = codes.get(c, 0) + 1
    return {"key": key, "script": job["script"], "tuning": tun,
            "worst_key": wk, "worst": round(wv.worst, 2),
            "mean": round(sum(scores.values()) / max(1, len(scores)), 2),
            "n_judged": len(scores), "gate": wv.gate,
            "codes": codes, "scores": scores,
            "seconds": round(time.perf_counter() - t0, 2), "hw": hw()}


TASKS = {"measure": measure_job}


def run_shard(payload: dict, shard: int, total: int) -> dict:
    """מריץ את העבודות של הרנר הזה. כשל בעבודה אינו מפיל את השאר."""
    jobs = payload.get("jobs") or []
    plan = payload.get("shards") or []
    from showreel import cloudbatch as CB                   # noqa: PLC0415
    by_key = {CB.job_key(j): j for j in jobs}
    if 1 <= shard <= len(plan):
        mine = [by_key[k] for k in plan[shard - 1] if k in by_key]
    else:                                 # מטריצה רחבה מהתכנון
        mine = []
    out: dict[str, dict] = {}
    for j in mine:
        k = CB.job_key(j)
        fn = TASKS.get(str(j.get("task", "measure")))
        if fn is None:
            out[k] = {"key": k, "error": f"משימה לא מוכרת: {j.get('task')}"}
            continue
        try:
            out[k] = fn(j)
        except Exception as exc:                           # noqa: BLE001
            out[k] = {"key": k, "error": f"{type(exc).__name__}: {exc}",
                      "trace": traceback.format_exc()[-1500:]}
    return {"shard": shard, "total": total, "results": out,
            "hw": hw(), "n": len(mine)}


def main(argv=None) -> int:
    import argparse                                        # noqa: PLC0415
    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(description="רנר אצווה של האנימציה")
    ap.add_argument("--shard", type=int, default=1)
    ap.add_argument("--total", type=int, default=1)
    ap.add_argument("--payload", default=str(PAYLOAD))
    ap.add_argument("--out", default="")
    a = ap.parse_args(argv)

    p = Path(a.payload)
    if not p.is_file():
        print(f"אין מטען: {p}")
        return 2
    pay = json.loads(p.read_text(encoding="utf-8"))
    rep = run_shard(pay, a.shard, a.total)
    out = Path(a.out) if a.out else (p.parent /
                                     f"result-shard{a.shard}.json")
    out.write_text(json.dumps(rep, ensure_ascii=False, indent=1,
                              default=str), encoding="utf-8")
    ok = sum(1 for r in rep["results"].values() if "error" not in r)
    print(f"רנר {a.shard}/{a.total}: {ok}/{rep['n']} עבודות · "
          f"mps={rep['hw'].get('mps')} · {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
