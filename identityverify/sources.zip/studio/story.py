# -*- coding: utf-8 -*-
"""ממד הסיפור · מועצת מבקרים אוטומטית, על הפריימים עצמם.

**מה היה חסר.** ``studio/critics.py`` כבר מכיל מבקר סיפור, והוא
טוב במה שהוא עושה: הוא קורא את התוכנית הסמלית של השוט — מה הדמות
יודעת, רוצה, מרגישה ומסתירה, איפה הוצהר המהפך, וכמה ביטים נדחסו
לשוט. הוא **אינו רואה אף פריים**, וזה כתוב שם במפורש. לכן ציון
הסיפור של הפרויקט נגזר עד עכשיו כולו מהצהרה: מי שימלא את שדות
המצב וייתן ``arc.turn`` סביר יקבל 100, גם אם האנימציה שיצאה
בפועל שטוחה, או מקוטעת, או שכל הביטים שלה נדחסו לשנייה אחת.

**מה נמדד כאן.** אותה מועצה, שכבה שנייה: שבעה מדדים שנגזרים
מ**עקומת המצב הרגשי הנמדדת מתוך פריימי האנימציה** (``master.
state_curve`` על ``Lane`` של הדמות — אותה עקומה בדיוק שמבקר המשחק
מקבל, ולא עקומה שהומצאה כאן). שלושת הדברים שהמשימה דורשת:

* **קשת נרטיבית** — האם המצב הרגשי באמת נוסע (``story.frames.
  range``) והאם הדמות מסיימת במקום אחר מזה שבו פתחה
  (``story.frames.arc``). דמות שחוזרת בדיוק לאפס לא עברה כלום.
* **עקביות קצב רגשי** — שלישי הסצנה (``story.frames.pacing``):
  אין שליש מת. ומרווחי הביטים (``story.frames.spacing``): קצב,
  לא גיבנת אחת ואחר כך שתיקה.
* **מעברי כוונה** — מספר קטעי המגמה המשמעותיים
  (``story.frames.beats``) בתוך תחום קריא, ושער רעש
  (``story.frames.legible``) שמונע מרעידות להיחשב ביטים. ועוד
  שניים: זמן נחיתה אחרי הביט האחרון (``story.frames.landing``),
  ובמפלס הסצנה — ששתי הדמויות אינן עקומה אחת
  (``story.scene.duet``).

**למה אין כאן אף מספר דקורטיבי.** כל מדד הוא ``critics.Measure``
עם ערך נמדד, סף כתוב ומדרון מוצהר (``ramp_up``/``ramp_down``/
``band``) — אותה מכונה של חמשת המבקרים, ולכן אותה שפה בדיוק
באבחון, בספר התיקונים ובראיות. "מועצה" כאן אינה דעה: היא ארבעה
עשר מדדים לדמות (שבעה סמליים ושבעה על הפריימים) ועוד אחד לסצנה,
וכולם נגזרים ממדידה.

הרצה::

    python -m studio.story            # המועצה, טקסט קריא
    python -m studio.story --json
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from studio import critics as C                              # noqa: E402

#: שתי הדמויות של הסצנה הראשית.
CAST = ("lucas", "maya")

# ------------------------------------------------------------ ספי הקבלה
# כל סף נקבע **אחרי** מדידה על הסצנה האמיתית, וכל אחד מהם רחוק
# מהערך הנמדד במרווח שאינו "בדיוק עובר": מדד שנקבע על גבול המדידה
# הוא מדד שמודד את עצמו.

RANGE_MIN = 0.15        #: טווח המצב הרגשי (יחידות העקומה). נמדד 1.14 / 0.37
ARC_SHIFT_MIN = 0.15    #: היסט פתיחה→סיום, בחלקי הטווח. נמדד 0.66 / 0.38
PACING_MIN = 0.45       #: השליש החלש חלקי הממוצע. נמדד 0.72 / 0.71
SPACING_CV_MAX = 0.75   #: פיזור מרווחי הביטים. נמדד 0.45 / 0.25
BEATS_BAND = (3, 10)    #: מעברי כוונה קריאים. נמדד 9 / 9
FLIP_MAX = 0.25         #: חלק החלפות הסימן בנגזרת. נמדד 0.09 / 0.13
LANDING_MIN = C.TAIL_MIN  #: שניות נחיתה אחרי הביט האחרון. נמדד 2.4 / 2.0
DUET_RHO_MAX = 0.85     #: שתי הדמויות אינן אותה עקומה. נמדד 0.47

#: קטע מגמה נחשב "ביט" רק אם הוא גם ארוך וגם משנה משהו. שני
#: התנאים יחד הם מה שמפריד ביט מרעידה.
BEAT_NET_MIN = 0.10     # שינוי נקי, בחלקי הטווח
BEAT_SEC_MIN = 0.35     # משך, בשניות

#: ספר התיקונים של המדדים החדשים, באותו מילון שבו יושבים כל
#: המבקרים. בלי זה ``Measure.to_dict`` היה מחזיר ``rerender``
#: לכולם, כלומר אבחון שאינו אומר מה לעשות.
REPAIRS = {
    "story.frames.range":    "widen_arc",
    "story.frames.arc":      "widen_arc",
    "story.frames.pacing":   "stage_beats",
    "story.frames.spacing":  "stage_beats",
    "story.frames.beats":    "stage_beats",
    "story.frames.legible":  "smooth_curves",
    "story.frames.landing":  "extend_tail",
    "story.scene.duet":      "break_symmetry",
}
C.REPAIR_FOR.update(REPAIRS)


# ---------------------------------------------------------- עזרי עקומה

def normalize(s: np.ndarray) -> tuple[np.ndarray, float]:
    """עקומה ב-0..1 והטווח המקורי שלה.

    הטווח מוחזר בנפרד ואינו נזרק: נרמול הוא מה שמאפשר להשוות
    *צורה*, והטווח הוא מה שמעיד אם בכלל קרה משהו. מדידה על
    עקומה מנורמלת בלבד נותנת 1.0 גם לרעש של אפסילון.
    """
    s = np.asarray(s, dtype=np.float64)
    if s.size == 0:
        return s, 0.0
    rng = float(s.max() - s.min())
    if rng <= 1e-12:
        return np.zeros_like(s), 0.0
    return (s - s.min()) / rng, rng


def beats_of(sn: np.ndarray, dt: float, net_min: float = BEAT_NET_MIN,
             sec_min: float = BEAT_SEC_MIN) -> list[dict]:
    """קטעי המגמה המשמעותיים בעקומה — "מעברי הכוונה".

    רצף של נגזרת בסימן אחד הוא מעבר אחד. רצף נספר רק אם הוא גם
    ארוך מ-``sec_min`` וגם מזיז את העקומה ביותר מ-``net_min``.
    """
    if sn.size < 3:
        return []
    d = np.diff(sn)
    sg = np.sign(d)
    out: list[dict] = []
    i = 0
    while i < sg.size:
        j = i
        while j + 1 < sg.size and sg[j + 1] == sg[i]:
            j += 1
        net = abs(float(sn[j + 1] - sn[i]))
        dur = (j + 1 - i) * dt
        if net >= net_min and dur >= sec_min and sg[i] != 0:
            out.append({"t0": round(i * dt, 3), "t1": round((j + 1) * dt, 3),
                        "net": round(net, 3), "dir": int(sg[i])})
        i = j + 1
    return out


# ------------------------------------------------- המדדים על הפריימים

def frame_measures(state: np.ndarray, dt: float,
                   seconds: float) -> list[C.Measure]:
    """שבעת המדדים שנגזרים מעקומת המצב הנמדדת."""
    sn, rng = normalize(state)
    n = sn.size
    ms: list[C.Measure] = []

    ms.append(C.M("story.frames.range", "טווח המצב הרגשי בפריימים", rng,
                  f">={RANGE_MIN}", rng >= RANGE_MIN,
                  C.ramp_up(rng, RANGE_MIN * 0.4, RANGE_MIN * 1.6), 2.0,
                  hint="האנימציה שטוחה — להרחיב את הקשת בפועל, "
                       "לא רק בתוכנית"))

    k = max(1, int(round(1.0 / max(dt, 1e-9))))
    shift = abs(float(sn[-k:].mean() - sn[:k].mean())) if n > 2 * k else 0.0
    ms.append(C.M("story.frames.arc", "היסט פתיחה→סיום", shift,
                  f">={ARC_SHIFT_MIN}", shift >= ARC_SHIFT_MIN,
                  C.ramp_up(shift, 0.0, ARC_SHIFT_MIN * 1.6), 2.0,
                  hint="הדמות מסיימת בדיוק מאיפה שהתחילה — אין מעבר"))

    d = np.abs(np.diff(sn))
    if d.size >= 6:
        th = [float(d[i * d.size // 3:(i + 1) * d.size // 3].mean())
              for i in range(3)]
        mean = sum(th) / 3.0
        ratio = min(th) / max(mean, 1e-9)
    else:
        th, ratio = [0.0, 0.0, 0.0], 0.0
    ms.append(C.M("story.frames.pacing", "השליש החלש ביחס לממוצע", ratio,
                  f">={PACING_MIN}", ratio >= PACING_MIN,
                  C.ramp_up(ratio, PACING_MIN * 0.5, PACING_MIN * 1.3), 1.5,
                  hint="יש שליש מת בסצנה — לפזר את הביטים"))

    bts = beats_of(sn, dt)
    cnt = len(bts)
    ms.append(C.M("story.frames.beats", "מעברי כוונה משמעותיים", cnt,
                  f"{BEATS_BAND[0]}–{BEATS_BAND[1]}",
                  BEATS_BAND[0] <= cnt <= BEATS_BAND[1],
                  C.band(float(cnt), *BEATS_BAND, soft=3.0), 1.5,
                  hint="או אין מעברים בכלל, או שהם רבים מדי להיקרא"))

    on = [b["t0"] for b in bts]
    if len(on) > 2:
        iv = np.diff(np.asarray(on, dtype=np.float64))
        cv = float(iv.std() / max(iv.mean(), 1e-9))
    else:
        cv = 9.9
    ms.append(C.M("story.frames.spacing", "פיזור מרווחי הביטים", cv,
                  f"<={SPACING_CV_MAX}", cv <= SPACING_CV_MAX,
                  C.ramp_down(cv, SPACING_CV_MAX * 0.6, SPACING_CV_MAX * 1.4),
                  1.0, hint="הביטים מגיעים בצרורות — לפזר אותם בזמן"))

    dd = np.diff(sn)
    flips = float(np.mean(np.diff(np.sign(dd)) != 0)) if dd.size > 2 else 1.0
    ms.append(C.M("story.frames.legible", "החלפות כיוון בנגזרת", flips,
                  f"<={FLIP_MAX}", flips <= FLIP_MAX,
                  C.ramp_down(flips, FLIP_MAX * 0.6, FLIP_MAX * 1.6), 1.0,
                  hint="העקומה רועדת — רעידה אינה ביט"))

    tail = (seconds - bts[-1]["t1"]) if bts else 0.0
    ms.append(C.M("story.frames.landing", "שניות נחיתה אחרי הביט האחרון",
                  tail, f">={LANDING_MIN}ש", tail >= LANDING_MIN,
                  C.ramp_up(tail, 0.0, LANDING_MIN * 1.5), 1.5,
                  hint="הסצנה נחתכת על הביט — להאריך את הזנב"))

    return ms


def duet_measure(a: np.ndarray, b: np.ndarray) -> C.Measure:
    """מדד הסצנה: שתי הדמויות אינן אותה עקומה.

    שתי עקומות זהות פירושן שאין כאן דו-שיח אלא הד. המדד הוא על
    המתאם המוחלט, כי גם היפוך מושלם הוא תלות מושלמת.
    """
    n = min(a.size, b.size)
    if n < 4:
        return C.M("story.scene.duet", "מתאם בין הדמויות", 1.0,
                   f"<={DUET_RHO_MAX}", False, 0.0, 1.5,
                   hint="אין שתי עקומות להשוות")
    sa, _ = normalize(a[:n])
    sb, _ = normalize(b[:n])
    if sa.std() < 1e-9 or sb.std() < 1e-9:
        rho = 1.0
    else:
        rho = abs(float(np.corrcoef(sa, sb)[0, 1]))
    return C.M("story.scene.duet", "מתאם בין הדמויות", rho,
               f"<={DUET_RHO_MAX}", rho <= DUET_RHO_MAX,
               C.ramp_down(rho, DUET_RHO_MAX * 0.85, 1.0), 1.5,
               hint="שתי הדמויות מבצעות אותה עקומה — להפריד כוונות")


# ------------------------------------------------------------- המועצה

def curves(cast=CAST, variant: str = "full", fps: int = 30) -> dict:
    """עקומת המצב הנמדדת לכל דמות, מתוך פריימי האנימציה.

    ``master`` הוא הגורם היחיד שיודע לבנות את המסלול ולנתק ממנו
    את השמע, ולכן הוא זה שעושה את זה גם כאן. שכפול הלוגיקה היה
    יוצר עקומה שנייה שאינה זו שהמבקרים רואים.
    """
    from studio import master as MA

    out: dict[str, dict] = {}
    with MA.scene_timing():
        for who in cast:
            ln = MA._lane_of(MA._track(who, variant, fps))
            out[who] = {"state": MA.state_curve(ln), "dt": ln.dt,
                        "seconds": float(ln.times[-1])}
    return out


def shot_verdict(who: str, variant: str = "full", fps: int = 30) -> C.Verdict:
    """מבקר הסיפור הסמלי הקיים, בלי שינוי, על אותה דמות."""
    from studio import master as MA

    with MA.scene_timing():
        ev = MA._evidence(who, variant, fps, None)
    return C.review_one("story", ev)


def council(cast=CAST, variant: str = "full", fps: int = 30) -> dict:
    """המועצה כולה: סמלי + פריימים לכל דמות, ועוד מדד סצנה.

    מחזיר גם ``metrics`` — זוגות ``(שם, איכות 0..1)`` בצורה
    ש-``baseline.from_metrics`` מקבל, וגם ``checks`` בוליאני
    לקוראים שסופרים בדיקות. ציון אחד, שתי צורות דיווח, בלי
    חישוב שני.
    """
    from studio import master as MA

    cur = curves(cast, variant, fps)
    per: dict[str, dict] = {}
    ms_all: list[tuple[str, C.Measure]] = []
    with MA.scene_timing():
        for who in cast:
            ev = MA._evidence(who, variant, fps, None)
            sym = C.review_one("story", ev)
            fr = frame_measures(cur[who]["state"], cur[who]["dt"],
                                cur[who]["seconds"])
            sn, _ = normalize(cur[who]["state"])
            per[who] = {"symbolic": sym.to_dict(),
                        "frames": C._verdict("story", fr).to_dict(),
                        "beats": beats_of(sn, cur[who]["dt"])}
            for m in sym.measures:
                ms_all.append((who, C.Measure(**{k: v for k, v in m.items()
                                                 if k != "repair"})))
            for m in fr:
                ms_all.append((who, m))

    names = list(cast)
    duet = duet_measure(cur[names[0]]["state"], cur[names[1]]["state"]) \
        if len(names) >= 2 else None
    if duet is not None:
        ms_all.append(("scene", duet))

    wsum = sum(m.weight for _, m in ms_all) or 1.0
    score = round(100.0 * sum(m.weight * m.quality for _, m in ms_all) / wsum,
                  1)
    metrics = [(f"{who}/{m.code}", m.quality) for who, m in ms_all]
    checks = {f"{who}/{m.code}":
              {"value": m.value, "limit": m.limit, "pass": bool(m.ok)}
              for who, m in ms_all}
    failed = [k for k, v in checks.items() if not v["pass"]]
    return {"score": score, "passed": not failed, "metrics": metrics,
            "checks": checks, "failures": failed, "per_character": per,
            "scene": (duet.to_dict() if duet is not None else None),
            "cast": names, "seconds": cur[names[0]]["seconds"]}


def text(d: dict) -> str:
    L = [f"מועצת הסיפור · ציון {d['score']:.1f} · "
         f"{len(d['checks']) - len(d['failures'])}/{len(d['checks'])} מדדים"]
    for who in d["cast"]:
        p = d["per_character"][who]
        L.append(f"  {who}: סמלי {p['symbolic']['score']:.1f} · "
                 f"פריימים {p['frames']['score']:.1f} · "
                 f"{len(p['beats'])} מעברי כוונה")
        for m in p["frames"]["measures"]:
            L.append(f"      {'✓' if m['ok'] else '✗'} {m['code']:<22}"
                     f" {m['label']} = {m['value']} (דרוש {m['limit']})")
    if d["scene"]:
        s = d["scene"]
        L.append(f"  סצנה: {'✓' if s['ok'] else '✗'} {s['code']} = "
                 f"{s['value']} (דרוש {s['limit']})")
    if d["failures"]:
        L.append("  נפלו: " + ", ".join(d["failures"]))
    return "\n".join(L)


def main(argv=None) -> int:
    import argparse

    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(description="מועצת הסיפור על הפריימים")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args(argv)
    d = council()
    if a.json:
        print(json.dumps(d, ensure_ascii=False, indent=2, default=str))
    else:
        print(text(d))
    return 0 if d["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
