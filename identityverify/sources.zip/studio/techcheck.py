# -*- coding: utf-8 -*-
"""הממד הטכני · בדיקת צינור רינדור קלילה, בלי דפדפן ובלי GPU.

**מה הבעיה שהמודול הזה פותר.** הממד ``technical`` בשער האיכות
(``studio/mission.py``) היה היחיד מתוך שלושה-עשר שהחזיר "לא נמדד"
בכל הרצה, וזו הסיבה שהפסק נשאר ``FAIL`` גם כששנים-עשר הממדים
האחרים נמדדו. הסיבה לא הייתה באיכות אלא בשרשרת האספקה של המדידה:
המקור היחיד שלו היה ``studio/qa.py``, ש-``inspect`` שלו דורש
**קובץ סרטון מרונדר**. סרטון כזה נולד רק מהמנוע האמיתי — דפדפן,
WebGL, 1920x1080, דקות של עבודה ו-15MB לדמות — ולכן בכל הרצה
שאינה הפקה מלאה פשוט לא היה מה למדוד. ממד P0 שאינו נמדד הוא ממד
שאינו שומר על כלום.

**מה נמדד כאן במקום.** לא דעה על הצינור, ולא דגל "דילגנו". המודול
מרנדר באמת: בונה פריימים בנומפיי, **מקודד אותם ל-H.264 בקובץ
mp4 אמיתי** דרך PyAV, ואז **פותח את הקובץ ומפענח אותו בחזרה**
ומשווה. שלוש משפחות הבדיקות שהמשימה דורשת:

* **שלמות פריימים** — כל פריים שנכנס יוצא, אף אחד אינו ריק, אף
  פענוח אינו זורק, חותמות הזמן עולות ומרווחות שווה.
* **התאמת רזולוציה** — מה שיצא מהמקודד הוא מה שהוצהר, כולל פורמט
  פיקסלים ויחס צלעות, וגם הקובץ המסופק בפועל (אם קיים) נבדק מול
  תקן ההפקה דרך הכותרת בלבד.
* **יציבות קידוד** — אין מנה באורך אפס, פיזור גודל המנות אינו
  פרוע, יש פריים מפתח, ונאמנות ההארה בסבב הלוך-חזור בתוך סף.

**למה זה אינו "מוק".** מוק היה מחזיר מספר. כאן אין שום מספר
שאינו נמדד על בתים שעברו דרך מקודד: מי שיקלקל את ``remux``, את
בחירת הפורמט או את שרשרת ה-PyAV — הבדיקה הזו תיפול, גם בלי
דפדפן. ולהפך: היא **אינה** מתיימרת למדוד את *תוכן* ההפקה. את זה
מודדים ``qa.inspect`` על הסרטון האמיתי וחמשת המבקרים, והממד
הטכני לוקח את **המינימום** של שני המקורות (``mission.DIMS``) —
כך שבדיקה קלילה שעברה אינה מכסה על סרטון אמיתי שנפל.

הרצה::

    python -m studio.techcheck            # הבדיקה, טקסט קריא
    python -m studio.techcheck --json
"""
from __future__ import annotations

import json
import math
import sys
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

#: תקן ההפקה, כפי שהוא בפועל בכל הסרטונים שבתיקיית הפלט.
PROD_W, PROD_H, PROD_FPS = 1920, 1080, 30

#: גודל הבדיקה. אותו יחס צלעות בדיוק (16:9) ושליש מהצלע, כדי
#: שהבדיקה תיגמר בשבריר שנייה ולא תיגע בזיכרון. **לא** 1920x1080:
#: מכונה חנוקה בזיכרון אינה צריכה לקודד 60 פריימים של HD כדי
#: לבדוק שהמקודד שומר על רזולוציה.
W, H, FPS, N = 640, 360, 30, 60

#: איפה נשמר קובץ הבדיקה. נכתב מחדש בכל הרצה, ולכן אינו נערם.
OUT = ROOT / "production" / "techcheck"

#: ספי הקבלה. כל אחד מהם נימוק ולא טעם.
MAX_LUMA_ERR = 0.045      # שגיאת הארה ממוצעת בסבב הלוך-חזור (0..1)
MIN_FRAME_STD = 0.02      # פריים שטוח מזה נחשב ריק
MIN_MOTION = 0.004        # תנועה שהוזרקה וחייבת להימדד בפלט
MAX_SIZE_CV = 1.20        # פיזור יחסי של גודל המנות (ללא מפתח)
MAX_DUR_ERR = 0.08        # הפרש משך מוצהר/נמדד, בשניות
MAX_PTS_JITTER = 0.25     # סטיית מרווח חותמות הזמן, ביחידות פריים


# --------------------------------------------------------- בניית פריימים

def synth_frames(n: int = N, w: int = W, h: int = H) -> np.ndarray:
    """``n`` פריימים דטרמיניסטיים, עם תנועה אמיתית ובלי רעש גבוה.

    למה גרדיאנט ועיגול נע ולא רעש אקראי: המודול הזה בודק את
    **המקודד**, לא את עצמו. רעש לבן הוא תוכן שאבד בכוונה בכל
    מקודד עם אובדן, ובדיקת נאמנות עליו הייתה נופלת מסיבה שאינה
    תקלה. גרדיאנט חלק ועיגול נע הם בדיוק מה שאנימציה היא: שטחים
    רציפים שזזים.
    """
    ys, xs = np.mgrid[0:h, 0:w].astype(np.float32)
    gx, gy = xs / max(1, w - 1), ys / max(1, h - 1)
    out = np.empty((n, h, w, 3), dtype=np.uint8)
    for i in range(n):
        u = i / max(1, n - 1)
        # רקע: גרדיאנט אלכסוני שנע עם הזמן
        base = 0.25 + 0.45 * (0.5 * gx + 0.5 * gy) + 0.12 * np.sin(
            2 * math.pi * (u + 0.25 * gx))
        # "דמות": עיגול שנע על קו אופקי ומשנה בהירות
        cx = 0.18 + 0.64 * u
        cy = 0.50 + 0.18 * math.sin(2 * math.pi * u)
        r = 0.14
        d = np.sqrt(((gx - cx) * (w / h)) ** 2 + (gy - cy) ** 2)
        disc = np.clip(1.0 - d / r, 0.0, 1.0)
        img = np.clip(base * (1.0 - disc) + (0.95 - 0.35 * u) * disc,
                      0.0, 1.0)
        rgb = np.stack([img, img * (0.65 + 0.3 * u), 1.0 - 0.5 * img], -1)
        out[i] = np.clip(rgb * 255.0, 0, 255).astype(np.uint8)
    return out


def _luma(a: np.ndarray) -> np.ndarray:
    """הארה ב-0..1 מתוך מערך RGB uint8 (BT.601, כמו ההמרה במקודד)."""
    f = a.astype(np.float32) / 255.0
    return 0.299 * f[..., 0] + 0.587 * f[..., 1] + 0.114 * f[..., 2]


# ------------------------------------------------------------- קידוד

def encode(frames: np.ndarray, path: Path, fps: int = FPS,
           codec: str = "libx264") -> dict:
    """מקודד את הפריימים לקובץ mp4 אמיתי, ומחזיר מה שנמדד בדרך.

    גודל כל מנה נשמר, כי זה מה שהופך את "יציבות קידוד" למדידה
    ולא להצהרה: מקודד שמתפרץ על פריים אחד נראה כאן.
    """
    import av

    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        path.unlink()
    n, h, w = frames.shape[0], frames.shape[1], frames.shape[2]
    sizes: list[int] = []
    keys = 0
    with av.open(str(path), mode="w") as c:
        st = c.add_stream(codec, rate=fps)
        st.width, st.height = w, h
        st.pix_fmt = "yuv420p"
        try:
            st.options = {"crf": "18", "preset": "veryfast"}
        except Exception:                                # noqa: BLE001
            pass
        for i in range(n):
            vf = av.VideoFrame.from_ndarray(frames[i], format="rgb24")
            for pkt in st.encode(vf):
                sizes.append(int(pkt.size))
                keys += 1 if pkt.is_keyframe else 0
                c.mux(pkt)
        for pkt in st.encode():
            sizes.append(int(pkt.size))
            keys += 1 if pkt.is_keyframe else 0
            c.mux(pkt)
    return {"codec": codec, "w": w, "h": h, "fps": fps, "frames_in": n,
            "packets": len(sizes), "packet_sizes": sizes,
            "keyframes": keys,
            "bytes": path.stat().st_size if path.exists() else 0}


# ------------------------------------------------------------- פענוח

def decode(path: Path) -> dict:
    """פותח את הקובץ, מפענח הכול, ומחזיר מה שיצא בפועל.

    חריגה בפענוח אינה מפילה את הבדיקה — היא **נספרת**. קובץ שחלק
    ממנו פגום הוא בדיוק מה שהבדיקה הזו קיימת בשבילו.
    """
    import av

    lumas: list[np.ndarray] = []
    pts: list[float] = []
    errors = 0
    w = h = 0
    pix = ""
    declared = 0.0
    # **קובץ פגום אינו נפתח בכלל, ולא רק נופל באמצע הפענוח.** ב-mp4
    # טבלת המיקומים (``moov``) יושבת בסוף הקובץ, ולכן קובץ קטוע
    # מפיל את ``av.open`` עצמו. בלי התפיסה הזו המודול שקיים כדי
    # לזהות קבצים פגומים היה **זורק** עליהם במקום למדוד אותם —
    # נתפס בבדיקה השלילית ב-08/10.
    try:
        c = av.open(str(path))
    except Exception:                                    # noqa: BLE001
        return {"w": 0, "h": 0, "pix_fmt": "", "rate": 0.0,
                "frames_out": 0, "pts": [], "declared_sec": 0.0,
                "errors": 1, "luma": np.zeros((0, 1, 1), np.float32)}
    with c:
        st = c.streams.video[0]
        cc = st.codec_context
        w, h, pix = int(cc.width), int(cc.height), str(cc.pix_fmt)
        rate = float(st.average_rate or 0.0)
        tb = float(st.time_base or 0.0)
        if c.duration:
            declared = float(c.duration) / av.time_base
        try:
            for fr in c.decode(video=0):
                arr = fr.to_ndarray(format="rgb24")
                lumas.append(_luma(arr))
                t = fr.pts * tb if (fr.pts is not None and tb) else float(
                    len(pts)) / max(rate, 1e-9)
                pts.append(float(t))
        except Exception:                                # noqa: BLE001
            errors += 1
    L = np.asarray(lumas, dtype=np.float32) if lumas else np.zeros((0, 1, 1),
                                                                   np.float32)
    return {"w": w, "h": h, "pix_fmt": pix, "rate": rate,
            "frames_out": int(L.shape[0]), "pts": pts,
            "declared_sec": round(declared, 4), "errors": errors,
            "luma": L}


def header_of(path: Path) -> dict:
    """כותרת סרטון בלבד — בלי לפענח אף פריים.

    זה מה שמאפשר לבדוק את **הקובץ המסופק האמיתי** (90 שניות,
    1920x1080, עשרות MB) בעלות של אפס: רזולוציה, קצב, מספר
    פריימים ומשך יושבים בכותרת.
    """
    import av

    with av.open(str(path)) as c:
        st = c.streams.video[0]
        cc = st.codec_context
        return {"path": str(path), "w": int(cc.width), "h": int(cc.height),
                "pix_fmt": str(cc.pix_fmt),
                "fps": round(float(st.average_rate or 0.0), 3),
                "frames": int(st.frames or 0),
                "seconds": round(float(c.duration or 0) / av.time_base, 3),
                "mb": round(path.stat().st_size / 1e6, 2)}


# ------------------------------------------------------------- הבדיקה

def _chk(value, limit: str, ok: bool) -> dict:
    return {"value": value, "limit": limit, "pass": bool(ok)}


@dataclass
class Tech:
    """תוצאת הבדיקה הטכנית, בצורה שה-audit-ים כאן מחזירים."""

    checks: dict = field(default_factory=dict)
    detail: dict = field(default_factory=dict)

    @property
    def total(self) -> int:
        return len(self.checks)

    @property
    def passed(self) -> int:
        return sum(1 for v in self.checks.values() if v["pass"])

    @property
    def score(self) -> float:
        if not self.checks:
            return 0.0
        return round(100.0 * self.passed / self.total, 1)

    @property
    def ok(self) -> bool:
        return self.total > 0 and self.passed == self.total

    def failures(self) -> list[str]:
        return [k for k, v in self.checks.items() if not v["pass"]]

    def to_dict(self) -> dict:
        return {"checks": self.checks, "detail": self.detail,
                "score": self.score, "passed": self.ok}

    def text(self) -> str:
        L = [f"בדיקה טכנית · {self.passed}/{self.total} · "
             f"ציון {self.score:.1f}"]
        for k, v in self.checks.items():
            L.append(f"  {'✓' if v['pass'] else '✗'} {k:<34} "
                     f"{v['value']}  (דרוש {v['limit']})")
        return "\n".join(L)


def _delivered() -> Path | None:
    """הסרטון המסופק הגדול ביותר שקיים, או ``None``.

    נבחר הגדול כי הוא ההפקה ולא טיוטת בדיקה, והוא נקרא **רק**
    בכותרת. אין כאן פענוח.
    """
    cands: list[Path] = []
    for d in (ROOT / "out", ROOT / "production", ROOT / "showreel"):
        if d.is_dir():
            cands += [p for p in d.rglob("*.mp4") if p.stat().st_size > 2e5]
    if not cands:
        return None
    return max(cands, key=lambda p: p.stat().st_size)


def audit(frames: int = N, w: int = W, h: int = H, fps: int = FPS,
          path: Path | None = None, check_delivered: bool = True) -> Tech:
    """מרנדר, מקודד, מפענח, ומודד. זו כל הבדיקה הטכנית."""
    path = Path(path) if path else (OUT / "probe.mp4")
    src = synth_frames(frames, w, h)
    enc = encode(src, path, fps)
    dec = decode(path)

    ck: dict[str, dict] = {}
    # ---- שלמות פריימים
    ck["קובץ נוצר ואינו ריק"] = _chk(enc["bytes"], ">0", enc["bytes"] > 0)
    ck["כל הפריימים שנכנסו יצאו"] = _chk(
        f"{dec['frames_out']}/{frames}", "זהה", dec["frames_out"] == frames)
    ck["אין שגיאת פענוח"] = _chk(dec["errors"], "==0", dec["errors"] == 0)

    L = dec["luma"]
    stds = L.reshape(L.shape[0], -1).std(axis=1) if L.shape[0] else np.array([])
    ck["אין פריים ריק או שחור"] = _chk(
        round(float(stds.min()), 4) if stds.size else 0.0,
        f">={MIN_FRAME_STD}", bool(stds.size and stds.min() >= MIN_FRAME_STD))

    pts = np.asarray(dec["pts"], dtype=np.float64)
    rising = bool(pts.size > 1 and np.all(np.diff(pts) > 0))
    ck["חותמות זמן עולות"] = _chk(pts.size, "עולה ממש", rising)
    if pts.size > 2:
        d = np.diff(pts) * fps
        jit = float(np.abs(d - 1.0).max())
    else:
        jit = 9.9
    ck["מרווח הפריימים אחיד"] = _chk(round(jit, 4),
                                     f"<={MAX_PTS_JITTER} פריים",
                                     jit <= MAX_PTS_JITTER)
    exp_sec = frames / float(fps)
    derr = abs(dec["declared_sec"] - exp_sec)
    ck["משך הקובץ כמוצהר"] = _chk(
        f"{dec['declared_sec']}ש מול {round(exp_sec, 3)}ש",
        f"פער<={MAX_DUR_ERR}ש", derr <= MAX_DUR_ERR)

    # ---- התאמת רזולוציה
    ck["רזולוציה כמבוקש"] = _chk(f"{dec['w']}x{dec['h']}", f"{w}x{h}",
                                 dec["w"] == w and dec["h"] == h)
    ck["פורמט פיקסלים כמוצהר"] = _chk(dec["pix_fmt"], "yuv420p",
                                      dec["pix_fmt"] == "yuv420p")
    ar_src, ar_out = w / h, (dec["w"] / dec["h"] if dec["h"] else 0.0)
    ck["יחס צלעות נשמר"] = _chk(round(ar_out, 4), f"=={round(ar_src, 4)}",
                                abs(ar_out - ar_src) < 1e-3)
    ck["קצב פריימים כמוצהר"] = _chk(dec["rate"], f"=={fps}",
                                    abs(dec["rate"] - fps) < 0.01)
    ck["יחס הצלעות תואם תקן ההפקה"] = _chk(
        round(ar_src, 4), f"=={round(PROD_W / PROD_H, 4)}",
        abs(ar_src - PROD_W / PROD_H) < 1e-3)

    # ---- יציבות קידוד
    sizes = np.asarray(enc["packet_sizes"], dtype=np.float64)
    ck["אין מנה באורך אפס"] = _chk(
        int(sizes.size and (sizes <= 0).sum()), "==0",
        bool(sizes.size and (sizes > 0).all()))
    ck["יש פריים מפתח"] = _chk(enc["keyframes"], ">=1", enc["keyframes"] >= 1)
    body = sizes[1:] if sizes.size > 2 else sizes
    cv = float(body.std() / max(body.mean(), 1e-9)) if body.size else 9.9
    ck["פיזור גודל המנות יציב"] = _chk(round(cv, 3), f"<={MAX_SIZE_CV}",
                                       cv <= MAX_SIZE_CV)
    ck["מספר המנות כמספר הפריימים"] = _chk(
        f"{enc['packets']}/{frames}", "זהה", enc["packets"] == frames)

    # נאמנות ותנועה: האם מה שיצא הוא מה שנכנס, ולא תמונה קפואה
    if dec["frames_out"] == frames and frames:
        ref = _luma(src)
        err = float(np.abs(ref - L).mean())
        mo_src = float(np.abs(np.diff(ref, axis=0)).mean())
        mo_out = float(np.abs(np.diff(L, axis=0)).mean())
    else:
        err, mo_src, mo_out = 1.0, 0.0, 0.0
    ck["נאמנות הארה בסבב הלוך-חזור"] = _chk(round(err, 4),
                                            f"<={MAX_LUMA_ERR}",
                                            err <= MAX_LUMA_ERR)
    ck["התנועה שהוזרקה נמדדת בפלט"] = _chk(round(mo_out, 5),
                                           f">={MIN_MOTION}",
                                           mo_out >= MIN_MOTION)

    detail = {"file": str(path), "mb": round(enc["bytes"] / 1e6, 3),
              "codec": enc["codec"], "frames": frames,
              "size": f"{w}x{h}", "fps": fps,
              "luma_err": round(err, 4), "packet_cv": round(cv, 3),
              "motion_src": round(mo_src, 5), "motion_out": round(mo_out, 5),
              "keyframes": enc["keyframes"]}

    # ---- הקובץ המסופק האמיתי, בכותרת בלבד
    if check_delivered:
        try:
            dp = _delivered()
        except Exception:                                # noqa: BLE001
            dp = None
        if dp is not None:
            try:
                hd = header_of(dp)
                detail["delivered"] = hd
                ck["קובץ ההפקה ברזולוציית התקן"] = _chk(
                    f"{hd['w']}x{hd['h']}", f"{PROD_W}x{PROD_H}",
                    hd["w"] == PROD_W and hd["h"] == PROD_H)
                ck["קצב ההפקה כתקן"] = _chk(hd["fps"], f"=={PROD_FPS}",
                                            abs(hd["fps"] - PROD_FPS) < 0.05)
                ck["קובץ ההפקה אינו קטוע"] = _chk(
                    f"{hd['frames']} פריימים · {hd['seconds']}ש",
                    "פריימים>0 ומשך>0",
                    hd["frames"] > 0 and hd["seconds"] > 0)
            except Exception as exc:                     # noqa: BLE001
                detail["delivered_error"] = f"{type(exc).__name__}: {exc}"
    return Tech(ck, detail)


def main(argv=None) -> int:
    import argparse

    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(description="בדיקת צינור רינדור קלילה")
    ap.add_argument("--frames", type=int, default=N)
    ap.add_argument("--no-delivered", action="store_true",
                    help="בלי בדיקת הקובץ המסופק")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args(argv)
    t = audit(frames=a.frames, check_delivered=not a.no_delivered)
    if a.json:
        print(json.dumps(t.to_dict(), ensure_ascii=False, indent=2,
                         default=str))
    else:
        print(t.text())
    return 0 if t.ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
