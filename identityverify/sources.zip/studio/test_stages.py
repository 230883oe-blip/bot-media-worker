# -*- coding: utf-8 -*-
"""בדיקות לשלושת השלבים שנוספו: בסיס (1), מצלמה (9), תאורה (10).

**כל בדיקה כאן דו-כיוונית.** בדיקה שמוודאת רק שהמצב התקין עובר
אינה שומרת על כלום: היא תמשיך לעבור גם אחרי שמישהו ירכך את הסף
עד שהכול עובר. לכן לכל מדד יש גם מקרה שחייב **ליפול**.
"""
from __future__ import annotations

import copy
import json
import math
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

_ok = _bad = 0
_fails: list[str] = []


def check(name: str, cond: bool, extra: str = "") -> None:
    global _ok, _bad
    if cond:
        _ok += 1
        print(f"  ✓ {name}" + (f"   {extra}" if extra else ""))
    else:
        _bad += 1
        _fails.append(name)
        print(f"  ✗ {name}   {extra}")


# ======================================================= שלב 1 · בסיס

def t_baseline_scoring() -> None:
    from studio import baseline as B
    print("בסיס · גזירת ציון:")
    sc, ev = B.from_checks({"a": {"pass": True}, "b": {"pass": True},
                            "c": {"pass": False}}, "x/")
    check("ציון משיעור בדיקות שעברו", abs(sc - 66.7) < 0.1, f"{sc}")
    check("ראיה של בדיקה שנכשלה מסומנת",
          any(e.endswith("✗") for e in ev), str(ev))
    check("טבלה ריקה אינה מחזירה ציון מלא",
          B.from_checks({})[0] == 0.0)
    check("שדה בלי pass אינו נספר",
          B.from_checks({"a": {"value": 1}})[0] == 0.0)
    sc2, _ = B.from_metrics([("a", 1.0), ("b", 0.0)])
    check("ציון ממדדים רציפים הוא ממוצע", abs(sc2 - 50.0) < 0.01, f"{sc2}")
    check("None במדד מדולג ולא מאפס",
          B.from_metrics([("a", 1.0), ("b", None)])[0] == 100.0)
    check("NaN במדד מדולג",
          B.from_metrics([("a", 1.0), ("b", float("nan"))])[0] == 100.0)
    check("אין מדדים בכלל = 0 ולא חריגה",
          B.from_metrics([])[0] == 0.0)


def t_baseline_states() -> None:
    from studio import baseline as B
    print("בסיס · שלושת המצבים:")
    m = B.Score("k", "ל", 90.0, "measured", ["a", "b", "c", "d", "e"])
    u = B.Score("k", "ל", None, "unmeasured")
    x = B.Score("k", "ל", 0.0, "missing", note="אין מערכת")
    rep = B.Report("t", "now", [m, u, x])
    # ההוכחה הישירה ש'לא נמדד' אינו משתתף: הממוצע **זהה** עם
    # ובלי הרשומה שלו. השוואה לערך קבוע לא הייתה מוכיחה את זה,
    # כי אותו מספר יכול לצאת מכמה הרכבים שונים.
    check("'לא נמדד' אינו משנה את הממוצע כלל",
          rep.mean == B.Report("t", "now", [m, x]).mean,
          f"{rep.mean} מול {B.Report('t', 'now', [m, x]).mean}")
    check("ואילו 'אין מערכת' כן מוריד אותו",
          rep.mean < B.Report("t", "now", [m]).mean, f"{rep.mean}")
    check("'אין מערכת' כן נכנס לממוצע כאפס",
          rep.mean_flat == 45.0, f"{rep.mean_flat}")
    check("'לא נמדד' אינו נספר כנמדד", len(rep.measured) == 1)
    check("ו'אין מערכת' כן משתתף בממוצע", len(rep.scored) == 2)
    check("משקל של לא-נמדד הוא אפס", u.weight == 0.0)
    check("משקל גדל עם הראיות",
          B.Score("k", "ל", 1, "measured", ["a"]).weight
          < B.Score("k", "ל", 1, "measured", list("abcde")).weight)
    check("משקל חסום ב-1",
          B.Score("k", "ל", 1, "measured", list("abcdefghijk")).weight == 1.0)
    # ממוצע ריק אינו מפיל
    check("דוח בלי מדידות מחזיר 0 ולא חריגה",
          B.Report("t", "now", [u]).mean == 0.0)


def t_baseline_compare() -> None:
    from studio import baseline as B
    print("בסיס · השוואה מול בסיס:")
    base = B.Report("base", "now", [
        B.Score("a", "א", 90.0, "measured", list("abc")),
        B.Score("b", "ב", 80.0, "measured", list("abc")),
        B.Score("c", "ג", 70.0, "measured", list("abc"))])
    new = copy.deepcopy(base)
    new.tag = "new"
    cmp = B.compare(new, base)
    check("גרסה זהה אינה נסיגה", cmp["ok"] and not cmp["regressed"])
    check("דלתא אפס בגרסה זהה",
          all(r["delta"] == 0.0 for r in cmp["rows"]))
    # נסיגה אמיתית
    worse = copy.deepcopy(base)
    worse.by_key()["b"].value = 60.0
    c2 = B.compare(worse, base)
    check("נסיגה אמיתית נתפסת", c2["regressed"] == ["b"], str(c2["regressed"]))
    check("ונסיגה מסמנת ok=False", not c2["ok"])
    # שיפור
    better = copy.deepcopy(base)
    better.by_key()["b"].value = 95.0
    c3 = B.compare(better, base)
    check("שיפור מזוהה כשיפור", c3["improved"] == ["b"])
    check("ושיפור אינו מסמן כשל", c3["ok"])
    # רעש מדידה אינו נסיגה
    noise = copy.deepcopy(base)
    noise.by_key()["b"].value = 80.0 - B.NOISE / 2
    check("שינוי מתחת לרעש אינו נסיגה",
          not B.compare(noise, base)["regressed"])
    # אבדן מדידה אינו נסיגה - אבל כן כשל
    lost = copy.deepcopy(base)
    s = lost.by_key()["c"]
    s.state, s.value = "unmeasured", None
    c4 = B.compare(lost, base)
    check("אבדן מדידה מדווח בנפרד מנסיגה",
          c4["lost_measurement"] == ["c"] and not c4["regressed"])
    check("ואבדן מדידה מסמן ok=False", not c4["ok"])
    # מדידה חדשה
    gained = copy.deepcopy(base)
    gained.scores.append(B.Score("d", "ד", 50.0, "measured", list("ab")))
    c5 = B.compare(gained, base)
    check("קטגוריה שנמדדה לראשונה מדווחת",
          c5["newly_measured"] == ["d"])
    check("וקטגוריה חדשה אינה נסיגה", not c5["regressed"])


def t_baseline_store() -> None:
    from studio import baseline as B
    print("בסיס · הבסיס אינו נהרס:")
    old = B.STORE
    with tempfile.TemporaryDirectory() as td:
        B.STORE = Path(td)
        try:
            rep = B.Report("r1", "now",
                           [B.Score("a", "א", 90.0, "measured", ["x"])])
            p = B.save(rep, "r1")
            check("מדידה נשמרת ונטענת", B.load("r1").mean == 90.0)
            check("תג שאינו קיים מחזיר None", B.load("nope") is None)
            try:
                B.save(rep, B.V0)
                check("הבסיס מוגן מהמסלול הרגיל", False, "הצליח לדרוס")
            except ValueError:
                check("הבסיס מוגן מהמסלול הרגיל", True)
            _, how = B.freeze_v0(rep)
            check("freeze ראשון כותב", "נכתב" in how, how)
            _, how2 = B.freeze_v0(rep)
            check("freeze שני אינו דורס", "לא נדרס" in how2, how2)
            rep2 = B.Report("r2", "now",
                            [B.Score("a", "א", 50.0, "measured", ["x"])])
            _, how3 = B.freeze_v0(rep2, force=True)
            check("force דורס אך שומר עותק",
                  "נכתב" in how3 and "נשמר" in how3, how3)
            keeps = list(Path(td).glob(f"{B.V0}.*.json"))
            check("העותק של הבסיס הקודם קיים", len(keeps) == 1)
            check("ובעותק יושב הבסיס הישן",
                  json.loads(keeps[0].read_text(encoding="utf-8"))["mean"]
                  == 90.0)
            check("והבסיס החדש הוא החדש", B.load(B.V0).mean == 50.0)
            # קובץ פגום אינו מפיל
            B.path_of("broken").write_text("{לא json", encoding="utf-8")
            check("קובץ פגום מחזיר None ולא חריגה",
                  B.load("broken") is None)
            # שער בלי בסיס
            B.path_of(B.V0).unlink()
            g = B.gate(rep)
            check("שער בלי בסיס מדווח קיום ולא איכות",
                  not g["ok"] and "why" in g, str(g)[:70])
        finally:
            B.STORE = old


def t_baseline_live() -> None:
    from studio import baseline as B
    print("בסיס · מדידה אמיתית:")
    # 08/10/2026: המטריצה גדלה משתים-עשרה קטגוריות לארבע-עשרה.
    # ``technical`` ו-``story`` נוספו כי שני הממדים האלה בשער
    # האיכות נשענו על מקור יחיד שאינו קיים בכל סביבה (קובץ mp4
    # מרונדר / תוכנית סמלית מוצהרת), ולכן ``technical`` — ממד P0 —
    # החזיר "לא נמדד" בכל הרצה שאינה הפקה מלאה.
    check("יש בדיוק ארבע-עשרה קטגוריות",
          len(B.CATEGORIES) == 14, str(len(B.CATEGORIES)))
    keys = [c.key for c in B.CATEGORIES]
    check("אין מפתח כפול", len(set(keys)) == len(keys))
    need = {"identity", "face", "eyes", "lipsync", "body", "hands",
            "emotion", "animation", "camera", "lighting", "rendering",
            "continuity", "technical", "story"}
    check("כל ארבע-עשרה הקטגוריות שהוגדרו קיימות",
          set(keys) == need, str(need ^ set(keys)))
    rep = B.measure(only=["eyes", "animation"], tag="t")
    check("מדידה חלקית מודדת רק את מה שביקשו", len(rep.scores) == 2)
    check("וכל ציון בטווח 0..100",
          all(0.0 <= s.value <= 100.0 for s in rep.measured))
    check("ולכל ציון יש ראיות",
          all(s.evidence for s in rep.measured))

    # גלאי שזורק אינו מפיל את המדידה כולה
    orig = B.CATEGORIES

    def boom(_q):
        raise RuntimeError("נפל בכוונה")
    B.CATEGORIES = (B.Cat("x", "נופל", boom),
                    B.Cat("eyes", "עיניים", B._p_eyes))
    try:
        r = B.measure(tag="t")
        check("גלאי שנפל אינו מפיל את המדידה", len(r.scores) == 2)
        check("והוא מסומן 'לא נמדד' ולא 'נכשל'",
              r.by_key()["x"].state == "unmeasured")
        check("והסיבה נשמרת", "נפל בכוונה" in r.by_key()["x"].note)
        check("והוא אינו משפיע על הממוצע",
              r.mean == r.by_key()["eyes"].value)
    finally:
        B.CATEGORIES = orig


# ===================================================== שלב 9 · מצלמה

def t_camera_geometry() -> None:
    from rig import camera as K
    print("מצלמה · גאומטריה:")
    wide = K.Shot("wide", 0, 1)
    fh = K.frame_height_m(wide, 1.70)
    # זו הבדיקה שמאמתת את הנוסחה מול המספרים של appeal.CONDITIONS:
    # מרחק 3.05, שדה 32°, דמות 1.70 -> הדמות ממלאת את הפריים.
    check("שוט רחב ממסגר דמות שלמה", 1.60 <= fh <= 1.90, f"{fh:.3f} מטר")
    ecu = K.Shot("extreme_close_up", 0, 1)
    check("תקריב קיצוני ממסגר פחות מרבע מטר",
          K.frame_height_m(ecu, 1.70) < 0.25,
          f"{K.frame_height_m(ecu, 1.70):.3f}")
    check("גובה הדמות משנה את המרחק",
          K.Shot("medium", 0, 1).frame(0.5, 1.90)["dist"]
          > K.Shot("medium", 0, 1).frame(0.5, 1.50)["dist"])
    # dolly באמת מתקרב
    d = K.Shot("close_up", 0, 1, "dolly_in")
    check("dolly_in מקרב את המצלמה",
          d.frame(1.0)["dist"] < d.frame(0.0)["dist"])
    o = K.Shot("close_up", 0, 1, "dolly_out")
    check("dolly_out מרחיק", o.frame(1.0)["dist"] > o.frame(0.0)["dist"])
    rf = K.Shot("close_up", 0, 1, "rack_focus")
    check("rack_focus משנה עומק שדה לאורך השוט",
          rf.frame(1.0)["dof"] > rf.frame(0.0)["dof"] + 0.3)
    p = K.Shot("medium", 0, 1, "pan")
    check("pan מסיט זווית", abs(p.frame(1.0)["yaw"] - p.frame(0.0)["yaw"]) > 3)
    check("static אינו מזיז כלום",
          K.Shot("medium", 0, 1).frame(0.0) == K.Shot("medium", 0, 1).frame(1.0))


def t_camera_visibility() -> None:
    from rig import camera as K
    print("מצלמה · נראות:")
    ecu = K.Shot("extreme_close_up", 0, 1)
    wide = K.Shot("wide", 0, 1)
    med = K.Shot("medium", 0, 1)
    cu = K.Shot("close_up", 0, 1)
    check("אישון נראה בתקריב קיצוני",
          K.visibility(ecu, "gaze") >= 0.5, f"{K.visibility(ecu, 'gaze')}")
    check("אישון אינו נראה בשוט רחב",
          K.visibility(wide, "gaze") <= 0.15,
          f"{K.visibility(wide, 'gaze')}")
    check("גבה נראית בתקריב",
          K.visibility(cu, "brows") >= 0.5, f"{K.visibility(cu, 'brows')}")
    check("משקל אינו נראה בתקריב קיצוני",
          K.visibility(ecu, "stance") <= 0.10,
          f"{K.visibility(ecu, 'stance')}")
    check("משקל נראה בשוט רחב",
          K.visibility(wide, "stance") >= 0.4,
          f"{K.visibility(wide, 'stance')}")
    check("ידיים נראות בשוט רחב ולא בתקריב",
          K.visibility(wide, "hands") > K.visibility(cu, "hands"))
    check("אזור שאינו מוכר מחזיר אפס",
          K.visibility(cu, "לא_קיים") == 0.0)
    check("נראות תמיד בטווח 0..1",
          all(0.0 <= K.visibility(s, r) <= 1.0
              for s in (ecu, wide, med, cu)
              for r in K.DETAIL_M))
    # זווית חדה מורידה קריאות
    check("מעל-הכתף קריא פחות מתקריב חזיתי באותו פרט",
          K.visibility(K.Shot("over_shoulder", 0, 1), "brows")
          <= K.visibility(cu, "brows"))
    # מיפוי ערוץ לאזור
    check("ערוץ מבט ממופה לאזור מבט",
          K.region_of_channel("eye_aim_x") == "gaze")
    check("ערוץ אצבע ממופה לידיים",
          K.region_of_channel("curl_index_L") == "hands")
    check("ערוץ משקל ממופה לעמידה",
          K.region_of_channel("weight_shift") == "stance")
    check("ערוץ כתף ממופה לגו",
          K.region_of_channel("shoulder_fwd") == "torso")


def t_camera_choice() -> None:
    from rig import camera as K, cinema
    print("מצלמה · בחירה ומדידה:")
    track = cinema.take("full", "b")
    strats = K.strategies(cinema.SCENE_LEN, cinema.A_SPEECH, cinema.B_SPEECH)
    check("שש אסטרטגיות - שלוש אמיתיות ושלוש ביקורת",
          len(strats) == 6 and len(K.REAL) == 3 and len(K.CONTROL) == 3)
    check("כל אסטרטגיה מכסה את הסצנה בלי חור",
          all(s.covers(cinema.SCENE_LEN) for s in strats.values()))
    covs = {k: K.coverage(s, track) for k, s in strats.items()}
    check("כל כיסוי בטווח 0..1",
          all(0.0 <= c.delivered <= 1.0 and 0.0 <= c.score <= 1.0
              for c in covs.values()))
    best = max((covs[k].score for k in K.REAL))
    check("כל אסטרטגיית ביקורת נחותה מהנבחרת",
          all(covs[k].score < best for k in K.CONTROL),
          str({k: covs[k].score for k in K.CONTROL}))
    check("רחב-בלבד מפסיד את רוב מידע הפנים",
          covs["wide_only"].delivered < 0.55,
          f"{covs['wide_only'].delivered}")
    check("חיתוכים מקוטעים נענשים על שוטים קצרים",
          covs["random_cuts"].detail["short_shots"])
    res = K.choose(track, cinema.SCENE_LEN, cinema.A_SPEECH, cinema.B_SPEECH)
    check("הנבחרת היא אחת האמיתיות", res["chosen"] in K.REAL, res["chosen"])
    check("לכל שוט נבחר יש נימוק",
          all(s["why"] for s in res["why_shots"]))
    check("הדירוג מכיל את כל שש", len(res["ranking"]) == 6)
    check("והדירוג ממוין יורד",
          all(a[1] >= b[1] for a, b in zip(res["ranking"],
                                           res["ranking"][1:])))
    # הכיסוי לכל אזור מסתכם נכון
    pr = covs[res["chosen"]].per_region
    check("כיסוי לכל אזור הוא שבר תקין",
          all(0.0 <= v["share"] <= 1.0 for v in pr.values()), str(list(pr)))

    # שוט פסול נדחה - בדיקת הכיוון השני
    for bad, why in ((("אין_כזה", 0, 1, "static"), "סוג שוט"),
                     (("wide", 0, 1, "אין_כזו"), "תנועה"),
                     (("wide", 1, 1, "static"), "אורך אפס")):
        try:
            K.Shot(*bad)
            check(f"{why} פסול נדחה", False, "התקבל")
        except ValueError:
            check(f"{why} פסול נדחה", True)


def t_camera_audit() -> None:
    from rig import camera as K
    print("מצלמה · מבחן הקבלה:")
    rep = K.audit()
    check("מבחן הקבלה של שלב 9 עובר", rep["passed"],
          str([k for k, v in rep["checks"].items() if not v["pass"]]))
    check("הדוח מחזיר checks במבנה שהבסיס קורא",
          all("value" in v and "limit" in v and "pass" in v
              for v in rep["checks"].values()))
    check("לפחות שבעה סוגי שוט", len(K.KINDS) >= 7)
    check("לפחות שבע תנועות מצלמה", len(K.MOVES) >= 7)
    check("לכל סוג שוט יש תכלית כתובה",
          all(k.purpose for k in K.KINDS.values()))
    # ווידוא שהמבחן אינו מרוכך: הורדת הסף של הנראות שוברת אותו
    lo, hi = K.PX_FLOOR, K.PX_FULL
    try:
        K.PX_FLOOR, K.PX_FULL = 0.0, 0.0001   # הכול נראה תמיד
        soft = K.audit()
        check("מדד שבו הכול נראה אינו עובר את המבחן",
              not soft["passed"])
    finally:
        K.PX_FLOOR, K.PX_FULL = lo, hi
    check("והמבחן חוזר לעבור אחרי השחזור", K.audit()["passed"])


# ===================================================== שלב 10 · תאורה

def t_look_bible() -> None:
    from rig import look as L
    print("תאורה · ספר הסגנון:")
    check("שלושה מצבי קבלה", len(L.TRIO) == 3)
    check("כל מצב בשלישייה קיים בטבלה",
          all(k in L.MOODS for k in L.TRIO))
    check("לכל מצב יש הדגשה ורגש שהוא משרת",
          all(m.emphasis and m.serves for m in L.MOODS.values()))
    check("שפת צבע עם לפחות שלושה גוונים",
          len(L.COLOR_LANGUAGE) >= 3)
    for key in ("skin", "eyes", "hair", "clothing", "environment"):
        check(f"חומר מוגדר: {key}", key in L.MATERIALS)
    check("פיזור תת-עורי קיים בעור ולא בבגד",
          L.MATERIALS["skin"]["sss"] > 0.5
          and L.MATERIALS["clothing"]["sss"] == 0.0)
    check("עיניים חלקות יותר מבד",
          L.MATERIALS["eyes"]["roughness"] < L.MATERIALS["clothing"]["roughness"])
    alb = L.albedo()
    check("לכל אזור יש צבע בסיס",
          all(k in alb for k in ("skin", "hair", "lip", "sclera", "iris")))
    check("לכל אזור יש נורמל",
          all(k in L.NORMALS for k in alb), str(set(alb) - set(L.NORMALS)))


def t_look_shading() -> None:
    from rig import look as L
    print("תאורה · מודל ההצללה:")
    alb = L.albedo()
    for key in L.TRIO:
        m = L.MOODS[key]
        c = L.shade("skin", m, alb)
        check(f"[{key}] צבע מוגמר בטווח 0..1",
              all(0.0 <= float(v) <= 1.0 for v in c), str(c.round(3)))
    n = L.MOODS["neutral"]
    check("אזור בצל כהה מאותו אזור מואר",
          L._luma(L.shade("skin", n, alb, shadowed=True))
          < L._luma(L.shade("skin", n, alb, shadowed=False)))
    check("שיער כהה מעור, כמו בפלטה",
          L._luma(L.shade("hair", n, alb))
          < L._luma(L.shade("skin", n, alb)))
    check("לבן העין בהיר מהאישון",
          L._luma(L.shade("sclera", n, alb))
          > L._luma(L.shade("pupil", n, alb)))
    # מיפוי טונים לא יוצא מהתחום גם בקלט ענק
    import numpy as np
    check("מיפוי הטונים חסום גם בקלט גדול",
          float(L._aces(np.array([40.0, 40.0, 40.0])).max()) <= 1.0)
    check("מתאם דירוג של רצף זהה הוא 1",
          abs(L._spearman([1, 2, 3, 4], [1, 2, 3, 4]) - 1.0) < 1e-9)
    check("ושל רצף הפוך הוא מינוס 1",
          abs(L._spearman([1, 2, 3, 4], [4, 3, 2, 1]) + 1.0) < 1e-9)


def t_look_moods() -> None:
    from rig import look as L
    print("תאורה · שני התנאים המנוגדים:")
    alb = L.albedo()
    pairs = [L.compare_moods(a, b, alb)
             for i, a in enumerate(L.TRIO) for b in L.TRIO[i + 1:]]
    check("שלושה זוגות נבדקים", len(pairs) == 3)
    for p in pairs:
        check(f"[{p['pair']}] הדמות נשארת זהה", p["identity_ok"],
              f"{p['identity']}")
        check(f"[{p['pair']}] והאטמוספרה זזה", p["atmosphere_ok"],
              f"מרחק {p['atmo_distance']}")
    sigs = {k: L.render_signature(L.MOODS[k], alb) for k in L.TRIO}
    check("המתוח מנוגד יותר מהניטרלי",
          sigs["tense"]["contrast"] > sigs["neutral"]["contrast"])
    check("החם חם יותר מהניטרלי",
          sigs["warm"]["warmth"] > sigs["neutral"]["warmth"])
    check("הפרדת נושא מרקע בכל מצב",
          all(s["separation"] >= 0.05 for s in sigs.values()))
    # --- הכיוון השני: שינוי חשיפה בלבד **אינו** אווירה חדשה.
    base = L.MOODS["neutral"]
    for e in (1.10, 1.22, 1.40, 1.70):
        fake = L.Mood(**{**base.__dict__, "key": "_c", "e": e})
        L.MOODS["_c"] = fake
        try:
            c = L.compare_moods("neutral", "_c", alb)
        finally:
            L.MOODS.pop("_c", None)
        check(f"חשיפה {e} לבדה אינה אווירה חדשה",
              not c["atmosphere_ok"], f"מרחק {c['atmo_distance']}")
        check(f"וחשיפה {e} שומרת על הזהות", c["identity_ok"])
    # והכיוון השני של הזהות: מצב שמהפך את ההיררכיה נופל
    flip = L.Mood(**{**base.__dict__, "key": "_f", "k": 0.0, "f": 0.0,
                     "a": 0.0, "r": 9.0, "bounce": 0.0})
    L.MOODS["_f"] = flip
    try:
        c = L.compare_moods("neutral", "_f", alb)
    finally:
        L.MOODS.pop("_f", None)
    check("מצב שמהפך את סדר הבהירות נופל בבדיקת הזהות",
          not c["identity_ok"] or c["identity"] < 1.0,
          f"זהות {c['identity']}")


def t_look_sync() -> None:
    from rig import look as L
    print("תאורה · סנכרון מול הבמה:")
    hm = L.html_moods()
    check("טבלת התאורה נקראת מתוך stage.html", len(hm) >= 5, str(list(hm)))
    sync = L.sync_report()
    check("פייתון וה-HTML תואמים מספר-מספר", sync["ok"],
          "; ".join(sync["mismatch"][:4]))
    check("אין מצב ב-HTML שאין לו רשומה בפייתון",
          not sync["html_only"], str(sync["html_only"]))
    # הכיוון השני: טבלה שנערכה בצד אחד חייבת להפיל את הבדיקה
    with tempfile.TemporaryDirectory() as td:
        p = Path(td) / "stage.html"
        txt = L.STAGE_HTML.read_text(encoding="utf-8")
        p.write_text(txt.replace("warm:    {k:2.25", "warm:    {k:9.99"),
                     encoding="utf-8")
        bad = L.sync_report(p)
        check("עריכה בצד ה-HTML בלבד מפילה את הסנכרון",
              not bad["ok"] and any("warm" in m for m in bad["mismatch"]),
              str(bad["mismatch"][:2]))
        # ומצב שנמחק מה-HTML גם נתפס
        p.write_text(txt.replace("  tense:   {", "  tenseX:  {"),
                     encoding="utf-8")
        gone = L.sync_report(p)
        check("מצב שנמחק מה-HTML נתפס",
              any("tense" in m for m in gone["mismatch"]))


def t_look_audit() -> None:
    from rig import look as L
    print("תאורה · מבחן הקבלה:")
    rep = L.audit()
    check("מבחן הקבלה של שלב 10 עובר", rep["passed"],
          str([k for k, v in rep["checks"].items() if not v["pass"]]))
    check("הדוח מחזיר checks במבנה שהבסיס קורא",
          all("value" in v and "limit" in v and "pass" in v
              for v in rep["checks"].values()))
    check("גרסת הביקורת אינה נשארת בטבלה אחרי המבחן",
          "control_exposure" not in L.MOODS)
    # ווידוא שהמבחן אינו מרוכך
    old = L.ATMO_MIN
    try:
        L.ATMO_MIN = 0.0
        soft = L.audit()
        check("סף אווירה אפס מפיל את המבחן (הביקורת עוברת)",
              not soft["passed"])
    finally:
        L.ATMO_MIN = old
    check("והמבחן חוזר לעבור אחרי השחזור", L.audit()["passed"])


# ============================================ חיבור הבסיס לשני החדשים

def t_wired_into_baseline() -> None:
    from studio import baseline as B
    print("חיבור · שתי הקטגוריות החסרות נמדדות עכשיו:")
    rep = B.measure(only=["camera", "lighting"], tag="t")
    cam, lit = rep.by_key()["camera"], rep.by_key()["lighting"]
    check("מצלמה נמדדת ואינה 'אין מערכת'",
          cam.state == "measured", f"{cam.state} · {cam.note}")
    check("תאורה נמדדת ואינה 'אין מערכת'",
          lit.state == "measured", f"{lit.state} · {lit.note}")
    check("ציון המצלמה מלא", cam.value == 100.0, f"{cam.value}")
    check("ציון התאורה מלא", lit.value == 100.0, f"{lit.value}")
    check("ולשתיהן יש ראיות", cam.evidence and lit.evidence)
    full = B.measure(tag="t")
    check("כל ארבע-עשרה הקטגוריות נמדדות עכשיו",
          len(full.measured) == len(B.CATEGORIES),
          str([s.key for s in full.scores if s.state != "measured"]))
    base = B.load(B.V0)
    if base is not None:
        cmp = B.compare(full, base)
        # ההשוואה היא על **איחוד** המפתחות, ולכן שתי הקטגוריות
        # שנוספו ב-08/10 נכנסות לשורות גם כשהבסיס המקובע אינו
        # מכיר אותן — ונרשמות כ"נמדד מחדש" ולא כנסיגה.
        check("ההשוואה מול הבסיס המקובע רצה",
              "rows" in cmp and len(cmp["rows"]) == len(B.CATEGORIES))
        check("ושתי הקטגוריות החדשות נרשמות כנמדדות מחדש",
              {"technical", "story"} <= set(cmp["newly_measured"]),
              str(cmp["newly_measured"]))
        check("ושתי הקטגוריות שהיו חסרות שיפרו",
              set(cmp["improved"]) >= {"camera", "lighting"},
              str(cmp["improved"]))
        check("ואין נסיגה באף קטגוריה", not cmp["regressed"],
              str(cmp["regressed"]))


def t_identity_measured() -> None:
    """"זהות הדמות" במדידת הפרויקט - שהיא באמת מודדת זהות.

    **שני באגים שקטים, 08/10/2026.** (1) ``detail`` חזר ריק בכל אחת
    מחמש המדידות השמורות בפרויקט, כי הקורא ביקש מפתחות
    ``pair``/``shape`` שאינם קיימים בפלט של ``dimorph.audit_shape``.
    (2) הציון נגזר כולו משבע בדיקות **שפת הצורות**, ולכן ממד בשם
    "זהות" לא שאל אף פעם אם הדמות נשארת אותה דמות אחרי שהיא זזה.
    שתי הבדיקות כאן נכשלות על הקוד הקודם.
    """
    from studio import baseline as B
    from studio import mission as M
    print("זהות הדמות · נמדדת באמת:")
    rep = B.measure(only=["identity"], tag="t")
    s = rep.by_key()["identity"]
    check("הזהות נמדדת", s.state == "measured", f"{s.state} · {s.note}")
    check("ולפרטים יש תוכן, לא מילון ריק",
          bool(s.detail.get("per_character")) and
          bool(s.detail.get("shape_measured")),
          str(s.detail)[:80])
    ev = set(s.evidence or [])
    need = {"זהות/bone_length_drift", "זהות/face_measure_drift",
            "זהות/rest_recovery_mm", "זהות/pose_separation_pct"}
    check("ארבעת מדדי חסינות הזהות לפוזה נמצאים בראיות",
          need <= {e.rstrip(" ✗") for e in ev}, str(need - ev))
    check("ושפת הצורות לא נזנחה",
          any(e.startswith("צורה/") for e in ev), str(sorted(ev)[:3]))
    check("הזהות אינה נגזרת מטבלה אחת בלבד", len(ev) >= 15, len(ev))

    # הממד של המשימה ("character") שואב מכאן, ולכן השרשרת נבדקת
    # מקצה לקצה ולא רק הגלאי.
    g = M.quality_gate(rep, check_regression=False)
    ch = g.by_key()["character"]
    check("ממד הזהות של שער האיכות נמדד מהגלאי הזה",
          ch.state == "measured" and ch.value == s.value,
          f"{ch.state} · {ch.value} מול {s.value}")


def t_technical_pipeline() -> None:
    """הממד הטכני · בדיקת צינור רינדור שרצה בכל סביבה.

    **הכשל שזה סוגר, 08/10/2026.** ``technical`` הוא ממד P0 בשער
    האיכות, והמקור היחיד שלו היה ``qa.inspect`` — שדורש קובץ mp4
    מרונדר של 1920x1080, כלומר דפדפן ומנוע. לכן בכל הרצה שאינה
    הפקה מלאה הוא החזיר "לא נמדד", הפסק נשאר ``FAIL``, ואף מדידת
    איכות לא נכשלה בדרך. ``studio/techcheck.py`` מקודד קליפ זעיר
    אמיתי ומפענח אותו בחזרה.

    שלוש הבדיקות השליליות כאן הן העיקר: בדיקה שאינה יכולה להיכשל
    אינה בדיקה. קובץ קטוע, יחס צלעות שאינו תקן ההפקה, ותמונה
    קפואה — כל אחד מהם מפיל מדד אחר ומזוהה בשמו.
    """
    import numpy as np
    from studio import techcheck as T
    print("טכני · צינור רינדור קליל:")
    t = T.audit(frames=24, check_delivered=False)
    check("הבדיקה הטכנית רצה בלי דפדפן ובלי קובץ הפקה",
          t.total >= 18, f"{t.passed}/{t.total}")
    check("וכל הבדיקות עוברות על קידוד תקין",
          t.ok and t.score == 100.0, str(t.failures()))
    check("והקובץ באמת נוצר ואינו ריק",
          Path(t.detail["file"]).exists() and t.detail["mb"] > 0,
          str(t.detail.get("mb")))

    # שלילי 1 · קובץ קטוע: הפענוח מחזיר פחות פריימים משנכנסו
    p = Path(t.detail["file"])
    raw = p.read_bytes()
    cut = p.with_name("probe_cut.mp4")
    cut.write_bytes(raw[:len(raw) // 3])
    dec = T.decode(cut)
    check("קובץ קטוע מזוהה — פחות פריימים או שגיאת פענוח",
          dec["frames_out"] < 24 or dec["errors"] > 0,
          f"{dec['frames_out']} פריימים · {dec['errors']} שגיאות")
    cut.unlink(missing_ok=True)

    # שלילי 2 · יחס צלעות שאינו תקן ההפקה
    odd = T.audit(frames=12, w=320, h=176, check_delivered=False)
    check("יחס צלעות שאינו 16:9 מפיל את בדיקת התקן",
          "יחס הצלעות תואם תקן ההפקה" in odd.failures(),
          str(odd.failures()))

    # שלילי 3 · תמונה קפואה: אין תנועה בפלט
    frames = np.repeat(T.synth_frames(1, 320, 180), 24, axis=0)
    fz = T.OUT / "probe_frozen.mp4"
    T.encode(frames, fz)
    d2 = T.decode(fz)
    mo = float(np.abs(np.diff(d2["luma"], axis=0)).mean())
    check("תמונה קפואה נמדדת כחסרת תנועה",
          mo < T.MIN_MOTION, f"{mo:.6f} מול {T.MIN_MOTION}")
    fz.unlink(missing_ok=True)


def t_story_council() -> None:
    """ממד הסיפור · מועצה שמודדת גם את הפריימים, 08/10/2026.

    עד עכשיו ציון הסיפור נגזר **כולו** מהתוכנית הסמלית של השוט
    (``critics.story_critic``, שאינו רואה אף פיקסל וכתוב שם
    במפורש), ולכן שוט עם שדות מצב מלאים קיבל 100 גם אם האנימציה
    שיצאה ממנו שטוחה או מקוטעת. שבעת המדדים החדשים נגזרים מעקומת
    המצב הרגשי **הנמדדת מתוך הפריימים**, ושלוש הבדיקות השליליות
    כאן מראות שהם באמת מפרידים: עקומה שטוחה, רעש, וסולם חלק.
    """
    import numpy as np
    from studio import story as S
    print("סיפור · מועצת המבקרים על הפריימים:")

    dt = 1.0 / 30.0
    n = 361
    # שלילי 1 · עקומה שטוחה: אין קשת, אין קצב, אין מעברים
    flat = S.frame_measures(np.zeros(n), dt, 12.0)
    bad = {m.code for m in flat if not m.ok}
    check("עקומה שטוחה מפילה טווח, קשת ומעברי כוונה",
          {"story.frames.range", "story.frames.arc",
           "story.frames.beats"} <= bad, str(sorted(bad)))
    check("וציון הפריימים שלה נמוך",
          S.C._verdict("story", flat).score < 35.0,
          str(S.C._verdict("story", flat).score))

    # שלילי 2 · רעש: הרבה החלפות כיוון, אף אחת מהן אינה ביט
    rng = np.random.default_rng(7)
    noise = np.cumsum(rng.normal(0, 1, n)) * 0.0
    noise = rng.normal(0, 1, n)
    nm = {m.code: m for m in S.frame_measures(noise, dt, 12.0)}
    check("רעש אינו עובר את שער הקריאות",
          not nm["story.frames.legible"].ok,
          str(nm["story.frames.legible"].value))

    # שלילי 3 · סולם חלק עולה: קשת יש, מעברי כוונה אין
    ramp = np.linspace(0.0, 1.0, n)
    rm = {m.code: m for m in S.frame_measures(ramp, dt, 12.0)}
    check("סולם ליניארי אחד אינו שלושה מעברי כוונה",
          not rm["story.frames.beats"].ok,
          str(rm["story.frames.beats"].value))
    check("אבל הקשת שלו כן נמדדת", rm["story.frames.arc"].ok,
          str(rm["story.frames.arc"].value))

    # והמועצה האמיתית, על הסצנה האמיתית
    d = S.council()
    check("המועצה מחזירה מדד לכל דמות, סמלי ועל פריימים",
          len(d["checks"]) >= 29, len(d["checks"]))
    check("וציון הסיפור עובר את סף הממד (90)",
          d["score"] >= 90.0, f"{d['score']}")
    check("ושתי הדמויות קיבלו מדידת פריימים אמיתית",
          all(p["frames"]["available"] for p in d["per_character"].values()))
    check("ומדד הסצנה מראה ששתי הדמויות אינן אותה עקומה",
          d["scene"]["ok"], str(d["scene"]["value"]))


def t_two_domains_in_gate() -> None:
    """שני הממדים שלא נמדדו — נמדדים עכשיו בשער עצמו, 08/10/2026."""
    from studio import baseline as B
    from studio import mission as M
    print("שער האיכות · טכני וסיפור נמדדים:")
    rep = B.measure(only=["technical", "story"], tag="t")
    by = rep.by_key()
    for key, he in (("technical", "טכני"), ("story", "סיפור")):
        s = by[key]
        check(f"{he}: נמדד ואינו 'אין מערכת'",
              s.state == "measured", f"{s.state} · {s.note}")
        check(f"{he}: ציון חיובי אמיתי", (s.value or 0.0) > 0.0,
              str(s.value))
        check(f"{he}: ועם ראיות בשמן", len(s.evidence) >= 7,
              str(len(s.evidence)))
    g = M.quality_gate(rep, check_regression=False)
    for key, he in (("technical", "טכני"), ("story", "סיפור")):
        d = g.by_key()[key]
        check(f"ממד {he} בשער נמדד מהגלאי הזה",
              d.state == "measured" and d.value == by[key].value,
              f"{d.state} · {d.value} מול {by[key].value}")
        check(f"וממד {he} עובר את הסף שלו ({d.threshold:.0f})",
              d.passed, f"{d.value}")
    check("ושני הממדים אינם נמצאים עוד ברשימת 'לא נמדד'",
          not ({"technical", "story"} & {s.key for s in g.unmeasured}),
          str([s.key for s in g.unmeasured]))


TESTS = (t_baseline_scoring, t_baseline_states, t_baseline_compare,
         t_baseline_store, t_baseline_live, t_identity_measured,
         t_camera_geometry, t_camera_visibility, t_camera_choice,
         t_camera_audit,
         t_look_bible, t_look_shading, t_look_moods, t_look_sync,
         t_look_audit,
         t_wired_into_baseline,
         t_technical_pipeline, t_story_council, t_two_domains_in_gate)


def main() -> int:
    sys.stdout.reconfigure(encoding="utf-8")
    print("=== בדיקות שלבים 1 · 9 · 10 ===\n")
    for fn in TESTS:
        fn()
        print()
    print(f"{_ok}/{_ok + _bad} עברו")
    if _fails:
        print("נכשלו: " + ", ".join(_fails))
    return 0 if not _bad else 1


if __name__ == "__main__":
    raise SystemExit(main())
