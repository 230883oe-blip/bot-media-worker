# -*- coding: utf-8 -*-
r"""אימות "זהות הדמות" - **רץ בענן, וגם מקומית כסימולציה של אותו קוד**.

ההנחיה שהולידה את הקובץ (08/10/2026, המשתמש):
"תתקן זהות הדמות ותריץ אימות אמיתי בענן ותעשה סימולציה".

שלוש החלטות, וכל אחת מהן תיקון של משהו שנמדד כאן קודם:

* **אותו קובץ בדיוק רץ בשני המקומות.** הסימולציה אינה "קוד שמחקה את
  הענן" - היא ``python gpucloud/identity_job.py`` על המכונה הזאת.
  ב-08/10 נכתב כאן שהסימולציה "כיסתה בדיוק את מה שנפל בענן", וזה
  נשען על הנחה. כששני הצדדים מריצים קובץ אחד, ההשוואה היא עובדה:
  ``compare_identity.py`` משווה שדה-שדה ואומר איפה הם נחלקו.
* **ארבעה חלקים נפרדים.** החלק שמעניין (מדידת הזהות, 4 שניות) אינו
  מחכה לחבילת הבדיקות (עשר דקות), וכשל באחד נראה בנפרד מכשל באחר.
* **המדידה כאן אינה בודקת רק "עובר".** היא שומרת את ה**ערכים**
  המדודים, כי שני הצדדים חייבים להסכים על מספרים ולא רק על פסק.
  מספרי נקודה צפה בין x86 ל-ARM אינם זהים ביט-בביט, ולכן ההשוואה
  סובלנית לסדר הגודל של רעש float ולא לשינוי אמיתי.
"""
from __future__ import annotations

import json
import platform
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

#: שמונה בדיקות הזהות שחייבות להיות שם. אם מישהו ימחק אחת מהן,
#: האימות ייפול במקום "לעבור על שבע".
EXPECT_CHECKS = (
    "bone_length_drift", "face_measure_drift", "rest_recovery_mm",
    "pose_separation_pct", "weights_sum_to_one", "no_negative_weights",
    "every_bone_weighted", "all_characters_measured",
)

#: ארבעת מדדי חסינות הזהות לפוזה, שהם לב הממד. ``prefix`` הוא
#: הקידומת שהגלאי של מדידת הפרויקט שם עליהם.
CORE_METRICS = ("bone_length_drift", "face_measure_drift",
                "rest_recovery_mm", "pose_separation_pct")


def part_a_identity() -> dict:
    """ביקורת הזהות עצמה - ארבע דמויות, ארבעה מדדים, בריאות משקולות."""
    t0 = time.perf_counter()
    from rig import identity

    a = identity.audit(quality="fast")
    checks = a.get("checks") or {}
    missing = [k for k in EXPECT_CHECKS if k not in checks]
    problems = list(a.get("problems") or [])
    if missing:
        problems.append(f"בדיקות זהות נעלמו מהביקורת: {missing}")

    # הערכים לכל דמות, לטובת ההשוואה בין הענן למקומי. רק מספרים -
    # מבנה גדול היה הופך את ההשוואה לרועשת בלי להוסיף ידיעה.
    per = {}
    for n, r in (a.get("per_character") or {}).items():
        if "error" in r:
            per[n] = {"error": r["error"]}
            continue
        per[n] = {
            "verts": r["verts"], "poses": r["poses"],
            "rigid_verts": r["rigid_verts"],
            "bone_length_drift": r["bone_length_drift"],
            "face_measure_drift": r["face_measure_drift"],
            "rest_recovery_mm": r["rest_recovery_mm"],
            "pose_separation_pct": r["pose_separation_pct"],
            "geometry_passes": r["geometry_passes"],
            "weights_sum_ok": bool(r["weights"]["sum_ok"]),
            "weights_negative": int(r["weights"]["negative"]),
            "bones_used": int(r["weights"]["bones_used"]),
            "weightless_bones": r["weightless_bones"],
        }
    return {"ok": bool(a.get("passed")) and not missing,
            "checks": {k: {"value": _plain(v.get("value")),
                           "limit": _plain(v.get("limit")),
                           "pass": bool(v.get("pass"))}
                       for k, v in checks.items()},
            "problems": problems, "per_character": per,
            "n_checks": len(checks),
            "seconds": round(time.perf_counter() - t0, 2)}


def part_b_probe() -> dict:
    """הגלאי של מדידת הפרויקט - כולל התיקון של ``detail`` הריק.

    שתי טענות נבדקות, ולא אחת: שהציון נגזר משתי הטבלאות יחד (15
    ראיות ולא 7), ושה-``detail`` נושא נתונים. השנייה היא הבאג שהיה
    שקוף לגמרי: ``{'pairs': {}}`` בכל חמש המדידות השמורות.
    """
    t0 = time.perf_counter()
    from studio import baseline as B

    rep = B.measure(quality="fast", only=["identity"], tag="cloud_identity")
    s = rep.by_key()["identity"]
    ev = [str(e) for e in (s.evidence or [])]
    bare = {e.rstrip(" ✗") for e in ev}
    det = s.detail or {}
    problems = []
    if s.state != "measured":
        problems.append(f"הזהות אינה נמדדת: {s.state} · {s.note}")
    if not det.get("per_character"):
        problems.append("detail חזר בלי נתוני דמויות - הבאג השקט חזר")
    if not det.get("shape_measured"):
        problems.append("detail חזר בלי מדידת הצורות")
    for m in CORE_METRICS:
        if f"זהות/{m}" not in bare:
            problems.append(f"מדד הזהות {m} אינו בראיות")
    if not any(e.startswith("צורה/") for e in ev):
        problems.append("שפת הצורות נזנחה מהראיות")
    return {"ok": not problems, "problems": problems,
            "state": s.state, "value": _plain(s.value),
            "n_evidence": len(ev), "evidence": sorted(ev),
            "failed_evidence": sorted(e for e in ev if e.endswith("✗")),
            "detail_characters": sorted(det.get("per_character") or {}),
            "identity_passed": det.get("identity_passed"),
            "shape_passed": det.get("shape_passed"),
            "seconds": round(time.perf_counter() - t0, 2)}


def part_c_gate() -> dict:
    """שער האיכות של הפרויקט - שממד "זהות" מגיע אליו מדוד ולא ריק."""
    t0 = time.perf_counter()
    from studio import baseline as B
    from studio import mission as M

    rep = B.measure(quality="fast", tag="cloud_gate")
    g = M.quality_gate(rep, check_regression=False)
    by = g.by_key()
    ch = by.get("character")
    problems = []
    if ch is None:
        problems.append("אין ממד 'character' בשער האיכות")
    else:
        if ch.state != "measured":
            problems.append(f"ממד הזהות {ch.state}: {ch.note}")
        if not ch.parts.get("baseline:identity"):
            problems.append("ממד הזהות אינו שואב מגלאי הזהות")
    # **שני הממדים שנוספו ב-08/10 נבדקים כאן ולא רק מקומית.**
    # ``technical`` היה ממד P0 שהחזיר "לא נמדד" בכל הרצה שאינה הפקה
    # מלאה, ו-``story`` נגזר כולו מתוכנית סמלית מוצהרת. אם אחד מהם
    # חוזר להיות לא-נמדד בענן (למשל כי ``av`` לא הותקן שם), העבודה
    # הזאת חייבת להיכשל - אחרת הרגרסיה חוזרת בשקט בדיוק במקום שבו
    # היא נולדה.
    for key, he in (("technical", "טכני"), ("story", "סיפור")):
        d = by.get(key)
        if d is None:
            problems.append(f"אין ממד '{key}' בשער האיכות")
            continue
        if d.state != "measured":
            problems.append(f"ממד {he} {d.state}: {d.note}")
        elif not d.passed:
            problems.append(f"ממד {he} {d.value} מתחת לסף {d.threshold}")
    return {"ok": not problems, "problems": problems,
            "character": None if ch is None else {
                "state": ch.state, "value": _plain(ch.value),
                "threshold": ch.threshold, "passed": bool(ch.passed),
                "parts": {k: _plain(v) for k, v in (ch.parts or {}).items()}},
            "quality_score": _plain(g.quality_score),
            "measured_categories": sorted(s.key for s in rep.measured),
            "unmeasured_dims": sorted(s.key for s in g.unmeasured),
            "dim_scores": {s.key: _plain(s.value) for s in g.scores},
            "seconds": round(time.perf_counter() - t0, 2)}


def part_d_tests() -> dict:
    """חבילת הבדיקות המלאה של הריג, בתהליך נפרד.

    תהליך נפרד בכוונה: ``SystemExit`` או קריסה בבדיקה אחת לא לוקחים
    איתם את כל האימות. קריאת שורת הסיכום ולא ספירה ידנית - ספירה
    ידנית הייתה מפספסת בדיקה שקרסה לפני ההדפסה (נמדד 08/10).
    """
    t0 = time.perf_counter()
    try:
        p = subprocess.run([sys.executable, "-m", "rig.test_rig"],
                           cwd=str(ROOT), capture_output=True, timeout=2700)
    except subprocess.TimeoutExpired:
        return {"ok": False, "why": "חבילת הבדיקות עברה 45 דקות"}
    out = (p.stdout or b"").decode("utf-8", "replace")
    err = (p.stderr or b"").decode("utf-8", "replace")
    passed = total = -1
    for ln in reversed(out.splitlines()):
        ln = ln.strip()
        if "/" in ln and ln.endswith("עברו"):
            try:
                a, b = ln.split(" ")[0].split("/")
                passed, total = int(a), int(b)
            except ValueError:
                continue
            break
    fails = [ln.strip() for ln in out.splitlines() if ln.strip().startswith("✗")]
    # הבדיקה שנוספה 08/10 חייבת להיות שם. חבילה שעוברת בלי הבדיקה
    # הזאת היא בדיוק המצב שממנו באנו.
    ran_audit = "ביקורת זהות הצוות:" in out
    return {"ok": (p.returncode == 0 and passed >= 0 and passed == total
                   and ran_audit),
            "identity_audit_ran": ran_audit,
            "crashed_midway": passed < 0 and "Traceback" in err,
            "returncode": p.returncode, "passed": passed, "total": total,
            "failures": fails[:40], "stderr_tail": err[-1500:],
            "seconds": round(time.perf_counter() - t0, 1)}


def part_e_stages() -> dict:
    """בדיקות השלבים - שם יושבת הבדיקה שהזהות נמדדת מקצה לקצה."""
    t0 = time.perf_counter()
    try:
        p = subprocess.run([sys.executable, "studio/test_stages.py"],
                           cwd=str(ROOT), capture_output=True, timeout=1800)
    except subprocess.TimeoutExpired:
        return {"ok": False, "why": "בדיקות השלבים עברו 30 דקות"}
    out = (p.stdout or b"").decode("utf-8", "replace")
    err = (p.stderr or b"").decode("utf-8", "replace")
    passed = total = -1
    for ln in reversed(out.splitlines()):
        ln = ln.strip()
        if "/" in ln and ln.endswith("עברו"):
            try:
                a, b = ln.split(" ")[0].split("/")
                passed, total = int(a), int(b)
            except ValueError:
                continue
            break
    ran = "זהות הדמות · נמדדת באמת:" in out
    return {"ok": p.returncode == 0 and passed >= 0 and passed == total and ran,
            "identity_test_ran": ran, "returncode": p.returncode,
            "passed": passed, "total": total,
            "failures": [ln.strip() for ln in out.splitlines()
                         if ln.strip().startswith("✗")][:40],
            "stderr_tail": err[-1200:],
            "seconds": round(time.perf_counter() - t0, 1)}


def _plain(x):
    """מספר פייתון רגיל. ``numpy.float64`` אינו ניתן לסריאליזציה ל-JSON,
    וזה היה מפיל את כתיבת ה-artifact **בסוף** הריצה - אחרי שכל זמן
    הענן כבר נשרף."""
    if isinstance(x, (bool, str)) or x is None:
        return x
    try:
        f = float(x)
    except (TypeError, ValueError):
        return str(x)
    return int(f) if f.is_integer() and abs(f) < 1e15 else f


PARTS = {
    "identity": (("a_identity", part_a_identity), ("b_probe", part_b_probe),
                 ("c_gate", part_c_gate)),
    "tests":    (("d_tests", part_d_tests), ("e_stages", part_e_stages)),
    "all":      (("a_identity", part_a_identity), ("b_probe", part_b_probe),
                 ("c_gate", part_c_gate), ("d_tests", part_d_tests),
                 ("e_stages", part_e_stages)),
}

#: כולם חוסמים. אין כאן חלק "מודד איכות שמבנהו משתנה".
BLOCKING = ("a_identity", "b_probe", "c_gate", "d_tests", "e_stages")


def main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    only = "all"
    if "--only" in argv:
        i = argv.index("--only")
        if i + 1 < len(argv):
            only = argv[i + 1]
    if only not in PARTS:
        print(f"--only חייב להיות אחד מ-{sorted(PARTS)}")
        return 2
    dest = Path(argv[argv.index("--out") + 1]) if "--out" in argv \
        else HERE / "result.json"

    out: dict = {"started": time.strftime("%Y-%m-%d %H:%M:%S"),
                 "python": sys.version.split()[0],
                 "machine": platform.machine(),
                 "system": platform.system(),
                 "where": "github-actions" if "--out" not in argv else "local",
                 "part": only}
    for name, fn in PARTS[only]:
        try:
            out[name] = fn()
        except Exception as exc:                               # noqa: BLE001
            import traceback
            out[name] = {"ok": False, "why": f"{type(exc).__name__}: {exc}",
                         "traceback": traceback.format_exc()[-800:]}
        print(f"[{name}] ok={out[name].get('ok')}", flush=True)

    ran = [k for k in BLOCKING if k in out]
    out["ok"] = bool(ran) and all(out[k].get("ok") for k in ran)
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(json.dumps(out, ensure_ascii=False, indent=1),
                    encoding="utf-8")
    print(f"\nנכתב {dest} · ok={out['ok']}")
    return 0 if out["ok"] else 1


if __name__ == "__main__":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:                                          # noqa: BLE001
        pass
    sys.exit(main())
