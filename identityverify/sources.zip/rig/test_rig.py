# -*- coding: utf-8 -*-
"""בדיקות יחידה לצינור הדמות. מריצים: python -m rig.test_rig

כל מקרה כאן נולד מתקלה אמיתית שנראתה בפועל, ולא מדמיון.
"""
from __future__ import annotations

import json
import math
import sys
import tempfile
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from rig import (acting, basemesh, controls, detail, face,      # noqa: E402
                 glbio, identity, pipeline)
from rig.skeleton import (Skeleton, Spring, quat_from_euler,    # noqa: E402
                          quat_mul, quat_to_mat, two_bone_ik)
from rig import paths                                 # noqa: E402

HERE = Path(__file__).resolve().parent          # rig/
STUDIO = HERE.parent                            # anim_studio/

FAILS = []
SKIPS = []
RUN = 0


def check(name, cond, extra=""):
    global RUN
    RUN += 1
    if cond:
        print(f"  ✓ {name}")
    else:
        print(f"  ✗ {name} {extra}")
        FAILS.append(name)


def skip(name, why):
    """בדיקה שלא ניתן להריץ **כאן**, ונאמר מי ולמה.

    למה זה קיים (08/10). חבילת הבדיקות נפלה בענן באמצע, בריצה
    37699431625, בשורה הזו:

        FileNotFoundError: 'D:\\claude-bot\\out\\char3d\\rigged/zippy.rig.json'

    הנכסים הממורגים הם מאות מגה־בייט ואינם ב-git, ולכן על שרת לינוקס
    הם באמת אינם שם. אבל התוצאה לא הייתה "בדיקה נכשלה" אלא
    **``SystemExit`` באמצע הריצה**: כל 5 הבדיקות שאחריה - ובהן
    `t_arkit`, זו שבגללה הריצה נעשתה כולה - לא רצו בכלל, והדוח חזר
    עם ``passed=-1``.

    לכן דילוג, ולא ``check(..., True)``: דילוג **אינו נספר כהצלחה**.
    הוא נרשם בשמו, נדפס בסוף, וריצה שבה דולג משהו אומרת את זה
    במפורש - אחרת "1412/1412 עברו" בענן היה שקר שנראה כמו הצלחה.
    """
    SKIPS.append(name)
    print(f"  ↷ {name} — דולג: {why}")


def t_skeleton():
    print("שלד:")
    s = Skeleton()
    c = s.counts()
    check("יש לפחות 60 עצמות", c["total"] >= 60, c)
    check("יש 30 עצמות אצבע", c.get("finger") == 30, c)
    check("יש לפחות 15 עצמות פנים", c.get("face", 0) >= 15, c)
    need = ["jaw", "tongue_01", "tongue_02", "eye_L", "eye_R",
            "eyelid_up_L", "eyelid_lo_R", "brow_in_L", "brow_out_R",
            "cheek_L", "cheek_R", "hand_L", "thumb_01_R", "pinky_03_L",
            "thigh_L", "toe_R"]
    check("כל העצמות הנדרשות קיימות",
          all(n in s.by_name for n in need),
          [n for n in need if n not in s.by_name])
    check("ההורה תמיד מופיע לפני הבן",
          all(s.by_name[b.parent].index < b.index
              for b in s.bones if b.parent), "")
    # FK של פוזת מנוחה חייב להחזיר בדיוק את מקומות המנוחה
    W = s.forward({})
    err = max(float(np.linalg.norm(W[b.index][:3, 3] - np.array(b.rest)))
              for b in s.bones)
    check("FK בפוזת מנוחה מחזיר את מקומות המנוחה", err < 1e-9, err)
    # inverse bind
    M = s.skin_matrices(W)
    check("מטריצות העור בפוזת מנוחה הן היחידה",
          np.allclose(M, np.eye(4), atol=1e-9))
    # גובה
    s2 = Skeleton(height=1.40)
    check("קנה המידה לפי גובה עובד",
          abs(s2.by_name["head_tip"].rest[1] - 1.40) < 1e-6,
          s2.by_name["head_tip"].rest)


def t_quats():
    print("מתמטיקה:")
    q = quat_from_euler(0.3, -0.2, 0.7)
    check("קוורטניון מנורמל", abs(np.linalg.norm(q) - 1) < 1e-12)
    R = quat_to_mat(q)
    check("מטריצת הסיבוב אורתוגונלית",
          np.allclose(R @ R.T, np.eye(3), atol=1e-12))
    check("כפל קוורטניונים = שרשור סיבובים",
          np.allclose(quat_to_mat(quat_mul(q, q)), R @ R, atol=1e-12))


def t_ik():
    print("IK:")
    root = np.array([0.0, 1.4, 0.0])
    mid = np.array([0.45, 1.4, 0.0])
    end = np.array([0.69, 1.4, 0.0])
    l1 = np.linalg.norm(mid - root)
    l2 = np.linalg.norm(end - mid)
    for tgt in ([0.3, 1.1, 0.4], [0.0, 1.9, 0.1], [-0.2, 1.4, 0.3],
                [9.0, 9.0, 9.0], [0.0, 1.4, 0.0]):
        nm, ne = two_bone_ik(root, mid, end, np.array(tgt, float),
                             root + np.array([0, 0, 1.0]))
        ok = (np.all(np.isfinite(nm)) and np.all(np.isfinite(ne))
              and abs(np.linalg.norm(nm - root) - l1) < 1e-6
              and abs(np.linalg.norm(ne - nm) - l2) < 1e-6)
        check(f"IK שומר אורכי עצם, מטרה {tgt}", ok, (nm, ne))
    # מטרה בטווח -> הקצה מגיע אליה
    tgt = np.array([0.3, 1.15, 0.25])
    nm, ne = two_bone_ik(root, mid, end, tgt, root + np.array([0, 0, 1.0]))
    check("מטרה בתוך הטווח מושגת", np.linalg.norm(ne - tgt) < 1e-6,
          np.linalg.norm(ne - tgt))


def t_controls():
    print("בקרות:")
    s = Skeleton()
    check("יש לפחות 60 בקרות", len(controls.CONTROLS) >= 60,
          len(controls.CONTROLS))
    for g in ("face", "body", "hand", "limb"):
        check(f"קיימת קבוצת בקרות {g}", g in controls.GROUPS)
    try:
        controls.normalize({"אין_כזה": 1})
        check("בקרה לא קיימת נדחית", False)
    except KeyError:
        check("בקרה לא קיימת נדחית", True)
    check("ערך מחוץ לתחום נחתך ולא זורק",
          controls.clamp("jaw_open", 5.0) == 1.0)
    check("nan הופך ל-0 ולא מעלים את הדמות",
          controls.clamp("head_yaw", float("nan")) == 0.0)

    q0 = controls.evaluate(s, {})
    qj = controls.evaluate(s, {"jaw_open": 1.0})
    check("פתיחת פה מזיזה את עצם הלסת",
          not np.allclose(qj["jaw"], q0.get("jaw", [0, 0, 0, 1]), atol=1e-6))
    # הלסת יורדת ולא עולה
    W0 = s.forward(q0)
    W1 = s.forward(qj)
    i = s.by_name["jaw_tip"].index
    check("פתיחת פה מורידה את הסנטר",
          W1[i][1, 3] < W0[i][1, 3] - 1e-4,
          (W0[i][1, 3], W1[i][1, 3]))
    # מצמוץ
    qb = controls.evaluate(s, {"blink_L": 1.0})
    check("מצמוץ מזיז רק את העפעף השמאלי",
          not np.allclose(qb["eyelid_up_L"], [0, 0, 0, 1], atol=1e-6)
          and np.allclose(qb["eyelid_up_R"], [0, 0, 0, 1], atol=1e-6))
    # אגרוף מזיז 15 עצמות אצבע בכל יד
    qf = controls.evaluate(s, {"fist_L": 1.0})
    moved = [n for n, v in qf.items() if not np.allclose(v, [0, 0, 0, 1], 1e-6)
             and s.by_name[n].kind == "finger" and n.endswith("_L")]
    check("אגרוף מכופף 15 פרקי אצבע ביד אחת", len(moved) == 15, len(moved))
    # אצבע מכופפת נעה לכיוון כף היד ולא לאחור
    # "כיפוף" נמדד כקירוב קצה האצבע אל שורש כף היד, ולא כירידה ב-Y:
    # בפוזת ברירת המחדל הזרוע תלויה למטה, ואז אצבע שמתכופפת נכון
    # דווקא *עולה* מעט. הניסוח הראשון של הבדיקה נפל על זה.
    tip = s.by_name["index_tip_L"].index
    wrist = s.by_name["hand_L"].index
    Wa = s.forward(controls.evaluate(s, {}))
    Wb = s.forward(controls.evaluate(s, {"curl_index_L": 1.0}))
    da = np.linalg.norm(Wa[tip][:3, 3] - Wa[wrist][:3, 3])
    db = np.linalg.norm(Wb[tip][:3, 3] - Wb[wrist][:3, 3])
    check("כיפוף אצבע מקרב את קצה האצבע לכף היד", db < da * 0.85, (da, db))
    # IK
    tgt = np.array([0.30, 1.25, 0.34])
    qi = controls.evaluate(s, {}, {"hand_L": {"target": tgt,
                                              "pole": (0.6, 1.0, -0.3)}})
    hw = s.forward(qi)[s.by_name["hand_L"].index][:3, 3]
    check("IF של היד מגיע למטרה", np.linalg.norm(hw - tgt) < 1e-4,
          np.linalg.norm(hw - tgt))
    try:
        controls.evaluate(s, {}, {"אין": {"target": (0, 0, 0)}})
        check("שרשרת IK לא מוכרת נדחית", False)
    except KeyError:
        check("שרשרת IK לא מוכרת נדחית", True)
    # ברירת המחדל: זרועות מורדות, לא צלב
    wrist = s.forward(controls.evaluate(s, {}))[s.by_name["hand_L"].index][:3, 3]
    check("בפוזת ברירת המחדל הזרועות מורדות",
          wrist[1] < s.by_name["chest"].rest[1], wrist)


def t_secondary():
    print("תנועה משנית:")
    sp = Spring(dim=3)
    x = sp.step(np.array([1.0, 0, 0]), 1 / 24)
    check("הקפיץ מתחיל על המטרה ולא קופץ מאפס",
          np.allclose(x, [1, 0, 0]))
    out = [sp.step(np.array([0.0, 0, 0]), 1 / 24) for _ in range(90)]
    check("הקפיץ מתכנס אל המטרה",
          np.linalg.norm(out[-1]) < 1e-3, out[-1])
    check("הקפיץ אינו מתפוצץ",
          all(np.all(np.isfinite(o)) and np.linalg.norm(o) < 5 for o in out))
    s = Skeleton()
    sm = controls.SecondaryMotion()
    q = controls.evaluate(s, {"spine_twist": 1.0})
    q2 = sm.apply(dict(q), 1 / 24)
    check("תנועה משנית שומרת על נורמה 1",
          all(abs(np.linalg.norm(v) - 1) < 1e-6 for v in q2.values()))


def t_mesh_and_weights():
    print("גאומטריה ומשקולות:")
    s = Skeleton()
    mb, meta = basemesh.build(s, {}, quality="fast")
    attrs = basemesh.to_arrays(mb, s)
    n = attrs["position"].shape[0]
    check("יש גאומטריה", n > 500, n)
    check("יש משולשים", attrs["index"].size % 3 == 0 and attrs["index"].size > 0)
    check("כל האינדקסים בתוך הטווח", int(attrs["index"].max()) < n)
    h = identity.weight_health(attrs, s)
    check("סכום המשקולות הוא 1 בכל קודקוד", h["sum_ok"], (h["sum_min"],
                                                          h["sum_max"]))
    check("אין משקולות שליליות", h["negative"] == 0)
    check("4 השפעות לכל היותר", h["max_influences"] == 4)
    check("כל העצמות חוץ מהשורש מקבלות משקולת",
          h["bones_without_weights"] in ([], ["root"]),
          h["bones_without_weights"])
    # הרשת אטומה מספיק: כל קודקוד מופיע בלפחות משולש אחד
    used = np.unique(attrs["index"])
    check("אין קודקודים יתומים", used.size == n, (used.size, n))
    # נורמלים מנורמלים
    ln = np.linalg.norm(attrs["normal"], axis=1)
    check("נורמלים באורך 1", np.allclose(ln, 1.0, atol=1e-4))


def t_identity():
    print("זהות:")
    s = Skeleton()
    mb, _ = basemesh.build(s, {}, quality="fast")
    attrs = basemesh.to_arrays(mb, s)
    lib = controls.pose_library(s)
    poses = {k: controls.evaluate(s, c, ik) for k, (c, ik) in lib.items()}
    check("יש לפחות 5 פוזות", len(poses) >= 5, len(poses))
    rep = identity.identity_report(s, attrs, poses)
    check("אורכי העצמות לא משתנים בין פוזות",
          rep["bone_length_drift"]["max_rel"] < 1e-9,
          rep["bone_length_drift"]["max_rel"])
    check("מידות הפנים לא משתנות בין פוזות",
          rep["face_measure_drift"]["max_rel"] < 1e-9,
          rep["face_measure_drift"]["max_rel"])
    check("שחזור פוזת המנוחה מדויק מתחת לחצי מ\"מ",
          rep["rest_recovery_worst_mm"] < 0.5,
          rep["rest_recovery_worst_mm"])
    check("הפוזות באמת שונות זו מזו",
          rep["pose_separation"]["min_mean_pct"] > 0.5,
          rep["pose_separation"]["min_mean_pct"])
    check("דוח הזהות עובר", rep["passes"])
    # מבחן שלילי. הניסיון הראשון כאן היה לקשור את כל הקודקודים לעצם
    # אחת - והמדד "עבר", **בצדק**: זה פסל נוקשה, והזהות שלו באמת
    # נשמרת. סבוטאז' אמיתי לזהות הוא משקולות מרוחות בין עצמות רחוקות:
    # אז אין אף אזור קשיח שאפשר לשחזר ממנו את צורת המנוחה.
    rng = np.random.default_rng(7)
    bad = {k: v.copy() for k, v in attrs.items()}
    nb = len(s.bones)
    bad["skinIndex"] = rng.integers(0, nb, size=attrs["skinIndex"].shape
                                    ).astype(np.uint16)
    bad["skinWeight"] = np.full(attrs["skinWeight"].shape, 0.25, np.float32)
    rep2 = identity.identity_report(s, bad, poses)
    check("ריג מרוח בכוונה נתפס על ידי המדד", not rep2["passes"],
          rep2["rest_recovery_worst_mm"])
    check("מדד הסחיפה מזהה מדידה שהשתנתה",
          identity.drift([{"a": 1.0}, {"a": 1.2}])["max_rel"] > 0.05)


def t_identity_audit():
    """ביקורת זהות הצוות - הממד שמדידת הפרויקט קוראת לו "זהות הדמות".

    **הבאג שהוליד את הבדיקה (08/10/2026).** הממד הזה הציג 100 בכל
    מדידה שמורה בפרויקט, אבל הוא נגזר **כולו** מ-`dimorph.audit_shape`
    - שבע בדיקות של שפת הצורות. כלומר הממד ששמו "זהות" לא שאל אף
    פעם אם הדמות נשארת אותה דמות אחרי שהיא זזה. במקביל ה-``detail``
    שלו חזר ריק (``{'pairs': {}}``) בכל חמשת הדוחות השמורים, כי
    הקורא ביקש מפתחות ``pair``/``shape`` שאינם קיימים בתוצאה -
    ולכן גם אי אפשר היה לראות בדיעבד שלא נמדד כלום.
    """
    print("ביקורת זהות הצוות:")
    a = identity.audit(quality="fast")
    check("כל ארבע דמויות הצוות נמדדות",
          sorted(a["per_character"]) == sorted(identity.AUDIT_NAMES),
          sorted(a["per_character"]))
    check("שמונה בדיקות זהות, לא אפס", len(a["checks"]) == 8,
          len(a["checks"]))
    check("לכל דמות יש פרטים מדידים ולא מילון ריק",
          all(r.get("verts", 0) > 500 and r.get("poses")
              for r in a["per_character"].values()),
          {k: r.get("verts") for k, r in a["per_character"].items()})
    check("ביקורת הזהות עוברת על הצוות הנוכחי", a["passed"], a["problems"])

    # --- מבחנים שליליים. בלעדיהם "עובר" כאן אינו אומר דבר: מודד
    # שמחזיר 100 גם כשהזהות שבורה הוא בדיוק הבאג שתוקן כאן.
    orig = controls.evaluate
    try:
        # כל הפוזות זהות -> אין הפרדה, ולכן "אפס סחיפה" חסר ערך.
        controls.evaluate = lambda sk, ctl, ik=None: orig(sk, {}, None)
        bad = identity.audit(quality="fast", names=("lucas",))
    finally:
        controls.evaluate = orig
    check("פוזות זהות נתפסות בהפרדת הפוזות",
          not bad["checks"]["pose_separation_pct"]["pass"],
          bad["checks"]["pose_separation_pct"]["value"])

    orig_bl = identity.bone_lengths
    try:
        seq = [0]

        def _drifty(sk, q=None):
            d = dict(orig_bl(sk, q))
            seq[0] += 1
            k = sorted(d)[0]
            d[k] = d[k] * (1.0 + 0.01 * seq[0])
            return d

        identity.bone_lengths = _drifty
        bad2 = identity.audit(quality="fast", names=("lucas",))
    finally:
        identity.bone_lengths = orig_bl
    check("אורך עצם שנמתח בפוזה נתפס",
          not bad2["checks"]["bone_length_drift"]["pass"],
          bad2["checks"]["bone_length_drift"]["value"])

    # דמות שהמדידה שלה נפלה אינה דמות שעברה. זו ההבחנה שמונעת
    # "100" על ביקורת שבעצם לא מדדה כלום.
    bad3 = identity.audit(quality="fast", names=("lucas", "אין_דמות_כזאת"))
    check("דמות שלא נמדדה מפילה את הביקורת ולא נעלמת",
          not bad3["passed"]
          and not bad3["checks"]["all_characters_measured"]["pass"],
          bad3["problems"][:1])


def t_glb():
    print("קובץ GLB:")
    s = Skeleton()
    mb, _ = basemesh.build(s, {}, quality="fast")
    attrs = basemesh.to_arrays(mb, s)
    col = np.tile(np.array([[0.8, 0.6, 0.5]], np.float32),
                  (attrs["position"].shape[0], 1))
    with tempfile.TemporaryDirectory() as d:
        p = Path(d) / "t.glb"
        info = glbio.write_skinned_glb(p, attrs, s, color=col)
        check("הקובץ נכתב", p.exists() and p.stat().st_size > 1000, info)
        js, bin_ = glbio.read_glb(p)
        check("יש skin בקובץ", len(js.get("skins", [])) == 1)
        check("מספר המפרקים תואם את השלד",
              len(js["skins"][0]["joints"]) == len(s.bones))
        prim = js["meshes"][0]["primitives"][0]
        for a in ("POSITION", "NORMAL", "JOINTS_0", "WEIGHTS_0", "COLOR_0"):
            check(f"יש מאפיין {a}", a in prim["attributes"])
        check("ל-POSITION יש min/max",
              "min" in js["accessors"][prim["attributes"]["POSITION"]])
        for i, bv in enumerate(js["bufferViews"]):
            check(f"bufferView {i} מיושר ל-4 בתים",
                  bv.get("byteOffset", 0) % 4 == 0)
        # קריאה חוזרת של המשקולות
        w = glbio.accessor(js, bin_, prim["attributes"]["WEIGHTS_0"])
        check("המשקולות בקובץ מסתכמות ל-1",
              np.allclose(w.sum(axis=1), 1.0, atol=1e-4))
        ji = glbio.accessor(js, bin_, prim["attributes"]["JOINTS_0"])
        check("אינדקסי המפרקים בתוך הטווח", int(ji.max()) < len(s.bones))
        ibm = glbio.accessor(js, bin_, js["skins"][0]["inverseBindMatrices"])
        check("inverseBindMatrices בגודל הנכון", ibm.shape == (len(s.bones), 16))
        # הצומת של הרשת אינה בת של מפרק
        joints = set(js["skins"][0]["joints"])
        kids = {c for nd in js["nodes"] for c in nd.get("children", [])}
        mesh_nodes = [i for i, nd in enumerate(js["nodes"]) if "mesh" in nd]
        check("צומת הרשת אינה בת של מפרק",
              all(i not in kids or i not in joints for i in mesh_nodes))

    # ---- חומרים (05/10): שיער בחומר אחד עם העור יוצא פלסטיק מבריק.
    # roughnessFactor=0.55 הוא הטווח שבו אור מכוון מייצר הבהק לבן
    # רחב, ועל שיער כהה זה נקרא בתקריב כפלסטיק יצוק.
    with tempfile.TemporaryDirectory() as d:
        p = Path(d) / "m.glb"
        info = glbio.write_skinned_glb(p, attrs, s, color=col,
                                       tags=list(mb.tag),
                                       morphs=None)
        js, _ = glbio.read_glb(p)
        names = [m["name"] for m in js["materials"]]
        check("הדמות נכתבת ביותר מחומר אחד", len(names) >= 3, names)
        rough = {m["name"]: m["pbrMetallicRoughness"]["roughnessFactor"]
                 for m in js["materials"]}
        check("השיער מט משמעותית מהעור",
              rough["hair"] - rough["skin"] > 0.15, rough)
        check("גלגל העין הוא החלק המבריק בדמות",
              rough["eye"] < 0.2 < rough["skin"], rough)
        check("להבהק השיער יש גם עוצמה מונמכת",
              any("KHR_materials_specular" in m.get("extensions", {})
                  for m in js["materials"]
                  if m["name"] == "hair"))
        check("הסיומת מוכרזת כאופציונלית בלבד",
              "KHR_materials_specular" in js.get("extensionsUsed", [])
              and "extensionsRequired" not in js)
        prims = js["meshes"][0]["primitives"]
        check("יש primitive לכל חומר", len(prims) == len(names), len(prims))
        # אפס שכפול: כל ה-primitives חולקים בדיוק את אותם accessors
        check("ה-primitives חולקים את אותם קודקודים",
              len({json.dumps(pr["attributes"], sort_keys=True)
                   for pr in prims}) == 1)
        check("לכל primitive index אחר",
              len({pr["indices"] for pr in prims}) == len(prims))
        tot = sum(js["accessors"][pr["indices"]]["count"] for pr in prims)
        check("סך המשולשים נשמר אחרי הפיצול",
              tot == int(attrs["index"].size), (tot, int(attrs["index"].size)))
        hp = [pr for pr, nm in zip(prims, [names[pr["material"]]
                                           for pr in prims]) if nm == "hair"]
        check("לשיער יש משולשים משל עצמו",
              bool(hp) and js["accessors"][hp[0]["indices"]]["count"] > 300,
              js["accessors"][hp[0]["indices"]]["count"] if hp else 0)

    # צורות הפנים הן תכונה של ה-primitive ולא של ה-mesh. primitive
    # בלי targets לא זז כשהפנים משחקות, כלומר השיער היה קופא בזמן
    # שהפנים נעות - פגם שקט שאין עליו שום שגיאה.
    with tempfile.TemporaryDirectory() as d:
        n = attrs["position"].shape[0]
        mo = {"names": ["t0"], "deltas": np.zeros((1, n, 3), np.float32)}
        p = Path(d) / "mm.glb"
        glbio.write_skinned_glb(p, attrs, s, color=col, tags=list(mb.tag),
                                morphs=mo)
        js, _ = glbio.read_glb(p)
        prims = js["meshes"][0]["primitives"]
        check("כל primitive מקבל את צורות הפנים",
              all("targets" in pr and len(pr["targets"]) == 1 for pr in prims))
        check("הדלתות אינן משוכפלות בין ה-primitives",
              len({pr["targets"][0]["POSITION"] for pr in prims}) == 1)


def t_pipeline():
    print("צינור מלא:")
    with tempfile.TemporaryDirectory() as d:
        r = pipeline.build_character("בדיקה", d, quality="fast")
        check("נבנה GLB", Path(r["glb_info"]["path"]).exists())
        check("נכתב קובץ ריג",
              (Path(d) / "בדיקה.rig.json").exists())
        check("הדוח כולל בקרות", len(r["controls"]) >= 60)
        check("הדוח כולל שרשראות IK", len(r["ik_chains"]) == 4)
        check("הזהות עוברת", r["identity"]["geometry_drift"]["passes"],
              r["identity"]["geometry_drift"]["max_rel_drift"])
        check("כל הפוזות סופיות",
              all(v["finite"] for v in r["pose_report"].values()))


def t_foreground():
    print("זיהוי רקע:")
    a = np.full((200, 160, 3), 0.95)
    a += np.linspace(-0.02, 0.02, 200)[:, None, None]      # רקע מדורג
    a[60:140, 60:100] = [0.3, 0.2, 0.15]
    m = pipeline.foreground_mask(a)
    frac = m.mean()
    check("רקע מדורג אינו נספר כדמות", 0.05 < frac < 0.15, frac)
    ys, xs = np.nonzero(m)
    check("תיבת הדמות נכונה",
          abs(int(ys.min()) - 60) <= 2 and abs(int(xs.max()) - 99) <= 2,
          (ys.min(), ys.max(), xs.min(), xs.max()))


def t_showreel():
    """סרטון ההדגמה. כל מקרה כאן נולד ממה שנראה בפריימים ב-05/10."""
    print("סרטון ההדגמה:")
    from rig import showreel

    s = Skeleton()
    floor = showreel.rest_floor(s)
    lib = controls.pose_library(s)

    # הדמות מרחפת: שורש הדמות אינו זז עם הפוזה, ולכן בכפיפה כפות
    # הרגליים עולות מעל הרצפה והצל נשאר למטה.
    q_rest = controls.evaluate(s, *lib["rest"])
    q_crouch = controls.evaluate(s, *lib["crouch"])
    off_rest = showreel.ground_offset(s, q_rest, floor)
    off_crouch = showreel.ground_offset(s, q_crouch, floor)
    check("פוזת מנוחה אינה זזה אנכית", abs(off_rest) < 1e-9, off_rest)
    check("כפיפה מקבלת היסט שלילי לרצפה", off_crouch < -0.02, off_crouch)
    idx = showreel._foot_idx(s)
    W = s.forward(q_crouch)
    check("אחרי ההיסט כפות הרגליים חוזרות לקו הרצפה",
          abs((W[idx, 1, 3].min() + off_crouch) - floor) < 1e-9)
    # root יושבת על y=0 בכל פוזה; מינימום על כל העצמות מחזיר 0 תמיד
    check("ההיסט אינו נגזר מעצם השורש",
          abs(float(s.forward(q_crouch)[:, 1, 3].min())) < 1e-9
          and abs(off_crouch) > 1e-6, off_crouch)

    # מיזוג פוזות: שמות העצמות מתאחדים, ועצם שחסרה באחת הפוזות היא
    # סיבוב יחידה - בדיוק כמו שהצופה מתנהג.
    mid = showreel.blend_q(q_rest, q_crouch, 0.5)
    check("המיזוג מכסה את כל העצמות משתי הפוזות",
          set(mid) == set(q_rest) | set(q_crouch))
    check("קוורטניוני המיזוג מנורמלים",
          max(abs(float(np.linalg.norm(v)) - 1) for v in mid.values()) < 1e-6)
    check("מיזוג ב-0 מחזיר את הפוזה הראשונה",
          all(np.allclose(mid0, q_rest.get(k, [0, 0, 0, 1]))
              for k, mid0 in showreel.blend_q(q_rest, q_crouch, 0.0).items()))

    # מחזור הפוזות: החזקה ואז מעבר - בלי ההחזקה הדמות לא עוצרת באף פוזה
    libq = {k: controls.evaluate(s, *lib[k]) for k in ("rest", "crouch")}
    order = ["rest", "crouch"]
    held = showreel._cycle_pose(libq, order, 0.10)     # בתוך ההחזקה
    check("בתחילת הקטע הדמות עומדת בפוזה",
          np.allclose(held["hips"], libq["rest"].get(
              "hips", np.array([0.0, 0.0, 0.0, 1.0])), atol=1e-9))
    moved = showreel._cycle_pose(libq, order, 0.45)    # אחרי ההחזקה
    check("בהמשך הקטע הפוזה באמת מתחלפת",
          not np.allclose(moved["hips"], held["hips"], atol=1e-6))

    # ציר הזמן: כל סצנה חייבת אורך חיובי ותיאור של מה היא מוכיחה
    shots = showreel.build_shots(1.7, lib, lib)
    check("לפחות שש סצנות בציר הזמן", len(shots) >= 6, len(shots))
    keys = [sh.key for sh in shots]
    check("יש סצנת תקריב פנים לכל אחת מהדמויות",
          "closeup_maya" in keys and "closeup_lucas" in keys, keys)
    check("לכל סצנה כתובית ומשפט הוכחה",
          all(sh.cap and sh.sub and sh.proves for sh in shots))
    check("כל הסצנות ארוכות מהחשכת החיתוך",
          all(sh.secs > 2 * showreel.FADE for sh in shots))
    # ההחשכה חייבת להיות 1 בקצוות ו-0 באמצע, אחרת החיתוך נראה כקפיצה
    sh = shots[0]
    check("החשכה מלאה בתחילת הסצנה",
          showreel._fade_at(0.0, sh.secs) == 1.0)
    check("אין החשכה באמצע הסצנה",
          showreel._fade_at(sh.secs / 2, sh.secs) == 0.0)
    check("הכתובית מוסתרת בזמן ההחשכה",
          showreel._cap_opacity(0.0, sh.secs) == 0.0
          and showreel._cap_opacity(sh.secs, sh.secs) == 0.0)

    # הזרועות: 0.80 השאיר אותן פרושות ב-34 מעלות מהגוף (בובת ראווה)
    check("זרועות המנוחה צמודות לגוף",
          showreel.idle(0.0)["arm_down_L"] >= 0.90)
    # מצמוץ בסינוס נראה כמו ישנוניות; הוא חייב להיות אפס רוב הזמן
    b = [showreel.blink(i / 30.0) for i in range(93)]
    check("המצמוץ קצר ולא רציף",
          sum(1 for v in b if v > 0.05) < len(b) * 0.2 and max(b) > 0.9,
          (sum(1 for v in b if v > 0.05), round(max(b), 2)))

    # כל בקרה שהסצנות משתמשות בה חייבת להיות קיימת בריג, אחרת
    # controls.normalize זורק רק בזמן הרנדור - אחרי שלוש דקות עבודה
    bad = []
    for sh in shots:
        for fn in (sh.a, sh.b):
            for t in (0.0, 1.3, 3.7):
                try:
                    ctl, ik = fn(t / max(sh.secs, 1e-6), t)
                    controls.normalize(ctl)
                    controls.evaluate(s, ctl, ik)
                except Exception as e:                   # noqa: BLE001
                    bad.append(f"{sh.key}:{type(e).__name__}:{e}")
    check("כל הסצנות מריצות בקרות תקפות", not bad, bad[:3])



def t_detail():
    """תווי הפנים והשיער כגאומטריה. כל מקרה כאן נולד מתקלה שנראתה
    בפועל בתקריב ב-05/10, ולא מדמיון."""
    print("תווי פנים ושיער:")
    s = Skeleton(head_scale=1.1)
    mb, meta = basemesh.build(s, {"hair_len": 0.9})
    groups = {g[0]: (g[1], g[2]) for g in mb.groups}
    need = ["hair_cap", "lip_up", "lip_lo", "mouth_bag", "brow_geo_L",
            "lash_R", "cornea_L", "eyelid_up_L", "eyelid_lo_R", "ear_L"]
    check("כל תווי הפנים קיימים כגאומטריה נפרדת",
          all(n in groups for n in need),
          [n for n in need if n not in groups])
    check("נבנו מנעולי שיער לשיער ארוך",
          sum(1 for n in groups if n.startswith("hair_lock")) >= 8,
          sum(1 for n in groups if n.startswith("hair_lock")))
    h0, h1 = groups["head"]
    check("צפיפות הראש מספיקה לתקריב", h1 - h0 >= 10000, h1 - h0)
    check("כל קודקודי הראש מתויגים לצבע",
          all(mb.tag[i] is not None for i in range(h0, h1)))

    v = np.asarray(mb.v)
    P = {b.name: np.asarray(b.rest, float) for b in s.bones}
    H = detail.Head(P, s.height / 1.70, {})
    hv = v[h0:h1] - H.hc
    hr = np.linalg.norm(hv, axis=1)
    hu = hv / hr[:, None]

    def protrusion(name):
        a, b = groups[name]
        d = v[a:b] - H.hc
        r = np.linalg.norm(d, axis=1)
        j = np.argmax((d / r[:, None]) @ hu.T, axis=1)
        return (r - hr[j]) * 1000

    # הבדיקה שתפסה את התקלה הגדולה: גלגל העין היה 10.7 מ"מ **בתוך**
    # הגולגולת, כלומר לדמות לא היו עיניים בכלל - רק שני כתמים אפלים,
    # וזה עבר את כל 83 הבדיקות הקודמות ואת כל 14 קריטריוני הקבלה.
    cor = protrusion("cornea_L")
    check("הקשתית בולטת מעל פני הראש (יש עיניים)",
          float(cor.max()) > 0.5, round(float(cor.max()), 2))
    check("הקשתית אינה בולטת כמו כדור", float(cor.max()) < 9.0,
          round(float(cor.max()), 2))
    check("הגבה יושבת על פני הראש ולא בתוכו",
          float(np.median(protrusion("brow_geo_L"))) > 0.0)
    check("חלל הפה כולו בתוך הראש",
          float(protrusion("mouth_bag").max()) < 0.0,
          round(float(protrusion("mouth_bag").max()), 2))

    # ---- מקרים שנולדו מהתקריב של 05/10 (סבב שלישי): הגבות והשיער
    # יצאו גסים גם אחרי הסבב השני. שתי סיבות נמדדו, לא נוחשו:
    # הגבה הייתה צינור **בודד** בחתך קבוע (נקרא כתולעת פלסטיק), ובחזית
    # לא הייתה שום גאומטריית שיער - רק החלק הקדמי של הכובע, שהוא
    # אליפסואיד חלק לחלוטין ונקרא כקסדה צבועה.
    pr = detail.skin_probe(mb, H)

    n_str = sum(1 for n in groups if n.startswith("brow_hair_L"))
    check("הגבה היא מסת שערות ולא צינור בודד", n_str >= 5, n_str)

    # עובי המסה **בניצב** לכיוון הגבה. המדידה הראשונה כאן מדדה מרחק
    # לכל הכיוונים, כולל לאורך הגבה - ואז "עובי" של 4.6 מ"מ היה בעצם
    # הפריסה האורכית, והבדיקה לא הרגישה בכלל לשינוי העובי האמיתי.
    def brow_perp(t: float) -> float:
        a, b = groups["brow_geo_L"]
        bv = v[a:b]
        c = detail._brow_ridge(H, "L", t, 0.0, pr)
        c1 = detail._brow_ridge(H, "L", min(1.0, t + 0.05), 0.0, pr)
        c0 = detail._brow_ridge(H, "L", max(0.0, t - 0.05), 0.0, pr)
        tg = c1 - c0
        tg = tg / max(1e-12, float(np.linalg.norm(tg)))
        d = bv - c
        al = d @ tg
        perp = np.linalg.norm(d - al[:, None] * tg, axis=1)
        sel = np.abs(al) < H.R * 0.035
        return float(np.median(perp[sel]) * 1000) if sel.any() else -1.0

    mid, tail = brow_perp(0.45), brow_perp(0.92)
    check("זנב הגבה מתחדד ואינו פס בעובי אחיד",
          0.0 < tail < mid * 0.80, (round(mid, 2), round(tail, 2)))
    # המקרה שנתפס **בעין ברנדור ולא כאן**: פירוק הצינור לשערות הקטין
    # את המסה - פי שלושה דקה מהצינור שהוחלף. "יש מרקם" ו"מתחדד" עברו
    # שניהם. גודל המסה הוא תנאי נפרד, והוא נמדד כ**גובה** ולא כמרחק
    # חציוני מהעקום: במסה מלאה החציון מוטה כלפי מטה בגלל השערות
    # הפנימיות, ולכן הוא אינו מדד לגודל הנראה.
    def brow_height(t: float) -> float:
        a, b = groups["brow_geo_L"]
        bv = v[a:b]
        c = detail._brow_ridge(H, "L", t, 0.0, pr)
        c1 = detail._brow_ridge(H, "L", min(1.0, t + 0.05), 0.0, pr)
        c0 = detail._brow_ridge(H, "L", max(0.0, t - 0.05), 0.0, pr)
        tg = c1 - c0
        tg = tg / max(1e-12, float(np.linalg.norm(tg)))
        al = (bv - c) @ tg
        sel = np.abs(al) < H.R * 0.035
        if not sel.any():
            return -1.0
        yy = bv[sel][:, 1]
        return float(yy.max() - yy.min()) * 1000

    hgt = brow_height(0.45)
    check("מסת הגבה בגובה של גבה אמיתית ונראית בתקריב", hgt >= 5.0,
          round(hgt, 2))
    # **המקרה שהפיל את כל הסבב הזה.** הגבה נמדדה 38.6 מ"מ מעל מרכז
    # העין ו-1.6 מ"מ מעל קו השיער, כלומר היא הייתה קבורה בתוך מסת
    # השיער ולשתי הדמויות לא נראו גבות בתקריב. הסיבה: היסט של 4 מ"מ
    # מהעצם ועוד הקרנה על פני הראש, שמעלה את הגובה לפי הכיוון. אף
    # אחת מהבדיקות על צורת הגבה לא יכלה לתפוס את זה - הגבה הייתה
    # מושלמת, היא פשוט לא הייתה במקום שבו מסתכלים.
    bL = v[groups["brow_geo_L"][0]:groups["brow_geo_L"][1]]
    eyeL = H.eye_center("L")
    above_eye = (float(bL[:, 1].mean()) - float(eyeL[1])) * 1000
    check("הגבה יושבת מעל העין ולא רחוק ממנה",
          8.0 < above_eye < 30.0, round(above_eye, 1))
    uf = np.array([0.0, 0.0, 1.0])
    yh = H.hairline(uf)
    y_hair = float(H.surf(np.array([0.0, yh, (1 - yh * yh) ** 0.5]))[1])
    gap_hair = (y_hair - float(bL[:, 1].max())) * 1000
    check("הגבה נמצאת מתחת לקו השיער ולא בתוכו",
          gap_hair > 4.0, round(gap_hair, 1))

    pb = protrusion("brow_geo_L")
    check("כל שערת גבה יושבת מעל העור ולא נקברת בו",
          float(pb.min()) > 0.5, round(float(pb.min()), 2))
    check("לגבה יש מרקם ולא משטח חלק", float(pb.std()) > 0.25,
          round(float(pb.std()), 2))

    n_fr = sum(1 for n in groups if n.startswith("hair_fringe"))
    check("יש קווצות שיער בחזית (לא רק כובע חלק)", n_fr >= 7, n_fr)
    if n_fr:
        brow_top = max(float(P[f"brow_{a}_{sd}"][1])
                       for a in ("in", "out") for sd in ("L", "R"))
        lo = min(float(v[a:b][:, 1].min())
                 for n, (a, b) in groups.items() if n.startswith("hair_fringe"))
        # האזהרה מ-_add_locks: מנעול שיורד בחזית נופל על הפנים. כאן
        # האורך נגזר מגובה הגבה **ונקטם בפועל**, ולכן חייב להישאר
        # מרווח חיובי גם בראש רחב ובשיער ארוך.
        check("קווצות החזית עוצרות מעל הגבה ואינן מכסות את הפנים",
              lo > brow_top, round(1000 * (lo - brow_top), 2))
        pfr = np.concatenate([protrusion(n) for n in groups
                              if n.startswith("hair_fringe")])
        # ההיסט נמדד מעל **העור שנבנה בפועל**. מול האליפסואיד לבדו
        # נמדד שהקווצות ישבו 10.8 מ"מ בתוך המצח, כלומר נעלמו.
        check("קווצות החזית נשענות על העור ולא שקועות בתוכו",
              float(np.median(pfr)) > 2.0 and float(pfr.min()) > -4.0,
              (round(float(np.median(pfr)), 2), round(float(pfr.min()), 2)))
        # --- הפוני כשכבה ולא כשורת משולשים (05/10, סבב חמישי)
        check("הפוני בנוי בשתי שכבות ולא בשורה אחת",
              any(n.startswith("hair_fringe_0") for n in groups) and
              any(n.startswith("hair_fringe_1") for n in groups),
              sorted({n[:15] for n in groups if n.startswith("hair_fringe")}))
        air_new = detail.fringe_air(mb, H)
        # שכבת ההשוואה נבנית על **אותה דמות בדיוק**, ולכן ההפרש הוא
        # של הגאומטריה ולא של הראש או של גובה הגבה.
        detail._add_fringe(mb, H, legacy=True)
        air_old = detail.fringe_air(mb, H, "hair_fringe_9")
        check("אוויר בין קווצות פוני שכנות - מעט",
              air_new["air_frac"] < 0.35, air_new)
        # זו הבדיקה שתופסת חזרה אחורה: המראה של "משולשים שטוחים
        # נפרדים" הוא בדיוק air_frac גבוה, והוא נמדד ב-0.71 בגרסה
        # שהייתה כאן. שיפור של פחות מפי שניים אינו תיקון.
        check("ופחות מחצי מזה שהיה בפוני של הסבב הקודם",
              air_new["air_frac"] < air_old["air_frac"] * 0.5,
              (air_new["air_frac"], air_old["air_frac"]))
        check("ויש יותר קווצות פוני מקודם (צפיפות + שכבה)",
              air_new["strands"] > air_old["strands"],
              (air_new["strands"], air_old["strands"]))

    # חריצי המסרק על הכובע: בלי שונות בעובי הכובע הוא אליפסואיד
    pcap = protrusion("hair_cap")
    check("לכובע השיער יש חריצי קווצות ולא עובי אחיד",
          float(pcap.std()) > 1.5, round(float(pcap.std()), 2))

    # ---- מקרים שנולדו מהתקריב של 05/10 (סבב שני) ----
    head = v[h0:h1]
    relx = np.abs(head[:, 0] - H.hc[0]) / H.R
    rely = (head[:, 1] - H.hc[1]) / H.R

    # (1) "הקשתית בולטת" לא מספיק: אפשר שהיא בולטת מהכדור ובכל זאת
    # קבורה מתחת לעור שסביבה. זה בדיוק מה שקרה כשהוקטנה הארובה -
    # הקרנית ישבה 1.6 מ"מ מאחורי העור ולשתי הדמויות לא היו עיניים.
    eL = H.eye_center("L")
    near = np.linalg.norm(head[:, :2] - eL[:2], axis=1) < 0.008 * H.k
    ca, cb = groups["cornea_L"]
    cor_z = float(v[ca:cb, 2].max())
    skin_z = float(head[near, 2].max()) if near.any() else -9.0
    check("הקרנית לפני העור שסביבה ולא קבורה מתחתיו",
          cor_z - skin_z > 0.0008, round((cor_z - skin_z) * 1000, 2))
    check("הקרנית אינה כדור מודבק על הפנים",
          cor_z - skin_z < 0.008, round((cor_z - skin_z) * 1000, 2))

    # (2) באג היחידות של האף: "גשר האף" ו"קצה האף" נקראו ב-y_rel
    # (0=סנטר) בעוד כל שאר תווי הפנים ב-rel_y (0=מרכז הראש). לכן האף
    # נבנה בפועל **על הסנטר**: לא היה אף, והיה רכס אנכי מהשפה לסנטר.
    mid = relx < 0.25
    fy = rely[mid][int(np.argmax(head[mid, 2]))]
    check("הנקודה הקדמית ביותר בפנים היא האף ולא הסנטר",
          -0.22 < float(fy) < 0.10, round(float(fy), 3))
    nose_z = float(head[mid, 2].max())
    chin = mid & (rely < -0.45)
    check("אין רכס אנכי שבולט על הסנטר",
          nose_z - float(head[chin, 2].max()) > 0.006,
          round((nose_z - float(head[chin, 2].max())) * 1000, 1))

    # (3) יחידת המידה של הפנים היא **הראש ולא הגוף**: למאיה ראש רחב
    # ב-20%, ובלי זה גלגל העין, האף והשפתיים נשארו בגודל הבסיס והיא
    # יצאה בתקריב עם עיניים קטנטנות ואף זעיר על ראש גדול.
    def cornea_span(hs):
        s2 = Skeleton(head_scale=hs)
        mb2, _ = basemesh.build(s2, {"hair_len": 0.9})
        g2 = {g[0]: (g[1], g[2]) for g in mb2.groups}
        a2, b2 = g2["cornea_L"]
        w = np.asarray(mb2.v)[a2:b2]
        return float(w[:, 0].max() - w[:, 0].min())
    r10, r125 = cornea_span(1.0), cornea_span(1.25)
    check("תווי הפנים גדלים יחד עם רוחב הראש",
          abs(r125 / r10 - 1.25) < 0.04, round(r125 / r10, 3))

    # (4) תספורת צמודה: מנעול באורך 2 ס"מ שנתלה מהעורף בלט בתקריב
    # של לוקאס כגוש שחור מנותק ליד האוזן.
    mb3, _ = basemesh.build(Skeleton(), {"hair_len": 0.03})
    n_lock = sum(1 for g in mb3.groups if g[0].startswith("hair_lock"))
    check("שיער קצר מאוד נבנה בלי מנעולים תלויים", n_lock == 0, n_lock)

    # (4ב) **הקווצות הארוכות בצדדים היו קו ישר אנכי.** הגרסה הקודמת
    # קבעה y = anchor - length*s והזיזה את x,z רק ב-6.5%, ולכן נמדדה
    # סטייה של פחות מ-2% מהמֶתר (הקו הישר בין העוגן לקצה). שיער
    # אמיתי הוא 8-20%. זו הייתה כל ה"ישרות" שנראתה בצדדים.
    def lock_axes(mbx, seg=8):
        gx = {g[0]: (g[1], g[2]) for g in mbx.groups}
        vx = np.asarray(mbx.v)
        out = []
        for nm in sorted(n for n in gx if n.startswith("hair_lock")):
            a, b = gx[nm]
            nring = (b - a - 2) // seg          # שתי נקודות מרכז לכיסויים
            if nring < 4:
                continue
            out.append(np.array([vx[a + k * seg: a + (k + 1) * seg].mean(axis=0)
                                 for k in range(nring)]))
        return out
    ax_list = lock_axes(mb)
    check("יש קווצות ארוכות למדידה", len(ax_list) >= 8, len(ax_list))
    devs = []
    for axis in ax_list:
        d = axis[-1] - axis[0]
        L = float(np.linalg.norm(d))
        d = d / L
        w = axis - axis[0]
        perp = w - np.outer(w @ d, d)
        devs.append(float(np.linalg.norm(perp, axis=1).max() / L))
    check("קווצה ארוכה אינה קו ישר (סטייה מהמתר)",
          float(np.median(devs)) > 0.045, round(float(np.median(devs)), 4))
    check("הקווצה גם אינה מתפתלת עד כדי קשר",
          max(devs) < 0.40, round(max(devs), 4))
    # הקווצות אינן מתואמות: אם כולן מתעקמות לאותו צד באותו גובה זה
    # נראה כמסרק ולא כשיער. הפאזה מפוזרת בזווית הזהובה.
    nmin = min(len(a) for a in ax_list)
    mid = np.array([a[nmin // 2] - a[0] for a in ax_list])
    rad = np.array([float(np.linalg.norm(m)) for m in mid])
    check("הקווצות אינן מתואמות זו לזו",
          float(np.std(rad) / max(1e-9, np.mean(rad))) > 0.05,
          round(float(np.std(rad) / max(1e-9, np.mean(rad))), 3))
    # הקווצה "מחבקת" את הגולגולת ואינה נבלעת בה: כל נקודה בציר
    # חייבת להיות מחוץ לאליפסואיד הראש (q>=1), פרט לעוגן שיושב על
    # פני הראש עצמו ומוסתר בכובע.
    axes_h = np.array([H.scale[0] * H.R, H.scale[1] * H.R, H.scale[2] * H.R])
    qmin = min(float(np.sqrt((((a[1:] - H.hc) / axes_h) ** 2).sum(axis=1)).min())
               for a in ax_list)
    check("קווצה אינה נבלעת בתוך הגולגולת", qmin > 1.0, round(qmin, 4))

    # (4ג) **השיער בצדדים נראה כמסה אחת ולא כקווצות נפרדות.**
    # זה נראה ברנדור אחרי הסבב הרביעי, וזה היה נכון: 31 קווצות
    # בפיזור אזימוטלי אחיד, כולן באורך ±14% מהבסיס. הן נגעו זו בזו
    # לכל אורכן, והקצוות נפלו באותו גובה - כלומר משטח רציף בלי שום
    # חור. העין קוראת חור, לא איכות של קווצה בודדת.
    # שלוש המדידות שמוכיחות הפרדה, וכל אחת מהן נופלת בנפרד:
    anc = np.array([a[0] for a in ax_list])
    tip = np.array([a[-1] for a in ax_list])
    th_a = np.sort(np.arctan2(anc[:, 2] - H.hc[2], anc[:, 0] - H.hc[0]))
    gps = np.diff(th_a)
    med = float(np.median(gps))
    # (א) רווחי אוויר אזימוטליים. הרווח הגדול ביותר הוא תמיד החזית
    # (אין שם מנעולים בכלל), ולכן הוא **מוחרג** - אחרת המדידה הייתה
    # עוברת גם בפיזור אחיד לגמרי.
    inner = [float(g) for g in gps if g < 1.0]
    wide = sum(1 for g in inner if g > 1.8 * med)
    check("יש רווחי אוויר בין אשכולות הקווצות", wide >= 2,
          (wide, round(med, 4)))
    # (ב) שכבות אורך: הקצוות אינם מסתדרים לקו אחד.
    Ln = np.array([float(np.linalg.norm(a[-1] - a[0])) for a in ax_list])
    spread = float(tip[:, 1].std() / max(1e-9, Ln.mean()))
    check("קצות הקווצות מפוזרים בגובה (תספורת שכבות)", spread > 0.15,
          round(spread, 3))
    # (ג) איסוף: הקצה של קווצה קרוב לשכן שלו בתוך האשכול, ורחוק
    # מהאשכול הבא. זה מה שהופך אוסף קווצות דקות לקווצות **נראות**.
    dd = np.linalg.norm(tip[:, None, :] - tip[None, :, :], axis=2)
    np.fill_diagonal(dd, 1e9)
    coh = float(dd.min(axis=1).mean() / max(1e-9, np.median(dd[dd < 1e8])))
    check("הקווצות נאספות לאשכולות ולא מתפזרות אחיד", coh < 0.45,
          round(coh, 3))

    # (5) קו שיער חלק לחלוטין נקרא בתקריב ככובע ים. חייבת להיות בו
    # פסגת אלמנה (שקע במרכז המצח) וגליות על האזימוט.
    def hl_at(th):
        return H.hairline(np.array([math.sin(th), 0.35, math.cos(th)]))
    check("קו השיער יורד במרכז המצח (פסגת אלמנה)",
          hl_at(0.0) < min(hl_at(0.30), hl_at(-0.30)),
          (round(hl_at(0.0), 4), round(hl_at(0.30), 4)))
    ths = [-0.9 + 0.1 * i for i in range(19)]
    check("קו השיער אינו קשת מושלמת",
          float(np.std([hl_at(t) for t in ths])) > 0.004,
          round(float(np.std([hl_at(t) for t in ths])), 4))

    # כיוון הפאות: כובע השיער נבנה מלמטה למעלה, הפוך מ-sphere(), ועם
    # הסדר של הכדור כל הכובע יצא הפוך ונחתך ברנדור בלי שום שגיאה.
    attrs = basemesh.to_arrays(mb, s)
    a, b = groups["hair_cap"]
    nrm = attrs["normal"][a:b]
    out = v[a:b] - H.hc
    out = out / np.linalg.norm(out, axis=1, keepdims=True)
    dot = float(np.mean(np.sum(nrm * out, axis=1)))
    check("הנורמלים של כובע השיער פונים החוצה", dot > 0.5, round(dot, 3))

    # שיער ארוך שכולו קשור לראש מסתובב כמו לוח עץ וחוצה את הכתף
    lock = [n for n in groups if n.startswith("hair_lock")]
    lo = min(groups[n][0] for n in lock)
    hi = max(groups[n][1] for n in lock)
    names = {b.index: b.name for b in s.bones}
    bones_used = set()
    for i in range(lo, hi):
        bones_used |= set(mb.w[i])
    check("שיער ארוך נגרר גם מהצוואר והחזה",
          {"neck", "chest"} <= bones_used, sorted(bones_used))

    # מרחב צבע: COLOR_0 הוא לינארי, והצבעים נדגמים מתמונת sRGB
    lin = pipeline._to_linear(np.array([[0.5, 0.5, 0.5]]))
    check("הצבע מומר ל-מרחב לינארי", 0.18 < float(lin[0, 0]) < 0.25,
          round(float(lin[0, 0]), 4))
    col = pipeline.bake_colors(mb, s, pipeline.DEFAULT_PALETTE)
    check("לכל קודקוד יש צבע", col.shape[0] == len(mb.v))
    tags = np.array([t or "" for t in mb.tag], dtype=object)
    hair_c = col[tags == "hair"].mean(axis=0)
    skin_c = col[tags == "skin"].mean(axis=0)
    check("השיער כהה משמעותית מהעור",
          float(hair_c.mean()) < float(skin_c.mean()) * 0.55,
          (round(float(hair_c.mean()), 3), round(float(skin_c.mean()), 3)))

    # אורך השיער הוא מידת זהות שנמדדת מהתמונה
    refs = paths.char3d()
    if (refs / "lucas_ref.png").exists() and (refs / "maya_ref.png").exists():
        hl = {}
        for n in ("lucas", "maya"):
            pal = pipeline.expand_palette(
                pipeline.palette_from_image(refs / f"{n}_ref.png"))
            hl[n] = pipeline.hair_from_image(refs / f"{n}_ref.png",
                                             pal)["hair_len"]
        check("אורך השיער נמדד ושונה בין הדמויות",
              hl["maya"] - hl["lucas"] > 0.5, hl)

# ======================================================= TASK 02: משחק פנים


_FACE_CACHE = {}


def _face_fixture():
    """רשת + צורות פנים, פעם אחת לכל הבדיקות. בנייה מלאה היא כשתי
    שניות, ובלי המטמון כל בדיקה כאן הייתה מוסיפה אותן מחדש."""
    if "v" not in _FACE_CACHE:
        sk = Skeleton(1.70)
        mb, _meta = basemesh.build(sk)
        P = {b.name: np.asarray(b.rest, float) for b in sk.bones}
        H = detail.Head(P, 1.0)
        _FACE_CACHE["v"] = (sk, mb, H, face.build(mb, H))
    return _FACE_CACHE["v"]


def _delta_centroid(M, V, name):
    """מרכז המסה של התזוזה: ממוצע מיקומי הקודקודים משוקלל בגודל
    התזוזה שלהם. עמיד לצפיפות הסריג, ולכן מתאים גם לסימטריה וגם
    למיקום."""
    d = M["deltas"][M["names"].index(name)]
    w = np.linalg.norm(d, axis=1)
    s = float(w.sum())
    if s < 1e-12:
        return np.zeros(3)
    return (V * w[:, None]).sum(axis=0) / s


def t_face():
    print("\n[צורות פנים · blendshapes]")
    sk, mb, H, M = _face_fixture()
    V = np.asarray(mb.v, float)
    g = {n: (a, b) for n, a, b in mb.groups}
    rep = M["report"]

    dead = [k for k, v in rep.items() if v["dead"]]
    check("אין צורה מתה (מסכה שלא פגעה באף קודקוד)", not dead, dead)
    check("כל הצורות נרשמו", len(M["names"]) == len(face.NAMES),
          f"{len(M['names'])} מול {len(face.NAMES)}")
    check("הדלתות סופיות",
          bool(np.all(np.isfinite(M["deltas"]))))

    # תזוזה סבירה: צורה שמזיזה סנטימטרים שוברת את הפנים, וצורה
    # שמזיזה פחות מחצי מילימטר לא נראית כלל בתקריב.
    too_big = [k for k, v in rep.items() if v["max_mm"] > 14.0]
    too_small = [k for k, v in rep.items() if v["max_mm"] < 0.5]
    check("אין צורה שמזיזה יותר מ-14 מ\"מ", not too_big, too_big)
    check("אין צורה שמזיזה פחות מחצי מ\"מ", not too_small, too_small)

    # --- סימטריה. **לא** לפי ספירת קודקודים: נמדד שסריג הראש עצמו
    # אינו סימטרי בצפיפות (1059 קודקודים בצד שמאל מול 680 בימין
    # באותה מסכה בדיוק), ולכן ספירה מחזירה "אסימטריה" על צורה
    # סימטרית לגמרי. המדדים שעמידים לצפיפות הסריג הם שיא התזוזה
    # ומרכז המסה של התזוזה, משוקף.
    bad_sym = []
    for nm in face.NAMES:
        if not nm.endswith("_L"):
            continue
        rn = nm[:-2] + "_R"
        if rn not in rep:
            continue
        if abs(rep[nm]["max_mm"] - rep[rn]["max_mm"]) > 0.05:
            bad_sym.append((nm, "שיא", rep[nm]["max_mm"], rep[rn]["max_mm"]))
            continue
        cl = _delta_centroid(M, V, nm)
        cr = _delta_centroid(M, V, rn)
        cr = np.array([-cr[0], cr[1], cr[2]])      # שיקוף
        if float(np.linalg.norm(cl - cr)) * 1000 > 1.5:
            bad_sym.append((nm, "מרכז",
                            np.round((cl - cr) * 1000, 2).tolist()))
    check("צורות שמאל/ימין סימטריות (שיא תזוזה ומרכז מסה משוקף)",
          not bad_sym, bad_sym)

    # --- מיקום: כל צורה חייבת לשבת באזור הנכון של הפנים. זו הבדיקה
    # שתופסת באג יחידות (rel_y מול y_rel), שכבר קרה כאן פעמיים.
    hc, R = H.hc, H.R
    place = []
    for nm, (lo, hi) in {
            "nose_wrinkle": (-0.12, 0.22),      # גשר האף, סביב גובה העיניים
            "nose_flare": (-0.22, -0.02),       # נחיריים, מתחת
            "lip_pucker": (-0.45, -0.18),       # קו הפה
            "lip_lo_depress": (-0.45, -0.22),
            "cheek_hollow_L": (-0.30, 0.10),    # לחי, מתחת לעין ומעל הפה
            "cheek_raise_L": (-0.05, 0.25),
            "eye_wide_L": (0.00, 0.30),         # גובה העין
    }.items():
        c = _delta_centroid(M, V, nm)
        ry = float((c[1] - hc[1]) / R)
        if not (lo <= ry <= hi):
            place.append((nm, round(ry, 3), (lo, hi)))
    check("כל צורה יושבת בגובה הנכון של הפנים", not place, place)

    # העפעף חייב להישאר על מעטפת גלגל העין
    c = H.eye_center("L")
    worst = 0.0
    for shp, grp in (("eye_wide_L", "eyelid_up_L"),
                     ("eye_wide_L", "lash_L"),
                     ("lid_tighten_L", "eyelid_lo_L")):
        d = M["deltas"][M["names"].index(shp)]
        a, b = g[grp]
        r0 = np.linalg.norm(V[a:b] - c, axis=1)
        r1 = np.linalg.norm(V[a:b] + d[a:b] - c, axis=1)
        worst = max(worst, abs(float(r1.mean() - r0.mean())) * 1000)
    check("העפעף נגלל על גלגל העין ולא מתרומם מעליו (<0.3 מ\"מ)",
          worst < 0.3, f"{worst:.3f} מ\"מ")
    moved = np.linalg.norm(
        M["deltas"][M["names"].index("eye_wide_L")], axis=1).max() * 1000
    check("ובכל זאת הפקיחה מזיזה אותו ממש (>3 מ\"מ)", moved > 3.0,
          f"{moved:.2f} מ\"מ")

    # הקרנית לא משתנה בפקיחה, אבל כן באישון
    for shp, grp, want in (("eye_wide_L", "cornea_L", False),
                           ("pupil_dilate_L", "cornea_L", True)):
        d = M["deltas"][M["names"].index(shp)]
        a, b = g[grp]
        mv = float(np.linalg.norm(d[a:b], axis=1).max())
        check(f"{shp} {'מזיז' if want else 'אינו מזיז'} את הקרנית",
              (mv > 1e-4) == want, f"{mv * 1000:.3f} מ\"מ")

    # הרכבה לינארית - בדיוק מה ש-three.js עושה
    pos = V.copy()
    p1 = face.apply_morphs(pos, M["deltas"], {"lip_pucker": 1.0})
    p2 = face.apply_morphs(pos, M["deltas"], {"lip_pucker": 0.5})
    check("משקולת חצי = חצי תזוזה",
          float(np.abs((p2 - pos) * 2 - (p1 - pos)).max()) < 1e-6)
    p0 = face.apply_morphs(pos, M["deltas"], {})
    check("בלי משקולות הרשת לא זזה",
          float(np.abs(p0 - pos).max()) < 1e-9)

    try:
        face.weights_vector({"אין_כזו_צורה": 1.0})
        ok = False
    except KeyError:
        ok = True
    check("שם צורה שגוי זורק ולא נבלע", ok)


def t_acting():
    print("\n[מערכת המשחק · קומבינציות ותזמון]")
    a = acting.audit()
    check("עשר קבוצות פנים", a["regions"] == 10, a["regions"])
    check("אין קבוצה ריקה", all(v > 0 for v in a["per_region"].values()),
          a["per_region"])
    check("כל צורת פנים משויכת לקבוצה אחת",
          a["named"] >= len(face.NAMES))

    # --- ההוכחה המרכזית של TASK 02: שליטה עצמאית
    bad = []
    for r in acting.REGIONS:
        ctl, mph = acting.isolate(r, 1.0)
        act = acting.region_activity(ctl, mph)
        others = {k: v for k, v in act.items() if k != r and v > 1e-6}
        if act[r] < 1e-6 or others:
            bad.append((r, act[r], others))
    check("בידוד קבוצה מפעיל אותה ורק אותה (10/10)", not bad, bad)

    # --- שלוש הקומבינציות שהמשתמש הגדיר, מרכיב מול מרכיב
    for nm, want in (
            ("surprise", ("brows", "eyelids", "jaw", "gaze", "head")),
            ("suspicion", ("brows", "eyelids", "head")),
            ("sadness", ("brows", "mouth", "head", "gaze"))):
        d = acting.describe(nm)
        miss = [r for r in want if d["activity"].get(r, 0) <= 1e-6]
        check(f"{nm}: כל המרכיבים שהוגדרו פעילים", not miss, miss)
        check(f"{nm}: נוגע ב-4 קבוצות לפחות",
              sum(1 for v in d["activity"].values() if v > 1e-6) >= 4,
              d["activity"])
        check(f"{nm}: לא כל החלקים מתחילים יחד",
              len(d["delays"]) >= 4, d["delays"])

    # הם חייבים להיות שונים זה מזה - אחרת זו טבלה ולא מערכת
    vecs = {}
    for nm in ("surprise", "suspicion", "sadness"):
        c, m = acting.pose_of(nm)
        vecs[nm] = {**{f"c:{k}": v for k, v in c.items()},
                    **{f"m:{k}": v for k, v in m.items()}}
    pairs = [("surprise", "suspicion"), ("surprise", "sadness"),
             ("suspicion", "sadness")]
    worst = 1.0
    for x, y in pairs:
        ks = set(vecs[x]) | set(vecs[y])
        dv = sum(abs(vecs[x].get(k, 0) - vecs[y].get(k, 0)) for k in ks)
        sv = sum(abs(vecs[x].get(k, 0)) + abs(vecs[y].get(k, 0)) for k in ks)
        worst = min(worst, dv / max(1e-9, sv))
    check("שלושת הביטויים שונים זה מזה מהותית (>55%)", worst > 0.55,
          f"{worst * 100:.1f}%")

    # --- אסימטריה
    # .get ולא [] בכל מקום: `pose_of` מחזיר **רק** את הבקרות שהביטוי
    # נגע בהן, ולכן גישה ישירה נופלת ב-KeyError על בקרה שהביטוי
    # במכוון לא הפעיל - וזה היה נראה כמו קריסת הבדיקה ולא כמו מידע.
    c, _m = acting.pose_of("suspicion")
    dl = sum(abs(c.get(f"{n}_L", 0.0) - c.get(f"{n}_R", 0.0))
             for n in ("brow_inner_up", "brow_up", "brow_outer_up",
                       "brow_furrow"))
    check("חשד אסימטרי בגבות", dl > 0.15, round(dl, 3))
    c0, _ = acting.pose_of("amusement", bias=0.0)
    c1, _ = acting.pose_of("amusement", bias=0.8)
    d0 = abs(c0.get("smile_L", 0) - c0.get("smile_R", 0))
    d1 = abs(c1.get("smile_L", 0) - c1.get("smile_R", 0))
    check("bias מגדיל אסימטריה", d1 > d0 + 0.15, (round(d0, 3), round(d1, 3)))

    # --- עצב: גבה **פנימית** ולא הרמה אחידה
    cs, _ = acting.pose_of("sadness")
    check("עצב מרים את הגבה הפנימית",
          cs.get("brow_inner_up_L", 0) > 0.3,
          round(cs.get("brow_inner_up_L", 0), 3))
    check("ולא מרים את הגבה כולה",
          abs(cs.get("brow_up_L", 0)) < 0.05,
          round(cs.get("brow_up_L", 0), 3))

    # --- תזמון: השהיה ומהירות הם פרמטרים מדידים
    b = acting.Beat("jaw_drop", 1.0, 0.0, 0.5, 0.2, 0.3, 0.3)
    check("לפני ההשהיה העוצמה אפס",
          acting.envelope(b, 0.4) == 0.0 and acting.envelope(b, 0.55) > 0)

    def t_half(expr_name, speed):
        e = acting.EXPRESSIONS[expr_name].scaled(1.0, speed)
        bt = e.beats[0]
        pk = abs(bt.peak)
        for i in range(2000):
            t = i * 0.005
            if abs(acting.envelope(bt, t, e.speed)) >= pk * 0.5:
                return t
        return float("inf")

    fast, slow = t_half("sadness", 2.0), t_half("sadness", 0.5)
    check("מהירות נמוכה = הגעה איטית לחצי העוצמה",
          slow > fast * 3.0, (round(fast, 3), round(slow, 3)))
    check("עצב איטי מברירת המחדל",
          acting.EXPRESSIONS["sadness"].speed < 0.7)
    check("רפלקס מהיר מעצב פי 2 לפחות",
          acting.EXPRESSIONS["flinch"].speed >
          acting.EXPRESSIONS["sadness"].speed * 2)

    # --- קיזוז וחיתוך
    ctl, mph = acting.finalize(
        {}, {"mouth_corner_up_L": 0.8, "mouth_corner_down_L": 0.5})
    check("אנטגוניסטים מתקזזים",
          abs(mph["mouth_corner_up_L"] - 0.3) < 1e-6 and
          mph["mouth_corner_down_L"] == 0.0, mph)
    ctl, mph = acting.finalize({"blink_L": 1.0}, {"eye_wide_L": 1.0})
    check("פקיחה רחבה מדכאת מצמוץ", ctl["blink_L"] < 0.05, ctl["blink_L"])
    ctl, _ = acting.finalize({"jaw_open": 5.0}, {})
    check("ערך חורג נחתך בתוך התחום", 0.0 <= ctl["jaw_open"] <= 1.0,
          ctl["jaw_open"])
    ctl, mph = acting.finalize({"jaw_fwd": 0.8}, {})
    check("בקרה מונעת מתורגמת לצורה",
          "jaw_fwd" not in ctl and mph.get("jaw_thrust", 0) > 0.5, (ctl, mph))

    # --- אותה יחידת פה, משמעות אחרת
    cp, mp = acting.pose_of("polite_smile")
    ca, ma = acting.pose_of("amusement")
    check("שני החיוכים מרימים את אותה זווית פה",
          mp.get("mouth_corner_up_L", 0) > 0.1 and
          ma.get("mouth_corner_up_L", 0) > 0.1)
    check("ורק אחד מהם מרים את הלחי",
          mp.get("cheek_raise_L", 0) < 0.05 and
          ma.get("cheek_raise_L", 0) > 0.3,
          (mp.get("cheek_raise_L", 0), ma.get("cheek_raise_L", 0)))

    # --- מיקרו-תנועות
    p = acting.Performance(seed=1.0)
    bl = [p._blink(i * 0.02) for i in range(900)]
    closed = sum(1 for v in bl if v > 0.5)
    check("מצמוץ: עצום רק בחלק קטן מהזמן",
          0.005 < closed / len(bl) < 0.16, round(closed / len(bl), 4))
    gaps = []
    last = None
    for i, v in enumerate(bl):
        if v > 0.5 and (last is None or i - last > 8):
            if last is not None:
                gaps.append((i - last) * 0.02)
            last = i
    check("מצמוץ לא מחזורי (המרווחים שונים)",
          len(gaps) >= 2 and max(gaps) - min(gaps) > 0.25, gaps)
    sx = [p._saccade(i * 0.02)[0] for i in range(400)]
    check("המבט זז אבל נשאר בתחום",
          max(sx) - min(sx) > 0.15 and max(abs(v) for v in sx) < 0.4)
    p2 = acting.Performance(seed=1.0)
    check("אותה הצגה דטרמיניסטית",
          p2._blink(3.33) == p._blink(3.33))

    # --- ההצגה כולה
    perf = acting.Performance(seed=2.0)
    perf.add("doubt", at=0.2).add("realization", at=1.6)
    ok, peak = True, 0.0
    for i in range(240):
        c, m = perf.solve(i * 0.02)
        for k, v in c.items():
            lo, hi, _d, _g = controls.CONTROLS[k]
            if not (lo - 1e-6 <= v <= hi + 1e-6) or v != v:
                ok = False
        for k, v in m.items():
            if not (-1.0001 <= v <= 1.0001) or v != v:
                ok = False
            peak = max(peak, abs(v))
    check("ערבוב שני ביטויים נשאר בתחום ובלי nan", ok)
    check("ובאמת הפעיל צורות פנים", peak > 0.2, round(peak, 3))


def t_acting_showreel():
    print("\n[סצנות TASK 02]")
    cov = showreel_mod().scene_coverage()
    check("שבע סצנות", len(cov) == 7, len(cov))
    dead = [k for k, v in cov.items() if v["peak_shapes"] < 1]
    check("בכל סצנה מופעלות צורות פנים", not dead, dead)
    # סצנת הבידוד פטורה: ארבע מעשר הקבוצות (גבות, לשון, ראש) ממומשות
    # בעצמות בלבד, ולכן יש בה חלון מכוון בלי אף צורה.
    gaps = {k: v["worst_gap_sec"] for k, v in cov.items()
            if k != "isolation" and v["worst_gap_sec"] > 1.1}
    check("אין סצנה שנשארת ריקה יותר מ-1.1 שניות", not gaps, gaps)
    low = {k: v["active_pct"] for k, v in cov.items()
           if k != "isolation" and v["active_pct"] < 50}
    check("כל סצנה פעילה ברוב הזמן", not low, low)


def showreel_mod():
    from rig import showreel                               # noqa: PLC0415
    return showreel


def t_face_glb():
    print("\n[GLB עם צורות פנים]")
    sk, mb, H, M = _face_fixture()
    attrs = basemesh.to_arrays(mb, sk)
    with tempfile.TemporaryDirectory() as td:
        p = Path(td) / "m.glb"
        info = glbio.write_skinned_glb(p, attrs, sk, morphs=M)
        check("נכתבו כל הצורות",
              info["morph_targets"] == len(face.NAMES), info["morph_targets"])
        js, _bin = glbio.read_glb(p)
        prim = js["meshes"][0]["primitives"][0]
        check("ל-primitive יש targets",
              len(prim.get("targets", [])) == len(face.NAMES))
        names = js["meshes"][0].get("extras", {}).get("targetNames", [])
        check("ויש targetNames באורך תואם - בלעדיו three.js מתעלם מהשמות",
              names == list(face.NAMES), len(names))
        check("משקולות ההתחלה אפס",
              all(w == 0 for w in js["meshes"][0].get("weights", [])))
        acc = js["accessors"][prim["targets"][0]["POSITION"]]
        check("ל-target יש min/max כנדרש בתקן",
              "min" in acc and "max" in acc)
        # GLB בלי morphs חייב להישאר תקין - תאימות אחורה
        p2 = Path(td) / "n.glb"
        i2 = glbio.write_skinned_glb(p2, attrs, sk)
        js2, _ = glbio.read_glb(p2)
        check("בלי צורות ה-GLB נשאר תקין ובלי targets",
              i2["morph_targets"] == 0 and
              "targets" not in js2["meshes"][0]["primitives"][0])


def t_ear():
    """
    האוזן - רגרסיה לשלוש התלונות של 05/10: "מרובעת ושטוחה ובולטת
    מבעד לשיער". הבדיקה מודדת **גאומטריה** ולא קוראת את הקוד:
    עובי אמיתי, שקע אמיתי, וצומת קדמי שצמוד לראש.
    """
    print("אוזן:")
    from . import detail
    s = Skeleton()
    mb, _meta = basemesh.build(s, {}, quality="full")
    attrs = basemesh.to_arrays(mb, s)
    P, ln = attrs["position"], np.linalg.norm(attrs["normal"], axis=1)
    grp = {n: (a, b) for n, a, b in mb.groups}
    check("יש שתי אוזניות", "ear_L" in grp and "ear_R" in grp)
    v0, v1 = grp["ear_L"]
    q = P[v0:v1]
    check("אין נורמל מנוון בכל הרשת - פאה באפס שטח היא קרום בלי עובי",
          np.allclose(ln, 1.0, atol=1e-4))
    # 1. "שטוחה": לאוזן יש עובי אמיתי ולא קרום. היחס לגובה הוא
    #    המדד, כי המידות עצמן תלויות בגודל הראש.
    th = float(q[:, 0].max() - q[:, 0].min())
    hi = float(q[:, 1].max() - q[:, 1].min())
    dp = float(q[:, 2].max() - q[:, 2].min())
    check("לאוזן עובי של לפחות 18% מגובהה", th / hi > 0.18, round(th / hi, 3))
    check("והיא גבוהה מעומקה, כמו אוזן אמיתית", hi > dp, (round(hi, 4), round(dp, 4)))
    # 2. "מרובעת": מספר הנקודות על הצללית. פחות מ-24 על חצי היקף
    #    נראה כמצולע בתקריב.
    check("לפחות 24 פרוסות על ההיקף", (v1 - v0) / 20 >= 24, (v1 - v0))
    # 3. השקע (קונכה): חייב להיות קודקוד ש**שקוע** פנימה ביחס
    #    לצומת, אחרת אין צל ואין קריאה של אוזן. כדור מעוך לא יכול
    #    לייצר את זה - זו בדיוק התקלה הקודמת.
    H = detail.Head({b.name: np.asarray(b.rest, float) for b in s.bones}, 1.0)
    base_x = float(H.surf(np.array([1.0, 0.0, -0.18]))[0])
    inside = float((q[:, 0] - base_x).min())
    outside = float((q[:, 0] - base_x).max())
    check("יש שקע אמיתי פנימה מקו הראש (קונכה)", inside < -1e-4, round(inside, 5))
    check("ויש בליטה אמיתית החוצה (הליקס)", outside > 2e-3, round(outside, 5))
    # 4. "בולטת מבעד לשיער": הצומת הקדמי צמוד לראש, והבליטה
    #    עולה לאחור. בגרסה הקודמת כל הכדור הוזז החוצה יחד.
    front = q[q[:, 2] > np.percentile(q[:, 2], 80)]
    rear = q[q[:, 2] < np.percentile(q[:, 2], 20)]
    f_out = float(np.abs(front[:, 0] - base_x).max())
    r_out = float(np.abs(rear[:, 0] - base_x).max())
    check("הצומת הקדמי בולט פחות מהקצה האחורי", f_out < r_out,
          (round(f_out, 5), round(r_out, 5)))


def t_emotion():
    """
    מנוע הרגש (TASK 03). הבדיקה אינה "המנוע רץ" אלא **שכל אחד
    מששת המשתנים משנה את ההופעה בפועל** - אחרת זו טבלה ולא מנוע.
    """
    print("מנוע רגש:")
    from . import emotion as E
    a = E.audit()
    check("המנוע שלם (כל רגש מצביע להבעה קיימת)", a["ok"], a["problems"][:3])
    check("יש לפחות 15 רגשות ו-8 כוונות",
          a["emotions"] >= 15 and a["intentions"] >= 8)

    # --- knows: אותו משפט, פער ידע הפוך -> כוונה אחרת ותזמון אחר
    more = E.plan(E.Situation(feels="suspicion", knows_more=0.9))
    less = E.plan(E.Situation(feels="suspicion", knows_more=-0.9))
    check("יודעת יותר -> בודקת/מחזיקה", more.intention in ("test", "withhold"),
          more.intention)
    check("יודעת פחות -> מחפשת", less.intention == "seek", less.intention)
    check("מי שיודע יותר נע פחות ממי שמחפש",
          more.timing.speed < less.timing.speed,
          (more.timing.speed, less.timing.speed))
    check("ומחזיק מבט זמן ארוך יותר", more.gaze.hold > less.gaze.hold * 1.5,
          (more.gaze.hold, less.gaze.hold))

    # --- hides: שתי שכבות, לא עוצמה מונמכת. זה לב המשימה.
    open_ = E.plan(E.Situation(feels="sadness"))
    hid = E.plan(E.Situation(feels="neutral", hides="sadness"))
    check("בלי הסתרה אין נזילה", open_.leak == [])
    check("עם הסתרה יש נזילה", len(hid.leak) > 0)
    check("הפנים הגלויות אינן הרגש האמיתי",
          all(n not in [x for x, _ in hid.face] for n, _ in hid.leak),
          hid.face)
    check("הנזילה חלשה מההבעה הגלויה",
          max(a for _, a in hid.leak) < max(a for _, a in hid.face),
          (hid.leak, hid.face))
    check("הסתרה אינה רק עוצמה מונמכת - היא הבעה אחרת לגמרי",
          {n for n, _ in hid.face} != {n for n, _ in open_.face})
    check("הסתרה מוסיפה השהיית תגובה",
          hid.timing.delay > open_.timing.delay + 0.05,
          (hid.timing.delay, open_.timing.delay))
    check("והופכת את ההבעה לאסימטרית", hid.timing.bias > 0.1, hid.timing.bias)
    check("ומקצרת את החזקת המבט", hid.gaze.hold < open_.gaze.hold,
          (hid.gaze.hold, open_.gaze.hold))
    # הנזילה יושבת רק באזורים שאין בהם שליטה רצונית
    for n, _ in hid.leak:
        regs = acting.EXPRESSIONS[n].regions()
        check(f"הנזילה ({n}) נוגעת באזור שאין בו שליטה",
              bool(regs & set(E.LEAK_REGIONS)), sorted(regs))

    # --- feels: arousal נמוך = איטי. לא נכתב בקוד, נגזר.
    sad = E.plan(E.Situation(feels="sadness"))
    sur = E.plan(E.Situation(feels="surprise"))
    check("עצב איטי מהפתעה, בלי שזה כתוב ביד",
          sad.timing.speed < sur.timing.speed,
          (sad.timing.speed, sur.timing.speed))
    # --- control מבדיל כעס מפחד באותו arousal
    ang = E.plan(E.Situation(feels="anger"))
    fea = E.plan(E.Situation(feels="fear"))
    check("כעס ופחד באותה אנרגיה בקירוב",
          abs(E.EMOTIONS["anger"].arousal - E.EMOTIONS["fear"].arousal) < 0.1)
    check("ובכל זאת הגוף הפוך: הכועס נפתח והמפוחד מתכנס",
          ang.body.spine_bend < fea.body.spine_bend,
          (ang.body.spine_bend, fea.body.spine_bend))

    # --- looks_at משנה את המבט בפועל
    down = E.plan(E.Situation(feels="shame", looks_at="down"))
    at = E.plan(E.Situation(feels="shame", looks_at="partner"))
    check("מבט למטה מזיז את העיניים למטה", down.gaze.aim_y < -0.05, down.gaze.aim_y)
    check("ומבט בבן השיח ישיר יותר", at.gaze.directness >= down.gaze.directness)

    # --- change: שינוי רגשי בתוך השוט
    arc = E.arc(E.Situation(feels="surprise", change="surprise->anger",
                            shot_len=4.0))
    check("שינוי רגשי מייצר שתי תוכניות ונקודת מפנה", arc is not None)
    check("המפנה בתוך השוט ולא בקצה", 0.2 < arc.turn < 4.0, arc.turn)
    check("לפני המפנה הרגש הראשון", arc.at(0.1).emotion.name == "surprise")
    check("ואחריו השני", arc.at(3.9).emotion.name == "anger")
    check("המעבר רך ולא מתג", 0.0 < arc.weight(arc.turn + arc.blend * 0.5) < 1.0)
    check("מעבר להתרגשות חד ממעבר להירגעות",
          (E.arc(E.Situation(feels="sadness", change="sadness->surprise")).blend <
           E.arc(E.Situation(feels="surprise", change="surprise->sadness")).blend))
    check("בלי change אין קשת", E.arc(E.Situation(feels="joy")) is None)

    # --- wants: עוצמת הרצון משנה את גודל המחווה
    weak = E.plan(E.Situation(feels="curiosity", knows_more=-0.9,
                              want_strength=0.1))
    strong = E.plan(E.Situation(feels="curiosity", knows_more=-0.9,
                                want_strength=1.0))
    check("רצון חזק -> מחווה גדולה יותר",
          strong.gesture[0].amount > weak.gesture[0].amount,
          (strong.gesture[0].amount, weak.gesture[0].amount))
    check("אין מחווה בלי כוונה שמייצרת אותה",
          E.plan(E.Situation(feels="suspicion", knows_more=0.9)).gesture == [])
    check("המחווה מגיעה אחרי תחילת ההבעה ולא לפניה",
          all(g.at >= strong.timing.delay for g in strong.gesture))

    # --- החיבור למערכת המשחק: הפלט הוא בקרות תקפות
    for name, sit in E.SCENES.items():
        ctl, mph = E.solve(sit, 0.9)
        try:
            controls.normalize(ctl)
        except KeyError as exc:
            check(f"תרחיש {name}: בקרות תקפות", False, str(exc))
            continue
        check(f"תרחיש {name}: בקרות תקפות ומשהו באמת זז",
              any(abs(v) > 1e-4 for v in ctl.values()) or
              any(abs(v) > 1e-4 for v in mph.values()))
    # שפת הגוף מגיעה לבקרות הגוף, ולא רק לפנים
    ctl, _ = E.solve(E.Situation(feels="sadness", looks_at="down"), 1.2)
    check("שפת הגוף מגיעה לעמוד השדרה", abs(ctl.get("spine_bend", 0.0)) > 1e-4)
    check("והמבט מגיע לכיוון העיניים", abs(ctl.get("eye_aim_y", 0.0)) > 1e-4)
    # שתי דמויות באותו מצב אינן זהות (seed שונה = מיקרו-תנועה שונה)
    c1, _ = E.solve(E.Situation(feels="interest"), 1.3, seed=1.0)
    c2, _ = E.solve(E.Situation(feels="interest"), 1.3, seed=7.0)
    check("אותו מצב בשני seeds אינו פלט זהה",
          any(abs(c1[k] - c2.get(k, 0.0)) > 1e-6 for k in c1))


def t_eyes():
    """
    מערכת משחק העיניים (TASK 04). הבדיקה אינה "המערכת רצה" אלא
    **שכל אחת מהיכולות שנדרשו נמדדת בפלט בפועל**. מערכת עיניים אפשר
    לכתוב בעשרים שורות שנראות נכון לגמרי ולא עושות כלום בתמונה, ולכן
    כאן נמדדים מספרים ולא נוכחות של פונקציות.
    """
    print("משחק עיניים:")
    from rig import eyes as EY                               # noqa: PLC0415
    a = EY.audit()
    check("כל 12 הדרישות עוברות את המדידה", a["ok"], a["problems"])
    f = a["features"]

    # --- main sequence: סקאדה גדולה ארוכה מסקאדה קטנה. בלי זה כל
    # תנועת מבט אורכת אותו זמן, וזה בדיוק מה שנראה כאנימציה.
    check("אורך הסקאדה נגזר ממשרעתה",
          EY.saccade_dur(0.9) > EY.saccade_dur(0.15) * 1.6,
          (EY.saccade_dur(0.9), EY.saccade_dur(0.15)))

    # --- העיניים לפני הראש. זו הטעות הנפוצה ביותר: ראש ועיניים
    # שזזים באותו פריים נראים כמו ראש שהעיניים מודבקות אליו.
    check("העיניים מובילות, הראש מאחר אחריהן",
          0.05 < f["head_lag_sec"] < 0.45, f["head_lag_sec"])

    # --- אסימטריה: גם במשרעת וגם בזמן
    e = EY.EyeActing(seed=1.0, shot_len=4.0)
    lids = [e._lid(i / 240.0) for i in range(960)]
    check("שני העפעפיים אינם זהים", max(abs(l - r) for l, r in lids) > 0.004,
          round(max(abs(l - r) for l, r in lids), 5))
    # הפרש הזמן נמדד על **ההתחלה**: מצמוץ שרק נמוך יותר בצד אחד הוא
    # קיטום משרעת, לא אסימטריה בתזמון.
    tl = next((i for i, (l, _r) in enumerate(lids) if l > 0.02), -1)
    tr = next((i for i, (_l, r) in enumerate(lids) if r > 0.02), -1)
    check("ואחד מהם מקדים את השני בזמן", tl != tr, (tl, tr))

    # --- מצמוץ שנגרר מהסטת מבט, ולא טיימר. זה ההבדל בין מצמוץ
    # שהוא חלק מהמשחק למצמוץ שהוא נורה מהבהבת.
    e2 = EY.EyeActing(seed=4.0, shot_len=8.0, directness=0.6, hold=1.1)
    near = 0
    for b, _amt in e2._bl:
        if any(abs(b - fx.at) < 0.12 for fx in e2.fixes[1:]):
            near += 1
    check("חלק מהמצמוצים נגררים מהסטת מבט", near >= 1,
          (near, len(e2._bl)))
    gaps = [y - x for x, y in zip([b for b, _ in e2._bl],
                                  [b for b, _ in e2._bl][1:])]
    check("ואין מצמוץ מחזורי (מרווחים אינם שווים)",
          len(gaps) > 2 and np.std(gaps) / max(1e-9, np.mean(gaps)) > 0.12,
          round(float(np.std(gaps) / max(1e-9, np.mean(gaps))), 3))

    # --- ריכוז מדכא מצמוץ. אם לא, "קשר עין" הוא רק כיוון.
    hi = EY.EyeActing(seed=1.0, directness=0.95, arousal=0.5)
    lo = EY.EyeActing(seed=1.0, directness=0.40, arousal=0.5)
    check("נעיצה מדכאת מצמוץ", hi.blink_rate() > lo.blink_rate(),
          (hi.blink_rate(), lo.blink_rate()))

    # --- מיקוד אינו הסטת מבט: גם על אותה מטרה המיקוד משתנה
    same = EY.EyeActing(seed=2.0, shot_len=5.0, conceal=True)
    vg = [same._verge(i / 60.0) for i in range(300)]
    check("יש שינוי מיקוד אמיתי", max(vg) - min(vg) > 0.20,
          round(max(vg) - min(vg), 3))

    # --- פקיחה רגשית: control מפריד פחד מכעס גם בעיניים
    fear = EY.EyeActing(valence=-0.7, arousal=0.88, control=0.12)
    ang = EY.EyeActing(valence=-0.62, arousal=0.84, control=0.80)
    wf, tf, _ = fear._openness()
    wa, ta, _ = ang._openness()
    check("פחד פוקח עיניים וכעס מצמצם אותן", wf > wa and ta > tf,
          ((wf, tf), (wa, ta)))

    # --- תגובה מושהית, ומושהית **יותר** כשמסתירים
    plain = EY.EyeActing(control=0.8)
    hide = EY.EyeActing(control=0.3, conceal=True)
    check("תגובת העיניים מושהית",
          plain.reaction_latency() > 0.1, plain.reaction_latency())
    check("ומי שמסתיר מגיב לאט יותר",
          hide.reaction_latency() > plain.reaction_latency() + 0.1,
          (hide.reaction_latency(), plain.reaction_latency()))

    # --- הדיבור אינו מפעיל את העיניים. זו דרישה מפורשת של המשימה,
    # והיא נמדדת בקורלציה ולא מוצהרת.
    check("המבט אינו מסונכרן לדיבור",
          abs(f["speech_gaze_corr"]) < 0.25, f["speech_gaze_corr"])
    check("ובכל זאת היא מסיטה מבט לפני שהיא מדברת",
          f["pre_speech_shifts"] >= 1)

    # --- הפלט תקף, ואין שתי מערכות שכותבות לאותו מצמוץ
    ctl, mph = EY.EyeActing(seed=3.0, shot_len=3.0).solve(1.1)
    controls.normalize(ctl)
    for k in mph:
        check(f"צורה {k} קיימת", k in face.NAMES)
    p_eyes = acting.Performance(seed=1.0, micro=True, eyes_own=True)
    c_eyes, _ = p_eyes.solve(1.0)
    check("כש-TASK 04 פעיל, מערכת המשחק אינה ממצמצת בעצמה",
          "blink_L" not in c_eyes and "eye_aim_x" not in c_eyes,
          sorted(c_eyes))
    check("אבל הנשימה ורעד הגבות נשארים",
          abs(c_eyes.get("breath", 0.0)) > 1e-9)
    p_old = acting.Performance(seed=1.0, micro=True)
    c_old, _ = p_old.solve(1.0)
    check("וההתנהגות הוותיקה לא השתנתה", "blink_L" in c_old)


def t_emotion_scenes():
    """
    **זה מה שלא נכנס ב-TASK 03.** המנוע היה קיים ונבדק, אבל סצנות
    הסרטון המשיכו לקרוא להבעות ישירות. הבדיקה כאן היא שהסצנות של
    TASK 04 באמת נבנות מ-`Situation` ושהמבט בהן הוא מערכת העיניים.
    """
    print("\n[סצנות TASK 04: משמעות ועיניים]")
    S = showreel_mod()
    from rig import emotion as E                             # noqa: PLC0415
    shots = S.build_shots_emotion(1.70)
    keys = [sh.key for sh in shots]
    check("לפחות שבע סצנות משמעות ועיניים", len(shots) >= 7, len(shots))
    # TASK 05 הוסיף שתי סצנות לציר הזמן הזה. הבדיקה נשענת על
    # **השמות** ולא על המספר, אחרת כל תוספת עתידית מפילה אותה בלי
    # שקרה שום דבר רע.
    check("ובהן שתי הסצנות של הדיבור כהופעה",
          "speech_perf" in keys and "delivery" in keys, keys)
    src = (HERE / "showreel.py").read_text(encoding="utf-8")
    body = src.split("def build_shots_emotion")[1].split(
        "\ndef shots_for")[0]
    check("הסצנות נבנות מ-Situation ולא מהבעה ישירה",
          "E.SCENES[" in body or "E.Situation(" in body)
    check("ואין בהן קריאה ישירה ל-EXPRESSIONS",
          "EXPRESSIONS" not in body, "EXPRESSIONS בתוך build_shots_emotion")
    check("המבט בא ממערכת העיניים", "eye_actor" in src)

    cov = S.scene_coverage(1.70, 30, task=4)
    low = {k: v["active_pct"] for k, v in cov.items() if v["active_pct"] < 80}
    check("כל סצנה פעילה ברוב הזמן", not low, low)
    dead = [k for k, v in cov.items() if v["peak_shapes"] < 1]
    check("בכל סצנה מופעלות צורות פנים", not dead, dead)

    # הפלט של כל סצנה חייב להיות בקרות וצורות תקפות **בכל פריים**,
    # ולא רק בפריים שנדגם. סצנה שנופלת בשנייה 4 הפילה רנדור שלם.
    for sh in shots:
        n = int(round(sh.secs * 12))
        bad = ""
        for i in range(n):
            t, u = i / 12.0, i / max(1, n - 1)
            for fn in (sh.a, sh.b):
                r = fn(u, t)
                try:
                    controls.normalize(r[0])
                    if len(r) > 2 and r[2]:
                        for k in r[2]:
                            if k not in face.NAMES:
                                raise KeyError(k)
                except KeyError as exc:
                    bad = f"{t:.2f}ש: {exc}"
                    break
            if bad:
                break
        check(f"סצנה {sh.key}: פלט תקף בכל פריים", not bad, bad)

    # והראיה שזו **משמעות** ולא הבעה: אותו משפט בדיוק, פער ידע הפוך,
    # ושני המבטים יוצאים שונים לגמרי.
    more = E.eye_actor(E.SCENES["יודעת-יותר"], seed=1.0)
    less = E.eye_actor(E.SCENES["לא-מבינה"], seed=1.0)
    check("מי שיודע יותר מחזיק מבט יותר מזמן ממי שמחפש",
          more.hold > less.hold * 1.4, (more.hold, less.hold))
    check("ומי שמחפש מסתכל על עצם ולא בעיניים",
          less.home == "object" and more.home == "partner",
          (less.home, more.home))
    # מי שמסתיר מוריד מבט, ולא "מסתכל פחות חזק"
    hid = E.eye_actor(E.SCENES["עצב-מוסתר"], seed=1.0)
    check("מי שמסתיר מוריד מבט ואז מציץ לבדוק",
          "conceal" in {f.reason for f in hid.fixes} and
          "check" in {f.reason for f in hid.fixes},
          sorted({f.reason for f in hid.fixes}))


def t_sss():
    """
    שכבת פיזור האור מתחת לעור. הבדיקה היא על **המקור של דף הבמה**
    ועל שרשרת ה-shader של three.js שבתיקייה: נקודת ההשתלה חייבת
    להתקיים בגרסה שבאמת נטענת, אחרת השכבה נכשלת בשקט ברנדור
    ואף אחד לא יודע. זו הסיבה שהבדיקה קוראת את שני הקבצים.
    """
    print("פיזור אור מתחת לעור:")
    stage = (HERE / "stage.html").read_text(encoding="utf-8")
    three = (STUDIO / "lib" / "three.module.js").read_text(encoding="utf-8")
    anchor = ('reflectedLight.directDiffuse += irradiance * '
              'BRDF_Lambert( material.diffuseColor );')
    check("נקודת ההשתלה קיימת ב-three.js שבתיקייה", anchor in three)
    check("דף הבמה מחפש בדיוק את אותה נקודה", anchor in stage)
    # המלכודת שנתפסה כאן 05/10: אותה שורה מופיעה בארבעה מודלי
    # תאורה (lambert/phong/physical/toon), ו-replace עם מחרוזת
    # מחליף את הראשון בלבד. ב-MeshStandard צפוי מופע אחד - אבל
    # "צפוי" אינו "נמדד", ולכן הקוד **סופר** לפני שהוא מחליף.
    check("השורה אינה ייחודית בקובץ - בדיוק למה שצריך לספור",
          three.count(anchor) > 1, three.count(anchor))
    check("הקוד סופר מופעים לפני ההחלפה", "split(SSS_ANCHOR).length" in stage)
    check("ומסרב להשתיל כשאין בדיוק מופע אחד",
          "hits !== 1" in stage and "return;" in stage)
    for frag in ("uSssWrap", "uSssStrength", "uSssThru", "uSssColor"):
        check(f"יש uniform בשם {frag}", frag in stage)
    check("יש אור עוטף (wrap) - זה מה שמוציא את העור מפלסטיק",
          "sssNL + uSssWrap" in stage)
    check("יש גוון התפזרות בקצה הצל", "sssBand" in stage)
    check("ויש העברה בקצוות דקים (אוזן, אף)", "sssBack" in stage)
    check("ההשתלה מאומתת, ולא מונחת שעבדה", "__sssOk" in stage)
    check("וכשל נרשם ל-ERR כדי שהבקרה תתפוס אותו",
          "[SSS]" in stage and "sss_ok" in stage)
    check("מפתח התוכנית נדרס - בלעדיו three מחזיר shader ממוטמן "
          "ו-onBeforeCompile לא נקרא בכלל",
          "customProgramCacheKey" in stage)
    check("אין SSS על שיער או על עין - שם הוא מחזיר את הפלסטיק",
          "'hair'" not in stage.split("SSS_BY_MATERIAL")[1][:200] and
          "hair:" not in stage.split("SSS_BY_MATERIAL")[1][:200])
    check("חומר שהוא מערך מטופל גם כן (primitives מרובים)",
          "Array.isArray(o.material)" in stage)


def t_speech():
    """TASK 05: הדיבור כהופעה ולא כסנכרון שפתיים.

    כל מקרה כאן הוא **דרישה מפורשת** מהמשימה, והוא נמדד ולא מוצהר.
    """
    from rig import speech as S
    print("דיבור כהופעה (TASK 05):")
    a = S.audit()
    check("טבלת הויזמות והפונמות שלמה ועקבית",
          a["visemes"] >= 14 and a["phonemes"] >= 25, a)

    ph = S.phonemize("לא התכוונתי שזה יישמע ככה.")
    vow = sum(1 for p, _d in ph if p in "aeiou")
    check("משפט עברי מפוענח לפונמות", len(ph) >= 12, len(ph))
    # בלי תנועות הפה כמעט לא נפתח, וזה היה המצב כשא'/ע'/ו'/י' טופלו
    # כעיצורים: רצף עיצורים בלבד נותן לסת שכמעט אינה זזה.
    check("ויש בו תנועות ולא רק עיצורים", vow >= len(ph) * 0.3,
          f"{vow}/{len(ph)}")
    durs = {d for _p, d in ph}
    check("אורכי הפונמות אינם אחידים (הקצב נגזר מהטקסט)",
          len(durs) > len(ph) * 0.6, len(durs))

    f = S.features()
    # --- הדרישה הראשונה: הפה אינו המניע הראשי
    check("הקורלציה לסינוס נמוכה בהרבה מזו של המנוע שהוחלף",
          f["sine_corr"] < f["sine_corr_old"] * 0.65,
          (f["sine_corr"], f["sine_corr_old"]))
    check("המנוע הישן אכן היה סינוס כמעט טהור - בסיס ההשוואה תקף",
          f["sine_corr_old"] > 0.85, f["sine_corr_old"])
    # --- pauses
    check("יש פאוזות בתוך המשפט", f["pauses"] >= 2, f["pauses"])
    check("ויש רגעי פה סגור בתוך חלון הדיבור",
          f["closed_frac_in_speech"] > 0.04, f["closed_frac_in_speech"])
    # --- hesitation
    check("היסוס מוסיף פונמות ואירוע משלו",
          f["hesitation_phones"] > 0, f["hesitation_phones"])
    # --- breathing / swallowing / non-verbal
    ev = f["events"]
    for k, he in (("breath", "נשימה"), ("swallow", "בליעה"),
                  ("react", "תגובה לא-מילולית בין מילים")):
        check(f"מתוכננת {he}", ev.get(k, 0) >= 1, ev.get(k, 0))
    check("וכיבוי האירועים הלא-מילוליים עובד (אינם קבועים בקוד)",
          f["nonverbal_off"] == 0 and f["nonverbal_events"] >= 4,
          (f["nonverbal_off"], f["nonverbal_events"]))
    # --- reduced mouth movement during quiet speech
    check("דיבור שקט מקטין את תנועת הפה",
          0.05 < f["quiet_jaw_ratio"] < 0.6, f["quiet_jaw_ratio"])
    # --- smiles during speech
    check("חיוך **תוך** דיבור: הפינות עולות בעוד הפה פתוח",
          f["smile_while_open"] > 0.2, f["smile_while_open"])
    # --- speaking while angry / sad
    check("דיבור בכעס: שפתיים לחוצות + אף מתרחב + פתיחה חדה",
          f["angry_press_max"] > 0.3 and f["angry_flare_max"] > 0.2 and
          f["angry_jaw_max"] > f["jaw_max"],
          (f["angry_press_max"], f["angry_flare_max"],
           f["angry_jaw_max"], f["jaw_max"]))
    check("דיבור בעצב: הפינות נופלות והפתיחה מצטמצמת",
          f["sad_corner_down_max"] > 0.2 and f["sad_jaw_ratio"] < 0.85,
          (f["sad_corner_down_max"], f["sad_jaw_ratio"]))
    check("כמה ויזמות שונות בשימוש במשפט אחד",
          f["visemes_used"] >= 6, f["visemes_used"])

    # --- הדרישה שהיא כל שם המשימה: הפה **אינו** המניע הראשי
    d = S.drive_report()
    check("סנכרון השפתיים אינו המניע הראשי של אנימציית הפנים",
          d["mouth_share"] < 0.45, d["mouth_share"])
    check("ועדיין יש לפה נוכחות אמיתית (לא כובה)",
          d["mouth_share"] > 0.08, d["mouth_share"])

    # --- ההגשה נגזרת מה-Situation ולא נקבעת ביד
    from rig import emotion as E
    hid = S.voice_from(E.SCENES["עצב-מוסתר"])
    opn = S.voice_from(_rep_sit(E, "עצב-מוסתר", hides=""))
    check("דמות שמסתירה משהו מדברת שקט יותר מזו שאינה מסתירה",
          hid.loudness < opn.loudness, (round(hid.loudness, 3),
                                        round(opn.loudness, 3)))
    check("ובמתח גבוה יותר בשפתיים",
          hid.tension > opn.tension, (round(hid.tension, 3),
                                      round(opn.tension, 3)))


def _rep_sit(E, name, **kw):
    from dataclasses import replace
    return replace(E.SCENES[name], **kw)


# ============================================ TASK 06: משחק גוף מלא

def t_body():
    print("גוף מלא (TASK 06):")
    from rig import body as B

    rep = B.audit()
    check("כל צורת מחווה מפנה לבקרות שקיימות",
          not rep["controls_missing"], rep["controls_missing"])
    check("לכל כוונה יש ערך בטבלת המחוות",
          not rep["intentions_missing"], rep["intentions_missing"])
    check("אין מחווה שאינה תומכת בכוונה שהולידה אותה",
          not rep["illegal_plays"], rep["illegal_plays"])
    check("נוספו בקרות גוף: משקל, כתפיים, כפות רגליים, מרפק",
          len(rep["new_controls"]) >= 12, len(rep["new_controls"]))
    for need in ("weight_shift", "shoulder_up_L", "shoulder_fwd_R",
                 "foot_roll_L", "foot_turn_R", "elbow_out_L",
                 "hips_shift", "weight_drop", "weight_fwd"):
        check(f"קיימת בקרה {need}", need in controls.CONTROLS)

    # --- השער: מחווה בלי סיבה סמנטית לא נולדת בכלל
    try:
        B.Gesture(kind="beat", reason="", shape="beat_small")
        check("מחווה בלי סיבה סמנטית נדחית", False, "לא נזרקה שגיאה")
    except B.GestureError:
        check("מחווה בלי סיבה סמנטית נדחית", True)
    try:
        B.Gesture(kind="beat", reason="   ", shape="beat_small")
        check("גם סיבה שהיא רווחים בלבד נדחית", False)
    except B.GestureError:
        check("גם סיבה שהיא רווחים בלבד נדחית", True)
    try:
        B.Gesture(kind="wave_randomly", reason="שתיראה מונפשת",
                  shape="beat_small")
        check("סוג מחווה שאינו בטקסונומיה נדחה", False)
    except B.GestureError:
        check("סוג מחווה שאינו בטקסונומיה נדחה", True)
    # הכיוון השני - מחווה תקינה **כן** נבנית. בלי זה שער רחב מדי
    # היה עובר את הבדיקה בכך שהוא פוסל הכול.
    ok = B.Gesture(kind="beat", reason="מדגישה את המילה",
                   shape="beat_small")
    check("מחווה עם סיבה נבנית כרגיל", ok.kind == "beat")

    # --- השער השני: המחווה חייבת לתמוך בכוונה
    try:
        B.Gesture(kind="deictic", reason="מצביעה", shape="point_near",
                  anchor="שם", intention="observe")
        check("מחווה שהכוונה אוסרת נדחית", False)
    except B.GestureError:
        check("מחווה שהכוונה אוסרת נדחית", True)
    g_ok = B.Gesture(kind="deictic", reason="מצביעה על מה שהיא קובעת",
                     shape="point_near", anchor="זה", intention="assert")
    check("אותה מחווה תחת כוונה שמרשה אותה - עוברת",
          g_ok.intention == "assert")

    # --- השער השלישי: מחווה גדולה חייבת מילת עוגן
    try:
        B.Gesture(kind="deictic", reason="מצביעה", shape="point_near",
                  amount=0.8)
        check("מחווה גדולה בלי מילת עוגן נדחית", False)
    except B.GestureError:
        check("מחווה גדולה בלי מילת עוגן נדחית", True)
    small = B.Gesture(kind="beat", reason="קצב", shape="beat_small",
                      amount=0.8)
    check("beat פטור מעוגן - הוא קצב ולא תוכן", small.amount == 0.8)

    # --- ארבע הפאזות, בסדר הנכון
    g = B.Gesture(kind="metaphoric", reason="מושיטה את המילה",
                  shape="offer_palm", anchor="בסדר", amount=0.7,
                  stroke=1.0, prep=0.25, hold=0.2, retract=0.5)
    phases = [g.phase(t) for t in (0.5, 0.85, 1.02, 1.15, 1.45, 2.2)]
    check("פאזות המחווה בסדר: הכנה→הדגשה→החזקה→חזרה→מנוחה",
          phases == ["idle", "preparation", "stroke", "hold",
                     "retraction", "idle"], phases)
    check("ההכנה אינה מגיעה לשיא - השיא הוא ההדגשה",
          g.weight(0.95) < g.weight(1.05), (g.weight(0.95), g.weight(1.05)))
    check("ההחזרה איטית יותר מההכנה", g.retract > g.prep)
    check("מחוץ לחלון המחווה אין שום תנועה",
          g.weight(0.0) == 0.0 and g.weight(5.0) == 0.0)

    # --- יציבה: contrapposto אמיתי
    st = B.stance_for("assert", 0.2, 0.6, 0.8, side=1.0)
    stl = B.stance_for("assert", 0.2, 0.6, 0.8, side=-1.0)
    check("המשקל נשען על רגל אחת ולא מתחלק שווה", abs(st.weight) > 0.25,
          st.weight)
    check("צד הנשענות נקבע מ-side ולא מהרגש",
          st.weight * stl.weight < 0, (st.weight, stl.weight))

    act = B.BodyActor(stance=st, gestures=[])
    c = act.solve(3.0)
    check("הטיית האגן והקיזוז של העמוד הפוכים בסימן",
          c["hips_shift"] * c["spine_side"] < 0,
          (c["hips_shift"], c["spine_side"]))
    check("הראש מתקזז בחזרה לכיוון האופק",
          c["head_roll"] * c["hips_shift"] < 0,
          (c["head_roll"], c["hips_shift"]))
    hi, lo = ("R", "L") if c["weight_shift"] > 0 else ("L", "R")
    check("הרגל החופשית מתכופפת יותר מהנושאת",
          c[f"knee_{lo}"] > c[f"knee_{hi}"],
          (c[f"knee_{lo}"], c[f"knee_{hi}"]))
    check("וכף הרגל החופשית מתגלגלת יותר",
          c[f"foot_roll_{lo}"] > c[f"foot_roll_{hi}"])

    # --- השרשרת: האגן מגיע ליעדו לפני הראש
    early = act.solve(0.14)
    hips_u = abs(early["hips_shift"]) / max(1e-6, abs(c["hips_shift"]))
    head_u = abs(early["head_roll"]) / max(1e-6, abs(c["head_roll"]))
    check("בתחילת התנועה האגן התקדם יותר מהראש - שרשרת ולא קפיצה",
          hips_u > head_u, (round(hips_u, 3), round(head_u, 3)))

    # --- ידיים: שום **תנועה** בלי מחווה מאושרת.
    #
    # הניסוח כאן חשוב, והוא תוקן אחרי שהרנדור הראשון החזיר זרועות
    # פרושות באוויר: הדרישה היא "never use random hand *waving*",
    # כלומר האיסור הוא על **תנועה** בלי סיבה - לא על פוזה. יד רפויה
    # של אדם עומד אינה בערך אפס: היא צמודה לירך, המרפק כפוף מעט
    # והאצבעות מתעגלות. מה שאסור הוא שהערכים האלה **ישתנו** בלי
    # שמחווה מסבירה את השינוי. המדידה הזו גם חזקה יותר מהקודמת -
    # היא תופסת נדנוד ידיים שהערך הממוצע שלו אפס.
    idle_actor = B.BodyActor(stance=st, gestures=[])
    HAND = ("arm_", "curl_", "fist", "spread_", "wrist_", "elbow_")
    snaps = [idle_actor.solve(t) for t in (0.8, 2.0, 3.7, 5.1)]
    keys = [k for k in snaps[0] if k.startswith(HAND)]
    moved = [k for k in keys
             if max(abs(s[k] - snaps[0][k]) for s in snaps) > 1e-6]
    check("בלי מחווה - אפס תנועת ידיים (לא 'ניפנוף כדי שתיראה מונפשת')",
          not moved, moved[:4])
    check("ובכל זאת היד אינה תלויה כמקל - יש פוזת מנוחה",
          snaps[0].get("elbow_R", 0) > 0.05
          and snaps[0].get("curl_index_R", 0) > 0.05)
    check("האצבעות אינן כולן באותה התעגלות (יד ולא כפפה)",
          snaps[0]["curl_thumb_R"] != snaps[0]["curl_pinky_R"])
    act2 = B.BodyActor(stance=st, gestures=[g])
    g_keys = [k for k in act2.solve(1.15) if k.startswith(HAND)]
    g_moved = [k for k in g_keys
               if abs(act2.solve(1.15).get(k, 0.0)
                      - act2.solve(5.0).get(k, 0.0)) > 1e-4]
    check("עם מחווה - הידיים כן משנות מצב בזמן", len(g_moved) >= 3,
          len(g_moved))
    at_peak = act2.solve(1.15)
    check("עם מחווה - הידיים כן זזות",
          any(abs(at_peak.get(k, 0.0)) > 0.01
              for k in ("arm_down_R", "spread_R", "wrist_pitch_R")))

    try:
        B.BodyActor(stance=st, gestures=[{"kind": "beat"}])
        check("מילון במקום Gesture נדחה (עוקף את השערים)", False)
    except B.GestureError:
        check("מילון במקום Gesture נדחה (עוקף את השערים)", True)

    # --- 'מתבוננת' היא כוונה שבה הידיים דוממות, וזה תקין
    from rig import emotion as E
    obs = B.actor_for(E.SCENES["הפתעה-להבנה"], "observe",
                      speech=((0.5, 2.0),))
    check("כוונה 'observe' אינה מייצרת מחוות כלל", not obs.gestures)
    seek = B.actor_for(E.SCENES["לא-מבינה"], "seek", speech=((0.5, 2.0),))
    check("כוונה 'seek' כן מייצרת מחוות", len(seek.gestures) >= 1)
    check("ולכל אחת מהן סיבה כתובה",
          all(g.reason.strip() for g in seek.gestures))

    # --- רצון חזק = מחווה גדולה יותר. זה מה שמונע ניפנוף סתמי.
    lo_s = B.actor_for(_rep_sit(E, "לא-מבינה", want_strength=0.1),
                       "seek", speech=((0.5, 2.0),))
    hi_s = B.actor_for(_rep_sit(E, "לא-מבינה", want_strength=1.0),
                       "seek", speech=((0.5, 2.0),))
    check("רצון חזק מגדיל את המחווה",
          hi_s.gestures[0].amount > lo_s.gestures[0].amount * 1.3,
          (lo_s.gestures[0].amount, hi_s.gestures[0].amount))

    # --- הסתרה מקפיאה את הגוף, לא מרעידה אותו
    op = B.actor_for(E.SCENES["עצב-גלוי"], speech=((0.5, 2.0),))
    hd = B.actor_for(E.SCENES["עצב-מוסתר"], speech=((0.5, 2.0),))
    check("הסתרה ממעיטה בתנועה (sway קטן יותר)",
          hd.stance.sway < op.stance.sway,
          (hd.stance.sway, op.stance.sway))
    check("והמתח בכתפיים עולה",
          hd.stance.shoulder_up > 0.0)

    # --- ה-stroke נופל על מילה שקיימת במשפט
    line = "רגע... אז זה היה אתה?"
    idx, word = B.stressed_word(line)
    check("מילת ההדגשה קיימת במשפט", word and word in line, word)
    t_at = B.word_time(line, idx, 1.0, 3.0)
    check("זמן המילה נופל בתוך חלון הדיבור", 1.0 <= t_at <= 3.0, t_at)

    # --- כל הבקרות שהגוף מייצר הן בקרות חוקיות וטווח תקף
    bad = [k for k in act2.solve(1.2) if k not in controls.CONTROLS]
    check("כל הבקרות שהגוף מייצר רשומות", not bad, bad[:4])
    nrm = controls.normalize(act2.solve(1.2))
    check("ואף ערך אינו חורג מהטווח",
          all(controls.CONTROLS[k][0] - 1e-9 <= v <= controls.CONTROLS[k][1]
              + 1e-9 for k, v in nrm.items()))


# ============================================ TASK 06: קול אמיתי

def t_voice():
    print("קול אמיתי (TASK 06):")
    from rig import voice as V

    files = V.available()
    check("יש קובצי קול מוקלטים בפרויקט", len(files) >= 4, len(files))
    if not files:
        return
    voices = {json.loads(p.with_suffix(".json").read_text("utf-8"))["voice"]
              for p in files if p.with_suffix(".json").exists()}
    check("יש גם קול גברי וגם קול נשי",
          any("Avri" in v for v in voices) and
          any("Hila" in v for v in voices), voices)

    tr = V.load("לא, הכול בסדר.", "avri")
    check("ההקלטה נטענת ומנותחת", tr is not None)
    if tr is None:
        return
    check("השמע נקרא באורך סביר", 1.0 < tr.seconds < 10.0, tr.seconds)
    check("יש מסגרות ניתוח (פריים לכל 10 מילישניות)",
          len(tr.rms) > int(tr.seconds * 80), len(tr.rms))
    check("זוהה דיבור ולא רק שקט",
          0.10 < float(tr.voiced.mean()) < 0.95, float(tr.voiced.mean()))
    check("יש פורמנטים מדודים בקטעי הדיבור",
          float(tr.f1[tr.voiced].max()) > 200.0)

    vis = [v for _a, _b, v in tr.visemes if v != "sil"]
    check("הופקו ויזמות מהשמע עצמו", len(vis) >= 6, len(vis))
    check("ויזמה אינה קצרה מ-30 מילישניות (אין ריצוד)",
          all(b - a >= 0.029 for a, b, _ in tr.visemes),
          min((round(b - a, 3) for a, b, _ in tr.visemes), default=0))
    check("כל הויזמות ממופות לויזמות שהפה מכיר",
          all(v in ("a", "e", "i", "o", "u", "s", "f", "m", "sil")
              for _a, _b, v in tr.visemes))
    check("המילה 'בסדר' הניבה הגה שורק (ס) שנמדד מהשמע",
          any(v == "s" for _a, _b, v in tr.visemes))
    check("יש גם רגע של שפתיים סגורות", any(v == "m" for *_x, v in tr.visemes))

    # --- הברות: אשכול תנועות רציף הוא הברה אחת
    syl = V.syllables(tr)
    check("מספר ההברות קטן ממספר מקטעי התנועה (אשכול = הברה)",
          len(syl) < len([1 for *_x, v in tr.visemes
                          if v in ("a", "e", "i", "o", "u")]) or len(syl) <= 7,
          len(syl))
    check("ניקוד נגזר מההגייה ולא מכלל קבוע",
          any(ch in V._NIQQUD.values() for ch in V.vocalize("לא", tr)))

    # --- הערכים שבזמן
    mid = tr.seconds * 0.5
    check("אפשר לדגום ויזמה ועוצמה בכל רגע",
          isinstance(tr.viseme_at(mid), tuple))
    check("מחוץ להקלטה אין אנרגיה", tr.energy(tr.seconds + 5) >= 0.0)

    # --- שני קולות שונים מניבים ניתוח שונה
    th = V.load("לא, הכול בסדר.", "hila")
    if th is not None:
        check("אותו משפט בשני קולות - שני ניתוחים שונים",
              [v for *_x, v in tr.visemes] != [v for *_x, v in th.visemes])
        check("קנה המידה של הקול נמדד ואינו מוצהר לפי מין הדובר",
              V._voice_scale(th) != V._voice_scale(tr))

    # --- חיבור למנוע הדיבור: החלון נמתח לשמע האמיתי
    from rig import speech as S
    a = S.SpeechActor("לא, הכול בסדר.", ((0.5, 1.2),), S.Delivery(), track=tr)
    b = S.SpeechActor("לא, הכול בסדר.", ((0.5, 1.2),), S.Delivery())
    check("עם שמע, חלון הדיבור נמתח לאורך ההקלטה האמיתית",
          a.windows[0][1] > b.windows[0][1] + 0.5,
          (a.windows, b.windows))
    check("והפונמות הן אלה שנמדדו ולא אלה שנוחשו מהטקסט",
          [p.ph for p in a.phones] != [p.ph for p in b.phones])
    check("הפה פעיל בתוך חלון הדיבור",
          a.mouth_energy((a.windows[0][0] + a.windows[0][1]) / 2) > 0.05)
    check("ויש נשימה לפני תחילת הדיבור",
          any(e.kind == "breath" and e.at < a.windows[0][0]
              for e in a.events))

    # --- מיזוג פס קול
    buf = V.mix([(1.0, tr), (6.0, tr)], 12.0)
    check("פס הקול באורך הסרטון", abs(len(buf) / V.RATE - 12.0) < 0.1)
    check("ושני הקטעים נשתלו במקומות הנכונים",
          float(abs(buf[int(1.3 * V.RATE):int(2.0 * V.RATE)]).max()) > 0.01
          and float(abs(buf[int(6.3 * V.RATE):int(7.0 * V.RATE)]).max())
          > 0.01)
    check("ולפני הקטע הראשון שקט מוחלט",
          float(abs(buf[:int(0.9 * V.RATE)]).max()) < 1e-6)
    check("אין גלישה מעל 1.0 (הגבלה רכה ולא חיתוך)",
          float(abs(buf).max()) <= 1.0)
    cut = V.mix([(11.5, tr)], 12.0)
    check("קטע שחורג מסוף הסרטון נחתך ולא מפיל",
          abs(len(cut) / V.RATE - 12.0) < 0.1)


def t_body_scenes():
    print("סצנות TASK 06:")
    from rig import body as B
    from rig import showreel as SH

    shots = SH.build_shots_body(1.70)
    check("יש לפחות שש סצנות גוף", len(shots) >= 6, len(shots))
    check("לכל סצנה כתובית ומשפט הוכחה",
          all(s.cap and s.proves for s in shots))

    spoken = 0
    for s in shots:
        for fn in (s.a, s.b):
            r = fn(0.45, s.secs * 0.45)
            ctl = r[0] or {}
            if not ctl:
                continue
            bad = [k for k in ctl if k not in controls.CONTROLS]
            check(f"[{s.key}] כל הבקרות חוקיות", not bad, bad[:3])
            nrm = controls.normalize(ctl)
            check(f"[{s.key}] הערכים בטווח",
                  all(controls.CONTROLS[k][0] - 1e-9 <= v
                      <= controls.CONTROLS[k][1] + 1e-9
                      for k, v in nrm.items()))
            bod = getattr(fn, "body", None)
            check(f"[{s.key}] יש שחקן גוף", bod is not None)
            if bod is not None:
                check(f"[{s.key}] המשקל אינו מחולק שווה",
                      abs(bod.weight_at(s.secs * 0.45)) > 0.10,
                      bod.weight_at(s.secs * 0.45))
                check(f"[{s.key}] כל מחווה נושאת סיבה",
                      all(g.reason.strip() and g.kind in B.KINDS
                          for g in bod.gestures))
            if getattr(fn, "track", None) is not None:
                spoken += 1
    check("לפחות שש הופעות דיבור נשענות על הקלטה אמיתית",
          spoken >= 6, spoken)

    # --- פס הקול: סדר, מיקום ובלי חפיפות
    cues = SH.soundtrack_cues(shots)
    check("נאספו קטעי קול לפס הקול", len(cues) >= 6, len(cues))
    check("הקטעים ממוינים בציר הזמן",
          all(cues[i][0] <= cues[i + 1][0] for i in range(len(cues) - 1)))
    overlap = [(round(a, 2), round(b, 2))
               for (a, ta), (b, _tb) in zip(cues, cues[1:])
               if b < a + ta.seconds - 0.05]
    # חפיפה אינה תקלה תאורטית: בגרסה הראשונה שתי דמויות אמרו את
    # אותו משפט באותה שנייה בדיוק, וזה נשמע כהד ולא כדיאלוג.
    check("אין שני קטעי דיבור שחופפים זה לזה", not overlap, overlap)
    total = sum(s.secs for s in shots)
    check("כל קטע דיבור מתחיל בתוך הסרטון",
          all(0.0 <= at < total for at, _ in cues))
    check("שתי הדמויות נשמעות - גם קול גברי וגם נשי",
          len({t.voice for _a, t in cues}) >= 2,
          {t.voice for _a, t in cues})


# ================================ TASK 07: עקרונות האנימציה
#
# **בדיקה אחת לכל עיקרון, וכולן נמדדות על תנועה אמיתית.** זו
# הדרישה המילולית ("Create automated tests for each principle"),
# והיא גם מה שמונע את הכשל הצפוי: עיקרון שהוצהר ולא התרחש.
#
# שתי החלטות שקבעו את צורת הבדיקות האלה:
#
# 1. **המדידה לא מקבלת את האובייקט שייצר את התנועה** - היא מקבלת
#    מערך ערכים בזמן. לכן בדיקה כאן אינה יכולה לעבור בגלל דגל
#    שהוגדר נכון; היא עוברת רק אם העקומה שיצאה באמת נראית כך.
# 2. **חלון הדגימה נגמר בסוף ההחזקה ולא בסוף המחווה**, כי מחווה
#    מלאה חוזרת לאפס - ואז "המהלך נטו" הוא אפס ואין מול מה למדוד
#    נסיגה או חריגה. זה נתפס בהרצה הראשונה: m_anticipation החזירה
#    "אין מהלך בכלל" על עקומה מושלמת.

def _gesture_curve(g, fps=240, upto=None):
    """(זמנים, משקלים) של מחווה אמיתית, מתחילת הנסיגה."""
    hi = g.stroke + 0.06 + g.hold if upto is None else upto
    ts = np.linspace(g.opens - 0.04, hi, int((hi - g.opens + 0.04) * fps))
    return ts, np.array([g.weight(float(t)) for t in ts])


def _real_actor(secs=4.0, intention="assert", seed=0.0):
    from dataclasses import replace as _rep
    from rig import body as B
    from rig import emotion as E
    sit = _rep(E.SCENES["לא-מבינה"], shot_len=secs, want_strength=0.95)
    return B.actor_for(sit, intention, seed=seed, speech=((0.5, 2.3),))


def t_principles():
    print("עקרונות אנימציה (TASK 07):")
    from rig import body as B
    from rig import principles as P

    # --- הרישום עצמו: עיקרון בלי מדידה אינו עיקרון
    check("שנים-עשר עקרונות ברישום", len(P.PRINCIPLES) == 12,
          len(P.PRINCIPLES))
    missing = [k for k, (_d, fn) in P.PRINCIPLES.items()
               if not callable(getattr(P, fn, None))]
    check("לכל עיקרון יש פונקציית מדידה ממשית", not missing, missing)
    rep = P.audit()
    check("כל שתים-עשרה המדידות עוברות על תנועת ההתייחסות",
          rep["passed"] == 12 and not rep["missing"],
          [r for r in rep["results"] if not r["ok"]])

    # --- התנועה האמיתית שכל המדידות ייבדקו עליה
    act = _real_actor()
    check("יש מחווה אמיתית למדוד עליה", len(act.gestures) >= 1,
          len(act.gestures))
    g = act.gestures[0]
    ts, ws = _gesture_curve(g)

    # 1 · Anticipation
    v = P.m_anticipation(ts, ws)
    check(f"[1 אנטיציפציה] {v.detail}", v.ok, v.score)
    check("[1 אנטיציפציה] המשקל שלילי לפני ההכנה - היד נסוגה",
          g.weight(g.opens + g.lead * 0.5) < 0.0,
          g.weight(g.opens + g.lead * 0.5))
    check("[1 אנטיציפציה] וההיסט עצמו מתהפך בזמן הנסיגה",
          np.sign(B.shape_ctl_at(g, g.opens + g.lead * 0.5)
                  .get(f"arm_down_{g.hand}", 0.0))
          == -np.sign(B.shape_ctl_at(g, g.stroke + 0.03)
                      .get(f"arm_down_{g.hand}", 0.0)))

    # 2 · Squash & Stretch - שימור נפח, ושער סגנוני
    pairs = [P.squash(a, "jaw") for a in (-0.12, -0.05, 0.0, 0.07, 0.12)]
    v = P.m_squash_stretch(pairs)
    check(f"[2 מעיכה/מתיחה] {v.detail}", v.ok, v.score)
    try:
        P.squash(0.30, "jaw")
        bad = True
    except P.StyleError:
        bad = False
    check("[2 מעיכה/מתיחה] מעיכה מוגזמת נדחית בשער ולא מתקבלת", not bad)
    try:
        P.squash(0.05, "walk")
        bad = True
    except P.StyleError:
        bad = False
    check("[2 מעיכה/מתיחה] והקשר שאינו מתאים לסגנון נדחה גם הוא", not bad)
    fs = P.face_squash(0.8)
    check("[2 מעיכה/מתיחה] לסת פתוחה שואבת את הלחיים פנימה",
          fs["cheek_hollow_L"] > 0.0 and
          all(k in face.NAMES for k in fs), fs)

    # 3 · Timing - אותה מחווה, עוררות שונה
    durs, wts = [], []
    for ar in (0.15, 0.50, 0.90):
        gg = B.gestures_for("assert", "אז זה היה אתה?", 0.4, 2.0,
                            want=0.9, arousal=ar, control=0.5)[0]
        durs.append(gg.end - gg.opens)
        wts.append(1.0 - ar)          # עוררות נמוכה = גוף כבד ואיטי
    v = P.m_timing(durs, wts)
    check(f"[3 תזמון] {v.detail}", v.ok, [round(d, 3) for d in durs])

    # 4 · Spacing
    v = P.m_spacing(ts, ws)
    check(f"[4 ריווח] {v.detail}", v.ok, v.score)
    lin = np.linspace(0.0, 1.0, len(ts))
    check("[4 ריווח] אינטרפולציה ליניארית **נכשלת** במדידה הזו",
          not P.m_spacing(ts, lin).ok, P.m_spacing(ts, lin).score)

    # 5 · Arcs - מסלול כף היד במרחב, מהשלד עצמו
    skel = Skeleton()
    pts = []
    # **חלון הדגימה הוא מסע ההכנה בלבד: מ-`start` ועד ה-stroke.**
    # זה לא כיוונון נוח אלא תיקון של טעות מדידה, ושתי ההרצות
    # שנפלו רשומות כאן כדי שלא תחזור:
    #
    # * מ-`opens` (תחילת הנסיגה המכינה) - הנסיגה היא מהלך **הפוך**,
    #   ולכן המסלול יוצא אחורה ואז קדימה. `m_arcs` החזירה 92%
    #   קמירות ו"זיגזג", ובצדק: זה אינו מסלול אחד.
    # * עד סוף ההחזקה - שם יושבת החריגה, וחריגה **חוצה את המיתר
    #   מעבר לנקודת הסיום** מעצם הגדרתה. נמדד: סטייה נגדית של 56%
    #   מהקמירות, בדיוק בפריימים של ה-overshoot.
    #
    # קשת היא תכונה של **מסע** בין שתי פוזות. חריגה והתיישבות הן
    # עיקרון אחר, שנמדד בנפרד (6), ושני העקרונות אינם אמורים
    # להימדד על אותו חלון.
    for t in np.linspace(g.start, g.stroke, 24):
        q = controls.evaluate(skel, act.solve(float(t)))
        W = skel.forward(q)
        pts.append(W[skel.by_name[f"hand_{g.hand}"].index][:3, 3].copy())
    v = P.m_arcs(np.array(pts))
    check(f"[5 קשתות] {v.detail}", v.ok, v.score)
    straight = np.linspace(pts[0], pts[-1], 24)
    check("[5 קשתות] קו ישר בין אותן נקודות נכשל במדידה",
          not P.m_arcs(straight).ok)

    # 6 · Follow-through
    v = P.m_follow_through(ts, ws)
    check(f"[6 חריגה והתיישבות] {v.detail}", v.ok, v.score)
    check("[6 חריגה והתיישבות] יש רגע שבו היד מעבר לפוזה שלה",
          any(g.overshooting(float(t)) for t in ts))
    check("[6 חריגה והתיישבות] ואחריו היא מתיישבת על 1.0",
          abs(g.weight(g.stroke + 0.06 + g.hold - 1e-4) - 1.0) < 0.02,
          g.weight(g.stroke + 0.06 + g.hold - 1e-4))

    # 7 · Overlap - בתוך אותה יד: כתף, מרפק, שורש, אצבעות
    cts = np.linspace(g.opens - 0.05, g.end, 300)
    chan = {}
    for key in ("arm_down", "elbow", "wrist_pitch", "curl_pinky"):
        full = f"{key}_{g.hand}"
        if full not in B.SHAPES.get(g.shape, {}).keys() | set():
            pass
        chan[key] = np.array([B.shape_ctl_at(g, float(t)).get(full, 0.0)
                              for t in cts])
    chan = {k: v2 for k, v2 in chan.items() if np.abs(v2).max() > 1e-9}
    v = P.m_overlap(chan, cts)
    check(f"[7 חפיפה] {v.detail}", v.ok and len(chan) >= 3,
          sorted(chan))
    check("[7 חפיפה] והסדר הוא מהגוף אל הקצה ולא הפוך",
          B.DISTAL_LAG["curl_pinky"] > B.DISTAL_LAG["wrist_pitch"]
          > B.DISTAL_LAG["elbow"] >= B.DISTAL_LAG["arm_down"])

    # 8+9 · Ease-in / Ease-out, על המחווה המלאה
    fts = np.linspace(g.opens - 0.03, g.end + 0.03, 500)
    fws = np.array([g.weight(float(t)) for t in fts])
    vi, vo = P.m_ease_in(fts, fws), P.m_ease_out(fts, fws)
    check(f"[8 ease-in] {vi.detail}", vi.ok, vi.score)
    check(f"[9 ease-out] {vo.detail}", vo.ok, vo.score)
    check("[9 ease-out] המחווה נגמרת באפס מדויק ולא נקטעת באוויר",
          abs(g.weight(g.end - 1e-5)) < 0.01, g.weight(g.end - 1e-5))

    # 10 · Secondary action - נמדדת כהפרש מול אותו גוף בלי מחוות
    bare = B.BodyActor(stance=act.stance, gestures=[], seed=act.seed,
                       shift_at=act.shift_at, reshift=act.reshift)
    free = "L" if g.hand == "R" else "R"
    prim = np.array([act.drive(float(t)) for t in cts])
    sec = np.array([act.solve(float(t)).get(f"shoulder_up_{free}", 0.0)
                    - bare.solve(float(t)).get(f"shoulder_up_{free}", 0.0)
                    for t in cts])
    v = P.m_secondary(prim, sec)
    check(f"[10 תנועה משנית] {v.detail}", v.ok, v.score)
    check("[10 תנועה משנית] היא אפס כשאין מחוות בכלל",
          abs(bare.solve(float(g.stroke)).get(f"shoulder_up_{free}", 0.0)
              - bare.solve(float(g.stroke))
              .get(f"shoulder_up_{free}", 0.0)) < 1e-12
          and bare.drive(float(g.stroke)) == 0.0)

    # 11 · Staging - מתוך סצנה אמיתית
    from rig import showreel as SH
    shots = SH.build_shots_body(1.70)
    X = {"A": -0.52, "B": 0.52}          # מיקומי הדמויות בבמה
    solo = [s for s in shots if s.vis and not s.vis.get("A", True)]
    check("[11 במה] יש סצנת סוליסט למדוד עליה", bool(solo))
    if solo:
        sh = solo[0]
        cam = sh.cam(0.5)
        st = P.Staging(subject_x=X["B"], others_x=[], cam_tx=cam.get("tx", 0.0),
                       caption=sh.cap)
        v = P.m_staging(st)
        check(f"[11 במה] {v.detail}", v.ok, (cam.get("tx"), sh.key))
        bad = P.Staging(subject_x=X["B"], others_x=[], cam_tx=0.0,
                        caption=sh.cap)
        check("[11 במה] מצלמה שמביטה למרכז הריק נכשלת במדידה",
              not P.m_staging(bad).ok)

    # 12 · Appeal - הפוזות של הסצנות עצמן
    poses = []
    for sh in shots:
        for fn in (sh.a, sh.b):
            r = fn(0.45, sh.secs * 0.45)
            if r and r[0]:
                poses.append(controls.normalize(r[0]))
    v = P.m_appeal(poses)
    check(f"[12 קסם] {v.detail}", v.ok and len(poses) >= 6, len(poses))
    flat = [{k: 0.0 for k in poses[0]}, {k: 0.0 for k in poses[0]}]
    check("[12 קסם] פוזה סימטרית וישרה נכשלת במדידה",
          not P.m_appeal(flat).ok)


def t_syllables():
    print("דיוק ספירת ההברות (TASK 07):")
    from rig import voice as V

    rep = V.syllable_audit()
    check("נמדדו כל עשרת המשפטים שהוקלטו", rep["n"] >= 10, rep["n"])
    if not rep["n"]:
        return
    per = rep["per_voice"]
    check("יש מדידה נפרדת לקול הגברי ולנשי", len(per) == 2, sorted(per))
    # **זו הבדיקה שהמשתמש ביקש.** הפער שדווח היה הטיה מגדרית: הקול
    # הנשי נספר חסר (3 הברות במקום 9). הסף כאן אינו "דיוק מושלם"
    # אלא **אי-קיום הטיה**: אותה שגיאה בשני הקולות.
    check(f"אין הטיה בין הקולות (פער {rep['voice_gap']} הברות בממוצע)",
          rep["voice_gap"] <= 0.5, {k: v["mae"] for k, v in per.items()})
    # 05/10 (TASK 08): הספים כאן הודקו אחרי שנוסף כלל ההיאטוס
    # (`voice.hiatus`). לפניו: 8/10 מדויק, שגיאה 0.4. אחריו: 9/10
    # ו-0.1, והקול הגברי מדויק לחלוטין. הסף הוא **המצב שנמדד**,
    # כדי שנסיגה תיתפס מיד.
    check(f"שגיאה ממוצעת של עד שתי עשיריות הברה למשפט ({rep['mae']})",
          rep["mae"] <= 0.2, rep["mae"])
    check(f"לפחות תשעה מתוך {rep['n']} משפטים נספרו במדויק",
          rep["exact"] >= 9,
          [(r["voice"], r["text"], r["got"], r["expected"])
           for r in rep["rows"] if r["got"] != r["expected"]])
    check("הקול הגברי מדויק בכל המשפטים",
          per.get("avri", {}).get("exact") == per.get("avri", {}).get("n"),
          per.get("avri"))
    # והמבחן החד ביותר: מה שעוד חסר **חסר באותה מידה בשני הקולות**.
    # משפט מהיר שבו שתי הברות נבלעות הוא מגבלת מדידה; משפט שנבלע
    # רק בקול אחד הוא הטיה - וזו הייתה התקלה.
    dev = {}
    for r in rep["rows"]:
        dev[r["voice"]] = dev.get(r["voice"], 0) + (r["got"] - r["expected"])
    check("ומה שעדיין חסר - חסר **באותה מידה** בשני הקולות",
          abs(dev.get("hila", 0) - dev.get("avri", 0)) <= 1, dev)

    # --- המדד עצמו: סונוריות ולא עוצמה
    tr = V.load("זה בסדר, אני רגילה.", "hila")
    check("מעטפת הסונוריות נמדדת ונשמרת",
          tr is not None and len(tr.sonor) == len(tr.rms))
    if tr is not None:
        ns = V.nuclei(tr)
        check("גרעיני ההברות מופרדים בבקעה אמיתית",
              all((ns[i + 1] - ns[i]) * tr.hop >= V._SEP2 - 1e-9
                  for i in range(len(ns) - 1)), ns)

    # --- כלל ההיאטוס: גבול הברה בלי בקעת עוצמה (05/10, TASK 08)
    #
    # המשפט "רגע... אז זה היה אתה?" נספר 6 במקום 8 בשני הקולות.
    # כאן נבדק שהגבול "זֶה|הָ" - שתי תנועות שה"ה" ביניהן אינה
    # חוסמת את הזרימה - נמצא עכשיו, ושהכלל *אינו* מפצל את שני
    # המקרים שמדמים אותו.
    tr2 = V.load("רגע... אז זה היה אתה?", "avri")
    check("ההקלטה של המשפט המהיר קיימת", tr2 is not None)
    if tr2 is not None:
        ns2 = V.nuclei(tr2)
        check(f"המשפט המהיר נספר במדויק ({len(ns2)} הברות)",
              len(ns2) == 8, len(ns2))
        # הגבול שאבד: פסגות ב-2.08 וב-2.15, בקעה של שליש דציבל
        near = [i for i in ns2 if 2.05 <= i * tr2.hop <= 2.20]
        check("ושני גרעיני «זֶה·הָ» נמצאים בתוך אותו קטע מקולי",
              len(near) == 2, [round(i * tr2.hop, 2) for i in near])
        db2 = V._envelope_db(tr2)
        j, i2 = near[0], near[-1]
        dip2 = min(float(db2[j]), float(db2[i2])) - float(db2[j:i2 + 1].min())
        check(f"הבקעה ביניהם אכן זניחה ({dip2:.2f}dB) - "
              f"כלומר כלל העוצמה לבדו לא היה מוצא אותם",
              dip2 < V._DIP_DB, round(dip2, 3))
        # כתף על מדרון: הפסגה ב-0.28 נמוכה ב-12dB מזו ב-0.40, והיא
        # רק שלב בעלייה. הכלל חייב לדחות אותה.
        sj = int(0.26 / tr2.hop) + int(db2[int(0.26 / tr2.hop):
                                           int(0.31 / tr2.hop)].argmax())
        si = int(0.38 / tr2.hop) + int(db2[int(0.38 / tr2.hop):
                                           int(0.43 / tr2.hop)].argmax())
        check("כתף על מדרון עלייה **אינה** הברה",
              not V.hiatus(tr2, db2, sj, si),
              (round(sj * tr2.hop, 2), round(si * tr2.hop, 2),
               round(float(abs(db2[si] - db2[sj])), 2)))
    # ההברה שנשארה חסרה עד 05/10, ושנמצאה בסוף: `הָ` של "היה" בקול
    # הנשי. היא יושבת **בתוך בקעת האנרגיה**, כי /ה/ הוא חיכוך גרוני
    # נשוף שמוריד את העוצמה בדיוק בתחילת ההברה. מה שמצא אותה הוא
    # פתיחת הלסת (F1), ולא ספי עוצמה. ראה `voice.breathy_nuclei`.
    tr3 = V.load("רגע... אז זה היה אתה?", "hila")
    if tr3 is not None:
        db3 = V._envelope_db(tr3)
        ns3 = V.nuclei(tr3)
        check(f"בקול הנשי נמצאו {len(ns3)} גרעינים מתוך 8 הברות",
              len(ns3) == 8, [round(i * tr3.hop, 2) for i in ns3])
        # ההברה הנשופה נמצאת סביב 2.07 שניות, והיא **בקעה** בעוצמה
        bre = [i for i in ns3 if 2.03 <= i * tr3.hop <= 2.11]
        check("ההברה הנשופה `הָ` נספרת",
              len(bre) == 1, [round(i * tr3.hop, 2) for i in bre])
        if bre:
            m = bre[0]
            nb = [i for i in ns3 if i != m]
            lo = max(i for i in nb if i < m)
            hi = min(i for i in nb if i > m)
            check(f"והיא **מתחת** לשני שכניה בעוצמה "
                  f"({db3[m]:.1f}dB מול {db3[lo]:.1f} ו-{db3[hi]:.1f}) - "
                  f"כלומר כלל עוצמה לא יכול היה למצוא אותה",
                  db3[m] < db3[lo] and db3[m] < db3[hi],
                  (round(float(db3[m]), 2), round(float(db3[lo]), 2),
                   round(float(db3[hi]), 2)))
            a1, _ = V._fmt_at(tr3, lo)
            b1, _ = V._fmt_at(tr3, hi)
            m1, _ = V._fmt_at(tr3, m)
            check(f"אבל הלסת שם פתוחה יותר מבשניהם "
                  f"(F1 {m1:.0f} מול {a1:.0f} ו-{b1:.0f}, יחס "
                  f"{m1 / max(a1, b1):.2f})",
                  m1 / max(a1, b1) >= V._BREATHY_F1,
                  round(m1 / max(a1, b1), 3))
        # ולא מתווספות הברות שלא נהגו: הסף נבחן על **כל** עשר
        # ההקלטות דרך `syllable_audit`, וזו הבדיקה שתיפול מיד אם
        # הכיול יזוז לכיוון של פיצול יתר.
        acc = V.syllable_audit()
        check(f"וכל עשרת המשפטים נספרים במדויק ({acc['exact']}/{acc['n']})",
              acc["exact"] == acc["n"] and acc["n"] >= 10, acc["rows"])
        check(f"ואין פער בין הקולות ({acc['voice_gap']})",
              acc["voice_gap"] == 0.0, acc["per_voice"])
        # חיכוך אינו גרעין: ל-ס/שׁ יש אנרגיה כמו לתנועה, והוא נספר
        # כהברה כל עוד המדד הוא עוצמה גולמית.
        fr = [i for i, (a, b, v2) in enumerate(tr.visemes) if v2 == "s"]
        check("יש חיכוך בהקלטה (יש מה לדכא)", bool(fr))
        idx = {V._envelope_db(tr).argmax()}
        check("ושיא הסונוריות אינו נופל על פריים חיכוכי",
              all(tr.zcr[i] < V._FRIC_ZCR for i in idx),
              [float(tr.zcr[i]) for i in idx])


def t_secondary_rig():
    """TASK 08 - תנועה משנית: פיזיקה, משקולות, גאומטריה וסצנות."""
    print("תנועה משנית (TASK 08):")
    from rig import secondary as S
    from rig.skeleton import Skeleton as Sk

    # --- 1. כל האיברים שהמשימה מונה קיימים
    skel = Sk(accessories=("glasses",))
    rig = S.SoftRig(skel)
    groups = rig.report()["groups"]
    for g in ("hair", "clothing", "coat", "accessory", "hands", "head",
              "torso"):
        check(f"יש אלמנט בקבוצה «{g}»", bool(groups.get(g)), sorted(groups))
    check("לכל האלמנטים הרכים יש עצם בשלד",
          all(b in skel.by_name for b in S.SOFT_BONES),
          [b for b in S.SOFT_BONES if b not in skel.by_name])

    a = S.audit()
    # --- 2. **הדרישה המרכזית**: בלי תנועה ראשית אין תנועה משנית.
    check(f"גוף קפוא -> תנועה משנית אפס ({a['still_max_deg']}°)",
          a["still_max_deg"] < 1e-6, a["still_max_deg"])
    check(f"וגם אנרגיה אפס בקפיצים ({a['still_energy']})",
          a["still_energy"] < 1e-6, a["still_energy"])
    # --- 3. ועם תנועה ראשית - כן יש, ובמתאם גבוה אליה
    moved = [b for b, v in a["peak_deg"].items() if v > 0.5]
    check(f"עם תנועה ראשית כל {len(a['peak_deg'])} האלמנטים מגיבים",
          len(moved) == len(a["peak_deg"]),
          {b: v for b, v in a["peak_deg"].items() if v <= 0.5})
    worst = min(a["corr_to_primary"].values())
    check(f"התגובה **נגררת מהראשית** - מתאם מינימלי {worst}",
          worst >= 0.4, a["corr_to_primary"])
    check("אף אלמנט לא חורג מתקרת הזווית שלו",
          not a["over_limit"], a["over_limit"])
    # --- 4. אחרי עצירה - דעיכה לאפס
    check(f"אחרי עצירה האנרגיה דועכת ({a['settled_energy']})",
          a["settled_energy"] < 1e-3, a["settled_energy"])
    check(f"והזווית חוזרת לאפס ({a['settled_max_deg']}°)",
          a["settled_max_deg"] < 1e-2, a["settled_max_deg"])
    # --- 5. אין היפוך סימן ואין קפיצה: הקוורטניונים נשארים תקינים
    rig.reset()
    bad = 0
    for i in range(60):
        q = controls.evaluate(skel, {"head_yaw": 0.6 * math.sin(i / 4.0),
                                     "spine_twist": 0.4 * math.sin(i / 5.0)})
        q = rig.solve(q, 1 / 30)
        bad += sum(1 for v in q.values()
                   if abs(float(np.linalg.norm(v)) - 1.0) > 1e-6)
    check("כל הקוורטניונים נשארים מנורמלים לאורך 60 פריימים", bad == 0, bad)

    # --- 6. המשקולות: עצם רכה שלא מזיזה קודקודים היא תנועה בלתי נראית
    mb, meta = basemesh.build(skel, {}, quality="fast")
    attrs = basemesh.to_arrays(mb, skel)
    cnt = meta["secondary"]["bound"]
    for grp, nm in (("hair", "שיער"), ("clothing", "שרוול"),
                    ("coat", "מכפלת"), ("accessory", "משקפיים")):
        check(f"קודקודי {nm} נקשרו לעצם רכה ({cnt.get(grp, 0)})",
              cnt.get(grp, 0) > 0, cnt)
    hair_v = np.array([t == "hair" for t in mb.tag])
    skin_v = np.array([t == "skin" for t in mb.tag])
    rest = identity.skin(skel, attrs, {})
    qq = {"hair_side_L": quat_from_euler(0.0, 0.0, 0.30)}
    bent = identity.skin(skel, attrs, qq)
    d = np.linalg.norm(bent - rest, axis=1)
    check("סיבוב עצם שיער מזיז שיער בפועל "
          f"({float(d[hair_v].max()) * 1000:.1f} מ\"מ)",
          float(d[hair_v].max()) > 0.002, float(d[hair_v].max()))
    check("ו**לא** מזיז את העור של הפנים "
          f"({float(d[skin_v].max()) * 1000:.2f} מ\"מ)",
          float(d[skin_v].max()) < float(d[hair_v].max()) * 0.35,
          (float(d[skin_v].max()), float(d[hair_v].max())))
    gl = np.array([t == "glasses" for t in mb.tag])
    check("יש גאומטריית משקפיים", int(gl.sum()) > 100, int(gl.sum()))
    bent_g = identity.skin(skel, attrs,
                           {"glasses": quat_from_euler(0.05, 0.0, 0.0)})
    dg = np.linalg.norm(bent_g - rest, axis=1)
    check("עצם המשקפיים מזיזה את המשקפיים ולא את הפנים",
          float(dg[gl].max()) > float(dg[skin_v].max()) * 3.0,
          (float(dg[gl].max()), float(dg[skin_v].max())))
    # השיער נשאר צמוד: העברת המשקולת אינה מנתקת אותו מהגולגולת
    far = float(np.abs(np.linalg.norm(bent - rest, axis=1)[hair_v]).max())
    check(f"והתזוזה חסומה ואינה מנתקת את השיער ({far * 100:.2f} ס\"מ)",
          far < 0.05, far)

    # --- 7. הסצנות של המשימה
    from rig import showreel as sr
    shots = sr.shots_for(8, 1.70, {}, {})
    check(f"יש ציר זמן ל-TASK 08 ({len(shots)} סצנות)",
          len(shots) >= 5, len(shots))
    check("לכל סצנה יש כתובית חיה שמדווחת את הזוויות",
          all(s.caption_of for s in shots),
          [s.key for s in shots if not s.caption_of])
    keys = {s.key for s in shots}
    check("יש סצנה שמוכיחה שתנועה משנית אינה עצמאית",
          "respond_not_independent" in keys, sorted(keys))
    check("ויש סצנת התיישבות אחרי עצירה", "settle" in keys, sorted(keys))
    sec = sum(s.secs for s in shots)
    check(f"אורך הקטע {sec:.1f} שניות", 25.0 <= sec <= 60.0, sec)


# ================================================= TASK 09: קסם הדמות


def t_appeal():
    """תשע האיכויות של מנהל הקסם, ועוד שלוש בדיקות של **הכלים** שהן
    נשענות עליהם: המצלמה בפייתון, מילוי הצללית, והיות המדד דו-כיווני."""
    print("מנהל קסם הדמות (TASK 09):")
    from rig import appeal as AP                          # noqa: PLC0415

    # --- המצלמה: שחזור מדויק של three.js
    eye, R = AP.camera(0.0, 0.0, 3.0, 1.0)
    check("מצלמה חזיתית יושבת על ציר z",
          abs(eye[0]) < 1e-9 and abs(eye[1] - 1.0) < 1e-9
          and abs(eye[2] - 3.0) < 1e-9, [round(v, 4) for v in eye])
    check("צירי המצלמה אורתונורמליים",
          np.allclose(R.T @ R, np.eye(3), atol=1e-9),
          float(np.abs(R.T @ R - np.eye(3)).max()))
    # נקודה במרכז המסגור חייבת ליפול במרכז הפריים בדיוק
    px, dz = AP.project(np.array([[0.0, 1.0, 0.0]]), 0, 0, 3.0, 1.0,
                        32.0, 400, 600)
    check("מרכז המסגור נופל במרכז הפריים",
          abs(px[0, 0] - 200) < 1e-6 and abs(px[0, 1] - 300) < 1e-6,
          [round(float(v), 4) for v in px[0]])
    check("ועומק הנקודה הוא מרחק המצלמה", abs(dz[0] - 3.0) < 1e-9,
          round(float(dz[0]), 6))
    # נקודה בגובה הקצה העליון של שדה הראייה
    half = math.tan(math.radians(16.0)) * 3.0
    px2, _ = AP.project(np.array([[0.0, 1.0 + half, 0.0]]), 0, 0, 3.0, 1.0,
                        32.0, 400, 600)
    check("קצה שדה הראייה האנכי נופל על שפת הפריים",
          abs(float(px2[0, 1])) < 1e-6, round(float(px2[0, 1]), 6))

    rig_dir = paths.rigged()
    if not (rig_dir / "lucas.rig.json").exists():
        skip("מנהל הקסם על הדמויות הבנויות",
             f"אין נכסים ממורגים תחת {rig_dir}")
        return
    chars = [AP.Char(n, rig_dir) for n in ("lucas", "maya")]

    # --- הצללית חייבת להיות **מלאה**, לא קונטור
    ch = chars[0]
    sp = AP.shot_params(ch.height, AP.CONDITIONS[2])
    raw, dzr = AP.project(ch.attrs["position"], sp["yaw"], sp["pitch"],
                          sp["dist"], sp["cy"], sp["fov"], 180, 250)
    thin = AP.raster(raw[dzr > 0], 180, 250)
    s = AP.silhouette(ch, AP.CONDITIONS[2])
    ys, xs = np.nonzero(s["mask"])
    bb = (xs.max() - xs.min() + 1) * (ys.max() - ys.min() + 1)
    fill_thin = float(thin.sum()) / bb
    check(f"רסטר מהקודקודים בלבד מחזיר קונטור מחורר ({fill_thin:.2f} "
          f"מתיבת התוחם) - ולכן יש `densify`", fill_thin < 0.25,
          round(fill_thin, 3))

    # **חורים ולא יחס לתיבת התוחם.** הניסוח הקודם היה
    # `fill_bbox > fill_thin * 1.25`, ושני הגדלים האלה מנורמלים
    # לתיבת התוחם של פוזת ה-A - כלומר הם תלויים ברוחב הזרועות
    # הפרושות ובצללית הגוף. כשהגוף התרחב (TASK 10ב) הרסטר הדל
    # כיסה יותר פיקסלים, היחס ירד ל-1.215, והבדיקה נפלה על דמות
    # תקינה לחלוטין. מה שהיא באמת אמורה להגן עליו הוא **שהצללית
    # אטומה**: בכל שורה, בין הקצה השמאלי לימני אין פיקסלים ריקים.
    # זה נכון בכל צללית ובכל רוחב גוף, ואין בו קבוע שתלוי בדמות.
    # **מנורמל לצללית עצמה ולא לתיבת התוחם.** נוסה כאן גם מדד
    # "חורים בתוך השורה" ונפסל: בפוזת A יש פער אמיתי בין הזרוע
    # לפלג הגוף, ולכן גם הצללית הצפופה מראה 11% "חורים" - כלומר
    # המדד מדד את הפוזה ולא את הרסטור. מה שנשאר, והוא בדיוק הטענה:
    # חלק ניכר מהצללית **קיים רק בזכות `densify`**.
    dense = s["mask"]
    only_dense = float((dense & ~(thin > 0)).sum()) / max(1, dense.sum())
    check(f"ו-`densify` מייצר {only_dense:.0%} מהצללית בעצמו",
          only_dense > 0.10, round(only_dense, 3))
    check("וכל פיקסל של הרסטר הדל נמצא גם בצללית הצפופה",
          float(((thin > 0) & ~dense).sum()) / max(1, (thin > 0).sum())
          < 0.02)

    # --- פרופורציות: נמדדות מהרשת, ובתוך החלון
    for c in chars:
        pr = AP.proportions(c)
        hm = c.head_metrics()
        check(f"[{c.name}] גובה הראש נמדד מהגולגולת ולא מהעצמות "
              f"({hm['h']:.3f} מ')", 0.17 <= hm["h"] <= 0.30, hm["h"])
        check(f"[{c.name}] כל שש הפרופורציות בחלון הקסם "
              f"({pr['values']['heads_tall']:.2f} ראשים)",
              pr["in_window"] == pr["of"], pr["outside"])
        sw = c.shoulder_width()
        check(f"[{c.name}] רוחב הכתפיים נמדד בפוזת מנוחה ולא בפוזת "
              f"הכריכה ({sw:.3f} מ')", 0.25 <= sw <= 0.55, round(sw, 3))

    # --- הזרוע לא מתקצרת כשמצרים כתפיים (באג ריג שנמדד כאן)
    a = Skeleton(height=1.78, shoulder_scale=1.0)
    b = Skeleton(height=1.78, shoulder_scale=0.80)
    def armlen(sk):
        bw = identity.bone_world(sk)
        return (float(np.linalg.norm(bw["upperarm_L"] - bw["forearm_L"]))
                + float(np.linalg.norm(bw["forearm_L"] - bw["hand_L"])))
    check(f"הצרת כתפיים אינה מקצרת את הזרוע "
          f"({armlen(a):.4f} מול {armlen(b):.4f})",
          abs(armlen(a) - armlen(b)) < 1e-9,
          (round(armlen(a), 5), round(armlen(b), 5)))
    bwa, bwb = identity.bone_world(a), identity.bone_world(b)
    check("אבל מפרק הכתף כן זז פנימה",
          float(bwb["upperarm_L"][0]) < float(bwa["upperarm_L"][0]) - 0.01,
          (round(float(bwa["upperarm_L"][0]), 4),
           round(float(bwb["upperarm_L"][0]), 4)))

    # --- הדוח המלא
    rep = AP.evaluate(chars)
    for k, v in rep["checks"].items():
        check(f"[{k}] {v['value']}", v["pass"], v["limit"])

    # --- המדד חייב להיות דו-כיווני: שתי דמויות **זהות** חייבות ליפול
    import copy                                           # noqa: PLC0415
    twin = copy.copy(chars[0])
    twin.name = "twin"
    rec = AP.recognizability([chars[0], twin])
    check(f"שתי דמויות זהות נכשלות בזיהוי (שוליים {rec['margin']})",
          not rec["ok"], rec["margin"])
    sil = AP.silhouette(chars[0], AP.CONDITIONS[0])
    check("וצללית מול עצמה מחזירה מובחנות אפס",
          AP.silhouette_distinctness(sil, sil) == 0.0,
          AP.silhouette_distinctness(sil, sil))

    # --- אביזרים: המשקפיים חייבים להיות בנכס, לא רק בקוד
    lu = chars[0].rig
    check("ללוקאס יש אביזר משקפיים ברשומת הדמות",
          "glasses" in (lu.get("accessories") or []), lu.get("accessories"))
    check("ויש קודקודי משקפיים בגאומטריה",
          int(chars[0].mask_of("glasses").sum()) > 100,
          int(chars[0].mask_of("glasses").sum()))
    check("ועצם המשקפיים קיימת בשלד שנבנה מהרשומה",
          "glasses" in chars[0].skel.by_name,
          sorted(n for n in chars[0].skel.by_name if "glass" in n))
    check("השלד מהרשומה זהה במספר העצמות ל-GLB",
          len(chars[0].skel.bones) == lu["mesh"]["bones"],
          (len(chars[0].skel.bones), lu["mesh"]["bones"]))
    check("ולמאיה אין אביזר (שני המסלולים נבדקים)",
          not (chars[1].rig.get("accessories") or [])
          and "glasses" not in chars[1].skel.by_name)
    # גודל הראש של מאיה מגיע לשלד שהסרטון בונה
    from rig import showreel as SR                         # noqa: PLC0415
    _, sk_m, _ = SR.load_char("maya", rig_dir)
    check("הסרטון בונה את מאיה עם גודל הראש שלה",
          abs(float(identity.bone_world(sk_m)["eye_L"][0])
              - float(chars[1].attrs["position"][:, 0].max() * 0 + 0)) >= 0.0
          and len(sk_m.bones) == chars[1].rig["mesh"]["bones"],
          len(sk_m.bones))
    bw_m = identity.bone_world(sk_m)
    plain = identity.bone_world(Skeleton(height=chars[1].height))
    check("וקו העיניים שלה אינו של שלד ברירת מחדל "
          f"({float(bw_m['eye_L'][0]):.4f} מול {float(plain['eye_L'][0]):.4f})",
          abs(float(bw_m["eye_L"][0]) - float(plain["eye_L"][0])) > 1e-3,
          (round(float(bw_m["eye_L"][0]), 4),
           round(float(plain["eye_L"][0]), 4)))

    # --- תשעת תנאי הרנדור מוגדרים, ושתי תאורות ביניהם
    names = [c[0] for c in AP.CONDITIONS]
    for need in ("close_up", "medium", "wide", "side_profile",
                 "three_quarter", "low_angle", "high_angle"):
        check(f"תנאי «{need}» מוגדר", need in names)
    check("ויש שתי תאורות שונות",
          len([c for c in AP.CONDITIONS if c[6] != "studio"]) >= 2,
          sorted({c[6] for c in AP.CONDITIONS}))
    vh = (HERE / "viewer.html").read_text(encoding="utf-8")
    for light in sorted({c[6] for c in AP.CONDITIONS}):
        check(f"מצב התאורה «{light}» קיים בצופה", f"{light}:" in vh)


def t_hair_recession():
    """נסיגת השיער והלבוש (05/10) - שבע בדיקות, **כולן דו-כיווניות**.

    הסכנה כאן אינה שהנסיגה לא תעבוד אלא שהיא תעבוד *יותר מדי*:
    מי שמוריד רוויה בלי גבול מקבל דמות אפורה שעוברת כל מדד
    היררכיה ונראית מתה. לכן נבדק גם שהפרט **נשאר** במסגרת סביב
    הפנים ושהצבע לא נמחק.
    """
    print("נסיגת השיער והלבוש (05/10):")
    from rig import pipeline as P                         # noqa: PLC0415

    R = 0.115
    face = np.array([0.0, 1.60, 0.09])
    base = np.asarray(P.DEFAULT_PALETTE["hair"], np.float32)
    near = face + np.array([0.0, 0.02, -0.02])            # ליד הפנים
    far = face + np.array([0.0, -R * 3.2, -R * 1.0])      # מסה היקפית
    pos = np.stack([near, far])
    col = np.stack([base * 1.18, base * 1.18]).astype(np.float32)
    out = P.hair_recession(col, pos, base, face, R)

    def sat(c):
        mx, mn = float(max(c)), float(min(c))
        return (mx - mn) / max(mx, 1e-9)

    check("קודקוד שיער שצמוד לפנים כמעט אינו נוגע",
          float(np.abs(out[0] - col[0]).max()) < 0.02,
          float(np.abs(out[0] - col[0]).max()))
    check("ומסת השיער ההיקפית מאבדת רוויה",
          sat(out[1]) < sat(col[1]) * 0.75,
          (round(sat(col[1]), 3), round(sat(out[1]), 3)))
    check("ומתכהה", float(out[1].sum()) < float(col[1].sum()) * 0.92,
          (round(float(col[1].sum()), 3), round(float(out[1].sum()), 3)))
    check("אבל אינה נמחקת לאפור מוחלט",
          sat(out[1]) > 0.08, round(sat(out[1]), 3))
    # הכיוון השני: בלי ההחרגה של הפנים זו הייתה דה-סטורציה גורפת.
    check("הנסיגה מונוטונית במרחק",
          sat(out[0]) > sat(out[1]),
          (round(sat(out[0]), 3), round(sat(out[1]), 3)))
    # הלבוש: טווח אחר לגמרי, ולכן קודקוד חולצה בחזה כן נוגע.
    shirt = np.asarray(P.DEFAULT_PALETTE["shirt"], np.float32)
    chest = face + np.array([0.0, -R * 3.0, 0.0])
    w = P.wear_recession(np.stack([shirt]), np.stack([chest]), shirt,
                         face, R)
    check("הלבוש נסוג גם הוא, ובעוצמה חלשה יותר",
          sat(w[0]) < sat(shirt) and sat(w[0]) > sat(shirt) * 0.70,
          (round(sat(shirt), 3), round(sat(w[0]), 3)))
    check("`focal_recession` עם desat=0 אינו משנה כלום",
          float(np.abs(P.focal_recession(
              col, pos, base, face, R, near=0.1, far=0.2, flatten=0.0,
              desat=0.0, darken=0.0, cool=0.0) - col).max()) < 1e-6)


def t_cinema():
    """מבחן המשחק הקולנועי (TASK 10). הסצנה, שמונת האירועים, ארבעת
    מבחני ההשתקה וחמש ההפרכות - והעיקר: שההפרכות באמת נופלות."""
    print("מבחן המשחק הקולנועי (TASK 10):")
    from rig import cinema as C                           # noqa: PLC0415

    # --- ההשתקה היא מבנית, לא הצהרתית
    frame = {"jaw_open": 0.8, "mouth_stretch": 0.4, "lip_press": 0.3,
             "brow_furrow_L": 0.5, "eye_aim_x": 0.2, "smile": 0.9,
             "tongue_up": 0.1, "chin_raise": 0.2}
    vis = C.visual_only(frame)
    check("`visual_only` מסיר כל ערוץ שההגאים מניעים",
          not any(C.is_audio_driven(k) for k in vis), sorted(vis))
    check("ומשאיר את הערוצים הוויזואליים",
          {"brow_furrow_L", "eye_aim_x"} <= set(vis), sorted(vis))
    check("ערוץ פה שייווסף מחר ייתפס לפי התחילית ולא לפי רשימה",
          C.is_audio_driven("mouth_whatever_new") and
          not C.is_audio_driven("brow_whatever_new"))
    # הכיוון השני: ציון אי-נוחות אינו מגיב לפה
    a = dict(frame)
    b = dict(frame, jaw_open=0.0, mouth_stretch=0.0, smile=0.0)
    check("ולכן ציון אי-הנוחות אדיש לחלוטין לתנועת הפה",
          abs(C.discomfort(a) - C.discomfort(b)) < 1e-9)

    # --- טבלת ה-FACS אינה המצאה
    for nm in C.FACS_DISCOMFORT:
        check(f"יחידת FACS «{nm}» קיימת ב-acting.AU",
              bool(C._au_channels(nm)))
    check("וחיוך מקוזז ולא נספר כאי-נוחות",
          C.discomfort({"cheek_raise_L": 1.0, "cheek_raise_R": 1.0})
          < C.discomfort({}))

    rep = C.audit(fps=20)
    for k, v in rep["checks"].items():
        check(f"[TASK 10] {k}", v["pass"], v["value"])
    check("שמונת האירועים כולם נדרשים", len(C.BEAT_WINDOWS) == 8,
          len(C.BEAT_WINDOWS))
    check("וחמש גרסאות הביקורת נבדקו", len(rep["controls"]) == 5,
          sorted(rep["controls"]))
    # --- ההחלקה: הכיוון השני של מה שתוקן כאן
    import numpy as _np                                   # noqa: PLC0415
    spike = _np.zeros(60)
    spike[30] = 1.0
    sm = C._smooth(spike, 1 / 30.0)
    check("החלקה מרסקת ספייק של פריים בודד", float(sm.max()) < 0.2,
          round(float(sm.max()), 3))
    step = _np.concatenate([_np.zeros(30), _np.ones(30)])
    check("ואינה מוחקת מדרגה אמיתית",
          float(C._smooth(step, 1 / 30.0)[-1]) > 0.95)


def t_hierarchy_robustness():
    """יתרון הפנים שורד שינוי תסרוקת. זו הבדיקה שהערת המשתמש
    מ-05/10 דרשה, והיא הדרישה הנכונה: עד התיקון הפער של מאיה היה
    1.066 מול סף 1.05, כלומר כל שינוי בשיער היה מפיל אותו."""
    print("עמידות היררכיית הקשב לשינוי תסרוקת (05/10):")
    from rig import appeal as AP                          # noqa: PLC0415

    c = np.array([[0.30, 0.17, 0.11]], np.float32)
    up = AP._sat_mul(c, 1.8)
    lum = 0.2126 * c[0, 0] + 0.7152 * c[0, 1] + 0.0722 * c[0, 2]

    def sat(x):
        mx, mn = float(x.max()), float(x.min())
        return (mx - mn) / max(mx, 1e-9)

    check("`_sat_mul` מגביר רוויה", sat(up) > sat(c) * 1.3,
          (round(sat(c), 3), round(sat(up), 3)))
    check("ושומר על הבהירות", abs(float(
        0.2126 * up[0, 0] + 0.7152 * up[0, 1] + 0.0722 * up[0, 2]
        - lum)) < 1e-5)
    check("מבחן הלחץ תוקף ארבע וריאציות שיער",
          len(AP.HAIR_STRESS) >= 4, sorted(AP.HAIR_STRESS))
    rigged = paths.rigged()
    if (rigged / "maya.glb").exists():
        ch = AP.Char("maya", rigged)
        rb = AP.hierarchy_robustness(ch)
        check("ומאיה עוברת את כולן", rb["ok"],
              (rb["worst"], rb["worst_variant"]))
        check("והפער שלה גדל מעבר למרווח שהיה (1.066)",
              rb["base"]["face_lead"] >= 1.15,
              rb["base"]["face_lead"])
        check("ושיער אינו האזור השני בדירוג יותר",
              rb["base"]["order"][1] != "hair", rb["base"]["order"])


# ================================ TASK 10ב: דימורפיזם ודיאלוג חופף
#
# שתי החלטות שקבעו את צורת הבדיקות האלה, ושתיהן אותו עיקרון:
#
# 1. **בדיקת הגאומטריה מודדת קודקודים, לא פרמטרים.** אפשר לכתוב
#    `shoulder_w=0.168` ולהצהיר "כתפיים רחבות" בלי שאף קודקוד זז -
#    למשל אם הפרופיל לא חובר לבנייה, או אם המסגרת הפכה את הצירים
#    (וזה בדיוק מה שהיה כאן). לכן הכול נמדד מ-`mb.v`.
# 2. **כל ההשוואות הן בין שתי הדמויות**, ולא מול קבוע. קבוע שאפשר
#    להזיז עד שהבדיקה תעבור אינו בדיקה.

def t_dimorph():
    print("דימורפיזם מיני (TASK 10ב):")
    from rig import basemesh as BM                        # noqa: PLC0415
    from rig import dimorph as DM                         # noqa: PLC0415

    # --- הסופר-אליפסה: n=2 חייבת להיות האליפסה **בדיוק**, אחרת
    #     הפרמטר החדש משנה דמויות שלא ביקשו אותו.
    mb1, mb2 = BM.MeshBuilder(), BM.MeshBuilder()
    rings = [((0, 0, 0), 0.1, 0.05, {"hips": 1.0}),
             ((0, 0.2, 0), 0.1, 0.05, {"hips": 1.0})]
    rings_n = [(c, a, b, w, 2.0) for c, a, b, w in rings]
    mb1.tube(rings, 24, True, True, "t", (0.0, 1.0, 0.0))
    mb2.tube(rings_n, 24, True, True, "t", (0.0, 1.0, 0.0))
    d = np.abs(np.asarray(mb1.v) - np.asarray(mb2.v)).max()
    check("אקספוננט 2 מחזיר את האליפסה בדיוק", d < 1e-12, d)

    # --- המסגרת המפורשת: rx הוא X ו-rz הוא Z.
    mb3 = BM.MeshBuilder()
    mb3.tube(rings, 24, True, True, "t", (0.0, 1.0, 0.0),
             frame=((1.0, 0.0, 0.0), (0.0, 0.0, -1.0)))
    V = np.asarray(mb3.v)
    ex = float(np.abs(V[:, 0]).max())
    ez = float(np.abs(V[:, 2]).max())
    check("עם frame מפורש rx הוא הרוחב", abs(ex - 0.1) < 1e-9, ex)
    check("ו-rz הוא העומק", abs(ez - 0.05) < 1e-9, ez)
    # והנורמלים לא התהפכו: סימן הנפח החתום של הצינור נשמר.
    def _vol(mb):
        P = np.asarray(mb.v)
        T = np.asarray(mb.f)
        a, b, c = P[T[:, 0]], P[T[:, 1]], P[T[:, 2]]
        return float(np.sum(np.einsum("ij,ij->i", a, np.cross(b, c))) / 6.0)
    check("והמסגרת שומרת על כיווניות הפאות",
          np.sign(_vol(mb3)) == np.sign(_vol(mb1)),
          (round(_vol(mb1), 6), round(_vol(mb3), 6)))

    # --- פרופיל הזרוע: מונוטוני אצל מאיה, לא-מונוטוני אצל לוקאס.
    pm = [r[1] for r in DM.arm_profile(DM.MASC)]
    pf = [r[1] for r in DM.arm_profile(DM.FEM)]
    check("פרופיל הזרוע הנשי יורד בהדרגה בלי חריגה",
          all(pf[i + 1] <= pf[i] + 1e-12 for i in range(len(pf) - 1)), pf)
    check("והגברי מכיל עלייה - שריר",
          any(pm[i + 1] > pm[i] + 1e-12 for i in range(len(pm) - 1)), pm)

    # --- והמדידה על הרשת שנבנתה בפועל.
    rep = DM.audit("fast")
    for k, v in rep["checks"].items():
        check(f"[{k}] {v['how'][:48]}", v["pass"],
              f"{v['value']} (גבול {v['limit']})")
    check("דוח הדימורפיזם עובר במלואו", rep["passed"])

    # --- ושהדמויות בהרכב באמת מקבלות מבנה, ולא ברירת מחדל.
    from rig import pipeline as PL                        # noqa: PLC0415
    for name, want in (("lucas", "masc"), ("maya", "fem")):
        got = PL.CAST[name]["shape_override"].get("dimorph")
        check(f"{name} משויך למבנה «{want}»", got == want, got)


def t_shape_language():
    """
    זיגי מול גרומפ: ניגוד **שפת צורות**, לא ניגוד מין (05/10).

    הבקשה הייתה ששתי דמויות חדשות ייבנו בשפות צורה הפוכות - עגול
    וזורם מול מלבני ונוקשה - "ולא שכפולים". הסכנה האמיתית אינה
    שהמנוע לא יבנה, אלא שהוא יבנה שתי וריאציות של אותו גוף ויקרא להן
    בשמות חדשים, ושום דבר בקוד לא יידע. לכן ההוכחה היא מדידה של
    הצללית מהרשת שנבנתה, בדיוק כמו בדימורפיזם.
    """
    print("שפת צורות - זיגי מול גרומפ:")
    from rig import dimorph as DM                         # noqa: PLC0415
    from rig import pipeline as PL                        # noqa: PLC0415

    # --- התקנים עצמם: עגול הוא אליפסה טהורה, מרובע הוא סופר-אליפסה.
    check("זיגי בלי שום זווית בכתף", DM.ROUND.shoulder_square == 0.0,
          DM.ROUND.shoulder_square)
    check("גרומפ עם כתף מרובעת ממש", DM.BLOCK.shoulder_square >= 2.0,
          DM.BLOCK.shoulder_square)
    check("חתך זיגי כמעט מעגלי (rx≈rz בחזה)",
          abs(DM.ROUND.chest_w - DM.ROUND.chest_d) <= 0.012,
          (DM.ROUND.chest_w, DM.ROUND.chest_d))
    check("חזה גרומפ לוח ולא חבית",
          DM.BLOCK.chest_w - DM.BLOCK.chest_d >= 0.035,
          (DM.BLOCK.chest_w, DM.BLOCK.chest_d))
    check("לגרומפ אין מותן - גוף נוקשה אינו מתעקל",
          DM.BLOCK.waist_w >= DM.BLOCK.hip_w, (DM.BLOCK.waist_w, DM.BLOCK.hip_w))
    check("ולזיגי יש התעקלות רכה", DM.ROUND.waist_w < DM.ROUND.hip_w,
          (DM.ROUND.waist_w, DM.ROUND.hip_w))
    check("גפיים דקות אצל זיגי ועבות אצל גרומפ",
          DM.BLOCK.arm_base - DM.ROUND.arm_base >= 0.02,
          (DM.ROUND.arm_base, DM.BLOCK.arm_base))
    check("זרוע גרומפ גליל שאינו מתכנס", DM.BLOCK.arm_taper >= 1.0,
          DM.BLOCK.arm_taper)

    # --- והמדידה על הרשת שנבנתה בפועל, שהיא ההוכחה היחידה.
    rep = DM.audit_shape("fast")
    for k, v in rep["checks"].items():
        check(f"[{k}] {v['why'][:48]}", v["pass"],
              f"זיגי={v['zippy']} גרומפ={v['grump']} פער={v['gap']}")
    check("דוח שפת הצורות עובר במלואו", rep["passed"])

    # --- ושההרכב באמת מפנה אליהן, ולא לברירת מחדל ניטרלית.
    for name, want in (("zippy", "round"), ("grump", "block")):
        check(f"{name} משויך לשפת הצורות «{want}»",
              PL.CAST[name]["shape_override"].get("dimorph") == want,
              PL.CAST[name]["shape_override"].get("dimorph"))
    # והדמויות הישנות לא נגעו: תוספת אינה החלפה.
    for name, want in (("lucas", "masc"), ("maya", "fem")):
        check(f"{name} לא השתנה", PL.CAST[name]["shape_override"].get("dimorph") == want,
              PL.CAST[name]["shape_override"].get("dimorph"))
    check("זיגי נמוכה מגרומפ - ניגוד גם בצללית הכוללת",
          PL.CAST["zippy"]["height"] < PL.CAST["grump"]["height"] - 0.2,
          (PL.CAST["zippy"]["height"], PL.CAST["grump"]["height"]))

    # --- חוזה התסריט בן 50 השניות. תסריט שמספריו לא נסגרים הוא תקלה
    #     שמתגלה רק אחרי שעת רינדור, ולכן הוא נבדק כאן ולא שם.
    import importlib.util                                 # noqa: PLC0415
    from pathlib import Path as _P                        # noqa: PLC0415
    sp = _P(__file__).resolve().parent.parent / "production" / "script" / "sunbeam50.py"
    spec = importlib.util.spec_from_file_location("sunbeam50", sp)
    sb = importlib.util.module_from_spec(spec)
    # **חובה לפני `exec_module`:** `@dataclass` מחפש את המודול ב-
    # `sys.modules[cls.__module__]`, ובלי הרישום הוא מקבל None ונופל
    # ב-AttributeError באמצע טעינת הקובץ. נתפס כאן בהרצה.
    sys.modules.setdefault("sunbeam50", sb)
    spec.loader.exec_module(sb)
    for k, v in sb.validate().items():
        check(f"[תסריט] {k}", v["pass"], v["detail"])
    check("התסריט משתמש בדמויות החדשות", set(sb.CAST) == {"zippy", "grump"},
          sb.CAST)


def t_duet():
    print("דיאלוג חופף ומשחק שתי דמויות (TASK 10ב):")
    from rig import duet as D                             # noqa: PLC0415

    check("חלון הדיבור של מאיה נפתח בתוך זה של לוקאס",
          D.L_SPEECH[0] < D.M_SPEECH[0] < D.L_SPEECH[1],
          (D.L_SPEECH, D.M_SPEECH))
    check("והחפיפה חיובית", D.OVERLAP > 0.2, D.OVERLAP)

    # --- המראה היא מראה: מיפוי כפול מחזיר את המקור.
    f = {"weight_shift": 0.4, "shoulder_up_L": 0.2, "shoulder_up_R": -0.1,
         "head_yaw": 0.3, "breath": 0.5}
    check("מיפוי מראה כפול מחזיר את הפריים",
          D.mirror(D.mirror(f)) == f, D.mirror(D.mirror(f)))
    check("ומראה הופכת את סימן הערוץ הצדי",
          D.mirror(f)["weight_shift"] == -0.4)
    check("ומחליפה צדדים", D.mirror(f)["shoulder_up_R"] == 0.2)
    check("ואינה נוגעת בערוץ שאינו צדי",
          D.mirror(f)["breath"] == 0.5)

    # --- הנשימה התגובתית: השאיפה החדה יושבת על רגע ההפרעה.
    ts = np.linspace(0.0, D.SCENE_LEN, 541)
    dlt = np.array([D.reactive_breath("lucas", float(t), True)
                    - D.reactive_breath("lucas", float(t), False)
                    for t in ts])
    at = float(ts[int(np.argmax(np.abs(dlt)))])
    check("שיא התגובה של לוקאס נופל על רגע ההפרעה",
          abs(at - D.CUT_IN) < 0.30, (round(at, 3), D.CUT_IN))
    before = np.abs(dlt[ts < D.CUT_IN - 0.5]).max()
    check("ולפניה אין תגובה בכלל", before < 1e-9, before)

    # --- פס הקול: כאן החפיפה **נדרשת**, בניגוד לסצנות TASK 06.
    from rig import showreel as SH                        # noqa: PLC0415
    shots = SH.build_shots_duet(1.70)
    check("יש ארבע סצנות לדואט", len(shots) == 4, len(shots))
    check("לכל סצנה כתובית ומשפט הוכחה",
          all(s.cap and s.proves for s in shots))
    cues = SH.soundtrack_cues(shots)
    check("שני קטעי קול לכל שוט דיאלוג", len(cues) >= 4, len(cues))
    over = [(round(a, 2), round(b, 2))
            for (a, ta), (b, _tb) in zip(cues, cues[1:])
            if b < a + ta.seconds - 0.05]
    # **ההפך מ-`t_body_scenes`.** שם חפיפה היא תקלה (שתי דמויות
    # שאומרות את אותו משפט באותה שנייה נשמעות כהד); כאן היא
    # הדרישה, ו-`voice.mix` מחבר את הקטעים עם הגבלה רכה.
    check("ובפס הקול יש חפיפה אמיתית - זו הדרישה כאן", bool(over), over)

    # --- וכל הבקרות חוקיות ובטווח, בשני השוטים.
    from rig import controls as C                         # noqa: PLC0415
    for s in shots:
        for fn in (s.a, s.b):
            ctl = fn(0.45, s.secs * 0.45)[0] or {}
            if not ctl:
                continue
            bad = [k for k in ctl if k not in C.CONTROLS]
            check(f"[{s.key}] כל הבקרות חוקיות", not bad, bad[:3])
            nrm = C.normalize(ctl)
            check(f"[{s.key}] הערכים בטווח",
                  all(C.CONTROLS[k][0] - 1e-9 <= v <= C.CONTROLS[k][1] + 1e-9
                      for k, v in nrm.items()))

    # --- ערוץ הנשימה אינו רווי. זה הפגם שנמדד 05/10: שני מודולים
    #     הנפישו אותו במלוא העוצמה וחוברו, ואצל מאיה 28% מהפריימים
    #     נקטמו על 1.0 - כלומר בית החזה נעצר בשיא כל נשימה.
    for who in ("lucas", "maya"):
        fn = D.actor(who)
        b = np.array([fn(0.0, float(t))[0].get("breath", 0.0)
                      for t in np.linspace(0, D.SCENE_LEN, 181)])
        sat = float(np.mean(np.abs(b) >= 0.999))
        check(f"[{who}] ערוץ הנשימה אינו רווי", sat < 0.01,
              f"{sat:.1%} מהפריימים")
        check(f"[{who}] ובכל זאת הנשימה נראית",
              float(b.max() - b.min()) > 0.25, round(float(b.max() - b.min()), 3))

    # --- הדוח המלא, כולל חמש ההפרכות.
    rep = D.audit()
    for k, v in rep["checks"].items():
        check(f"[{k}] {v['how'][:48]}", v["pass"],
              f"{v['value']} (גבול {v['limit']})")
    check("דוח הדואט עובר במלואו", rep["passed"])


def t_park():
    """
    שכבת הסביבה הצרובה וסצנת החוץ בת 50 השניות (05/10).

    כל מקרה כאן הוא **תקלה שנתפסה בפועל** בבנייה של היום, ולא
    בדיקה שנכתבה "ליתר ביטחון".
    """
    import tempfile
    from pathlib import Path as _P

    from production.script import sunbeam50 as SB
    from rig import park as PK

    print("סביבה צרובה - פארק:")

    # --- וקטור הצל. שתי התקלות שההגנה הזאת מונעת.
    dx, dy = PK.shadow_vector(-62.0, 24.0)
    check("שמש משמאל => הצל נמשך ימינה", dx > 0, round(dx, 3))
    check("שמש נמוכה => צל ארוך מגובה העצם",
          (dx ** 2 + dy ** 2) ** 0.5 > 1.8, round((dx**2 + dy**2) ** 0.5, 3))
    hi = PK.shadow_vector(-62.0, 70.0)
    check("ושמש גבוהה => צל קצר", abs(hi[0]) < abs(dx), round(hi[0], 3))
    # elevation אפס היה נותן אורך אינסופי, ו-PIL היה מצייר אליפסה
    # בגודל מיליוני פיקסלים עד לקריסת זיכרון.
    zero = PK.shadow_vector(-62.0, 0.0)
    check("אורך הצל חסום גם ב-elevation אפס",
          (zero[0] ** 2 + zero[1] ** 2) ** 0.5 <= 6.5, round(zero[0], 3))

    # --- הצריבה עצמה, לתיקייה זמנית. זו הבדיקה שמוודאת שהסביבה
    #     באמת מיוצרת ולא רק שהחוזה שלה נראה טוב.
    with tempfile.TemporaryDirectory(prefix="parkqa_") as d:
        man = PK.bake(d, SB.LOCATION, width=640, height=360)
        rep = PK.validate(man, d)
        for k, v in rep.items():
            check(f"[סביבה] {k}", v["pass"], v["detail"])
        check("הסביבה נצרבת פעם אחת ולא פר פריים", man["baked_once"] is True)
        sizes = {k: (_P(d) / v).stat().st_size for k, v in man["layers"].items()}
        check("כל שכבה היא קובץ אמיתי ולא קובץ ריק",
              all(s > 400 for s in sizes.values()), sizes)

    # --- **תקלה שנתפסה ברנדור המלא, 06/10.** אריח האור המנוקד מונח
    #     בדפדפן ב-`background-repeat:repeat`, ולכן הוא חוזר כל 1024
    #     פיקסלים לרוחב הפריים. האריח הראשון צויר כתמונה רגילה -
    #     כתם ליד הקצה נחתך ולא המשיך בצד השני, והטשטוש משך פנימה
    #     את פיקסלי השפה. התוצאה בפריים המלא: קו אנכי חד מלמעלה עד
    #     למטה, בדיוק כל 1024 פיקסלים, בארבעת השוטים. נמדד: קפיצה
    #     של 71 רמות בהירות בתפר. אחרי התיקון (ציור מעוטף + טשטוש
    #     על פרישת 3x3 וחיתוך המרכז) הקפיצה היא 0.006.
    #
    #     נבדק בכמה זרעים: תפר נוצר מכתם *שנופל* ליד הקצה, ולכן זרע
    #     אחד יכול לעבור במקרה גם בקוד שבור.
    import random as _rnd
    for _seed in (7, 11, 42):
        sx, sy = PK.tile_seam(PK._dapple(256, _rnd.Random(_seed)))
        check(f"[זרע {_seed}] אריח האור המנוקד מתלכד ואינו מצייר קו אנכי",
              max(abs(sx), abs(sy)) <= 1.5, (sx, sy))

    # --- ציר הזמן של הסרט, בפריימים.
    from rig import sunbeam as SBM
    shots = SBM.build_shots(1.42)
    tl = SBM.validate_timeline(shots, fps=30)
    for k, v in tl.items():
        check(f"[ציר זמן] {k}", v["pass"], v["detail"])

    # --- חוזה התסריט, כולל אורכי ההקלטה.
    for k, v in SB.validate().items():
        check(f"[תסריט] {k}", v["pass"], v["detail"])

    # --- הניגוד שהתסריט בנוי עליו: זיגי באוויר, גרומפ שוקע.
    lift = SBM._lift_of("s1_park_wide")
    zs = [lift("zippy", t / 30) for t in range(90)]
    gs = [lift("grump", t / 30) for t in range(90)]
    check("זיגי באמת עוזבת את הקרקע", max(zs) > 0.10, round(max(zs), 3))
    check("ולא שוקעת מתחתיה", min(zs) >= -1e-9, round(min(zs), 5))
    check("גרומפ שוקע במשקלו ולא מתרומם",
          max(gs) <= 1e-9 and min(gs) < -0.005,
          (round(max(gs), 5), round(min(gs), 5)))

    # --- הבמה: השכבות קיימות, והשמש מוכוונת ולא רק נצבעת.
    stage = (HERE / "stage.html").read_text(encoding="utf-8")
    for frag in ("envSky", "envFar", "envGround", "envNear", "envDap",
                 "flare"):
        check(f"דף הבמה מכיל את שכבת {frag}", frag in stage)
    check("יש פונקציית הזרקת סביבה", "window.__env" in stage)
    check("השמש מוכוונת לזווית ולא רק מוחלפת בעוצמה",
          "function aimSun" in stage and "sun_hard_left" in stage)
    # ה-target של אור מכוון חייב להיות בתוך הסצנה, אחרת ההכוונה
    # פשוט לא נתפסת - והכשל שקט לגמרי.
    check("מטרת האור נוספת לסצנה", "scene.add(key.target)" in stage)
    check("מישור הצל גדל עם השמש הנמוכה כדי שהצל לא ייחתך",
          "Math.tan(e)" in stage)
    # transform ולא background-position: הזזת רקע מאלצת צביעה
    # מחדש של כל השכבה בכל פריים.
    check("הרקע זז ב-transform ולא בצביעה מחדש",
          "el.style.transform" in stage)

    # --- דמות שאינה מדברת בשוט. עד 05/10 זה היה מרסק את בניית
    #     השוט כולו, וזה מצב לגיטימי בדיאלוג של שניים.
    from rig import body as B
    for it in B._PLAYBOOK:
        gs2 = B.gestures_for(it, "", 0.4, 1.8, want=1.0, arousal=0.9)
        check(f"[{it}] דמות בלי שורה אינה מפילה את בניית המחוות",
              all(g.anchor or g.kind in ("beat", "adaptor") for g in gs2),
              [g.kind for g in gs2])
        # **הבאג השני, והוא היה חמור יותר:** המחווה השנייה לא קיבלה
        # עוגן לעולם, ולכן כל כוונה שבה היא אינה `beat` קרסה גם
        # כשיש טקסט מלא. `seek` היא כזו, והיא לא נבחרה עד 05/10.
        gs3 = B.gestures_for(it, "בוא נרוץ עד העץ הגדול שם", 0.4, 1.8,
                             want=1.0, arousal=0.9)
        check(f"[{it}] וכשיש שורה, כל המחוות של הכוונה נבנות",
              len(gs3) == len(B._PLAYBOOK[it]),
              f"{len(gs3)}/{len(B._PLAYBOOK[it])} {[g.kind for g in gs3]}")


def t_facestyle():
    """
    TASK 11 · שפת הצורות של הפנים, השיער והבגד (06/10).

    מה שהבדיקות כאן שומרות עליו, ולמה כל אחת מהן נולדה מתקלה:

    * **ברירת המחדל זהה מספרית.** מחולל הראש משותף לכל הדמויות
      בפרויקט. אם `plain` אינו זהות מדויקת, כל שינוי כאן מזיז גם את
      לוקאס ומאיה - ואת זה אף בדיקה אחרת לא תתפוס, כי הן מודדות
      יחסים ולא ערכים.
    * **העיוות ב-XZ שומר על Y.** כל תו פנים ממוקם בגובה. עיוות
      שמזיז Y מזיז את האף והפה ביחס לגולגולת, והתוצאה אינה קריסה
      אלא פנים מעוותות - כלומר כשל שקט.
    * **שיטוח הקודקוד אינו יכול להזיז את קו השיער.** הסף 0.70 קיים
      בדיוק לשם כך: קו השיער הקדמי הוא 0.63.
    * **עין ענקית אינה חוצה את גשר האף.** מרכז העין קבוע בשלד,
      ולכן הגדלת הרדיוס ב-52% הייתה יכולה לחבר את שתי העיניים לכתם
      אחד. זה גבול מדיד, לא עניין של טעם.
    """
    print("שפת צורות הפנים (TASK 11):")
    from rig import facestyle as FS                        # noqa: PLC0415
    from rig import pipeline as PL                         # noqa: PLC0415
    from rig import secondary as SC                        # noqa: PLC0415

    # --- 1. ברירת המחדל היא זהות מדויקת
    s = Skeleton(height=1.70)
    P = {b.name: np.asarray(b.rest, float) for b in s.bones}
    Hp = detail.Head(P, 1.0, {})
    check("ברירת המחדל היא הראש שהיה (קני האליפסואיד)",
          tuple(np.round(Hp.scale, 6)) == (0.92, 1.12, 1.00),
          tuple(Hp.scale))
    check("ובהיצרות הפנים התחתונות", abs(Hp.narrow(0.0) - 0.70) < 1e-12,
          Hp.narrow(0.0))
    pt = np.array([0.031, Hp.hc[1] + 0.4 * Hp.R, Hp.hc[2] + 0.05])
    check("ובלי שום עיוות - warp מחזיר את אותו אובייקט",
          Hp.warp_xz(pt) is pt and Hp.warp_y(pt) is pt)
    check("ובמשרעת החיוך", FS.PLAIN.smile == 1.0 and FS.PLAIN.eye == 1.0)

    # --- 2. העיוות שומר על Y, ושיטוח הקודקוד אינו נוגע בקו השיער
    Hg = detail.Head(P, 1.0, {"face": "grim"})
    for rel in (-0.5, -0.2, 0.0, 0.3, 0.63, 0.9):
        q = np.array([0.021, Hg.hc[1] + rel * Hg.R, Hg.hc[2] + 0.04])
        check(f"עיוות ה-XZ שומר על הגובה (rel={rel})",
              abs(float(Hg.warp_xz(q)[1] - q[1])) < 1e-12)
    for rel in (0.0, 0.40, 0.63, 0.699):
        q = np.array([0.0, Hg.hc[1] + rel * Hg.R, Hg.hc[2]])
        check(f"שיטוח הקודקוד אינו מזיז את rel={rel}",
              abs(float(Hg.warp_y(q)[1] - q[1])) < 1e-12)
    qt = np.array([0.0, Hg.hc[1] + 0.95 * Hg.R, Hg.hc[2]])
    check("אבל הוא כן משטח את הקודקוד עצמו",
          float(Hg.warp_y(qt)[1]) < float(qt[1]) - 0.004 * Hg.R,
          round(float((Hg.warp_y(qt)[1] - Hg.hc[1]) / Hg.R), 4))

    # --- 3. התקנים: הכיוון נקבע מהעיצוב
    check("זיגי: גולגולת כדורית לחלוטין",
          tuple(FS.JOY.skull) == (1.0, 1.0, 1.0) and
          FS.JOY.skull_square == 0.0 and FS.JOY.crown_flat == 0.0,
          FS.JOY.skull)
    check("גרומפ: חתך מרובע ופרופיל קופסה",
          FS.GRIM.skull_square >= 1.5 and FS.GRIM.skull_box >= 1.5,
          (FS.GRIM.skull_square, FS.GRIM.skull_box))
    check("זיגי: עין ענקית, גרומפ: עין קטנה",
          FS.JOY.eye >= 1.4 > 1.0 > FS.GRIM.eye,
          (FS.JOY.eye, FS.GRIM.eye))
    check("זיגי: חיוך מוגזם, גרומפ: פה כקו ישר",
          FS.JOY.smile >= 1.4 and FS.GRIM.mouth_arc == 0.0,
          (FS.JOY.smile, FS.GRIM.mouth_arc))
    check("זיגי: שיער מתולתל, גרומפ: שיער קשיח",
          FS.JOY.hair_coil > 0 and FS.GRIM.hair_coil == 0.0 and
          FS.GRIM.hair_wob < 0.3, (FS.JOY.hair_coil, FS.GRIM.hair_wob))
    check("זיגי: היגררות גבוהה, גרומפ: נמוכה",
          FS.JOY.hair_follow > 1.0 > FS.GRIM.hair_follow,
          (FS.JOY.hair_follow, FS.GRIM.hair_follow))

    # --- 3ב. TASK 12 · חיתוך הלסת כתכונה של שפת הצורות (06/10).
    # הבאג שנתפס ברנדור: הראש של זיגי נמדד כספרה בכל השערים ובכל זאת
    # נראה בתקריב כדלי שטוח. הסיבה היא `under` ב-`basemesh._head`,
    # שמרים את הקוטב התחתון של הכדור ב-0.26R ומושך אותו אחורה
    # ב-0.40R - כלומר הופך את תחתית הכדור למדף - והוא היה קבוע מקודד
    # לכל דמות. כאן הוא תכונה, וברירת המחדל שלה חייבת להיות 1.0
    # **בדיוק**: מכפלה ב-1.0 היא זהות מדויקת בנקודה צפה, וזה מה
    # ששומר על לוקאס, מאיה וגרומפ בלי שינוי של ספרה אחת.
    check("ברירת המחדל של חיתוך הלסת היא 1.0 בדיוק",
          FS.PLAIN.jaw_under == 1.0 and FS.GRIM.jaw_under == 1.0,
          (FS.PLAIN.jaw_under, FS.GRIM.jaw_under))
    for v in (0.0, 0.137, 0.5, 1.0, 1.9):
        check(f"ומכפלה ב-1.0 אינה משנה אף ספרה (v={v})",
              v * FS.PLAIN.jaw_under == v)
    check("ולזיגי החיתוך מופחת, אחרת תחתית הכדור נחתכת למדף",
          0.0 < FS.JOY.jaw_under < 0.6, FS.JOY.jaw_under)

    # --- 3ג. TASK 12 · שפת כובע השיער יושבת **מעל** העור.
    # הבאג: `t` בקו השיער היה -0.045, כלומר הכובע נכנס אל תוך
    # הגולגולת וצץ ממנה רק סביב v=0.10. מה שנראה בפרופיל כ"קו השיער"
    # לא היה שפת הכובע אלא **קו החיתוך בין שני משטחים**, וקו חיתוך
    # בין שתי רשתות בחלוקה שונה הוא תמיד מדרגות - מדרגות עם הצללה
    # ועובי, להבדיל ממדרגת הצבע שכבר רוככה ב-`hair_mix`.
    check("שפת כובע השיער חיובית ממש", detail.HAIR_LIP > 0.0,
          detail.HAIR_LIP)

    def _cap_t(v: float, uz: float = 1.0, wob: float = 1.0) -> float:
        """אותו ביטוי עובי בדיוק כמו ב-`detail.add_hair`, בלי החריצים
        (שהם מכפיל סביב 1 ואינם משנים את הסימן בשפה)."""
        return ((0.085 + 0.055 * detail._ss(0.4, -0.8, uz)) *
                detail._ss(0.03, 0.30, v) +
                detail.HAIR_LIP * detail._ss(0.16, 0.0, v))

    for v in (0.0, 0.02, 0.05, 0.08, 0.10, 0.16, 0.30, 0.6, 1.0):
        for uz in (-1.0, 0.0, 1.0):
            check(f"עובי הכובע אינו שלילי באף נקודה (v={v}, uz={uz})",
                  _cap_t(v, uz) >= 0.0, round(_cap_t(v, uz), 5))
    check("ובשפה עצמה הוא חיובי ממש, ולכן אין חיתוך עם הגולגולת",
          _cap_t(0.0) > 0.0, round(_cap_t(0.0), 5))
    # וההוכחה על הרשת. **ההשוואה חייבת להיות באותו כיוון בנייה.**
    # ניסיון ראשון השווה כל קודקוד כובע אל `surf` של הכיוון שבו הוא
    # יושב בפועל - וזה שגוי: `surf` מעוות, ולכן כיוון הנקודה שהוא
    # מחזיר אינו הכיוון שהוזן לו. על גרומפ (קודקוד שטוח + פרופיל
    # קופסה) זה נתן "שקיעה" מדומה של 0.103R על כובע שאינו שוקע כלל.
    # כאן הטבעת התחתונה של הכובע משוחזרת מאותן נוסחאות בדיוק,
    # ומושווית אל הגולגולת **באותו `u`**.
    for who in ("lucas", "zippy", "grump"):
        cc = PL.CAST[who]
        csh = dict(cc["shape_override"])
        cs = Skeleton(height=cc["height"],
                      shoulder_scale=float(csh.get("shoulder_scale", 1.0)),
                      accessories=tuple(cc["accessories"]))
        cp = {b.name: np.asarray(b.rest, float) for b in cs.bones}
        Hc = detail.Head(cp, cc["height"] / 1.70, csh)
        worst = 1e9
        for si in range(48):
            th = si / 48 * 2 * math.pi
            cx, cz = math.cos(th), math.sin(th)
            yy = Hc.hairline(np.array([cx, 0.0, cz]))
            for _ in range(2):
                rxy = math.sqrt(max(1e-6, 1.0 - min(0.98, yy * yy)))
                yy = Hc.hairline(np.array([cx * rxy, yy, cz * rxy]))
            yy = max(-0.92, min(0.92, yy))
            phi = math.acos(yy) * 1.07
            u = np.array([math.sin(phi) * math.cos(th), math.cos(phi),
                          math.sin(phi) * math.sin(th)])
            base = Hc.surf(u)
            t0 = _cap_t(0.0, float(u[2]))
            lift = float(np.linalg.norm(base - Hc.hc)) * t0 / Hc.R
            worst = min(worst, lift)
        check(f"[{who}] שפת הכובע מורמת מעל העור ואינה שוקעת בגולגולת",
              worst > 1e-9, round(worst, 6))

    # --- 4. ההרכב באמת מפנה לשפות החדשות
    for name, want in (("zippy", "joy"), ("grump", "grim")):
        check(f"{name} משויך לשפת פנים «{want}»",
              PL.CAST[name]["shape_override"].get("face") == want,
              PL.CAST[name]["shape_override"].get("face"))
    for name in ("lucas", "maya"):
        check(f"{name} נשאר בלי שפת פנים (לא נגעתי בו)",
              "face" not in PL.CAST[name]["shape_override"])

    # --- 5. המדידה על הרשת שנבנתה, שהיא ההוכחה היחידה.
    # **באיכות מלאה ולא בטיוטה** (06/10): שלושה מהשערים - סליל רכסי
    # הכובע ורוחב רצועת המעבר - נמדדים על פרטים שרשת טיוטה אינה
    # דוגמת כלל (הרכסים הם 15 על ההיקף, ולטיוטה יש 28 קודקודים שם),
    # ולכן הם מדולגים בה. שער שמדולג אינו שומר על כלום.
    rep = FS.audit("full")
    for k, v in rep["checks"].items():
        check(f"[{k}] {v['why'][:46]}", v["pass"],
              f"זיגי={v['zippy']} גרומפ={v['grump']} פער={v['gap']}")
    check("דוח שפת הפנים עובר במלואו", rep["passed"])
    skipped = [k for k, v in rep["checks"].items() if v.get("skip")]
    check("ובאיכות מלאה אף שער אינו מדולג", not skipped, skipped)
    # ובטיוטה הדילוג אכן מסומן כדילוג ולא נספר כהצלחה
    rep_f = FS.audit("fast")
    check("ובטיוטה השערים שאי אפשר למדוד מסומנים כמדולגים",
          {k for k, v in rep_f["checks"].items() if v.get("skip")} ==
          {"cap_coil", "grump_cap_coil_abs", "zippy_cap_coil_abs",
           "grump_hairline_band_abs", "zippy_hairline_band_abs"},
          [k for k, v in rep_f["checks"].items() if v.get("skip")])

    # --- 6. העיניים של זיגי אינן מתחברות לכתם אחד
    zc = PL.CAST["zippy"]
    zsh = dict(zc["shape_override"])
    zs = Skeleton(height=zc["height"],
                  shoulder_scale=float(zsh.get("shoulder_scale", 1.0)))
    zp = {b.name: np.asarray(b.rest, float) for b in zs.bones}
    Hz = detail.Head(zp, zc["height"] / 1.70, zsh)
    gap = abs(float(Hz.eye_center("L")[0] - Hz.eye_center("R")[0])) \
        - 2 * Hz.eye_r
    check("עין זיגי ענקית אבל לא חוצה את גשר האף", gap > 0.0015,
          round(gap, 5))
    # והקרנית עדיין פורצת את העור, אחרת אין עיניים בתקריב
    mbz, _m = basemesh.build(zs, zsh, quality="fast")
    probe = detail.skin_probe(mbz, Hz)
    e = Hz.eye_center("L")
    d = e - Hz.hc + np.array([0.0, 0.0, Hz.eye_r])
    front = float(np.linalg.norm(d))
    check("וקרנית זיגי פורצת את פני העור", front > probe(d) - 0.0006,
          (round(front, 5), round(probe(d), 5)))

    # --- 7. הפה של גרומפ הוא קו ישר **ברשת**, ולא רק בהגדרה
    gc = PL.CAST["grump"]
    gsh = dict(gc["shape_override"])
    gs = Skeleton(height=gc["height"],
                  shoulder_scale=float(gsh.get("shoulder_scale", 1.0)))
    mbg, _m = basemesh.build(gs, gsh, quality="fast")
    lip = None
    for nm, a, b in mbg.groups:
        if nm == "lip_up":
            lip = np.asarray(mbg.v[a:b], float)
    gp = {b.name: np.asarray(b.rest, float) for b in gs.bones}
    Hgr = detail.Head(gp, gc["height"] / 1.70, gsh)
    spread = float(lip[:, 1].max() - lip[:, 1].min()) / Hgr.R
    check("שפת גרומפ העליונה שטוחה (פה זועף)", spread < 0.085,
          round(spread, 4))

    # --- 8. ההיגררות באמת הועברה לעצמות הרכות
    soft = {p.bone for p in SC.HAIR}
    for mb_, nm in ((mbz, "זיגי"), (mbg, "גרומפ")):
        sh = [sum(v for kk, v in mb_.w[i].items() if kk in soft)
              for i, tg in enumerate(mb_.tag) if tg == "hair"]
        check(f"שיער {nm} קשור לעצמות הרכות", len(sh) > 50 and max(sh) > 0.05,
              (len(sh), round(max(sh) if sh else 0.0, 3)))

    # --- 9. ראש מעוצב עם אביזר אינו מפיל את בניית המשקפיים
    gs2 = Skeleton(height=1.74, accessories=("glasses",))
    mb2, meta2 = basemesh.build(gs2, gsh, quality="fast")
    check("משקפיים נבנים גם על ראש מעוצב",
          any(g.startswith("glass") for g in meta2["groups"]),
          [g for g in meta2["groups"] if "glass" in g][:3])
    check("ואין nan/inf ברשת מעוצבת",
          bool(np.all(np.isfinite(np.asarray(mb2.v, float)))))

    # --- 10. **הפער האחרון של TASK 11: מעבר הצבע בקו השיער** (06/10)
    #
    # מה שנראה בתקריב של גרומפ היה "מעבר צבע משונן במצח", והאבחון
    # הנכון שלו אינו רנדור אלא חשבון: צבע קודקוד הוא הכרעה אחת
    # לקודקוד, התגית שקובעת אותו בינארית (`in_hair > 0.5`), וקו
    # השיער עובר באלכסון לרשת וזז לאורכה - ולכן הוא חותך כל עמוד
    # בגובה אחר, והגבול הוא שיניים ברוחב מרובע שלם.
    #
    # שלוש בדיקות, ולכל אחת תפקיד נפרד:
    #   (א) שהמדרגה אכן נפרשה - נמדד מהצבע האפוי, לא מהכוונה.
    #   (ב) **שהבדיקה הזו בכלל מסוגלת להיכשל**: עם ריכוך מאופס היא
    #       חייבת לחזור למדרגה מלאה. בלי זה היא בדיקה שתמיד עוברת.
    #   (ג) שברירת המחדל לא זזה באף ספרה - הניסוח בנקודה צפה.
    def _front_step(name, fade=None):
        c = PL.CAST[name]
        sh = dict(c["shape_override"])
        sk = Skeleton(height=c["height"],
                      shoulder_scale=float(sh.get("shoulder_scale", 1.0)),
                      accessories=tuple(c["accessories"]))
        old = detail.Head.HAIR_FADE
        if fade is not None:
            detail.Head.HAIR_FADE = fade
        try:
            mbx, _mm = basemesh.build(sk, sh, quality="full")
        finally:
            detail.Head.HAIR_FADE = old
        pal = PL.expand_palette(dict(PL.DEFAULT_PALETTE))
        colx = PL.bake_colors(mbx, sk, pal)
        pp = {b.name: np.asarray(b.rest, float) for b in sk.bones}
        Hx = detail.Head(pp, c["height"] / 1.70, sh)
        Vx = np.asarray(mbx.v, float)
        tg = np.array([t or "" for t in mbx.tag], dtype=object)
        tr = np.asarray(mbx.f, int)
        ed = np.concatenate([tr[:, [0, 1]], tr[:, [1, 2]], tr[:, [2, 0]]])
        ia, ib = ed[:, 0], ed[:, 1]
        fz = ((Vx[:, 2] - Hx.hc[2]) / Hx.R > 0.55) & \
             (np.abs(Vx[:, 0] - Hx.hc[0]) / Hx.R < 0.55)
        sel = ((((tg[ia] == "hair") & (tg[ib] == "skin")) |
                ((tg[ia] == "skin") & (tg[ib] == "hair")))
               & fz[ia] & fz[ib])
        lin = PL._to_linear(np.array([pal["hair"], pal["skin"]], np.float32))
        gap = float(np.linalg.norm(lin[0] - lin[1]))
        if not int(sel.sum()):
            return 0.0, 0
        dd = np.linalg.norm(colx[ia[sel]] - colx[ib[sel]], axis=1) / gap
        return float(np.median(dd)), int(sel.sum())

    for who in ("grump", "zippy"):
        step, nedge = _front_step(who)
        check(f"מעבר הצבע בקו השיער של {who} אינו מדרגה",
              nedge >= 60 and step < 0.55, (round(step, 3), nedge))
    # והבדיקה מסוגלת להיכשל: בלי ריכוך המדרגה חוזרת להיות מלאה
    step0, _n = _front_step("grump", fade=1e-9)
    check("ובלי הריכוך היא אכן חוזרת למדרגה מלאה (הבדיקה חיה)",
          step0 > 0.90, round(step0, 3))

    # ברירת המחדל: שני המכפילים החדשים ניטרליים **בדיוק**, ולכן
    # לוקאס ומאיה נבנים אחרי השינוי כמו לפניו.
    check("ברירת המחדל: שיער לא קשיח ולא מסולסל",
          FS.PLAIN.hair_wob == 1.0 and FS.PLAIN.hair_coil == 0.0,
          (FS.PLAIN.hair_wob, FS.PLAIN.hair_coil))
    check("ומכפיל ההתפתלות הוא 1.0 בדיוק (ולא 0.9999999999999999)",
          (1.0 - 0.70 * (1.0 - FS.PLAIN.hair_wob)) == 1.0)
    Hd = detail.Head(P, 1.0, {})
    for th in (0.0, 0.4, -0.9, 1.7, 3.0):
        u = np.array([math.sin(th), 0.35, math.cos(th)])
        want = detail._pw([(0.00, -0.34), (0.30, -0.18), (0.50, 0.02),
                           (0.72, 0.36), (0.88, 0.58), (1.00, 0.63)])
        uu = u / np.linalg.norm(u)
        fr = (float(uu[2]) + 1.0) * 0.5
        thh = math.atan2(float(uu[0]), float(uu[2]))
        ref = (want(fr)
               + detail._ss(0.55, 1.0, fr)
               * detail._ss(0.30, 0.62, abs(float(uu[0]))) * 0.14
               - detail._ss(0.78, 1.0, fr)
               * detail._ss(0.17, 0.0, abs(float(uu[0]))) * 0.072
               + detail._ss(0.45, 0.85, fr)
               * (0.017 * math.sin(thh * 5.0)
                  + 0.010 * math.sin(thh * 11.0 + 1.3)))
        check(f"קו השיער של ברירת המחדל זהה בכל ספרה (th={th})",
              Hd.hairline(u) == ref, (Hd.hairline(u), ref))


def t_ensemble():
    """
    TASK 13 (06/10) - להקה ועקרונות דיסני: סנאי, עלים, פנס, קשת
    מצלמה, מעיכה מוגזמת, משקל וסיבתיות.

    שלושה מהמקרים כאן תפסו תקלה אמיתית **באותה ריצה שבה נכתבו**,
    והם מסומנים. השאר הם שערים שמונעים רגרסיה בדמויות הקיימות.
    """
    from production.script import sunbeam50 as SB
    from rig import ensemble as EN
    from rig import park as PK
    from rig import principles as PR
    from rig import sunbeam as SBM

    print("TASK 13 - להקה ועקרונות דיסני:")

    # --- 1. החוזה המלא של המודול. הוא מודד 56 דברים בעצמו, ואין
    #     טעם לשכפל אותם כאן - מה שנבדק כאן הוא שכולם עוברים.
    tk = EN.Take()
    rep = EN.audit(tk)
    bad = [k for k, v in rep.items() if not v["pass"]]
    check(f"חוזה הלהקה עובר במלואו ({len(rep)} בדיקות)", not bad,
          bad[:4] or "הכול")

    # --- 2. **דרגת הסגנון לא הרפתה את הדמויות הריאליסטיות.**
    #     זו הבדיקה המרכזית של המשימה: ההגזמה נפתחה לקריקטורה
    #     בלבד, ואסור שהיא תזלוג ללוקאס ולמאיה.
    for who in ("lucas", "maya"):
        check(f"{who} נשאר בדרגת אדם", PR.tier_of(who) == "human",
              PR.tier_of(who))
        try:
            PR.squash_styled(0.25, "jaw", tier=PR.tier_of(who))
            check(f"ותקרת 12% על {who} עדיין חוסמת", False, "לא נזרקה שגיאה")
        except PR.StyleError:
            check(f"ותקרת 12% על {who} עדיין חוסמת", True)
    sy, sx = PR.squash(0.12, "jaw")
    check("הפונקציה המקורית מחזירה בדיוק מה שהחזירה קודם",
          abs(sy - 1.12) < 1e-12 and abs(sy * sx * sx - 1.0) < 1e-12,
          (sy, sx))
    check("ודרגת הקריקטורה פותחת 45%", PR.STYLE_TIERS["cartoon"]["max"] > 0.4,
          PR.STYLE_TIERS["cartoon"]["max"])
    sy2, sx2 = PR.squash_styled(0.42, "jump", tier="cartoon")
    check("ושומרת נפח גם ב-42%", abs(sy2 * sx2 * sx2 - 1.0) < 1e-12,
          round(sy2 * sx2 * sx2, 12))

    # --- 3. שפת הצורות של דמות המשנה **נמדדת מהגאומטריה**.
    sph = [EN.sphericity(p) for p in EN.CRITTER_PARTS]
    check("כל איבר של הסנאי עגול (מעל 0.60)", min(sph) >= 0.60,
          round(min(sph), 3))
    # התקלה שנתפסה 06/10: אוזן (1.35, 0.70) נתנה 0.519 - איבר
    # מחודד בתוך דמות שהוכרזה עגולה. הבדיקה הזו היא מה שתפס את זה.
    check("והבדיקה חיה: אוזן מחודדת הייתה נכשלת",
          EN.sphericity({"sy": 1.35, "sz": 0.70}) < 0.60,
          round(EN.sphericity({"sy": 1.35, "sz": 0.70}), 3))

    # --- 4. סיבתיות: הסיבה לפני התוצאה, בפריימים.
    ii = tk._idx(EN.IMPACT_T)
    li = int(np.argmax(tk.leaf_energy))
    ri = int(np.argmax(np.r_[0.0, np.diff(tk.g_annoy)]))
    check("העלים נחים לפני הנחיתה",
          float(np.abs(tk.leaf_spd[:ii]).max()) == 0.0)
    check("הפיזור קודם לתגובה של גרומפ", li < ri, (li, ri))
    check("וההשהיה בטווח אנושי", 0.2 <= (ri - li) / tk.fps <= 1.2,
          round((ri - li) / tk.fps, 3))

    # --- 5. פיזיקת העלים: שום עלה לא נעלם ושום עלה לא קופא באוויר.
    check("אף עלה אינו שוקע מתחת לקרקע",
          float(tk.leaf_pos[:, :, 1].min()) >= 0.0,
          round(float(tk.leaf_pos[:, :, 1].min()), 5))
    check("כל העלים נוחתים בתוך השוט",
          float(tk.leaves.t_land.max()) < tk.secs - EN.IMPACT_T,
          round(float(tk.leaves.t_land.max()), 3))
    check("ובסוף השוט כולם במנוחה",
          float(np.abs(tk.leaf_spd[-1]).max()) < 1e-6)
    # **הפתרון הסגור חייב להסכים עם אינטגרציה צעד-צעד**, אחרת
    # המדידה מודדת עקומה אחת והרנדור מצייר אחרת.
    i0 = 3
    p, v = tk.leaves.p0[i0].copy(), tk.leaves.v0[i0].copy()
    dt = 1 / 600.0
    for _ in range(int(0.25 / dt)):
        v += (-EN.DRAG * v - np.array([0.0, EN.G, 0.0])) * dt
        p += v * dt
    ref = EN._leaf_path(tk.leaves.p0[i0], tk.leaves.v0[i0],
                        np.array([0.25]))[0]
    check("הפתרון הסגור של העלה מסכים עם אינטגרציה נומרית",
          float(np.abs(ref - p).max()) < 0.004,
          round(float(np.abs(ref - p).max()), 5))

    # --- 6. זעזוע שדועך. התקלה הקלאסית: מתנד שממשיך לנצח.
    pk = float(np.abs(tk.shake).max())
    late = float(np.abs(tk.shake[tk._idx(EN.IMPACT_T + 0.8):
                                 tk._idx(EN.IMPACT_T + 1.1)]).max())
    check("הזעזוע דועך מתחת ל-4% תוך 0.8 שניות", late < pk * 0.04,
          (round(pk, 5), round(late, 6)))
    check("וגרומפ אינו עולה מעל הקרקע אף פעם",
          float(tk.g_lift.max()) <= 0.0, round(float(tk.g_lift.max()), 5))

    # --- 7. שתי השכבות של הערימה מתלכדות (צרוב מול תלת-ממד).
    sxp, syp = EN.project(np.array(EN.LEAF_ANCHOR), tk.cams[0])
    bx = PK.PROPS["leaves"]["at"][0] * PK.PAD - (PK.PAD - 1.0) / 2.0
    check("הערימה הצרובה יושבת בדיוק על העלים התלת-ממדיים",
          abs(bx - sxp) < 0.06
          and abs(PK.PROPS["leaves"]["at"][1] - syp) < 0.06,
          (round(bx, 3), round(sxp, 3)))

    # --- 8. הבמה: פונקציות ההזרקה קיימות, והמפרט מתאים להן.
    stage = (HERE / "stage.html").read_text(encoding="utf-8")
    for fn in ("window.__ensemble", "window.__lamp", "ensFrame",
               "InstancedMesh", "lampGlow"):
        check(f"הבמה מכילה {fn}", fn in stage)
    spec = EN.stage_spec()
    check("מפרט הבמה נושא צבע לכל עלה",
          len(spec["leaves"]["colors"]) == EN.LEAF_N,
          len(spec["leaves"]["colors"]))
    check("וכל הצבעים בפורמט שהדפדפן מבין",
          all(c.startswith("#") and len(c) == 7
              for c in spec["leaves"]["colors"]))
    check("המפרט ניתן להמרה ל-JSON", bool(json.dumps(spec)))

    # --- 9. התסריט והבימוי: 60 שניות, חמישה שוטים, שוט להקה אחד.
    check("התסריט הוא 60 שניות בדיוק", SB.TOTAL_SECONDS == 60.0,
          SB.TOTAL_SECONDS)
    check("ויש בו חמישה שוטים", len(SB.SHOTS) == 5, len(SB.SHOTS))
    check("חוזה התסריט עובר", SB.passed(),
          [k for k, v in SB.validate().items() if not v["pass"]])
    sh = SBM.build_shots(1.42, 1.74)
    tl = SBM.validate_timeline(sh)
    check("חוזה ציר הזמן עובר",
          all(v["pass"] for v in tl.values()),
          [k for k, v in tl.items() if not v["pass"]])
    ens = [s for s in sh if getattr(s, "ens_of", None) is not None]
    check("שוט אחד בלבד נושא את הלהקה", len(ens) == 1,
          [s.key for s in ens])
    # **התקלה שהעטיפה הזו הייתה גורמת בשקט**: עטיפת השחקן למיקרו-
    # הבעות מאבדת את `track`, ואז הסרטון יוצא אילם בלי שום שגיאה.
    check("עטיפת המיקרו-הבעות שומרת את ההקלטה",
          all(getattr(f, "track", None) is not None
              for f in (ens[0].a, ens[0].b)))
    check("ושומרת את חלון הדיבור",
          all(getattr(f, "speech", None) is not None
              for f in (ens[0].a, ens[0].b)))
    # והמיקרו-הבעות באמת מגיעות לבקרות, ובלי לדרוס את מנוע הרגש.
    ctl_before = ens[0].b(0.05, 0.5)[0]
    ctl_after = ens[0].b(0.55, 5.5)[0]
    check("הגבות של גרומפ מרטטות אחרי הפגיעה ולא לפניה",
          abs(float(ctl_after.get("brow_furrow_L", 0.0)))
          + abs(float(ctl_after.get("breath", 0.0))) > 0.05,
          (round(float(ctl_before.get("brow_furrow_L", 0.0)), 3),
           round(float(ctl_after.get("brow_furrow_L", 0.0)), 3)))
    check("וכל הבקרות נשארות בטווח חוקי",
          all(-1.0001 <= float(v) <= 1.0001
              for v in ctl_after.values() if isinstance(v, (int, float))))

    # --- 9ב. **התקלה של 06/10 ששרפה רינדור של 17 דקות.**
    #     ערוץ מיקרו-הבעה בשם `nose_flare` - שהוא יחידת פעולה בפנים
    #     ולא בקרה של הריג - עבר את כל הבדיקות ואת רינדור הבדיקה,
    #     כי ערכו אפס ברוב השוט. `controls.normalize` זרק KeyError
    #     רק בפריים 1586 מתוך 1800, אחרי שכל שאר הסרט כבר רונדר.
    #     המסקנה: ערוץ שנשלח לריג נבדק בכל **הפריימים**, לא בפריים
    #     אחד, ומול מרשם הבקרות ולא מול הזיכרון.
    unknown = set()
    for i in range(0, tk.n, 3):
        for k in EN.grump_micro(float(tk.t[i])):
            if k not in controls.CONTROLS:
                unknown.add(k)
    check("כל ערוצי המיקרו-הבעות קיימים במרשם הבקרות", not unknown,
          sorted(unknown))
    try:
        for i in range(0, tk.n, 3):
            controls.normalize(EN.grump_micro(float(tk.t[i])))
        check("והריג מקבל אותם בכל פריים בשוט", True)
    except Exception as exc:                            # noqa: BLE001
        check("והריג מקבל אותם בכל פריים בשוט", False, str(exc))
    # והבדיקה חיה: שם שאינו בקרה אכן מפיל את normalize.
    try:
        controls.normalize({"nose_flare": 0.3})
        check("הבדיקה חיה: שם שאינו בקרה נדחה", False, "לא נזרקה שגיאה")
    except KeyError:
        check("הבדיקה חיה: שם שאינו בקרה נדחה", True)
    # וגם המסלול המלא: הבקרות שהשחקן העטוף מחזיר, בכל פריים.
    try:
        for i in range(0, 300, 5):
            controls.normalize(ens[0].b(i / 300.0, i / 30.0)[0])
        check("ובקרות השחקן העטוף תקפות בכל השוט", True)
    except Exception as exc:                            # noqa: BLE001
        check("ובקרות השחקן העטוף תקפות בכל השוט", False, str(exc))

    # --- 10. אין נזק לשוטים הקיימים: ארבעת הראשונים בלי להקה,
    #     ועם אותה מצלמה ואותה תנועת מקום כמו קודם.
    for s in sh[:4]:
        check(f"{s.key} לא קיבל להקה", getattr(s, "ens_of", None) is None)
    old = _lift_ref = SBM._lift_of("s1_park_wide")
    check("תנועת המקום של השוט הראשון לא זזה",
          abs(old("zippy", 0.37) - sh[0].lift_of("zippy", 0.37)) < 1e-12,
          (old("zippy", 0.37), sh[0].lift_of("zippy", 0.37)))
    cam_old = SBM._cam("wide", 0.5, 1.42, 1.74)
    check("ומצלמת השוט הראשון לא זזה",
          sh[0].cam(0.5) == cam_old, (sh[0].cam(0.5), cam_old))


def t_locomotion():
    """TASK 14 · הליכה, ריצה והמעבר. 06/10."""
    print("\n[locomotion] TASK 14 - תנועה במקום")
    from rig import locomotion as LM                    # noqa: PLC0415

    # --- 1. 25 שערי המודול, על גובה ברירת המחדל.
    rep = LM.default_audit()
    for k, v in rep.items():
        check(k, v["pass"], v["detail"])

    # --- 2. ועל **שתי הדמויות החדשות**: אורך הצעד נגזר מהרגל,
    #     ולכן מערך שעובר על 1.70 מ' אינו ראיה ל-1.12 מ'.
    for nm in ("shafud", "kufta"):
        c = pipeline.CAST[nm]
        sh = c["shape_override"]
        sk = Skeleton(height=c["height"],
                      shoulder_scale=float(sh.get("shoulder_scale", 1.0)),
                      head_scale=1.0, asym=sh.get("asym"))
        r = LM.audit(LM.Move(sk, [("walk", 3.0)]),
                     LM.Move(sk, [("run", 3.0)]),
                     LM.Move(sk, [("stand", 1.0), ("walk", 2.2),
                                  ("run", 3.0)]), step=3)
        bad = [k for k, v in r.items() if not v["pass"]]
        check(f"כל שערי התנועה עוברים על {nm}", not bad, bad)

    # --- 3. הצעד **באמת** נגזר ולא מקודד: שינוי השקיעה משנה אותו.
    sk = Skeleton(height=1.70)
    deep = LM.replace(LM.RUN, crouch=LM.RUN.crouch * 1.3)
    a = LM.Move(sk, [("run", 1.5)])
    b = LM.Move(sk, [("run", 1.5)], gaits=dict(LM.GAITS, run=deep))
    check("שקיעה עמוקה יותר = מחזור ארוך יותר (הצעד נגזר)",
          b.cyc[-1] > a.cyc[-1] * 1.08,
          (round(a.cyc[-1], 3), round(b.cyc[-1], 3)))

    # --- 4. **אין ברירת מחדל שקטה.** הילוך שאינו קיים נדחה.
    try:
        LM.Move(sk, [("sprint", 2.0)])
        check("הילוך שאינו קיים נדחה", False, "לא נזרקה שגיאה")
    except KeyError:
        check("הילוך שאינו קיים נדחה", True)

    # --- 5. העטיפה מעבירה תכונות, ו-tuple באורך 3 שורד.
    mv = LM.Move(sk, [("walk", 1.2)])

    def fake(u, t):
        return ({"smile_L": 0.4}, {}, {"jaw": 0.2})
    fake.track = "דמה"
    w = mv.drive(fake)
    res = w(0.5, 0.6)
    check("העטיפה שומרת על איבר שלישי ב-tuple", len(res) == 3, len(res))
    check("ומשחק הפנים שורד את התנועה",
          abs(res[0].get("smile_L", 0.0) - 0.4) < 1e-12,
          res[0].get("smile_L"))
    check("ותנועת הרגל גוברת על בקרת גוף שהגיעה מהשחקן",
          "foot_L" in res[1] and "foot_R" in res[1], sorted(res[1]))


def t_cast14():
    """TASK 14 · ההרכב החדש והא-סימטריה. 06/10."""
    print("\n[cast14] TASK 14 - שפוד וכופתה")
    from rig import cast14 as C14                       # noqa: PLC0415

    rep = C14.audit("fast")
    for k, v in rep.items():
        if not k.startswith("_"):
            check(k, v["pass"], v["detail"])

    # **השער שמגן על כל השאר:** שלד בלי `asym` חייב להיות זהה
    # לשלד שהיה לפני TASK 14 **בכל ספרה**, אחרת 28 שערי הסגנון
    # ו-1024 הבדיקות נשענים על גאומטריה אחרת.
    a = Skeleton(height=1.74, shoulder_scale=1.12)
    b = Skeleton(height=1.74, shoulder_scale=1.12, asym=None)
    c = Skeleton(height=1.74, shoulder_scale=1.12, asym={})
    same = all(a.by_name[n].rest == b.by_name[n].rest == c.by_name[n].rest
               for n in a.by_name)
    check("asym=None ו-asym={} אינם משנים אף עצם", same)

    # ואי-סימטריה שהוזמנה **כן** מזיזה, ורק את הצד שביקשו.
    d = Skeleton(height=1.74, asym={"shoulder_y": 0.03})
    dy_l = d.by_name["clavicle_L"].rest[1] - a.by_name["clavicle_L"].rest[1]
    dy_r = d.by_name["clavicle_R"].rest[1] - a.by_name["clavicle_R"].rest[1]
    check("גובה כתף א-סימטרי מרים צד אחד ומוריד את השני",
          dy_l > 0.02 and dy_r < -0.02, (round(dy_l, 4), round(dy_r, 4)))
    hips = d.by_name["hips"].rest == a.by_name["hips"].rest
    check("ואינו נוגע באגן", hips)

    # הדמויות החדשות רשומות ובונות שלד תקין.
    for nm in C14.NEW:
        check(f"{nm} רשום ב-CAST", nm in pipeline.CAST)


def t_chase():
    """TASK 14 · חוזה סצנת המרדף. 06/10."""
    print("\n[chase] TASK 14 - המרדף")
    from rig import chase as CH                         # noqa: PLC0415

    shots = CH.build_shots(1.98, 1.12)
    for k, v in CH.validate(shots).items():
        check(k, v["pass"], v["detail"])

    # הסחיפה **נגזרת** מהנסיעה ואינה עקומה שנכתבה: אם מכפילים את
    # הקצב, הסחיפה מוכפלת באותה מידה בדיוק.
    sk = Skeleton(height=1.70)
    from rig import locomotion as LM                    # noqa: PLC0415
    mv = LM.Move(sk, [("run", 2.0)], treadmill=True)
    p1 = mv.pan_of(1.9, 0.03)
    p2 = mv.pan_of(1.9, 0.06)
    check("סחיפת הרקע נגזרת מהנסיעה (פי 2 בקנה = פי 2 בסחיפה)",
          abs(p2 - 2 * p1) < 1e-6, (p1, p2))

    # **שוט ישן לא קיבל תנועת מקום.** זה מה שמוודא שכל 13 המשימות
    # הקודמות מרונדרות בדיוק כמו קודם: `move_of` דורס את נעילת
    # הרצפה, ושוט שקיבל אותו בטעות היה מרחף.
    from rig import sunbeam as SBM                      # noqa: PLC0415
    old = SBM.build_shots(1.42, 1.74)
    bad = [s.key for s in old if getattr(s, "move_of", None) is not None]
    check("אף שוט של הסצנה הקודמת לא קיבל תנועת מקום", not bad, bad)


def t_gender():
    """TASK 15 · שני ארכיטיפים מגדריים ומרווח הזרוע. 06/10."""
    print("\n[gender] TASK 15 - גבר ואישה מובחנים")
    from rig import gender as GD                        # noqa: PLC0415
    from rig import dimorph as DM                       # noqa: PLC0415
    from rig import facestyle as FS                     # noqa: PLC0415
    from rig import controls as CT                      # noqa: PLC0415

    # --- 1. שני הדגמים רשומים ונגישים בשם, בשני המודולים.
    for key in ("male", "female"):
        check(f"פרופיל גוף {key} רשום", DM.get(key).key == key)
        check(f"סגנון פנים {key} רשום", FS.get(key).key == key)
    for nm in GD.PAIR:
        check(f"{nm} רשום ב-CAST", nm in pipeline.CAST)

    # --- 2. השער המלא: גבהים, איסור ניטרליות, כיוון, מוחלטים, מרווח.
    rep = GD.audit(quality="fast")
    check("הגבהים הם 1.85 ו-1.65", rep["heights"]["ok"],
          rep["heights"]["bad"])
    check("אין ערכים ניטרליים באף ציר", rep["neutral_free"]["ok"],
          rep["neutral_free"]["bad"][:4])
    d = rep["directed"]
    for r in d["rows"]:
        check(f"מכוון · {r['desc']}", r["ok"],
              (r["male"], r["female"], r["gap"], r["need"]))
    for r in rep["absolutes"]["rows"]:
        check(f"מוחלט · {r['desc']}", r["ok"],
              (r["value"], r["dir"], r["ref"]))
    check("הזרוע אינה נבלעת בגוף באף פוזה, הליכה או ריצה",
          rep["clearance"]["ok"], rep["clearance"]["bad"])

    # --- 3. **הכיוון ההפוך של איסור הניטרליות.** שער שעובר על
    #     הדגמים שכתבנו אינו ראיה שהוא *יכול* להיכשל: דגם שבו שני
    #     הארכיטיפים באותו צד של הניטרלי חייב להיפול. בלי הבדיקה
    #     הזו אפשר להחליף את כל ההשוואה ב-`return True` ואף בדיקה
    #     לא תשים לב.
    real = DM.FEMALE
    try:
        DM.FEMALE = DM.replace(real, hip_w=DM.NEUTRAL.hip_w * 0.5)
        bad = GD.neutral_free()
        check("ושני ערכים באותו צד של הניטרלי **נכשלים**",
              not bad["ok"] and any("hip_w" in b for b in bad["bad"]),
              bad["bad"][:2])
    finally:
        DM.FEMALE = real
    check("והדגם הוחזר למקומו", DM.FEMALE is real)

    # --- 4. **מרווח הזרוע הוא תקרה חד-צדדית.** היא חוסמת הצמדה
    #     ואינה נוגעת בהרמת יד, ושני הכיוונים נבדקים: בלי הכיוון
    #     השני, תקרה שחוסמת גם `arm_down` שלילי הייתה מונעת מהדמות
    #     להרים את היד - בדיוק אצל הדמות שהמרווח נועד לעזור לה.
    free = Skeleton(height=1.65)
    guard = Skeleton(height=1.65, arm_clear=0.26)
    check("שלד בלי מרווח אינו מושפע", free.arm_clear == 0.0)
    qa = CT.evaluate(free, {"arm_down_L": 1.0})
    qb = CT.evaluate(guard, {"arm_down_L": 1.0})
    check("הצמדה מלאה נחסמת כשיש מרווח",
          not np.allclose(qa["upperarm_L"], qb["upperarm_L"]))
    ra = CT.evaluate(free, {"arm_down_L": -0.8})
    rb = CT.evaluate(guard, {"arm_down_L": -0.8})
    check("והרמת היד **אינה** נחסמת",
          np.allclose(ra["upperarm_L"], rb["upperarm_L"]))
    # והערך המדויק: התקרה היא 1 - arm_clear, לא קבוע.
    cap = CT.evaluate(guard, {"arm_down_L": 0.74})
    check("תקרת ההצמדה היא בדיוק 1 פחות המרווח",
          np.allclose(cap["upperarm_L"], qb["upperarm_L"]))
    check("וערך מתחת לתקרה עובר כמו שהוא",
          not np.allclose(CT.evaluate(guard, {"arm_down_L": 0.5})
                          ["upperarm_L"], qb["upperarm_L"]))

    # --- 5. **שש הדמויות שהיו אינן משתנות באף ספרה.** `arm_clear`
    #     של כל ששת הפרופילים הקיימים הוא 0.0, ולכן התקרה מדלגת
    #     על הקוד כולו אצלן. זה הכיוון שמגן על 1087 הבדיקות שלפני.
    for key in ("masc", "fem", "neutral", "round", "block",
                "spire", "fluid"):
        check(f"פרופיל {key} ללא מרווח זרוע",
              DM.get(key).arm_clear == 0.0)
    for nm in ("lucas", "maya", "zippy", "grump", "shafud", "kufta"):
        sk = pipeline.cast_skeleton(nm)
        check(f"{nm} נבנה בלי מרווח זרוע", sk.arm_clear == 0.0)
        c = pipeline.CAST[nm]
        sh = c["shape_override"]
        ref = Skeleton(height=c["height"],
                       shoulder_scale=float(sh.get("shoulder_scale", 1.0)),
                       head_scale=1.0,
                       accessories=tuple(c["accessories"]),
                       asym=sh.get("asym"))
        same = all(np.allclose(a.rest, b.rest)
                   for a, b in zip(sk.bones, ref.bones))
        check(f"ושלד {nm} זהה לשלד שנבנה ישירות", same)

    # --- 6. **המודד עצמו נבדק בשני הכיוונים.** `_radial_gap` חייב
    #     להחזיר שלילי על קודקוד שבתוך החתך וחיובי על אחד שמחוצה
    #     לו. מודד שמחזיר תמיד חיובי עובר כל השערים למעלה ואינו
    #     מודד כלום - וזו בדיוק הגרסה הראשונה שלו שנפסלה כאן.
    ang = np.linspace(0, 2 * np.pi, 48, endpoint=False)
    ring = np.stack([0.10 * np.cos(ang),
                     np.full_like(ang, 1.00),
                     0.10 * np.sin(ang)], axis=1)
    inside = np.array([0.04, 1.00, 0.0])
    outside = np.array([0.17, 1.00, 0.0])
    check("קודקוד בתוך החתך מקבל מרווח שלילי",
          GD._radial_gap(inside, ring) < 0,
          GD._radial_gap(inside, ring))
    check("וקודקוד מחוצה לו מקבל חיובי",
          GD._radial_gap(outside, ring) > 0,
          GD._radial_gap(outside, ring))
    # וזרוע שנמצאת **לפני** החזה ולא בתוכו היא מרווח חיובי: זו
    # תנועת הריצה הנכונה, והמודד הראשון פסל אותה בטעות.
    front = np.array([0.0, 1.00, 0.17])
    check("זרוע לפני הגו אינה נחשבת חדירה",
          GD._radial_gap(front, ring) > 0, GD._radial_gap(front, ring))

    # --- 7. **מבדק הערך החזותי על הזוג הבנוי.** זה השער היחיד שאינו
    #     יכול לרוץ על רשת שנבנתה בזיכרון: הוא מודד צלליות, היררכיה
    #     והרמוניית צבע מתוך ה-GLB וה-npz שנכתבו. הוא תפס כאן שני
    #     פגמים אמיתיים שכל השערים האחרים פספסו - ראש גדול מדי לתמר
    #     (5.67 ראשים, מתחת לחלון) ובועז בלי שפת צורות דומיננטית.
    rig_dir = paths.rigged()
    if not (rig_dir / f"{GD.MALE_CHAR}.rig.json").exists():
        skip("מבדק הערך החזותי על הזוג המגדרי",
             f"הזוג המגדרי לא נבנה תחת {rig_dir}")
    else:
        from rig import appeal as AP                    # noqa: PLC0415
        gchars = [AP.Char(n, rig_dir) for n in GD.PAIR]
        for ch in gchars:
            check(f"מרווח הזרוע שרד את קובץ הדמות של {ch.name}",
                  ch.skel.arm_clear > 0.0, ch.skel.arm_clear)
        grep = AP.evaluate(gchars)

        def _flat(d, p=""):
            for k, v in d.items():
                if isinstance(v, dict) and "pass" in v:
                    yield p + k, v
                elif isinstance(v, dict):
                    yield from _flat(v, p + k + ".")
        for key, v in _flat(grep):
            check(f"ערך חזותי · {key}", v["pass"], str(v.get("detail"))[:160])

    # --- 8. ההפרדה בין שני הזוגות הקודמים: הניגוד כאן מגדרי, ולכן
    #     הגבהים **קרובים** בכוונה. שער שהיה נשען על הגובה היה
    #     עובר כאן בקושי, ולכן חשוב לנעול שהוא לא נשען עליו.
    hm = GD.WANT_HEIGHT[GD.MALE_CHAR] / GD.WANT_HEIGHT[GD.FEMALE_CHAR]
    check("יחס הגבהים קטן מכל זוג קודם בפרויקט", hm < 1.23, round(hm, 4))
    check("וכל המדדים המכוונים חסרי יחידה",
          all(k not in ("height", "shoulder_w", "hip_w", "R")
              for k, _s, _h, _n, _d in GD.DIMORPHIC))


def t_disney_appeal():
    """TASK 16 (06/10) · שפת דיסני/פיקסאר.

    **הבדיקה הראשונה כאן נולדה מכשל אמיתי שעבר 1168/1168.**
    אחרי מעבר הדמויות לשפה האורגנית, רנדור התקריב הראה שלתמר
    **אין עיניים**: `eye=1.78` עם ההיסט הקיים ב-`eye_center`
    (שמפצה על עין *קטנה* ולכן מושך עין ענקית אחורה) הניח את
    הקרנית **3.1 מ"מ מתחת לעור**. אף שער מספרי לא תפס את זה -
    הבדיקה "הקרנית פורצת את פני העור" הייתה כתובה על **זיגי
    בלבד**, ומבדקי הערך החזותי מודדים קשב וניגוד, שאינם צונחים
    כשהעין נבלעת (הארובה, העפעף והריס עדיין שם).

    הלקח: בדיקה שנכתבה בגלל דמות אחת צריכה לרוץ על **כל** ההרכב
    ברגע שהפרמטר שהיא מגינה עליו הפך לציר עיצוב פתוח.
    """
    print("\n[TASK 16] שפת דיסני/פיקסאר")
    from rig import dimorph as DM_                       # noqa: PLC0415
    from rig import facestyle as FS                      # noqa: PLC0415
    from rig import gender as GD                         # noqa: PLC0415

    # --- 1. הקרנית פורצת את פני העור **בכל** דמות בהרכב.
    for name, c in pipeline.CAST.items():
        sh = dict(c["shape_override"])
        skel = pipeline.cast_skeleton(name)
        P = {b.name: np.asarray(b.rest, float) for b in skel.bones}
        H = detail.Head(P, c["height"] / 1.70, sh)
        mb, _m = basemesh.build(skel, sh, quality="fast")
        probe = detail.skin_probe(mb, H)
        d = H.eye_center("L") - H.hc + np.array([0.0, 0.0, H.eye_r])
        out = float(np.linalg.norm(d)) - float(probe(d))
        check(f"הקרנית של {name} פורצת את פני העור", out > 0.0005,
              round(out, 5))
        # ושתי העיניים אינן מתלכדות לכתם אחד. 1.5 מ"מ הוא הסף
        # שנקבע כאן לזיגי ב-TASK 11, והוא נשאר אותו סף.
        gap = abs(float(H.eye_center("L")[0] - H.eye_center("R")[0])) \
            - 2 * H.eye_r
        check(f"ושתי העיניים של {name} אינן נוגעות", gap > 0.0015,
              round(gap, 5))

    # --- 2. הרצפה המשותפת: אין זוויתיות, ויש עיניים/שיער/צוואר.
    sh_rep = GD.shared_language()
    check("שפת העיצוב המשותפת עוברת בשתי הדמויות", sh_rep["ok"],
          "; ".join(sh_rep["bad"])[:200])
    check("ויש בה את כל 25 הכללים", sh_rep["n"] >= 25, sh_rep["n"])

    # --- 3. **אף ציר ברשימת הניגוד אינו מודד זוויתיות.** זו
    #     הרגרסיה שנועלת את ההכרעה: אם מישהו יחזיר את
    #     `skull_square`/`shoulder_squareness`/`cloth_square`
    #     לניגוד המגדרי, הוא יחייב מחדש את הגבר להיות מרובע -
    #     כלומר יבטל את כל הסבב הזה בלי שום שגיאה.
    ANG = {"skull_square", "skull_box", "crown_flat", "limb_square",
           "shoulder_square", "shoulder_squareness", "cloth_square"}
    check("אין מדד זוויתיות ברשימת הניגוד המכוון",
          not (ANG & {k for k, _s, _h, _n, _d in GD.DIMORPHIC}))
    check("ואין כזה בצירים המנוגדים",
          not (ANG & {f for f, _m, _s in GD.OPPOSED}))
    check("ולא בחד-כיווניים",
          not (ANG & {f for f, _m, _w in GD.ONE_SIDED}))
    check("וכולם מופיעים ברצפה המשותפת",
          ANG - {"shoulder_squareness", "cloth_square"}
          <= {f for f, _m, _o, _r, _d in GD.SHARED})

    # --- 4. שש הדמויות הקודמות לא השתנו: כל אחת מהן חייבת להישאר
    #     על ברירות המחדל של השדות החדשים, אחרת הסבב הזה דלף אליהן.
    NEW_F = ("eye_in", "eye_out", "lid_cover", "nose_len", "nose_w",
             "nose_tip", "nose_up", "cheek", "cheek_hollow",
             "hair_clump", "hair_thick", "hair_pull")
    base = FS.PLAIN
    #: **החריג היחיד, והוא מכוון ומתועד:** `drop` (כופתה) קיבלה
    #: `eye_out=0.008` כ**תיקון באג** - הקרנית שלה ישבה 3.96 מ"מ
    #: מתחת לעור מאז TASK 14, כלומר לדמות לא היו עיניים. ראה
    #: `facestyle.DROP`. כל שדה אחר, בכל שפה אחרת, חייב להישאר
    #: בברירת המחדל - אחרת הסבב הזה דלף אל הדמויות הישנות.
    EXEMPT = {("drop", "eye_out")}
    for key in ("plain", "joy", "grim", "edge", "drop"):
        fs = FS.PRESETS[key]
        same = all(getattr(fs, f) == getattr(base, f) for f in NEW_F
                   if (key, f) not in EXEMPT)
        check(f"שפת הפנים {key} לא נגעה בשדות החדשים", same)
    for key in ("masc", "fem", "neutral", "round", "block", "spire",
                "fluid"):
        dm = DM_.PRESETS[key]
        check(f"פרופיל הגוף {key} בלי עקומת S",
              dm.trap_rise == 0.0 and dm.neck_flare == 0.0)

    # --- 5. עקומת ה-S: הפרופיל **אינו** מונוטוני יורד בשתי הדמויות
    #     החדשות, והוא כן מונוטוני בכל השאר. זו ההגדרה התפעולית של
    #     "לא צוואר גלילי", והיא נמדדת על הפרופיל ולא על הפרמטר.
    def _mono(dm):
        ws = [w for t, w, _d, _e, _o in DM_.torso_profile(dm) if t >= 0.86]
        return all(ws[i] >= ws[i + 1] for i in range(len(ws) - 1))
    for key in ("male", "female"):
        check(f"צוואר {key} אינו חרוט מונוטוני", not _mono(DM_.PRESETS[key]))
    for key in ("masc", "fem", "neutral", "round", "block", "spire",
                "fluid"):
        check(f"וצוואר {key} לא השתנה", _mono(DM_.PRESETS[key]))

    # --- 6. בניית דמות מ-`CAST` לפי שם **חייבת** להעביר את
    #     `shape_override`. הבאג שנתפס כאן: `python -m rig.pipeline
    #     boaz` בנה דמות ברירת מחדל בשם boaz - שני הקבצים יצאו
    #     13626 KB בדיוק, ומבדק ההפרדה החזיר 0.000.
    import inspect                                       # noqa: PLC0415
    src = inspect.getsource(pipeline.main)
    check("בניית דמות מההרכב לפי שם עוברת דרך build_cast",
          "elif a.name in CAST" in src and "names=[a.name]" in src)


def t_organic_surface():
    """06/10 - משטחים אורגניים: Catmull-Clark, טופולוגיה וצפיפות.

    כל בדיקה כאן נועלת מספר שנמדד באותו יום, ושלושה מהם היו באגים
    אמיתיים שאף בדיקה קיימת לא תפסה.
    """
    import numpy as np
    from . import organic as O, appeal, basemesh as BM
    print("משטח אורגני:")

    # --- 1. שחזור הפוליגונים מהמשולשים
    q = O.quads_from_tris(np.array([0, 1, 2, 0, 2, 3, 4, 5, 6], np.uint32))
    check("quad משוחזר מזוג משולשים עוקב", q == [(0, 1, 2, 3), (4, 5, 6)])

    # --- 2. ההחלקה היא Catmull-Clark ולא לפלסיאן: קובייה מתעגלת
    cube = np.array([[x, y, z] for x in (-1, 1) for y in (-1, 1)
                     for z in (-1, 1)], float)
    F = [(0, 1, 3, 2), (4, 6, 7, 5), (0, 4, 5, 1),
         (2, 3, 7, 6), (0, 2, 6, 4), (1, 5, 7, 3)]
    tris = []
    for a, b, c, d in F:
        tris += [a, b, c, a, c, d]
    tris = np.array(tris, np.uint32)
    sm = O.smooth(cube, tris, passes=1)
    r = float(np.linalg.norm(sm, axis=1).mean())
    check("ההחלקה מעגלת קובייה", 1.25 < r < 1.45, f"רדיוס {r:.3f} (היה 1.732)")

    # --- 3. חלוקת משטח אמיתית מורידה חדות
    nv, ni = O.subdivide(cube, tris)
    p_before = O.smoothness(cube, tris)["p99"]
    p_after = O.smoothness(nv, ni)["p99"]
    check("subdivide מכפיל רשת ומוריד חדות",
          len(nv) > len(cube) and p_after < p_before - 20,
          f"{len(cube)}->{len(nv)} קודקודים, p99 {p_before}->{p_after}")

    # --- 4. קצה מכוון נשאר חד. זו ההגנה על קו השפתיים.
    tag = np.array(["skin"] * 4 + ["lip_line"] * 4)
    kept = O.smooth(cube, tris, tag=tag, passes=1)
    moved = float(np.abs(kept[4:] - cube[4:]).max())
    check("קודקוד על קצה מכוון אינו נמרח", moved < 0.26,
          f"תזוזה {moved:.3f}")

    # --- 5. המודד מתעלם מקצה מכוון (אחרת ציון 0 לדמות תקינה)
    both = O.smoothness(cube, tris)["p99"]
    only = O.smoothness(cube, tris, None, tag)["p99"]
    check("המודד מחריג גבול תגיות", only <= both,
          f"עם תגיות {only} מול {both}")

    # --- 6. קודקוד פנימי עם צלע crease אחת אינו פינה.
    #     זה היה באג: 256 קודקודי עור הוקפאו וההחלקה *ייצרה* מדרגות.
    faces = O.quads_from_tris(tris)
    topo = O.Topo(faces, len(cube))
    cr = O.crease_edges(topo, tag)
    kind = O.vertex_kind(topo, cr)
    cnt = np.zeros(len(cube), np.int32)
    for ei, (a, b) in enumerate(topo.edges):
        if cr[ei]:
            cnt[a] += 1
            cnt[b] += 1
    lone = (cnt == 1) & np.array([len(topo.ef[topo.edges[ei]]) == 2
                                  for ei in range(len(topo.edges))]).any() \
        if False else (cnt == 1)
    check("סיווג קודקודים מחזיר שלושה סוגים בלבד",
          set(np.unique(kind)) <= {0, 1, 2})

    # --- 7. הדמויות הבנויות: אפס פאות אבודות. היו 464.
    #
    # **שתי הבדיקות האחרונות כאן קוראות קבצים מהדיסק**, ואלה הנכסים
    # הממורגים (מאות מגה־בייט, לא ב-git). על שרת לינוקס הם אינם שם,
    # וקריאה עיוורת שלהם היא מה שהפיל את כל החבילה באמצע. ראה `skip`.
    _HAVE = paths.have_assets("zippy", "tamar")
    _WHY = f"אין נכסים ממורגים תחת {paths.rigged()}"
    if not _HAVE:
        skip("אפס פאות אבודות בדמויות הבנויות", _WHY)
    for nm in ("zippy", "tamar") if _HAVE else ():
        ch = appeal.Char(nm)
        pos = np.asarray(ch.attrs["position"], float)
        idx = np.asarray(ch.attrs["index"], np.int64)
        dg = O.degenerate_faces(pos, idx)
        check(f"{nm}: אין פאה בשטח אפס", dg == 0, f"{dg} (היו 464)")

    # --- 8. הצפיפות: 360/seg חייב להיות מתחת לסף הזוויתיות.
    #     seg_limb=16 נתן 22.5° לכל צלע אורכית, כלומר 33.9% מהזרוע.
    import inspect
    src = inspect.getsource(BM.build)
    for key, want in (("seg_body", 32), ("seg_limb", 32), ("seg_fing", 20)):
        line = [ln for ln in src.splitlines() if ln.strip().startswith(key)]
        check(f"{key} בצפיפות שמתחת ל-20°",
              bool(line) and f'"full": {want}' in line[0],
              line[0].strip() if line else "לא נמצא")

    # --- 9. האיברים חלקים בפועל. זה המספר שהמשתמש רואה.
    if not _HAVE:
        skip("חלקות האיברים בדמויות הבנויות", _WHY)
    else:
        ch = appeal.Char("zippy")
        pos = np.asarray(ch.attrs["position"], float)
        idx = np.asarray(ch.attrs["index"], np.int64)
        for g, was in (("arm_L", 33.86), ("leg_L", 33.28),
                       ("torso", 4.47)):
            s = O.smoothness(pos, idx, ch.group_mask(g), ch.tag)
            check(f"{g}: צלעות חדות מתחת ל-6%", s["over20"] < 6.0,
                  f"{s['over20']}% (היה {was}%)")
        sh = O.smoothness(pos, idx, ch.group_mask("head"), ch.tag)
        check("הראש לא נסוג", sh["over20"] <= 0.62,
              f"{sh['over20']}% (היה 0.62%)")

    # --- 10. העקומה והמודד שלה
    p = [O.hermite((0, 0, 0), (0, 1, 0), (0, 1, 0), (0, 1, 0), t / 8)
         for t in range(9)]
    check("Hermite על משיקים ישרים הוא קו ישר",
          O.tangent_break(p) < 1e-6)
    bent = [(0, 0, 0), (0, 1, 0), (1, 1, 0)]
    check("שבר משיק מודד פינה", abs(O.tangent_break(bent) - 90.0) < 1e-6)


def t_neck_spline():
    """TASK 18 (06/10) - הצוואר: ספליין רציף במקום צינור עם פינה.

    **מה שנמדד לפני התיקון, וזה כל הסיפור.** השבר בשרשרת הגו היה
    5.622°, והוא היה מרוכז ב**נקודה אחת** - מפרק הצוואר - בעוד
    שלושת המרווחים שמעליה מדדו 0.000° בדיוק. כלומר הצוואר לא היה
    "מעט זוויתי": הוא היה גליל ישר מושלם שהודבק בזווית. ומרווחי
    הטבעות היו 109.7 / 42.7 / 27.9 מ"מ - יחס 3.93.

    שני שערים נדרשים כאן, לא אחד, כי כל אחד לבד עובר גם על
    הגיאומטריה השבורה:
      * **צפיפות** לבד עוברת על צינור חלק עם פינה.
      * **שבר משיק** לבד עובר על שתי טבעות שהוסטו לעקומה.
    """
    print("צוואר - ספליין רציף (TASK 18):")
    import numpy as np                                     # noqa: PLC0415
    from . import dimorph as DM, organic as O              # noqa: PLC0415
    from .skeleton import Skeleton                         # noqa: PLC0415

    spine = ["hips", "spine_01", "spine_02", "chest", "neck"]
    for nm, h in (("male", 1.85), ("female", 1.65), ("neutral", 1.70)):
        dm = DM.get(nm)
        sk = Skeleton(height=h)
        P = {b.name: np.asarray(b.rest, float) for b in sk.bones}
        prof = DM.torso_profile(dm)
        neck = [r for r in prof if r[0] > 1.0]

        # --- 1. צפיפות: 6 טבעות הן המינימום שעקומה קובית דורשת.
        check(f"[{nm}] לצוואר {len(neck)} טבעות (>=6)", len(neck) >= 6,
              len(neck))

        # --- 2. מרכזי הטבעות על הספליין, כמו ב-`basemesh`.
        sp = [P[n] for n in spine]
        sp = ([sp[0] * 2 - sp[1]] + sp
              + [P["head"], P["head"] + (P["head"] - P["neck"]) * 1.25])
        un = float(len(spine) - 1)

        def C(t, _sp=sp, _un=un, _P=P):
            if t <= 1.0:
                return O.catmull_rom(_sp, _un * max(0.0, t))
            return O.catmull_rom(_sp, _un + (t - 1.0) * 3.2)

        chain = [C(r[0]) for r in prof if r[0] >= 0.5]
        nchain = [C(r[0]) for r in prof if r[0] >= 1.0]

        # --- 3. השבר. הסף 3.5° ולא 1°: ב-`neutral` אין `trap_rise`,
        # ולכן בשרשרת חסרה טבעת ביניים בכתף והשבר שם 3.22°. הסף
        # חייב לחסום את 5.62° הישן ולהתיר את מה שנמדד עכשיו.
        tb = O.tangent_break(chain)
        check(f"[{nm}] שבר משיק בשרשרת {tb:.3f}° < 3.5° (היה 5.622°)",
              tb < 3.5, round(tb, 3))
        tn = O.tangent_break(nchain)
        check(f"[{nm}] ובצוואר עצמו {tn:.3f}° < 2.0°", tn < 2.0, round(tn, 3))

        # --- 4. אחידות המרווח. היה 3.93.
        su = O.step_uniformity(nchain)
        check(f"[{nm}] מרווחי טבעות אחידים ({su:.3f} < 1.6, היה 3.93)",
              su < 1.6, round(su, 3))

        # --- 5. הצוואר אינו גליל: הרוחב חייב להשתנות בפועל.
        w = [float(r[1]) for r in neck]
        check(f"[{nm}] רוחב הצוואר משתנה לאורכו",
              (max(w) - min(w)) / max(w) > 0.15,
              round((max(w) - min(w)) / max(w), 4))

        # --- 6. אי-מונוטוניות, רק למי שביקש `neck_flare`. זה השער
        # שהטבעת החריגה הישנה שירתה, והוא חייב להמשיך לעבור בלי
        # הטבעת הזאת.
        flare = float(getattr(dm, "neck_flare", 0.0) or 0.0)
        rises = any(w[i + 1] > w[i] + 1e-9 for i in range(len(w) - 1))
        if flare > 1e-9:
            check(f"[{nm}] הצוואר מתרחב בבסיס הגולגולת (flare={flare})",
                  rises, [round(x, 4) for x in w])
        else:
            check(f"[{nm}] בלי flare הצוואר רק מצטר", not rises,
                  [round(x, 4) for x in w])

        # --- 7. הקצה העליון חייב לחדור לגולגולת, אחרת נראה תפר.
        top = float(nchain[-1][1])
        check(f"[{nm}] קצה הצוואר מעל מפרק הראש", top > float(P["head"][1]),
              (round(top, 4), round(float(P["head"][1]), 4)))

    # --- 8. Catmull-Rom: תכונות הנוסחה עצמה, בלי דמות.
    sq = [(0, 0, 0), (0, 1, 0), (0, 2, 0), (0, 3, 0)]
    check("Catmull-Rom עובר דרך נקודת הבקרה (u=0)",
          float(np.linalg.norm(O.catmull_rom(sq, 0.0)
                               - np.array([0, 1, 0]))) < 1e-12)
    check("ו-u=1 הוא הנקודה הבאה",
          float(np.linalg.norm(O.catmull_rom(sq, 1.0)
                               - np.array([0, 2, 0]))) < 1e-12)
    check("על נקודות קולינאריות הוא קו ישר",
          O.tangent_break(O.catmull_rom_chain(sq, 12)) < 1e-6)
    corner = [(0, 0, 0), (0, 1, 0), (1, 1, 0), (2, 1, 0)]
    check("ועל פינה הוא מחליק אותה (90° -> פחות מ-30°)",
          O.tangent_break(O.catmull_rom_chain(corner, 24)) < 30.0,
          round(O.tangent_break(O.catmull_rom_chain(corner, 24)), 2))
    check("Catmull-Rom דוחה פחות מ-4 נקודות בקרה",
          _raises(lambda: O.catmull_rom([(0, 0, 0), (0, 1, 0)], 0.0)))
    # smoothstep: הנגזרת באפס ובאחד היא מה שמונע תפר.
    check("smoothstep נעול בקצוות",
          abs(O.smoothstep(0.0)) < 1e-12 and abs(O.smoothstep(1.0) - 1) < 1e-12)
    d0 = (O.smoothstep(1e-4) - O.smoothstep(0.0)) / 1e-4
    check(f"ונגזרתו באפס מתאפסת ({d0:.2e})", abs(d0) < 1e-3, d0)
    check("smoothstep מקטם מחוץ לטווח",
          O.smoothstep(-5.0) == 0.0 and O.smoothstep(5.0) == 1.0)
    # step_uniformity: המודד שתפס את הדגימה המקרית.
    check("אחידות על מרווחים שווים היא 1.0",
          abs(O.step_uniformity([(0, 0, 0), (0, 1, 0), (0, 2, 0)]) - 1.0) < 1e-9)
    check("ועל 1 מול 3 היא 3.0",
          abs(O.step_uniformity([(0, 0, 0), (0, 1, 0), (0, 4, 0)]) - 3.0) < 1e-9)


def t_disney_park():
    """TASK 18 (06/10) - "הפארק הדינמי": ארבע דמויות, סביבה, 60 שניות.

    ארבעת המקרים הראשונים כאן הם **באגים אמיתיים שנמדדו היום**,
    וכל אחד מהם עבר את כל 1260 הבדיקות שקדמו לו:

    1. **`shoulder_square` הוא תוספת קופסתיות, לא אקספוננט.** הנחתי
       ש-1.0 הוא "אליפסה מדויקת" וכתבתי 0.97 כדי לעגל. המדידה:
       קלט 0.0 מודד 1.000, קלט 1.15 מודד 1.131. כלומר 0.97 הוסיף
       11% קופסתיות לארבע הדמויות במקום להוריד.
    2. **"עין בוהה" היא יחס ולא גודל.** אריאל נמדד בבליטת קרנית של
       20.50 מ"מ מול רדיוס גלגל 20.67 - 0.992 מרדיוס העין מחוץ
       לעור. השער הקיים (`t_disney_appeal`) בודק רק שהקרנית
       **פורצת**, ולכן עין שיושבת כולה על העור עברה אותו.
    3. **גוף שזז פעם אחת חייב להיות דינמי לכל אורך הסרט.** האופניים
       נצרבו במקום המנוחה וצוירו דינמית בנסיעה. בתמונת בדיקה נראו
       **שני זוגות אופניים** בפריים אחד. תמונה צרובה אי אפשר למחוק
       בזמן ריצה.
    4. **מקסימום שמשתנה בין שני קצות אותה תנועה אינו אותה תנועה.**
       מרחק הפנורמה היה `max(tall*2.4, fit(fov))`; כש-fov נפתח
       `fit` קטן, ולכן ב-u=0 ניצח איבר אחד וב-u=1 האחר - והריחוק
       בפועל היה פי 1.29 במקום פי 1.52 שהוזמן.
    """
    print("")
    print("הפארק הדינמי (TASK 18):")
    from . import cast_disney as CD                        # noqa: PLC0415
    from . import disney_mesh as DMESH                     # noqa: PLC0415
    from . import dimorph as DM                            # noqa: PLC0415
    from stage import park_disney as PD                    # noqa: PLC0415
    from showreel import disney_story as DS                # noqa: PLC0415

    # --- 1. `shoulder_square`: אפס הוא אליפסה, לא 1.0.
    m = {nm: DMESH.build(nm, "fast") for nm in CD.CAST4}
    for nm in CD.CAST4:
        check(f"[{nm}] חתך הכתף אליפסה מדויקת (1.000)",
              m[nm]["squareness"] <= 1.01, round(m[nm]["squareness"], 4))

    # --- 2. העין: שני הצדדים של החלון.
    for nm in CD.CAST4:
        check(f"[{nm}] הקרנית פורצת את העור",
              m[nm]["eye_out"] > DMESH.EYE_OUT_MIN_M,
              str(round(m[nm]['eye_out'] * 1000, 2)) + ' מ"מ')
        check(f"[{nm}] והעין אינה מודבקת (יחס < {DMESH.EYE_OUT_MAX_R})",
              m[nm]["eye_ratio"] < DMESH.EYE_OUT_MAX_R,
              round(m[nm]["eye_ratio"], 3))

    # --- 3. האופניים דינמיים תמיד; אין עותק צרוב למחוק.
    t0, t1 = DS.BIKE_ROLL
    for t in (0.0, t0, (t0 + t1) / 2, t1, 60.0):
        check(f"האופניים דינמיים גם ב-{t:.0f}ש",
              not PD.bike_at(t, t0, t1)["baked"], t)

    # --- 4. הפנורמה באמת מתרחקת.
    hs = {k: 1.85 for k in DS.SLOTS}
    c0, c1 = DS._cam("zoomout", 0.0, hs), DS._cam("zoomout", 1.0, hs)
    check("הפנורמה המסיימת מתרחקת פי 1.5 לפחות",
          c1["dist"] >= c0["dist"] * 1.5,
          f"{c0['dist']:.2f} -> {c1['dist']:.2f}")

    # --- 5. הצוואר הוא S ולא צינור: מינימום פנימי בחצי-הרוחב.
    for nm in CD.CAST4:
        check(f"[{nm}] פרופיל הצוואר הוא S (מינימום פנימי)",
              m[nm]["neck_s"], f"מינימום ב-{m[nm]['neck_argmin']}")

    # --- 5ב. TASK 20 · האגן, הירכיים והקונטור הנשי.
    #
    # **הנעילה הראשונה כאן חשובה מכל השאר:** `dimorph.THIGH_X` הוא
    # העתק של המספר שב-`skeleton.build`, והוא נקרא כדי לגזור את
    # שוקת הירך מהאגן. אם מישהו יזיז את המפרק בשלד והמספר כאן
    # יישאר, המשטח ייתפר במקום הלא נכון **בלי שום שגיאה** - ואין
    # שום מדד אחר שתופס את זה.
    _sk = Skeleton(1.70)
    _rest = {b.name: b.rest for b in _sk.bones}
    _tx = abs(float(_rest["thigh_L"][0]))
    check("dimorph.THIGH_X זהה למפרק הירך בשלד",
          abs(_tx - DM.THIGH_X) < 1e-9, f"{_tx:.4f} מול {DM.THIGH_X:.4f}")
    _hy = float(_rest["hips"][1])
    _s1 = float(_rest["spine_01"][1])
    _ty = float(_rest["thigh_L"][1])
    check("ו-HIP_DROP/HIP_SPAN נגזרים מאותם מפרקים",
          abs((_hy - _ty) - DM.HIP_DROP) < 1e-9
          and abs((_s1 - _hy) - DM.HIP_SPAN) < 1e-9,
          f"{_hy - _ty:.3f} / {_s1 - _hy:.3f}")

    for nm in CD.CAST4:
        check(f"[{nm}] מעטפת הצללית אגן->ירך מתחת ל-"
              f"{DMESH.HIP_BREAK_MAX:.0f}°",
              m[nm]["hip_break"] <= DMESH.HIP_BREAK_MAX,
              f"{m[nm]['hip_break']:.2f}°")

    # הקונטור הדו-אוני, ו**שני הכיוונים**: מי שביקש מקבל אונות,
    # ומי שלא ביקש אינו זז באף ספרה. הכיוון השני הוא זה שמגן על
    # שלוש הדמויות האחרות ועל תשעת הפרופילים הקיימים.
    lob = [nm for nm in CD.CAST4 if m[nm]["bust_lobe"] > 0.0]
    check("יש דמות אחת לפחות עם קונטור חזה נשי", bool(lob), lob)
    for nm in lob:
        check(f"[{nm}] שקע הסטרנום בין האונות",
              m[nm]["bust_dip"] >= DMESH.BUST_DIP_MIN,
              f'{m[nm]["bust_dip"] * 1000:.2f} מ"מ')
        check(f"[{nm}] והאונות מרוחקות זו מזו",
              m[nm]["bust_gap"] >= DMESH.BUST_GAP_MIN,
              f'{m[nm]["bust_gap"] * 1000:.0f} מ"מ')
    for nm in CD.CAST4:
        if nm in lob:
            continue
        check(f"[{nm}] לא ביקש אונות ולכן אף קודקוד לא זז",
              m[nm]["bust_moved"] == 0, m[nm]["bust_moved"])

    # ופרופיל שלא ביקש מיזוג נבנה בדיוק כמו קודם. זה השער שמגן על
    # 1575 הבדיקות שקדמו, בדיוק כמו `PRIOR` ב-`cast_disney`.
    _neutral = DM.PRESETS["neutral"]
    check("hip_blend=0 מחזיר את שתי שורות האגן המקוריות",
          [round(r[0], 4) for r in DM.torso_profile(_neutral)][:2]
          == [-0.34, -0.16],
          [round(r[0], 4) for r in DM.torso_profile(_neutral)][:3])
    check("ו-hip_loft ריק כשלא ביקשו אותו",
          DM.hip_loft(_neutral) == [], len(DM.hip_loft(_neutral)))
    _fem = DM.replace(_neutral, hip_blend=1.0)
    check("וכשכן ביקשו - השוקת אינה ריקה ועולה כלפי מעלה",
          len(DM.hip_loft(_fem)) == DM.LOFT_RINGS
          and DM.hip_loft(_fem)[0][0] > 0.0,
          len(DM.hip_loft(_fem)))
    # המיזוג **מרחיב בלבד.** אגן שרחב ממילא מהיעד אינו מצטר - זה
    # היה באג שיצר חריץ בצורת חגורה אצל שיר.
    _wide = DM.replace(_neutral, hip_w=0.30, hip_blend=1.0)
    _w0 = [r[1] for r in DM.torso_profile(DM.replace(_neutral, hip_w=0.30))]
    check("מיזוג אינו מצר אגן שרחב מהיעד",
          max(r[1] for r in DM.torso_profile(_wide)) >= max(_w0) - 1e-9,
          f"{max(r[1] for r in DM.torso_profile(_wide)):.4f} מול "
          f"{max(_w0):.4f}")

    # --- 5ב. TASK 21 · קו המותניים. הבאג שנתפס **ברנדור ולא במדידה**:
    # הגאומטריה של המיזוג עברה את כל השערים, אבל `bake_colors` צבע
    # לפי קבוצת רשת - `torso` כולו חולצה ו-`leg_` כולו מכנס. אחרי
    # שהשוקת העלתה את ראש הרגל מעל מפרק הירך שני הגבולות נחתכים,
    # וברנדור נראה טריז בצבע החולצה שיורד בין שתי מסות בצבע המכנס.
    # שתי בדיקות, ובשני הכיוונים: מי שמיזג מקבל קו אחד, ומי שלא
    # מיזג אינו משנה אף קודקוד.
    import numpy as _np
    from . import basemesh as _BM                         # noqa: PLC0415
    from . import pipeline as PL                          # noqa: PLC0415
    for _nm, _want in (("dn_shir", True), ("maya", False)):
        _c = PL.CAST[_nm]
        _mb, _ = _BM.build(PL.cast_skeleton(_nm),
                           _c["shape_override"], quality="fast")
        _wy = getattr(_mb, "waist_y", None)
        check(f"[{_nm}] קו המותניים {'נקבע' if _want else 'לא נקבע'}",
              (_wy is not None) == _want, _wy)
        if not _want:
            continue
        _sk = PL.cast_skeleton(_nm)
        _col = PL.bake_colors(_mb, _sk, PL.DEFAULT_PALETTE)
        _pos = _np.asarray(_mb.v, float)
        _grp = {g[0]: (g[1], g[2]) for g in _mb.groups}
        _t0, _t1 = _grp["torso"]
        _ty, _tc = _pos[_t0:_t1, 1], _col[_t0:_t1]
        # צבע ייחוס: אמצע החולצה, בין קו המותניים לבסיס הצוואר.
        _nk = float(_sk.by_name["neck"].rest[1])
        _mid = (_ty > _wy + 0.02) & (_ty < _nk - 0.05)
        check("יש רצועת חולצה לדגום ממנה", bool(_mid.any()), int(_mid.sum()))
        _shirt = _np.median(_tc[_mid], axis=0)
        _below = _ty < _wy
        _same = _np.all(_np.abs(_tc[_below] - _shirt) < 0.02, axis=1)
        check("ואף קודקוד של הטורסו מתחת לקו אינו בצבע החולצה",
              int(_same.sum()) == 0,
              f"{int(_same.sum())} מתוך {int(_below.sum())}")

    # --- 6. השערים המלאים של שלושת המודולים
    rep = CD.audit("fast")
    bad = [k for k, v in rep.items()
           if not k.startswith("_") and not v["pass"]]
    check("כל שערי ההרכב עוברים", not bad, bad or len(rep) - 1)
    rep = DMESH.audit("fast")
    bad = [k for k, v in rep.items()
           if not k.startswith("_") and not v["pass"]]
    check("וכל שערי הגיאומטריה האורגנית", not bad, bad or len(rep) - 1)

    # --- 7. חוזה התסריט: 1800 פריימים ואפס החלקת רגליים.
    rep = DS.contract()
    bad = [k for k, v in rep.items() if not v["pass"]]
    check("וחוזה התסריט של 60 השניות", not bad, bad or len(rep))

    # --- 8. הבמה מוכללת, וההחלפות מצאו את המקור. החלפה שהחמיצה
    #        משאירה במה דו-דמותית **בשקט**, וזה הכשל היחיד כאן
    #        שאף בדיקת פריים לא תופסת.
    html = DS.stage_html()
    check("הבמה הוכללה לארבעה מקומות", "const SLOTS" in html
          and "['A', 'B']" not in html, len(html))
    check("ושכבת האובייקטים הדינמיים נכנסה", "dnFrame" in html,
          html.count("dnFrame"))


def t_task22():
    """TASK 22 · פנים בסגנון בובת אופנה, הרכב של שמונה, ותסריט 90 ש'.

    שלוש קבוצות, וכל אחת מהן מפריכה טענה מההוראה ולא מתארת אותה.
    הבנייה כאן היא ב-`fast` ובכוונה: `full` הוא כ-6 שניות לדמות,
    כלומר כ-50 שניות לשמונה - וחבילת בדיקות שרצה דקה אינה נבדקת.
    חמשת הסיפים כוילו על `full` (ראה `doll.py`), ולכן נבדק כאן
    מה שאינו תלוי בצפיפות: שהשדות הגיעו, שהפונקציות באמת מזיזות
    קודקודים, ושהפרופילים שלא ביקשו אינם זזים באף ספרה.
    """
    print("\nפיסול בובת אופנה, הרכב של שמונה ותסריט 90ש (TASK 22):")
    import numpy as _np
    from rig import cast_disney as _CD
    from rig import detail as _DT
    from rig import dimorph as _DM
    from rig import doll as _DL
    from rig import basemesh as _BM
    from rig import pipeline as _PL
    from showreel import park90 as _P90

    # --- 1 · אפס הוא דילוג, לא "עוצמה אפס". זה השער שמגן על כל
    #        הדמויות הקודמות, והוא נבדק על **אובייקט** ולא על
    #        התוצאה: `is` מוכיח שלא נוצר עותק ולא בוצעה אריתמטיקה.
    p = _np.array([0.03, 0.08, 0.02])
    hc = _np.zeros(3)
    check("doll.cranium באפס מחזיר את אותו אובייקט",
          _DL.cranium(p, hc, 0.09, 0.0) is p, "ללא עותק")
    check("ו-doll.cheekbone כנ\"ל",
          _DL.cheekbone(p, hc, 0.09, 1.0, 1.0, 0.0) is p, "ללא עותק")
    check("ו-doll.jawline כנ\"ל",
          _DL.jawline(p, hc, 0.09, 0.0) is p, "ללא עותק")
    check("ו-doll.cupid_bow כנ\"ל",
          _DL.cupid_bow(p, hc, 0.09, 1.0, -0.3, 0.05, 1.0,
                        -0.30, 0.29, 0.0) is p, "ללא עותק")
    check("ו-lid_metric באפס זהה למרחק האוקלידי",
          _DL.lid_metric(p, _np.zeros(3), 0.0)
          == float(_np.hypot(p[0], p[1])), "שוויון מדויק")
    check("ו-socket_gain(0) הוא 1.0 בדיוק",
          _DL.socket_gain(0.0) == 1.0, "ולא 0.999…")

    # --- 2 · ובעוצמה חיובית הן **כן** מזיזות. בלי זה "אפס=דילוג"
    #        עובר גם כשהפונקציה אינה עושה דבר בשום עוצמה.
    q = _DL.cranium(_np.array([0.03, 0.06, 0.02]), hc, 0.09, 1.0)
    check("ובעוצמה 1 הגולגולת כן זזה",
          float(_np.linalg.norm(q - _np.array([0.03, 0.06, 0.02])))
          > 1e-4, f"{float(_np.linalg.norm(q - _np.array([0.03, 0.06, 0.02]))) * 1000:.2f} מ\"מ")
    # והיא מצטרת (מכפיל קטן מ-1) ולא מתרחבת
    check("והיא מצטרת ולא מתרחבת", abs(q[0]) < 0.03,
          f"{q[0]:.5f} מול 0.03")

    # --- 3 · הפרופילים הקודמים לא ביקשו דבר. זה מה שמוכיח שאף
    #        אחת מתשע הדמויות הקיימות לא יכולה להיות מושפעת.
    old = ("masc", "fem", "round", "block", "spire", "fluid",
           "male", "female")
    bad = [k for k in old
           if any(float(getattr(_DM.get(k), f, 0.0) or 0.0)
                  for f in ("doll_cranium", "doll_cheek", "doll_jaw",
                            "doll_lid", "doll_lip"))]
    check("אף פרופיל גוף קודם אינו נושא שדה פיסול", not bad,
          bad or f"{len(old)} פרופילים נקיים")

    # --- 4 · ההרכב: שמונה דמויות, שמונה גבהים, וכולן ביקשו פיסול
    check("ההרכב מונה שמונה דמויות", len(_CD.CAST8) == 8,
          len(_CD.CAST8))
    hs = sorted({round(float(_PL.CAST[n]["height"]), 3)
                 for n in _CD.CAST8})
    check("בשמונה גבהים נבדלים", len(hs) == 8,
          " · ".join(f"{h:.2f}" for h in hs))
    check("ויחס הגובה בין הגבוהה לנמוכה לפחות 1.5",
          hs[-1] / hs[0] >= 1.50, f"{hs[-1] / hs[0]:.3f}")
    miss = [n for n in _CD.CAST8
            if not float((_PL.CAST[n]["shape_override"]["dimorph"]
                          ).get("doll_cranium", 0.0) or 0.0)]
    check("וכל שמונה ביקשו גולגולת פרבולואידית", not miss,
          miss or "8/8")
    miss = [n for n in _CD.CAST8
            if not float((_PL.CAST[n]["shape_override"]["dimorph"]
                          ).get("doll_lip", 0.0) or 0.0)]
    check("וכל שמונה ביקשו קשת קופידון", not miss, miss or "8/8")
    check("ולכל אחת יש שם תפקיד וקול",
          all(n in _CD.ROLE and n in _CD.VOICES for n in _CD.CAST8),
          f"{len(_CD.ROLE)} תפקידים · {len(_CD.VOICES)} קולות")

    # --- 5 · על הרשת הבנויה: הקשת קיימת, והלחי בולטת. שתי דמויות
    #        בלבד (זמן), ובהן הזוג הראשי של החיבוק.
    for nm in ("dn_ariel", "dn_shir"):
        c = _PL.CAST[nm]
        sh = dict(c["shape_override"])
        skel = _PL.cast_skeleton(nm)
        Pb = {b.name: _np.asarray(b.rest, float) for b in skel.bones}
        H = _DT.Head(Pb, float(c["height"]) / 1.70, sh)
        mb, _m = _BM.build(skel, sh, quality="fast")
        m = _DL.measure(mb, H)
        check(f"[{nm}] והלסת מצטרת בחלון",
              _DL.JAW_TAPER_LO <= m["jaw_taper"] <= _DL.JAW_TAPER_HI,
              f'{m["jaw_taper"]:.3f}')

    # --- 5ב · קשת קופידון. **אנליטית ולא מהרשת ב-`fast`**, וזה
    #         נמדד ולא הונח: ב-`fast` לראש 18 טבעות בלבד, ורצועת
    #         השפה העליונה (±0.030R) תופסת פחות משתי טבעות - ולכן
    #         `bow_dip` מחזיר 0.0 מחוסר נקודות, גם כשהקשת קיימת.
    #         בדיקה שעוברת רק באיכות מלאה אינה בדיקה; הנוסחה עצמה
    #         אינה תלויה בצפיפות בכלל.
    def _lip_z(xn):
        q = _DL.cupid_bow(_np.array([xn * 0.09, 0.0, 0.0]), hc, 0.09,
                          1.0, -0.268, xn, 1.0, -0.30, 0.29, 1.0)
        return float(q[2])

    peak, mid = _lip_z(_DL.BOW_PEAK), _lip_z(0.0)
    check("קשת קופידון: הפסגה קדמית לשקע המרכזי", peak > mid,
          f'{(peak - mid) * 1000:.2f} מ"מ')
    check("והשקע המרכזי נסוג אחורה ואינו רק נמוך", mid < 0.0,
          f'{mid * 1000:.2f} מ"מ')

    # --- 5ג · ועל הרשת האמיתית, באיכות מלאה, לדמות אחת. זה השער
    #         שמוכיח שהנוסחה שורדת את הבנייה ולא רק את עצמה.
    c = _PL.CAST["dn_shir"]
    sh = dict(c["shape_override"])
    skel = _PL.cast_skeleton("dn_shir")
    Pb = {b.name: _np.asarray(b.rest, float) for b in skel.bones}
    H = _DT.Head(Pb, float(c["height"]) / 1.70, sh)
    mb, _m = _BM.build(skel, sh, quality="full")
    m = _DL.measure(mb, H)
    bad = [g for g, ok in _DL.gates(m).items() if not ok]
    check("[dn_shir] כל חמשת שערי פיסול הפנים על הרשת המלאה",
          not bad, bad or
          f'גולגולת {m["cranial_fit"]:.4f} · לחי '
          f'{m["cheek_relief"] * 1000:.1f} מ"מ · לסת {m["jaw_taper"]:.2f}'
          f' · שקד {m["lid_aspect"]:.2f} · קשת '
          f'{m["bow_dip"] * 1000:.1f} מ"מ')

    # --- 6 · הגולגולת של `Head.surf` זהה לזו של הרשת. זה הכשל
    #        היחיד כאן ששום בדיקת פנים לא תופסת: שיער שיושב על
    #        גולגולת אחת ועור על אחרת.
    c = _PL.CAST["dn_shir"]
    sh = dict(c["shape_override"])
    skel = _PL.cast_skeleton("dn_shir")
    Pb = {b.name: _np.asarray(b.rest, float) for b in skel.bones}
    H = _DT.Head(Pb, float(c["height"]) / 1.70, sh)
    check("Head טוען את עוצמת הגולגולת מהפרופיל",
          H.doll_cranium > 0.0, f"{H.doll_cranium:.2f}")
    up = H.surf(_np.array([0.0, 1.0, 0.15]))
    H2 = _DT.Head(Pb, float(c["height"]) / 1.70,
                  {**sh, "dimorph": {**sh["dimorph"],
                                     "doll_cranium": 0.0}})
    up0 = H2.surf(_np.array([0.0, 1.0, 0.15]))
    check("וקודקוד הגולגולת האנליטית באמת זז",
          float(_np.linalg.norm(up - up0)) > 1e-4,
          f'{float(_np.linalg.norm(up - up0)) * 1000:.2f} מ"מ')

    # --- 6ב · Mirror Enforcement (שער הסימטריה, נוסף 07/10).
    #        אנליטי ולא מהרשת: מעריך את פונקציות הפיסול בנקודה
    #        ובבבואתה סביב מישור X. נמדד 07/10 שסטיית בבואה על הרשת
    #        אחידה ~0.01-0.04 בכל הדמויות (רעש טסלציה), ולכן שער על
    #        הרשת מערבב רעש עם גוש אמיתי. ראה `doll.mirror_residual`.
    check("פיסול הפנים סימטרי סביב מישור X (שארית ~0)",
          _DL.mirror_residual(hc, 0.09) <= _DL.MIRROR_MAX,
          f'{_DL.mirror_residual(hc, 0.09):.2e}')
    # והשער אינו ריק: איבר תלוי-סימן מוזרק נתפס. בלי זה "שארית ~0"
    # עובר גם כשהמדד עיוור לאסימטריה - בדיוק המלכודת של שער מהרשת.
    _orig_ck = _DL.cheekbone

    def _broken_ck(p, h, R, k, fr, amt):
        qq = _orig_ck(p, h, R, k, fr, amt).copy()
        qq[2] += 0.002 * (p[0] - h[0]) / R * amt     # `x` במקום `abs(x)`
        return qq

    _DL.cheekbone = _broken_ck
    try:
        _rb = _DL.mirror_residual(hc, 0.09)
    finally:
        _DL.cheekbone = _orig_ck
    check("והשער תופס איבר תלוי-סימן מוזרק", _rb > _DL.MIRROR_MAX,
          f'{_rb * 1000:.2f} מ"מ שארית')
    check("וחזרה לפונקציה המקורית - שוב סימטרי",
          _DL.mirror_residual(hc, 0.09) <= _DL.MIRROR_MAX)

    # --- 6ג · רכס הלחי חלק ברזולוציה מלאה ולא פסים. `m` הוא
    #        dn_shir ב-full מסעיף 5ג. הפסים מופיעים רק ב-`fast`,
    #        שם sigma=0.085 קרוב למרווח הקודקודים; ב-full המרווח
    #        0.024R, כלומר הרכס פרוס על ~7 קודקודים - חלק.
    check("[dn_shir] רכס הלחי חלק ולא פסים (full)",
          0.0 < m["cheek_band"] <= _DL.CHEEK_BAND_MAX,
          f'{m["cheek_band"]:.4f} מול תקרה {_DL.CHEEK_BAND_MAX}')
    check("ושער הסימטריה נמנה בקבוצת השערים",
          "פנים סימטריות (Mirror Enforcement)" in _DL.gates(m))

    # --- 7 · חוזה התסריט של 90 השניות
    rep = _P90.audit()
    bad = [k for k, v in rep.items() if not v["pass"]]
    check("וכל שערי תסריט 90 השניות", not bad, bad or len(rep))
    check("והחיבוק הוא בין הבחור והבחורה הראשיים",
          _P90.SLOT_OF[_P90.LEAD_M] == "dn_ariel"
          and _P90.SLOT_OF[_P90.LEAD_F] == "dn_shir",
          f"{_P90.SLOT_OF[_P90.LEAD_M]} + {_P90.SLOT_OF[_P90.LEAD_F]}")
    check("והם בתת-קבוצות מנוגדות בהתפצלות",
          (_P90.LEAD_M in _P90.GROUP_L) != (_P90.LEAD_F in _P90.GROUP_L),
          "אחרת ההתאחדות אינה מאחדת דבר")


def t_arkit():
    """ממשק ARKit-52. השאלה היחידה שחשובה כאן: האם משבצת שמוצהרת
    כמונעת **באמת מזיזה** את הפנים. משבצת שקיימת ואינה עושה דבר
    גרועה ממשבצת נעדרת, כי כלי לכידה יניע אותה ולא יקבל שגיאה."""
    from . import arkit as A
    print("\n[ממשק ARKit-52]")

    a = A.audit()
    check("שער המיפוי עובר (אין יעד מומצא)", a["ok"], a["problems"])
    check("רשימת התקן היא 52 שמות", len(A.ARKIT_52) == 52, len(A.ARKIT_52))
    check("לכל שם בתקן יש משבצת",
          all(n in A.SLOTS for n in A.ARKIT_52))
    check("אין משבצת שאינה בתקן",
          not [n for n in A.SLOTS if n not in A.ARKIT_52])

    # --- 1 · יעד מומצא נדחה. זו הבדיקה בכיוון ההפוך, ובלעדיה השער
    #         עובר גם כשהוא לא בודק כלום.
    saved = A.SLOTS["jawOpen"]
    try:
        A.SLOTS["jawOpen"] = A.Slot("jawOpen", "exact",
                                    ctl={"אין_בקרה_כזו": 1.0})
        check("בקרה מומצאת נתפסת בשער", not A.audit()["ok"])
        A.SLOTS["jawOpen"] = A.Slot("jawOpen", "exact",
                                    mph={"אין_צורה_כזו": 1.0})
        check("צורה מומצאת נתפסת בשער", not A.audit()["ok"])
        A.SLOTS["jawOpen"] = A.Slot("jawOpen", "exact")
        check("משבצת מונעת שאינה מניעה דבר נתפסת",
              not A.audit()["ok"])
    finally:
        A.SLOTS["jawOpen"] = saved
    check("השער חזר לעבור אחרי השחזור", A.audit()["ok"])

    # --- 2 · חוזה המשבצת הנעדרת.
    #
    # **נבדק על משבצת מוזרקת, ולא על כך שיש נעדרות בפועל.** עד 08/10
    # היו כאן שבע נעדרות אמיתיות, והבדיקה דרשה `len(absent) > 0`.
    # ברגע שהפער נסגר (שבע הצורות נבנו ב-`face.py`) הדרישה הזו הפכה
    # לבדיקה שנופלת **דווקא כשהמשימה הצליחה** - כלומר תגמול על פער.
    # החוזה עצמו חייב להמשיך להיות נבדק, כי הוא עוד יידרש למשבצת
    # חדשה שתיפתח בעתיד; לכן הוא נמדד על פער שמוזרק לכאן ומוסר מיד.
    absent = set(A.absent())
    check("אין משבצת נעדרת - הכיסוי מלא", not absent, sorted(absent))
    check("נעדרת אינה נפלטת כמטרת morph",
          not (absent & set(A.targets())))
    _gap_saved = A.SLOTS["mouthClose"]
    try:
        A.SLOTS["mouthClose"] = A.Slot("mouthClose", "absent",
                                       note="פער מוזרק לבדיקה")
        check("משבצת שהוכרזה נעדרת מופיעה כנעדרת",
              set(A.absent()) == {"mouthClose"}, A.absent())
        check("נעדרת אינה נפלטת כמטרת morph",
              "mouthClose" not in A.targets())
        check("נעדרת מחזירה הנעה ריקה",
              A.drive({"mouthClose": 1.0}) == ({}, {}))
        check("השער עובר על נעדרת שיש לה הסבר", A.audit()["ok"])
        A.SLOTS["mouthClose"] = A.Slot("mouthClose", "absent")
        check("נעדרת בלי הסבר נתפסת בשער", not A.audit()["ok"])
    finally:
        A.SLOTS["mouthClose"] = _gap_saved
    check("השער עובר אחרי שהפער המוזרק הוסר", A.audit()["ok"])

    # --- 3 · תזוזה בפועל על רשת בנויה. כאן נופלת כל טענה שקרית.
    sk, mb, H, M = _face_fixture()
    pos = np.asarray(mb.v, float)
    base_q = controls.evaluate(sk, {})

    def _probe(name):
        """(תזוזת קודקוד במ"מ, שינוי סיבוב מרבי, מרכז מסה x, עצמות,
        תזוזה ממוצעת בציר הרוחב).

        האיבר החמישי נוסף 08/10 בשביל זוג **כיוונים** שמיושם בשתי
        צורות נגדיות: שם מרכז המסה זהה בשני הצדדים (אותה מסכה), ומה
        שמבדיל ביניהם הוא כיוון התזוזה עצמו.
        """
        ctl, mph = A.drive({name: 1.0})
        mm, cx, dxm = 0.0, None, 0.0
        if mph:
            p = face.apply_morphs(pos, M["deltas"], mph, M["names"])
            d = p - pos
            mm = float(np.abs(d).max()) * 1000.0
            w = np.linalg.norm(d, axis=1)
            if w.sum() > 1e-12:
                cx = float((pos[:, 0] * w).sum() / w.sum())
                dxm = float(d[:, 0].sum() / max(int(np.count_nonzero(
                    w > 1e-9)), 1))
        rot, bones = 0.0, []
        if ctl:
            q = controls.evaluate(sk, ctl)
            for b, v in q.items():
                if b not in base_q:
                    continue
                dv = float(np.abs(np.asarray(v)
                                  - np.asarray(base_q[b])).max())
                if dv > 1e-6:
                    bones.append(b)
                rot = max(rot, dv)
        return mm, rot, cx, sorted(bones), dxm

    dead = [n for n in A.supported()
            if _probe(n)[0] < 0.05 and _probe(n)[1] < 1e-6]
    check("אין משבצת מונעת שאינה מזיזה דבר", not dead, dead)

    # --- 4 · «מדויק» פירושו באמת צד נפרד. שתי משפחות ולא אחת:
    #         זוג צדדי גוף (עין, גבה, פינת פה) מול זוג **כיוונים**
    #         על בקרה דו-כיוונית (jawLeft/jawRight הם אותה לסת).
    #         מודד שמתייחס לשניהם אותו דבר פוסל התנהגות תקינה -
    #         וזו המלכודת שנפלה כאן במדידה הראשונה.
    # 08/10: `mouthLeft`/`mouthRight` נוספו כזוג כיוונים ולא כזוג
    # צדדים. הזזת הפה שמאלה והזזתו ימינה הן אותה מסת קודקודים בדיוק,
    # ולכן מרכז המסה שלהן זהה (≈0) ומודד הצדדים היה פוסל אותן למרות
    # שהן תקינות לחלוטין - אותה מלכודת שתועדה כאן ב-`jawLeft/jawRight`,
    # בגרסה שנייה שלה.
    AXIS_PAIRS = {("jawLeft", "jawRight"), ("mouthLeft", "mouthRight")}
    pairs = [(n, n.replace("Left", "Right"))
             for n in A.of_kind("exact") if n.endswith("Left")]
    check("יש זוגות צד מוצהרים כמדויקים", len(pairs) >= 8, len(pairs))
    for lf, rt in pairs:
        _mm, _r, cxl, bl, dxl = _probe(lf)
        _mm2, _r2, cxr, br, dxr = _probe(rt)
        if (lf, rt) in AXIS_PAIRS:
            cl = A.SLOTS[lf].ctl
            cr = A.SLOTS[rt].ctl
            if cl and set(cl) == set(cr):
                # אותה בקרה דו-כיוונית, בסימן הפוך (הלסת).
                check(f"{lf}/{rt}: כיוונים הפוכים על אותה בקרה",
                      all(cl[k] * cr[k] < 0 for k in cl), (cl, cr))
                both, _ = A.drive({lf: 1.0, rt: 1.0})
                check(f"{lf}+{rt} יחד מתאפסים",
                      all(abs(v) < 1e-9 for v in both.values()), both)
            else:
                # שתי צורות נגדיות. אין כאן בקרה שתתאפס, ולכן נמדדת
                # **התזוזה בפועל על הרשת**: מדידה גאומטרית תופסת גם
                # צורה שנכתבה עם סימן הפוך, מה שהשוואת מקדמים לא
                # יכולה לתפוס כשהיעדים אינם אותו יעד.
                check(f"{lf}/{rt}: תזוזה הפוכה בציר הרוחב",
                      dxl * dxr < 0
                      and min(abs(dxl), abs(dxr)) > 1e-5,
                      f"{dxl:+.6f} מול {dxr:+.6f}")
            continue
        if cxl is not None and cxr is not None:
            check(f"{lf}/{rt}: מזיזים צדדים מנוגדים",
                  cxl * cxr < 0 and abs(cxl - cxr) > 0.005,
                  f"{cxl:+.4f} מול {cxr:+.4f}")
        else:
            check(f"{lf}/{rt}: מזיזים עצמות שונות",
                  bool(bl) and bool(br) and bl != br, (bl, br))

    # --- 5 · «משותף־צד» - החוזה, ועצמאות הצדדים בפועל.
    #
    # **הסעיף הזה התהפך ב-08/10, בדיוק כמו סעיף 2.** עד כאן היו 16
    # משבצות `shared` אמיתיות, והבדיקה דרשה `len(sh) >= 6`. ברגע
    # ששמונה צורות מפוצלות נוספו ב-`face.py` וארבע בקרות מבט לכל עין
    # ב-`controls.py`, הדרישה הזו נפלה **דווקא כשהמשימה הצליחה** -
    # כלומר תגמול על מגבלה. החוזה של `shared` עצמו עוד יידרש למשבצת
    # עתידית, ולכן הוא נמדד כאן על זוג שמוזרק ומוסר מיד, ואילו המצב
    # בפועל נבדק כעצמאות גאומטרית אמיתית.
    sh = [(n, n.replace("Left", "Right"))
          for n in A.of_kind("shared") if n.endswith("Left")]
    check("אין משבצת משותפת־צד - כל צד נשלט בנפרד", not sh, sh)
    _sh_saved = (A.SLOTS["mouthDimpleLeft"], A.SLOTS["mouthDimpleRight"])
    try:
        for _n in ("mouthDimpleLeft", "mouthDimpleRight"):
            A.SLOTS[_n] = A.Slot(_n, "shared", mph={"mouth_dimple": 0.5},
                                 note="זוג משותף מוזרק לבדיקה")
        inj = A.of_kind("shared")
        check("זוג שהוכרז משותף מופיע כמשותף",
              set(inj) == {"mouthDimpleLeft", "mouthDimpleRight"}, inj)
        tl = set(A.SLOTS["mouthDimpleLeft"].mph)
        tr = set(A.SLOTS["mouthDimpleRight"].mph)
        check("משותף פירושו אותו יעד לשני הצדדים", tl == tr, (tl, tr))
        _, m = A.drive({"mouthDimpleLeft": 1.0, "mouthDimpleRight": 1.0})
        check("שני צדדים של זוג משותף נותנים 1.0 ולא 2.0",
              abs(m.get("mouth_dimple", 0.0) - 1.0) < 1e-9, m)
        check("השער עובר על זוג משותף מאוזן", A.audit()["ok"])
        A.SLOTS["mouthDimpleRight"] = A.Slot(
            "mouthDimpleRight", "shared", mph={"mouth_dimple": 1.0},
            note="סכום שבור")
        check("זוג משותף שסכומו אינו 1.0 נתפס בשער", not A.audit()["ok"])
    finally:
        A.SLOTS["mouthDimpleLeft"], A.SLOTS["mouthDimpleRight"] = _sh_saved
    check("השער עובר אחרי שהזוג המוזרק הוסר", A.audit()["ok"])

    # עצמאות המבט: משבצת של עין אחת מזיזה **רק** את העין שלה. זו
    # המדידה שמוכיחה שהפיצול אמיתי ולא רק הצהרה בטבלה.
    for _ak, _own, _other in (("Left", "eye_L", "eye_R"),
                              ("Right", "eye_R", "eye_L")):
        _mm, _r, _cx, bones, _dx = _probe(f"eyeLookUp{_ak}")
        check(f"eyeLookUp{_ak} מזיז את {_own} בלבד",
              bones == [_own], bones)
    # שתי העיניים למעלה = מבט מלא למעלה, **ושווה בדיוק** למבט המשותף
    # על 1.0. זה מה שמונע "מלמעלה כפול" או "חצי משרעת".
    c, _ = A.drive({"eyeLookUpLeft": 1.0, "eyeLookUpRight": 1.0})
    q_ark = controls.evaluate(sk, c)
    q_mst = controls.evaluate(sk, {"eye_aim_y": 1.0})
    check("שתי העיניים למעלה = מבט משותף מלא למעלה",
          all(np.allclose(q_ark[b], q_mst[b], atol=1e-12)
              for b in ("eye_L", "eye_R")),
          {b: (q_ark[b], q_mst[b]) for b in ("eye_L", "eye_R")})
    # למעלה ולמטה באותה עצימות על אותה עין = עין שמביטה ישר.
    c, _ = A.drive({"eyeLookUpLeft": 1.0, "eyeLookDownLeft": 1.0})
    check("למעלה+למטה באותה עין מתאפסים",
          all(abs(v) < 1e-9 for v in c.values()), c)
    # פזילה פנימה: ההתכנסות היא עכשיו **תוצאה** של שתי עיניים
    # שמסתובבות לכיוונים נגדיים, ולא מקדם `eye_converge` מפורש.
    c, _ = A.drive({"eyeLookInLeft": 1.0, "eyeLookInRight": 1.0})
    check("פזילה פנימה אינה נזקקת לבקרת ההתכנסות",
          "eye_converge" not in c, c)
    yl = float(np.asarray(controls.evaluate(sk, c)["eye_L"])[1])
    yr = float(np.asarray(controls.evaluate(sk, c)["eye_R"])[1])
    check("פזילה פנימה מסובבת את שתי העיניים לכיוונים נגדיים",
          yl * yr < 0 and min(abs(yl), abs(yr)) > 1e-4, (yl, yr))
    # והחוצה הוא ההיפך המדויק - בלי זה "פנימה" הוא רק שם.
    c_out, _ = A.drive({"eyeLookOutLeft": 1.0, "eyeLookOutRight": 1.0})
    ol = float(np.asarray(controls.evaluate(sk, c_out)["eye_L"])[1])
    check("החוצה הוא ההיפך המדויק של פנימה",
          abs(ol + yl) < 1e-12, (ol, yl))

    # --- 5ב · הצורות המפוצלות: ``L + R`` הוא **בדיוק** המקורית.
    #
    # זו הטענה שכל הפיצול עומד עליה, ולכן היא נמדדת על הרשת הבנויה
    # ולא מונחת. אם היא נשברת, פיצול הצד אינו הפרדה אלא גאומטריה
    # חדשה שאיש לא כיול - וזה היה מופיע כפה עקום בכל דמות.
    for base, lf_s, rt_s in face.SPLIT_PAIRS:
        i_b, i_l, i_r = (M["names"].index(x) for x in (base, lf_s, rt_s))
        db, dl, dr = M["deltas"][i_b], M["deltas"][i_l], M["deltas"][i_r]
        err = float(np.abs((dl + dr) - db).max()) * 1000.0
        check(f"{base}: פיצול הצד מחזיר את הצורה במדויק",
              err < 1e-6, f"{err:.6f} מ\"מ")
        # ולא "חצי צורה בכל צד": המשרעת בצד שלו נשמרת במלואה.
        mb_, ml_ = (float(np.linalg.norm(x, axis=1).max())
                    for x in (db, dl))
        check(f"{base}: הצד שומר את המשרעת המלאה",
              abs(mb_ - ml_) < 1e-9, (mb_, ml_))
    check("חלוקת האחדות סוכמת ל-1 בכל קודקוד",
          float(np.abs(face.FaceSpace(mb, H).side_split("L")
                       + face.FaceSpace(mb, H).side_split("R")
                       - 1.0).max()) < 1e-12)
    # והלא־מפוצלת אינה נפלטת לכלי לכידה - אחרת אותה תנועה ניתנת
    # להנעה משני מקומות (אזהרת Command A ו-Qwen, 08/10).
    _tg = {k for n in A.targets() for k in A.SLOTS[n].mph}
    check("הצורה הלא־מפוצלת אינה מטרת ARKit",
          not _tg & {b for b, _l, _r in face.SPLIT_PAIRS}, sorted(_tg))

    # --- 6 · גמה שלמה אינה חורגת מטווח אף בקרה.
    full = {n: 1.0 for n in A.supported()}
    ctl, mph = A.drive(full)
    bad = [(k, v) for k, v in ctl.items()
           if not (controls.CONTROLS[k][0] - 1e-9 <= v
                   <= controls.CONTROLS[k][1] + 1e-9)]
    check("הנעה מלאה בתוך הטווח של כל בקרה", not bad, bad)
    check("כל הצורות בתוך [0,1]",
          all(0.0 <= v <= 1.0 for v in mph.values()))

    # --- 7 · קלט פגום אינו מפיל פריים, ושם לא תקני נתפס ב-strict.
    check("שם שאינו בתקן מדולג כברירת מחדל",
          A.drive({"headPitch": 1.0, "jawOpen": 1.0})[0] == {"jaw_open": 1.0})
    check("ובמצב קפדני הוא נזרק",
          _raises(lambda: A.drive({"headPitch": 1.0}, strict=True)))
    check("משקולת שלילית אינה כיוון הפוך אלא מתעלמים ממנה",
          A.drive({"jawOpen": -1.0}) == ({}, {}))
    check("משקולת מעל 1 מהודקת",
          A.drive({"jawOpen": 9.0})[0]["jaw_open"] == 1.0)
    check("משקולת לא מספרית מדולגת",
          A.drive({"jawOpen": None}) == ({}, {}))
    check("הנעה ריקה מחזירה ריק", A.drive({}) == ({}, {}))
    check("None מחזיר ריק", A.drive(None) == ({}, {}))

    # --- 8 · הכיסוי שמדידת הבסיס נשענת עליו.
    cov = A.coverage()
    check("סכום המצבים הוא 52",
          cov["exact"] + cov["shared"] + cov["absent"] == 52, cov)
    check("מונעים = מדויקים + משותפים",
          cov["driven"] == cov["exact"] + cov["shared"], cov)
    check("רוב התקן מונע בפועל", cov["ratio"] >= 0.80, cov["ratio"])
    print(f"   {cov['driven']}/52 מונעים · {cov['exact']} מדויקים · "
          f"{cov['shared']} משותפי־צד · {cov['absent']} נעדרים")


def _raises(fn) -> bool:
    try:
        fn()
    except Exception:
        return True
    return False


def main():
    global RUN
    sys.stdout.reconfigure(encoding="utf-8")
    for fn in (t_skeleton, t_quats, t_ik, t_controls, t_secondary,
               t_mesh_and_weights, t_identity, t_identity_audit,
               t_glb, t_pipeline,
               t_detail, t_ear, t_face, t_acting, t_emotion, t_eyes,
               t_speech, t_sss, t_face_glb, t_acting_showreel,
               t_emotion_scenes, t_foreground, t_showreel,
               t_body, t_voice, t_body_scenes,
               t_principles, t_syllables, t_secondary_rig, t_appeal,
               t_hair_recession, t_hierarchy_robustness, t_cinema,
               t_dimorph, t_shape_language, t_facestyle,
               t_duet, t_park, t_ensemble,
               t_locomotion, t_cast14, t_chase, t_gender,
               t_disney_appeal, t_organic_surface, t_neck_spline,
               t_disney_park, t_task22, t_arkit):
        # **חריגה בבדיקה אחת אינה מבטלת את כל החבילה (08/10).**
        # בענן (ריצה 37699431625) `t_organic_surface` זרק
        # `FileNotFoundError`, הוא עלה עד `main`, והחבילה יצאה
        # באמצע: חמש הבדיקות שאחריה - ובהן `t_arkit`, זו שבגללה
        # הריצה נעשתה - לא רצו כלל, והדוח חזר ``passed=-1``.
        #
        # כאן החריגה נרשמת כ**כשל** בשמה, וההרצה ממשיכה. זה אינו
        # ריכוך: כשל נשאר כשל וקוד היציאה נשאר 1. מה שהשתנה הוא
        # שעכשיו רואים את *כל* הכשלים בריצה אחת ולא רק את הראשון.
        try:
            fn()
        except Exception as e:                            # noqa: BLE001
            import traceback
            nm = getattr(fn, "__name__", str(fn))
            print(f"  ✗ {nm} קרס: {type(e).__name__}: {e}")
            traceback.print_exc()
            FAILS.append(f"{nm} (חריגה)")
            RUN += 1
    print(f"\n{RUN - len(FAILS)}/{RUN} עברו")
    if SKIPS:
        print(f"דולגו {len(SKIPS)} (נכסים שלא נבנו כאן): "
              + ", ".join(SKIPS))
    if FAILS:
        print("נכשלו:", ", ".join(FAILS))
    return 1 if FAILS else 0


if __name__ == "__main__":
    raise SystemExit(main())
