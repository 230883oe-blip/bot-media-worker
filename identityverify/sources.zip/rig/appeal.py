# -*- coding: utf-8 -*-
"""TASK 09 · מנהל קסם הדמות (Character Appeal Director).

"כאן אנחנו מתחילים להתקרב ממש ל-Pixar מבחינת עיצוב דמות, לא חיקוי של
דמות קיימת."

=== מה ההבדל בין הקובץ הזה לבין "עוד בדיקה" ===

תשע האיכויות שהמשימה מונה - צללית, פרופורציות, קריאות פנים, שפת
צורה, אסימטריה, היררכיה חזותית, הרמוניית צבע, זיהוי ו"קריאות רגשית" -
הן בדיוק סוג הדברים שקל להצהיר עליהם ואי אפשר לבדוק בעין. לכן כל
אחת מהן כאן היא **פונקציה שמחזירה מספר**, והמספר נמדד על הגאומטריה
שנבנתה בפועל ועל הפיקסלים שיצאו בפועל - לא על כוונות.

שתי החלטות מבנה שנובעות מזה:

1. **המצלמה מחושבת גם בפייתון.** `camera` ו-`project` משחזרים *בדיוק*
   את המצלמה של `viewer.html` (אותו lookAt, אותו fov אנכי, אותו יחס
   צדדים). בלי זה אי אפשר לשאול "בן כמה פיקסלים העין בשוט רחב", כי
   התשובה היא מכפלה של גאומטריה במסגור. הבדיקה `t_appeal` מאמתת את
   ההיטל הזה מול תיבת האלפא של רנדור WebGL אמיתי - אם הם ייפרדו, כל
   מדידת הקריאות כאן הופכת לסיפור.

2. **מדידה שאין לה נגד-מדידה היא חסרת ערך.** "זיהוי" לבד עובר גם על
   שתי דמויות זהות; לכן `recognizability` מחזיר גם *הפרדה* בין הדמויות
   ומחלק בה. "אסימטריה" לבד עוברת גם על דמות שבורה; לכן היא חלון ולא
   סף. "קריאות פנים" לבד עוברת על פנים ענקיות; לכן היא נמדדת בפיקסלים
   בשוט רחב *וגם* ביחס לרוחב הראש.

=== תשעת תנאי הרנדור ===

המשימה דורשת שהדמות תישאר מזוהה בתקריב, שוט בינוני, שוט רחב, פרופיל,
שלושה-רבעים, זווית נמוכה, זווית גבוהה ובתאורות שונות. "תאורות שונות"
ברבים, ולכן יש שתיים (`rim` ו-`hard_key`) ובסך הכול תשעה תנאים.
התאורה נוספה כ-`window.__light` ב-`viewer.html`, והיא **קבועה ואינה
נעה עם המצלמה** - אחרת אי אפשר להפריד "התאורה זזה" מ"הדמות השתנתה".
"""
from __future__ import annotations

import argparse
import asyncio
import base64
import functools
import http.server
import json
import math
import shutil
import socketserver
import sys
import tempfile
import threading
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
STUDIO = HERE.parent
if str(STUDIO) not in sys.path:
    sys.path.insert(0, str(STUDIO))

from rig import acting, basemesh, controls, face, identity, pipeline  # noqa: E402
from rig import paths                                 # noqa: E402

RIG_DIR = paths.rigged()
OUT_DIR = paths.char3d("appeal")

#: (שם, yaw, pitch, מרחק כמכפלת גובה, מרכז כמכפלת גובה, fov, תאורה)
CONDITIONS = [
    ("close_up",       -14.0,   4.0, 0.72, 0.905, 26.0, "studio"),
    ("medium",          -8.0,   2.0, 1.55, 0.760, 32.0, "studio"),
    ("wide",             0.0,   2.0, 3.05, 0.500, 32.0, "studio"),
    ("side_profile",    88.0,   1.0, 1.55, 0.760, 32.0, "studio"),
    ("three_quarter",   38.0,   5.0, 1.55, 0.760, 32.0, "studio"),
    ("low_angle",      -18.0, -22.0, 1.70, 0.560, 32.0, "studio"),
    ("high_angle",     -18.0,  28.0, 1.70, 0.820, 32.0, "studio"),
    ("light_rim",        -8.0,  2.0, 1.55, 0.760, 32.0, "rim"),
    ("light_hard_key",   -8.0,  2.0, 1.55, 0.760, 32.0, "hard_key"),
]

WIDTH, HEIGHT = 720, 1000


# =========================================================== מצלמה והיטל

def camera(yaw: float, pitch: float, dist: float, cy: float):
    """(מקום המצלמה, מטריצת הצירים) - העתק מדויק של `viewer.html`.

    three.js בונה `lookAt` כך: z = נורמל(עין - מטרה), x = נורמל(up × z),
    y = z × x. כל חריגה מזה מזיזה את ההיטל בכמה פיקסלים, וכמה פיקסלים
    זה בדיוק סדר הגודל שמחליט אם "העין קריאה בשוט רחב".
    """
    ry, rp = math.radians(yaw), math.radians(pitch)
    eye = np.array([math.sin(ry) * math.cos(rp) * dist,
                    cy + math.sin(rp) * dist,
                    math.cos(ry) * math.cos(rp) * dist])
    target = np.array([0.0, cy, 0.0])
    z = eye - target
    z /= np.linalg.norm(z)
    up = np.array([0.0, 1.0, 0.0])
    x = np.cross(up, z)
    nx = np.linalg.norm(x)
    if nx < 1e-9:                      # מצלמה בדיוק מעל/מתחת
        x = np.cross(np.array([0.0, 0.0, 1.0]), z)
        nx = np.linalg.norm(x)
    x /= nx
    y = np.cross(z, x)
    return eye, np.stack([x, y, z], axis=1)       # עמודות


def project(pts: np.ndarray, yaw: float, pitch: float, dist: float,
            cy: float, fov: float, w: int, h: int):
    """נקודות עולם -> פיקסלים + עומק. fov הוא **אנכי**, כמו ב-three.js."""
    eye, R = camera(yaw, pitch, dist, cy)
    cam = (np.asarray(pts, float) - eye) @ R          # R אורתונורמלית
    depth = -cam[:, 2]                                # לפני המצלמה => חיובי
    safe = np.maximum(depth, 1e-6)
    f = 1.0 / math.tan(math.radians(fov) * 0.5)
    aspect = w / float(h)
    ndx = (f / aspect) * cam[:, 0] / safe
    ndy = f * cam[:, 1] / safe
    px = (ndx + 1.0) * 0.5 * w
    py = (1.0 - ndy) * 0.5 * h
    return np.stack([px, py], axis=1), depth


def shot_params(height_m: float, cond) -> dict:
    name, yaw, pitch, dmul, cymul, fov, light = cond
    return {"name": name, "yaw": yaw, "pitch": pitch,
            "dist": height_m * dmul, "cy": height_m * cymul,
            "fov": fov, "light": light}


# ================================================================ מסכות

def _shift_or(m: np.ndarray, r: int) -> np.ndarray:
    """הרחבה (dilate) ברדיוס r, בלי scipy."""
    out = m.copy()
    for dy in range(-r, r + 1):
        for dx in range(-r, r + 1):
            if dx == 0 and dy == 0:
                continue
            out |= np.roll(np.roll(m, dy, 0), dx, 1)
    return out


def _shift_and(m: np.ndarray, r: int) -> np.ndarray:
    out = m.copy()
    for dy in range(-r, r + 1):
        for dx in range(-r, r + 1):
            if dx == 0 and dy == 0:
                continue
            out &= np.roll(np.roll(m, dy, 0), dx, 1)
    return out


def densify(pos: np.ndarray, index: np.ndarray) -> np.ndarray:
    """קודקודים + מרכזי משולשים + אמצעי צלעות.

    **זה לא ייפוי.** צללית שנרסטרה מהקודקודים בלבד יצאה כאן 13%-22%
    מתיבת התוחם שלה, כלומר קונטור מחורר ולא גוף: בדמות הזו 75% מהקודקודים
    יושבים בשיער ובפנים, והגו והרגליים הם צינורות דלילים. כל מדידת שטח
    על מסכה כזאת מחזירה מספר של *צפיפות הרשת*, לא של הצורה - ו"קמירות
    0.22" על אדם עומד היא בדיוק הסימן לזה.

    ארבע דגימות לכל משולש מכפילות את צפיפות הדגימה פי ~4 בלי לרסטר
    משולשים אחד-אחד בפייתון, והצפיפות הזאת היא שמאפשרת לסגירה
    המורפולוגית למלא את הפנים בלי להרחיב את הקצה.
    """
    f = np.asarray(index, np.int64).reshape(-1, 3)
    a, b, c = pos[f[:, 0]], pos[f[:, 1]], pos[f[:, 2]]
    return np.concatenate([pos, (a + b + c) / 3.0,
                           (a + b) / 2.0, (b + c) / 2.0, (c + a) / 2.0])


def raster(px: np.ndarray, w: int, h: int, close: int = 2) -> np.ndarray:
    """מסכת צללית מנקודות על המשטח.

    הנקודות הן **מעטפת**, לא נפח, ולכן היסטוגרמה גולמית מחזירה קונטור
    מחורר. סגירה מורפולוגית (הרחבה ואז כיווץ) ממלאת אותה בלי להרחיב את
    הקצה החוצה - וזה חשוב, כי כל מדידות הצללית כאן הן יחסי שטח.
    """
    ok = (px[:, 0] >= 0) & (px[:, 0] < w) & (px[:, 1] >= 0) & (px[:, 1] < h)
    m = np.zeros((h, w), bool)
    if not ok.any():
        return m
    xi = px[ok, 0].astype(np.int32)
    yi = px[ok, 1].astype(np.int32)
    m[yi, xi] = True
    if close > 0:
        m = _shift_and(_shift_or(m, close), close)
    return m


def hull_area(mask: np.ndarray) -> float:
    """שטח הקמור של הצללית (monotone chain). בלי scipy, ובמכוון:
    התלות היחידה בפרויקט היא numpy."""
    ys, xs = np.nonzero(mask)
    if len(xs) < 3:
        return float(len(xs))
    pts = sorted(set(zip(xs.tolist(), ys.tolist())))
    if len(pts) < 3:
        return float(len(pts))

    def half(seq):
        out = []
        for p in seq:
            while len(out) >= 2:
                (x1, y1), (x2, y2) = out[-2], out[-1]
                if (x2 - x1) * (p[1] - y1) - (y2 - y1) * (p[0] - x1) <= 0:
                    out.pop()
                else:
                    break
            out.append(p)
        return out

    hull = half(pts)[:-1] + half(pts[::-1])[:-1]
    a = 0.0
    for i in range(len(hull)):
        x1, y1 = hull[i]
        x2, y2 = hull[(i + 1) % len(hull)]
        a += x1 * y2 - x2 * y1
    return abs(a) * 0.5


def extremities(mask: np.ndarray, prom: float = 0.14) -> int:
    """מספר ה"קצוות" הקריאים בצללית: פסגות של פונקציית הרדיוס סביב
    מרכז המסה.

    זה המדד שמפריד צללית קריאה (ראש, שתי ידיים, שתי רגליים) מגוש. הוא
    נמדד על **רדיוס מנורמל**, ולכן הוא אינו תלוי בגודל הדמות בפריים -
    וזו הסיבה שהוא נשאר אותו מספר בתקריב ובשוט רחב.
    """
    ys, xs = np.nonzero(mask)
    if len(xs) < 20:
        return 0
    cx, cy = xs.mean(), ys.mean()
    ang = np.arctan2(ys - cy, xs - cx)
    rad = np.hypot(xs - cx, ys - cy)
    nb = 72
    bins = ((ang + math.pi) / (2 * math.pi) * nb).astype(int) % nb
    prof = np.zeros(nb)
    np.maximum.at(prof, bins, rad)
    if prof.max() <= 0:
        return 0
    prof = prof / prof.max()
    cnt = 0
    for i in range(nb):
        a, b, c = prof[(i - 1) % nb], prof[i], prof[(i + 1) % nb]
        if b >= a and b > c and b > prom:
            # בולטות מקומית: גבוה מהבקעה הקרובה בשני הכיוונים
            lo = min(prof[(i - 3) % nb], prof[(i + 3) % nb])
            if b - lo >= prom:
                cnt += 1
    return cnt


def splat(px: np.ndarray, depth: np.ndarray, color: np.ndarray,
          w: int, h: int):
    """רסטר צבע עם z-buffer, בפייתון. מחזיר (תמונה RGB, מסכה).

    למה בכלל: ההיררכיה החזותית וההרמוניה חייבות להימדד על **תמונה**,
    אבל בדיקת יחידה לא יכולה לפתוח דפדפן. התמונה כאן היא אלבדו בלי
    תאורה - וזה בדיוק מה שצריך למדידת ניגודיות וצבע, כי תאורה מוסיפה
    הטיה שאינה תכונה של עיצוב הדמות. הרנדור האמיתי נמדד בנפרד.
    """
    img = np.zeros((h, w, 3), np.float32)
    zb = np.full((h, w), np.inf, np.float32)
    ok = ((px[:, 0] >= 0) & (px[:, 0] < w) & (px[:, 1] >= 0) & (px[:, 1] < h)
          & (depth > 0))
    if not ok.any():
        return img, np.zeros((h, w), bool)
    xi = px[ok, 0].astype(np.int32)
    yi = px[ok, 1].astype(np.int32)
    dz = depth[ok].astype(np.float32)
    col = color[ok]
    order = np.argsort(-dz)                  # רחוק קודם, קרוב דורס
    xi, yi, dz, col = xi[order], yi[order], dz[order], col[order]
    img[yi, xi] = col
    zb[yi, xi] = dz
    mask = np.isfinite(zb)
    # מילוי החורים שבין הקודקודים, מאותה סיבה שב-`raster`
    full = _shift_and(_shift_or(mask, 2), 2)
    hole = full & ~mask
    if hole.any():
        for _ in range(3):
            sm = np.zeros_like(img)
            cnt = np.zeros((h, w), np.float32)
            for dy, dx in ((0, 1), (0, -1), (1, 0), (-1, 0)):
                sm += np.roll(np.roll(img, dy, 0), dx, 1)
                cnt += np.roll(np.roll(mask.astype(np.float32), dy, 0), dx, 1)
            fill = hole & (cnt > 0)
            img[fill] = sm[fill] / np.maximum(cnt[fill, None], 1.0)
            mask = mask | fill
            hole = full & ~mask
    return img, full


# ====================================================== נתוני דמות

class Char:
    """דמות כפי שנבנתה: שלד, עור, תגיות, אזורים, לוח צבעים וצורות פנים."""

    def __init__(self, name: str, rig_dir: Path = RIG_DIR,
                 with_face: bool = True):
        self.name = name
        self.rig = json.loads((rig_dir / f"{name}.rig.json")
                              .read_text(encoding="utf-8"))
        npz = np.load(str(rig_dir / f"{name}.attrs.npz"))
        self.attrs = {k: npz[k] for k in ("position", "normal", "uv",
                                          "skinIndex", "skinWeight", "index")}
        self.color = npz["color"]
        if "tag" not in npz.files:
            raise RuntimeError(
                f"{name}.attrs.npz נבנה לפני TASK 09 ואין בו תגיות קודקוד. "
                "יש להריץ `python -m rig.pipeline --cast`.")
        self.tag = np.asarray(npz["tag"]).astype(str)
        self.skel = pipeline.skeleton_from_rig(self.rig)
        self.height = float(self.rig["height_m"])
        self.palette = self.rig["identity"]["palette"]
        self.groups = {g[0]: (int(g[1]), int(g[2]))
                       for g in self.rig["mesh"]["group_ranges"]}
        self.shape = self.rig["identity"]["shape"]
        self._mb = None
        self._morphs = None
        self._with_face = with_face
        self._surf: dict = {}

    # הרשת נבנית מחדש רק כשצריך את צורות הפנים (קריאות רגשית). זה
    # חישוב סקלרי של 2-5 שניות, והוא לא נעשה בשאר המדידות.
    def morphs(self) -> dict:
        if self._morphs is None:
            mb, _ = basemesh.build(self.skel, self.shape, quality="full")
            if len(mb.v) != len(self.attrs["position"]):
                raise RuntimeError(
                    f"{self.name}: בנייה חוזרת החזירה {len(mb.v)} קודקודים "
                    f"ולא {len(self.attrs['position'])} - ה-GLB והקוד "
                    "אינם מאותה גרסה.")
            self._mb = mb
            self._morphs = face.build(mb, mb.head)
        return self._morphs

    def mask_of(self, *tags) -> np.ndarray:
        return np.isin(self.tag, list(tags))

    def group_mask(self, *names) -> np.ndarray:
        m = np.zeros(len(self.attrs["position"]), bool)
        for n in names:
            if n in self.groups:
                a, b = self.groups[n]
                m[a:b] = True
        return m

    def posed(self, q: dict | None = None) -> np.ndarray:
        return identity.skin(self.skel, self.attrs, q or {})

    def surface(self, q: dict | None = None) -> np.ndarray:
        """ענן נקודות צפוף על המשטח - זה מה שהצלליות נמדדות עליו."""
        key = tuple(sorted(q)) if q else ()
        if key not in self._surf:
            self._surf[key] = densify(self.posed(q), self.attrs["index"])
        return self._surf[key]

    # ---------------------------------------------------- מידות מהרשת
    def mesh_box(self, mask: np.ndarray) -> dict:
        """תיבת התוחם של אזור **ברשת**, במטרים.

        כל מידת פרופורציה כאן נמדדת מהרשת ולא מהעצמות, וזה לא עניין
        של טעם: `head_tip` יושבת 1.70 בעוד פני הגולגולת מעליה,
        ו-`jaw_tip` יושבת מעל קצה הסנטר. גובה ראש שנמדד בין שתי
        העצמות האלה יצא 0.197 מ' לדמות בגובה 1.78 - כלומר 8.9 ראשים,
        שזה לא גוף של אדם אלא שגיאת מדידה של 20%.
        """
        p = self.attrs["position"][mask]
        if not len(p):
            return {}
        lo, hi = p.min(axis=0), p.max(axis=0)
        return {"lo": lo, "hi": hi, "size": hi - lo}

    def head_box(self) -> dict:
        m = self.mask_of("skin", "hair", "ear", "sclera", "iris", "pupil",
                         "brow", "lash", "lip_up", "lip_lo", "lip_line",
                         "nostril", "blush", "limbal", "catch")
        pos = self.attrs["position"]
        neck = float(identity.bone_world(self.skel)["neck"][1])
        return self.mesh_box(m & (pos[:, 1] > neck))

    def head_metrics(self) -> dict:
        """סנטר, קודקוד, גובה ורוחב הראש - מגאומטריית **הגולגולת**.

        לא מתגיות ולא מעצמות, ושתי הדרכים האלה נוסו ונמדדו כשגויות:
          * תגית `skin` נגמרת בקו השיער (הקרקפת מתויגת `hair`), ולכן
            "גובה ראש" יצא 0.145 מ' - 26% חסר.
          * `jaw_tip` ו-`head_tip` הן עצמות עוזרות: הראשונה *מעל* קצה
            הסנטר והשנייה *מתחת* לפני הגולגולת.
        קבוצת `head` היא הגאומטריה שנבנתה כגולגולת, והיא הדבר היחיד
        שהקצה שלו הוא באמת הקצה.
        """
        b = self.mesh_box(self.group_mask("head"))
        if not b:
            return {}
        return {"chin": float(b["lo"][1]), "crown": float(b["hi"][1]),
                "h": float(b["size"][1]), "w": float(b["size"][0])}

    def shoulder_width(self) -> float:
        """רוחב כתפיים: הפרוסה סביב עצם הבריח, **כולל הדלתואידים**,
        ועל **פוזת המנוחה** ולא על פוזת הכריכה.

        שתי טעויות נמדדו כאן אחת אחרי השנייה:
          * מדידה על הגו בלבד החזירה 0.18 מ' - זה רוחב בית החזה.
          * מדידה שכוללת את הזרועות החזירה 1.41 מ' - כי פוזת הכריכה
            של השלד היא **צלב**, ובגובה הבריח יושבת שם כל הזרוע
            הפרושה. זה אותו מקור טעות שתועד ב-README (פוזת כריכה אינה
            פוזת מנוחה), והוא חוזר בכל מדידה שנוגעת ברוחב.
        בפוזת המנוחה הזרועות מורדות, ולכן בגובה הבריח נשארים הגו
        והדלתואיד - וזה בדיוק רוחב הכתפיים.
        """
        lib = controls.pose_library(self.skel)
        q = controls.evaluate(self.skel, *lib["rest"]) if "rest" in lib else {}
        pos = self.posed(q)
        cy = float(identity.bone_world(self.skel)["clavicle_L"][1])
        m = (self.group_mask("torso", "arm_L", "arm_R")
             & (pos[:, 1] < cy + 0.02 * self.height)
             & (pos[:, 1] > cy - 0.04 * self.height))
        if m.sum() < 20:
            return 0.0
        return float(pos[m, 0].max() - pos[m, 0].min())


# ================================================= 1 · צללית (silhouette)

def silhouette(ch: Char, cond, pose: dict | None = None,
               w: int = 180, h: int = 250) -> dict:
    p = shot_params(ch.height, cond)
    px, dz = project(ch.surface(pose), p["yaw"], p["pitch"], p["dist"],
                     p["cy"], p["fov"], w, h)
    m = raster(px[dz > 0], w, h)
    n = int(m.sum())
    if not n:
        return {"shot": p["name"], "pixels": 0, "solidity": 1.0,
                "extremities": 0, "aspect": 0.0, "mask": m}
    ys, xs = np.nonzero(m)
    bw = xs.max() - xs.min() + 1
    bh = ys.max() - ys.min() + 1
    ha = hull_area(m)
    return {
        "shot": p["name"],
        "pixels": n,
        # קמירות: 1.0 = גוש קמור לגמרי (בובת שלג), נמוך מאוד = צללית
        # קרועה. הקסם יושב באמצע - יש חלל שלילי, אבל הגוף עוד קורא.
        "solidity": round(n / max(1.0, ha), 4),
        "extremities": extremities(m),
        "aspect": round(bh / max(1.0, bw), 3),
        "fill_bbox": round(n / float(bw * bh), 4),
        "mask": m,
    }


def silhouette_distinctness(a: dict, b: dict) -> float:
    """1 - IoU של שתי צלליות שנורמלו לאותה תיבה. זה המדד ל"האם אפשר
    להבדיל בין שתי הדמויות בצללית שחורה בלבד", וזו בדיוק הגרסה
    המחמירה של appeal."""
    ma, mb = _norm_mask(a["mask"]), _norm_mask(b["mask"])
    inter = float((ma & mb).sum())
    union = float((ma | mb).sum())
    return round(1.0 - inter / max(1.0, union), 4)


# ============================================= 2 · פרופורציות (proportions)

#: חלונות הפרופורציה. הם **לא** "נכון/לא נכון" אנטומי - הם התחום שבו
#: עיצוב מסוגנן נשאר קריא. מספר ראשים: 7.5 הוא אדם מצולם, 4-5 הוא ילד
#: מצויר, 6.0-7.2 הוא הטווח של דמות בוגרת מסוגננת.
PROP_WINDOW = {
    "heads_tall": (5.9, 7.5),
    "eye_line": (0.38, 0.58),       # גובה קו העיניים בתוך הראש, 0=סנטר
    "shoulder_to_head": (1.45, 2.45),
    "leg_fraction": (0.44, 0.56),   # אורך רגל / גובה
    "arm_fraction": (0.29, 0.40),   # כתף עד שורש כף היד / גובה
    "hand_to_head": (0.62, 1.05),   # אורך כף יד / גובה ראש
}


def proportions(ch: Char) -> dict:
    """ששת יחסי המידה שמחליטים אם עיצוב הדמות קורא.

    כולם נמדדים על **הרשת** (`Char.skull_height`, `Char.mesh_box`) ולא
    על העצמות, אחרי שהגרסה הראשונה כאן מדדה גובה ראש בין `jaw_tip`
    ל-`head_tip` והחזירה 8.9 ראשים לדמות של 1.78 מ'. שתי העצמות האלה
    הן עוזרות ריג ולא קצות גאומטריה; פני הגולגולת מעל `head_tip`
    וקצה הסנטר מתחת ל-`jaw_tip`.
    """
    bw = identity.bone_world(ch.skel)
    hm = ch.head_metrics()
    head_h, head_w, chin = hm["h"], hm["w"], hm["chin"]
    eye_y = float((bw["eye_L"][1] + bw["eye_R"][1]) * 0.5)
    sh = ch.shoulder_width()
    leg = (float(np.linalg.norm(bw["thigh_L"] - bw["shin_L"]))
           + float(np.linalg.norm(bw["shin_L"] - bw["foot_L"])))
    arm = (float(np.linalg.norm(bw["upperarm_L"] - bw["forearm_L"]))
           + float(np.linalg.norm(bw["forearm_L"] - bw["hand_L"])))
    tip = "middle_tip_L" if "middle_tip_L" in bw else "middle_03_L"
    hand = float(np.linalg.norm(bw["hand_L"] - bw[tip]))
    vals = {
        "heads_tall": ch.height / max(1e-6, head_h),
        "eye_line": (eye_y - chin) / max(1e-6, head_h),
        "shoulder_to_head": sh / max(1e-6, head_w),
        "leg_fraction": leg / ch.height,
        "arm_fraction": arm / ch.height,
        "hand_to_head": hand / max(1e-6, head_h),
    }
    inside = {}
    for k, (lo, hi) in PROP_WINDOW.items():
        v = vals[k]
        inside[k] = bool(lo <= v <= hi)
    return {"values": {k: round(v, 4) for k, v in vals.items()},
            "window": PROP_WINDOW, "inside": inside,
            "head_h_m": round(head_h, 4), "head_w_m": round(head_w, 4),
            "shoulder_m": round(sh, 4),
            "outside": [k for k, v in inside.items() if not v],
            "in_window": sum(inside.values()), "of": len(inside)}


# ========================================== 3 · קריאות פנים (readability)

#: תווי הפנים שחייבים להישאר נראים, ומה מודדים בכל אחד.
FEATURES = {
    "eye_L": ("sclera", "iris", "pupil"),
    "mouth": ("lip_up", "lip_lo", "lip_line"),
    "brow_L": ("brow",),
}
#: רוחב מינימלי בפיקסלים שבו תו פנים עוד נקרא בשוט. שלושה פיקסלים הם
#: הגבול שבו קו מפסיק להיות קו והופך לרעש דגימה (נייקוויסט + שוליים).
MIN_FEATURE_PX = 3.0


def facial_readability(ch: Char, conds=None, w: int = WIDTH,
                       h: int = HEIGHT) -> dict:
    """בן כמה פיקסלים כל תו פנים בכל שוט, ומה חלקו ברוחב הראש.

    זה המקום שבו "קריאות פנים" מפסיקה להיות דעה. בשוט רחב הראש תופס
    עשרות פיקסלים, ואם העין היא שני פיקסלים - הפנים לא קוראות שם, ולא
    משנה כמה הן מעוצבות בתקריב.
    """
    conds = conds or CONDITIONS
    head = ch.group_mask("head") | ch.mask_of("skin", "hair", "ear")
    pos = ch.attrs["position"]
    bw = identity.bone_world(ch.skel)
    head_y = float(bw["jaw_tip"][1])
    head = head & (pos[:, 1] > head_y - 0.02)
    out, rows = {}, []
    for cond in conds:
        p = shot_params(ch.height, cond)
        px, dz = project(pos, p["yaw"], p["pitch"], p["dist"], p["cy"],
                         p["fov"], w, h)
        vis = dz > 0
        hm = head & vis
        if not hm.any():
            continue
        hw = float(px[hm, 0].max() - px[hm, 0].min())
        hh = float(px[hm, 1].max() - px[hm, 1].min())
        feats = {}
        for fname, tags in FEATURES.items():
            m = ch.mask_of(*tags) & vis
            if fname.endswith("_L"):
                m = m & (pos[:, 0] > 0)
            if not m.any():
                feats[fname] = {"px": 0.0, "of_head": 0.0}
                continue
            fw = float(px[m, 0].max() - px[m, 0].min())
            feats[fname] = {"px": round(fw, 2),
                            "of_head": round(fw / max(1e-6, hw), 4)}
        out[p["name"]] = {"head_px": round(hw, 1), "head_px_h": round(hh, 1),
                          "features": feats}
        rows.append((p["name"], min(f["px"] for f in feats.values())))
    worst = min((v for _, v in rows), default=0.0)
    return {"per_shot": out, "min_feature_px": round(worst, 2),
            "limit_px": MIN_FEATURE_PX,
            "readable_in_all_shots": bool(worst >= MIN_FEATURE_PX),
            "worst_shot": min(rows, key=lambda r: r[1])[0] if rows else ""}


# =========================================== 4 · שפת צורה (shape language)

#: האזורים שעליהם נמדדת שפת הצורה, ושם האזור בעברית לדוח.
SHAPE_REGIONS = {
    "head": ("head",),
    "torso": ("torso",),
    "arm": ("arm_L",),
    "leg": ("leg_L",),
    "hand": ("palm_L",),
    "foot": ("foot_L",),
}


def _family(roundness: float, taper: float) -> str:
    """משפחת הצורה של אזור: עיגול / ריבוע / משולש.

    הסדר חשוב: **ההתחדדות נבדקת לפני העגלוּת**. צורה מתחדדת היא משולש
    גם אם היא עגולה בקצה אחד, ובדיקה הפוכה סיווגה את הזרוע כ"עיגול"
    רק משום שהחתך שלה עגול - וזה לא מה ששפת צורה מודדת.
    """
    if taper >= 1.35:
        return "triangle_down"
    if taper <= 0.74:
        return "triangle_up"
    if roundness >= 0.90:
        return "square"
    if roundness >= 0.66:
        return "round"
    return "triangle_down" if taper > 1.0 else "triangle_up"


def shape_language(ch: Char, w: int = 160, h: int = 220) -> dict:
    """הצורה הדומיננטית בכל אזור, מתוך הצללית הקדמית של האזור עצמו."""
    pos = ch.attrs["position"]
    p = shot_params(ch.height, CONDITIONS[2])     # שוט רחב, הדמות כולה
    px, dz = project(pos, p["yaw"], p["pitch"], p["dist"], p["cy"],
                     p["fov"], w, h)
    out = {}
    for rname, groups in SHAPE_REGIONS.items():
        m = ch.group_mask(*groups) & (dz > 0)
        if m.sum() < 30:
            continue
        sub = px[m]
        y0, y1 = sub[:, 1].min(), sub[:, 1].max()
        span = max(1e-6, y1 - y0)
        hi = sub[sub[:, 1] <= y0 + span * 0.28]
        lo = sub[sub[:, 1] >= y1 - span * 0.28]
        wtop = float(hi[:, 0].max() - hi[:, 0].min()) if len(hi) else 0.0
        wbot = float(lo[:, 0].max() - lo[:, 0].min()) if len(lo) else 0.0
        mask = raster(sub, w, h, close=1)
        ys, xs = np.nonzero(mask)
        bw = max(1, xs.max() - xs.min() + 1)
        bh = max(1, ys.max() - ys.min() + 1)
        roundness = float(mask.sum()) / float(bw * bh)
        taper = wtop / max(1e-6, wbot)
        out[rname] = {"roundness": round(roundness, 4),
                      "taper": round(taper, 4),
                      "family": _family(roundness, taper)}
    fams = [v["family"] for v in out.values()]
    dom = max(set(fams), key=fams.count) if fams else ""
    return {"regions": out, "dominant": dom,
            "dominant_share": round(fams.count(dom) / max(1, len(fams)), 3),
            "families": sorted(set(fams)),
            # שפה אחת לכל הגוף היא עיצוב, לא רשימת צורות; אבל שפה
            # *יחידה* היא מונוטוניות. לכן נדרשת גם דומיננטיות וגם ניגוד.
            "has_language": bool(fams and fams.count(dom) / len(fams) >= 0.45),
            "has_contrast": len(set(fams)) >= 2}


# ================================================ 5 · אסימטריה (asymmetry)

#: חלון האסימטריה. אפס = בובה מכנית; יותר מדי = ריג שבור או פוזה
#: מעוותת. הקצה התחתון נקבע ממדידה: פוזת מנוחה בלי אסימטריה מחזירה
#: 0.000, והפוזות של `controls.pose_library` מחזירות 0.03-0.30.
ASYM_WINDOW = (0.015, 0.45)


def _pair(names):
    return [(n, n[:-2] + "_R") for n in names if n.endswith("_L")]


def asymmetry(ch: Char, q: dict, mph: dict | None = None) -> dict:
    """אסימטריה כגודל מדיד: הפרש הסיבוב בין כל זוג עצמות שמאל/ימין,
    והפרש המשקולות בין צורות פנים צדדיות."""
    pairs = _pair([b.name for b in ch.skel.bones])
    diffs = []
    for l, r in pairs:
        if l not in q and r not in q:
            continue
        ql = np.asarray(q.get(l, [0, 0, 0, 1.0]), float)
        qr = np.asarray(q.get(r, [0, 0, 0, 1.0]), float)
        # שיקוף ב-X הופך את הסימן של y ו-z בקוורטניון; פוזה סימטרית
        # לחלוטין מחזירה אפס מדויק אחרי השיקוף.
        qm = np.array([qr[0], -qr[1], -qr[2], qr[3]])
        diffs.append(float(np.linalg.norm(ql - qm)))
    bone = float(np.mean(diffs)) if diffs else 0.0
    shp = 0.0
    if mph:
        sp = _pair(list(mph))
        if sp:
            shp = float(np.mean([abs(mph.get(l, 0.0) - mph.get(r, 0.0))
                                 for l, r in sp]))
    score = bone + shp
    lo, hi = ASYM_WINDOW
    return {"bone": round(bone, 4), "shape": round(shp, 4),
            "score": round(score, 4), "window": ASYM_WINDOW,
            "pairs": len(diffs),
            "in_window": bool(lo <= score <= hi)}


# ====================================== 6 · היררכיה חזותית (hierarchy)

def _luma(img: np.ndarray) -> np.ndarray:
    return (0.2126 * img[:, :, 0] + 0.7152 * img[:, :, 1]
            + 0.0722 * img[:, :, 2])


def _blur3(a: np.ndarray) -> np.ndarray:
    out = a.astype(np.float32) * 4.0
    for dy, dx in ((0, 1), (0, -1), (1, 0), (-1, 0)):
        out += np.roll(np.roll(a, dy, 0), dx, 1)
    return out / 8.0


def saliency(img: np.ndarray, mask: np.ndarray,
             nrm: np.ndarray | None = None) -> np.ndarray:
    """מפת "לאן העין הולכת": ניגודיות מקומית, רוויה, קצה, **וצפיפות
    פרט גאומטרי**.

    האיבר הרביעי נוסף אחרי מדידה, ולא לשם שלמות: בלעדיו מאיה קיבלה
    "רווח 1.000" - חלק הקשב בתוך תיבת הפנים יצא **זהה** לחלק השטח
    שלה, עד שלוש ספרות. הסיבה פשוטה: האלבדו של הדמות שטוח לפי אזורים
    (חולצה בצבע אחד, עור בצבע אחד), ולכן ניגודיות וגרדיאנט מתאפסים
    כמעט בכל מקום והמפה יוצאת אחידה - כלומר המדד מדד שטח, לא קשב.

    מה שבאמת מבדיל פנים מחולצה הוא **שינוי הנורמל**: עין, שפה, נחיר
    וגבה מכופפים את המשטח עשרות פעמים בתוך סנטימטרים, וחולצה לא. זה
    גם מה שהעין האנושית באמת רואה כפרט.
    """
    L = _luma(img)
    loc = np.abs(L - _blur3(L))
    gy = np.abs(np.roll(L, 1, 0) - L)
    gx = np.abs(np.roll(L, 1, 1) - L)
    mx = img.max(axis=2)
    mn = img.min(axis=2)
    sat = (mx - mn) / np.maximum(mx, 1e-6)
    # כל איבר שנמדד מהפרש בין פיקסלים שכנים מוגבל ל**פנים** המסכה:
    # בגבול הצללית ההפרש הוא בין הדמות לרקע, כלומר קו מתאר ולא פרט
    # עיצוב. נמדד שבלי זה הרגליים (איבר דק = הרבה קו מתאר לכל פיקסל)
    # עקפו את הפנים בדירוג.
    edge = _shift_and(mask > 0, 2).astype(np.float32)
    s = (2.0 * loc + 0.5 * (gx + gy)) * edge + 0.6 * sat
    if nrm is not None:
        # `nrm` כאן הוא **מפת מזהי אזור**, לא נורמלים.
        #
        # שינוי נורמל נוסה כאן ונפסל במדידה: גליל דק מראה שינוי נורמל
        # חד לרוחבו מעצם היותו גליל, ולכן הרגליים ניצחו את הפנים
        # (`legs>hair>arms>torso>face`). זה מדד של **עובי**, לא של
        # פרט.
        #
        # מה שכן מבדיל פנים מרגל על אלבדו שטוח הוא מספר האזורים:
        # בפנים יש לובן, קשתית, אישון, ריס, שפה עליונה, תחתונה, קו
        # שפתיים, גבה, נחיר - תשעה גבולות בתוך סנטימטרים; ברגל יש
        # אזור אחד. צפיפות גבולות היא בדיוק "כמה קורה כאן", והיא
        # אדישה לעובי האיבר.
        ids = nrm[:, :, 0]
        bnd = np.zeros_like(ids, np.float32)
        for dy, dx in ((0, 1), (0, -1), (1, 0), (-1, 0)):
            bnd += (np.abs(np.roll(np.roll(ids, dy, 0), dx, 1) - ids)
                    > 1e-4).astype(np.float32)
        s = s + 0.9 * (bnd * 0.25) * edge
    return s * mask


def visual_hierarchy(ch: Char, cond=None, w: int = 360, h: int = 500) -> dict:
    """האם הפנים מנצחות את שאר הדמות על תשומת הלב.

    המדד הוא **רווח** ולא אחוז: חלק הקשב בתוך תיבת הראש חלקי חלק
    *השטח* שלה. ככה לא מקבלים "ניצחון" רק מפני שהראש גדול.
    """
    cond = cond or CONDITIONS[1]
    p = shot_params(ch.height, cond)
    pos = ch.attrs["position"]
    px, dz = project(pos, p["yaw"], p["pitch"], p["dist"], p["cy"],
                     p["fov"], w, h)
    img, mask = splat(px, dz, ch.color, w, h)
    # מפת מזהי אזור: לכל קודקוד מספר לפי התגית שלו. מועברת דרך אותו
    # z-buffer של `splat`, ולכן היא תמיד **של המשטח הקדמי**.
    uniq = {t: i for i, t in enumerate(sorted(set(ch.tag.tolist())))}
    tid = np.array([uniq[t] for t in ch.tag], np.float32)[:, None] / 255.0
    tmap, _ = splat(px, dz, np.repeat(tid, 3, axis=1), w, h)
    if not mask.any():
        return {"gain": 0.0, "ok": False}
    s = saliency(img, mask.astype(np.float32), tmap)
    bwld = identity.bone_world(ch.skel)
    hm = (ch.mask_of("skin", "sclera", "iris", "pupil", "brow", "lip_up",
                     "lip_lo", "lash", "ear")
          & (pos[:, 1] > float(bwld["jaw_tip"][1]) - 0.02) & (dz > 0))
    if not hm.any():
        return {"gain": 0.0, "ok": False}
    x0, x1 = int(px[hm, 0].min()), int(px[hm, 0].max()) + 1
    y0, y1 = int(px[hm, 1].min()), int(px[hm, 1].max()) + 1
    x0, y0 = max(0, x0), max(0, y0)
    x1, y1 = min(w, x1), min(h, y1)
    box = np.zeros((h, w), bool)
    box[y0:y1, x0:x1] = True
    box &= mask
    tot_s = float(s.sum())
    tot_a = float(mask.sum())
    if tot_s <= 0 or tot_a <= 0 or not box.any():
        return {"gain": 0.0, "ok": False}
    share_s = float(s[box].sum()) / tot_s
    share_a = float(box.sum()) / tot_a
    gain = share_s / max(1e-6, share_a)

    # --- דירוג האזורים: *למי* העין הולכת קודם.
    # זה הניסוח הנכון של היררכיה חזותית, וההחלטה לעבור אליו נולדה
    # ממדידה: "רווח" מוחלט על אלבדו שטוח חוזר כ-1.0 בדיוק, כי כשאין
    # תאורה הצפיפות אחידה והרווח מודד שטח. דירוג, לעומת זאת, שואל את
    # השאלה האמיתית - האם הפנים צפופות בפרט יותר מהשיער, מהבגד
    # ומהגפיים. דמות שבה התסרוקת מנצחת את הפנים היא בדיוק הכישלון
    # שהעיקרון הזה אמור לתפוס.
    bands = {
        "face": hm,
        "hair": ch.mask_of("hair") & (dz > 0),
        "torso": ch.group_mask("torso") & (dz > 0),
        "arms": ch.group_mask("arm_L", "arm_R", "palm_L", "palm_R") & (dz > 0),
        "legs": ch.group_mask("leg_L", "leg_R", "foot_L", "foot_R") & (dz > 0),
    }
    dens = {}
    for bn, bm in bands.items():
        if not bm.any():
            continue
        reg = np.zeros((h, w), bool)
        xs = np.clip(px[bm, 0].astype(int), 0, w - 1)
        ys = np.clip(px[bm, 1].astype(int), 0, h - 1)
        reg[ys, xs] = True
        reg = _shift_and(_shift_or(reg, 1), 1) & mask
        if reg.sum() < 20:
            continue
        dens[bn] = float(s[reg].mean())
    order = sorted(dens, key=dens.get, reverse=True)
    lead = (dens.get("face", 0.0)
            / max(1e-6, max((v for k, v in dens.items() if k != "face"),
                            default=0.0)))
    return {"shot": p["name"], "face_saliency_share": round(share_s, 4),
            "face_area_share": round(share_a, 4),
            "gain": round(gain, 3),
            "density": {k: round(v, 4) for k, v in dens.items()},
            "order": order, "face_lead": round(lead, 3),
            # הקריטריון הוא **הדירוג**: הפנים ראשונות. הפער הוא רק
            # שומר נגד תיקו - הממוצע נלקח על אלפי פיקסלים ולכן הרעש
            # שלו הוא שבריר אחוז, ו-5% הם כבר הפרש ממשי.
            #
            # **05/10 - האבחון שהיה כאן היה שגוי, וזה תועד כדי שלא
            # יחזור.** הכתוב כאן קודם תלה את הפער הדק של מאיה (1.066
            # מול 1.313 אצל לוקאס) ב"מסת השיער הארוך". פירוק המדד
            # למרכיביו הראה אחרת: האיבר הדומיננטי הוא **רוויה**
            # (0.45-0.47) ולא ניגודיות מקומית (0.02-0.04), ושיער
            # מאיה הוא חום ברוויה 0.571 בעוד שיער לוקאס אפרפר
            # ברוויה 0.037. המסה הכפילה את ההשפעה בשטח, אבל הסיבה
            # היא הצבע. אבחון לפי מסה היה שולח לקצר את השיער -
            # לשנות זהות - בלי לגעת בסיבה.
            # התיקון: `pipeline.focal_recession`. אחרי: מאיה 1.194,
            # והשיער ירד ממקום שני למקום רביעי בדירוג.
            # ועמידות הפער נאכפת ב-`hierarchy_robustness`.
            "limit": "הפנים ראשונות ובפער >=1.05",
            "ok": bool(order[:1] == ["face"] and lead >= 1.05)}


HAIR_STRESS = {
    "רוויה +45%": lambda c: _sat_mul(c, 1.45),
    "רוויה +80%": lambda c: _sat_mul(c, 1.80),
    "בהיר פי 1.6": lambda c: np.clip(c * 1.6, 0.0, 1.0),
    "כהה פי 0.6": lambda c: c * 0.6,
}


def _sat_mul(c: np.ndarray, k: float) -> np.ndarray:
    """מגביר רוויה סביב האפור של כל קודקוד, בלי לשנות בהירות."""
    lum = (0.2126 * c[:, 0:1] + 0.7152 * c[:, 1:2] + 0.0722 * c[:, 2:3])
    return np.clip(lum + (c - lum) * k, 0.0, 1.0)


def hierarchy_robustness(ch: Char, cond=None, floor: float = 1.05) -> dict:
    """האם יתרון הפנים שורד **שינוי תסרוקת**.

    זו הדרישה שנולדה מהערה של המשתמש, והיא הדרישה הנכונה: מדד
    שעובר בדמות אחת ביום אחד אינו מגן על כלום, כי התסרוקת היא
    בדיוק מה שמשנים. עד התיקון של 05/10 הפער של מאיה היה 1.066
    מול סף של 1.05 - שישית אחוז - כלומר **כל** שינוי בשיער היה
    מפיל אותו, ואיש לא היה יודע עד שמישהו היה מסתכל בתמונה.

    המבחן מריץ את אותו `visual_hierarchy` על ארבע וריאציות של צבע
    השיער (רוויה למעלה פי 1.45 ופי 1.8, בהיר פי 1.6, כהה פי 0.6)
    ודורש שהפנים יישארו ראשונות בכולן. **וריאציות של צבע ולא של
    גאומטריה** מסיבה שנמדדה: האיבר הדומיננטי במדד הוא רוויה, לא
    ניגודיות מקומית, ולכן שינוי צבע הוא הלחץ החזק ביותר שאפשר
    להפעיל - הוא תוקף בדיוק את הערוץ שהכשיל כאן קודם.
    """
    out = {"base": visual_hierarchy(ch, cond)}
    hair = ch.mask_of("hair")
    orig = ch.color.copy()
    worst, worst_name = out["base"]["face_lead"], "בלי שינוי"
    out["variants"] = {}
    try:
        for name, fn in HAIR_STRESS.items():
            c = orig.copy()
            c[hair] = fn(orig[hair])
            ch.color = c
            r = visual_hierarchy(ch, cond)
            out["variants"][name] = {"face_lead": r["face_lead"],
                                     "order": r["order"], "ok": r["ok"]}
            if r["face_lead"] < worst:
                worst, worst_name = r["face_lead"], name
    finally:
        ch.color = orig
    out["worst"] = round(float(worst), 3)
    out["worst_variant"] = worst_name
    out["limit"] = f"הפנים ראשונות ובפער >={floor} בכל הווריאציות"
    out["ok"] = bool(all(v["ok"] for v in out["variants"].values())
                     and worst >= floor)
    return out


# ================================== 7 · הרמוניית צבע (color harmony)

def rgb_to_hsv(rgb) -> tuple[float, float, float]:
    r, g, b = (float(x) for x in rgb[:3])
    mx, mn = max(r, g, b), min(r, g, b)
    d = mx - mn
    if d < 1e-9:
        hh = 0.0
    elif mx == r:
        hh = (60.0 * ((g - b) / d)) % 360.0
    elif mx == g:
        hh = 60.0 * ((b - r) / d) + 120.0
    else:
        hh = 60.0 * ((r - g) / d) + 240.0
    return hh, (d / mx if mx > 1e-9 else 0.0), mx


#: הסכמות שעיצוב דמות באמת משתמש בהן, כמרווחי גוון מהגוון הראשי.
SCHEMES = {
    "monochrome": [0.0],
    "analogous": [0.0, 30.0, -30.0],
    "complementary": [0.0, 180.0],
    "split_complementary": [0.0, 150.0, -150.0],
    "triad": [0.0, 120.0, -120.0],
}
#: הצבעים שנחשבים "העיצוב". גלגל העין והשן אינם בחירה אמנותית.
DESIGN_KEYS = ("skin", "hair", "shirt", "pants", "shoe", "lip", "iris",
               "brow")


def _hue_err(hues, weights, base, offsets):
    err = 0.0
    for hu, wt in zip(hues, weights):
        d = min(abs(((hu - (base + o) + 180.0) % 360.0) - 180.0)
                for o in offsets)
        err += wt * d
    return err / max(1e-6, sum(weights))


def color_harmony(ch: Char) -> dict:
    """איזו סכמת גוונים הלוח הזה, כמה הוא רחוק ממנה, ומה פריסת
    הבהירויות.

    הרמוניה היא *לא* "צבעים נעימים" - היא יחסי גוון מדידים. ולצידה
    נמדדים שני דברים שבלעדיהם דמות לא קוראת: פריסת בהירות (אחרת הכול
    נמרח לגוש אחד) ומשמעת רוויה (אחרת כל אזור צועק).
    """
    pal = {k: v for k, v in ch.palette.items() if k in DESIGN_KEYS}
    hsv = {k: rgb_to_hsv(v) for k, v in pal.items()}
    # משקל לפי השטח שהצבע תופס בפועל - גוון של שפה אינו שווה בחשיבותו
    # לגוון של חולצה.
    area = {}
    tagmap = {"skin": ("skin", "ear"), "hair": ("hair",), "lip": ("lip_up",
              "lip_lo", "lip_line"), "iris": ("iris",), "brow": ("brow",),
              "shirt": ("shirt",), "pants": ("pants",), "shoe": ("shoe",)}
    n = float(len(ch.tag))
    for k in pal:
        tags = tagmap.get(k, (k,))
        area[k] = max(0.004, float(ch.mask_of(*tags).sum()) / n)
    keys = sorted(pal)
    hues = [hsv[k][0] for k in keys]
    wts = [area[k] * hsv[k][1] + 1e-3 for k in keys]     # גוון אפור לא נחשב
    best = (1e9, "", 0.0)
    for sname, offs in SCHEMES.items():
        for base in range(0, 360, 5):
            e = _hue_err(hues, wts, float(base), offs)
            if e < best[0]:
                best = (e, sname, float(base))
    vals = [hsv[k][2] for k in keys]
    sats = [hsv[k][1] for k in keys]
    skin_v = hsv.get("skin", (0, 0, 0.5))[2]
    shirt_v = hsv.get("shirt", (0, 0, 0.5))[2]
    hair_v = hsv.get("hair", (0, 0, 0.2))[2]
    return {
        "palette": {k: [round(x, 3) for x in hsv[k]] for k in keys},
        "scheme": best[1], "scheme_base_hue": best[2],
        "scheme_error_deg": round(best[0], 2),
        "value_spread": round(max(vals) - min(vals), 3),
        "saturation_max": round(max(sats), 3),
        "loud_colors": sum(1 for s in sats if s > 0.72),
        "skin_shirt_contrast": round(abs(skin_v - shirt_v), 3),
        "skin_hair_contrast": round(abs(skin_v - hair_v), 3),
        # הספים: שגיאת גוון עד 26° היא סכמה מזוהה (מרווחי הסכמות
        # עצמן הם 30° ומעלה); פריסת בהירות 0.35 היא מה שמפריד שיער
        # מעור בצילום שחור-לבן; יותר משני צבעים רועשים = אין היררכיה.
        "ok": bool(best[0] <= 26.0
                   and (max(vals) - min(vals)) >= 0.35
                   and sum(1 for s in sats if s > 0.72) <= 2
                   and abs(skin_v - hair_v) >= 0.18),
    }


# ======================================== 8 · זיהוי (recognizability)

def _hu(mask: np.ndarray) -> np.ndarray:
    """שבעת מומנטי Hu של הצללית - חסינים להזזה, לסקאלה ולסיבוב במישור.
    הם מה שמאפשר להשוות תקריב לשוט רחב בכלל."""
    ys, xs = np.nonzero(mask)
    if len(xs) < 10:
        return np.zeros(7)
    x = xs - xs.mean()
    y = ys - ys.mean()
    m00 = float(len(xs))

    def mu(p, q):
        return float((x ** p * y ** q).sum())

    def nu(p, q):
        return mu(p, q) / (m00 ** (1.0 + (p + q) / 2.0))

    n20, n02, n11 = nu(2, 0), nu(0, 2), nu(1, 1)
    n30, n03, n21, n12 = nu(3, 0), nu(0, 3), nu(2, 1), nu(1, 2)
    h = np.zeros(7)
    h[0] = n20 + n02
    h[1] = (n20 - n02) ** 2 + 4 * n11 ** 2
    h[2] = (n30 - 3 * n12) ** 2 + (3 * n21 - n03) ** 2
    h[3] = (n30 + n12) ** 2 + (n21 + n03) ** 2
    h[4] = ((n30 - 3 * n12) * (n30 + n12)
            * ((n30 + n12) ** 2 - 3 * (n21 + n03) ** 2)
            + (3 * n21 - n03) * (n21 + n03)
            * (3 * (n30 + n12) ** 2 - (n21 + n03) ** 2))
    h[5] = ((n20 - n02) * ((n30 + n12) ** 2 - (n21 + n03) ** 2)
            + 4 * n11 * (n30 + n12) * (n21 + n03))
    h[6] = ((3 * n21 - n03) * (n30 + n12)
            * ((n30 + n12) ** 2 - 3 * (n21 + n03) ** 2)
            - (n30 - 3 * n12) * (n21 + n03)
            * (3 * (n30 + n12) ** 2 - (n21 + n03) ** 2))
    # לוג-סקאלה: המומנטים פורשים כמה סדרי גודל, ובלי זה h[0] לבדו
    # קובע כל מרחק.
    return np.sign(h) * np.log10(np.abs(h) + 1e-30)


def _norm_mask(m: np.ndarray, s: int = 64) -> np.ndarray:
    ys, xs = np.nonzero(m)
    if not len(xs):
        return np.zeros((s, s), bool)
    sub = m[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
    yi = np.linspace(0, sub.shape[0] - 1, s).astype(int)
    xi = np.linspace(0, sub.shape[1] - 1, s).astype(int)
    return sub[np.ix_(yi, xi)]


def signature(ch: Char, cond, pose=None, w: int = 220, h: int = 300,
              kind: str = "head"):
    """חתימת זהות **מהתמונה**, מנורמלת לאיבר שמופיע בכל השוטים.

    הגרסה הראשונה כאן מדדה את חתימת הגוף **המלא** בכל תשעת התנאים,
    והחזירה שולי זיהוי 1.01 - כלומר "הדמות לא מזוהה". זה היה נכון
    ומוטעה בעת ובעונה אחת: בתקריב פשוט **אין גוף בפריים**, ולכן
    הושוו שם מומנטים של ראש מול מומנטים של אדם שלם. חתימה חייבת
    להימדד על אותו תוכן.

    לכן יש שתי חתימות:

    * `head` - נמדדת על אזור הראש בלבד ומנורמלת לגודל הראש בפריים.
      היא קיימת בכל תשעת התנאים, וזו גם התשובה האמיתית לשאלה "האם
      מזהים את הדמות": אדם מזוהה לפי הפנים.
    * `body` - נמדדת רק בשוטים שבהם הדמות **כולה** בפריים, ומנורמלת
      לגובה שלה. היא זו שתופסת גוף שהשתנה.

    שתיהן על פיקסלים ולא על גאומטריה: `identity` כבר מוכיח שהגאומטריה
    אפס-סחיפה מעצם הבנייה, והשאלה כאן אחרת לגמרי.
    """
    p = shot_params(ch.height, cond)
    pos = ch.attrs["position"]
    surf = ch.surface(pose)
    px, dz = project(surf, p["yaw"], p["pitch"], p["dist"], p["cy"],
                     p["fov"], w, h)
    vpx, vdz = px[:len(pos)], dz[:len(pos)]
    vis = vdz > 0
    inside = (vpx[:, 0] > 0) & (vpx[:, 0] < w) & \
             (vpx[:, 1] > 0) & (vpx[:, 1] < h)
    bwld = identity.bone_world(ch.skel)
    neck = float(bwld["neck"][1])
    headv = ch.mask_of("skin", "hair", "ear", "sclera", "iris", "pupil",
                       "brow", "lash", "lip_up", "lip_lo", "lip_line",
                       "blush") & (pos[:, 1] > neck)
    feetv = ch.group_mask("foot_L", "foot_R")

    if kind == "body":
        hv, fv = headv & vis, feetv & vis
        # "הגוף כולו בפריים" = הראש **וגם** כפות הרגליים בתוך הגבולות.
        # בלי התנאי הזה חתימת גוף נמדדה גם בתקריב, שבו אין גוף בכלל,
        # ושולי הזיהוי יצאו 1.01 - "הדמות לא מזוהה" על דמות תקינה.
        if not (hv.any() and fv.any()
                and bool(inside[hv].all()) and bool(inside[fv].all())):
            return None
        m = raster(px[dz > 0], w, h)
        if not m.any():
            return None
        ys, xs = np.nonzero(m)
        bh = float(ys.max() - ys.min() + 1)
        bw = float(xs.max() - xs.min() + 1)
        hm = headv & vis
        hh = float(vpx[hm, 1].max() - vpx[hm, 1].min()) if hm.any() else 0.0
        feats = [*(_hu(_norm_mask(m)) * 0.30), bh / max(1.0, bw),
                 hh / max(1.0, bh)]
    else:
        hm = headv & vis
        if hm.sum() < 50:
            return None
        hpx = vpx[hm]
        hw = float(hpx[:, 0].max() - hpx[:, 0].min())
        hh = float(hpx[:, 1].max() - hpx[:, 1].min())
        if hw < 6 or hh < 6:
            return None
        m = raster(hpx, w, h, close=1)
        feats = [*(_hu(_norm_mask(m)) * 0.30), hh / max(1.0, hw)]
        for tags in (("sclera", "iris"), ("lip_up", "lip_lo"), ("brow",),
                     ("hair",)):
            mm = ch.mask_of(*tags) & vis
            if mm.any():
                feats.append(float(vpx[mm, 0].max() - vpx[mm, 0].min())
                             / max(1.0, hw))
                feats.append(float(mm.sum()) / max(1.0, float(hm.sum())))
            else:
                feats.extend([0.0, 0.0])
    for tags in (("skin",), ("hair",), ("shirt",), ("iris",), ("lip_up",)):
        mm = ch.mask_of(*tags) & vis
        if mm.any():
            c = ch.color[mm].mean(axis=0)
            feats.extend([float(c[0]), float(c[1]), float(c[2])])
        else:
            feats.extend([0.0, 0.0, 0.0])
    return np.asarray(feats, float)


def _margin(sigs: dict[str, dict]) -> dict:
    drift = {}
    sigs = {k: v for k, v in sigs.items() if v}
    if len(sigs) < 2:
        return {"drift": {}, "separation": {}, "worst_drift": 0.0,
                "min_separation": 0.0, "margin": 0.0,
                "note": "אין מספיק שוטים שבהם האיבר הזה בפריים"}
    for nm, per in sigs.items():
        v = np.stack(list(per.values()))
        med = np.median(v, axis=0)
        sc = np.maximum(np.abs(med), 0.05)
        d = {k: float(np.abs((s - med) / sc).mean())
             for k, s in per.items()}
        drift[nm] = {"per_shot": {k: round(x, 4) for k, x in d.items()},
                     "max": round(max(d.values()), 4),
                     "worst_shot": max(d, key=d.get)}
    sep = {}
    names = sorted(sigs)
    for i, a in enumerate(names):
        for b in names[i + 1:]:
            common = sorted(set(sigs[a]) & set(sigs[b]))
            vals = []
            for k in common:
                med = np.median(np.stack([sigs[a][k], sigs[b][k]]), axis=0)
                sc = np.maximum(np.abs(med), 0.05)
                vals.append(float(np.abs((sigs[a][k] - sigs[b][k]) / sc).mean()))
            sep[f"{a}|{b}"] = round(float(np.mean(vals)), 4) if vals else 0.0
    worst_drift = max((d["max"] for d in drift.values()), default=0.0)
    min_sep = min(sep.values()) if sep else 0.0
    margin = min_sep / max(1e-6, worst_drift)
    return {"drift": drift, "separation": sep,
            "worst_drift": round(worst_drift, 4),
            "min_separation": round(min_sep, 4),
            "margin": round(margin, 3)}


def recognizability(chars: list[Char], conds=None) -> dict:
    """סחיפת הזהות בין תנאי הרנדור, מול ההפרדה בין הדמויות.

    הקריטריון הוא **שולי הזיהוי**: ההפרדה בין שתי הדמויות חלקי הסחיפה
    הגדולה ביותר של דמות אחת בין התנאים. שוליים מעל 1.6 פירושם שהדמות
    דומה לעצמה בזווית אחרת יותר משהיא דומה לדמות השנייה, בפער ממשי -
    וזו ההגדרה המדידה של "נשארת מזוהה". בלי המכנה הזה גם שתי דמויות
    זהות היו עוברות.
    """
    conds = conds or CONDITIONS
    out = {}
    for kind in ("head", "body"):
        sigs: dict[str, dict] = {}
        for ch in chars:
            sigs[ch.name] = {}
            for cond in conds:
                s = signature(ch, cond, kind=kind)
                if s is not None:
                    sigs[ch.name][cond[0]] = s
        out[kind] = _margin(sigs)
        out[kind]["shots"] = sorted(set().union(*[set(v) for v in
                                                  sigs.values()])) \
            if sigs else []
    worst = min(out[k]["margin"] for k in out)
    return {**out, "margin": round(worst, 3), "limit": 1.6,
            "ok": bool(worst >= 1.6)}


# ============================ 9 · קריאות רגשית (emotional readability)

#: הרגשות שחייבים להיות מובחנים זה מזה. נבחרו מתוך `acting.EXPRESSIONS`
#: דווקא כזוגות שקל לבלבל ביניהם - חיוך מנומס מול שעשוע, חשד מול ספק.
EMOTIONS = ("surprise", "suspicion", "sadness", "amusement",
            "polite_smile", "doubt", "concentration", "discomfort")


def emotional_readability(ch: Char, emotions=None, shot=1,
                          w: int = WIDTH, h: int = HEIGHT) -> dict:
    """האם כל רגש נראה *אחר* - גם אחרי שהוא מצטמק לגודל של שוט בינוני.

    המדידה: שדה התזוזה של הפנים בשיא כל ביטוי (עצמות **וגם** צורות),
    מוקרן לפיקסלים של השוט, ומוחלק לרזולוציה שלו. אחר כך נמדד המרחק
    בין כל זוג רגשות ביחידות של **הרעש** - התזוזה של הרגש החלש ביותר.
    זוג שהמרחק בינו קטן מהרעש הוא שני רגשות שנראים אותו דבר, ואין שום
    טעם להנפיש אותם בנפרד.
    """
    emotions = [e for e in (emotions or EMOTIONS) if e in acting.EXPRESSIONS]
    mo = ch.morphs()
    deltas = mo["deltas"]
    names = mo["names"]
    idx = {n: i for i, n in enumerate(names)}
    pos = ch.attrs["position"]
    bwld = identity.bone_world(ch.skel)
    facem = (pos[:, 1] > float(bwld["jaw_tip"][1]) - 0.03)
    p = shot_params(ch.height, CONDITIONS[shot])
    base_px, dz = project(pos, p["yaw"], p["pitch"], p["dist"], p["cy"],
                          p["fov"], w, h)
    sel = facem & (dz > 0)
    fields = {}
    for e in emotions:
        ctl, mph = acting.pose_of(e)
        q = controls.evaluate(ch.skel, ctl, {})
        moved = identity.skin(ch.skel, ch.attrs, q).copy()
        for k, v in (mph or {}).items():
            if k in idx and abs(v) > 1e-6:
                moved += deltas[idx[k]] * float(v)
        npx, _ = project(moved, p["yaw"], p["pitch"], p["dist"], p["cy"],
                         p["fov"], w, h)
        fields[e] = (npx - base_px)[sel]
    mags = {e: float(np.linalg.norm(v, axis=1).mean())
            for e, v in fields.items()}
    noise = min(mags.values()) if mags else 0.0
    pairs = {}
    for i, a in enumerate(emotions):
        for b in emotions[i + 1:]:
            d = float(np.linalg.norm(fields[a] - fields[b], axis=1).mean())
            pairs[f"{a}|{b}"] = round(d, 4)
    worst = min(pairs.values()) if pairs else 0.0
    # 0.45 מהרעש: מתחת לזה שני הביטויים מזיזים את אותם פיקסלים באותו
    # כיוון, כלומר הם אותה הבעה בעוצמה אחרת.
    ratio = worst / max(1e-6, noise)
    return {"shot": p["name"], "emotions": list(emotions),
            "mean_px": {k: round(v, 3) for k, v in mags.items()},
            "closest_pair": min(pairs, key=pairs.get) if pairs else "",
            "closest_px": round(worst, 4),
            "noise_px": round(noise, 4), "ratio": round(ratio, 3),
            "limit": 0.45, "pairs": pairs,
            "ok": bool(ratio >= 0.45)}


# ============================================================ המנהל

def evaluate(chars: list[Char], conds=None) -> dict:
    """הערכת תשע האיכויות, בלי דפדפן. זה מה שרץ בבדיקות היחידה."""
    conds = conds or CONDITIONS
    t0 = time.time()
    per: dict[str, dict] = {}
    sil_masks: dict[str, dict] = {}
    for ch in chars:
        lib = controls.pose_library(ch.skel)
        # הצללית נמדדת על **פוזת משחק** ולא על פוזת מנוחה. בפוזת מנוחה
        # הזרועות צמודות לגוף, הידיים נבלעות בצללית, וספירת הקצוות
        # מחזירה 2 - כלומר נמדד שם המסגור ולא העיצוב. צללית היא תמיד
        # צללית של פוזה.
        pname = next((k for k in ("gesture_open", "reach_up", "point")
                      if k in lib), sorted(lib)[0])
        qs = controls.evaluate(ch.skel, *lib[pname])
        sils = {}
        for cond in conds:
            s = silhouette(ch, cond, pose=qs)
            sils[cond[0]] = s
        sil_masks[ch.name] = sils
        q = qs
        _, mph = acting.pose_of("suspicion")
        per[ch.name] = {
            "silhouette": {k: {kk: vv for kk, vv in v.items() if kk != "mask"}
                           for k, v in sils.items()},
            "proportions": proportions(ch),
            "facial_readability": facial_readability(ch, conds),
            "shape_language": shape_language(ch),
            "asymmetry": asymmetry(ch, q, mph),
            "visual_hierarchy": visual_hierarchy(ch),
            "hierarchy_robustness": hierarchy_robustness(ch),
            "color_harmony": color_harmony(ch),
            "emotional_readability": emotional_readability(ch),
        }
    rec = recognizability(chars, conds)
    pairs = {}
    names = [c.name for c in chars]
    for i, a in enumerate(names):
        for b in names[i + 1:]:
            for cond in conds:
                k = cond[0]
                pairs[f"{a}|{b}|{k}"] = silhouette_distinctness(
                    sil_masks[a][k], sil_masks[b][k])
    # מובחנות הצללית: ממוצע על כל התנאים, **ובנפרד** התקריב.
    # למה לא מינימום: פרופיל של שני אנשים דקים באותה פוזה אינו יכול
    # להיות שונה בלי לשנות מין יצור - נמדד 0.115 שם מול 0.362 בתקריב,
    # ושני המספרים נכונים. מה שבאמת צריך להיות מובחן הוא מה שהעיצוב
    # שולט בו: ראש, תסרוקת, מבנה - וזה מה שנראה בתקריב ובממוצע.
    vals = list(pairs.values())
    sil_mean = float(np.mean(vals)) if vals else 0.0
    cu = [v for k, v in pairs.items() if k.endswith("|close_up")]
    sil_cu = float(np.mean(cu)) if cu else 0.0

    # --- הציון לכל איכות, כקריטריון מעבר מדיד
    checks = {}
    for nm, r in per.items():
        sol = [v["solidity"] for v in r["silhouette"].values()]
        # ספירת הקצוות תלויה **בסוג השוט**, וזו לא פשרה אלא גאומטריה:
        # בפרופיל יד אחת מסתירה את השנייה ורגל אחת את השנייה, ובתקריב
        # פשוט אין גוף בפריים. נמדד: 4 קצוות בכל שבעת השוטים הפתוחים,
        # 3 בתקריב, 2 בפרופיל. דרישת "4 בכל שוט" הייתה פוסלת צללית
        # תקינה לגמרי בגלל הזווית שבה צולמה.
        OPEN = [k for k in r["silhouette"]
                if k not in ("close_up", "side_profile")]
        ext_open = [r["silhouette"][k]["extremities"] for k in OPEN]
        ext_all = [v["extremities"] for v in r["silhouette"].values()]
        checks[f"{nm}/silhouette_readable"] = (
            f"קמירות {min(sol):.2f}-{max(sol):.2f}, קצוות "
            f"{min(ext_open)} בשוט פתוח / {min(ext_all)} בכל שוט",
            "0.30<=קמירות<=0.92, קצוות>=4 בשוט פתוח ו->=2 בכולם",
            all(0.30 <= s <= 0.92 for s in sol)
            and min(ext_open) >= 4 and min(ext_all) >= 2)
        checks[f"{nm}/proportions"] = (
            f"{r['proportions']['in_window']}/{r['proportions']['of']} בחלון",
            "הכול בחלון", r["proportions"]["in_window"]
            == r["proportions"]["of"])
        checks[f"{nm}/facial_readability"] = (
            f"{r['facial_readability']['min_feature_px']} פיקסלים "
            f"({r['facial_readability']['worst_shot']})",
            f">={MIN_FEATURE_PX}",
            r["facial_readability"]["readable_in_all_shots"])
        checks[f"{nm}/shape_language"] = (
            f"{r['shape_language']['dominant']} "
            f"{r['shape_language']['dominant_share']:.0%}, "
            f"{len(r['shape_language']['families'])} משפחות",
            "דומיננטיות>=45% וניגוד",
            r["shape_language"]["has_language"]
            and r["shape_language"]["has_contrast"])
        checks[f"{nm}/asymmetry"] = (
            r["asymmetry"]["score"], f"{ASYM_WINDOW}",
            r["asymmetry"]["in_window"])
        checks[f"{nm}/visual_hierarchy"] = (
            f"{'>'.join(r['visual_hierarchy'].get('order', []))} "
            f"(פער {r['visual_hierarchy'].get('face_lead')})",
            r["visual_hierarchy"].get("limit"),
            r["visual_hierarchy"]["ok"])
        rb = r["hierarchy_robustness"]
        checks[f"{nm}/hierarchy_survives_hair"] = (
            f"הגרוע ביותר {rb['worst']} ב«{rb['worst_variant']}» "
            f"(מתוך {len(rb['variants'])} וריאציות שיער)",
            rb["limit"], rb["ok"])
        checks[f"{nm}/color_harmony"] = (
            f"{r['color_harmony']['scheme']} "
            f"±{r['color_harmony']['scheme_error_deg']}°, פריסה "
            f"{r['color_harmony']['value_spread']}",
            "סכמה מזוהה + פריסה", r["color_harmony"]["ok"])
        checks[f"{nm}/emotional_readability"] = (
            f"{r['emotional_readability']['ratio']} "
            f"({r['emotional_readability']['closest_pair']})",
            ">=0.45", r["emotional_readability"]["ok"])
    checks["cast/recognizability_margin"] = (
        rec["margin"], ">=2.0", rec["ok"])
    checks["cast/silhouette_distinct"] = (
        f"ממוצע {sil_mean:.3f}, תקריב {sil_cu:.3f}",
        "ממוצע>=0.15 ותקריב>=0.25",
        sil_mean >= 0.15 and sil_cu >= 0.25)

    return {
        "task": "TASK 09 - מנהל קסם הדמות",
        "when": time.strftime("%Y-%m-%d %H:%M:%S"),
        "conditions": [c[0] for c in conds],
        "characters": per,
        "recognizability": rec,
        "silhouette_distinctness": {k: v for k, v in pairs.items()},
        "checks": {k: {"value": v[0], "limit": v[1], "pass": bool(v[2])}
                   for k, v in checks.items()},
        "passed": all(v[2] for v in checks.values()),
        "seconds": round(time.time() - t0, 2),
    }


# ======================================================= רנדור אמיתי

def _serve(root: Path):
    h = functools.partial(http.server.SimpleHTTPRequestHandler,
                          directory=str(root))
    srv = socketserver.ThreadingTCPServer(("127.0.0.1", 0), h)
    srv.daemon_threads = True
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, srv.server_address[1]


def _stage(glb: Path) -> Path:
    d = Path(tempfile.mkdtemp(prefix="appeal_"))
    shutil.copytree(STUDIO / "lib", d / "lib")
    shutil.copytree(STUDIO / "utils", d / "utils")
    shutil.copy2(HERE / "viewer.html", d / "viewer.html")
    shutil.copy2(glb, d / "char.glb")
    return d


async def render_conditions(ch: Char, out_dir: Path, rig_dir: Path = RIG_DIR,
                            conds=None, w: int = WIDTH, h: int = HEIGHT):
    """מרנדר את הדמות בכל תשעת התנאים ומודד **על הפיקסלים**.

    שתי מדידות שרק כאן אפשר לעשות אותן:
      * `alpha_bbox` - תיבת הדמות בתמונה. היא נבדקת מול ההיטל שחושב
        בפייתון, וזו הראיה שכל "בן כמה פיקסלים התו" כאן אינו פיקציה.
      * `lighting_drift` - האם הדמות נראית אותה דמות כששתי התאורות
        מתחלפות. זו הדרישה המפורשת של המשימה, ואי אפשר לענות עליה
        בגאומטריה.
    """
    import engine                                       # noqa: PLC0415
    conds = conds or CONDITIONS
    out_dir.mkdir(parents=True, exist_ok=True)
    stage = _stage(rig_dir / ch.rig["glb"])
    srv, port = _serve(stage)
    br = engine.Browser(w + 40, h + 60)
    rows, info = {}, {}
    try:
        await br.start()
        url = f"http://127.0.0.1:{port}/viewer.html?w={w}&h={h}&glb=char.glb"
        await br.cmd("Page.navigate", {"url": url})
        for _ in range(400):
            if await br.js("!!window.__ready"):
                break
            await asyncio.sleep(0.1)
        err = await br.js("window.__err ? window.__err() : 'הצופה לא נטען'")
        if err:
            raise RuntimeError(f"הצופה החזיר שגיאה: {err}")
        info = json.loads(await br.js("JSON.stringify(window.__info||null)")
                          or "null") or {}
        if int(info.get("skeletonBones", 0)) != int(ch.rig["mesh"]["bones"]):
            raise RuntimeError(
                f"ב-GLB {info.get('skeletonBones')} עצמות ובריג "
                f"{ch.rig['mesh']['bones']} - הנכס והקוד אינם מסונכרנים.")
        await br.js("window.__pose('{}')")
        for cond in conds:
            p = shot_params(ch.height, cond)
            got = await br.js(f"window.__light({json.dumps(p['light'])})")
            if got != p["light"]:
                raise RuntimeError(f"אין מצב תאורה {p['light']} בצופה")
            d = await br.js(f"window.__shot({p['yaw']},{p['pitch']},"
                            f"{p['dist']},{p['cy']},{p['fov']})")
            if not isinstance(d, str) or not d.startswith("data:image"):
                raise RuntimeError(f"רנדור נכשל: {p['name']}")
            png = base64.b64decode(d.split(",", 1)[1])
            path = out_dir / f"{ch.name}__{p['name']}.png"
            path.write_bytes(png)
            sig = identity.image_signature(png)
            # ההיטל שחושב בפייתון, על אותם פרמטרים בדיוק
            px, dz = project(ch.surface(), p["yaw"], p["pitch"],
                             p["dist"], p["cy"], p["fov"], w, h)
            # **חייב להיות חתוך למסגרת.** הרנדור לא יכול לצייר מחוץ
            # לקנבס, ולכן תיבת האלפא שלו חתומה ב-(0,0,w,h); היטל
            # פייתון בלי חיתוך החזיר הפרש של 2396 פיקסלים בתקריב,
            # פשוט כי שם רוב הגוף מחוץ לפריים.
            vis = ((dz > 0) & (px[:, 0] >= 0) & (px[:, 0] <= w - 1)
                   & (px[:, 1] >= 0) & (px[:, 1] <= h - 1))
            pb = ([float(px[vis, 0].min()), float(px[vis, 1].min()),
                   float(px[vis, 0].max()), float(px[vis, 1].max())]
                  if vis.any() else None)
            rows[p["name"]] = {
                "png": str(path), "light": p["light"],
                "coverage": sig["coverage"], "alpha_bbox": sig["bbox"],
                "python_bbox": [round(v, 1) for v in pb] if pb else None,
                "color": [round(v, 1) for v in sig["color"]],
            }
    finally:
        await br.close()
        srv.shutdown()
        shutil.rmtree(stage, ignore_errors=True)
    # הסכמה בין ההיטל של פייתון לתיבת האלפא של WebGL
    errs = []
    for r in rows.values():
        bb, pb = r["alpha_bbox"], r["python_bbox"]
        if not bb or not pb:
            continue
        # **צלע שנחתכה בשפת הפריים אינה מודדת כלום.** כשהדמות חורגת
        # מהקנבס, תיבת האלפא שלה נעצרת ב-0 (או ב-w-1) בלי קשר לאיפה
        # היא באמת נגמרת, בעוד היטל פייתון מדווח את הנקודה הפנימית
        # הראשונה שנדגמה. נמדד: בכל שבעת השוטים שבהם הדמות שלמה
        # בפריים ההסכמה היא 0.3-3.3 פיקסלים, וכל "שגיאה" גדולה יושבת
        # דווקא על צלע חתוכה - כלומר על השוואה חסרת מובן.
        lim = (0, 0, w - 1, h - 1)
        diffs = [abs(bb[i] - pb[i]) for i in range(4)
                 if bb[i] != lim[i]]
        if not diffs:
            continue
        e = max(diffs)
        r["bbox_err_px"] = round(e, 1)
        r["edges_compared"] = len(diffs)
        errs.append(e)
    # סחיפת צבע בין התאורות, כאחוז
    lit = [r for k, r in rows.items() if k.startswith("light_")]
    base = rows.get("medium")
    ldrift = 0.0
    if base and lit:
        b = np.asarray(base["color"], float)
        ldrift = max(float(np.abs(np.asarray(r["color"], float) - b).max())
                     for r in lit) / 255.0
    return {"character": ch.name, "viewer": info, "renders": rows,
            "projection_err_px": round(max(errs), 1) if errs else None,
            "lighting_color_drift": round(ldrift, 4)}


def contact_sheet(pngs, out_path, cols=3, cell=(300, 418), labels=()):
    from PIL import Image, ImageDraw
    cw, chh = cell
    pad, top = 6, 24
    rows = (len(pngs) + cols - 1) // cols
    W = cols * (cw + pad) + pad
    H = rows * (chh + pad + top) + pad
    sheet = Image.new("RGB", (W, H), (20, 23, 30))
    d = ImageDraw.Draw(sheet)
    for i, p in enumerate(pngs):
        r, c = divmod(i, cols)
        im = Image.open(p).convert("RGBA")
        im.thumbnail((cw, chh))
        bg = Image.new("RGBA", (cw, chh), (34, 38, 48, 255))
        bg.alpha_composite(im, ((cw - im.width) // 2, (chh - im.height) // 2))
        x = c * (cw + pad) + pad
        y = r * (chh + pad + top) + pad + top
        sheet.paste(bg.convert("RGB"), (x, y))
        if i < len(labels):
            d.text((x + 3, y - top + 5), str(labels[i]), fill=(228, 234, 246))
    sheet.save(out_path)
    return out_path


def main(argv=None):
    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(description="מנהל קסם הדמות (TASK 09)")
    ap.add_argument("--dir", default=str(RIG_DIR))
    ap.add_argument("--out", default=str(OUT_DIR))
    ap.add_argument("--names", default="lucas,maya")
    ap.add_argument("--render", action="store_true",
                    help="לרנדר בפועל את תשעת התנאים")
    a = ap.parse_args(argv)
    rig_dir, out = Path(a.dir), Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    chars = [Char(n, rig_dir) for n in a.names.split(",") if n]
    rep = evaluate(chars)

    if a.render:
        rep["render"] = {}
        for ch in chars:
            r = asyncio.run(render_conditions(ch, out / "shots", rig_dir))
            rep["render"][ch.name] = r
            sheet = contact_sheet([r["renders"][c[0]]["png"] for c in CONDITIONS
                                   if c[0] in r["renders"]],
                                  out / f"{ch.name}_appeal_sheet.png",
                                  labels=[c[0] for c in CONDITIONS])
            r["sheet"] = str(sheet)
            rep["checks"][f"{ch.name}/projection_matches_render"] = {
                "value": r["projection_err_px"], "limit": "<=6 פיקסלים",
                "pass": bool(r["projection_err_px"] is not None
                             and r["projection_err_px"] <= 6.0)}
            rep["checks"][f"{ch.name}/lighting_identity"] = {
                "value": r["lighting_color_drift"], "limit": "<=0.30",
                "pass": bool(r["lighting_color_drift"] <= 0.30)}
        rep["passed"] = all(v["pass"] for v in rep["checks"].values())

    (out / "appeal.json").write_text(
        json.dumps(rep, ensure_ascii=False, indent=1, default=str),
        encoding="utf-8")
    print(f"=== {rep['task']} · {', '.join(c.name for c in chars)} ===")
    for k, v in rep["checks"].items():
        print(f"  {'✓' if v['pass'] else '✗'} {k}: {v['value']} "
              f"(גבול {v['limit']})")
    print(f"\n{'עבר' if rep['passed'] else 'נכשל'} · {rep['seconds']}ש")
    print(f"דוח: {out / 'appeal.json'}")
    return 0 if rep["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
