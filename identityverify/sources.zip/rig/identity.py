# -*- coding: utf-8 -*-
"""מדידת זהות: האם זו אותה דמות אחרי שהיא זזה ואחרי שהמצלמה זזה.

למה לא השוואת היסטוגרמות צבע, כמו שתכננתי בהתחלה: שלושה יועצים
חיצוניים פסלו את זה מאותה סיבה, ובצדק - היסטוגרמה משתנה מהתאורה
ומזווית המצלמה גם כשהדמות זהה לחלוטין, ולכן היא מודדת רנדור ולא זהות.

מה שנמדד כאן במקום הוא **גאומטריה**: אוסף מדידות שחייבות להיות
חסינות לפוזה, כי הן יושבות בתוך אזור קשיח אחד או בין שתי עצמות
שהמרחק ביניהן קבוע מעצם הבנייה (סיבוב לא משנה אורך).

**תיקון הצהרה, 08/10/2026.** עד כאן נכתב כאן שדליפת משקולת (גלגל
העין שמקבל טיפת משקולת לסת) תזיז את המרחק בין העיניים ותיתפס.
שני יועצים חיצוניים (Qwen של Alibaba, Command A של Cohere) הצביעו
על כך שזה אינו נכון, ו**ההערה שליד** ``FACE_MEASURES`` כאן בקובץ
מאשרת אותם במפורש: המדידות נעשות על *מקורות העצמות*
(``bone_world``) ולא על קודקודי הרשת, ולכן משקולת שדולפת אל העור
אינה משנה אותן כלל. זו החלטה נכונה - קודקוד על פני גלגל העין זז
לגיטימית כשהעין מביטה הצידה - אבל היא גם אומרת שהמדד הזה אינו
המדד שמוצא דליפות.

מה כן מוצא דליפה, ומה עוד לא: ``weight_health`` תופס סכום שאינו 1,
משקולת שלילית ועצם בלי עור. ``rest_recovery_error`` תופס ריג מרוח
(נמדד במבחן שלילי ב-`test_rig`). מה שעדיין **אינו נמדד** הוא דליפה
*מקומית וקטנה* שמשאירה את הסכום 1 ואת שאר המדדים תקינים - למשל
קודקוד שפה שנשלט בטעות בידי עצם כתף. זו מגבלה מוצהרת ולא כיסוי,
והיא רשומה כ-``KNOWN_GAPS`` כדי שלא תיחשב בטעות כנמדדת.
"""
from __future__ import annotations

import numpy as np

from .skeleton import Skeleton


def skin(skel: Skeleton, attrs: dict, local_q: dict | None = None) -> np.ndarray:
    """Linear Blend Skinning בפייתון. מחזיר עמדות אחרי הפוזה."""
    W = skel.forward(local_q or {})
    M = skel.skin_matrices(W)                     # (B,4,4)
    pos = attrs["position"].astype(np.float64)
    si = attrs["skinIndex"].astype(np.int32)
    sw = attrs["skinWeight"].astype(np.float64)
    out = np.zeros_like(pos)
    ph = np.concatenate([pos, np.ones((pos.shape[0], 1))], axis=1)
    for k in range(si.shape[1]):
        mats = M[si[:, k]]                        # (N,4,4)
        p = np.einsum("nij,nj->ni", mats, ph)[:, :3]
        out += p * sw[:, k:k + 1]
    return out


# ------------------------------------------------------------ נקודות ציון


def landmarks(skel: Skeleton, attrs: dict) -> dict[str, int]:
    """הקודקוד הקרוב ביותר לכל עצם-ציון. זה הופך מדידות שלד למדידות
    על **העור** - וזה מה שבודק את העור ולא רק את השלד."""
    pos = attrs["position"].astype(np.float64)
    want = ["eye_L", "eye_R", "head_tip", "jaw_tip", "chest",
            "clavicle_L", "clavicle_R", "hand_L", "hand_R",
            "foot_L", "foot_R", "hips",
            "index_tip_L", "pinky_tip_L", "thumb_tip_L"]
    out = {}
    for name in want:
        b = skel.by_name.get(name)
        if b is None:
            continue
        d = np.linalg.norm(pos - np.asarray(b.rest), axis=1)
        out[name] = int(np.argmin(d))
    return out


# מדידות זהות שחייבות להיות **חסינות לפוזה**. נמדדות על מקורות
# העצמות ולא על קודקודים: קודקוד על פני גלגל העין זז כשהעין מביטה
# לצד, וזו תנועה נכונה - לא סחיפת זהות. המדידה הראשונה שכתבתי כאן
# מדדה בטעות מרחק בין קצות אצבעות, שמשתנה לגיטימית באגרוף, והחזירה
# "21% סחיפה" על דמות תקינה לחלוטין. המדד היה שבור, לא הדמות.
FACE_MEASURES = [
    ("interocular", "eye_L", "eye_R"),
    ("eye_to_crown_L", "eye_L", "head_tip"),
    ("eye_to_crown_R", "eye_R", "head_tip"),
    ("brow_span", "brow_out_L", "brow_out_R"),
    ("cheek_span", "cheek_L", "cheek_R"),
    ("shoulder_width", "clavicle_L", "clavicle_R"),
    ("hip_width", "thigh_L", "thigh_R"),
]


def bone_world(skel: Skeleton, local_q: dict | None = None) -> dict[str, np.ndarray]:
    W = skel.forward(local_q or {})
    return {b.name: W[b.index][:3, 3] for b in skel.bones}


def face_measures(skel: Skeleton, local_q: dict | None = None) -> dict[str, float]:
    bw = bone_world(skel, local_q)
    out = {}
    for name, a, b in FACE_MEASURES:
        if a in bw and b in bw:
            out[name] = float(np.linalg.norm(bw[a] - bw[b]))
    return out


def bone_lengths(skel: Skeleton, local_q: dict | None = None) -> dict[str, float]:
    """אורך כל פרק עצם. סיבוב לא משנה אורך, ולכן כל סטייה כאן היא
    שגיאה אמיתית בריג (מתיחה, קריסה, nan)."""
    bw = bone_world(skel, local_q)
    out = {}
    for b in skel.bones:
        if b.parent is None:
            continue
        out[f"{b.parent}->{b.name}"] = float(
            np.linalg.norm(bw[b.name] - bw[b.parent]))
    return out


def rigid_vertices(attrs: dict, min_weight: float = 0.995):
    """קודקודים ששייכים כמעט לגמרי לעצם אחת. עליהם אפשר לשחזר את פוזת
    המנוחה בדיוק, ולכן הם הוכחת הזהות: אם השחזור מדויק, הצורה לא זזה -
    רק הסיבובים."""
    sw = attrs["skinWeight"].astype(np.float64)
    si = attrs["skinIndex"].astype(np.int64)
    k = np.argmax(sw, axis=1)
    w = sw[np.arange(sw.shape[0]), k]
    bone = si[np.arange(si.shape[0]), k]
    sel = np.nonzero(w >= min_weight)[0]
    return sel, bone[sel]


def rest_recovery_error(skel: Skeleton, attrs: dict, local_q: dict | None,
                        sel=None, bones=None) -> dict:
    """מחזיר את פוזת המנוחה מתוך הפוזה, דרך היפוך מטריצת העור של העצם
    השולטת, ומשווה למקור. שגיאה גדולה = הזהות נמחקה בפוזה."""
    if sel is None:
        sel, bones = rigid_vertices(attrs)
    if len(sel) == 0:
        return {"max_mm": float("inf"), "mean_mm": float("inf"), "verts": 0}
    W = skel.forward(local_q or {})
    M = skel.skin_matrices(W)
    pos = attrs["position"].astype(np.float64)
    posed = skin(skel, attrs, local_q)
    err = np.zeros(len(sel))
    for b in np.unique(bones):
        idx = sel[bones == b]
        inv = np.linalg.inv(M[b])
        p = posed[idx]
        ph = np.concatenate([p, np.ones((p.shape[0], 1))], axis=1)
        rec = (inv @ ph.T).T[:, :3]
        err[bones == b] = np.linalg.norm(rec - pos[idx], axis=1)
    return {"max_mm": float(err.max() * 1000), "mean_mm": float(err.mean() * 1000),
            "verts": int(len(sel))}


def drift(samples: list[dict[str, float]]) -> dict:
    """סחיפה = הסטייה היחסית המרבית של כל מדידה בין כל הדגימות."""
    if not samples:
        return {"max_rel": 1.0, "per_measure": {}}
    keys = [k for k in samples[0] if all(k in s for s in samples)]
    per = {}
    for k in keys:
        vals = np.array([s[k] for s in samples], dtype=np.float64)
        base = float(np.median(vals))
        if base < 1e-9:
            continue
        per[k] = float(np.max(np.abs(vals - base)) / base)
    worst = max(per, key=per.get) if per else None
    return {"max_rel": max(per.values()) if per else 1.0,
            "worst": worst, "per_measure": per}


def pose_separation(skel: Skeleton, attrs: dict,
                    poses: dict[str, dict]) -> dict:
    """כמה הפוזות באמת שונות זו מזו, כאחוז מגובה הדמות.

    בלי המדד הזה "אפס סחיפת זהות" הוא חסר ערך: גם דמות שלא זזה בכלל
    תעבור. זה החלק שמונע מהבדיקה לרמות את עצמה.
    """
    keys = sorted(poses)
    pts = {k: skin(skel, attrs, poses[k]) for k in keys}
    pairs = {}
    for i, a in enumerate(keys):
        for b in keys[i + 1:]:
            d = np.linalg.norm(pts[a] - pts[b], axis=1)
            pairs[f"{a}|{b}"] = {
                "mean_pct": float(d.mean() / skel.height * 100),
                "max_pct": float(d.max() / skel.height * 100)}
    means = [v["mean_pct"] for v in pairs.values()]
    return {"min_mean_pct": float(min(means)) if means else 0.0,
            "max_max_pct": float(max(v["max_pct"] for v in pairs.values()))
            if pairs else 0.0,
            "pairs": pairs}


def identity_report(skel: Skeleton, attrs: dict,
                    poses: dict[str, dict]) -> dict:
    """הדוח המלא: שלד, עור, פנים, והפרדה בין הפוזות."""
    keys = sorted(poses)
    sel, bones = rigid_vertices(attrs)
    bl = [bone_lengths(skel, poses[k]) for k in keys]
    fm = [face_measures(skel, poses[k]) for k in keys]
    rec = {k: rest_recovery_error(skel, attrs, poses[k], sel, bones)
           for k in keys}
    bl_d = drift(bl)
    fm_d = drift(fm)
    worst_rec = max(v["max_mm"] for v in rec.values())
    sep = pose_separation(skel, attrs, poses)
    return {
        "bone_length_drift": bl_d,
        "face_measure_drift": fm_d,
        "rest_recovery": rec,
        "rest_recovery_worst_mm": worst_rec,
        "rigid_verts": int(len(sel)),
        "pose_separation": sep,
        "max_rel_drift": max(bl_d["max_rel"], fm_d["max_rel"]),
        # סף שחזור המנוחה: 0.5 מ"מ על דמות בגובה 1.70 מטר, כלומר 0.03%.
        # הנתונים נשמרים ב-float32 (כך דורש glTF), ולכן רעש של ~0.07
        # מ"מ הוא הדיוק של הייצוג עצמו ולא שגיאת ריג. סף של 0.01 מ"מ
        # נוסה כאן ונפל על דיוק מכונה בלבד, על דמות תקינה לחלוטין.
        "rest_recovery_limit_mm": 0.5,
        "pose_separation_limit_pct": 0.5,
        "passes": bool(bl_d["max_rel"] < 1e-6 and fm_d["max_rel"] < 1e-6
                       and worst_rec < 0.5 and sep["min_mean_pct"] > 0.5),
    }


# ------------------------------------------------------------ בדיקות עור


def weight_health(attrs: dict, skel: Skeleton) -> dict:
    """בריאות המשקולות - מה ששובר דמויות בפועל."""
    sw = attrs["skinWeight"].astype(np.float64)
    si = attrs["skinIndex"].astype(np.int64)
    sums = sw.sum(axis=1)
    name_of = {b.index: b.name for b in skel.bones}
    helper = {b.index for b in skel.bones if b.kind == "helper"}
    on_helper = float(np.mean(np.any(np.isin(si, list(helper)) & (sw > 0.02),
                                     axis=1))) if helper else 0.0
    used = set(np.unique(si[sw > 0.001]).tolist())
    unused = sorted(name_of[i] for i in range(len(skel.bones))
                    if i not in used and skel.bones[i].kind != "helper")
    return {
        "sum_min": float(sums.min()),
        "sum_max": float(sums.max()),
        "sum_ok": bool(np.allclose(sums, 1.0, atol=1e-4)),
        "negative": int(np.sum(sw < -1e-6)),
        "max_influences": int(sw.shape[1]),
        "verts_on_helper_bones": on_helper,
        "bones_without_weights": unused,
        "bones_used": len(used),
    }


# ------------------------------------------------------------ מדד תמונה


# --------------------------------------------------- ביקורת זהות הצוות

#: העצמה היחידה שמותר לה להישאר בלי משקולות. ``root`` היא טרנספורם
#: העל של הדמות ואין לה עור משלה - בדיוק כפי שנקבע ב-`test_rig`
#: ("סכום המשקולות הוא 1 בכל קודקוד", רשימה מותרת ``[] או ["root"]``).
#: הרשימה נלקחת משם ולא מומצאת כאן מחדש.
WEIGHTLESS_OK = ("root",)

#: מי נמדד. אלה בדיוק ארבע הדמויות ש-`pipeline.CAST` בונה לסרטון,
#: ולכן המדידה מודדת את מה שבאמת נבנה ולא דמות הדגמה.
AUDIT_NAMES = ("lucas", "maya", "zippy", "grump")

#: **מה שהביקורת הזאת אינה מודדת.** רשימה מוצהרת ולא הערה: ממד
#: שמחזיר "עובר" בלי לומר מה הוא לא בדק הוא בדיוק הממד שהיה כאן
#: לפני 08/10. היא נוסעת בתוך הפלט, כדי שכל קורא של הדוח יראה אותה.
KNOWN_GAPS = (
    "דליפת משקולת מקומית וקטנה (קודקוד שפה שנשלט בידי עצם כתף) "
    "שמשאירה את סכום המשקולות 1 - מדדי הפנים נמדדים על מקורות "
    "העצמות ולא על העור, ולכן אינם רואים אותה.",
    "זהות חזותית (צבע, חומר, שיער) - נמדדת ב'רינדור ומראה' "
    "ולא כאן, בכוונה: היסטוגרמה משתנה מהתאורה גם כשהדמות זהה.",
)


def _audit_one(name: str, quality: str = "fast") -> dict:
    """מודד זהות של דמות אחת מתוך ``pipeline.CAST``, **בלי דפדפן**.

    זה החלק שהיה חסר: `rig.acceptance` כבר חישב את אותו דוח, אבל הוא
    דורש GLB מרוגג על הדיסק, שרת מקומי ו-Chrome - ולכן מדידת הפרויקט
    לא יכלה לקרוא לו, ולא קראה. כאן אותה גאומטריה בדיוק מחושבת
    ישירות מ-`basemesh.to_arrays`, בכ-0.9 שנייה לדמות ובלי שום I/O.
    """
    from . import basemesh, controls, pipeline            # noqa: PLC0415

    c = pipeline.CAST[name]
    shape = dict(c["shape_override"])
    skel = Skeleton(height=c["height"],
                    shoulder_scale=float(shape.get("shoulder_scale", 1.0)),
                    head_scale=1.0,
                    accessories=tuple(c["accessories"]))
    mb, _meta = basemesh.build(skel, shape, quality=quality)
    attrs = basemesh.to_arrays(mb, skel)

    lib = controls.pose_library(skel)
    poses = {p: controls.evaluate(skel, *lib[p]) for p in sorted(lib)}

    geo = identity_report(skel, attrs, poses)
    health = weight_health(attrs, skel)
    weightless = [b for b in health["bones_without_weights"]
                  if b not in WEIGHTLESS_OK]
    return {"name": name, "height": float(c["height"]),
            "verts": int(attrs["position"].shape[0]),
            "poses": sorted(poses),
            "bone_length_drift": geo["bone_length_drift"]["max_rel"],
            "bone_drift_worst": geo["bone_length_drift"].get("worst"),
            "face_measure_drift": geo["face_measure_drift"]["max_rel"],
            "face_drift_worst": geo["face_measure_drift"].get("worst"),
            "rest_recovery_mm": geo["rest_recovery_worst_mm"],
            "rest_recovery_limit_mm": geo["rest_recovery_limit_mm"],
            "pose_separation_pct": geo["pose_separation"]["min_mean_pct"],
            "pose_separation_limit_pct": geo["pose_separation_limit_pct"],
            "rigid_verts": geo["rigid_verts"],
            "geometry_passes": bool(geo["passes"]),
            "weights": {k: v for k, v in health.items()
                        if k != "bones_without_weights"},
            "weightless_bones": weightless}


def audit(quality: str = "fast",
          names: tuple[str, ...] = AUDIT_NAMES) -> dict:
    """ביקורת זהות הדמות על כל הצוות, בצורת ``checks`` התקנית.

    **למה הפונקציה הזאת נולדה (08/10/2026).** "זהות הדמות" של מדידת
    הפרויקט נמדדה עד כאן ב-`dimorph.audit_shape` לבדה, כלומר בשבע
    בדיקות של *שפת הצורות* (זיגי עגול מול גרומפ מרובע). זו מדידה
    נכונה - אבל היא מודדת **עיצוב**, לא זהות: היא לא בודקת אפילו
    פעם אחת שהדמות נשארת אותה דמות אחרי שהיא זזה. לכן הממד הציג
    100 בעוד ששום מדד סחיפה לא נמדד בכלל, והראיה החמורה מכולן -
    ``detail`` - חזרה **ריקה** בכל מדידה שמורה בפרויקט
    (``{'pairs': {}}``), כי הקורא ביקש מפתחות ``pair``/``shape``
    שמעולם לא היו בתוצאה.

    ארבעה מדדי זהות אמיתיים נמדדים כאן לכל דמות, ושלושה מהם כבר
    היו מוגדרים בפרויקט עם ספים מוצהרים (`identity_report`), כך
    שאף סף לא הומצא כדי לעבור:

    * סחיפת אורכי עצמות בין הפוזות - סיבוב אינו משנה אורך.
    * סחיפת מדדי הפנים - משקולת לסת שדולפת לגלגל העין נתפסת כאן.
    * שחזור פוזת המנוחה מתוך הפוזה (מ"מ) - הצורה לא זזה, רק הסיבובים.
    * הפרדת הפוזות - בלעדיה "אפס סחיפה" היה עובר גם על דמות שקפואה.

    ועוד שלוש בדיקות בריאות משקולות, שהן מה ששובר דמויות בפועל.
    """
    per = {}
    problems: list[str] = []
    for n in names:
        try:
            per[n] = _audit_one(n, quality)
        except Exception as exc:                            # noqa: BLE001
            per[n] = {"name": n, "error": f"{type(exc).__name__}: {exc}"}
            problems.append(f"{n}: המדידה נפלה - {per[n]['error']}")

    good = [r for r in per.values() if "error" not in r]
    if not good:
        return {"task": "זהות הדמות - גאומטריה חסינת פוזה",
                "quality": quality, "per_character": per,
                "checks": {}, "passed": False, "problems": problems,
                "known_gaps": list(KNOWN_GAPS)}

    def worst(key, hi=True):
        vals = [r[key] for r in good]
        return max(vals) if hi else min(vals)

    # הסף היחסי 1e-6 הוא זה שכבר אוכף ב-`identity_report.passes`
    # וב-`acceptance.checks`, ולא מספר חדש. מדובר בסחיפה של מיליונית,
    # כלומר רעש float ולא תנועה.
    bl, fm = worst("bone_length_drift"), worst("face_measure_drift")
    rec = worst("rest_recovery_mm")
    sep = worst("pose_separation_pct", hi=False)
    rec_lim = good[0]["rest_recovery_limit_mm"]
    sep_lim = good[0]["pose_separation_limit_pct"]
    bad_w = sorted({b for r in good for b in r["weightless_bones"]})
    neg = sum(int(r["weights"]["negative"]) for r in good)
    sums_ok = all(bool(r["weights"]["sum_ok"]) for r in good)

    checks = {
        "bone_length_drift": {
            "value": bl, "limit": 1e-6, "pass": bool(bl < 1e-6),
            "why": "אורך עצם אינו משתנה בפוזה - סיבוב לא מותח"},
        "face_measure_drift": {
            "value": fm, "limit": 1e-6, "pass": bool(fm < 1e-6),
            "why": "מדדי הפנים חסינים לפוזה - אחרת משקולת דולפת"},
        "rest_recovery_mm": {
            "value": rec, "limit": rec_lim, "pass": bool(rec < rec_lim),
            "why": "פוזת המנוחה משוחזרת מהפוזה - הצורה לא נמחקה"},
        "pose_separation_pct": {
            "value": sep, "limit": sep_lim, "pass": bool(sep > sep_lim),
            "why": "הפוזות באמת שונות - אחרת אפס סחיפה חסר ערך"},
        "weights_sum_to_one": {
            "value": sums_ok, "limit": True, "pass": bool(sums_ok),
            "why": "סכום המשקולות 1 בכל קודקוד"},
        "no_negative_weights": {
            "value": neg, "limit": 0, "pass": neg == 0,
            "why": "משקולת שלילית מקפלת את העור"},
        "every_bone_weighted": {
            "value": len(bad_w), "limit": 0, "pass": not bad_w,
            "why": f"כל עצמה נושאת עור (פרט ל-{', '.join(WEIGHTLESS_OK)})"},
        "all_characters_measured": {
            "value": len(good), "limit": len(names),
            "pass": len(good) == len(names),
            "why": "כל הצוות נמדד - דמות שלא נמדדה אינה דמות שעברה"},
    }
    problems += [f"{k}: {v['why']}" for k, v in checks.items()
                 if not v["pass"]]
    return {"task": "זהות הדמות - גאומטריה חסינת פוזה",
            "quality": quality, "per_character": per, "checks": checks,
            "passed": all(v["pass"] for v in checks.values()),
            "problems": problems, "known_gaps": list(KNOWN_GAPS)}


# ------------------------------------------------------------ מדד תמונה


def image_signature(png_bytes: bytes) -> dict:
    """חתימה של רנדור: שיעור הכיסוי, מרכז המסה, וצבע חציוני של הדמות.

    משמש לשני דברים בלבד, ולא למדידת זהות:
    (1) לאמת שבאמת יש דמות בפריים ושהיא לא גזורה או ריקה,
    (2) לאמת שרנדור חוזר של אותה פוזה ואותה מצלמה יוצא זהה.
    """
    import io

    from PIL import Image
    im = Image.open(io.BytesIO(png_bytes)).convert("RGBA")
    a = np.asarray(im).astype(np.float64)
    alpha = a[:, :, 3] / 255.0
    mask = alpha > 0.35
    n = int(mask.sum())
    h, w = mask.shape
    if n == 0:
        return {"coverage": 0.0, "pixels": 0, "cx": 0.0, "cy": 0.0,
                "color": [0, 0, 0], "bbox": None}
    ys, xs = np.nonzero(mask)
    rgb = a[:, :, :3][mask]
    return {
        "coverage": n / float(h * w),
        "pixels": n,
        "cx": float(xs.mean() / w),
        "cy": float(ys.mean() / h),
        "color": [float(v) for v in np.median(rgb, axis=0)],
        "bbox": [int(xs.min()), int(ys.min()), int(xs.max()), int(ys.max())],
        "size": [w, h],
    }
