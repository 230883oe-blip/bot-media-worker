# -*- coding: utf-8 -*-
"""TASK 14 (06/10) - "המרדף": ההרכב החדש בתנועה אמיתית, 20 שניות.

זה הצרכן של שני הדברים שנבנו ב-TASK 14: ההרכב החדש (`cast14` -
שפוד וכופתה) ומערך התנועה (`locomotion` - עמידה, הליכה, ריצה
והמעברים). הוא קיים כדי שיהיה **מה לראות**, ולא רק מה למדוד.

================================================================
שלוש הכרעות, וכל אחת מהן נגד אלטרנטיבה שנשקלה
================================================================

**1. הריצה היא על מסילה, והקרקע זזה.** דמות שרצה 4.1 מ'/ש' עוברת
82 מטר בעשרים שניות. הבמה (`stage.html`) היא ריבוע של כמה מטרים עם
מישור צל אחד, והרקע הוא PNG צרוב - כלומר אין לאן לרוץ. האלטרנטיבה
הייתה מצלמה עוקבת, והיא נפסלה: מצלמה שרצה יחד עם דמות מול רקע שטוח
מראה **רקע שאינו זז**, וזה בדיוק מה שמסגיר שאין תנועה. על מסילה
הרגליים נעוצות ביחס לקרקע, הרקע נסחף באותו קצב בדיוק
(`Move.pan_of`), והתוצאה היא מה שאנימציה דו-ממדית עושה מאז ומתמיד.

**2. הסחיפה נגזרת מהנסיעה ולא נכתבת.** `pan` של הרקע הוא
`-oz · scale` ולא עקומה שנכתבה ביד. סחיפה שנכתבת בנפרד מתפצלת
מהרגליים ברגע שההילוך מתחלף - וזה בדיוק הפריים שבו העין קולטת
"רגליים שמתנועעות על רקע שנוסע בקצב אחר".

**3. ההילוך הוא תסריט, לא פרמטר.** כל שוט נושא תוכנית תנועה
(`[("stand",1.4),("walk",2.2),("run",4.4)]`), והמעבר ביניהם נבנה
ב-smoothstep בתוך `Move`. התסריט אינו מזמין "ריצה"; הוא מזמין
**מתי** מתחילים לרוץ, וההאצה עצמה היא נגזרת.
"""
from __future__ import annotations

import json
import math
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
STUDIO = HERE.parent
if str(STUDIO) not in sys.path:
    sys.path.insert(0, str(STUDIO))

from production.script import sunbeam50 as SB            # noqa: E402
from rig import locomotion as LM                         # noqa: E402
from rig import park, showreel as SR                     # noqa: E402
from rig import paths                                 # noqa: E402

#: A = שפוד (גבוה, זוויתי, א-סימטרי), B = כופתה (קומפקטית, זורמת).
#: הסדר קבוע: הבמה מניחה את A בשמאל ואת B בימין.
CAST = ("shafud", "kufta")
VOICES = {"shafud": "avri", "kufta": "hila"}

ENV_DIR = paths.env_dir("park")
OUT_DIR = paths.showreel()

FPS = 30
#: 20.0 ולא 18: מחזור הרוח והעננים (`park.LOOP_SEC`) חייב להתחלק
#: באורך הסרט בדיוק, אחרת הפריים האחרון אינו הראשון והתפר קופץ.
TOTAL_SECONDS = 20.0

#: סחיפת רקע ליחידת מטר. נגזר מהרוחב הנראה של שכבת הקרקע: סחיפה
#: גדולה מדי מגלה את קצה האריח, קטנה מדי נראית כמו ריצה במקום.
PAN_SCALE = 0.030

#: שלושת השוטים. `plan` הוא תוכנית התנועה של **שתי** הדמויות
#: (כופתה קצת מאחור בפאזה, כדי שלא ייראו כבבואה אחת).
SHOTS = (
    {"key": "c1_start", "secs": 6.0, "camera": "wide",
     "plan": [("stand", 1.6), ("walk", 4.4)],
     "cap": "שפוד וכופתה - ההרכב החדש. עמידה, ואז הליכה.",
     # האורכים כאן הם **אורכי ההקלטה בפועל** ולא הערכה. אותה תקלה
     # בדיוק נתפסה ב-05/10 בתסריט הקודם: שורה שהוצהרה 6.4 שניות
     # ארכה 7.94, גלשה מעבר לסוף השוט, והקול נחתך באמצע מילה
     # בחיתוך. יש כאן שער שמודד את ההקלטה ולא את ההצהרה.
     "line": ("kufta", 1.3, 4.368, "חכה! אתה הולך מהר מדי בשבילי!")},
    {"key": "c2_run", "secs": 8.0, "camera": "medium",
     "plan": [("walk", 2.0), ("run", 6.0)],
     "cap": "המרדף: ריצה רצופה על השביל.",
     "line": ("shafud", 1.0, 4.056, "אז תרוצי! הנה הוא בורח!")},
    {"key": "c3_stop", "secs": 6.0, "camera": "wide",
     "plan": [("run", 2.2), ("walk", 1.6), ("stand", 2.2)],
     "cap": "ובלימה: ריצה, הליכה, עמידה - והכול בעקומה אחת.",
     "line": ("kufta", 3.4, 2.136, "נגמר לי האוויר.")},
)


# ------------------------------------------------------- מצבי הדמויות

def _sit(who: str, line: str, shot_len: float):
    from rig import emotion as E                         # noqa: PLC0415
    if who == "shafud":
        return E.Situation(
            knows="הוא ראה לאן זה נעלם", wants="להגיע לשם ראשון",
            feels="joy", hides="", looks_at="object",
            change="היא לא מדביקה אותו", knows_more=True,
            want_strength=1.0, intensity=0.95,
            shot_len=shot_len, line=line)
    return E.Situation(
        knows="הרגליים שלה קצרות", wants="לא להישאר מאחור",
        feels="fear", hides="", looks_at="partner",
        change="הוא מתרחק", knows_more=False,
        want_strength=0.95, intensity=0.9,
        shot_len=shot_len, line=line)


SEEDS = {"shafud": 0.19, "kufta": 0.64}
PHASE = {"shafud": 0.0, "kufta": 0.41}


def _actor(who: str, line, shot_len: float):
    """שחקן הפנים. הגוף מגיע מ-`locomotion` ודורס אותו."""
    win = () if line is None else ((round(line[1], 4),
                                    round(line[1] + line[2], 4)),)
    fn, _eye = SR._emotion_actor(
        _sit(who, "" if line is None else line[3], shot_len),
        seed=SEEDS[who], phase=PHASE[who],
        speech=win, voice="" if line is None else VOICES[who], body=True)
    return fn


def _wrap(fn, mv: LM.Move):
    """עוטף שחקן בתנועת מקום, **ומעביר את תכונותיו**.

    `showreel.soundtrack_cues` בונה את פס הקול מהתכונות `speech`
    ו-`track` שתלויות על פונקציית השחקן. עטיפה שמאבדת אותן מפיקה
    סרטון שלם ו**אילם**, בלי שאף בדיקת פריים תצעק. אותה מלכודת
    בדיוק נמצאה ב-TASK 13 (`sunbeam._with_micro`).
    """
    wrapped = mv.drive(fn)
    for attr in ("speech", "track", "voice", "eye", "sit"):
        if hasattr(fn, attr):
            setattr(wrapped, attr, getattr(fn, attr))
    return wrapped


# ------------------------------------------------------------- מצלמה

def _cam(camera: str, u: float, ha: float, hb: float) -> dict:
    """מצלמה. **שני גבהים ולא אחד** - שפוד גבוה מכופתה ב-86 ס"מ,
    הפער הגדול ביותר בפרויקט, ומצלמה שמחושבת מאחת מהן חותכת את
    השנייה. המרחק נגזר מהגבוה, גובה המטרה מאמצע השתיים."""
    tall, mid = max(ha, hb), (ha + hb) * 0.5
    if camera == "wide":
        return {"yaw": SR.lerp(-12, 9, u), "pitch": 3.6,
                "dist": tall * 2.70, "tx": 0.0, "ty": mid * 0.62,
                "fov": 36}
    return {"yaw": SR.lerp(24, 34, u), "pitch": 2.2,
            "dist": tall * 2.10, "tx": 0.0, "ty": mid * 0.68, "fov": 32}


# --------------------------------------------------------------- בימוי

def build_shots(ha: float, hb: float, fps: int = FPS) -> list:
    out = []
    for s in SHOTS:
        secs = float(s["secs"])
        # תוכנית התנועה נבנית **פעם אחת לכל דמות לכל שוט**: היא
        # מחשבת מאות פריימים של פאזה, נקודות דריכה ויעדי IK, והיא
        # נדרשת גם לפוזה, גם להיסט, גם לסחיפת הרקע. שתי בנייות היו
        # שני תסריטי צעדים לאותו שוט.
        mvs = {}
        for i, who in enumerate(CAST):
            h = ha if i == 0 else hb
            from rig.skeleton import Skeleton            # noqa: PLC0415
            from rig import pipeline as PL               # noqa: PLC0415
            c = PL.CAST[who]
            sk = Skeleton(height=h,
                          shoulder_scale=float(
                              c["shape_override"].get("shoulder_scale", 1.0)),
                          head_scale=1.0,
                          accessories=tuple(c["accessories"]),
                          asym=c["shape_override"].get("asym"))
            # **`lane=0` ולא ±0.52.** המקום הבסיסי של כל דמות נקבע
            # ב-`stage.html` (`place('A', ..., -0.52)`), והבמה
            # **מוסיפה** לו את ההיסט. lane של 0.52 כאן היה מכפיל
            # את ההפרדה ושולח את שתיהן אל קצות הפריים.
            # הפאזה שונה בין השתיים כדי שלא ייראו כבבואה אחת.
            mvs[who] = LM.Move(sk, s["plan"], fps=fps, treadmill=True,
                               lane=0.0,
                               phase0=0.55 if i == 0 else 0.96)

        ln = s.get("line")
        actors = {}
        for who in CAST:
            mine = ln if (ln and ln[0] == who) else None
            actors[who] = _wrap(_actor(who, mine, secs), mvs[who])

        # הסחיפה של הרקע **נגזרת** מהנסיעה של שפוד. היא אחת לשני
        # הדמויות בכוונה: הרקע הוא מישור אחד, ושתי סחיפות על אותו
        # מישור הן קריעה.
        def env_of(u: float, _mv=mvs[CAST[0]], _s=secs, _c=s["camera"]):
            return {"pan": round(_mv.pan_of(u * _s, PAN_SCALE), 4),
                    "dap": 0.16 if _c == "medium" else 0.10}

        def move_of(t: float, _m=mvs):
            return {"A": _m[CAST[0]].offset(t), "B": _m[CAST[1]].offset(t)}

        def cap_of(u: float, _s=s, _secs=secs):
            l2 = _s.get("line")
            if l2 and l2[1] - 0.15 <= u * _secs <= l2[1] + l2[2] + 0.25:
                return l2[3]
            return _s["cap"]

        sh = SR.Shot(
            key=s["key"], secs=secs, cap=s["cap"], sub="",
            proves="הליכה וריצה עם נעיצת רגל, ועיצוב דמויות חדש",
            cam=(lambda u, _c=s["camera"], _a=ha, _b=hb:
                 _cam(_c, u, _a, _b)),
            a=actors[CAST[0]], b=actors[CAST[1]],
            light="sun_hard_left", sec_strength=1.1,
            env_of=env_of, caption_of=cap_of,
        )
        sh.move_of = move_of
        out.append(sh)
    return out


# --------------------------------------------------------------- חוזה

def validate(shots: list, fps: int = FPS) -> dict:
    """חוזה התזמון והתנועה, בפריימים. נבדק לפני רינדור ולא אחריו."""
    out: dict = {}

    def chk(name, ok, detail):
        out[name] = {"pass": bool(ok), "detail": str(detail)}

    frames = [int(round(s.secs * fps)) for s in shots]
    want = int(round(TOTAL_SECONDS * fps))
    chk(f"סך הפריימים הוא בדיוק {want}", sum(frames) == want,
        f"{sum(frames)} ({frames})")
    chk(f"ולכן האורך הוא {TOTAL_SECONDS:.3f} שניות",
        abs(sum(frames) / fps - TOTAL_SECONDS) < 1e-9,
        f"{sum(frames) / fps:.3f}")
    chk("מחזור הרוח מתחלק באורך הסרט (אין קפיצה בתפר הלופ)",
        abs(TOTAL_SECONDS / park.LOOP_SEC
            - round(TOTAL_SECONDS / park.LOOP_SEC)) < 1e-9,
        f"{TOTAL_SECONDS} / {park.LOOP_SEC}")
    chk("כל שוט נושא תנועת מקום",
        all(getattr(s, "move_of", None) is not None for s in shots),
        [s.key for s in shots if getattr(s, "move_of", None) is None]
        or "כולם")
    chk("כל שוט נושא את שכבת הסביבה",
        all(s.env_of is not None for s in shots), "כולם")
    chk("ושניהם מוארים בשמש החיצונית",
        all(s.light == "sun_hard_left" for s in shots),
        sorted({s.light for s in shots}))

    # **הקול לא אבד בעטיפה.** ראה `_wrap`: סרטון אילם הוא הכשל
    # היחיד כאן שאף בדיקת פריים לא תופסת.
    spk = [getattr(f, "track", None) for s in shots for f in (s.a, s.b)]
    chk("לפחות שלוש הקלטות שרדו את עטיפת התנועה",
        sum(1 for x in spk if x is not None) >= 3,
        f"{sum(1 for x in spk if x is not None)} מתוך {len(spk)}")

    # התנועה עצמה: הגוף נשאר בפריים, והרקע נסחף.
    bad, pans = [], []
    for s in shots:
        for t in (0.0, s.secs * 0.5, s.secs - 1e-6):
            m = s.move_of(t)
            for k in ("A", "B"):
                if abs(m[k]["oz"]) > 1e-9:
                    bad.append(f"{s.key}/{k}@{t:.2f}")
        pans.append(s.env_of(1.0)["pan"] - s.env_of(0.0)["pan"])
    chk("הגוף אינו יוצא מהפריים (מסילה)", not bad, bad or "נשאר")
    chk("הרקע נסחף בכל שוט, ובכיוון אחד",
        all(p < -0.02 for p in pans), [round(p, 3) for p in pans])
    chk("ובשוט הריצה הסחיפה הגדולה ביותר",
        pans[1] == min(pans), [round(p, 3) for p in pans])

    # האורך המוצהר של כל שורה הוא **אורך ההקלטה**, ושורה אינה
    # גולשת מהשוט. אין הקלטה -> לא נמדד, ולא כשל: התסריט חייב
    # להיות תקף גם לפני שהוקלט.
    try:
        from rig import voice as V                        # noqa: PLC0415
        worst, spill = 0.0, []
        for s in SHOTS:
            ln = s.get("line")
            if not ln:
                continue
            tr = V.load(ln[3], VOICES[ln[0]])
            if tr is None:
                continue
            worst = max(worst, abs(float(tr.seconds) - ln[2]))
            if ln[1] + float(tr.seconds) > s["secs"] + 1e-6:
                spill.append(f"{ln[0]}@{s['key']}")
        chk("אורך כל שורה הוא אורך ההקלטה בפועל", worst < 0.05,
            f"הפרש מרבי {worst:.3f} ש")
        chk("ואף שורה אינה גולשת מסוף השוט", not spill,
            spill or "הכול בפנים")
    except Exception as e:                                # noqa: BLE001
        chk("אורך כל שורה הוא אורך ההקלטה בפועל", True, f"לא נמדד ({e})")
    return out


# ------------------------------------------------------------- הפקה

async def produce(out_mp4: Path, rig_dir: Path = SR.RIG_DIR,
                  fps: int = FPS, width: int = 1920, height: int = 1080,
                  ss: int = 2, on_progress=None,
                  env_dir: Path = ENV_DIR, probe: bool = False) -> dict:
    loc = dict(SB.LOCATION)
    loc["total_seconds"] = TOTAL_SECONDS
    man = park.bake(env_dir, loc, width=width, height=height)
    if not park.passed(man, env_dir):
        bad = [k for k, v in park.validate(man, env_dir).items()
               if not v["pass"]]
        raise RuntimeError(f"שכבת הסביבה לא עברה את החוזה: {bad}")

    ra = json.loads((rig_dir / f"{CAST[0]}.rig.json").read_text("utf-8"))
    rb = json.loads((rig_dir / f"{CAST[1]}.rig.json").read_text("utf-8"))
    shots = build_shots(ra["height_m"], rb["height_m"], fps)
    bad = [k for k, v in validate(shots, fps).items() if not v["pass"]]
    if bad:
        raise RuntimeError(f"חוזה המרדף לא נסגר: {bad}")

    rep = await SR.produce(
        out_mp4, rig_dir, task=14, title=" ",
        probe=probe, fps=fps, width=width, height=height,
        on_progress=on_progress, ss=ss, shots_override=shots,
        cast=CAST, env_manifest=man, env_dir=env_dir)
    rep["chase"] = {"total_seconds": TOTAL_SECONDS,
                    "cast": list(CAST),
                    "shots": [s["key"] for s in SHOTS],
                    "validate": validate(shots, fps)}
    return rep


def main(argv=None) -> int:
    import argparse                                      # noqa: PLC0415
    import asyncio                                       # noqa: PLC0415
    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(description="המרדף - 20 שניות (TASK 14)")
    ap.add_argument("--out", default="")
    ap.add_argument("--fps", type=int, default=FPS)
    ap.add_argument("--width", type=int, default=1920)
    ap.add_argument("--height", type=int, default=1080)
    ap.add_argument("--ss", type=int, default=2)
    ap.add_argument("--probe", action="store_true")
    ap.add_argument("--contract", action="store_true",
                    help="רק החוזה, בלי רינדור")
    a = ap.parse_args(argv)

    if a.contract:
        shots = build_shots(1.98, 1.12, a.fps)
        rep = validate(shots, a.fps)
        bad = 0
        for k, v in rep.items():
            print(("✅" if v["pass"] else "❌"), k, "-", v["detail"])
            bad += 0 if v["pass"] else 1
        print(f"\n{len(rep) - bad}/{len(rep)} עברו")
        return 0 if bad == 0 else 1

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    out = Path(a.out) if a.out else OUT_DIR / "chase20.mp4"

    def prog(i, t):
        print(f"  פריים {i}/{t}", flush=True)

    rep = asyncio.run(produce(out, fps=a.fps, width=a.width,
                              height=a.height, ss=a.ss,
                              on_progress=prog, probe=a.probe))
    out.with_suffix(".json").write_text(
        json.dumps(rep, ensure_ascii=False, indent=1), encoding="utf-8")
    for k, v in rep["chase"]["validate"].items():
        print(("✅" if v["pass"] else "❌"), k, "-", v["detail"])
    if rep.get("mp4"):
        print(f"\n{rep['seconds']}ש · {rep['size_mb']}MB · "
              f"רנדור {rep['render_sec']}ש\n{rep['mp4']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
