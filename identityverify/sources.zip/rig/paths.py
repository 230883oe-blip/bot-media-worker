# -*- coding: utf-8 -*-
r"""שורש נכסי ההפקה - **נקודה אחת**, ולא נתיב ווינדוס קשיח בכל מודול.

למה זה נכתב. עד 08/10 עשרים ושבעה מקומות בקוד החזיקו
``Path(r"D:\claude-bot\out\char3d\...")`` כקבוע מודול. על המחשב הזה
זה עבד, ולכן אף אחד לא הרגיש בזה - אבל ברגע שחבילת הבדיקות רצה על
שרת לינוקס (GitHub Actions) הנתיב הזה הוא **מחרוזת חסרת משמעות**,
ו-``Path`` בלינוקס אינו מזהה ``D:\`` ככונן אלא כשם קובץ אחד ארוך עם
לוכסנים הפוכים בתוכו. התוצאה שנמדדה בריצה 37699431625:

    FileNotFoundError: 'D:\\claude-bot\\out\\char3d\\rigged/zippy.rig.json'

והיא הפילה את חבילת הבדיקות **באמצע**, כלומר כל הבדיקות שאחריה
(ובהן ``t_arkit``, זו שבגללה הריצה נעשתה) לא רצו בכלל.

## שלוש דרגות, בסדר הזה

1. ``ANIM_OUT_ROOT`` בסביבה - מי שיודע איפה הנכסים גובר על כל ניחוש.
2. השורש ההיסטורי ``D:\claude-bot\out`` **אם הוא קיים בפועל**. זה
   מה שמשאיר את המחשב הזה בדיוק כפי שהיה: אותם קבצים, אותם נתיבים,
   אפס מיגרציה.
3. ``<שורש הפרויקט>/out`` - נגזר מ-``Path(__file__)`` ולכן נכון בכל
   מערכת הפעלה ובכל תיקיית עבודה.

## למה לא להעביר הכול ל-(3) ולסיים

כי הנכסים (``*.rig.json``, ``*.attrs.npz``, סביבות הפארק) הם מאות
מגה־בייט ואינם ב-git. העברה כזו הייתה *מוחקת* את הנכסים הקיימים
מבחינת הקוד בלי להזיז אף קובץ - כלומר הופכת תקלה בענן לתקלה גם כאן.
הדרגה (2) היא מה שמונע את זה.

## חוזה

אף פונקציה כאן **אינה יוצרת תיקיות**. מי שכותב - יוצר. שאילתת נתיב
שיוצרת תיקייה בייבוא היא מה שמלכלך דיסק בכל ריצת בדיקות.
"""
from __future__ import annotations

import os
from pathlib import Path

#: שורש הפרויקט - התיקייה שמעל ``rig/``. נגזר ולא נכתב.
PROJECT_ROOT: Path = Path(__file__).resolve().parent.parent

#: השורש ההיסטורי. נבדק בקיום, לא מונח.
LEGACY_ROOT: Path = Path("D:/claude-bot/out")

_ENV = "ANIM_OUT_ROOT"


def _resolve() -> tuple[Path, str]:
    env = os.environ.get(_ENV)
    if env:
        return Path(env).expanduser().resolve(), "env"
    try:
        if LEGACY_ROOT.is_dir():
            return LEGACY_ROOT, "legacy"
    except OSError:
        # נתיב עם תחביר לא חוקי במערכת הזו. בלינוקס ``D:/...`` הוא
        # שם חוקי אך לא קיים, ולכן בפועל זה פשוט יחזיר False.
        pass
    return PROJECT_ROOT / "out", "project"


OUT_ROOT, SOURCE = _resolve()

#: תיקיית הדמויות התלת־ממדיות. כל הנכסים יושבים תחתיה.
CHAR3D: Path = OUT_ROOT / "char3d"


def out(*parts: str) -> Path:
    """נתיב תחת שורש הפלט."""
    return OUT_ROOT.joinpath(*parts)


def char3d(*parts: str) -> Path:
    """נתיב תחת ``<שורש>/char3d``."""
    return CHAR3D.joinpath(*parts)


def rigged(*parts: str) -> Path:
    """תיקיית הדמויות הממורגות (``*.rig.json`` + ``*.attrs.npz``)."""
    return CHAR3D.joinpath("rigged", *parts)


def env_dir(*parts: str) -> Path:
    """תיקיית סביבות (פארק וכו')."""
    return CHAR3D.joinpath("env", *parts)


def showreel(*parts: str) -> Path:
    return CHAR3D.joinpath("showreel", *parts)


def have_assets(*names: str) -> bool:
    """האם הנכסים הממורגים של הדמויות האלה קיימים כאן בפועל.

    זה השער שבדיקה תלויית־נכסים צריכה לעבור לפני שהיא נוגעת בדיסק.
    בלעדיו היא זורקת ``FileNotFoundError`` ומפילה את כל הריצה שאחריה
    - וזה בדיוק מה שקרה בענן.
    """
    base = CHAR3D / "rigged"
    try:
        if not base.is_dir():
            return False
        if not names:
            return any(base.glob("*.rig.json"))
        return all((base / f"{n}.rig.json").is_file()
                   and (base / f"{n}.attrs.npz").is_file() for n in names)
    except OSError:
        return False


def describe() -> str:
    return (f"שורש הפלט: {OUT_ROOT}  (מקור: {SOURCE})\n"
            f"שורש הפרויקט: {PROJECT_ROOT}\n"
            f"נכסים ממורגים: {'קיימים' if have_assets() else 'לא נבנו כאן'}")


if __name__ == "__main__":
    print(describe())
